(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const s of document.querySelectorAll('link[rel="modulepreload"]'))n(s);new MutationObserver(s=>{for(const a of s)if(a.type==="childList")for(const r of a.addedNodes)r.tagName==="LINK"&&r.rel==="modulepreload"&&n(r)}).observe(document,{childList:!0,subtree:!0});function e(s){const a={};return s.integrity&&(a.integrity=s.integrity),s.referrerPolicy&&(a.referrerPolicy=s.referrerPolicy),s.crossOrigin==="use-credentials"?a.credentials="include":s.crossOrigin==="anonymous"?a.credentials="omit":a.credentials="same-origin",a}function n(s){if(s.ep)return;s.ep=!0;const a=e(s);fetch(s.href,a)}})();const Gd={save(i,t){try{localStorage.setItem(i,t)}catch{}},load(i){try{return localStorage.getItem(i)}catch{return null}}},Rp={name:"web",adsAvailable:!1,onMute:null,async init(){},loadingStart(){},loadingStop(){},gameplayStart(){},gameplayStop(){},happytime(){},async rewarded(){return!1},async midgame(){return!1},save:Gd.save,load:Gd.load,muted:()=>!1,notify(){},cancelNotify(){}},jn=(i,t=0,e=1)=>i<t?t:i>e?e:i;function st(i){if(!isFinite(i))return"∞";const t=Math.abs(i);if(t<1e3)return String(Math.floor(i));const e=["K","M","B","T","Qa","Qi"];let n=-1,s=t;for(;s>=1e3&&n<e.length-1;)s/=1e3,n++;return(i<0?"-":"")+(s>=100?Math.floor(s):s>=10?s.toFixed(1).replace(/\.0$/,""):s.toFixed(2).replace(/\.?0+$/,""))+e[n]}function pe(i){if(i=Math.max(0,Math.ceil(i)),i<60)return i+"s";const t=Math.floor(i/86400),e=Math.floor(i%86400/3600),n=Math.floor(i%3600/60),s=i%60;return t?`${t}d ${e}h`:e?`${e}h ${n}m`:s&&n<10?`${n}m ${s}s`:`${n}m`}const ut=i=>String(i).replace(/[&<>"']/g,t=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[t]);function Tn(i){let t=i>>>0;return()=>{t=t+1831565813|0;let e=Math.imul(t^t>>>15,1|t);return e=e+Math.imul(e^e>>>7,61|e)^e,((e^e>>>14)>>>0)/4294967296}}function js(i){let t=2166136261;for(let e=0;e<i.length;e++)t^=i.charCodeAt(e),t=Math.imul(t,16777619);return t>>>0}let Cp=0;const Ye=(i="x")=>i+Date.now().toString(36)+(Cp++).toString(36)+Math.floor(Math.random()*1296).toString(36),xe=(i,t=document)=>t.querySelector(i),Es=(i,t=document)=>Array.from(t.querySelectorAll(i)),Yt=i=>{if(i<100)return Math.round(i);const t=Math.pow(10,Math.floor(Math.log10(i))-1);return Math.round(i/t)*t},Pp=100,kl=i=>Math.round(40*Math.pow(i,1.85)),Lp=i=>({dm:3+Math.floor(i/5),credits:100*i}),Qr=[{id:"a1",text:"Tap the Solar Bay to collect the credits Helio earned",kind:"collect",n:1,reward:{credits:150},hint:"bay"},{id:"a2",text:"Start a recipe at the Fabricator",kind:"craft",n:1,reward:{cells:20},hint:"fab"},{id:"a3",text:"Harvest Power Cells from the Fabricator",kind:"harvest",n:1,reward:{credits:100},hint:"fab"},{id:"a4",text:"Feed Helio until it reaches level 2",kind:"botLevel",n:2,reward:{cells:40,dm:5},hint:"bay"},{id:"a5",text:"Recruit Ember from the Shop (Bots tab)",kind:"ownSpecies",t:"ember",reward:{credits:200},hint:"shop"},{id:"a6",text:"Build a Plasma Bay so Ember has a home",kind:"bayEl",t:"plasma",reward:{credits:250},hint:"shop"},{id:"a7",text:"Upgrade the Command Center to level 2",kind:"cc",n:2,reward:{dm:10,credits:300},hint:"command"},{id:"a8",text:"Place a decoration (Shop → Decor)",kind:"decor",n:1,reward:{credits:150}},{id:"a9",text:"Raise any bot to level 4",kind:"botLevel",n:4,reward:{cells:150,dm:10}},{id:"a10",text:"Upgrade a Bay to level 2 (more credit storage)",kind:"bayLevel",n:2,reward:{credits:500}},{id:"a11",text:"Expand the island: buy a new plot of land",kind:"land",n:1,reward:{dm:15}},{id:"a12",text:"Run 4 bots",kind:"bots",n:4,reward:{credits:800}},{id:"a13",text:"Reach Commander level 6",kind:"level",n:6,reward:{dm:20}},{id:"a14",text:"Upgrade the Command Center to level 4",kind:"cc",n:4,reward:{credits:2500,dm:15}},{id:"b1",text:"Build the Assembly Bay (Shop → Buildings)",kind:"build",t:"assembly",reward:{credits:1e3,dm:10}},{id:"b2",text:"Post a bot as a helper at the Fabricator (tap a bot)",kind:"helper",reward:{cells:300}},{id:"b3",text:"Build the Fusion Lab",kind:"build",t:"fusion",reward:{credits:1500,dm:15}},{id:"b4",text:"Fuse two level-4 bots in the Fusion Lab",kind:"fusions",n:1,reward:{cells:400,dm:10}},{id:"b5",text:"Boot the new core in the Assembly Bay and activate it",kind:"boots",n:1,reward:{credits:1500}},{id:"a15",text:"Recruit an Advanced hybrid bot",kind:"rarity",t:"advanced",reward:{dm:30}},{id:"b6",text:"Discover 12 species in the Botdex",kind:"dex",n:12,reward:{dm:25}},{id:"b7",text:"Upgrade the Command Center to level 6",kind:"cc",n:6,reward:{credits:8e3,dm:20}},{id:"b8",text:"Fuse an Elite bot (three elements)",kind:"rarity",t:"elite",reward:{dm:40}},{id:"b9",text:"Discover 25 species",kind:"dex",n:25,reward:{dm:40}},{id:"b10",text:"Fuse an Epic bot",kind:"rarity",t:"epic",reward:{dm:60}},{id:"c1",text:"Build the Arena (Shop → Buildings)",kind:"build",t:"arena",reward:{credits:3e3,dm:15}},{id:"c2",text:"Win your first Arena battle",kind:"arenaWins",n:1,reward:{cells:500,dm:15}},{id:"c3",text:"Reach the Silver league",kind:"trophies",n:350,reward:{dm:30}},{id:"b11",text:"Reach Commander level 20",kind:"level",n:20,reward:{dm:50}},{id:"d1",text:"Build the Launch Pad (Shop → Buildings)",kind:"build",t:"pad",reward:{credits:6e3,dm:20}},{id:"d2",text:"Send a bot crew to the Moon (Space)",kind:"visit",t:"moon",reward:{cells:1500,dm:15}},{id:"d3",text:"Build an outpost on a world you have visited",kind:"outposts",n:1,reward:{credits:8e3}},{id:"c4",text:"Reach the Gold league",kind:"trophies",n:850,reward:{dm:60}},{id:"e1",text:"Found Tranquility Base on the Moon (island button, top left)",kind:"island",t:"moon",reward:{credits:2e4,dm:30}},{id:"e2",text:"Build a Bay on the Moon",kind:"bayOn",t:"moon",reward:{cells:5e3}},{id:"d4",text:"Land a crew on Mars",kind:"visit",t:"mars",reward:{dm:40}},{id:"e3",text:"Found Bradbury Landing on Mars",kind:"island",t:"mars",reward:{credits:1e5,dm:60}},{id:"d5",text:"Reach Europa's hidden ocean",kind:"visit",t:"europa",reward:{dm:60}},{id:"d6",text:"Reach Pluto, the edge of the Solar System",kind:"visit",t:"pluto",reward:{dm:120}},{id:"f1",text:"Repel a Kr'thul raid (tap the red Swarm warning)",kind:"raids",n:1,reward:{dm:40,cells:8e3}},{id:"f2",text:"Make first contact at Proxima Centauri (Starship, Launch Pad level 10)",kind:"visit",t:"proxima",reward:{dm:150}},{id:"h1",text:"Claim a reward in this week's event (event button, top right)",kind:"eventSteps",n:1,reward:{dm:25}},{id:"f3",text:"Meet all five civilisations",kind:"visit",t:"epseri",reward:{dm:300}},{id:"g1",text:"Found the Precursor Vault (island button)",kind:"island",t:"vault",reward:{dm:200}},{id:"g2",text:"Summon your first Relic AI",kind:"relics",n:1,reward:{dm:100}},{id:"g3",text:"Forge relic crystals at the Relic Forge twice",kind:"forged",n:2,reward:{dm:150}},{id:"g4",text:"Run six Relic AIs",kind:"relics",n:6,reward:{dm:300}}],_u=1;function zl(i=Date.now()){const t=(r,o,l,c=1,d)=>({id:Ye("i"),t:r,x:o,z:l,r:0,lvl:c,...d?{el:d}:{}}),e=t("command",13,13),n=t("bay",8,9,1,"solar"),s=t("fab",19,9);return{v:_u,created:i,last:i,name:"New Haven",res:{credits:600,cells:30,dm:25,iridium:0},xp:0,lvl:1,islands:{home:{plots:["1,1","2,1","3,1","1,2","2,2","3,2","1,3","2,3","3,3"],bought:0,items:[e,n,s,t("tree",12,9),t("tree",17,18),t("rock",8,19),t("tree",9,18),t("path",14,17),t("path",15,17),t("path",14,18),t("path",15,18)]}},at:"home",bots:[{id:Ye("b"),sp:"helio",lvl:1,fed:0,bay:n.id,born:i}],jobs:[],cores:[],dex:{helio:i},bay:{[n.id]:120},ready:{},obj:{i:0,claimed:{}},stats:{},settings:{sfx:.8,music:.45,quality:"auto"},paint:{primary:"#e9eef5",accent:"#22c7e8"},banner:{bg:"#1b6fd8",fg:"#ffd23a",emblem:"star"},builders:2,landBought:0,tut:0}}function Dp(i){const t=zl(i.created||Date.now()),e=i;e.isl&&!e.islands&&(e.islands={home:{plots:e.isl.plots,items:e.isl.items,bought:e.landBought||0}},e.at="home",delete e.isl);for(const s in t)e[s]===void 0&&(e[s]=t[s]);for(const s in t.settings)e.settings[s]===void 0&&(e.settings[s]=t.settings[s]);e.res.iridium===void 0&&(e.res.iridium=0);for(const s of i.bots)i.dex[s.sp]||(i.dex[s.sp]=s.born||Date.now());const n=Qr.findIndex(s=>!i.obj.claimed[s.id]);return i.obj.i=n<0?Qr.length:n,i.v=_u,i}const Vd=[3,20,60,180,600,1800,3600,2*3600,4*3600,8*3600,12*3600,16*3600,24*3600,36*3600,48*3600],Vn=(i,t=0)=>Vd[Math.min(Vd.length-1,Math.max(0,i-1+t))],Wn=(i,t,e,n,s)=>({name:i,size:t,cat:"decor",max:1,unlock:n,desc:s,buildCost:()=>e,upCost:()=>0,time:()=>0}),Qt={command:{name:"Command Center",size:[4,4],cat:"core",max:15,unique:!0,unlock:1,desc:"The heart of your colony. Its level sets how far every other building can grow, and how many Bays and Fabricators you can run.",buildCost:()=>0,upCost:i=>Yt(400*Math.pow(2.05,i-1)),time:i=>Vn(i,0)},hub:{name:"Colony Hub",size:[4,4],cat:"core",max:13,unlock:1,desc:"The heart of an off-world island. Its level caps every building here, and it stays two levels below your Command Center.",buildCost:()=>0,upCost:i=>Yt(900*Math.pow(2.05,i-1)),time:i=>Vn(i,1)},bay:{name:"Bot Bay",size:[3,3],cat:"bay",max:10,unlock:1,desc:"Home and charging dock for bots of its element. Bots earn credits here; the bay holds them until you collect.",buildCost:i=>Yt(150*Math.pow(1.6,i)),upCost:i=>Yt(250*Math.pow(1.9,i-1)),time:i=>Vn(i,-1)},fab:{name:"Fabricator",size:[3,3],cat:"production",max:10,unlock:1,desc:"Prints Power Cells for your bots. Pick a recipe that matches when you will be back.",buildCost:i=>Yt(300*Math.pow(2.4,i)),upCost:i=>Yt(400*Math.pow(1.95,i-1)),time:i=>Vn(i,-1)},assembly:{name:"Assembly Bay",size:[3,3],cat:"production",max:10,unique:!0,unlock:4,desc:"Boots new bot cores: from the shop, from the Fusion Lab and from events. More levels boot more cores at once, faster.",buildCost:()=>1500,upCost:i=>Yt(1800*Math.pow(1.9,i-1)),time:i=>Vn(i,0)},fusion:{name:"Fusion Lab",size:[4,3],cat:"production",max:10,unique:!0,unlock:5,desc:"Fuses two bots of level 4 or more into a new core. The child may take after either parent, or be a hybrid of both: sometimes a rarer one.",buildCost:()=>3e3,upCost:i=>Yt(3500*Math.pow(1.9,i-1)),time:i=>Vn(i,1)},arena:{name:"Arena",size:[4,4],cat:"production",max:10,unique:!0,unlock:6,desc:"Your gateway to the holo-arena in orbit: pick three bots and battle rival colonies for trophies, rewards and league glory.",buildCost:()=>5e3,upCost:i=>Yt(5e3*Math.pow(1.9,i-1)),time:i=>Vn(i,1)},pad:{name:"Launch Pad",size:[3,3],cat:"production",max:10,unique:!0,unlock:10,desc:"Rockets crewed by your bots fly expeditions across the Solar System. Higher levels unlock bigger rockets (further worlds) and more launch slots.",buildCost:()=>12e3,upCost:i=>Yt(12e3*Math.pow(1.85,i-1)),time:i=>Vn(i,1)},mine:{vault:!0,name:"Crystal Mine",size:[2,2],cat:"production",max:10,unlock:27,desc:"Digs relic crystals out of the Precursor bedrock. Pick a colour and a dig; deeper digs take longer and pay more.",buildCost:i=>Yt(6e4*Math.pow(1.8,i)),upCost:i=>Yt(5e4*Math.pow(1.8,i-1)),time:i=>Vn(i,2)},forge:{vault:!0,name:"Relic Forge",size:[3,3],cat:"production",max:1,unique:!0,unlock:27,desc:"Fuses four relic crystals and some Iridium into one of the next tier.",buildCost:()=>12e4,upCost:()=>0,time:i=>Vn(i,4)},relicbay:{vault:!0,name:"Relic Sanctum",size:[3,3],cat:"bay",max:10,unlock:27,desc:"An ancient arch that wakes Relic AIs of its element. They earn Iridium here.",buildCost:i=>Yt(9e4*Math.pow(1.7,i)),upCost:i=>Yt(8e4*Math.pow(1.85,i-1)),time:i=>Vn(i,2)},monolith:{...Wn("Precursor Monolith",[1,1],2e4,27,"A black monolith covered in moving glyphs."),vault:!0},tree:Wn("Holo Tree",[1,1],40,1,"A glowing tree grown from engineered moss and fibre optics."),rock:Wn("Moon Rock",[1,1],30,1,"A souvenir boulder. Every colony keeps one."),path:Wn("Walkway",[1,1],10,1,"A paved tile for paths and plazas."),lamp:Wn("Lumen Post",[1,1],60,2,"A tall lamp with a soft, warm glow."),flag:Wn("Colony Flag",[1,1],100,3,"Flies your colony colours."),crystal:Wn("Crystal Cluster",[1,1],250,4,"Grown in microgravity, sold by the kilo."),fountain:Wn("Gravity Fountain",[2,2],600,5,"Water arcing in a gentle artificial gravity well."),dish:Wn("Dish Array",[2,2],900,7,"Listening to the stars, mostly for show."),statue:Wn("Bot Statue",[2,2],1500,9,"A monument to the bots who built the colony."),arch:{...Wn("Starlight Arch",[2,1],0,1,"A ring of light that only loyal commanders own. Earned on day 21 of the login calendar."),exclusive:"calendar"}},Wd=["bay","fab","assembly","fusion","arena","pad","tree","rock","path","lamp","flag","crystal","fountain","dish","statue"],Ca=i=>2+i,Ws=i=>1+Math.floor(i/3),Xs=[0,0,2,3,5,7,9,12,15,18,21,25,29,33,38,44],Jn=i=>2+Math.floor((i-1)/3),Mu=i=>Yt(400*Math.pow(2,i-1)),Si={command:["alloy","geo","kinetic"],fab:["solar","volt","plasma"],fusion:["neural","chrono","photon"],assembly:["alloy","neural","volt"]},Xd={command:"construction speed",fab:"Power Cells per recipe",fusion:"fusion speed",assembly:"boot speed"},Qs=i=>1+(i>=5?1:0)+(i>=9?1:0),Fa=i=>1+Math.floor((Math.max(1,i)-1)/3),ta=[{name:"Quick Charge",sec:30,cells:12,cost:20,xp:1,lvl:1},{name:"Standard Cells",sec:300,cells:60,cost:80,xp:3,lvl:1},{name:"Battery Pack",sec:1800,cells:240,cost:300,xp:8,lvl:2},{name:"Power Core",sec:7200,cells:700,cost:900,xp:20,lvl:3},{name:"Fusion Rod",sec:8*3600,cells:2200,cost:2600,xp:50,lvl:5},{name:"Star Battery",sec:24*3600,cells:6e3,cost:6500,xp:120,lvl:7}],Su=(i,t)=>Math.round(i.cells*(1+.1*(t-1))),fe=6,$l=5,Ip=i=>Yt(800*Math.pow(2,i)),Np=i=>3+i*2,j=(i,t,e,n,s,a,r)=>({name:i,el:t,rarity:e,chassis:n,desc:s,...a?{price:a,unlock:r}:{}}),tt={helio:j("Helio",["solar"],"standard","orb","A floating solar collector with a sunny disposition. Your first crewmate.",300,1),ember:j("Ember",["plasma"],"standard","rover","Welds hull plates with a plasma torch it is very proud of.",350,1),tidepool:j("Tidepool",["hydro"],"standard","crawler","Recycles every drop of water on the island. Twice.",400,2),frostbyte:j("Frostbyte",["cryo"],"standard","walker","Keeps the servers cold and the jokes colder.",450,3),digger:j("Digger",["geo"],"standard","rover","Has never met a rock it could not move.",500,3),sprout:j("Sprout",["bio"],"standard","android","Talks to the greenhouse plants. They grow faster.",550,4),sparky:j("Sparky",["volt"],"standard","drone","A hyperactive power drone. Do not let it near the coffee.",600,4),bolt:j("Bolt",["alloy"],"standard","mech","Lifts girders, opens jars, never complains.",700,5),zephyr:j("Zephyr",["aero"],"standard","drone","Rides the ventilation currents for fun.",800,5),lumen:j("Lumen",["photon"],"standard","drone","A flying floodlight that loves an audience.",900,6),brawler:j("Brawler",["kinetic"],"standard","mech","Built for demolition, adores being useful.",1e3,6),anchor:j("Anchor",["gravity"],"standard","walker","Heavier than it looks, calmer than it sounds.",1200,7),umbra:j("Umbra",["void"],"standard","orb","Absorbs stray light. Prefers the night shift.",1400,7),tick:j("Tick",["chrono"],"standard","android","Always exactly on time, sometimes slightly early.",1600,8),cortex:j("Cortex",["neural"],"standard","orb","A small AI that asks a lot of questions.",1800,8),solarflare:j("Solarflare",["solar","plasma"],"advanced","drone","Catches sunlight, throws it back as fire.",2600,9),thunderhead:j("Thunderhead",["volt","hydro"],"advanced","orb","A storm in a sphere. Crackles when it is happy.",3200,10),magmaw:j("Magmaw",["geo","plasma"],"advanced","crawler","Eats rock, breathes lava, purrs.",3800,11),greenhouse:j("Greenhouse",["bio","solar"],"advanced","android","A walking garden that photosynthesises on the job.",4400,12),glacier:j("Glacier",["cryo","alloy"],"advanced","mech","Ice-armoured and unhurried. Nothing gets past.",5e3,13),floe:j("Floe",["hydro","cryo"],"advanced","crawler","Skates across frozen reservoirs, clearing them.",5600,14),quarry:j("Quarry",["geo","alloy"],"advanced","mech","Turns asteroids into neatly stacked bricks.",6200,15),mangrove:j("Mangrove",["bio","hydro"],"advanced","walker","Grows roots into the water pipes. On purpose.",6900,16),dynamo:j("Dynamo",["volt","alloy"],"advanced","rover","A rolling generator with a lot of torque.",7600,17),eclipse:j("Eclipse",["void","photon"],"advanced","orb","Half light, half dark, entirely mysterious.",8400,18),rampart:j("Rampart",["kinetic","alloy"],"advanced","mech","A wall that walks. Very reassuring.",9200,19),stormkite:j("Stormkite",["aero","volt"],"advanced","drone","Flies into lightning to recharge.",1e4,20),monolith:j("Monolith",["gravity","geo"],"advanced","walker","Stands perfectly still for days. Then dances.",11e3,21),paradox:j("Paradox",["chrono","neural"],"advanced","android","Remembers things that have not happened yet.",12e3,22),synapse:j("Synapse",["neural","volt"],"advanced","orb","Thinks in lightning. Talks in puns.",13e3,23),blizzard:j("Blizzard",["aero","cryo"],"advanced","drone","Brings its own weather everywhere it goes.",14e3,24),prism:j("Prism",["photon","solar"],"advanced","orb","Splits starlight into every colour it knows.",15e3,25),undertow:j("Undertow",["void","gravity"],"advanced","crawler","Pulls things in. Gently. Usually.",16e3,26),blastforge:j("Blastforge",["plasma","kinetic"],"advanced","mech","Forges hull plates with controlled explosions.",17500,27),rootbound:j("Rootbound",["bio","geo"],"advanced","walker","Plants a tree with every step.",19e3,28),rainmaker:j("Rainmaker",["hydro","aero"],"advanced","drone","Seeds clouds over the greenhouses.",20500,29),sundial:j("Sundial",["chrono","photon"],"advanced","android","Tells time by the shadows it casts.",22e3,30),mycelium:j("Mycelium",["neural","bio"],"advanced","crawler","A network of thinking fungus in a shell.",24e3,31),orbiter:j("Orbiter",["gravity","aero"],"advanced","orb","Has its own small moon. It is very attached.",26e3,32),permafrost:j("Permafrost",["cryo","void"],"advanced","walker","Cold enough to freeze light.",28e3,33),arcjet:j("Arcjet",["volt","plasma"],"advanced","rover","Rides a cushion of ionised air.",3e4,34),mirrorplate:j("Mirrorplate",["alloy","photon"],"advanced","mech","Polished so well it reflects your mood.",32e3,35),striker:j("Striker",["kinetic","aero"],"advanced","drone","Fast, precise, slightly showing off.",34e3,36),pendulum:j("Pendulum",["chrono","gravity"],"advanced","walker","Swings between moments.",36e3,37),oracle:j("Oracle",["neural","photon"],"advanced","orb","Answers questions before you ask them.",38e3,38),mudlark:j("Mudlark",["geo","hydro"],"advanced","rover","Happiest up to its axles in wet regolith.",4e4,39),sunvolt:j("Sunvolt",["solar","volt"],"advanced","rover","Charges in sunlight, discharges in enthusiasm.",42e3,40),phantom:j("Phantom",["void","neural"],"advanced","android","Appears on cameras that are switched off.",45e3,41),thermocline:j("Thermocline",["plasma","cryo"],"advanced","crawler","Hot on one side, frozen on the other.",48e3,42),corona:j("Corona",["solar","plasma","photon"],"elite","orb","A miniature star on a leash."),tsunami:j("Tsunami",["hydro","kinetic","aero"],"elite","crawler","Moves like a wave and hits like one too."),tectonic:j("Tectonic",["geo","gravity","kinetic"],"elite","mech","Rearranges continents for practice."),verdant:j("Verdant",["bio","solar","hydro"],"elite","android","Terraforms a garden wherever it stands."),tesla:j("Tesla",["volt","alloy","neural"],"elite","android","An inventor bot with a coil for a heart."),borealis:j("Borealis",["cryo","photon","aero"],"elite","drone","Paints the polar sky in green fire."),nightshade:j("Nightshade",["void","bio","neural"],"elite","crawler","Beautiful, clever, best kept at arm's length."),chronoforge:j("Chronoforge",["chrono","plasma","alloy"],"elite","mech","Forges parts it will need tomorrow."),gravwell:j("Gravwell",["gravity","void","hydro"],"elite","orb","A floating whirlpool that hums."),overclock:j("Overclock",["volt","chrono","kinetic"],"elite","rover","Runs every process twice as fast. Including naps."),dreadnought:j("Dreadnought",["alloy","kinetic","gravity"],"elite","mech","Armour plate all the way down."),lumina:j("Lumina",["photon","bio","neural"],"elite","android","A gardener that glows in the dark."),supernova:j("Supernova",["solar","plasma","gravity","photon"],"epic","orb","Contains a star's last breath, politely."),leviathan:j("Leviathan",["hydro","cryo","gravity","kinetic"],"epic","crawler","The deep-ocean bot of Europa legends."),titanforge:j("Titanforge",["alloy","geo","plasma","kinetic"],"epic","mech","Builds space stations single-handed. It has four hands."),gaia:j("Gaia",["bio","geo","hydro","solar"],"epic","android","Turns dead rock into living soil."),tempest:j("Tempest",["aero","volt","hydro","cryo"],"epic","drone","A hurricane that follows instructions."),eventide:j("Eventide",["void","chrono","photon"],"epic","orb","Lives in the moment between day and night."),hivemind:j("Hivemind",["neural","bio","alloy","volt"],"epic","crawler","A thousand tiny minds in one shell."),starweaver:j("Starweaver",["photon","gravity","aero"],"epic","drone","Spins light sails from starlight."),quasar:j("Quasar",["volt","void","photon","gravity"],"epic","orb","Brighter than a galaxy, smaller than a fridge."),juggernaut:j("Juggernaut",["kinetic","alloy","gravity","geo"],"epic","mech","Unstoppable. Literally: nobody has tried."),solaris:j("Solaris Prime",["solar","photon","plasma","neural"],"legendary","android","The first AI to dream of the Sun, and then build one."),abyssal:j("Abyssal",["void","hydro","gravity","cryo"],"legendary","crawler","From the dark oceans beneath Enceladus."),chronarch:j("Chronarch",["chrono","neural","photon","void"],"legendary","android","Keeper of every second the colony has lived."),colossus:j("Colossus",["alloy","kinetic","geo","gravity"],"legendary","mech","A walking fortress the size of a hab block."),seraph:j("Seraph",["aero","photon","bio","solar"],"legendary","drone","Six wings of light, one gentle voice."),voltaic:j("Voltaic Storm",["volt","aero","plasma","kinetic"],"legendary","orb","Lightning that learned to fly."),omega:j("Omega Protocol",["neural","alloy","chrono","kinetic"],"prototype","mech","The last line of code anyone wrote by hand."),genesis:j("Genesis Engine",["bio","solar","hydro","geo"],"prototype","android","Makes worlds. Small ones, for now."),horizon:j("Event Horizon",["gravity","void","chrono","photon"],"prototype","orb","Nothing it looks at can look away."),architect:j("The Architect",["neural","chrono","gravity","photon"],"singularity","orb","It designed itself. Then it designed the rest."),primemover:j("Prime Mover",["kinetic","plasma","solar","gravity"],"singularity","mech","The engine at the start of everything."),veyari:{...j("Veyari Gardener",["bio","photon","void"],"legendary","android","A crystalline gardener from Proxima b, a gift from the Veyari to seal first contact."),alien:"contact"},synod:{...j("Synod Envoy",["alloy","neural","chrono"],"legendary","mech","A delegate of the machine Synod of Barnard's Star. It votes on everything."),alien:"contact"},mycelar:{...j("Mycelar Sporeling",["bio","neural","hydro"],"epic","crawler","A fragment of Tau Ceti's singing fungal mind, curious about everything."),alien:"contact"},oshoru:{...j("Oshoru Swimmer",["hydro","aero","kinetic"],"epic","orb","A young Oshoru from TRAPPIST-1e, sent to see the stars."),alien:"contact"},lumenchoir:{...j("Lumen Choir",["photon","solar","neural"],"prototype","orb","A being of pure light from Epsilon Eridani. It hums in harmonies."),alien:"contact"},krdrone:{...j("Kr'thul Drone",["void","kinetic"],"advanced","crawler","A Swarm drone, captured and reprogrammed. Still a little bitey."),alien:"swarm"},krwarrior:{...j("Kr'thul Warrior",["void","kinetic","plasma"],"elite","crawler","A Swarm warrior that now fights for the colony."),alien:"swarm"},solstice:{...j("Solstice Seraph",["solar","photon","aero"],"legendary","drone","Born in the light of the Solar Solstice. It never casts a shadow."),alien:"event"},champion:{...j("Arena Champion",["kinetic","alloy","photon"],"legendary","mech","Forged for the Arena Cup. It bows before every fight."),alien:"event"},voyager:{...j("Deep Voyager",["gravity","void","aero"],"legendary","orb","A Deep Space Week veteran that has seen the edge of the Solar System."),alien:"event"},chimera:{...j("Chimera Core",["neural","bio","plasma","chrono"],"legendary","crawler","A happy accident of the Fusion Frenzy. Nobody is quite sure what it is."),alien:"event"},blossom:{...j("Blossom Sentinel",["bio","hydro","photon"],"legendary","android","Guardian of the Garden Gala. Flowers open as it passes."),alien:"event"},anvil:{...j("Anvil Titan",["alloy","plasma","geo"],"legendary","mech","Built during Forge Fest by every builder drone at once."),alien:"event"},aurorawisp:{...j("Aurora Wisp",["aurora","relic","bio"],"epic","orb","A Precursor intelligence of Aurora, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},aurorawarden:{...j("Aurora Warden",["aurora","relic","photon"],"legendary","android","A Precursor intelligence of Aurora, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},auroraprime:{...j("Aurora Prime",["aurora","relic","solar"],"prototype","drone","A Precursor intelligence of Aurora, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},arcanaglyph:{...j("Arcana Glyph",["arcana","relic","neural"],"epic","orb","A Precursor intelligence of Arcana, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},arcanamagus:{...j("Arcana Magus",["arcana","relic","chrono"],"legendary","android","A Precursor intelligence of Arcana, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},arcanaprime:{...j("Arcana Prime",["arcana","relic","void"],"prototype","orb","A Precursor intelligence of Arcana, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},entropyspark:{...j("Entropy Spark",["entropy","relic","plasma"],"epic","crawler","A Precursor intelligence of Entropy, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},entropyreaver:{...j("Entropy Reaver",["entropy","relic","kinetic"],"legendary","mech","A Precursor intelligence of Entropy, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},entropyprime:{...j("Entropy Prime",["entropy","relic","gravity"],"prototype","orb","A Precursor intelligence of Entropy, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},joysprite:{...j("Joy Sprite",["joy","relic","aero"],"epic","drone","A Precursor intelligence of Joy, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},joyjester:{...j("Joy Jester",["joy","relic","volt"],"legendary","android","A Precursor intelligence of Joy, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},joyprime:{...j("Joy Prime",["joy","relic","photon"],"prototype","orb","A Precursor intelligence of Joy, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},reveriedrifter:{...j("Reverie Drifter",["reverie","relic","cryo"],"epic","orb","A Precursor intelligence of Reverie, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},reverieoracle:{...j("Reverie Oracle",["reverie","relic","neural"],"legendary","android","A Precursor intelligence of Reverie, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},reverieprime:{...j("Reverie Prime",["reverie","relic","hydro"],"prototype","drone","A Precursor intelligence of Reverie, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},soulember:{...j("Soul Ember",["soul","relic","solar"],"epic","orb","A Precursor intelligence of Soul, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},soulkeeper:{...j("Soul Keeper",["soul","relic","geo"],"legendary","mech","A Precursor intelligence of Soul, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},soulprime:{...j("Soul Prime",["soul","relic","chrono"],"prototype","android","A Precursor intelligence of Soul, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},krbrood:{...j("Kr'thul Brood",["void","bio","gravity","kinetic"],"epic","crawler","A living Swarm carrier. It keeps trying to adopt the other bots."),alien:"swarm"}},Qn=Object.keys(tt),qt={standard:{name:"Standard",color:"#b9c3cf",earn:10,power:1,fuseChance:1,assembly:30},advanced:{name:"Advanced",color:"#5fdc7a",earn:15,power:1.2,fuseChance:.6,assembly:600},elite:{name:"Elite",color:"#4aa8ff",earn:22,power:1.45,fuseChance:.35,assembly:3600},epic:{name:"Epic",color:"#b06dff",earn:34,power:1.75,fuseChance:.18,assembly:4*3600},legendary:{name:"Legendary",color:"#ffa53a",earn:52,power:2.1,fuseChance:.08,assembly:12*3600},prototype:{name:"Prototype",color:"#ff4f6a",earn:80,power:2.6,fuseChance:.035,assembly:24*3600},singularity:{name:"Singularity",color:"#7af7ff",earn:125,power:3.2,fuseChance:.015,assembly:48*3600}},We=Object.keys(qt),di=i=>We.indexOf(tt[i].rarity),wu=[2,4,8,15,30,60,120];function Hc(i,t,e=Date.now()){if(i.dex[t])return!1;i.dex[t]=e;const n=wu[di(t)];return i.res.dm+=n,on.push({kind:"discover",sp:t,dm:n}),!0}const Gc=i=>Object.keys(i.dex).filter(t=>tt[t]).length;function ea(i){const t=tt[i.sp],e=qt[t.rarity].power,n=1+.1*(t.el.length-1);return{hp:Math.round((120+32*(i.lvl-1))*e*n),atk:Math.round((20+5.5*(i.lvl-1))*e*n)}}const qi=4;function Eu(i,t){const e=tt[i.sp],n=tt[t.sp],s=new Set([...e.el,...n.el]),a=di(i.sp),r=di(t.sp),o=Math.min(a,r),l=Math.max(a,r),c=[];for(const h of Qn){const u=tt[h],f=We.indexOf(u.rarity),g=h===i.sp||h===t.sp;u.alien&&!g||!g&&(!u.el.every(x=>s.has(x))||!u.el.some(x=>e.el.includes(x))||!u.el.some(x=>n.el.includes(x))||u.el.length<2||f<(o>=2?o:o-1)||f===3&&l<1||f===4&&o<2||f===5&&o<3||f===6&&o<4||f>l+2)||c.push({sp:h,w:qt[u.rarity].fuseChance*(g?1.3:1)})}const d=c.reduce((h,u)=>h+u.w,0);return c.map(h=>({sp:h.sp,p:h.w/d})).sort((h,u)=>di(u.sp)-di(h.sp)||u.p-h.p)}const Hl=(i,t)=>{const e=di(i.sp),n=di(t.sp);return Math.round(120*(1+e)*(1+n)*Math.pow(1.7,Math.max(e,n)))};function Za(i,t){const e=Si[t.t]||[];let n=0;for(const s of i.bots){if(s.post!==t.id)continue;const a=tt[s.sp],r=(.04+.006*s.lvl)*Math.sqrt(qt[a.rarity].power)*(a.el.some(o=>e.includes(o))?1.5:1);n+=r}return Math.min(.6,n)}const Gl=(i,t,e)=>Math.round(qt[tt[e].rarity].assembly*(1-.05*(t.lvl-1))*(1-Za(i,t)));function Au(i,t,e,n){if(t.lvl<1||Ee(i,t.id,"build"))return{ok:!1,why:"The Fusion Lab is under construction"};if(Ee(i,t.id,"fuse"))return{ok:!1,why:"Already fusing"};const s=i.bots.find(o=>o.id===e),a=i.bots.find(o=>o.id===n);if(!s||!a)return{ok:!1,why:"Pick two bots"};if(s===a)return{ok:!1,why:"Pick two different bots"};if(s.lvl<qi||a.lvl<qi)return{ok:!1,why:`Both bots need level ${qi}`};if(Ba(i,s)||Ba(i,a))return{ok:!1,why:"A parent is away on an expedition"};if(tt[s.sp].alien==="relic"||tt[a.sp].alien==="relic")return{ok:!1,why:"Relic AIs cannot be fused"};const r=Hl(s,a);return i.res.credits<r?{ok:!1,why:"Not enough credits",cost:r}:{ok:!0,cost:r}}function Up(i,t,e,n,s=Date.now(),a=Math.random){const r=Au(i,t,e,n);if(!r.ok)return r;const o=i.bots.find(f=>f.id===e),l=i.bots.find(f=>f.id===n);i.res.credits-=r.cost||0;const c=Eu(o,l);let d=a(),h=c[0].sp;for(const f of c){if(d<f.p){h=f.sp;break}d-=f.p}const u=Gl(i,t,h);return i.jobs.push({id:Ye("j"),kind:"fuse",item:t.id,start:s,end:s+u*1e3,sp:h,parents:[e,n]}),i.stats.fusions=(i.stats.fusions||0)+1,ce(i,15+10*di(h)),{...r,time:u,sp:h}}const Fp=(i,t,e)=>Math.round(qt[tt[e].rarity].assembly*.5*(1-.05*(t.lvl-1))*(1-Za(i,t)));function Eo(i,t,e,n=Date.now()){const s={id:Ye("c"),sp:t,from:e,state:"waiting",at:n};return i.cores.push(s),Vl(i,n),on.push({kind:"core",core:s.id,sp:t}),s}function Vl(i,t=Date.now()){const e=zt(i,"assembly")[0];if(!e||e.lvl<1||Ee(i,e.id,"build"))return;let n=i.jobs.filter(s=>s.kind==="boot").length;for(const s of i.cores){if(n>=Fa(e.lvl))break;s.state==="waiting"&&(s.state="booting",i.jobs.push({id:Ye("j"),kind:"boot",item:e.id,start:t,end:t+Fp(i,e,s.sp)*1e3,core:s.id}),n++)}}function Op(i,t,e=Date.now()){const n=i.cores.find(r=>r.id===t);if(!n||n.state!=="ready")return{ok:!1,why:"Still booting"};const s=bs(i,n.sp),a={id:Ye("b"),sp:n.sp,lvl:1,fed:0,bay:s?s.id:null,born:e,...s?{}:{stored:!0}};return i.bots.push(a),i.cores=i.cores.filter(r=>r!==n),Hc(i,n.sp,e),i.stats.boots=(i.stats.boots||0)+1,ce(i,10+12*di(n.sp)),on.push({kind:"newBot",bot:a.id}),{ok:!0,bot:a}}function bs(i,t,e){const n=tt[t].el;return zt(i,"bay").filter(s=>s.lvl>0&&s.el&&n.includes(s.el)&&s.id!==e&&Rn(i,s.id).length<Jn(s.lvl)).sort((s,a)=>Rn(i,s.id).length-Rn(i,a.id).length)[0]}const to=(i,t)=>i.bots.filter(e=>e.post===t);function Tu(i,t,e){return Si[e.t]?e.lvl<1?{ok:!1,why:"Under construction"}:tt[t.sp].alien==="relic"?{ok:!1,why:"Relic AIs stay in their Sanctum"}:t.stored?{ok:!1,why:"Activate it from storage first"}:Ba(i,t)?{ok:!1,why:"Away on an expedition"}:t.post===e.id?{ok:!1,why:"Already helping here"}:to(i,e.id).length>=Qs(e.lvl)?{ok:!1,why:`All ${Qs(e.lvl)} helper slots are taken`}:{ok:!0}:{ok:!1,why:"Bots cannot help here"}}function Bp(i,t,e){const n=Tu(i,t,e);return n.ok&&(t.post=e.id,i.stats.posts=(i.stats.posts||0)+1),n}function kp(i){delete i.post}function zp(i,t){t.bay=null,t.stored=!0,delete t.post}function $p(i,t){const e=bs(i,t.sp);return e?(t.bay=e.id,delete t.stored,{ok:!0}):{ok:!1,why:`No room: build or upgrade a ${tt[t.sp].el.map(n=>n[0].toUpperCase()+n.slice(1)).join("/")} Bay`}}const Ru=i=>Math.round((tt[i.sp].price||2e3*Math.pow(3,di(i.sp)))*.25*(1+.1*(i.lvl-1)));function Hp(i,t){if(i.bots.length<=1)return{ok:!1,why:"You need at least one bot"};i.bots=i.bots.filter(n=>n!==t);const e=Ru(t);return i.res.credits+=e,{ok:!0,cost:e}}const Gp=(i,t)=>i.cores.find(e=>e.id===t),Sn={home:{name:"Home orbit",theme:"haven",world:"earth",blurb:"Your first island, in low Earth orbit."},moon:{name:"Tranquility Base",theme:"moon",world:"moon",needs:"moon",level:14,cost:6e4,perk:"Low gravity: bays here hold 50% more credits",blurb:"An island of grey regolith floating above the Moon, with Earth hanging in the black sky."},vault:{name:"The Precursor Vault",theme:"vault",world:"vault",needs:"epseri",level:27,cost:15e5,perk:"Relic crystals, the Forge and Relic AIs that earn Iridium",blurb:"A shard of the Precursors' world, found beyond Epsilon Eridani: violet ground veined with light."},mars:{name:"Bradbury Landing",theme:"mars",world:"mars",needs:"mars",level:22,cost:4e5,perk:"Rich regolith: Fabricators here print 30% more cells",blurb:"Rust-red ground above the plains of Mars, with Phobos racing overhead."}},Vp=["home","moon","mars","vault"],Ve={aurora:{name:"Aurora",color:"#6fffc8"},arcana:{name:"Arcana",color:"#8a5cff"},entropy:{name:"Entropy",color:"#ff3d6e"},joy:{name:"Joy",color:"#ffd24a"},reverie:{name:"Reverie",color:"#7aa8ff"},soul:{name:"Soul",color:"#f2f2ff"}},Pa=Object.keys(Ve),el=["Shard","Crystal","Gem","Prism"],Ao=[{name:"Surface dig",sec:600,shards:4,cost:4e3},{name:"Deep dig",sec:2*3600,shards:18,cost:15e3},{name:"Core dig",sec:8*3600,shards:60,cost:42e3}],Cu=(i,t)=>Math.round(i*(1+.15*(t-1))),eo=4,Pu=i=>[30,120,400][i]||0,Vc=[[0,30],[2,8],[3,6]],Wc=[[1,10],[1,25],[2,12],[3,8]],Wl=(i,t)=>[0,0,0,2.5,4,7,10][i]*(1+.6*(t-1)),Wp=i=>Math.round(300*Math.pow(1.7,i-1));function qe(i){const t=i;return t.vault||(t.vault={crystals:Object.fromEntries(Pa.map(e=>[e,[0,0,0,0]])),ready:{}}),t.vault}const To=i=>tt[i].alien==="relic",Ti=i=>tt[i].el[0],Xl=i=>We.indexOf(tt[i].rarity)-3;function Xp(i,t,e,n){const s=Ao[e];return!s||!Pa.includes(n)?{ok:!1}:t.lvl<1||Ee(i,t.id,"build")?{ok:!1,why:"Under construction"}:Ee(i,t.id,"dig")?{ok:!1,why:"Already digging"}:qe(i).ready[t.id]?{ok:!1,why:"Collect the crystals first"}:i.res.credits<s.cost?{ok:!1,why:"Not enough credits",cost:s.cost}:{ok:!0,cost:s.cost,time:s.sec}}function qp(i,t,e,n,s=Date.now()){const a=Xp(i,t,e,n);return a.ok&&(i.res.credits-=a.cost||0,i.jobs.push({id:Ye("j"),kind:"dig",item:t.id,start:s,end:s+Ao[e].sec*1e3,recipe:e,sp:n}),i.stats.digs=(i.stats.digs||0)+1),a}function Yp(i,t,e,n){qe(i).ready[t.id]={color:n,n:Cu(Ao[e].shards,Math.max(1,t.lvl))},on.push({kind:"dug",item:t.id})}function Lu(i,t){const e=qe(i).ready[t.id];return e?(delete qe(i).ready[t.id],qe(i).crystals[e.color][0]+=e.n,ce(i,5+Math.round(e.n/4)),e):null}function Du(i,t,e){const n=qe(i);if(!zt(i,"forge").some(a=>a.lvl>0))return{ok:!1,why:"Build the Relic Forge"};if(e>=3)return{ok:!1,why:"Prisms are the highest tier"};if(n.crystals[t][e]<eo)return{ok:!1,why:`Needs ${eo}`};const s=Pu(e);return(i.res.iridium||0)<s?{ok:!1,why:"Not enough Iridium",cost:s}:{ok:!0,cost:s}}function Kp(i,t,e){const n=Du(i,t,e);if(!n.ok)return n;const s=qe(i);return s.crystals[t][e]-=eo,s.crystals[t][e+1]++,i.res.iridium=(i.res.iridium||0)-(n.cost||0),ce(i,10*(e+1)),i.stats.forged=(i.stats.forged||0)+1,n}const Iu=(i,t)=>zt(i,"relicbay").filter(e=>e.lvl>0&&e.el===Ti(t)&&Rn(i,e.id).length<Jn(e.lvl))[0];function Nu(i,t){if(!To(t))return{ok:!1};const[e,n]=Vc[Xl(t)],s=qe(i).crystals[Ti(t)][e];return Iu(i,t)?s<n?{ok:!1,why:`Needs ${n} ${Ti(t)} ${["shards","crystals","gems","prisms"][e]}`}:{ok:!0}:{ok:!1,why:`Needs a ${Ti(t)[0].toUpperCase()+Ti(t).slice(1)} Relic Sanctum with room`}}function Zp(i,t,e=Date.now()){const n=Nu(i,t);if(!n.ok)return n;const[s,a]=Vc[Xl(t)];qe(i).crystals[Ti(t)][s]-=a;const r={id:Ye("b"),sp:t,lvl:1,fed:0,bay:Iu(i,t).id,born:e};return i.bots.push(r),i.dex[t]||(i.dex[t]=e,i.res.dm+=40,on.push({kind:"discover",sp:t,dm:40})),ce(i,80+Xl(t)*60),on.push({kind:"newBot",bot:r.id}),{...n,bot:r}}function Uu(i,t){if(!To(t.sp))return{ok:!1};if(t.lvl>=5)return{ok:!1,why:"Five stars: fully evolved"};const[e,n]=Wc[t.lvl-1];return qe(i).crystals[Ti(t.sp)][e]<n?{ok:!1,why:`Needs ${n} ${Ti(t.sp)} ${["shards","crystals","gems","prisms"][e]}`}:{ok:!0}}function Jp(i,t){const e=Uu(i,t);if(!e.ok)return e;const[n,s]=Wc[t.lvl-1];return qe(i).crystals[Ti(t.sp)][n]-=s,t.lvl++,ce(i,60*t.lvl),on.push({kind:"evolved",bot:t.id,stars:t.lvl}),e}const Fu=(i,t)=>Rn(i,t).reduce((e,n)=>e+Wl(We.indexOf(tt[n.sp].rarity),n.lvl),0)/60,Oa=i=>Wp(Math.max(1,i.lvl)),on=[],Ri=i=>{on.push(i)},jp=(i,t)=>Object.entries(t).every(([e,n])=>i.res[e]>=(n||0)),Qp=(i,t)=>{for(const[e,n]of Object.entries(t))i.res[e]-=n||0},Cn=(i,t)=>{for(const[e,n]of Object.entries(t))e in i.res&&(i.res[e]+=n)},On=(i,t,e=1)=>{i.stats[t]=(i.stats[t]||0)+e};function ce(i,t){if(!(t<=0))for(i.xp+=t;i.lvl<Pp&&i.xp>=kl(i.lvl);){i.xp-=kl(i.lvl),i.lvl++;const e=Lp(i.lvl);Cn(i,e),Ri({kind:"levelup",lvl:i.lvl,reward:e})}}const kn=i=>i.islands[i.at]||i.islands.home,Ro=i=>Object.values(i.islands).flatMap(t=>t.items),zt=(i,t)=>Ro(i).filter(e=>e.t===t),Xc=(i,t)=>kn(i).items.filter(e=>e.t===t),Re=(i,t)=>Ro(i).find(e=>e.id===t),Ji=(i,t)=>Object.keys(i.islands).find(e=>i.islands[e].items.some(n=>n.id===t))||"home",ji=i=>(zt(i,"command")[0]||{lvl:1}).lvl,Co=(i,t=i.at)=>{const e=i.islands[t],n=e&&e.items.find(s=>s.t==="command"||s.t==="hub");return n?Math.max(1,n.lvl):1},fn=i=>{const[t,e]=Qt[i.t].size;return i.r%2?[e,t]:[t,e]},Ou=(i,t)=>`${Math.floor(i/fe)},${Math.floor(t/fe)}`,Bu=(i,t,e)=>t>=0&&e>=0&&t<fe*$l&&e<fe*$l&&kn(i).plots.includes(Ou(t,e));function hs(i,t,e,n,s,a){for(let r=t;r<t+n;r++)for(let o=e;o<e+s;o++)if(!Bu(i,r,o))return!1;for(const r of kn(i).items){if(r.id===a)continue;const[o,l]=fn(r);if(t<r.x+o&&t+n>r.x&&e<r.z+l&&e+s>r.z)return!1}return!0}const Po=i=>i.jobs.filter(t=>t.kind==="build").length,Ee=(i,t,e)=>i.jobs.find(n=>n.item===t&&(!e||n.kind===e));function Zn(i,t,e){const n=Qt[t];if(!n)return{ok:!1,why:"Unknown"};if(n.exclusive){const c=i.stats["decor_"+t]||0;return zt(i,t).length<c?{ok:!0,cost:0,time:0}:{ok:!1,why:c?"All placed":"Earned from the login calendar",cost:0}}if(i.lvl<n.unlock)return{ok:!1,why:`Commander level ${n.unlock}`,cost:n.buildCost(zt(i,t).length)};if(n.vault&&i.at!=="vault")return{ok:!1,why:"Only in the Precursor Vault"};const s=n.unique?zt(i,t).length:Xc(i,t).length,a=Co(i);if(n.unique&&s)return{ok:!1,why:"Already built"};if(t==="hub")return{ok:!1,why:"Every new island comes with its Colony Hub"};const r=i.at==="home"?"Command Center":"Colony Hub";if(t==="bay"&&s>=Ca(a))return{ok:!1,why:`Bay limit here (${Ca(a)}): upgrade the ${r}`};if(t==="fab"&&s>=Ws(a))return{ok:!1,why:`Fabricator limit here (${Ws(a)}): upgrade the ${r}`};const o=t==="bay"&&e&&!zt(i,"bay").some(c=>c.el===e)?Math.round(n.buildCost(Math.max(0,s-1))*.7):n.buildCost(s),l=Math.round(n.time(1)*Gu(i));return l>0&&Po(i)>=i.builders?{ok:!1,why:"All builder drones are busy",cost:o,time:l}:i.res.credits<o?{ok:!1,why:"Not enough credits",cost:o,time:l}:{ok:!0,cost:o,time:l}}function ku(i,t,e,n,s,a,r=Date.now()){const o=Zn(i,t,a);if(!o.ok)return o;const l={id:Ye("i"),t,x:e,z:n,r:s,lvl:o.time?0:1,...a?{el:a}:{}},[c,d]=fn(l);return hs(i,e,n,c,d)?(i.res.credits-=o.cost||0,kn(i).items.push(l),On(i,"built"),o.time?i.jobs.push({id:Ye("j"),kind:"build",item:l.id,start:r,end:r+o.time*1e3,lvl:1}):(ce(i,Hu(o.cost||0)),Qt[t].cat==="decor"&&On(i,"decor")),t==="bay"&&(i.bay[l.id]=0),{...o,item:l}):{ok:!1,why:"Something is in the way"}}const zu=(i,t)=>t.t==="command"?Qt.command.max:t.t==="hub"?Math.min(Qt.hub.max,Math.max(1,ji(i)-2)):Math.min(Qt[t.t].max,Co(i,Ji(i,t.id)));function qc(i,t){const e=Qt[t.t];if(e.cat==="decor")return{ok:!1,why:"Decorations do not upgrade"};if(Ee(i,t.id,"build"))return{ok:!1,why:"Under construction"};if(t.lvl>=e.max)return{ok:!1,why:"Maximum level"};if(t.t==="hub"&&t.lvl>=ji(i)-2)return{ok:!1,why:`Colony Hubs stay two levels below the Command Center (level ${t.lvl+3} needed)`};if(t.t!=="command"&&t.t!=="hub"&&t.lvl>=Co(i,Ji(i,t.id)))return{ok:!1,why:`Upgrade the ${Ji(i,t.id)==="home"?"Command Center":"Colony Hub"} to level ${t.lvl+1} first`};if(t.t==="command"&&i.lvl<Xs[t.lvl+1])return{ok:!1,why:`Commander level ${Xs[t.lvl+1]} needed`};if(t.t==="fab"&&Ee(i,t.id,"craft"))return{ok:!1,why:"Finish or harvest the recipe first"};const n=e.upCost(t.lvl),s=Math.round(e.time(t.lvl+1)*(t.t==="command"?1:Gu(i)));return Po(i)>=i.builders?{ok:!1,why:"All builder drones are busy",cost:n,time:s}:i.res.credits<n?{ok:!1,why:"Not enough credits",cost:n,time:s}:{ok:!0,cost:n,time:s}}function $u(i,t,e=Date.now()){const n=qc(i,t);return n.ok&&(i.res.credits-=n.cost||0,On(i,"upgrades"),i.jobs.push({id:Ye("j"),kind:"build",item:t.id,start:e,end:e+(n.time||0)*1e3,lvl:t.lvl+1})),n}const Hu=i=>Math.max(5,Math.round(i/15)),Gu=i=>{const t=zt(i,"command")[0];return t?1-Za(i,t):1};function Vu(i,t,e,n,s){const[a,r]=fn({t:t.t,r:s});return hs(i,e,n,a,r,t.id)?(t.x=e,t.z=n,t.r=s,!0):!1}function Wu(i,t){if(Qt[t.t].cat!=="decor"||Qt[t.t].exclusive)return!1;const e=i.islands[Ji(i,t.id)];return e.items=e.items.filter(n=>n!==t),i.res.credits+=Math.floor(Qt[t.t].buildCost(0)*.5),!0}const ui=i=>i<=60?0:Math.ceil(1.1*Math.pow(i/60,.7));function Xu(i,t,e=Date.now()){const n=ui((t.end-e)/1e3);return i.res.dm<n?!1:(i.res.dm-=n,t.end=e,La(i,e),!0)}const wi=i=>{const t=tt[i.sp];return qt[t.rarity].earn*(1+.15*(t.el.length-1))*(1+.35*(i.lvl-1))},Lo=40,Do=i=>Math.round(4*Math.pow(1.33,i-1)),Rn=(i,t)=>i.bots.filter(e=>e.bay===t),qu=(i,t)=>!!(i.space&&i.space.exps.some(e=>e.crew.includes(t.id))),tm=i=>{const t=i.space;if(!t)return 1;let e=0;for(const n of["proxima","barnard","tauceti","trappist","epseri"])t.visits[n]>0&&e++;return 1+.05*e},Io=(i,t)=>Rn(i,t).filter(e=>!e.post&&!qu(i,e)).reduce((e,n)=>e+wi(n),0)/60*tm(i),Ba=qu,Wi=(i,t)=>Mu(Math.max(1,i.lvl))*(t&&Ji(t,i.id)==="moon"?1.5:1);function Yc(i,t){if(To(t.sp))return{ok:!1,why:"Relic AIs evolve with crystals, not cells"};if(t.lvl>=Lo)return{ok:!1,why:"Maximum level"};const e=Do(t.lvl);if(i.res.cells<e)return{ok:!1,why:"Not enough Power Cells",cost:e};i.res.cells-=e,t.fed++,On(i,"feeds"),ce(i,1+Math.floor(t.lvl/4));let n=!1;return t.fed>=4&&(t.fed=0,t.lvl++,n=!0,Ri({kind:"botLevel",bot:t.id,lvl:t.lvl})),{ok:!0,cost:e,lvlUp:n}}function Kc(i,t){const e=tt[t];if(!e||!e.price)return{ok:!1,why:"Not for sale"};const n=i.bots.filter(a=>a.sp===t).length,s=Math.round(e.price*(1+.5*n));if(i.lvl<(e.unlock||1))return{ok:!1,why:`Commander level ${e.unlock}`,cost:s};if(e.rarity!=="standard"){const a=zt(i,"assembly")[0];if(!a||a.lvl<1)return{ok:!1,why:"Build the Assembly Bay first: rarer bots boot there",cost:s}}else if(!bs(i,t)){const a=e.el.map(o=>o[0].toUpperCase()+o.slice(1));return{ok:!1,why:zt(i,"bay").some(o=>o.el&&e.el.includes(o.el))?`No room: upgrade or add a ${a.join("/")} Bay`:`Build a ${a.join(" or ")} Bay first`,cost:s}}return i.res.credits<s?{ok:!1,why:"Not enough credits",cost:s}:{ok:!0,cost:s}}function Yu(i,t,e=Date.now()){const n=Kc(i,t);if(!n.ok)return n;if(i.res.credits-=n.cost||0,On(i,"recruits"),ce(i,10+Math.round((n.cost||0)/50)),tt[t].rarity!=="standard"){const r=Eo(i,t,"shop",e);return{...n,core:r.id}}const s=bs(i,t),a={id:Ye("b"),sp:t,lvl:1,fed:0,bay:s.id,born:e};return i.bots.push(a),Hc(i,t,e),Ri({kind:"newBot",bot:a.id}),{...n,bot:a}}function Ku(i,t,e){const n=Re(i,e);return!n||!n.el||!tt[t.sp].el.includes(n.el)||t.bay===e||Rn(i,e).length>=Jn(n.lvl)?!1:(t.bay=e,delete t.stored,!0)}function Zc(i,t){const e=Math.floor(i.bay[t.id]||0);if(e<=0)return 0;if(i.bay[t.id]-=e,t.t==="relicbay")return i.res.iridium=(i.res.iridium||0)+e,On(i,"iridium",e),e;i.res.credits+=e,On(i,"collects"),On(i,"collected",e);const n=(i.stats.xpFrac||0)+e/50,s=Math.floor(n);return i.stats.xpFrac=n-s,ce(i,s),e}const Zu=i=>ta.map((t,e)=>({...t,i:e,open:Math.max(1,i.lvl)>=t.lvl,out:Su(t,Math.max(1,i.lvl))}));function Ju(i,t,e){const n=ta[e];return n?t.lvl<1||Ee(i,t.id,"build")?{ok:!1,why:"Under construction"}:Ee(i,t.id,"craft")?{ok:!1,why:"Already printing"}:i.ready[t.id]?{ok:!1,why:"Harvest first"}:t.lvl<n.lvl?{ok:!1,why:`Fabricator level ${n.lvl}`}:i.res.credits<n.cost?{ok:!1,why:"Not enough credits",cost:n.cost}:{ok:!0,cost:n.cost,time:n.sec}:{ok:!1}}function ju(i,t,e,n=Date.now()){const s=Ju(i,t,e);return s.ok&&(i.res.credits-=s.cost||0,On(i,"crafts"),i.jobs.push({id:Ye("j"),kind:"craft",item:t.id,start:n,end:n+ta[e].sec*1e3,recipe:e})),s}function Jc(i,t){const e=i.ready[t.id];return e?(delete i.ready[t.id],i.res.cells+=e.cells,ce(i,e.xp),On(i,"harvests"),e.cells):0}function No(i,t){const e=kn(i).plots;if(e.includes(t))return"open";const[n,s]=t.split(",").map(Number);return[[1,0],[-1,0],[0,1],[0,-1]].some(([a,r])=>e.includes(`${n+a},${s+r}`))?"buyable":"far"}const em={home:1,moon:4,mars:12},Uo=i=>Math.round(Ip(kn(i).bought)*(em[i.at]||1)),Fo=i=>Np(kn(i).bought)+(i.at==="moon"?10:i.at==="mars"?18:0);function jc(i,t){if(No(i,t)!=="buyable")return{ok:!1,why:"Expand next to your island"};const e=Uo(i),n=Fo(i);return i.lvl<n?{ok:!1,why:`Commander level ${n}`,cost:e}:i.res.credits<e?{ok:!1,why:"Not enough credits",cost:e}:{ok:!0,cost:e}}function Qu(i,t){const e=jc(i,t);return e.ok&&(i.res.credits-=e.cost||0,kn(i).plots.push(t),kn(i).bought++,i.landBought++,On(i,"land"),ce(i,25+i.landBought*10),Ri({kind:"land",key:t})),e}function nm(i,t){i.jobs=i.jobs.filter(n=>n!==t);const e=Re(i,t.item);if(e){if(t.kind==="build"){const n=e.lvl===0;e.lvl=t.lvl||e.lvl+1;const s=Qt[e.t];ce(i,Hu(n?s.buildCost(0):s.upCost(e.lvl-1))),Ri({kind:"built",item:e.id,lvl:e.lvl,first:n}),e.t==="assembly"&&Vl(i,t.end)}if(t.kind==="craft"){const n=ta[t.recipe||0];i.ready[e.id]={cells:Math.round(Su(n,Math.max(1,e.lvl))*(1+Za(i,e))*(Ji(i,e.id)==="mars"?1.3:1)),xp:n.xp},Ri({kind:"crafted",item:e.id})}if(t.kind==="fuse"&&t.sp){const n=Eo(i,t.sp,"fusion",t.end);Ri({kind:"fused",item:e.id,core:n.id,sp:t.sp})}if(t.kind==="dig"&&Yp(i,e,t.recipe||0,t.sp||"aurora"),t.kind==="boot"){const n=Gp(i,t.core);n&&(n.state="ready",Ri({kind:"booted",core:n.id,sp:n.sp})),Vl(i,t.end)}}}function La(i,t=Date.now()){let e=i.last||t;if(t<e){i.last=t;return}for(;;){const n=i.jobs.filter(a=>a.end<=t).sort((a,r)=>a.end-r.end)[0],s=n?Math.max(e,n.end):t;if(im(i,(s-e)/1e3),e=s,!n)break;nm(i,n)}i.last=t}function im(i,t){if(!(t<=0)){for(const e of zt(i,"relicbay")){if(e.lvl<1)continue;const n=Oa(e),s=i.bay[e.id]||0;s<n&&(i.bay[e.id]=Math.min(n,s+Fu(i,e.id)*t))}for(const e of zt(i,"bay")){if(e.lvl<1)continue;const n=Wi(e,i),s=i.bay[e.id]||0;s>=n||(i.bay[e.id]=Math.min(n,s+Io(i,e.id)*t))}}}function no(i,t){switch(t.kind){case"collect":return(i.stats.collects||0)>=(t.n||1);case"craft":return(i.stats.crafts||0)>=(t.n||1);case"harvest":return(i.stats.harvests||0)>=(t.n||1);case"botLevel":return i.bots.some(e=>e.lvl>=(t.n||1));case"ownSpecies":return i.bots.some(e=>e.sp===t.t);case"bayEl":return zt(i,"bay").some(e=>e.el===t.t&&e.lvl>0);case"cc":return ji(i)>=(t.n||1);case"decor":return(i.stats.decor||0)>=(t.n||1);case"bayLevel":return zt(i,"bay").some(e=>e.lvl>=(t.n||1));case"land":return i.landBought>=(t.n||1);case"bots":return i.bots.length>=(t.n||1);case"level":return i.lvl>=(t.n||1);case"rarity":return i.bots.some(e=>tt[e.sp].rarity===t.t);case"build":return zt(i,t.t||"").some(e=>e.lvl>0);case"fusions":return(i.stats.fusions||0)>=(t.n||1);case"boots":return(i.stats.boots||0)>=(t.n||1);case"helper":return i.bots.some(e=>!!e.post);case"dex":return Gc(i)>=(t.n||1);case"arenaWins":return(i.stats.arenaWins||0)>=(t.n||1);case"visit":return!!(i.space&&i.space.visits[t.t||""]>0);case"outposts":return(i.stats.outposts||0)>=(t.n||1);case"island":return!!i.islands[t.t||""];case"raids":return(i.stats.raidsWon||0)>=(t.n||1);case"relics":return i.bots.filter(e=>To(e.sp)).length>=(t.n||1);case"forged":return(i.stats.forged||0)>=(t.n||1);case"eventSteps":return(i.stats.eventSteps||0)>=(t.n||1);case"bayOn":return!!(i.islands[t.t||""]&&i.islands[t.t||""].items.some(e=>e.t==="bay"&&e.lvl>0));case"trophies":return(i.arena&&i.arena.best||0)>=(t.n||1)}return!1}const Da=i=>Qr[i.obj.i]||null;function tf(i){const t=Da(i);return!t||!no(i,t)?null:(Cn(i,t.reward),i.obj.claimed[t.id]=Date.now(),i.obj.i++,ce(i,10+i.obj.i*3),t)}const Sa=i=>kl(i.lvl);function Qc(i,t){const e=Sn[t];return!e||!e.cost?{ok:!1,why:"Unknown"}:i.islands[t]?{ok:!1,why:"Already founded"}:i.space&&i.space.visits[e.needs||""]>0?i.lvl<(e.level||1)?{ok:!1,why:`Commander level ${e.level}`,cost:e.cost}:i.res.credits<e.cost?{ok:!1,why:"Not enough credits",cost:e.cost}:{ok:!0,cost:e.cost}:{ok:!1,why:`Send an expedition to ${{moon:"the Moon",mars:"Mars",epseri:"Epsilon Eridani"}[e.needs||""]||e.needs} first`}}function ef(i,t){const e=Qc(i,t);if(!e.ok)return e;i.res.credits-=e.cost||0;const n=(s,a,r)=>({id:Ye("i"),t:s,x:a,z:r,r:0,lvl:1});return i.islands[t]={plots:["1,1","2,1","3,1","1,2","2,2","3,2","1,3","2,3","3,3"],bought:0,items:[n("hub",13,13),n("rock",9,9),n("rock",19,18),n("rock",8,17),n("crystal",18,9)]},i.at=t,On(i,"islands"),ce(i,150),Ri({kind:"founded",key:t}),e}function nf(i,t){return i.islands[t]?(i.at=t,!0):!1}const sf=i=>Mu(i),sm=Object.freeze(Object.defineProperty({__proto__:null,BOT_MAX:Lo,addXp:ce,advance:La,allItems:Ro,areaFree:hs,bayCap:Wi,bayCapAt:sf,bayRate:Io,botEarn:wi,botsIn:Rn,build:ku,buildersBusy:Po,buyPlot:Qu,canBuild:Zn,canBuyPlot:jc,canCraft:Ju,canFound:Qc,canPay:jp,canRecruit:Kc,canUpgrade:qc,ccLevel:ji,claimStep:tf,collectBay:Zc,craft:ju,currentStep:Da,dims:fn,dmCost:ui,events:on,feed:Yc,feedCost:Do,finishNow:Xu,found:ef,give:Cn,harvest:Jc,here:kn,homeFor:bs,hubLevel:Co,islandOf:Ji,item:Re,itemsHere:Xc,itemsOf:zt,jobOf:Ee,maxLevelOf:zu,moveBot:Ku,moveItem:Vu,onMission:Ba,pay:Qp,plotCost:Uo,plotLevel:Fo,plotOf:Ou,plotState:No,recipesFor:Zu,recruit:Yu,sellDecor:Wu,stepDone:no,tileOpen:Bu,travel:nf,upgrade:$u,xpNeedOf:Sa},Symbol.toStringTag,{value:"Module"}));const td="187",am=0,qd=1,rm=2,Wr=1,af=2,wa=3,ps=0,en=1,Un=2,qs=0,Ia=1,Zi=2,Yd=3,Kd=4,om=5,Vs=100,lm=101,cm=102,dm=103,hm=104,um=200,fm=201,pm=202,mm=203,rf=204,of=205,gm=206,vm=207,xm=208,ym=209,bm=210,_m=211,Mm=212,Sm=213,wm=214,ql=0,Yl=1,Kl=2,ka=3,Zl=4,Jl=5,jl=6,Ql=7,ed=0,Em=1,Am=2,Di=0,lf=1,cf=2,df=3,nd=4,hf=5,uf=6,ff=7,pf=300,na=301,za=302,nl=303,il=304,io=1e3,Ci=1001,tc=1002,Qe=1003,Tm=1004,er=1005,pn=1006,sl=1007,Pi=1008,xn=1009,mf=1010,gf=1011,$a=1012,id=1013,pi=1014,ti=1015,mi=1016,sd=1017,ad=1018,ia=1020,vf=35902,xf=35899,yf=1021,bf=1022,hi=1023,Qi=1026,Yi=1027,rd=1028,od=1029,ms=1030,ld=1031,cd=1033,Xr=33776,qr=33777,Yr=33778,Kr=33779,ec=35840,nc=35841,ic=35842,sc=35843,ac=36196,rc=37492,oc=37496,lc=37488,cc=37489,so=37490,dc=37491,hc=37808,uc=37809,fc=37810,pc=37811,mc=37812,gc=37813,vc=37814,xc=37815,yc=37816,bc=37817,_c=37818,Mc=37819,Sc=37820,wc=37821,Ec=36492,Ac=36494,Tc=36495,Rc=36283,Cc=36284,ao=36285,Pc=36286,Rm=3200,ro=0,Cm=1,Ai="",Je="srgb",oo="srgb-linear",lo="linear",le="srgb",al=7680,Pm=519,Lm=512,Dm=513,Im=514,_f=515,Nm=516,Um=517,Mf=518,Sf=519,wf=35044,Zd="300 es",ei=2e3,Ha=2001;function Fm(i){for(let t=i.length-1;t>=0;--t)if(i[t]>=65535)return!0;return!1}function co(i){return document.createElementNS("http://www.w3.org/1999/xhtml",i)}function Om(){const i=co("canvas");return i.style.display="block",i}const Jd={};function ho(...i){const t="THREE."+i.shift();console.log(t,...i)}function Ef(i){const t=i[0];if(typeof t=="string"&&t.startsWith("TSL:")){const e=i[1];e&&e.isStackTrace?i[0]+=" "+e.getLocation():i[1]='Stack trace not available. Enable "THREE.Node.captureStackTrace" to capture stack traces.'}return i}function Ut(...i){i=Ef(i);const t="THREE."+i.shift();{const e=i[0];e&&e.isStackTrace?console.warn(e.getError(t)):console.warn(t,...i)}}function ie(...i){i=Ef(i);const t="THREE."+i.shift();{const e=i[0];e&&e.isStackTrace?console.error(e.getError(t)):console.error(t,...i)}}function Zr(...i){const t=i.join(" ");t in Jd||(Jd[t]=!0,Ut(...i))}function Bm(i,t,e){return new Promise(function(n,s){function a(){switch(i.clientWaitSync(t,i.SYNC_FLUSH_COMMANDS_BIT,0)){case i.WAIT_FAILED:s();break;case i.TIMEOUT_EXPIRED:setTimeout(a,e);break;default:n()}}setTimeout(a,e)})}const km={[ql]:ql,[Kl]:jl,[Zl]:Zl,[ka]:Jl,[Yl]:Yl,[jl]:Kl,[Ql]:Ql,[Jl]:ka};class _s{addEventListener(t,e){this._listeners===void 0&&(this._listeners={});const n=this._listeners;n[t]===void 0&&(n[t]=[]),n[t].indexOf(e)===-1&&n[t].push(e)}hasEventListener(t,e){const n=this._listeners;return n===void 0?!1:n[t]!==void 0&&n[t].indexOf(e)!==-1}removeEventListener(t,e){const n=this._listeners;if(n===void 0)return;const s=n[t];if(s!==void 0){const a=s.indexOf(e);a!==-1&&s.splice(a,1)}}dispatchEvent(t){const e=this._listeners;if(e===void 0)return;const n=e[t.type];if(n!==void 0){t.target=this;const s=n.slice(0);for(let a=0,r=s.length;a<r;a++)s[a].call(this,t);t.target=null}}}const an=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"];let jd=1234567;const Ys=Math.PI/180,Ga=180/Math.PI;function es(){const i=Math.random()*4294967295|0,t=Math.random()*4294967295|0,e=Math.random()*4294967295|0,n=Math.random()*4294967295|0;return(an[i&255]+an[i>>8&255]+an[i>>16&255]+an[i>>24&255]+"-"+an[t&255]+an[t>>8&255]+"-"+an[t>>16&15|64]+an[t>>24&255]+"-"+an[e&63|128]+an[e>>8&255]+"-"+an[e>>16&255]+an[e>>24&255]+an[n&255]+an[n>>8&255]+an[n>>16&255]+an[n>>24&255]).toLowerCase()}function jt(i,t,e){return Math.max(t,Math.min(e,i))}function dd(i,t){return(i%t+t)%t}function zm(i,t,e,n,s){return n+(i-t)*(s-n)/(e-t)}function $m(i,t,e){return i!==t?(e-i)/(t-i):0}function Na(i,t,e){return(1-e)*i+e*t}function Hm(i,t,e,n){return Na(i,t,1-Math.exp(-e*n))}function Gm(i,t=1){return t-Math.abs(dd(i,t*2)-t)}function Vm(i,t,e){return i<=t?0:i>=e?1:(i=(i-t)/(e-t),i*i*(3-2*i))}function Wm(i,t,e){return i<=t?0:i>=e?1:(i=(i-t)/(e-t),i*i*i*(i*(i*6-15)+10))}function Xm(i,t){return i+Math.floor(Math.random()*(t-i+1))}function qm(i,t){return i+Math.random()*(t-i)}function Ym(i){return i*(.5-Math.random())}function Km(i){i!==void 0&&(jd=i);let t=jd+=1831565813;return t=Math.imul(t^t>>>15,t|1),t^=t+Math.imul(t^t>>>7,t|61),((t^t>>>14)>>>0)/4294967296}function Zm(i){return i*Ys}function Jm(i){return i*Ga}function jm(i){return i>0&&Number.isInteger(i)&&2**Math.round(Math.log2(i))===i}function Qm(i){return Math.pow(2,Math.ceil(Math.log(i)/Math.LN2))}function Af(i){return Math.pow(2,Math.floor(Math.log(i)/Math.LN2))}function t0(i,t,e,n,s){const a=Math.cos,r=Math.sin,o=a(e/2),l=r(e/2),c=a((t+n)/2),d=r((t+n)/2),h=a((t-n)/2),u=r((t-n)/2),f=a((n-t)/2),g=r((n-t)/2);switch(s){case"XYX":i.set(o*d,l*h,l*u,o*c);break;case"YZY":i.set(l*u,o*d,l*h,o*c);break;case"ZXZ":i.set(l*h,l*u,o*d,o*c);break;case"XZX":i.set(o*d,l*g,l*f,o*c);break;case"YXY":i.set(l*f,o*d,l*g,o*c);break;case"ZYZ":i.set(l*g,l*f,o*d,o*c);break;default:Ut("MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+s)}}function Oo(i){switch(i.constructor){case Uint32Array:return 4294967295;case Uint16Array:return 65535;case Uint8Array:case Uint8ClampedArray:return 255;case Int32Array:return 2147483647;case Int16Array:return 32767;case Int8Array:return 127;default:return}}function hd(i,t){if(t.constructor===Float32Array)return i;const e=Oo(t);if(e===void 0)throw new Error("THREE.MathUtils: Invalid component type.");return Math.max(i/e,-1)}function ud(i,t){if(t.constructor===Float32Array)return i;const e=Oo(t);if(e===void 0)throw new Error("THREE.MathUtils: Invalid component type.");return Math.round(i*e)}const uo={DEG2RAD:Ys,RAD2DEG:Ga,generateUUID:es,clamp:jt,euclideanModulo:dd,mapLinear:zm,inverseLerp:$m,lerp:Na,damp:Hm,pingpong:Gm,smoothstep:Vm,smootherstep:Wm,randInt:Xm,randFloat:qm,randFloatSpread:Ym,seededRandom:Km,degToRad:Zm,radToDeg:Jm,isPowerOfTwo:jm,ceilPowerOfTwo:Qm,floorPowerOfTwo:Af,setQuaternionFromProperEuler:t0,normalize:ud,denormalize:hd},Rd=class Rd{constructor(t=0,e=0){this.x=t,this.y=e}get width(){return this.x}set width(t){this.x=t}get height(){return this.y}set height(t){this.y=t}set(t,e){return this.x=t,this.y=e,this}setScalar(t){return this.x=t,this.y=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;default:throw new Error("THREE.Vector2: index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;default:throw new Error("THREE.Vector2: index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y)}copy(t){return this.x=t.x,this.y=t.y,this}add(t){return this.x+=t.x,this.y+=t.y,this}addScalar(t){return this.x+=t,this.y+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this}subScalar(t){return this.x-=t,this.y-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this}multiply(t){return this.x*=t.x,this.y*=t.y,this}multiplyScalar(t){return this.x*=t,this.y*=t,this}divide(t){return this.x/=t.x,this.y/=t.y,this}divideScalar(t){return this.multiplyScalar(1/t)}applyMatrix3(t){const e=this.x,n=this.y,s=t.elements;return this.x=s[0]*e+s[3]*n+s[6],this.y=s[1]*e+s[4]*n+s[7],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this}clamp(t,e){return this.x=jt(this.x,t.x,e.x),this.y=jt(this.y,t.y,e.y),this}clampScalar(t,e){return this.x=jt(this.x,t,e),this.y=jt(this.y,t,e),this}clampLength(t,e){const n=this.length();return this.divideScalar(n||1).multiplyScalar(jt(n,t,e))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(t){return this.x*t.x+this.y*t.y}cross(t){return this.x*t.y-this.y*t.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(t){const e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;const n=this.dot(t)/e;return Math.acos(jt(n,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){const e=this.x-t.x,n=this.y-t.y;return e*e+n*n}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this}equals(t){return t.x===this.x&&t.y===this.y}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this}rotateAround(t,e){const n=Math.cos(e),s=Math.sin(e),a=this.x-t.x,r=this.y-t.y;return this.x=a*n-r*s+t.x,this.y=a*s+r*n+t.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}};Rd.prototype.isVector2=!0;let It=Rd;class Ni{constructor(t=0,e=0,n=0,s=1){this.isQuaternion=!0,this._x=t,this._y=e,this._z=n,this._w=s}static slerpFlat(t,e,n,s,a,r,o){let l=n[s+0],c=n[s+1],d=n[s+2],h=n[s+3],u=a[r+0],f=a[r+1],g=a[r+2],x=a[r+3];if(h!==x||l!==u||c!==f||d!==g){let m=l*u+c*f+d*g+h*x;m<0&&(u=-u,f=-f,g=-g,x=-x,m=-m);let p=1-o;if(m<.9995){const y=Math.acos(m),A=Math.sin(y);p=Math.sin(p*y)/A,o=Math.sin(o*y)/A,l=l*p+u*o,c=c*p+f*o,d=d*p+g*o,h=h*p+x*o}else{l=l*p+u*o,c=c*p+f*o,d=d*p+g*o,h=h*p+x*o;const y=1/Math.sqrt(l*l+c*c+d*d+h*h);l*=y,c*=y,d*=y,h*=y}}t[e]=l,t[e+1]=c,t[e+2]=d,t[e+3]=h}static multiplyQuaternionsFlat(t,e,n,s,a,r){const o=n[s],l=n[s+1],c=n[s+2],d=n[s+3],h=a[r],u=a[r+1],f=a[r+2],g=a[r+3];return t[e]=o*g+d*h+l*f-c*u,t[e+1]=l*g+d*u+c*h-o*f,t[e+2]=c*g+d*f+o*u-l*h,t[e+3]=d*g-o*h-l*u-c*f,t}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get w(){return this._w}set w(t){this._w=t,this._onChangeCallback()}set(t,e,n,s){return this._x=t,this._y=e,this._z=n,this._w=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(t){return this._x=t.x,this._y=t.y,this._z=t.z,this._w=t.w,this._onChangeCallback(),this}setFromEuler(t,e=!0){const n=t._x,s=t._y,a=t._z,r=t._order,o=Math.cos,l=Math.sin,c=o(n/2),d=o(s/2),h=o(a/2),u=l(n/2),f=l(s/2),g=l(a/2);switch(r){case"XYZ":this._x=u*d*h+c*f*g,this._y=c*f*h-u*d*g,this._z=c*d*g+u*f*h,this._w=c*d*h-u*f*g;break;case"YXZ":this._x=u*d*h+c*f*g,this._y=c*f*h-u*d*g,this._z=c*d*g-u*f*h,this._w=c*d*h+u*f*g;break;case"ZXY":this._x=u*d*h-c*f*g,this._y=c*f*h+u*d*g,this._z=c*d*g+u*f*h,this._w=c*d*h-u*f*g;break;case"ZYX":this._x=u*d*h-c*f*g,this._y=c*f*h+u*d*g,this._z=c*d*g-u*f*h,this._w=c*d*h+u*f*g;break;case"YZX":this._x=u*d*h+c*f*g,this._y=c*f*h+u*d*g,this._z=c*d*g-u*f*h,this._w=c*d*h-u*f*g;break;case"XZY":this._x=u*d*h-c*f*g,this._y=c*f*h-u*d*g,this._z=c*d*g+u*f*h,this._w=c*d*h+u*f*g;break;default:Ut("Quaternion: .setFromEuler() encountered an unknown order: "+r)}return e===!0&&this._onChangeCallback(),this}setFromAxisAngle(t,e){const n=e/2,s=Math.sin(n);return this._x=t.x*s,this._y=t.y*s,this._z=t.z*s,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(t){const e=t.elements,n=e[0],s=e[4],a=e[8],r=e[1],o=e[5],l=e[9],c=e[2],d=e[6],h=e[10],u=n+o+h;if(u>0){const f=.5/Math.sqrt(u+1);this._w=.25/f,this._x=(d-l)*f,this._y=(a-c)*f,this._z=(r-s)*f}else if(n>o&&n>h){const f=2*Math.sqrt(1+n-o-h);this._w=(d-l)/f,this._x=.25*f,this._y=(s+r)/f,this._z=(a+c)/f}else if(o>h){const f=2*Math.sqrt(1+o-n-h);this._w=(a-c)/f,this._x=(s+r)/f,this._y=.25*f,this._z=(l+d)/f}else{const f=2*Math.sqrt(1+h-n-o);this._w=(r-s)/f,this._x=(a+c)/f,this._y=(l+d)/f,this._z=.25*f}return this._onChangeCallback(),this}setFromUnitVectors(t,e){let n=t.dot(e)+1;return n<1e-8?(n=0,Math.abs(t.x)>Math.abs(t.z)?(this._x=-t.y,this._y=t.x,this._z=0,this._w=n):(this._x=0,this._y=-t.z,this._z=t.y,this._w=n)):(this._x=t.y*e.z-t.z*e.y,this._y=t.z*e.x-t.x*e.z,this._z=t.x*e.y-t.y*e.x,this._w=n),this.normalize()}angleTo(t){return 2*Math.acos(Math.abs(jt(this.dot(t),-1,1)))}rotateTowards(t,e){const n=this.angleTo(t);if(n===0)return this;const s=Math.min(1,e/n);return this.slerp(t,s),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(t){return this._x*t._x+this._y*t._y+this._z*t._z+this._w*t._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let t=this.length();return t===0?(this._x=0,this._y=0,this._z=0,this._w=1):(t=1/t,this._x=this._x*t,this._y=this._y*t,this._z=this._z*t,this._w=this._w*t),this._onChangeCallback(),this}multiply(t){return this.multiplyQuaternions(this,t)}premultiply(t){return this.multiplyQuaternions(t,this)}multiplyQuaternions(t,e){const n=t._x,s=t._y,a=t._z,r=t._w,o=e._x,l=e._y,c=e._z,d=e._w;return this._x=n*d+r*o+s*c-a*l,this._y=s*d+r*l+a*o-n*c,this._z=a*d+r*c+n*l-s*o,this._w=r*d-n*o-s*l-a*c,this._onChangeCallback(),this}slerp(t,e){let n=t._x,s=t._y,a=t._z,r=t._w,o=this.dot(t);o<0&&(n=-n,s=-s,a=-a,r=-r,o=-o);let l=1-e;if(o<.9995){const c=Math.acos(o),d=Math.sin(c);l=Math.sin(l*c)/d,e=Math.sin(e*c)/d,this._x=this._x*l+n*e,this._y=this._y*l+s*e,this._z=this._z*l+a*e,this._w=this._w*l+r*e,this._onChangeCallback()}else this._x=this._x*l+n*e,this._y=this._y*l+s*e,this._z=this._z*l+a*e,this._w=this._w*l+r*e,this.normalize();return this}slerpQuaternions(t,e,n){return this.copy(t).slerp(e,n)}random(){const t=2*Math.PI*Math.random(),e=2*Math.PI*Math.random(),n=Math.random(),s=Math.sqrt(1-n),a=Math.sqrt(n);return this.set(s*Math.sin(t),s*Math.cos(t),a*Math.sin(e),a*Math.cos(e))}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._w===this._w}fromArray(t,e=0){return this._x=t[e],this._y=t[e+1],this._z=t[e+2],this._w=t[e+3],this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._w,t}fromBufferAttribute(t,e){return this._x=t.getX(e),this._y=t.getY(e),this._z=t.getZ(e),this._w=t.getW(e),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}const Cd=class Cd{constructor(t=0,e=0,n=0){this.x=t,this.y=e,this.z=n}set(t,e,n){return n===void 0&&(n=this.z),this.x=t,this.y=e,this.z=n,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;default:throw new Error("THREE.Vector3: index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("THREE.Vector3: index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this}multiplyVectors(t,e){return this.x=t.x*e.x,this.y=t.y*e.y,this.z=t.z*e.z,this}applyEuler(t){return this.applyQuaternion(Qd.setFromEuler(t))}applyAxisAngle(t,e){return this.applyQuaternion(Qd.setFromAxisAngle(t,e))}applyMatrix3(t){const e=this.x,n=this.y,s=this.z,a=t.elements;return this.x=a[0]*e+a[3]*n+a[6]*s,this.y=a[1]*e+a[4]*n+a[7]*s,this.z=a[2]*e+a[5]*n+a[8]*s,this}applyNormalMatrix(t){return this.applyMatrix3(t).normalize()}applyMatrix4(t){const e=this.x,n=this.y,s=this.z,a=t.elements,r=1/(a[3]*e+a[7]*n+a[11]*s+a[15]);return this.x=(a[0]*e+a[4]*n+a[8]*s+a[12])*r,this.y=(a[1]*e+a[5]*n+a[9]*s+a[13])*r,this.z=(a[2]*e+a[6]*n+a[10]*s+a[14])*r,this}applyQuaternion(t){const e=this.x,n=this.y,s=this.z,a=t.x,r=t.y,o=t.z,l=t.w,c=2*(r*s-o*n),d=2*(o*e-a*s),h=2*(a*n-r*e);return this.x=e+l*c+r*h-o*d,this.y=n+l*d+o*c-a*h,this.z=s+l*h+a*d-r*c,this}project(t){return this.applyMatrix4(t.matrixWorldInverse).applyMatrix4(t.projectionMatrix)}unproject(t){return this.applyMatrix4(t.projectionMatrixInverse).applyMatrix4(t.matrixWorld)}transformDirection(t){const e=this.x,n=this.y,s=this.z,a=t.elements;return this.x=a[0]*e+a[4]*n+a[8]*s,this.y=a[1]*e+a[5]*n+a[9]*s,this.z=a[2]*e+a[6]*n+a[10]*s,this.normalize()}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this}divideScalar(t){return this.multiplyScalar(1/t)}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this}clamp(t,e){return this.x=jt(this.x,t.x,e.x),this.y=jt(this.y,t.y,e.y),this.z=jt(this.z,t.z,e.z),this}clampScalar(t,e){return this.x=jt(this.x,t,e),this.y=jt(this.y,t,e),this.z=jt(this.z,t,e),this}clampLength(t,e){const n=this.length();return this.divideScalar(n||1).multiplyScalar(jt(n,t,e))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this.z=t.z+(e.z-t.z)*n,this}cross(t){return this.crossVectors(this,t)}crossVectors(t,e){const n=t.x,s=t.y,a=t.z,r=e.x,o=e.y,l=e.z;return this.x=s*l-a*o,this.y=a*r-n*l,this.z=n*o-s*r,this}projectOnVector(t){const e=t.lengthSq();if(e===0)return this.set(0,0,0);const n=t.dot(this)/e;return this.copy(t).multiplyScalar(n)}projectOnPlane(t){return rl.copy(this).projectOnVector(t),this.sub(rl)}reflect(t){return this.sub(rl.copy(t).multiplyScalar(2*this.dot(t)))}angleTo(t){const e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;const n=this.dot(t)/e;return Math.acos(jt(n,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){const e=this.x-t.x,n=this.y-t.y,s=this.z-t.z;return e*e+n*n+s*s}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)+Math.abs(this.z-t.z)}setFromSpherical(t){return this.setFromSphericalCoords(t.radius,t.phi,t.theta)}setFromSphericalCoords(t,e,n){const s=Math.sin(e)*t;return this.x=s*Math.sin(n),this.y=Math.cos(e)*t,this.z=s*Math.cos(n),this}setFromCylindrical(t){return this.setFromCylindricalCoords(t.radius,t.theta,t.y)}setFromCylindricalCoords(t,e,n){return this.x=t*Math.sin(e),this.y=n,this.z=t*Math.cos(e),this}setFromMatrixPosition(t){const e=t.elements;return this.x=e[12],this.y=e[13],this.z=e[14],this}setFromMatrixScale(t){const e=this.setFromMatrixColumn(t,0).length(),n=this.setFromMatrixColumn(t,1).length(),s=this.setFromMatrixColumn(t,2).length();return this.x=e,this.y=n,this.z=s,this}setFromMatrixColumn(t,e){return this.fromArray(t.elements,e*4)}setFromMatrix3Column(t,e){return this.fromArray(t.elements,e*3)}setFromEuler(t){return this.x=t._x,this.y=t._y,this.z=t._z,this}setFromColor(t){return this.x=t.r,this.y=t.g,this.z=t.b,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const t=Math.random()*Math.PI*2,e=Math.random()*2-1,n=Math.sqrt(1-e*e);return this.x=n*Math.cos(t),this.y=e,this.z=n*Math.sin(t),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}};Cd.prototype.isVector3=!0;let D=Cd;const rl=new D,Qd=new Ni,Pd=class Pd{constructor(t,e,n,s,a,r,o,l,c){this.elements=[1,0,0,0,1,0,0,0,1],t!==void 0&&this.set(t,e,n,s,a,r,o,l,c)}set(t,e,n,s,a,r,o,l,c){const d=this.elements;return d[0]=t,d[1]=s,d[2]=o,d[3]=e,d[4]=a,d[5]=l,d[6]=n,d[7]=r,d[8]=c,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(t){const e=this.elements,n=t.elements;return e[0]=n[0],e[1]=n[1],e[2]=n[2],e[3]=n[3],e[4]=n[4],e[5]=n[5],e[6]=n[6],e[7]=n[7],e[8]=n[8],this}extractBasis(t,e,n){return t.setFromMatrix3Column(this,0),e.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(t){const e=t.elements;return this.set(e[0],e[4],e[8],e[1],e[5],e[9],e[2],e[6],e[10]),this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){const n=t.elements,s=e.elements,a=this.elements,r=n[0],o=n[3],l=n[6],c=n[1],d=n[4],h=n[7],u=n[2],f=n[5],g=n[8],x=s[0],m=s[3],p=s[6],y=s[1],A=s[4],b=s[7],w=s[2],E=s[5],v=s[8];return a[0]=r*x+o*y+l*w,a[3]=r*m+o*A+l*E,a[6]=r*p+o*b+l*v,a[1]=c*x+d*y+h*w,a[4]=c*m+d*A+h*E,a[7]=c*p+d*b+h*v,a[2]=u*x+f*y+g*w,a[5]=u*m+f*A+g*E,a[8]=u*p+f*b+g*v,this}multiplyScalar(t){const e=this.elements;return e[0]*=t,e[3]*=t,e[6]*=t,e[1]*=t,e[4]*=t,e[7]*=t,e[2]*=t,e[5]*=t,e[8]*=t,this}determinant(){const t=this.elements,e=t[0],n=t[1],s=t[2],a=t[3],r=t[4],o=t[5],l=t[6],c=t[7],d=t[8];return e*r*d-e*o*c-n*a*d+n*o*l+s*a*c-s*r*l}invert(){const t=this.elements,e=t[0],n=t[1],s=t[2],a=t[3],r=t[4],o=t[5],l=t[6],c=t[7],d=t[8],h=d*r-o*c,u=o*l-d*a,f=c*a-r*l,g=e*h+n*u+s*f;if(g===0)return this.set(0,0,0,0,0,0,0,0,0);const x=1/g;return t[0]=h*x,t[1]=(s*c-d*n)*x,t[2]=(o*n-s*r)*x,t[3]=u*x,t[4]=(d*e-s*l)*x,t[5]=(s*a-o*e)*x,t[6]=f*x,t[7]=(n*l-c*e)*x,t[8]=(r*e-n*a)*x,this}transpose(){let t;const e=this.elements;return t=e[1],e[1]=e[3],e[3]=t,t=e[2],e[2]=e[6],e[6]=t,t=e[5],e[5]=e[7],e[7]=t,this}getNormalMatrix(t){return this.setFromMatrix4(t).invert().transpose()}transposeIntoArray(t){const e=this.elements;return t[0]=e[0],t[1]=e[3],t[2]=e[6],t[3]=e[1],t[4]=e[4],t[5]=e[7],t[6]=e[2],t[7]=e[5],t[8]=e[8],this}setUvTransform(t,e,n,s,a,r,o){const l=Math.cos(a),c=Math.sin(a);return this.set(n*l,n*c,-n*(l*r+c*o)+r+t,-s*c,s*l,-s*(-c*r+l*o)+o+e,0,0,1),this}scale(t,e){return Zr("Matrix3: .scale() is deprecated. Use .makeScale() instead."),this.premultiply(ol.makeScale(t,e)),this}rotate(t){return Zr("Matrix3: .rotate() is deprecated. Use .makeRotation() instead."),this.premultiply(ol.makeRotation(-t)),this}translate(t,e){return Zr("Matrix3: .translate() is deprecated. Use .makeTranslation() instead."),this.premultiply(ol.makeTranslation(t,e)),this}makeTranslation(t,e){return t.isVector2?this.set(1,0,t.x,0,1,t.y,0,0,1):this.set(1,0,t,0,1,e,0,0,1),this}makeRotation(t){const e=Math.cos(t),n=Math.sin(t);return this.set(e,-n,0,n,e,0,0,0,1),this}makeScale(t,e){return this.set(t,0,0,0,e,0,0,0,1),this}equals(t){const e=this.elements,n=t.elements;for(let s=0;s<9;s++)if(e[s]!==n[s])return!1;return!0}fromArray(t,e=0){for(let n=0;n<9;n++)this.elements[n]=t[n+e];return this}toArray(t=[],e=0){const n=this.elements;return t[e]=n[0],t[e+1]=n[1],t[e+2]=n[2],t[e+3]=n[3],t[e+4]=n[4],t[e+5]=n[5],t[e+6]=n[6],t[e+7]=n[7],t[e+8]=n[8],t}clone(){return new this.constructor().fromArray(this.elements)}};Pd.prototype.isMatrix3=!0;let Bt=Pd;const ol=new Bt,th=new Bt().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),eh=new Bt().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function e0(){const i={enabled:!0,workingColorSpace:oo,spaces:{},convert:function(s,a,r){return this.enabled===!1||a===r||!a||!r||(this.spaces[a].transfer===le&&(s.r=Ii(s.r),s.g=Ii(s.g),s.b=Ii(s.b)),this.spaces[a].primaries!==this.spaces[r].primaries&&(s.applyMatrix3(this.spaces[a].toXYZ),s.applyMatrix3(this.spaces[r].fromXYZ)),this.spaces[r].transfer===le&&(s.r=Ks(s.r),s.g=Ks(s.g),s.b=Ks(s.b))),s},workingToColorSpace:function(s,a){return this.convert(s,this.workingColorSpace,a)},colorSpaceToWorking:function(s,a){return this.convert(s,a,this.workingColorSpace)},getPrimaries:function(s){return this.spaces[s].primaries},getTransfer:function(s){return s===Ai?lo:this.spaces[s].transfer},getToneMappingMode:function(s){return this.spaces[s].outputColorSpaceConfig.toneMappingMode||"standard"},getLuminanceCoefficients:function(s,a=this.workingColorSpace){return s.fromArray(this.spaces[a].luminanceCoefficients)},define:function(s){Object.assign(this.spaces,s)},_getMatrix:function(s,a,r){return s.copy(this.spaces[r].fromXYZ).multiply(this.spaces[a].toXYZ)},_getDrawingBufferColorSpace:function(s){return this.spaces[s].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(s=this.workingColorSpace){return this.spaces[s].workingColorSpaceConfig.unpackColorSpace}},t=[.64,.33,.3,.6,.15,.06],e=[.2126,.7152,.0722],n=[.3127,.329];return i.define({[oo]:{primaries:t,whitePoint:n,transfer:lo,toXYZ:th,fromXYZ:eh,luminanceCoefficients:e,workingColorSpaceConfig:{unpackColorSpace:Je},outputColorSpaceConfig:{drawingBufferColorSpace:Je}},[Je]:{primaries:t,whitePoint:n,transfer:le,toXYZ:th,fromXYZ:eh,luminanceCoefficients:e,outputColorSpaceConfig:{drawingBufferColorSpace:Je}}}),i}const te=e0();function Ii(i){return i<.04045?i*.0773993808:Math.pow(i*.9478672986+.0521327014,2.4)}function Ks(i){return i<.0031308?i*12.92:1.055*Math.pow(i,.41666)-.055}let As;class n0{static getDataURL(t,e="image/png"){if(/^data:/i.test(t.src)||typeof HTMLCanvasElement>"u")return t.src;let n;if(t instanceof HTMLCanvasElement)n=t;else{As===void 0&&(As=co("canvas")),As.width=t.width,As.height=t.height;const s=As.getContext("2d");t instanceof ImageData?s.putImageData(t,0,0):s.drawImage(t,0,0,t.width,t.height),n=As}return n.toDataURL(e)}static sRGBToLinear(t){if(typeof HTMLImageElement<"u"&&t instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&t instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&t instanceof ImageBitmap){const e=co("canvas");e.width=t.width,e.height=t.height;const n=e.getContext("2d");n.drawImage(t,0,0,t.width,t.height);const s=n.getImageData(0,0,t.width,t.height),a=s.data;for(let r=0;r<a.length;r++)a[r]=Ii(a[r]/255)*255;return n.putImageData(s,0,0),e}else if(t.data){const e=t.data.slice(0);for(let n=0;n<e.length;n++)e instanceof Uint8Array||e instanceof Uint8ClampedArray?e[n]=Math.floor(Ii(e[n]/255)*255):e[n]=Ii(e[n]);return{data:e,width:t.width,height:t.height}}else return Ut("ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),t}}let i0=0;class fd{constructor(t=null){this.isTextureSource=!0,Object.defineProperty(this,"id",{value:i0++}),this.uuid=es(),this.data=t,this.dataReady=!0,this.version=0}getSize(t){const e=this.data;return typeof HTMLVideoElement<"u"&&e instanceof HTMLVideoElement?t.set(e.videoWidth,e.videoHeight,0):typeof VideoFrame<"u"&&e instanceof VideoFrame?t.set(e.displayWidth,e.displayHeight,0):e!==null?t.set(e.width||0,e.height||0,e.depth||0):t.set(0,0,0),t}set needsUpdate(t){t===!0&&this.version++}toJSON(t){const e=t===void 0||typeof t=="string";if(!e&&t.images[this.uuid]!==void 0)return t.images[this.uuid];const n={uuid:this.uuid,url:""},s=this.data;if(s!==null){let a;if(Array.isArray(s)){a=[];for(let r=0,o=s.length;r<o;r++)s[r].isDataTexture?a.push(ll(s[r].image)):a.push(ll(s[r]))}else a=ll(s);n.url=a}return e||(t.images[this.uuid]=n),n}}function ll(i){return typeof HTMLImageElement<"u"&&i instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&i instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&i instanceof ImageBitmap?n0.getDataURL(i):i.data?{data:Array.from(i.data),width:i.width,height:i.height,type:i.data.constructor.name}:(Ut("Texture: Unable to serialize Texture."),{})}let s0=0;const cl=new D;class cn extends _s{constructor(t=cn.DEFAULT_IMAGE,e=cn.DEFAULT_MAPPING,n=Ci,s=Ci,a=pn,r=Pi,o=hi,l=xn,c=cn.DEFAULT_ANISOTROPY,d=Ai){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:s0++}),this.uuid=es(),this.name="",this.source=new fd(t),this.mipmaps=[],this.mapping=e,this.channel=0,this.wrapS=n,this.wrapT=s,this.magFilter=a,this.minFilter=r,this.anisotropy=c,this.format=o,this.internalFormat=null,this.type=l,this.offset=new It(0,0),this.repeat=new It(1,1),this.center=new It(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new Bt,this.generateMipmaps=!0,this.mipmapsAutoUpdate=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=d,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(t&&t.depth&&t.depth>1),this.pmremVersion=0,this.isPMREMTexture=!1,this.normalized=!1}get width(){return this.source.getSize(cl).x}get height(){return this.source.getSize(cl).y}get depth(){return this.source.getSize(cl).z}get image(){return this.source.data}set image(t){this.source.data=t}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(t){return this.name=t.name,this.source=t.source,this.mipmaps=t.mipmaps.slice(0),this.mapping=t.mapping,this.channel=t.channel,this.wrapS=t.wrapS,this.wrapT=t.wrapT,this.magFilter=t.magFilter,this.minFilter=t.minFilter,this.anisotropy=t.anisotropy,this.format=t.format,this.internalFormat=t.internalFormat,this.type=t.type,this.normalized=t.normalized,this.offset.copy(t.offset),this.repeat.copy(t.repeat),this.center.copy(t.center),this.rotation=t.rotation,this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrix.copy(t.matrix),this.generateMipmaps=t.generateMipmaps,this.mipmapsAutoUpdate=t.mipmapsAutoUpdate,this.premultiplyAlpha=t.premultiplyAlpha,this.flipY=t.flipY,this.unpackAlignment=t.unpackAlignment,this.colorSpace=t.colorSpace,this.renderTarget=t.renderTarget,this.isRenderTargetTexture=t.isRenderTargetTexture,this.isPMREMTexture=t.isPMREMTexture,this.isArrayTexture=t.isArrayTexture,this.userData=JSON.parse(JSON.stringify(t.userData)),this.needsUpdate=!0,this}setValues(t){for(const e in t){const n=t[e];if(n===void 0){Ut(`Texture.setValues(): parameter '${e}' has value of undefined.`);continue}const s=this[e];if(s===void 0){Ut(`Texture.setValues(): property '${e}' does not exist.`);continue}s&&n&&s.isVector2&&n.isVector2||s&&n&&s.isVector3&&n.isVector3||s&&n&&s.isMatrix3&&n.isMatrix3?s.copy(n):this[e]=n}}toJSON(t){const e=t===void 0||typeof t=="string";if(!e&&t.textures[this.uuid]!==void 0)return t.textures[this.uuid];const n={metadata:{version:4.7,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(t).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,normalized:this.normalized,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,mipmapsAutoUpdate:this.mipmapsAutoUpdate,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),e||(t.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(t){if(this.mapping!==pf)return t;if(t.applyMatrix3(this.matrix),t.x<0||t.x>1)switch(this.wrapS){case io:t.x=t.x-Math.floor(t.x);break;case Ci:t.x=t.x<0?0:1;break;case tc:Math.abs(Math.floor(t.x)%2)===1?t.x=Math.ceil(t.x)-t.x:t.x=t.x-Math.floor(t.x);break}if(t.y<0||t.y>1)switch(this.wrapT){case io:t.y=t.y-Math.floor(t.y);break;case Ci:t.y=t.y<0?0:1;break;case tc:Math.abs(Math.floor(t.y)%2)===1?t.y=Math.ceil(t.y)-t.y:t.y=t.y-Math.floor(t.y);break}return this.flipY&&(t.y=1-t.y),t}set needsUpdate(t){t===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(t){t===!0&&this.pmremVersion++}}cn.DEFAULT_IMAGE=null;cn.DEFAULT_MAPPING=pf;cn.DEFAULT_ANISOTROPY=1;const Ld=class Ld{constructor(t=0,e=0,n=0,s=1){this.x=t,this.y=e,this.z=n,this.w=s}get width(){return this.z}set width(t){this.z=t}get height(){return this.w}set height(t){this.w=t}set(t,e,n,s){return this.x=t,this.y=e,this.z=n,this.w=s,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this.w=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setW(t){return this.w=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;case 3:this.w=e;break;default:throw new Error("THREE.Vector4: index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("THREE.Vector4: index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this.w=t.w!==void 0?t.w:1,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this.w+=t.w,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this.w+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this.w=t.w+e.w,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this.w+=t.w*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this.w-=t.w,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this.w-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this.w=t.w-e.w,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this.w*=t.w,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this.w*=t,this}applyMatrix4(t){const e=this.x,n=this.y,s=this.z,a=this.w,r=t.elements;return this.x=r[0]*e+r[4]*n+r[8]*s+r[12]*a,this.y=r[1]*e+r[5]*n+r[9]*s+r[13]*a,this.z=r[2]*e+r[6]*n+r[10]*s+r[14]*a,this.w=r[3]*e+r[7]*n+r[11]*s+r[15]*a,this}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this.w/=t.w,this}divideScalar(t){return this.multiplyScalar(1/t)}setAxisAngleFromQuaternion(t){this.w=2*Math.acos(t.w);const e=Math.sqrt(1-t.w*t.w);return e<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=t.x/e,this.y=t.y/e,this.z=t.z/e),this}setAxisAngleFromRotationMatrix(t){let e,n,s,a;const l=t.elements,c=l[0],d=l[4],h=l[8],u=l[1],f=l[5],g=l[9],x=l[2],m=l[6],p=l[10];if(Math.abs(d-u)<.01&&Math.abs(h-x)<.01&&Math.abs(g-m)<.01){if(Math.abs(d+u)<.1&&Math.abs(h+x)<.1&&Math.abs(g+m)<.1&&Math.abs(c+f+p-3)<.1)return this.set(1,0,0,0),this;e=Math.PI;const A=(c+1)/2,b=(f+1)/2,w=(p+1)/2,E=(d+u)/4,v=(h+x)/4,S=(g+m)/4;return A>b&&A>w?A<.01?(n=0,s=.707106781,a=.707106781):(n=Math.sqrt(A),s=E/n,a=v/n):b>w?b<.01?(n=.707106781,s=0,a=.707106781):(s=Math.sqrt(b),n=E/s,a=S/s):w<.01?(n=.707106781,s=.707106781,a=0):(a=Math.sqrt(w),n=v/a,s=S/a),this.set(n,s,a,e),this}let y=Math.sqrt((m-g)*(m-g)+(h-x)*(h-x)+(u-d)*(u-d));return Math.abs(y)<.001&&(y=1),this.x=(m-g)/y,this.y=(h-x)/y,this.z=(u-d)/y,this.w=Math.acos((c+f+p-1)/2),this}setFromMatrixPosition(t){const e=t.elements;return this.x=e[12],this.y=e[13],this.z=e[14],this.w=e[15],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this.w=Math.min(this.w,t.w),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this.w=Math.max(this.w,t.w),this}clamp(t,e){return this.x=jt(this.x,t.x,e.x),this.y=jt(this.y,t.y,e.y),this.z=jt(this.z,t.z,e.z),this.w=jt(this.w,t.w,e.w),this}clampScalar(t,e){return this.x=jt(this.x,t,e),this.y=jt(this.y,t,e),this.z=jt(this.z,t,e),this.w=jt(this.w,t,e),this}clampLength(t,e){const n=this.length();return this.divideScalar(n||1).multiplyScalar(jt(n,t,e))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z+this.w*t.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this.w+=(t.w-this.w)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this.z=t.z+(e.z-t.z)*n,this.w=t.w+(e.w-t.w)*n,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z&&t.w===this.w}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this.w=t[e+3],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t[e+3]=this.w,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this.w=t.getW(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}};Ld.prototype.isVector4=!0;let Ae=Ld;class a0 extends _s{constructor(t=1,e=1,n={}){super(),n=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:pn,depthBuffer:!0,stencilBuffer:!1,resolveColorBuffer:!0,resolveDepthBuffer:!0,resolveStencilBuffer:!0,storeMultisampledColorBuffer:!0,storeMultisampledDepthBuffer:!0,storeMultisampledStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1,useArrayDepthTexture:!1},n),this.isRenderTarget=!0,this.width=t,this.height=e,this.depth=n.depth,this.scissor=new Ae(0,0,t,e),this.scissorTest=!1,this.viewport=new Ae(0,0,t,e),this.textures=[];const s=n.count;for(let a=0;a<s;a++)this.textures[a]=new cn({width:t,height:e,depth:n.depth}),this.textures[a].isRenderTargetTexture=!0,this.textures[a].renderTarget=this;this._setTextureOptions(n),this.depthBuffer=n.depthBuffer,this.stencilBuffer=n.stencilBuffer,this.resolveColorBuffer=n.resolveColorBuffer,this.resolveDepthBuffer=n.resolveDepthBuffer,this.resolveStencilBuffer=n.resolveStencilBuffer,this.storeMultisampledColorBuffer=n.storeMultisampledColorBuffer,this.storeMultisampledDepthBuffer=n.storeMultisampledDepthBuffer,this.storeMultisampledStencilBuffer=n.storeMultisampledStencilBuffer,this._depthTexture=null,this.depthTexture=n.depthTexture,this.samples=n.samples,this.multiview=n.multiview,this.useArrayDepthTexture=n.useArrayDepthTexture}_setTextureOptions(t={}){const e={minFilter:pn,generateMipmaps:!1,flipY:!1,internalFormat:null};t.mapping!==void 0&&(e.mapping=t.mapping),t.wrapS!==void 0&&(e.wrapS=t.wrapS),t.wrapT!==void 0&&(e.wrapT=t.wrapT),t.wrapR!==void 0&&(e.wrapR=t.wrapR),t.magFilter!==void 0&&(e.magFilter=t.magFilter),t.minFilter!==void 0&&(e.minFilter=t.minFilter),t.format!==void 0&&(e.format=t.format),t.type!==void 0&&(e.type=t.type),t.anisotropy!==void 0&&(e.anisotropy=t.anisotropy),t.colorSpace!==void 0&&(e.colorSpace=t.colorSpace),t.flipY!==void 0&&(e.flipY=t.flipY),t.generateMipmaps!==void 0&&(e.generateMipmaps=t.generateMipmaps),t.mipmapsAutoUpdate!==void 0&&(e.mipmapsAutoUpdate=t.mipmapsAutoUpdate),t.internalFormat!==void 0&&(e.internalFormat=t.internalFormat);for(let n=0;n<this.textures.length;n++)this.textures[n].setValues(e)}get texture(){return this.textures[0]}set texture(t){this.textures[0]=t}set depthTexture(t){this._depthTexture!==null&&this._depthTexture.renderTarget===this&&(this._depthTexture.renderTarget=null),t!==null&&t.renderTarget===null&&(t.renderTarget=this),this._depthTexture=t}get depthTexture(){return this._depthTexture}setSize(t,e,n=1){if(this.width!==t||this.height!==e||this.depth!==n){this.width=t,this.height=e,this.depth=n;for(let s=0,a=this.textures.length;s<a;s++)this.textures[s].image.width=t,this.textures[s].image.height=e,this.textures[s].image.depth=n,this.textures[s].isData3DTexture!==!0&&(this.textures[s].isArrayTexture=this.textures[s].image.depth>1);this.dispose()}this.viewport.set(0,0,t,e),this.scissor.set(0,0,t,e)}clone(){return new this.constructor().copy(this)}copy(t){this.width=t.width,this.height=t.height,this.depth=t.depth,this.scissor.copy(t.scissor),this.scissorTest=t.scissorTest,this.viewport.copy(t.viewport),this.textures.length=0;for(let e=0,n=t.textures.length;e<n;e++){this.textures[e]=t.textures[e].clone(),this.textures[e].isRenderTargetTexture=!0,this.textures[e].renderTarget=this;const s=Object.assign({},t.textures[e].image);this.textures[e].source=new fd(s)}if(this.depthBuffer=t.depthBuffer,this.stencilBuffer=t.stencilBuffer,this.resolveColorBuffer=t.resolveColorBuffer,this.resolveDepthBuffer=t.resolveDepthBuffer,this.resolveStencilBuffer=t.resolveStencilBuffer,this.storeMultisampledColorBuffer=t.storeMultisampledColorBuffer,this.storeMultisampledDepthBuffer=t.storeMultisampledDepthBuffer,this.storeMultisampledStencilBuffer=t.storeMultisampledStencilBuffer,t.depthTexture!==null)if(t.depthTexture.renderTarget===t){const e=t.depthTexture.clone();e.renderTarget=null,this.depthTexture=e}else this.depthTexture=t.depthTexture;else this.depthTexture=null;return this.samples=t.samples,this.multiview=t.multiview,this.useArrayDepthTexture=t.useArrayDepthTexture,this}dispose(){this.dispatchEvent({type:"dispose"})}}class Bn extends a0{constructor(t=1,e=1,n={}){super(t,e,n),this.isWebGLRenderTarget=!0}}class Tf extends cn{constructor(t=null,e=1,n=1,s=1){super(null),this.isDataArrayTexture=!0,this.image={data:t,width:e,height:n,depth:s},this.magFilter=Qe,this.minFilter=Qe,this.wrapR=Ci,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}copy(t){return super.copy(t),this.wrapR=t.wrapR,this}addLayerUpdate(t){this.layerUpdates.add(t)}clearLayerUpdates(){this.layerUpdates.clear()}}class r0 extends cn{constructor(t=null,e=1,n=1,s=1){super(null),this.isData3DTexture=!0,this.image={data:t,width:e,height:n,depth:s},this.magFilter=Qe,this.minFilter=Qe,this.wrapR=Ci,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}copy(t){return super.copy(t),this.wrapR=t.wrapR,this}}const wo=class wo{constructor(t,e,n,s,a,r,o,l,c,d,h,u,f,g,x,m){this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],t!==void 0&&this.set(t,e,n,s,a,r,o,l,c,d,h,u,f,g,x,m)}set(t,e,n,s,a,r,o,l,c,d,h,u,f,g,x,m){const p=this.elements;return p[0]=t,p[4]=e,p[8]=n,p[12]=s,p[1]=a,p[5]=r,p[9]=o,p[13]=l,p[2]=c,p[6]=d,p[10]=h,p[14]=u,p[3]=f,p[7]=g,p[11]=x,p[15]=m,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new wo().fromArray(this.elements)}copy(t){const e=this.elements,n=t.elements;return e[0]=n[0],e[1]=n[1],e[2]=n[2],e[3]=n[3],e[4]=n[4],e[5]=n[5],e[6]=n[6],e[7]=n[7],e[8]=n[8],e[9]=n[9],e[10]=n[10],e[11]=n[11],e[12]=n[12],e[13]=n[13],e[14]=n[14],e[15]=n[15],this}copyPosition(t){const e=this.elements,n=t.elements;return e[12]=n[12],e[13]=n[13],e[14]=n[14],this}setFromMatrix3(t){const e=t.elements;return this.set(e[0],e[3],e[6],0,e[1],e[4],e[7],0,e[2],e[5],e[8],0,0,0,0,1),this}extractBasis(t,e,n){return this.determinantAffine()===0?(t.set(1,0,0),e.set(0,1,0),n.set(0,0,1),this):(t.setFromMatrixColumn(this,0),e.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this)}makeBasis(t,e,n){return this.set(t.x,e.x,n.x,0,t.y,e.y,n.y,0,t.z,e.z,n.z,0,0,0,0,1),this}extractRotation(t){if(t.determinantAffine()===0)return this.identity();const e=this.elements,n=t.elements,s=1/Ts.setFromMatrixColumn(t,0).length(),a=1/Ts.setFromMatrixColumn(t,1).length(),r=1/Ts.setFromMatrixColumn(t,2).length();return e[0]=n[0]*s,e[1]=n[1]*s,e[2]=n[2]*s,e[3]=0,e[4]=n[4]*a,e[5]=n[5]*a,e[6]=n[6]*a,e[7]=0,e[8]=n[8]*r,e[9]=n[9]*r,e[10]=n[10]*r,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromEuler(t){const e=this.elements,n=t.x,s=t.y,a=t.z,r=Math.cos(n),o=Math.sin(n),l=Math.cos(s),c=Math.sin(s),d=Math.cos(a),h=Math.sin(a);if(t.order==="XYZ"){const u=r*d,f=r*h,g=o*d,x=o*h;e[0]=l*d,e[4]=-l*h,e[8]=c,e[1]=f+g*c,e[5]=u-x*c,e[9]=-o*l,e[2]=x-u*c,e[6]=g+f*c,e[10]=r*l}else if(t.order==="YXZ"){const u=l*d,f=l*h,g=c*d,x=c*h;e[0]=u+x*o,e[4]=g*o-f,e[8]=r*c,e[1]=r*h,e[5]=r*d,e[9]=-o,e[2]=f*o-g,e[6]=x+u*o,e[10]=r*l}else if(t.order==="ZXY"){const u=l*d,f=l*h,g=c*d,x=c*h;e[0]=u-x*o,e[4]=-r*h,e[8]=g+f*o,e[1]=f+g*o,e[5]=r*d,e[9]=x-u*o,e[2]=-r*c,e[6]=o,e[10]=r*l}else if(t.order==="ZYX"){const u=r*d,f=r*h,g=o*d,x=o*h;e[0]=l*d,e[4]=g*c-f,e[8]=u*c+x,e[1]=l*h,e[5]=x*c+u,e[9]=f*c-g,e[2]=-c,e[6]=o*l,e[10]=r*l}else if(t.order==="YZX"){const u=r*l,f=r*c,g=o*l,x=o*c;e[0]=l*d,e[4]=x-u*h,e[8]=g*h+f,e[1]=h,e[5]=r*d,e[9]=-o*d,e[2]=-c*d,e[6]=f*h+g,e[10]=u-x*h}else if(t.order==="XZY"){const u=r*l,f=r*c,g=o*l,x=o*c;e[0]=l*d,e[4]=-h,e[8]=c*d,e[1]=u*h+x,e[5]=r*d,e[9]=f*h-g,e[2]=g*h-f,e[6]=o*d,e[10]=x*h+u}return e[3]=0,e[7]=0,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromQuaternion(t){return this.compose(o0,t,l0)}lookAt(t,e,n){const s=this.elements;return _n.subVectors(t,e),_n.lengthSq()===0&&(_n.z=1),_n.normalize(),Bi.crossVectors(n,_n),Bi.lengthSq()===0&&(Math.abs(n.z)===1?_n.x+=1e-4:_n.z+=1e-4,_n.normalize(),Bi.crossVectors(n,_n)),Bi.normalize(),nr.crossVectors(_n,Bi),s[0]=Bi.x,s[4]=nr.x,s[8]=_n.x,s[1]=Bi.y,s[5]=nr.y,s[9]=_n.y,s[2]=Bi.z,s[6]=nr.z,s[10]=_n.z,this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){const n=t.elements,s=e.elements,a=this.elements,r=n[0],o=n[4],l=n[8],c=n[12],d=n[1],h=n[5],u=n[9],f=n[13],g=n[2],x=n[6],m=n[10],p=n[14],y=n[3],A=n[7],b=n[11],w=n[15],E=s[0],v=s[4],S=s[8],P=s[12],R=s[1],N=s[5],F=s[9],H=s[13],L=s[2],$=s[6],X=s[10],z=s[14],et=s[3],V=s[7],Q=s[11],nt=s[15];return a[0]=r*E+o*R+l*L+c*et,a[4]=r*v+o*N+l*$+c*V,a[8]=r*S+o*F+l*X+c*Q,a[12]=r*P+o*H+l*z+c*nt,a[1]=d*E+h*R+u*L+f*et,a[5]=d*v+h*N+u*$+f*V,a[9]=d*S+h*F+u*X+f*Q,a[13]=d*P+h*H+u*z+f*nt,a[2]=g*E+x*R+m*L+p*et,a[6]=g*v+x*N+m*$+p*V,a[10]=g*S+x*F+m*X+p*Q,a[14]=g*P+x*H+m*z+p*nt,a[3]=y*E+A*R+b*L+w*et,a[7]=y*v+A*N+b*$+w*V,a[11]=y*S+A*F+b*X+w*Q,a[15]=y*P+A*H+b*z+w*nt,this}multiplyScalar(t){const e=this.elements;return e[0]*=t,e[4]*=t,e[8]*=t,e[12]*=t,e[1]*=t,e[5]*=t,e[9]*=t,e[13]*=t,e[2]*=t,e[6]*=t,e[10]*=t,e[14]*=t,e[3]*=t,e[7]*=t,e[11]*=t,e[15]*=t,this}determinant(){const t=this.elements,e=t[0],n=t[4],s=t[8],a=t[12],r=t[1],o=t[5],l=t[9],c=t[13],d=t[2],h=t[6],u=t[10],f=t[14],g=t[3],x=t[7],m=t[11],p=t[15],y=l*f-c*u,A=o*f-c*h,b=o*u-l*h,w=r*f-c*d,E=r*u-l*d,v=r*h-o*d;return e*(x*y-m*A+p*b)-n*(g*y-m*w+p*E)+s*(g*A-x*w+p*v)-a*(g*b-x*E+m*v)}determinantAffine(){const t=this.elements,e=t[0],n=t[4],s=t[8],a=t[1],r=t[5],o=t[9],l=t[2],c=t[6],d=t[10];return e*(r*d-o*c)-n*(a*d-o*l)+s*(a*c-r*l)}transpose(){const t=this.elements;let e;return e=t[1],t[1]=t[4],t[4]=e,e=t[2],t[2]=t[8],t[8]=e,e=t[6],t[6]=t[9],t[9]=e,e=t[3],t[3]=t[12],t[12]=e,e=t[7],t[7]=t[13],t[13]=e,e=t[11],t[11]=t[14],t[14]=e,this}setPosition(t,e,n){const s=this.elements;return t.isVector3?(s[12]=t.x,s[13]=t.y,s[14]=t.z):(s[12]=t,s[13]=e,s[14]=n),this}invert(){const t=this.elements,e=t[0],n=t[1],s=t[2],a=t[3],r=t[4],o=t[5],l=t[6],c=t[7],d=t[8],h=t[9],u=t[10],f=t[11],g=t[12],x=t[13],m=t[14],p=t[15],y=e*o-n*r,A=e*l-s*r,b=e*c-a*r,w=n*l-s*o,E=n*c-a*o,v=s*c-a*l,S=d*x-h*g,P=d*m-u*g,R=d*p-f*g,N=h*m-u*x,F=h*p-f*x,H=u*p-f*m,L=y*H-A*F+b*N+w*R-E*P+v*S;if(L===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const $=1/L;return t[0]=(o*H-l*F+c*N)*$,t[1]=(s*F-n*H-a*N)*$,t[2]=(x*v-m*E+p*w)*$,t[3]=(u*E-h*v-f*w)*$,t[4]=(l*R-r*H-c*P)*$,t[5]=(e*H-s*R+a*P)*$,t[6]=(m*b-g*v-p*A)*$,t[7]=(d*v-u*b+f*A)*$,t[8]=(r*F-o*R+c*S)*$,t[9]=(n*R-e*F-a*S)*$,t[10]=(g*E-x*b+p*y)*$,t[11]=(h*b-d*E-f*y)*$,t[12]=(o*P-r*N-l*S)*$,t[13]=(e*N-n*P+s*S)*$,t[14]=(x*A-g*w-m*y)*$,t[15]=(d*w-h*A+u*y)*$,this}scale(t){const e=this.elements,n=t.x,s=t.y,a=t.z;return e[0]*=n,e[4]*=s,e[8]*=a,e[1]*=n,e[5]*=s,e[9]*=a,e[2]*=n,e[6]*=s,e[10]*=a,e[3]*=n,e[7]*=s,e[11]*=a,this}getMaxScaleOnAxis(){const t=this.elements,e=t[0]*t[0]+t[1]*t[1]+t[2]*t[2],n=t[4]*t[4]+t[5]*t[5]+t[6]*t[6],s=t[8]*t[8]+t[9]*t[9]+t[10]*t[10];return Math.sqrt(Math.max(e,n,s))}makeTranslation(t,e,n){return t.isVector3?this.set(1,0,0,t.x,0,1,0,t.y,0,0,1,t.z,0,0,0,1):this.set(1,0,0,t,0,1,0,e,0,0,1,n,0,0,0,1),this}makeRotationX(t){const e=Math.cos(t),n=Math.sin(t);return this.set(1,0,0,0,0,e,-n,0,0,n,e,0,0,0,0,1),this}makeRotationY(t){const e=Math.cos(t),n=Math.sin(t);return this.set(e,0,n,0,0,1,0,0,-n,0,e,0,0,0,0,1),this}makeRotationZ(t){const e=Math.cos(t),n=Math.sin(t);return this.set(e,-n,0,0,n,e,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(t,e){const n=Math.cos(e),s=Math.sin(e),a=1-n,r=t.x,o=t.y,l=t.z,c=a*r,d=a*o;return this.set(c*r+n,c*o-s*l,c*l+s*o,0,c*o+s*l,d*o+n,d*l-s*r,0,c*l-s*o,d*l+s*r,a*l*l+n,0,0,0,0,1),this}makeScale(t,e,n){return this.set(t,0,0,0,0,e,0,0,0,0,n,0,0,0,0,1),this}makeShear(t,e,n,s,a,r){return this.set(1,n,a,0,t,1,r,0,e,s,1,0,0,0,0,1),this}compose(t,e,n){const s=this.elements,a=e._x,r=e._y,o=e._z,l=e._w,c=a+a,d=r+r,h=o+o,u=a*c,f=a*d,g=a*h,x=r*d,m=r*h,p=o*h,y=l*c,A=l*d,b=l*h,w=n.x,E=n.y,v=n.z;return s[0]=(1-(x+p))*w,s[1]=(f+b)*w,s[2]=(g-A)*w,s[3]=0,s[4]=(f-b)*E,s[5]=(1-(u+p))*E,s[6]=(m+y)*E,s[7]=0,s[8]=(g+A)*v,s[9]=(m-y)*v,s[10]=(1-(u+x))*v,s[11]=0,s[12]=t.x,s[13]=t.y,s[14]=t.z,s[15]=1,this}decompose(t,e,n){const s=this.elements;t.x=s[12],t.y=s[13],t.z=s[14];const a=this.determinantAffine();if(a===0)return n.set(1,1,1),e.identity(),this;let r=Ts.set(s[0],s[1],s[2]).length();const o=Ts.set(s[4],s[5],s[6]).length(),l=Ts.set(s[8],s[9],s[10]).length();a<0&&(r=-r),Xn.copy(this);const c=1/r,d=1/o,h=1/l;return Xn.elements[0]*=c,Xn.elements[1]*=c,Xn.elements[2]*=c,Xn.elements[4]*=d,Xn.elements[5]*=d,Xn.elements[6]*=d,Xn.elements[8]*=h,Xn.elements[9]*=h,Xn.elements[10]*=h,e.setFromRotationMatrix(Xn),n.x=r,n.y=o,n.z=l,this}makePerspective(t,e,n,s,a,r,o=ei,l=!1){const c=this.elements,d=2*a/(e-t),h=2*a/(n-s),u=(e+t)/(e-t),f=(n+s)/(n-s);let g,x;if(l)g=a/(r-a),x=r*a/(r-a);else if(o===ei)g=-(r+a)/(r-a),x=-2*r*a/(r-a);else if(o===Ha)g=-r/(r-a),x=-r*a/(r-a);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+o);return c[0]=d,c[4]=0,c[8]=u,c[12]=0,c[1]=0,c[5]=h,c[9]=f,c[13]=0,c[2]=0,c[6]=0,c[10]=g,c[14]=x,c[3]=0,c[7]=0,c[11]=-1,c[15]=0,this}makeOrthographic(t,e,n,s,a,r,o=ei,l=!1){const c=this.elements,d=2/(e-t),h=2/(n-s),u=-(e+t)/(e-t),f=-(n+s)/(n-s);let g,x;if(l)g=1/(r-a),x=r/(r-a);else if(o===ei)g=-2/(r-a),x=-(r+a)/(r-a);else if(o===Ha)g=-1/(r-a),x=-a/(r-a);else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+o);return c[0]=d,c[4]=0,c[8]=0,c[12]=u,c[1]=0,c[5]=h,c[9]=0,c[13]=f,c[2]=0,c[6]=0,c[10]=g,c[14]=x,c[3]=0,c[7]=0,c[11]=0,c[15]=1,this}equals(t){const e=this.elements,n=t.elements;for(let s=0;s<16;s++)if(e[s]!==n[s])return!1;return!0}fromArray(t,e=0){for(let n=0;n<16;n++)this.elements[n]=t[n+e];return this}toArray(t=[],e=0){const n=this.elements;return t[e]=n[0],t[e+1]=n[1],t[e+2]=n[2],t[e+3]=n[3],t[e+4]=n[4],t[e+5]=n[5],t[e+6]=n[6],t[e+7]=n[7],t[e+8]=n[8],t[e+9]=n[9],t[e+10]=n[10],t[e+11]=n[11],t[e+12]=n[12],t[e+13]=n[13],t[e+14]=n[14],t[e+15]=n[15],t}};wo.prototype.isMatrix4=!0;let ee=wo;const Ts=new D,Xn=new ee,o0=new D(0,0,0),l0=new D(1,1,1),Bi=new D,nr=new D,_n=new D,nh=new ee,ih=new Ni;class zn{constructor(t=0,e=0,n=0,s=zn.DEFAULT_ORDER){this.isEuler=!0,this._x=t,this._y=e,this._z=n,this._order=s}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get order(){return this._order}set order(t){this._order=t,this._onChangeCallback()}set(t,e,n,s=this._order){return this._x=t,this._y=e,this._z=n,this._order=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(t){return this._x=t._x,this._y=t._y,this._z=t._z,this._order=t._order,this._onChangeCallback(),this}setFromRotationMatrix(t,e=this._order,n=!0){const s=t.elements,a=s[0],r=s[4],o=s[8],l=s[1],c=s[5],d=s[9],h=s[2],u=s[6],f=s[10];switch(e){case"XYZ":this._y=Math.asin(jt(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(-d,f),this._z=Math.atan2(-r,a)):(this._x=Math.atan2(u,c),this._z=0);break;case"YXZ":this._x=Math.asin(-jt(d,-1,1)),Math.abs(d)<.9999999?(this._y=Math.atan2(o,f),this._z=Math.atan2(l,c)):(this._y=Math.atan2(-h,a),this._z=0);break;case"ZXY":this._x=Math.asin(jt(u,-1,1)),Math.abs(u)<.9999999?(this._y=Math.atan2(-h,f),this._z=Math.atan2(-r,c)):(this._y=0,this._z=Math.atan2(l,a));break;case"ZYX":this._y=Math.asin(-jt(h,-1,1)),Math.abs(h)<.9999999?(this._x=Math.atan2(u,f),this._z=Math.atan2(l,a)):(this._x=0,this._z=Math.atan2(-r,c));break;case"YZX":this._z=Math.asin(jt(l,-1,1)),Math.abs(l)<.9999999?(this._x=Math.atan2(-d,c),this._y=Math.atan2(-h,a)):(this._x=0,this._y=Math.atan2(o,f));break;case"XZY":this._z=Math.asin(-jt(r,-1,1)),Math.abs(r)<.9999999?(this._x=Math.atan2(u,c),this._y=Math.atan2(o,a)):(this._x=Math.atan2(-d,f),this._y=0);break;default:Ut("Euler: .setFromRotationMatrix() encountered an unknown order: "+e)}return this._order=e,n===!0&&this._onChangeCallback(),this}setFromQuaternion(t,e,n){return nh.makeRotationFromQuaternion(t),this.setFromRotationMatrix(nh,e,n)}setFromVector3(t,e=this._order){return this.set(t.x,t.y,t.z,e)}reorder(t){return ih.setFromEuler(this),this.setFromQuaternion(ih,t)}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._order===this._order}fromArray(t){return this._x=t[0],this._y=t[1],this._z=t[2],t[3]!==void 0&&(this._order=t[3]),this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._order,t}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}zn.DEFAULT_ORDER="XYZ";class pd{constructor(){this.mask=1}set(t){this.mask=(1<<t|0)>>>0}enable(t){this.mask|=1<<t|0}enableAll(){this.mask=-1}toggle(t){this.mask^=1<<t|0}disable(t){this.mask&=~(1<<t|0)}disableAll(){this.mask=0}test(t){return(this.mask&t.mask)!==0}isEnabled(t){return(this.mask&(1<<t|0))!==0}}let c0=0;const sh=new D,Rs=new Ni,vi=new ee,ir=new D,ha=new D,d0=new D,h0=new Ni,ah=new D(1,0,0),rh=new D(0,1,0),oh=new D(0,0,1),lh={type:"added"},u0={type:"removed"},Cs={type:"childadded",child:null},dl={type:"childremoved",child:null};class Ie extends _s{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:c0++}),this.uuid=es(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=Ie.DEFAULT_UP.clone();const t=new D,e=new zn,n=new Ni,s=new D(1,1,1);function a(){n.setFromEuler(e,!1)}function r(){e.setFromQuaternion(n,void 0,!1)}e._onChange(a),n._onChange(r),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:t},rotation:{configurable:!0,enumerable:!0,value:e},quaternion:{configurable:!0,enumerable:!0,value:n},scale:{configurable:!0,enumerable:!0,value:s},modelViewMatrix:{value:new ee},normalMatrix:{value:new Bt}}),this.matrix=new ee,this.matrixWorld=new ee,this.matrixAutoUpdate=Ie.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=Ie.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new pd,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.static=!1,this.userData={},this.pivot=null}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(t){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(t),this.matrix.decompose(this.position,this.quaternion,this.scale),this.pivot!==null&&this.position.copy(this.pivot).applyMatrix4(this.matrix).sub(this.pivot)}applyQuaternion(t){return this.quaternion.premultiply(t),this}setRotationFromAxisAngle(t,e){this.quaternion.setFromAxisAngle(t,e)}setRotationFromEuler(t){this.quaternion.setFromEuler(t,!0)}setRotationFromMatrix(t){this.quaternion.setFromRotationMatrix(t)}setRotationFromQuaternion(t){this.quaternion.copy(t)}rotateOnAxis(t,e){return Rs.setFromAxisAngle(t,e),this.quaternion.multiply(Rs),this}rotateOnWorldAxis(t,e){return Rs.setFromAxisAngle(t,e),this.quaternion.premultiply(Rs),this}rotateX(t){return this.rotateOnAxis(ah,t)}rotateY(t){return this.rotateOnAxis(rh,t)}rotateZ(t){return this.rotateOnAxis(oh,t)}translateOnAxis(t,e){return sh.copy(t).applyQuaternion(this.quaternion),this.position.add(sh.multiplyScalar(e)),this}translateX(t){return this.translateOnAxis(ah,t)}translateY(t){return this.translateOnAxis(rh,t)}translateZ(t){return this.translateOnAxis(oh,t)}localToWorld(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(this.matrixWorld)}worldToLocal(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(vi.copy(this.matrixWorld).invert())}lookAt(t,e,n){t.isVector3?ir.copy(t):ir.set(t,e,n);const s=this.parent;this.updateWorldMatrix(!0,!1),ha.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?vi.lookAt(ha,ir,this.up):vi.lookAt(ir,ha,this.up),this.quaternion.setFromRotationMatrix(vi),s&&(vi.extractRotation(s.matrixWorld),Rs.setFromRotationMatrix(vi),this.quaternion.premultiply(Rs.invert()))}add(t){if(arguments.length>1){for(let e=0;e<arguments.length;e++)this.add(arguments[e]);return this}return t===this?(ie("Object3D.add: object can't be added as a child of itself.",t),this):(t&&t.isObject3D?(t.removeFromParent(),t.parent=this,this.children.push(t),t.dispatchEvent(lh),Cs.child=t,this.dispatchEvent(Cs),Cs.child=null):ie("Object3D.add: object not an instance of THREE.Object3D.",t),this)}remove(t){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.remove(arguments[n]);return this}const e=this.children.indexOf(t);return e!==-1&&(t.parent=null,this.children.splice(e,1),t.dispatchEvent(u0),dl.child=t,this.dispatchEvent(dl),dl.child=null),this}removeFromParent(){const t=this.parent;return t!==null&&t.remove(this),this}clear(){return this.remove(...this.children)}attach(t){return this.updateWorldMatrix(!0,!1),vi.copy(this.matrixWorld).invert(),t.parent!==null&&(t.parent.updateWorldMatrix(!0,!1),vi.multiply(t.parent.matrixWorld)),t.applyMatrix4(vi),t.removeFromParent(),t.parent=this,this.children.push(t),t.updateWorldMatrix(!1,!0),t.dispatchEvent(lh),Cs.child=t,this.dispatchEvent(Cs),Cs.child=null,this}getObjectById(t){return this.getObjectByProperty("id",t)}getObjectByName(t){return this.getObjectByProperty("name",t)}getObjectByProperty(t,e){if(this[t]===e)return this;for(let n=0,s=this.children.length;n<s;n++){const r=this.children[n].getObjectByProperty(t,e);if(r!==void 0)return r}}getObjectsByProperty(t,e,n=[]){this[t]===e&&n.push(this);const s=this.children;for(let a=0,r=s.length;a<r;a++)s[a].getObjectsByProperty(t,e,n);return n}getWorldPosition(t){return this.updateWorldMatrix(!0,!1),t.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(ha,t,d0),t}getWorldScale(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(ha,h0,t),t}getWorldDirection(t){this.updateWorldMatrix(!0,!1);const e=this.matrixWorld.elements;return t.set(e[8],e[9],e[10]).normalize()}raycast(){}intersectsFrustum(){return!0}traverse(t){t(this);const e=this.children;for(let n=0,s=e.length;n<s;n++)e[n].traverse(t)}traverseVisible(t){if(this.visible===!1)return;t(this);const e=this.children;for(let n=0,s=e.length;n<s;n++)e[n].traverseVisible(t)}traverseAncestors(t){const e=this.parent;e!==null&&(t(e),e.traverseAncestors(t))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale);const t=this.pivot;if(t!==null){const e=t.x,n=t.y,s=t.z,a=this.matrix.elements;a[12]+=e-a[0]*e-a[4]*n-a[8]*s,a[13]+=n-a[1]*e-a[5]*n-a[9]*s,a[14]+=s-a[2]*e-a[6]*n-a[10]*s}this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(t){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||t)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,t=!0);const e=this.children;for(let n=0,s=e.length;n<s;n++)e[n].updateMatrixWorld(t)}updateWorldMatrix(t,e,n=!1){const s=this.parent;if(t===!0&&s!==null&&s.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||n)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,n=!0),e===!0){const a=this.children;for(let r=0,o=a.length;r<o;r++)a[r].updateWorldMatrix(!1,!0,n)}}toJSON(t){const e=t===void 0||typeof t=="string",n={};e&&(t={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.7,type:"Object",generator:"Object3D.toJSON"});const s={};s.uuid=this.uuid,s.type=this.type,s.name=this.name,s.castShadow=this.castShadow,s.receiveShadow=this.receiveShadow,s.visible=this.visible,s.frustumCulled=this.frustumCulled,s.renderOrder=this.renderOrder,s.static=this.static,s.matrixAutoUpdate=this.matrixAutoUpdate,Object.keys(this.userData).length>0&&(s.userData=this.userData),s.layers=this.layers.mask,s.matrix=this.matrix.toArray(),s.up=this.up.toArray(),this.pivot!==null&&(s.pivot=this.pivot.toArray()),this.morphTargetDictionary!==void 0&&(s.morphTargetDictionary=Object.assign({},this.morphTargetDictionary)),this.morphTargetInfluences!==void 0&&(s.morphTargetInfluences=this.morphTargetInfluences.slice()),this.isInstancedMesh&&(s.type="InstancedMesh",s.count=this.count,s.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(s.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(s.type="BatchedMesh",s.perObjectFrustumCulled=this.perObjectFrustumCulled,s.sortObjects=this.sortObjects,s.drawRanges=this._drawRanges,s.reservedRanges=this._reservedRanges,s.geometryInfo=this._geometryInfo.map(o=>({...o,boundingBox:o.boundingBox?o.boundingBox.toJSON():void 0,boundingSphere:o.boundingSphere?o.boundingSphere.toJSON():void 0})),s.instanceInfo=this._instanceInfo.map(o=>({...o})),s.availableInstanceIds=this._availableInstanceIds.slice(),s.availableGeometryIds=this._availableGeometryIds.slice(),s.nextIndexStart=this._nextIndexStart,s.nextVertexStart=this._nextVertexStart,s.geometryCount=this._geometryCount,s.maxInstanceCount=this._maxInstanceCount,s.maxVertexCount=this._maxVertexCount,s.maxIndexCount=this._maxIndexCount,s.geometryInitialized=this._geometryInitialized,s.matricesTexture=this._matricesTexture.toJSON(t),s.indirectTexture=this._indirectTexture.toJSON(t),this._colorsTexture!==null&&(s.colorsTexture=this._colorsTexture.toJSON(t)),this.boundingSphere!==null&&(s.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(s.boundingBox=this.boundingBox.toJSON()));function a(o,l){return o[l.uuid]===void 0&&(o[l.uuid]=l.toJSON(t)),l.uuid}if(this.isScene)this.background&&(this.background.isColor?s.background=this.background.toJSON():this.background.isTexture&&(s.background=this.background.toJSON(t).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(s.environment=this.environment.toJSON(t).uuid);else if(this.isMesh||this.isLine||this.isPoints){s.geometry=a(t.geometries,this.geometry);const o=this.geometry.parameters;if(o!==void 0&&o.shapes!==void 0){const l=o.shapes;if(Array.isArray(l))for(let c=0,d=l.length;c<d;c++){const h=l[c];a(t.shapes,h)}else a(t.shapes,l)}}if(this.isSkinnedMesh&&(s.bindMode=this.bindMode,s.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(a(t.skeletons,this.skeleton),s.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const o=[];for(let l=0,c=this.material.length;l<c;l++)o.push(a(t.materials,this.material[l]));s.material=o}else s.material=a(t.materials,this.material);if(this.children.length>0){s.children=[];for(let o=0;o<this.children.length;o++)s.children.push(this.children[o].toJSON(t).object)}if(this.animations.length>0){s.animations=[];for(let o=0;o<this.animations.length;o++){const l=this.animations[o];s.animations.push(a(t.animations,l))}}if(e){const o=r(t.geometries),l=r(t.materials),c=r(t.textures),d=r(t.images),h=r(t.shapes),u=r(t.skeletons),f=r(t.animations),g=r(t.nodes);o.length>0&&(n.geometries=o),l.length>0&&(n.materials=l),c.length>0&&(n.textures=c),d.length>0&&(n.images=d),h.length>0&&(n.shapes=h),u.length>0&&(n.skeletons=u),f.length>0&&(n.animations=f),g.length>0&&(n.nodes=g)}return n.object=s,n;function r(o){const l=[];for(const c in o){const d=o[c];delete d.metadata,l.push(d)}return l}}clone(t){return new this.constructor().copy(this,t)}copy(t,e=!0){if(this.name=t.name,this.up.copy(t.up),this.position.copy(t.position),this.rotation.order=t.rotation.order,this.quaternion.copy(t.quaternion),this.scale.copy(t.scale),this.pivot=t.pivot!==null?t.pivot.clone():null,this.matrix.copy(t.matrix),this.matrixWorld.copy(t.matrixWorld),this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrixWorldAutoUpdate=t.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=t.matrixWorldNeedsUpdate,this.layers.mask=t.layers.mask,this.visible=t.visible,this.castShadow=t.castShadow,this.receiveShadow=t.receiveShadow,this.frustumCulled=t.frustumCulled,this.renderOrder=t.renderOrder,this.static=t.static,this.animations=t.animations.slice(),this.userData=JSON.parse(JSON.stringify(t.userData)),e===!0)for(let n=0;n<t.children.length;n++){const s=t.children[n];this.add(s.clone())}return this}dispose(){this.dispatchEvent({type:"dispose"})}}Ie.DEFAULT_UP=new D(0,1,0);Ie.DEFAULT_MATRIX_AUTO_UPDATE=!0;Ie.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;class Te extends Ie{constructor(){super(),this.isGroup=!0,this.type="Group"}}const f0={type:"move"};class hl{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new Te,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new Te,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new D,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new D),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new Te,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new D,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new D,this._grip.eventsEnabled=!1),this._grip}dispatchEvent(t){return this._targetRay!==null&&this._targetRay.dispatchEvent(t),this._grip!==null&&this._grip.dispatchEvent(t),this._hand!==null&&this._hand.dispatchEvent(t),this}connect(t){if(t&&t.hand){const e=this._hand;if(e)for(const n of t.hand.values())this._getHandJoint(e,n)}return this.dispatchEvent({type:"connected",data:t}),this}disconnect(t){return this.dispatchEvent({type:"disconnected",data:t}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(t,e,n){let s=null,a=null,r=null;const o=this._targetRay,l=this._grip,c=this._hand;if(t&&e.session.visibilityState!=="visible-blurred"){if(c&&t.hand){r=!0;for(const x of t.hand.values()){const m=e.getJointPose(x,n),p=this._getHandJoint(c,x);m!==null&&(p.matrix.fromArray(m.transform.matrix),p.matrix.decompose(p.position,p.quaternion,p.scale),p.matrixWorldNeedsUpdate=!0,p.jointRadius=m.radius),p.visible=m!==null}const d=c.joints["index-finger-tip"],h=c.joints["thumb-tip"],u=d.position.distanceTo(h.position),f=.02,g=.005;c.inputState.pinching&&u>f+g?(c.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:t.handedness,target:this})):!c.inputState.pinching&&u<=f-g&&(c.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:t.handedness,target:this}))}else l!==null&&t.gripSpace&&(a=e.getPose(t.gripSpace,n),a!==null&&(l.matrix.fromArray(a.transform.matrix),l.matrix.decompose(l.position,l.quaternion,l.scale),l.matrixWorldNeedsUpdate=!0,a.linearVelocity?(l.hasLinearVelocity=!0,l.linearVelocity.copy(a.linearVelocity)):l.hasLinearVelocity=!1,a.angularVelocity?(l.hasAngularVelocity=!0,l.angularVelocity.copy(a.angularVelocity)):l.hasAngularVelocity=!1,l.eventsEnabled&&l.dispatchEvent({type:"gripUpdated",data:t,target:this})));o!==null&&(s=e.getPose(t.targetRaySpace,n),s===null&&a!==null&&(s=a),s!==null&&(o.matrix.fromArray(s.transform.matrix),o.matrix.decompose(o.position,o.quaternion,o.scale),o.matrixWorldNeedsUpdate=!0,s.linearVelocity?(o.hasLinearVelocity=!0,o.linearVelocity.copy(s.linearVelocity)):o.hasLinearVelocity=!1,s.angularVelocity?(o.hasAngularVelocity=!0,o.angularVelocity.copy(s.angularVelocity)):o.hasAngularVelocity=!1,this.dispatchEvent(f0)))}return o!==null&&(o.visible=s!==null),l!==null&&(l.visible=a!==null),c!==null&&(c.visible=r!==null),this}_getHandJoint(t,e){if(t.joints[e.jointName]===void 0){const n=new Te;n.matrixAutoUpdate=!1,n.visible=!1,t.joints[e.jointName]=n,t.add(n)}return t.joints[e.jointName]}}const Rf={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},ki={h:0,s:0,l:0},sr={h:0,s:0,l:0};function ul(i,t,e){return e<0&&(e+=1),e>1&&(e-=1),e<1/6?i+(t-i)*6*e:e<1/2?t:e<2/3?i+(t-i)*6*(2/3-e):i}class Rt{constructor(t,e,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(t,e,n)}set(t,e,n){if(e===void 0&&n===void 0){const s=t;s&&s.isColor?this.copy(s):typeof s=="number"?this.setHex(s):typeof s=="string"&&this.setStyle(s)}else this.setRGB(t,e,n);return this}setScalar(t){return this.r=t,this.g=t,this.b=t,this}setHex(t,e=Je){return t=Math.floor(t),this.r=(t>>16&255)/255,this.g=(t>>8&255)/255,this.b=(t&255)/255,te.colorSpaceToWorking(this,e),this}setRGB(t,e,n,s=te.workingColorSpace){return this.r=t,this.g=e,this.b=n,te.colorSpaceToWorking(this,s),this}setHSL(t,e,n,s=te.workingColorSpace){if(t=dd(t,1),e=jt(e,0,1),n=jt(n,0,1),e===0)this.r=this.g=this.b=n;else{const a=n<=.5?n*(1+e):n+e-n*e,r=2*n-a;this.r=ul(r,a,t+1/3),this.g=ul(r,a,t),this.b=ul(r,a,t-1/3)}return te.colorSpaceToWorking(this,s),this}setStyle(t,e=Je){function n(a){a!==void 0&&parseFloat(a)<1&&Ut("Color: Alpha component of "+t+" will be ignored.")}let s;if(s=/^(\w+)\(([^\)]*)\)/.exec(t)){let a;const r=s[1],o=s[2];switch(r){case"rgb":case"rgba":if(a=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d+(?:\.\d+)?|\.\d+)\s*)?$/.exec(o))return n(a[4]),this.setRGB(Math.min(255,parseInt(a[1],10))/255,Math.min(255,parseInt(a[2],10))/255,Math.min(255,parseInt(a[3],10))/255,e);if(a=/^\s*(\d+(?:\.\d+)?|\.\d+)\%\s*,\s*(\d+(?:\.\d+)?|\.\d+)\%\s*,\s*(\d+(?:\.\d+)?|\.\d+)\%\s*(?:,\s*(\d+(?:\.\d+)?|\.\d+)\s*)?$/.exec(o))return n(a[4]),this.setRGB(Math.min(100,parseFloat(a[1]))/100,Math.min(100,parseFloat(a[2]))/100,Math.min(100,parseFloat(a[3]))/100,e);break;case"hsl":case"hsla":if(a=/^\s*([+-]?(?:\d+(?:\.\d+)?|\.\d+))\s*,\s*(\d+(?:\.\d+)?|\.\d+)\%\s*,\s*(\d+(?:\.\d+)?|\.\d+)\%\s*(?:,\s*(\d+(?:\.\d+)?|\.\d+)\s*)?$/.exec(o))return n(a[4]),this.setHSL(parseFloat(a[1])/360,parseFloat(a[2])/100,parseFloat(a[3])/100,e);break;default:Ut("Color: Unknown color model "+t)}}else if(s=/^\#([A-Fa-f\d]+)$/.exec(t)){const a=s[1],r=a.length;if(r===3)return this.setRGB(parseInt(a.charAt(0),16)/15,parseInt(a.charAt(1),16)/15,parseInt(a.charAt(2),16)/15,e);if(r===6)return this.setHex(parseInt(a,16),e);Ut("Color: Invalid hex color "+t)}else if(t&&t.length>0)return this.setColorName(t,e);return this}setColorName(t,e=Je){const n=Rf[t.toLowerCase()];return n!==void 0?this.setHex(n,e):Ut("Color: Unknown color "+t),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(t){return this.r=t.r,this.g=t.g,this.b=t.b,this}copySRGBToLinear(t){return this.r=Ii(t.r),this.g=Ii(t.g),this.b=Ii(t.b),this}copyLinearToSRGB(t){return this.r=Ks(t.r),this.g=Ks(t.g),this.b=Ks(t.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(t=Je){return te.workingToColorSpace(rn.copy(this),t),Math.round(jt(rn.r*255,0,255))*65536+Math.round(jt(rn.g*255,0,255))*256+Math.round(jt(rn.b*255,0,255))}getHexString(t=Je){return("000000"+this.getHex(t).toString(16)).slice(-6)}getHSL(t,e=te.workingColorSpace){te.workingToColorSpace(rn.copy(this),e);const n=rn.r,s=rn.g,a=rn.b,r=Math.max(n,s,a),o=Math.min(n,s,a);let l,c;const d=(o+r)/2;if(o===r)l=0,c=0;else{const h=r-o;switch(c=d<=.5?h/(r+o):h/(2-r-o),r){case n:l=(s-a)/h+(s<a?6:0);break;case s:l=(a-n)/h+2;break;case a:l=(n-s)/h+4;break}l/=6}return t.h=l,t.s=c,t.l=d,t}getRGB(t,e=te.workingColorSpace){return te.workingToColorSpace(rn.copy(this),e),t.r=rn.r,t.g=rn.g,t.b=rn.b,t}getStyle(t=Je){te.workingToColorSpace(rn.copy(this),t);const e=rn.r,n=rn.g,s=rn.b;return t!==Je?`color(${t} ${e.toFixed(3)} ${n.toFixed(3)} ${s.toFixed(3)})`:`rgb(${Math.round(e*255)},${Math.round(n*255)},${Math.round(s*255)})`}offsetHSL(t,e,n){return this.getHSL(ki),this.setHSL(ki.h+t,ki.s+e,ki.l+n)}add(t){return this.r+=t.r,this.g+=t.g,this.b+=t.b,this}addColors(t,e){return this.r=t.r+e.r,this.g=t.g+e.g,this.b=t.b+e.b,this}addScalar(t){return this.r+=t,this.g+=t,this.b+=t,this}sub(t){return this.r=Math.max(0,this.r-t.r),this.g=Math.max(0,this.g-t.g),this.b=Math.max(0,this.b-t.b),this}multiply(t){return this.r*=t.r,this.g*=t.g,this.b*=t.b,this}multiplyScalar(t){return this.r*=t,this.g*=t,this.b*=t,this}lerp(t,e){return this.r+=(t.r-this.r)*e,this.g+=(t.g-this.g)*e,this.b+=(t.b-this.b)*e,this}lerpColors(t,e,n){return this.r=t.r+(e.r-t.r)*n,this.g=t.g+(e.g-t.g)*n,this.b=t.b+(e.b-t.b)*n,this}lerpHSL(t,e){this.getHSL(ki),t.getHSL(sr);const n=Na(ki.h,sr.h,e),s=Na(ki.s,sr.s,e),a=Na(ki.l,sr.l,e);return this.setHSL(n,s,a),this}setFromVector3(t){return this.r=t.x,this.g=t.y,this.b=t.z,this}applyMatrix3(t){const e=this.r,n=this.g,s=this.b,a=t.elements;return this.r=a[0]*e+a[3]*n+a[6]*s,this.g=a[1]*e+a[4]*n+a[7]*s,this.b=a[2]*e+a[5]*n+a[8]*s,this}equals(t){return t.r===this.r&&t.g===this.g&&t.b===this.b}fromArray(t,e=0){return this.r=t[e],this.g=t[e+1],this.b=t[e+2],this}toArray(t=[],e=0){return t[e]=this.r,t[e+1]=this.g,t[e+2]=this.b,t}fromBufferAttribute(t,e){return this.r=t.getX(e),this.g=t.getY(e),this.b=t.getZ(e),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const rn=new Rt;Rt.NAMES=Rf;class Bo extends Ie{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new zn,this.environmentIntensity=1,this.environmentRotation=new zn,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(t,e){return super.copy(t,e),this.background=t.background!==null?t.background.clone():null,this.environment=t.environment!==null?t.environment.clone():null,this.fog=t.fog!==null?t.fog.clone():null,this.backgroundBlurriness=t.backgroundBlurriness,this.backgroundIntensity=t.backgroundIntensity,this.backgroundRotation.copy(t.backgroundRotation),this.environmentIntensity=t.environmentIntensity,this.environmentRotation.copy(t.environmentRotation),this.overrideMaterial=t.overrideMaterial!==null?t.overrideMaterial.clone():null,this.matrixAutoUpdate=t.matrixAutoUpdate,this}toJSON(t){const e=super.toJSON(t);return this.fog!==null&&(e.object.fog=this.fog.toJSON()),e.object.backgroundBlurriness=this.backgroundBlurriness,e.object.backgroundIntensity=this.backgroundIntensity,e.object.backgroundRotation=this.backgroundRotation.toArray(),e.object.environmentIntensity=this.environmentIntensity,e.object.environmentRotation=this.environmentRotation.toArray(),e}}const qn=new D,xi=new D,fl=new D,yi=new D,Ps=new D,Ls=new D,ch=new D,pl=new D,ml=new D,gl=new D,vl=new Ae,xl=new Ae,yl=new Ae;class wn{constructor(t=new D,e=new D,n=new D){this.a=t,this.b=e,this.c=n}static getNormal(t,e,n,s){s.subVectors(n,e),qn.subVectors(t,e),s.cross(qn);const a=s.lengthSq();return a>0?s.multiplyScalar(1/Math.sqrt(a)):s.set(0,0,0)}static getBarycoord(t,e,n,s,a){qn.subVectors(s,e),xi.subVectors(n,e),fl.subVectors(t,e);const r=qn.dot(qn),o=qn.dot(xi),l=qn.dot(fl),c=xi.dot(xi),d=xi.dot(fl),h=r*c-o*o;if(h===0)return a.set(0,0,0),null;const u=1/h,f=(c*l-o*d)*u,g=(r*d-o*l)*u;return a.set(1-f-g,g,f)}static containsPoint(t,e,n,s){return this.getBarycoord(t,e,n,s,yi)===null?!1:yi.x>=0&&yi.y>=0&&yi.x+yi.y<=1}static getInterpolation(t,e,n,s,a,r,o,l){return this.getBarycoord(t,e,n,s,yi)===null?(l.x=0,l.y=0,"z"in l&&(l.z=0),"w"in l&&(l.w=0),null):(l.setScalar(0),l.addScaledVector(a,yi.x),l.addScaledVector(r,yi.y),l.addScaledVector(o,yi.z),l)}static getInterpolatedAttribute(t,e,n,s,a,r){return vl.setScalar(0),xl.setScalar(0),yl.setScalar(0),vl.fromBufferAttribute(t,e),xl.fromBufferAttribute(t,n),yl.fromBufferAttribute(t,s),r.setScalar(0),r.addScaledVector(vl,a.x),r.addScaledVector(xl,a.y),r.addScaledVector(yl,a.z),r}static isFrontFacing(t,e,n,s){return qn.subVectors(n,e),xi.subVectors(t,e),qn.cross(xi).dot(s)<0}set(t,e,n){return this.a.copy(t),this.b.copy(e),this.c.copy(n),this}setFromPointsAndIndices(t,e,n,s){return this.a.copy(t[e]),this.b.copy(t[n]),this.c.copy(t[s]),this}setFromAttributeAndIndices(t,e,n,s){return this.a.fromBufferAttribute(t,e),this.b.fromBufferAttribute(t,n),this.c.fromBufferAttribute(t,s),this}clone(){return new this.constructor().copy(this)}copy(t){return this.a.copy(t.a),this.b.copy(t.b),this.c.copy(t.c),this}getArea(){return qn.subVectors(this.c,this.b),xi.subVectors(this.a,this.b),qn.cross(xi).length()*.5}getMidpoint(t){return t.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(t){return wn.getNormal(this.a,this.b,this.c,t)}getPlane(t){return t.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(t,e){return wn.getBarycoord(t,this.a,this.b,this.c,e)}getInterpolation(t,e,n,s,a){return wn.getInterpolation(t,this.a,this.b,this.c,e,n,s,a)}containsPoint(t){return wn.containsPoint(t,this.a,this.b,this.c)}isFrontFacing(t){return wn.isFrontFacing(this.a,this.b,this.c,t)}intersectsBox(t){return t.intersectsTriangle(this)}closestPointToPoint(t,e){const n=this.a,s=this.b,a=this.c;let r,o;Ps.subVectors(s,n),Ls.subVectors(a,n),pl.subVectors(t,n);const l=Ps.dot(pl),c=Ls.dot(pl);if(l<=0&&c<=0)return e.copy(n);ml.subVectors(t,s);const d=Ps.dot(ml),h=Ls.dot(ml);if(d>=0&&h<=d)return e.copy(s);const u=l*h-d*c;if(u<=0&&l>=0&&d<=0&&l-d>0)return r=l/(l-d),e.copy(n).addScaledVector(Ps,r);gl.subVectors(t,a);const f=Ps.dot(gl),g=Ls.dot(gl);if(g>=0&&f<=g)return e.copy(a);const x=f*c-l*g;if(x<=0&&c>=0&&g<=0)return o=c/(c-g),e.copy(n).addScaledVector(Ls,o);const m=d*g-f*h;if(m<=0&&h-d>=0&&f-g>=0)return ch.subVectors(a,s),o=(h-d)/(h-d+(f-g)),e.copy(s).addScaledVector(ch,o);const p=1/(m+x+u);return r=x*p,o=u*p,e.copy(n).addScaledVector(Ps,r).addScaledVector(Ls,o)}equals(t){return t.a.equals(this.a)&&t.b.equals(this.b)&&t.c.equals(this.c)}}class Ms{constructor(t=new D(1/0,1/0,1/0),e=new D(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=t,this.max=e}set(t,e){return this.min.copy(t),this.max.copy(e),this}setFromArray(t){this.makeEmpty();for(let e=0,n=t.length;e<n;e+=3)this.expandByPoint(Yn.fromArray(t,e));return this}setFromBufferAttribute(t){this.makeEmpty();for(let e=0,n=t.count;e<n;e++)this.expandByPoint(Yn.fromBufferAttribute(t,e));return this}setFromPoints(t){this.makeEmpty();for(let e=0,n=t.length;e<n;e++)this.expandByPoint(t[e]);return this}setFromCenterAndSize(t,e){const n=Yn.copy(e).multiplyScalar(.5);return this.min.copy(t).sub(n),this.max.copy(t).add(n),this}setFromObject(t,e=!1){return this.makeEmpty(),this.expandByObject(t,e)}clone(){return new this.constructor().copy(this)}copy(t){return this.min.copy(t.min),this.max.copy(t.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(t){return this.isEmpty()?t.set(0,0,0):t.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(t){return this.isEmpty()?t.set(0,0,0):t.subVectors(this.max,this.min)}expandByPoint(t){return this.min.min(t),this.max.max(t),this}expandByVector(t){return this.min.sub(t),this.max.add(t),this}expandByScalar(t){return this.min.addScalar(-t),this.max.addScalar(t),this}expandByObject(t,e=!1){t.updateWorldMatrix(!1,!1);const n=t.geometry;if(n!==void 0){const a=n.getAttribute("position");if(e===!0&&a!==void 0&&t.isInstancedMesh!==!0&&t.isBatchedMesh!==!0)for(let r=0,o=a.count;r<o;r++)t.isMesh===!0?t.getVertexPosition(r,Yn):Yn.fromBufferAttribute(a,r),Yn.applyMatrix4(t.matrixWorld),this.expandByPoint(Yn);else t.boundingBox!==void 0?(t.boundingBox===null&&t.computeBoundingBox(),ar.copy(t.boundingBox)):(n.boundingBox===null&&n.computeBoundingBox(),ar.copy(n.boundingBox)),ar.applyMatrix4(t.matrixWorld),this.union(ar)}const s=t.children;for(let a=0,r=s.length;a<r;a++)this.expandByObject(s[a],e);return this}containsPoint(t){return t.x>=this.min.x&&t.x<=this.max.x&&t.y>=this.min.y&&t.y<=this.max.y&&t.z>=this.min.z&&t.z<=this.max.z}containsBox(t){return this.min.x<=t.min.x&&t.max.x<=this.max.x&&this.min.y<=t.min.y&&t.max.y<=this.max.y&&this.min.z<=t.min.z&&t.max.z<=this.max.z}getParameter(t,e){return e.set((t.x-this.min.x)/(this.max.x-this.min.x),(t.y-this.min.y)/(this.max.y-this.min.y),(t.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(t){return t.max.x>=this.min.x&&t.min.x<=this.max.x&&t.max.y>=this.min.y&&t.min.y<=this.max.y&&t.max.z>=this.min.z&&t.min.z<=this.max.z}intersectsSphere(t){return this.clampPoint(t.center,Yn),Yn.distanceToSquared(t.center)<=t.radius*t.radius}intersectsPlane(t){let e,n;return t.normal.x>0?(e=t.normal.x*this.min.x,n=t.normal.x*this.max.x):(e=t.normal.x*this.max.x,n=t.normal.x*this.min.x),t.normal.y>0?(e+=t.normal.y*this.min.y,n+=t.normal.y*this.max.y):(e+=t.normal.y*this.max.y,n+=t.normal.y*this.min.y),t.normal.z>0?(e+=t.normal.z*this.min.z,n+=t.normal.z*this.max.z):(e+=t.normal.z*this.max.z,n+=t.normal.z*this.min.z),e<=-t.constant&&n>=-t.constant}intersectsTriangle(t){if(this.isEmpty())return!1;this.getCenter(ua),rr.subVectors(this.max,ua),Ds.subVectors(t.a,ua),Is.subVectors(t.b,ua),Ns.subVectors(t.c,ua),zi.subVectors(Is,Ds),$i.subVectors(Ns,Is),rs.subVectors(Ds,Ns);let e=[0,-zi.z,zi.y,0,-$i.z,$i.y,0,-rs.z,rs.y,zi.z,0,-zi.x,$i.z,0,-$i.x,rs.z,0,-rs.x,-zi.y,zi.x,0,-$i.y,$i.x,0,-rs.y,rs.x,0];return!bl(e,Ds,Is,Ns,rr)||(e=[1,0,0,0,1,0,0,0,1],!bl(e,Ds,Is,Ns,rr))?!1:(or.crossVectors(zi,$i),e=[or.x,or.y,or.z],bl(e,Ds,Is,Ns,rr))}clampPoint(t,e){return e.copy(t).clamp(this.min,this.max)}distanceToPoint(t){return this.clampPoint(t,Yn).distanceTo(t)}getBoundingSphere(t){return this.isEmpty()?t.makeEmpty():(this.getCenter(t.center),t.radius=this.getSize(Yn).length()*.5),t}intersect(t){return this.min.max(t.min),this.max.min(t.max),this.isEmpty()&&this.makeEmpty(),this}union(t){return this.min.min(t.min),this.max.max(t.max),this}applyMatrix4(t){return this.isEmpty()?this:(bi[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(t),bi[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(t),bi[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(t),bi[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(t),bi[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(t),bi[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(t),bi[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(t),bi[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(t),this.setFromPoints(bi),this)}translate(t){return this.min.add(t),this.max.add(t),this}equals(t){return t.min.equals(this.min)&&t.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(t){return this.min.fromArray(t.min),this.max.fromArray(t.max),this}}const bi=[new D,new D,new D,new D,new D,new D,new D,new D],Yn=new D,ar=new Ms,Ds=new D,Is=new D,Ns=new D,zi=new D,$i=new D,rs=new D,ua=new D,rr=new D,or=new D,os=new D;function bl(i,t,e,n,s){for(let a=0,r=i.length-3;a<=r;a+=3){os.fromArray(i,a);const o=s.x*Math.abs(os.x)+s.y*Math.abs(os.y)+s.z*Math.abs(os.z),l=t.dot(os),c=e.dot(os),d=n.dot(os);if(Math.max(-Math.max(l,c,d),Math.min(l,c,d))>o)return!1}return!0}const De=new D,lr=new It;let p0=0;class Ne extends _s{constructor(t,e,n=!1){if(super(),Array.isArray(t))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:p0++}),this.name="",this.array=t,this.itemSize=e,this.count=t!==void 0?t.length/e:0,this.normalized=n,this.usage=wf,this.updateRanges=[],this.gpuType=ti,this.version=0,this._normalizationScale=t!==void 0?Oo(t):void 0}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}setUsage(t){return this.usage=t,this}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.name=t.name,this.array=new t.array.constructor(t.array),this.itemSize=t.itemSize,this.count=t.count,this.normalized=t.normalized,this.usage=t.usage,this.gpuType=t.gpuType,this._normalizationScale=t._normalizationScale,this}copyAt(t,e,n){t*=this.itemSize,n*=e.itemSize;for(let s=0,a=this.itemSize;s<a;s++)this.array[t+s]=e.array[n+s];return this}copyArray(t){return this.array.set(t),this}applyMatrix3(t){if(this.itemSize===2)for(let e=0,n=this.count;e<n;e++)lr.fromBufferAttribute(this,e),lr.applyMatrix3(t),this.setXY(e,lr.x,lr.y);else if(this.itemSize===3)for(let e=0,n=this.count;e<n;e++)De.fromBufferAttribute(this,e),De.applyMatrix3(t),this.setXYZ(e,De.x,De.y,De.z);return this}applyMatrix4(t){for(let e=0,n=this.count;e<n;e++)De.fromBufferAttribute(this,e),De.applyMatrix4(t),this.setXYZ(e,De.x,De.y,De.z);return this}applyNormalMatrix(t){for(let e=0,n=this.count;e<n;e++)De.fromBufferAttribute(this,e),De.applyNormalMatrix(t),this.setXYZ(e,De.x,De.y,De.z);return this}transformDirection(t){for(let e=0,n=this.count;e<n;e++)De.fromBufferAttribute(this,e),De.transformDirection(t),this.setXYZ(e,De.x,De.y,De.z);return this}set(t,e=0){return this.array.set(t,e),this}getComponent(t,e){let n=this.array[t*this.itemSize+e];return this.normalized&&(n=this._denormalize(n)),n}setComponent(t,e,n){return this.normalized&&(n=this._normalize(n)),this.array[t*this.itemSize+e]=n,this}getX(t){let e=this.array[t*this.itemSize];return this.normalized&&(e=this._denormalize(e)),e}setX(t,e){return this.normalized&&(e=this._normalize(e)),this.array[t*this.itemSize]=e,this}getY(t){let e=this.array[t*this.itemSize+1];return this.normalized&&(e=this._denormalize(e)),e}setY(t,e){return this.normalized&&(e=this._normalize(e)),this.array[t*this.itemSize+1]=e,this}getZ(t){let e=this.array[t*this.itemSize+2];return this.normalized&&(e=this._denormalize(e)),e}setZ(t,e){return this.normalized&&(e=this._normalize(e)),this.array[t*this.itemSize+2]=e,this}getW(t){let e=this.array[t*this.itemSize+3];return this.normalized&&(e=this._denormalize(e)),e}setW(t,e){return this.normalized&&(e=this._normalize(e)),this.array[t*this.itemSize+3]=e,this}setXY(t,e,n){return t*=this.itemSize,this.normalized&&(e=this._normalize(e),n=this._normalize(n)),this.array[t+0]=e,this.array[t+1]=n,this}setXYZ(t,e,n,s){return t*=this.itemSize,this.normalized&&(e=this._normalize(e),n=this._normalize(n),s=this._normalize(s)),this.array[t+0]=e,this.array[t+1]=n,this.array[t+2]=s,this}setXYZW(t,e,n,s,a){return t*=this.itemSize,this.normalized&&(e=this._normalize(e),n=this._normalize(n),s=this._normalize(s),a=this._normalize(a)),this.array[t+0]=e,this.array[t+1]=n,this.array[t+2]=s,this.array[t+3]=a,this}onUpload(t){return this.onUploadCallback=t,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const t={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return t.name=this.name,t.usage=this.usage,t.gpuType=this.gpuType,t}dispose(){this.dispatchEvent({type:"dispose"})}_denormalize(t){const e=this._normalizationScale;return e!==void 0?Math.max(t/e,-1):hd(t,this.array)}_normalize(t){const e=this._normalizationScale;return e!==void 0?Math.round(t*e):ud(t,this.array)}}class Cf extends Ne{constructor(t,e,n){super(new Uint16Array(t),e,n)}}class Pf extends Ne{constructor(t,e,n){super(new Uint32Array(t),e,n)}}class se extends Ne{constructor(t,e,n){super(new Float32Array(t),e,n)}}const m0=new Ms,fa=new D,_l=new D;class Ss{constructor(t=new D,e=-1){this.isSphere=!0,this.center=t,this.radius=e}set(t,e){return this.center.copy(t),this.radius=e,this}setFromPoints(t,e){const n=this.center;e!==void 0?n.copy(e):m0.setFromPoints(t).getCenter(n);let s=0;for(let a=0,r=t.length;a<r;a++)s=Math.max(s,n.distanceToSquared(t[a]));return this.radius=Math.sqrt(s),this}copy(t){return this.center.copy(t.center),this.radius=t.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(t){return t.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(t){return t.distanceTo(this.center)-this.radius}intersectsSphere(t){const e=this.radius+t.radius;return t.center.distanceToSquared(this.center)<=e*e}intersectsBox(t){return t.intersectsSphere(this)}intersectsPlane(t){return Math.abs(t.distanceToPoint(this.center))<=this.radius}clampPoint(t,e){const n=this.center.distanceToSquared(t);return e.copy(t),n>this.radius*this.radius&&(e.sub(this.center).normalize(),e.multiplyScalar(this.radius).add(this.center)),e}getBoundingBox(t){return this.isEmpty()?(t.makeEmpty(),t):(t.set(this.center,this.center),t.expandByScalar(this.radius),t)}applyMatrix4(t){return this.center.applyMatrix4(t),this.radius=this.radius*t.getMaxScaleOnAxis(),this}translate(t){return this.center.add(t),this}expandByPoint(t){if(this.isEmpty())return this.center.copy(t),this.radius=0,this;fa.subVectors(t,this.center);const e=fa.lengthSq();if(e>this.radius*this.radius){const n=Math.sqrt(e),s=(n-this.radius)*.5;this.center.addScaledVector(fa,s/n),this.radius+=s}return this}union(t){return t.isEmpty()?this:this.isEmpty()?(this.copy(t),this):(this.center.equals(t.center)===!0?this.radius=Math.max(this.radius,t.radius):(_l.subVectors(t.center,this.center).setLength(t.radius),this.expandByPoint(fa.copy(t.center).add(_l)),this.expandByPoint(fa.copy(t.center).sub(_l))),this)}equals(t){return t.center.equals(this.center)&&t.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(t){return this.radius=t.radius,this.center.fromArray(t.center),this}}let g0=0;const Nn=new ee,Ml=new Ie,Us=new D,Mn=new Ms,pa=new Ms,Ge=new D;class ge extends _s{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:g0++}),this.uuid=es(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.indirectOffset=0,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={},this._transformed=!1}getIndex(){return this.index}setIndex(t){return Array.isArray(t)?this.index=new(Fm(t)?Pf:Cf)(t,1):this.index=t,this}setIndirect(t,e=0){return this.indirect=t,this.indirectOffset=e,this}getIndirect(){return this.indirect}getAttribute(t){return this.attributes[t]}setAttribute(t,e){return this.attributes[t]=e,this}deleteAttribute(t){return delete this.attributes[t],this}hasAttribute(t){return this.attributes[t]!==void 0}addGroup(t,e,n=0){this.groups.push({start:t,count:e,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(t,e){this.drawRange.start=t,this.drawRange.count=e}applyMatrix4(t){const e=this.attributes.position;e!==void 0&&(e.applyMatrix4(t),e.needsUpdate=!0);const n=this.attributes.normal;if(n!==void 0){const a=new Bt().getNormalMatrix(t);n.applyNormalMatrix(a),n.needsUpdate=!0}const s=this.attributes.tangent;return s!==void 0&&(s.transformDirection(t),s.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this._transformed=!0,this}applyQuaternion(t){return Nn.makeRotationFromQuaternion(t),this.applyMatrix4(Nn),this}rotateX(t){return Nn.makeRotationX(t),this.applyMatrix4(Nn),this}rotateY(t){return Nn.makeRotationY(t),this.applyMatrix4(Nn),this}rotateZ(t){return Nn.makeRotationZ(t),this.applyMatrix4(Nn),this}translate(t,e,n){return Nn.makeTranslation(t,e,n),this.applyMatrix4(Nn),this}scale(t,e,n){return Nn.makeScale(t,e,n),this.applyMatrix4(Nn),this}lookAt(t){return Ml.lookAt(t),Ml.updateMatrix(),this.applyMatrix4(Ml.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Us).negate(),this.translate(Us.x,Us.y,Us.z),this}setFromPoints(t){const e=this.getAttribute("position");if(e===void 0){const n=[];for(let s=0,a=t.length;s<a;s++){const r=t[s];n.push(r.x,r.y,r.z||0)}this.setAttribute("position",new se(n,3))}else{const n=Math.min(t.length,e.count);for(let s=0;s<n;s++){const a=t[s];e.setXYZ(s,a.x,a.y,a.z||0)}t.length>e.count&&Ut("BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),e.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new Ms);const t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){ie("BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new D(-1/0,-1/0,-1/0),new D(1/0,1/0,1/0));return}if(t!==void 0){if(this.boundingBox.setFromBufferAttribute(t),e)for(let n=0,s=e.length;n<s;n++){const a=e[n];Mn.setFromBufferAttribute(a),this.morphTargetsRelative?(Ge.addVectors(this.boundingBox.min,Mn.min),this.boundingBox.expandByPoint(Ge),Ge.addVectors(this.boundingBox.max,Mn.max),this.boundingBox.expandByPoint(Ge)):(this.boundingBox.expandByPoint(Mn.min),this.boundingBox.expandByPoint(Mn.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&ie('BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new Ss);const t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){ie("BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new D,1/0);return}if(t){const n=this.boundingSphere.center;if(Mn.setFromBufferAttribute(t),e)for(let a=0,r=e.length;a<r;a++){const o=e[a];pa.setFromBufferAttribute(o),this.morphTargetsRelative?(Ge.addVectors(Mn.min,pa.min),Mn.expandByPoint(Ge),Ge.addVectors(Mn.max,pa.max),Mn.expandByPoint(Ge)):(Mn.expandByPoint(pa.min),Mn.expandByPoint(pa.max))}Mn.getCenter(n);let s=0;for(let a=0,r=t.count;a<r;a++)Ge.fromBufferAttribute(t,a),s=Math.max(s,n.distanceToSquared(Ge));if(e)for(let a=0,r=e.length;a<r;a++){const o=e[a],l=this.morphTargetsRelative;for(let c=0,d=o.count;c<d;c++)Ge.fromBufferAttribute(o,c),l&&(Us.fromBufferAttribute(t,c),Ge.add(Us)),s=Math.max(s,n.distanceToSquared(Ge))}this.boundingSphere.radius=Math.sqrt(s),isNaN(this.boundingSphere.radius)&&ie('BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const t=this.index,e=this.attributes;if(t===null||e.position===void 0||e.normal===void 0||e.uv===void 0){ie("BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const n=e.position,s=e.normal,a=e.uv;let r=this.getAttribute("tangent");(r===void 0||r.count!==n.count)&&(r=new Ne(new Float32Array(4*n.count),4),this.setAttribute("tangent",r));const o=[],l=[],c=new Uint8Array(n.count);for(let P=0;P<n.count;P++)o[P]=new D,l[P]=new D;const d=new D,h=new D,u=new D,f=new It,g=new It,x=new It,m=new D,p=new D;function y(P,R,N){c[P]=c[R]=c[N]=1,d.fromBufferAttribute(n,P),h.fromBufferAttribute(n,R),u.fromBufferAttribute(n,N),f.fromBufferAttribute(a,P),g.fromBufferAttribute(a,R),x.fromBufferAttribute(a,N),h.sub(d),u.sub(d),g.sub(f),x.sub(f);const F=1/(g.x*x.y-x.x*g.y);isFinite(F)&&(m.copy(h).multiplyScalar(x.y).addScaledVector(u,-g.y).multiplyScalar(F),p.copy(u).multiplyScalar(g.x).addScaledVector(h,-x.x).multiplyScalar(F),o[P].add(m),o[R].add(m),o[N].add(m),l[P].add(p),l[R].add(p),l[N].add(p))}let A=this.groups;A.length===0&&(A=[{start:0,count:t.count}]);for(let P=0,R=A.length;P<R;++P){const N=A[P],F=N.start,H=N.count;for(let L=F,$=F+H;L<$;L+=3)y(t.getX(L+0),t.getX(L+1),t.getX(L+2))}const b=new D,w=new D,E=new D,v=new D;function S(P){E.fromBufferAttribute(s,P),v.copy(E);const R=o[P];b.copy(R),b.sub(E.multiplyScalar(E.dot(R))).normalize(),w.crossVectors(v,R);const F=w.dot(l[P])<0?-1:1;r.setXYZW(P,b.x,b.y,b.z,F)}for(let P=0,R=n.count;P<R;++P)c[P]&&S(P);this._transformed=!0}computeVertexNormals(){const t=this.index,e=this.getAttribute("position");if(e!==void 0){let n=this.getAttribute("normal");if(n===void 0||n.count!==e.count)n=new Ne(new Float32Array(e.count*3),3),this.setAttribute("normal",n);else for(let u=0,f=n.count;u<f;u++)n.setXYZ(u,0,0,0);const s=new D,a=new D,r=new D,o=new D,l=new D,c=new D,d=new D,h=new D;if(t)for(let u=0,f=t.count;u<f;u+=3){const g=t.getX(u+0),x=t.getX(u+1),m=t.getX(u+2);s.fromBufferAttribute(e,g),a.fromBufferAttribute(e,x),r.fromBufferAttribute(e,m),d.subVectors(r,a),h.subVectors(s,a),d.cross(h),o.fromBufferAttribute(n,g),l.fromBufferAttribute(n,x),c.fromBufferAttribute(n,m),o.add(d),l.add(d),c.add(d),n.setXYZ(g,o.x,o.y,o.z),n.setXYZ(x,l.x,l.y,l.z),n.setXYZ(m,c.x,c.y,c.z)}else for(let u=0,f=e.count;u<f;u+=3)s.fromBufferAttribute(e,u+0),a.fromBufferAttribute(e,u+1),r.fromBufferAttribute(e,u+2),d.subVectors(r,a),h.subVectors(s,a),d.cross(h),n.setXYZ(u+0,d.x,d.y,d.z),n.setXYZ(u+1,d.x,d.y,d.z),n.setXYZ(u+2,d.x,d.y,d.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){const t=this.attributes.normal;for(let e=0,n=t.count;e<n;e++)Ge.fromBufferAttribute(t,e),Ge.normalize(),t.setXYZ(e,Ge.x,Ge.y,Ge.z)}toNonIndexed(){function t(o,l){const c=o.array,d=o.itemSize,h=o.normalized,u=new c.constructor(l.length*d);let f=0,g=0;for(let x=0,m=l.length;x<m;x++){o.isInterleavedBufferAttribute?f=l[x]*o.data.stride+o.offset:f=l[x]*d;for(let p=0;p<d;p++)u[g++]=c[f++]}return new Ne(u,d,h)}if(this.index===null)return Ut("BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const e=new ge,n=this.index.array,s=this.attributes;for(const o in s){const l=s[o],c=t(l,n);e.setAttribute(o,c)}const a=this.morphAttributes;for(const o in a){const l=[],c=a[o];for(let d=0,h=c.length;d<h;d++){const u=c[d],f=t(u,n);l.push(f)}e.morphAttributes[o]=l}e.morphTargetsRelative=this.morphTargetsRelative;const r=this.groups;for(let o=0,l=r.length;o<l;o++){const c=r[o];e.addGroup(c.start,c.count,c.materialIndex)}return e}toJSON(){const t={metadata:{version:4.7,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(t.uuid=this.uuid,t.type=this.parameters!==void 0&&this._transformed===!0?"BufferGeometry":this.type,t.name=this.name,Object.keys(this.userData).length>0&&(t.userData=this.userData),this.parameters!==void 0&&this._transformed!==!0){const l=this.parameters;for(const c in l)l[c]!==void 0&&(t[c]=l[c]);return t}t.data={attributes:{}};const e=this.index;e!==null&&(t.data.index={type:e.array.constructor.name,array:Array.prototype.slice.call(e.array)});const n=this.attributes;for(const l in n){const c=n[l];t.data.attributes[l]=c.toJSON(t.data)}const s={};let a=!1;for(const l in this.morphAttributes){const c=this.morphAttributes[l],d=[];for(let h=0,u=c.length;h<u;h++){const f=c[h];d.push(f.toJSON(t.data))}d.length>0&&(s[l]=d,a=!0)}a&&(t.data.morphAttributes=s,t.data.morphTargetsRelative=this.morphTargetsRelative);const r=this.groups;r.length>0&&(t.data.groups=JSON.parse(JSON.stringify(r)));const o=this.boundingSphere;return o!==null&&(t.data.boundingSphere=o.toJSON()),t}clone(){return new this.constructor().copy(this)}copy(t){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const e={};this.name=t.name;const n=t.index;n!==null&&this.setIndex(n.clone());const s=t.attributes;for(const c in s){const d=s[c];this.setAttribute(c,d.clone(e))}const a=t.morphAttributes;for(const c in a){const d=[],h=a[c];for(let u=0,f=h.length;u<f;u++)d.push(h[u].clone(e));this.morphAttributes[c]=d}this.morphTargetsRelative=t.morphTargetsRelative;const r=t.groups;for(let c=0,d=r.length;c<d;c++){const h=r[c];this.addGroup(h.start,h.count,h.materialIndex)}const o=t.boundingBox;o!==null&&(this.boundingBox=o.clone());const l=t.boundingSphere;return l!==null&&(this.boundingSphere=l.clone()),this.drawRange.start=t.drawRange.start,this.drawRange.count=t.drawRange.count,this.userData=t.userData,this._transformed=t._transformed,this}dispose(){this.dispatchEvent({type:"dispose"})}}class v0{constructor(t,e){this.isInterleavedBuffer=!0,this.array=t,this.stride=e,this.count=t!==void 0?t.length/e:0,this.usage=wf,this.updateRanges=[],this.version=0,this.uuid=es()}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}setUsage(t){return this.usage=t,this}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.array=new t.array.constructor(t.array),this.count=t.count,this.stride=t.stride,this.usage=t.usage,this}copyAt(t,e,n){t*=this.stride,n*=e.stride;for(let s=0,a=this.stride;s<a;s++)this.array[t+s]=e.array[n+s];return this}set(t,e=0){return this.array.set(t,e),this}clone(t){t.arrayBuffers===void 0&&(t.arrayBuffers={});const e=dh(this.array);t.arrayBuffers[e]===void 0&&(t.arrayBuffers[e]=this.array.slice(0).buffer);const n=new this.array.constructor(t.arrayBuffers[e]),s=new this.constructor(n,this.stride);return s.setUsage(this.usage),s}onUpload(t){return this.onUploadCallback=t,this}toJSON(t){t.arrayBuffers===void 0&&(t.arrayBuffers={});const e=dh(this.array);t.arrayBuffers[e]===void 0&&(t.arrayBuffers[e]=Array.from(new Uint32Array(this.array.slice(0).buffer)));const n={uuid:this.uuid,buffer:e,type:this.array.constructor.name,stride:this.stride};return n.usage=this.usage,n}}function dh(i){return i.buffer._uuid===void 0&&(i.buffer._uuid=es()),i.byteOffset===0&&i.byteLength===i.buffer.byteLength?i.buffer._uuid:i.buffer._uuid+":"+i.byteOffset+":"+i.byteLength}const hn=new D;class fo{constructor(t,e,n,s=!1){this.isInterleavedBufferAttribute=!0,this.name="",this.data=t,this.itemSize=e,this.offset=n,this.normalized=s,this._normalizationScale=t!==void 0?Oo(t.array):void 0}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(t){this.data.needsUpdate=t}applyMatrix4(t){for(let e=0,n=this.data.count;e<n;e++)hn.fromBufferAttribute(this,e),hn.applyMatrix4(t),this.setXYZ(e,hn.x,hn.y,hn.z);return this}applyNormalMatrix(t){for(let e=0,n=this.count;e<n;e++)hn.fromBufferAttribute(this,e),hn.applyNormalMatrix(t),this.setXYZ(e,hn.x,hn.y,hn.z);return this}transformDirection(t){for(let e=0,n=this.count;e<n;e++)hn.fromBufferAttribute(this,e),hn.transformDirection(t),this.setXYZ(e,hn.x,hn.y,hn.z);return this}getComponent(t,e){let n=this.array[t*this.data.stride+this.offset+e];return this.normalized&&(n=this._denormalize(n)),n}setComponent(t,e,n){return this.normalized&&(n=this._normalize(n)),this.data.array[t*this.data.stride+this.offset+e]=n,this}setX(t,e){return this.normalized&&(e=this._normalize(e)),this.data.array[t*this.data.stride+this.offset]=e,this}setY(t,e){return this.normalized&&(e=this._normalize(e)),this.data.array[t*this.data.stride+this.offset+1]=e,this}setZ(t,e){return this.normalized&&(e=this._normalize(e)),this.data.array[t*this.data.stride+this.offset+2]=e,this}setW(t,e){return this.normalized&&(e=this._normalize(e)),this.data.array[t*this.data.stride+this.offset+3]=e,this}getX(t){let e=this.data.array[t*this.data.stride+this.offset];return this.normalized&&(e=this._denormalize(e)),e}getY(t){let e=this.data.array[t*this.data.stride+this.offset+1];return this.normalized&&(e=this._denormalize(e)),e}getZ(t){let e=this.data.array[t*this.data.stride+this.offset+2];return this.normalized&&(e=this._denormalize(e)),e}getW(t){let e=this.data.array[t*this.data.stride+this.offset+3];return this.normalized&&(e=this._denormalize(e)),e}setXY(t,e,n){return t=t*this.data.stride+this.offset,this.normalized&&(e=this._normalize(e),n=this._normalize(n)),this.data.array[t+0]=e,this.data.array[t+1]=n,this}setXYZ(t,e,n,s){return t=t*this.data.stride+this.offset,this.normalized&&(e=this._normalize(e),n=this._normalize(n),s=this._normalize(s)),this.data.array[t+0]=e,this.data.array[t+1]=n,this.data.array[t+2]=s,this}setXYZW(t,e,n,s,a){return t=t*this.data.stride+this.offset,this.normalized&&(e=this._normalize(e),n=this._normalize(n),s=this._normalize(s),a=this._normalize(a)),this.data.array[t+0]=e,this.data.array[t+1]=n,this.data.array[t+2]=s,this.data.array[t+3]=a,this}clone(t){if(t===void 0){ho("InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");const e=[];for(let n=0;n<this.count;n++){const s=n*this.data.stride+this.offset;for(let a=0;a<this.itemSize;a++)e.push(this.data.array[s+a])}return new Ne(new this.array.constructor(e),this.itemSize,this.normalized)}else return t.interleavedBuffers===void 0&&(t.interleavedBuffers={}),t.interleavedBuffers[this.data.uuid]===void 0&&(t.interleavedBuffers[this.data.uuid]=this.data.clone(t)),new fo(t.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(t){if(t===void 0){ho("InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");const e=[];for(let n=0;n<this.count;n++){const s=n*this.data.stride+this.offset;for(let a=0;a<this.itemSize;a++)e.push(this.data.array[s+a])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:e,normalized:this.normalized}}else return t.interleavedBuffers===void 0&&(t.interleavedBuffers={}),t.interleavedBuffers[this.data.uuid]===void 0&&(t.interleavedBuffers[this.data.uuid]=this.data.toJSON(t)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}_denormalize(t){const e=this._normalizationScale;return e!==void 0?Math.max(t/e,-1):hd(t,this.data.array)}_normalize(t){const e=this._normalizationScale;return e!==void 0?Math.round(t*e):ud(t,this.data.array)}}const Sl=new D,x0=new D,y0=new Bt;class Ei{constructor(t=new D(1,0,0),e=0){this.isPlane=!0,this.normal=t,this.constant=e}set(t,e){return this.normal.copy(t),this.constant=e,this}setComponents(t,e,n,s){return this.normal.set(t,e,n),this.constant=s,this}setFromNormalAndCoplanarPoint(t,e){return this.normal.copy(t),this.constant=-e.dot(this.normal),this}setFromCoplanarPoints(t,e,n){const s=Sl.subVectors(n,e).cross(x0.subVectors(t,e)).normalize();return this.setFromNormalAndCoplanarPoint(s,t),this}copy(t){return this.normal.copy(t.normal),this.constant=t.constant,this}normalize(){const t=1/this.normal.length();return this.normal.multiplyScalar(t),this.constant*=t,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(t){return this.normal.dot(t)+this.constant}distanceToSphere(t){return this.distanceToPoint(t.center)-t.radius}projectPoint(t,e){return e.copy(t).addScaledVector(this.normal,-this.distanceToPoint(t))}intersectLine(t,e,n=!0){const s=t.delta(Sl),a=this.normal.dot(s);if(a===0)return this.distanceToPoint(t.start)===0?e.copy(t.start):null;const r=-(t.start.dot(this.normal)+this.constant)/a;return n===!0&&(r<0||r>1)?null:e.copy(t.start).addScaledVector(s,r)}intersectsLine(t){const e=this.distanceToPoint(t.start),n=this.distanceToPoint(t.end);return e<0&&n>0||n<0&&e>0}intersectsBox(t){return t.intersectsPlane(this)}intersectsSphere(t){return t.intersectsPlane(this)}coplanarPoint(t){return t.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(t,e){const n=e||y0.getNormalMatrix(t),s=this.coplanarPoint(Sl).applyMatrix4(t),a=this.normal.applyMatrix3(n).normalize();return this.constant=-s.dot(a),this}translate(t){return this.constant-=t.dot(this.normal),this}equals(t){return t.normal.equals(this.normal)&&t.constant===this.constant}clone(){return new this.constructor().copy(this)}toJSON(){return{normal:this.normal.toArray(),constant:this.constant}}fromJSON(t){return this.normal.fromArray(t.normal),this.constant=t.constant,this}}let b0=0;class Ui extends _s{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:b0++}),this.uuid=es(),this.name="",this.type="Material",this.blending=Ia,this.side=ps,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=rf,this.blendDst=of,this.blendEquation=Vs,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new Rt(0,0,0),this.blendAlpha=0,this.depthFunc=ka,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=Pm,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=al,this.stencilZFail=al,this.stencilZPass=al,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(t){this._alphaTest>0!=t>0&&this.version++,this._alphaTest=t}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(t){if(t!==void 0)for(const e in t){const n=t[e];if(n===void 0){Ut(`Material: parameter '${e}' has value of undefined.`);continue}const s=this[e];if(s===void 0){Ut(`Material: '${e}' is not a property of THREE.${this.type}.`);continue}s&&s.isColor?s.set(n):s&&s.isVector2&&n&&n.isVector2||s&&s.isEuler&&n&&n.isEuler||s&&s.isVector3&&n&&n.isVector3?s.copy(n):this[e]=n}}toJSON(t){const e=t===void 0||typeof t=="string";e&&(t={textures:{},images:{}});const n={metadata:{version:4.7,type:"Material",generator:"Material.toJSON"}};n.uuid=this.uuid,n.type=this.type,n.blending=this.blending,n.side=this.side,n.shadowSide=this.shadowSide,n.vertexColors=this.vertexColors,n.opacity=this.opacity,n.transparent=this.transparent,n.blendSrc=this.blendSrc,n.blendDst=this.blendDst,n.blendEquation=this.blendEquation,n.blendSrcAlpha=this.blendSrcAlpha,n.blendDstAlpha=this.blendDstAlpha,n.blendEquationAlpha=this.blendEquationAlpha,n.blendColor=this.blendColor.getHex(),n.blendAlpha=this.blendAlpha,n.depthFunc=this.depthFunc,n.depthTest=this.depthTest,n.depthWrite=this.depthWrite,n.colorWrite=this.colorWrite,n.clipIntersection=this.clipIntersection,n.clipShadows=this.clipShadows,n.stencilWriteMask=this.stencilWriteMask,n.stencilFunc=this.stencilFunc,n.stencilRef=this.stencilRef,n.stencilFuncMask=this.stencilFuncMask,n.stencilFail=this.stencilFail,n.stencilZFail=this.stencilZFail,n.stencilZPass=this.stencilZPass,n.stencilWrite=this.stencilWrite,n.polygonOffset=this.polygonOffset,n.polygonOffsetFactor=this.polygonOffsetFactor,n.polygonOffsetUnits=this.polygonOffsetUnits,n.dithering=this.dithering,n.alphaTest=this.alphaTest,n.alphaHash=this.alphaHash,n.alphaToCoverage=this.alphaToCoverage,n.premultipliedAlpha=this.premultipliedAlpha,n.forceSinglePass=this.forceSinglePass,n.allowOverride=this.allowOverride,n.visible=this.visible,n.toneMapped=this.toneMapped,n.name=this.name,this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.diffuseRoughness!==void 0&&(n.diffuseRoughness=this.diffuseRoughness),this.diffuseRoughnessMap&&this.diffuseRoughnessMap.isTexture&&(n.diffuseRoughnessMap=this.diffuseRoughnessMap.toJSON(t).uuid),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(t).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(t).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(t).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.sheenColorMap&&this.sheenColorMap.isTexture&&(n.sheenColorMap=this.sheenColorMap.toJSON(t).uuid),this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture&&(n.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(t).uuid),this.dispersion!==void 0&&(n.dispersion=this.dispersion),this.retroreflectivity!==void 0&&(n.retroreflectivity=this.retroreflectivity),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessMinimum!==void 0&&(n.iridescenceThicknessMinimum=this.iridescenceThicknessMinimum),this.iridescenceThicknessMaximum!==void 0&&(n.iridescenceThicknessMaximum=this.iridescenceThicknessMaximum),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(t).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(t).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(t).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(t).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(t).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(t).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(t).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(t).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(t).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(t).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(t).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(t).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(t).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(t).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(t).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(t).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(t).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(t).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapRotation!==void 0&&(n.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(t).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(t).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(t).uuid),this.attenuationDistance!==void 0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),Array.isArray(this.clippingPlanes)&&this.clippingPlanes.length>0&&(n.clippingPlanes=this.clippingPlanes.map(a=>a.toJSON())),this.rotation!==void 0&&(n.rotation=this.rotation),this.depthPacking!==void 0&&(n.depthPacking=this.depthPacking),this.linewidth!==void 0&&(n.linewidth=this.linewidth),this.linecap!==void 0&&(n.linecap=this.linecap),this.linejoin!==void 0&&(n.linejoin=this.linejoin),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.wireframe!==void 0&&(n.wireframe=this.wireframe),this.wireframeLinewidth!==void 0&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!==void 0&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!==void 0&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading!==void 0&&(n.flatShading=this.flatShading),this.fog!==void 0&&(n.fog=this.fog),Object.keys(this.userData).length>0&&(n.userData=this.userData);function s(a){const r=[];for(const o in a){const l=a[o];delete l.metadata,r.push(l)}return r}if(e){const a=s(t.textures),r=s(t.images);a.length>0&&(n.textures=a),r.length>0&&(n.images=r)}return n}fromJSON(t,e){if(t.uuid!==void 0&&(this.uuid=t.uuid),t.name!==void 0&&(this.name=t.name),t.color!==void 0&&this.color!==void 0&&this.color.setHex(t.color),t.roughness!==void 0&&(this.roughness=t.roughness),t.metalness!==void 0&&(this.metalness=t.metalness),t.sheen!==void 0&&(this.sheen=t.sheen),t.sheenColor!==void 0&&(this.sheenColor=new Rt().setHex(t.sheenColor)),t.sheenRoughness!==void 0&&(this.sheenRoughness=t.sheenRoughness),t.emissive!==void 0&&this.emissive!==void 0&&this.emissive.setHex(t.emissive),t.specular!==void 0&&this.specular!==void 0&&this.specular.setHex(t.specular),t.specularIntensity!==void 0&&(this.specularIntensity=t.specularIntensity),t.specularColor!==void 0&&this.specularColor!==void 0&&this.specularColor.setHex(t.specularColor),t.shininess!==void 0&&(this.shininess=t.shininess),t.clearcoat!==void 0&&(this.clearcoat=t.clearcoat),t.clearcoatRoughness!==void 0&&(this.clearcoatRoughness=t.clearcoatRoughness),t.diffuseRoughness!==void 0&&(this.diffuseRoughness=t.diffuseRoughness),t.dispersion!==void 0&&(this.dispersion=t.dispersion),t.retroreflectivity!==void 0&&(this.retroreflectivity=t.retroreflectivity),t.iridescence!==void 0&&(this.iridescence=t.iridescence),t.iridescenceIOR!==void 0&&(this.iridescenceIOR=t.iridescenceIOR),t.iridescenceThicknessMinimum!==void 0&&(this.iridescenceThicknessMinimum=t.iridescenceThicknessMinimum),t.iridescenceThicknessMaximum!==void 0&&(this.iridescenceThicknessMaximum=t.iridescenceThicknessMaximum),t.iridescenceThicknessRange!==void 0&&(this.iridescenceThicknessMinimum=t.iridescenceThicknessRange[0],this.iridescenceThicknessMaximum=t.iridescenceThicknessRange[1]),t.transmission!==void 0&&(this.transmission=t.transmission),t.thickness!==void 0&&(this.thickness=t.thickness),t.attenuationDistance!==void 0&&(this.attenuationDistance=t.attenuationDistance),t.attenuationColor!==void 0&&this.attenuationColor!==void 0&&this.attenuationColor.setHex(t.attenuationColor),t.anisotropy!==void 0&&(this.anisotropy=t.anisotropy),t.anisotropyRotation!==void 0&&(this.anisotropyRotation=t.anisotropyRotation),t.fog!==void 0&&(this.fog=t.fog),t.flatShading!==void 0&&(this.flatShading=t.flatShading),t.blending!==void 0&&(this.blending=t.blending),t.combine!==void 0&&(this.combine=t.combine),t.side!==void 0&&(this.side=t.side),t.shadowSide!==void 0&&(this.shadowSide=t.shadowSide),t.opacity!==void 0&&(this.opacity=t.opacity),t.transparent!==void 0&&(this.transparent=t.transparent),t.alphaTest!==void 0&&(this.alphaTest=t.alphaTest),t.alphaHash!==void 0&&(this.alphaHash=t.alphaHash),t.depthFunc!==void 0&&(this.depthFunc=t.depthFunc),t.depthTest!==void 0&&(this.depthTest=t.depthTest),t.depthWrite!==void 0&&(this.depthWrite=t.depthWrite),t.colorWrite!==void 0&&(this.colorWrite=t.colorWrite),t.clippingPlanes!==void 0&&(this.clippingPlanes=t.clippingPlanes.map(n=>new Ei().fromJSON(n))),t.clipIntersection!==void 0&&(this.clipIntersection=t.clipIntersection),t.clipShadows!==void 0&&(this.clipShadows=t.clipShadows),t.depthPacking!==void 0&&(this.depthPacking=t.depthPacking),t.blendSrc!==void 0&&(this.blendSrc=t.blendSrc),t.blendDst!==void 0&&(this.blendDst=t.blendDst),t.blendEquation!==void 0&&(this.blendEquation=t.blendEquation),t.blendSrcAlpha!==void 0&&(this.blendSrcAlpha=t.blendSrcAlpha),t.blendDstAlpha!==void 0&&(this.blendDstAlpha=t.blendDstAlpha),t.blendEquationAlpha!==void 0&&(this.blendEquationAlpha=t.blendEquationAlpha),t.blendColor!==void 0&&this.blendColor!==void 0&&this.blendColor.setHex(t.blendColor),t.blendAlpha!==void 0&&(this.blendAlpha=t.blendAlpha),t.stencilWriteMask!==void 0&&(this.stencilWriteMask=t.stencilWriteMask),t.stencilFunc!==void 0&&(this.stencilFunc=t.stencilFunc),t.stencilRef!==void 0&&(this.stencilRef=t.stencilRef),t.stencilFuncMask!==void 0&&(this.stencilFuncMask=t.stencilFuncMask),t.stencilFail!==void 0&&(this.stencilFail=t.stencilFail),t.stencilZFail!==void 0&&(this.stencilZFail=t.stencilZFail),t.stencilZPass!==void 0&&(this.stencilZPass=t.stencilZPass),t.stencilWrite!==void 0&&(this.stencilWrite=t.stencilWrite),t.wireframe!==void 0&&(this.wireframe=t.wireframe),t.wireframeLinewidth!==void 0&&(this.wireframeLinewidth=t.wireframeLinewidth),t.wireframeLinecap!==void 0&&(this.wireframeLinecap=t.wireframeLinecap),t.wireframeLinejoin!==void 0&&(this.wireframeLinejoin=t.wireframeLinejoin),t.rotation!==void 0&&(this.rotation=t.rotation),t.linewidth!==void 0&&(this.linewidth=t.linewidth),t.linecap!==void 0&&(this.linecap=t.linecap),t.linejoin!==void 0&&(this.linejoin=t.linejoin),t.dashSize!==void 0&&(this.dashSize=t.dashSize),t.gapSize!==void 0&&(this.gapSize=t.gapSize),t.scale!==void 0&&(this.scale=t.scale),t.polygonOffset!==void 0&&(this.polygonOffset=t.polygonOffset),t.polygonOffsetFactor!==void 0&&(this.polygonOffsetFactor=t.polygonOffsetFactor),t.polygonOffsetUnits!==void 0&&(this.polygonOffsetUnits=t.polygonOffsetUnits),t.dithering!==void 0&&(this.dithering=t.dithering),t.alphaToCoverage!==void 0&&(this.alphaToCoverage=t.alphaToCoverage),t.premultipliedAlpha!==void 0&&(this.premultipliedAlpha=t.premultipliedAlpha),t.forceSinglePass!==void 0&&(this.forceSinglePass=t.forceSinglePass),t.allowOverride!==void 0&&(this.allowOverride=t.allowOverride),t.visible!==void 0&&(this.visible=t.visible),t.toneMapped!==void 0&&(this.toneMapped=t.toneMapped),t.userData!==void 0&&(this.userData=t.userData),t.vertexColors!==void 0&&(typeof t.vertexColors=="number"?this.vertexColors=t.vertexColors>0:this.vertexColors=t.vertexColors),t.size!==void 0&&(this.size=t.size),t.sizeAttenuation!==void 0&&(this.sizeAttenuation=t.sizeAttenuation),t.map!==void 0&&(this.map=e[t.map]||null),t.matcap!==void 0&&(this.matcap=e[t.matcap]||null),t.alphaMap!==void 0&&(this.alphaMap=e[t.alphaMap]||null),t.bumpMap!==void 0&&(this.bumpMap=e[t.bumpMap]||null),t.bumpScale!==void 0&&(this.bumpScale=t.bumpScale),t.normalMap!==void 0&&(this.normalMap=e[t.normalMap]||null),t.normalMapType!==void 0&&(this.normalMapType=t.normalMapType),t.normalScale!==void 0){let n=t.normalScale;Array.isArray(n)===!1&&(n=[n,n]),this.normalScale=new It().fromArray(n)}return t.displacementMap!==void 0&&(this.displacementMap=e[t.displacementMap]||null),t.displacementScale!==void 0&&(this.displacementScale=t.displacementScale),t.displacementBias!==void 0&&(this.displacementBias=t.displacementBias),t.roughnessMap!==void 0&&(this.roughnessMap=e[t.roughnessMap]||null),t.metalnessMap!==void 0&&(this.metalnessMap=e[t.metalnessMap]||null),t.emissiveMap!==void 0&&(this.emissiveMap=e[t.emissiveMap]||null),t.emissiveIntensity!==void 0&&(this.emissiveIntensity=t.emissiveIntensity),t.specularMap!==void 0&&(this.specularMap=e[t.specularMap]||null),t.specularIntensityMap!==void 0&&(this.specularIntensityMap=e[t.specularIntensityMap]||null),t.specularColorMap!==void 0&&(this.specularColorMap=e[t.specularColorMap]||null),t.envMap!==void 0&&(this.envMap=e[t.envMap]||null),t.envMapRotation!==void 0&&this.envMapRotation.fromArray(t.envMapRotation),t.envMapIntensity!==void 0&&(this.envMapIntensity=t.envMapIntensity),t.reflectivity!==void 0&&(this.reflectivity=t.reflectivity),t.refractionRatio!==void 0&&(this.refractionRatio=t.refractionRatio),t.lightMap!==void 0&&(this.lightMap=e[t.lightMap]||null),t.lightMapIntensity!==void 0&&(this.lightMapIntensity=t.lightMapIntensity),t.aoMap!==void 0&&(this.aoMap=e[t.aoMap]||null),t.aoMapIntensity!==void 0&&(this.aoMapIntensity=t.aoMapIntensity),t.gradientMap!==void 0&&(this.gradientMap=e[t.gradientMap]||null),t.clearcoatMap!==void 0&&(this.clearcoatMap=e[t.clearcoatMap]||null),t.clearcoatRoughnessMap!==void 0&&(this.clearcoatRoughnessMap=e[t.clearcoatRoughnessMap]||null),t.clearcoatNormalMap!==void 0&&(this.clearcoatNormalMap=e[t.clearcoatNormalMap]||null),t.clearcoatNormalScale!==void 0&&(this.clearcoatNormalScale=new It().fromArray(t.clearcoatNormalScale)),t.diffuseRoughnessMap!==void 0&&(this.diffuseRoughnessMap=e[t.diffuseRoughnessMap]||null),t.iridescenceMap!==void 0&&(this.iridescenceMap=e[t.iridescenceMap]||null),t.iridescenceThicknessMap!==void 0&&(this.iridescenceThicknessMap=e[t.iridescenceThicknessMap]||null),t.transmissionMap!==void 0&&(this.transmissionMap=e[t.transmissionMap]||null),t.thicknessMap!==void 0&&(this.thicknessMap=e[t.thicknessMap]||null),t.anisotropyMap!==void 0&&(this.anisotropyMap=e[t.anisotropyMap]||null),t.sheenColorMap!==void 0&&(this.sheenColorMap=e[t.sheenColorMap]||null),t.sheenRoughnessMap!==void 0&&(this.sheenRoughnessMap=e[t.sheenRoughnessMap]||null),this}clone(){return new this.constructor().copy(this)}copy(t){this.name=t.name,this.blending=t.blending,this.side=t.side,this.vertexColors=t.vertexColors,this.opacity=t.opacity,this.transparent=t.transparent,this.blendSrc=t.blendSrc,this.blendDst=t.blendDst,this.blendEquation=t.blendEquation,this.blendSrcAlpha=t.blendSrcAlpha,this.blendDstAlpha=t.blendDstAlpha,this.blendEquationAlpha=t.blendEquationAlpha,this.blendColor.copy(t.blendColor),this.blendAlpha=t.blendAlpha,this.depthFunc=t.depthFunc,this.depthTest=t.depthTest,this.depthWrite=t.depthWrite,this.stencilWriteMask=t.stencilWriteMask,this.stencilFunc=t.stencilFunc,this.stencilRef=t.stencilRef,this.stencilFuncMask=t.stencilFuncMask,this.stencilFail=t.stencilFail,this.stencilZFail=t.stencilZFail,this.stencilZPass=t.stencilZPass,this.stencilWrite=t.stencilWrite;const e=t.clippingPlanes;let n=null;if(e!==null){const s=e.length;n=new Array(s);for(let a=0;a!==s;++a)n[a]=e[a].clone()}return this.clippingPlanes=n,this.clipIntersection=t.clipIntersection,this.clipShadows=t.clipShadows,this.shadowSide=t.shadowSide,this.colorWrite=t.colorWrite,this.precision=t.precision,this.polygonOffset=t.polygonOffset,this.polygonOffsetFactor=t.polygonOffsetFactor,this.polygonOffsetUnits=t.polygonOffsetUnits,this.dithering=t.dithering,this.alphaTest=t.alphaTest,this.alphaHash=t.alphaHash,this.alphaToCoverage=t.alphaToCoverage,this.premultipliedAlpha=t.premultipliedAlpha,this.forceSinglePass=t.forceSinglePass,this.allowOverride=t.allowOverride,this.visible=t.visible,this.toneMapped=t.toneMapped,this.userData=JSON.parse(JSON.stringify(t.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(t){t===!0&&this.version++}}class po extends Ui{constructor(t){super(),this.isSpriteMaterial=!0,this.type="SpriteMaterial",this.color=new Rt(16777215),this.map=null,this.alphaMap=null,this.rotation=0,this.sizeAttenuation=!0,this.transparent=!0,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.alphaMap=t.alphaMap,this.rotation=t.rotation,this.sizeAttenuation=t.sizeAttenuation,this.fog=t.fog,this}}let Fs;const ma=new D,Os=new D,Bs=new D,ks=new It,ga=new It,Lf=new ee,cr=new D,va=new D,dr=new D,hh=new It,wl=new It,uh=new It;class Lc extends Ie{constructor(t=new po){if(super(),this.isSprite=!0,this.type="Sprite",Fs===void 0){Fs=new ge;const e=new Float32Array([-.5,-.5,0,0,0,.5,-.5,0,1,0,.5,.5,0,1,1,-.5,.5,0,0,1]),n=new v0(e,5);Fs.setIndex([0,1,2,0,2,3]),Fs.setAttribute("position",new fo(n,3,0,!1)),Fs.setAttribute("uv",new fo(n,2,3,!1))}this.geometry=Fs,this.material=t,this.center=new It(.5,.5),this.count=1}intersectsFrustum(t){return t.intersectsSprite(this)}raycast(t,e){t.camera===null&&ie('Sprite: "Raycaster.camera" needs to be set in order to raycast against sprites.'),Os.setFromMatrixScale(this.matrixWorld),Lf.copy(t.camera.matrixWorld),this.modelViewMatrix.multiplyMatrices(t.camera.matrixWorldInverse,this.matrixWorld),Bs.setFromMatrixPosition(this.modelViewMatrix),t.camera.isPerspectiveCamera&&this.material.sizeAttenuation===!1&&Os.multiplyScalar(-Bs.z);const n=this.material.rotation;let s,a;n!==0&&(a=Math.cos(n),s=Math.sin(n));const r=this.center;hr(cr.set(-.5,-.5,0),Bs,r,Os,s,a),hr(va.set(.5,-.5,0),Bs,r,Os,s,a),hr(dr.set(.5,.5,0),Bs,r,Os,s,a),hh.set(0,0),wl.set(1,0),uh.set(1,1);let o=t.ray.intersectTriangle(cr,va,dr,!1,ma);if(o===null&&(hr(va.set(-.5,.5,0),Bs,r,Os,s,a),wl.set(0,1),o=t.ray.intersectTriangle(cr,dr,va,!1,ma),o===null))return;const l=t.ray.origin.distanceTo(ma);l<t.near||l>t.far||e.push({distance:l,point:ma.clone(),uv:wn.getInterpolation(ma,cr,va,dr,hh,wl,uh,new It),face:null,object:this})}copy(t,e){return super.copy(t,e),t.center!==void 0&&this.center.copy(t.center),this.material=t.material,this}toJSON(t){const e=super.toJSON(t);return e.object.center=this.center.toArray(),e}}function hr(i,t,e,n,s,a){ks.subVectors(i,e).addScalar(.5).multiply(n),s!==void 0?(ga.x=a*ks.x-s*ks.y,ga.y=s*ks.x+a*ks.y):ga.copy(ks),i.copy(t),i.x+=ga.x,i.y+=ga.y,i.applyMatrix4(Lf)}const _i=new D,El=new D,ur=new D,fr=new D;class ko{constructor(t=new D,e=new D(0,0,-1)){this.origin=t,this.direction=e}set(t,e){return this.origin.copy(t),this.direction.copy(e),this}copy(t){return this.origin.copy(t.origin),this.direction.copy(t.direction),this}at(t,e){return e.copy(this.origin).addScaledVector(this.direction,t)}lookAt(t){return this.direction.copy(t).sub(this.origin).normalize(),this}recast(t){return this.origin.copy(this.at(t,_i)),this}closestPointToPoint(t,e){e.subVectors(t,this.origin);const n=e.dot(this.direction);return n<0?e.copy(this.origin):e.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(t){return Math.sqrt(this.distanceSqToPoint(t))}distanceSqToPoint(t){const e=_i.subVectors(t,this.origin).dot(this.direction);return e<0?this.origin.distanceToSquared(t):(_i.copy(this.origin).addScaledVector(this.direction,e),_i.distanceToSquared(t))}distanceSqToSegment(t,e,n,s){El.copy(t).add(e).multiplyScalar(.5),ur.copy(e).sub(t).normalize(),fr.copy(this.origin).sub(El);const a=t.distanceTo(e)*.5,r=-this.direction.dot(ur),o=fr.dot(this.direction),l=-fr.dot(ur),c=fr.lengthSq(),d=Math.abs(1-r*r);let h,u,f,g;if(d>0)if(h=r*l-o,u=r*o-l,g=a*d,h>=0)if(u>=-g)if(u<=g){const x=1/d;h*=x,u*=x,f=h*(h+r*u+2*o)+u*(r*h+u+2*l)+c}else u=a,h=Math.max(0,-(r*u+o)),f=-h*h+u*(u+2*l)+c;else u=-a,h=Math.max(0,-(r*u+o)),f=-h*h+u*(u+2*l)+c;else u<=-g?(h=Math.max(0,-(-r*a+o)),u=h>0?-a:Math.min(Math.max(-a,-l),a),f=-h*h+u*(u+2*l)+c):u<=g?(h=0,u=Math.min(Math.max(-a,-l),a),f=u*(u+2*l)+c):(h=Math.max(0,-(r*a+o)),u=h>0?a:Math.min(Math.max(-a,-l),a),f=-h*h+u*(u+2*l)+c);else u=r>0?-a:a,h=Math.max(0,-(r*u+o)),f=-h*h+u*(u+2*l)+c;return n&&n.copy(this.origin).addScaledVector(this.direction,h),s&&s.copy(El).addScaledVector(ur,u),f}intersectSphere(t,e){if(t.radius<0)return null;_i.subVectors(t.center,this.origin);const n=_i.dot(this.direction),s=_i.dot(_i)-n*n,a=t.radius*t.radius;if(s>a)return null;const r=Math.sqrt(a-s),o=n-r,l=n+r;return l<0?null:o<0?this.at(l,e):this.at(o,e)}intersectsSphere(t){return t.radius<0?!1:this.distanceSqToPoint(t.center)<=t.radius*t.radius}distanceToPlane(t){const e=t.normal.dot(this.direction);if(e===0)return t.distanceToPoint(this.origin)===0?0:null;const n=-(this.origin.dot(t.normal)+t.constant)/e;return n>=0?n:null}intersectPlane(t,e){const n=this.distanceToPlane(t);return n===null?null:this.at(n,e)}intersectsPlane(t){const e=t.distanceToPoint(this.origin);return e===0||t.normal.dot(this.direction)*e<0}intersectBox(t,e){let n,s,a,r,o,l;const c=1/this.direction.x,d=1/this.direction.y,h=1/this.direction.z,u=this.origin;return c>=0?(n=(t.min.x-u.x)*c,s=(t.max.x-u.x)*c):(n=(t.max.x-u.x)*c,s=(t.min.x-u.x)*c),d>=0?(a=(t.min.y-u.y)*d,r=(t.max.y-u.y)*d):(a=(t.max.y-u.y)*d,r=(t.min.y-u.y)*d),n>r||a>s||((a>n||isNaN(n))&&(n=a),(r<s||isNaN(s))&&(s=r),h>=0?(o=(t.min.z-u.z)*h,l=(t.max.z-u.z)*h):(o=(t.max.z-u.z)*h,l=(t.min.z-u.z)*h),n>l||o>s)||((o>n||n!==n)&&(n=o),(l<s||s!==s)&&(s=l),s<0)?null:this.at(n>=0?n:s,e)}intersectsBox(t){return this.intersectBox(t,_i)!==null}intersectTriangle(t,e,n,s,a){const r=this.origin,o=this.direction,l=o.x,c=o.y,d=o.z,h=t.x-r.x,u=t.y-r.y,f=t.z-r.z,g=e.x-r.x,x=e.y-r.y,m=e.z-r.z,p=n.x-r.x,y=n.y-r.y,A=n.z-r.z,b=Math.abs(l),w=Math.abs(c),E=Math.abs(d);let v,S,P,R,N,F,H,L,$,X,z,et;if(b>=w&&b>=E?(P=l,F=h,$=g,et=p,l>=0?(v=c,S=d,R=u,N=f,H=x,L=m,X=y,z=A):(v=d,S=c,R=f,N=u,H=m,L=x,X=A,z=y)):w>=E?(P=c,F=u,$=x,et=y,c>=0?(v=d,S=l,R=f,N=h,H=m,L=g,X=A,z=p):(v=l,S=d,R=h,N=f,H=g,L=m,X=p,z=A)):(P=d,F=f,$=m,et=A,d>=0?(v=l,S=c,R=h,N=u,H=g,L=x,X=p,z=y):(v=c,S=l,R=u,N=h,H=x,L=g,X=y,z=p)),P===0)return null;const V=v/P,Q=S/P,nt=1/P,Et=R-V*F,$t=N-Q*F,K=H-V*$,xt=L-Q*$,Mt=X-V*et,Lt=z-Q*et,yt=Mt*xt-Lt*K,Gt=Et*Lt-$t*Mt,Pe=K*$t-xt*Et;if(s){if(yt<0||Gt<0||Pe<0)return null}else if((yt<0||Gt<0||Pe<0)&&(yt>0||Gt>0||Pe>0))return null;const Nt=yt+Gt+Pe;if(Nt===0)return null;const re=nt*(yt*F+Gt*$+Pe*et);return(Nt>0?re<0:re>0)?null:this.at(re/Nt,a)}applyMatrix4(t){return this.origin.applyMatrix4(t),this.direction.transformDirection(t),this}equals(t){return t.origin.equals(this.origin)&&t.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class Me extends Ui{constructor(t){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new Rt(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new zn,this.combine=ed,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.specularMap=t.specularMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapRotation.copy(t.envMapRotation),this.combine=t.combine,this.reflectivity=t.reflectivity,this.refractionRatio=t.refractionRatio,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.fog=t.fog,this}}const fh=new ee,ls=new ko,pr=new Ss,ph=new D,mr=new D,gr=new D,vr=new D,Al=new D,xr=new D,mh=new D,yr=new D;class Pt extends Ie{constructor(t=new ge,e=new Me){super(),this.isMesh=!0,this.type="Mesh",this.geometry=t,this.material=e,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),t.morphTargetInfluences!==void 0?this.morphTargetInfluences=t.morphTargetInfluences.slice():this.morphTargetInfluences=void 0,t.morphTargetDictionary!==void 0?this.morphTargetDictionary=Object.assign({},t.morphTargetDictionary):this.morphTargetDictionary=void 0,this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}updateMorphTargets(){const e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){const s=e[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let a=0,r=s.length;a<r;a++){const o=s[a].name||String(a);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=a}}}}getVertexPosition(t,e){const n=this.geometry,s=n.attributes.position,a=n.morphAttributes.position,r=n.morphTargetsRelative;e.fromBufferAttribute(s,t);const o=this.morphTargetInfluences;if(a&&o){xr.set(0,0,0);for(let l=0,c=a.length;l<c;l++){const d=o[l],h=a[l];d!==0&&(Al.fromBufferAttribute(h,t),r?xr.addScaledVector(Al,d):xr.addScaledVector(Al.sub(e),d))}e.add(xr)}return e}intersectsFrustum(t){return t.intersectsObject(this)}raycast(t,e){const n=this.geometry,s=this.material,a=this.matrixWorld;s!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),pr.copy(n.boundingSphere),pr.applyMatrix4(a),ls.copy(t.ray).recast(t.near),!(pr.containsPoint(ls.origin)===!1&&(ls.intersectSphere(pr,ph)===null||ls.origin.distanceToSquared(ph)>(t.far-t.near)**2))&&(fh.copy(a).invert(),ls.copy(t.ray).applyMatrix4(fh),!(n.boundingBox!==null&&ls.intersectsBox(n.boundingBox)===!1)&&this._computeIntersections(t,e,ls)))}_computeIntersections(t,e,n){let s;const a=this.geometry,r=this.material,o=a.index,l=a.attributes.position,c=a.attributes.uv,d=a.attributes.uv1,h=a.attributes.normal,u=a.groups,f=a.drawRange;if(o!==null)if(Array.isArray(r))for(let g=0,x=u.length;g<x;g++){const m=u[g],p=r[m.materialIndex],y=Math.max(m.start,f.start),A=Math.min(o.count,Math.min(m.start+m.count,f.start+f.count));for(let b=y,w=A;b<w;b+=3){const E=o.getX(b),v=o.getX(b+1),S=o.getX(b+2);s=br(this,p,t,n,c,d,h,E,v,S),s&&(s.faceIndex=Math.floor(b/3),s.face.materialIndex=m.materialIndex,e.push(s))}}else{const g=Math.max(0,f.start),x=Math.min(o.count,f.start+f.count);for(let m=g,p=x;m<p;m+=3){const y=o.getX(m),A=o.getX(m+1),b=o.getX(m+2);s=br(this,r,t,n,c,d,h,y,A,b),s&&(s.faceIndex=Math.floor(m/3),e.push(s))}}else if(l!==void 0)if(Array.isArray(r))for(let g=0,x=u.length;g<x;g++){const m=u[g],p=r[m.materialIndex],y=Math.max(m.start,f.start),A=Math.min(l.count,Math.min(m.start+m.count,f.start+f.count));for(let b=y,w=A;b<w;b+=3){const E=b,v=b+1,S=b+2;s=br(this,p,t,n,c,d,h,E,v,S),s&&(s.faceIndex=Math.floor(b/3),s.face.materialIndex=m.materialIndex,e.push(s))}}else{const g=Math.max(0,f.start),x=Math.min(l.count,f.start+f.count);for(let m=g,p=x;m<p;m+=3){const y=m,A=m+1,b=m+2;s=br(this,r,t,n,c,d,h,y,A,b),s&&(s.faceIndex=Math.floor(m/3),e.push(s))}}}}function _0(i,t,e,n,s,a,r,o){let l;if(t.side===en?l=n.intersectTriangle(r,a,s,!0,o):l=n.intersectTriangle(s,a,r,t.side===ps,o),l===null)return null;yr.copy(o),yr.applyMatrix4(i.matrixWorld);const c=e.ray.origin.distanceTo(yr);return c<e.near||c>e.far?null:{distance:c,point:yr.clone(),object:i}}function br(i,t,e,n,s,a,r,o,l,c){i.getVertexPosition(o,mr),i.getVertexPosition(l,gr),i.getVertexPosition(c,vr);const d=_0(i,t,e,n,mr,gr,vr,mh);if(d){const h=new D;wn.getBarycoord(mh,mr,gr,vr,h),s&&(d.uv=wn.getInterpolatedAttribute(s,o,l,c,h,new It)),a&&(d.uv1=wn.getInterpolatedAttribute(a,o,l,c,h,new It)),r&&(d.normal=wn.getInterpolatedAttribute(r,o,l,c,h,new D),d.normal.dot(n.direction)>0&&d.normal.multiplyScalar(-1));const u={a:o,b:l,c,normal:new D,materialIndex:0};wn.getNormal(mr,gr,vr,u.normal),d.face=u,d.barycoord=h}return d}class Df extends cn{constructor(t=null,e=1,n=1,s,a,r,o,l,c=Qe,d=Qe,h,u){super(null,r,o,l,c,d,s,a,h,u),this.isDataTexture=!0,this.image={data:t,width:e,height:n},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class gh extends Ne{constructor(t,e,n,s=1){super(t,e,n),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=s}copy(t){return super.copy(t),this.meshPerAttribute=t.meshPerAttribute,this}toJSON(){const t=super.toJSON();return t.meshPerAttribute=this.meshPerAttribute,t.isInstancedBufferAttribute=!0,t}}const zs=new ee,vh=new ee,_r=[],xh=new Ms,M0=new ee,xa=new Pt,ya=new Ss;class Mr extends Pt{constructor(t,e,n){super(t,e),this.isInstancedMesh=!0,this.instanceMatrix=new gh(new Float32Array(n*16),16),this.instanceColor=null,this.morphTexture=null,this.count=n,this.boundingBox=null,this.boundingSphere=null;for(let s=0;s<n;s++)this.setMatrixAt(s,M0)}computeBoundingBox(){const t=this.geometry,e=this.count;this.boundingBox===null&&(this.boundingBox=new Ms),t.boundingBox===null&&t.computeBoundingBox(),this.boundingBox.makeEmpty();for(let n=0;n<e;n++)this.getMatrixAt(n,zs),xh.copy(t.boundingBox).applyMatrix4(zs),this.boundingBox.union(xh)}computeBoundingSphere(){const t=this.geometry,e=this.count;this.boundingSphere===null&&(this.boundingSphere=new Ss),t.boundingSphere===null&&t.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let n=0;n<e;n++)this.getMatrixAt(n,zs),ya.copy(t.boundingSphere).applyMatrix4(zs),this.boundingSphere.union(ya)}copy(t,e){return super.copy(t,e),this.instanceMatrix.copy(t.instanceMatrix),this.morphTexture=t.morphTexture!==null?t.morphTexture.clone():null,this.instanceColor=t.instanceColor!==null?t.instanceColor.clone():null,this.count=t.count,this.boundingBox=t.boundingBox!==null?t.boundingBox.clone():null,this.boundingSphere=t.boundingSphere!==null?t.boundingSphere.clone():null,this}getColorAt(t,e){return this.instanceColor===null?e.setRGB(1,1,1):e.fromArray(this.instanceColor.array,t*3)}getMatrixAt(t,e){return e.fromArray(this.instanceMatrix.array,t*16)}getMorphAt(t,e){const n=e.morphTargetInfluences,s=this.morphTexture.source.data.data,a=n.length+1,r=t*a+1;for(let o=0;o<n.length;o++)n[o]=s[r+o]}raycast(t,e){const n=this.matrixWorld,s=this.count;if(xa.geometry=this.geometry,xa.material=this.material,xa.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),ya.copy(this.boundingSphere),ya.applyMatrix4(n),t.ray.intersectsSphere(ya)!==!1))for(let a=0;a<s;a++){this.getMatrixAt(a,zs),vh.multiplyMatrices(n,zs),xa.matrixWorld=vh,xa.raycast(t,_r);for(let r=0,o=_r.length;r<o;r++){const l=_r[r];l.instanceId=a,l.object=this,e.push(l)}_r.length=0}}setColorAt(t,e){return this.instanceColor===null&&(this.instanceColor=new gh(new Float32Array(this.instanceMatrix.count*3).fill(1),3)),e.toArray(this.instanceColor.array,t*3),this}setMatrixAt(t,e){return e.toArray(this.instanceMatrix.array,t*16),this}setMorphAt(t,e){const n=e.morphTargetInfluences,s=n.length+1;this.morphTexture===null&&(this.morphTexture=new Df(new Float32Array(s*this.count),s,this.count,rd,ti));const a=this.morphTexture.source.data.data;let r=0;for(let c=0;c<n.length;c++)r+=n[c];const o=this.geometry.morphTargetsRelative?1:1-r,l=s*t;return a[l]=o,a.set(n,l+1),this}updateMorphTargets(){}dispose(){super.dispose(),this.instanceMatrix.dispose(),this.instanceColor!==null&&this.instanceColor.dispose(),this.morphTexture!==null&&(this.morphTexture.dispose(),this.morphTexture=null)}}const cs=new Ss,S0=new It(.5,.5),Sr=new D;class Va{constructor(t=new Ei,e=new Ei,n=new Ei,s=new Ei,a=new Ei,r=new Ei){this.planes=[t,e,n,s,a,r]}set(t,e,n,s,a,r){const o=this.planes;return o[0].copy(t),o[1].copy(e),o[2].copy(n),o[3].copy(s),o[4].copy(a),o[5].copy(r),this}copy(t){const e=this.planes;for(let n=0;n<6;n++)e[n].copy(t.planes[n]);return this}setFromProjectionMatrix(t,e=ei,n=!1){const s=this.planes,a=t.elements,r=a[0],o=a[1],l=a[2],c=a[3],d=a[4],h=a[5],u=a[6],f=a[7],g=a[8],x=a[9],m=a[10],p=a[11],y=a[12],A=a[13],b=a[14],w=a[15];if(s[0].setComponents(c-r,f-d,p-g,w-y).normalize(),s[1].setComponents(c+r,f+d,p+g,w+y).normalize(),s[2].setComponents(c+o,f+h,p+x,w+A).normalize(),s[3].setComponents(c-o,f-h,p-x,w-A).normalize(),n)s[4].setComponents(l,u,m,b).normalize(),s[5].setComponents(c-l,f-u,p-m,w-b).normalize();else if(s[4].setComponents(c-l,f-u,p-m,w-b).normalize(),e===ei)s[5].setComponents(c+l,f+u,p+m,w+b).normalize();else if(e===Ha)s[5].setComponents(l,u,m,b).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+e);return this}intersectsObject(t){if(t.boundingSphere!==void 0)t.boundingSphere===null&&t.computeBoundingSphere(),cs.copy(t.boundingSphere).applyMatrix4(t.matrixWorld);else{const e=t.geometry;e.boundingSphere===null&&e.computeBoundingSphere(),cs.copy(e.boundingSphere).applyMatrix4(t.matrixWorld)}return this.intersectsSphere(cs)}intersectsSprite(t){cs.center.set(0,0,0);const e=S0.distanceTo(t.center);return cs.radius=.7071067811865476+e,cs.applyMatrix4(t.matrixWorld),this.intersectsSphere(cs)}intersectsSphere(t){const e=this.planes,n=t.center,s=-t.radius;for(let a=0;a<6;a++)if(e[a].distanceToPoint(n)<s)return!1;return!0}intersectsBox(t){const e=this.planes;for(let n=0;n<6;n++){const s=e[n];if(Sr.x=s.normal.x>0?t.max.x:t.min.x,Sr.y=s.normal.y>0?t.max.y:t.min.y,Sr.z=s.normal.z>0?t.max.z:t.min.z,s.distanceToPoint(Sr)<0)return!1}return!0}containsPoint(t){const e=this.planes;for(let n=0;n<6;n++)if(e[n].distanceToPoint(t)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}const yh=new ee;class md{constructor(){this.coordinateSystem=ei,this._frustums=[],this._count=0}setFromArrayCamera(t){const e=t.cameras,n=this._frustums;for(let s=0;s<e.length;s++){const a=e[s];yh.multiplyMatrices(a.projectionMatrix,a.matrixWorldInverse),n[s]===void 0&&(n[s]=new Va),n[s].setFromProjectionMatrix(yh,a.coordinateSystem,a.reversedDepth)}return this._count=e.length,this}getFrustum(t){return this._frustums[t]}intersectsObject(t){const e=this._frustums;for(let n=0;n<this._count;n++)if(e[n].intersectsObject(t))return!0;return!1}intersectsSprite(t){const e=this._frustums;for(let n=0;n<this._count;n++)if(e[n].intersectsSprite(t))return!0;return!1}intersectsSphere(t){const e=this._frustums;for(let n=0;n<this._count;n++)if(e[n].intersectsSphere(t))return!0;return!1}intersectsBox(t){const e=this._frustums;for(let n=0;n<this._count;n++)if(e[n].intersectsBox(t))return!0;return!1}containsPoint(t){const e=this._frustums;for(let n=0;n<this._count;n++)if(e[n].containsPoint(t))return!0;return!1}copy(t){this.coordinateSystem=t.coordinateSystem;const e=this._frustums,n=t._frustums;for(let s=0;s<t._count;s++)e[s]===void 0&&(e[s]=new Va),e[s].copy(n[s]);return this._count=t._count,this}clone(){return new md().copy(this)}}class mo extends Ui{constructor(t){super(),this.isLineBasicMaterial=!0,this.type="LineBasicMaterial",this.color=new Rt(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.linewidth=t.linewidth,this.linecap=t.linecap,this.linejoin=t.linejoin,this.fog=t.fog,this}}const go=new D,vo=new D,bh=new ee,ba=new ko,wr=new Ss,Tl=new D,_h=new D;class If extends Ie{constructor(t=new ge,e=new mo){super(),this.isLine=!0,this.type="Line",this.geometry=t,this.material=e,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),t.morphTargetInfluences!==void 0?this.morphTargetInfluences=t.morphTargetInfluences.slice():this.morphTargetInfluences=void 0,t.morphTargetDictionary!==void 0?this.morphTargetDictionary=Object.assign({},t.morphTargetDictionary):this.morphTargetDictionary=void 0,this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}computeLineDistances(){const t=this.geometry;if(t.index===null){const e=t.attributes.position,n=[0];for(let s=1,a=e.count;s<a;s++)go.fromBufferAttribute(e,s-1),vo.fromBufferAttribute(e,s),n[s]=n[s-1],n[s]+=go.distanceTo(vo);t.setAttribute("lineDistance",new se(n,1))}else Ut("Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}intersectsFrustum(t){return t.intersectsObject(this)}raycast(t,e){const n=this.geometry,s=this.matrixWorld,a=t.params.Line.threshold,r=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),wr.copy(n.boundingSphere),wr.applyMatrix4(s),wr.radius+=a,t.ray.intersectsSphere(wr)===!1)return;bh.copy(s).invert(),ba.copy(t.ray).applyMatrix4(bh);const o=a/((this.scale.x+this.scale.y+this.scale.z)/3),l=o*o,c=this.isLineSegments?2:1,d=n.index,u=n.attributes.position;if(d!==null){const f=Math.max(0,r.start),g=Math.min(d.count,r.start+r.count);for(let x=f,m=g-1;x<m;x+=c){const p=d.getX(x),y=d.getX(x+1),A=Er(this,t,ba,l,p,y,x);A&&e.push(A)}if(this.isLineLoop){const x=d.getX(g-1),m=d.getX(f),p=Er(this,t,ba,l,x,m,g-1);p&&e.push(p)}}else{const f=Math.max(0,r.start),g=Math.min(u.count,r.start+r.count);for(let x=f,m=g-1;x<m;x+=c){const p=Er(this,t,ba,l,x,x+1,x);p&&e.push(p)}if(this.isLineLoop){const x=Er(this,t,ba,l,g-1,f,g-1);x&&e.push(x)}}}updateMorphTargets(){const e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){const s=e[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let a=0,r=s.length;a<r;a++){const o=s[a].name||String(a);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=a}}}}}function Er(i,t,e,n,s,a,r){const o=i.geometry.attributes.position;if(go.fromBufferAttribute(o,s),vo.fromBufferAttribute(o,a),e.distanceSqToSegment(go,vo,Tl,_h)>n)return;Tl.applyMatrix4(i.matrixWorld);const c=t.ray.origin.distanceTo(Tl);if(!(c<t.near||c>t.far))return{distance:c,point:_h.clone().applyMatrix4(i.matrixWorld),index:r,face:null,faceIndex:null,barycoord:null,object:i}}const Mh=new D,Sh=new D;class wh extends If{constructor(t,e){super(t,e),this.isLineSegments=!0,this.type="LineSegments"}computeLineDistances(){const t=this.geometry;if(t.index===null){const e=t.attributes.position,n=[];for(let s=0,a=e.count;s<a;s+=2)Mh.fromBufferAttribute(e,s),Sh.fromBufferAttribute(e,s+1),n[s]=s===0?0:n[s-1],n[s+1]=n[s]+Mh.distanceTo(Sh);t.setAttribute("lineDistance",new se(n,1))}else Ut("LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}}class sa extends Ui{constructor(t){super(),this.isPointsMaterial=!0,this.type="PointsMaterial",this.color=new Rt(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.alphaMap=t.alphaMap,this.size=t.size,this.sizeAttenuation=t.sizeAttenuation,this.fog=t.fog,this}}const Eh=new ee,Dc=new ko,Ar=new Ss,Tr=new D;class Wa extends Ie{constructor(t=new ge,e=new sa){super(),this.isPoints=!0,this.type="Points",this.geometry=t,this.material=e,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),t.morphTargetInfluences!==void 0?this.morphTargetInfluences=t.morphTargetInfluences.slice():this.morphTargetInfluences=void 0,t.morphTargetDictionary!==void 0?this.morphTargetDictionary=Object.assign({},t.morphTargetDictionary):this.morphTargetDictionary=void 0,this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}intersectsFrustum(t){return t.intersectsObject(this)}raycast(t,e){const n=this.geometry,s=this.matrixWorld,a=t.params.Points.threshold,r=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),Ar.copy(n.boundingSphere),Ar.applyMatrix4(s),Ar.radius+=a,t.ray.intersectsSphere(Ar)===!1)return;Eh.copy(s).invert(),Dc.copy(t.ray).applyMatrix4(Eh);const o=a/((this.scale.x+this.scale.y+this.scale.z)/3),l=o*o,c=n.index,h=n.attributes.position;if(c!==null){const u=Math.max(0,r.start),f=Math.min(c.count,r.start+r.count);for(let g=u,x=f;g<x;g++){const m=c.getX(g);Tr.fromBufferAttribute(h,m),Ah(Tr,m,l,s,t,e,this)}}else{const u=Math.max(0,r.start),f=Math.min(h.count,r.start+r.count);for(let g=u,x=f;g<x;g++)Tr.fromBufferAttribute(h,g),Ah(Tr,g,l,s,t,e,this)}}updateMorphTargets(){const e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){const s=e[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let a=0,r=s.length;a<r;a++){const o=s[a].name||String(a);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=a}}}}}function Ah(i,t,e,n,s,a,r){const o=Dc.distanceSqToPoint(i);if(o<e){const l=new D;Dc.closestPointToPoint(i,l),l.applyMatrix4(n);const c=s.ray.origin.distanceTo(l);if(c<s.near||c>s.far)return;a.push({distance:c,distanceToRay:Math.sqrt(o),point:l,index:t,face:null,faceIndex:null,barycoord:null,object:r})}}class Nf extends cn{constructor(t=[],e=na,n,s,a,r,o,l,c,d){super(t,e,n,s,a,r,o,l,c,d),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(t){this.image=t}}class gd extends cn{constructor(t,e,n,s,a,r,o,l,c){super(t,e,n,s,a,r,o,l,c),this.isCanvasTexture=!0,this.needsUpdate=!0}}class aa extends cn{constructor(t,e,n=pi,s,a,r,o=Qe,l=Qe,c,d=Qi,h=1){if(d!==Qi&&d!==Yi)throw new Error("THREE.DepthTexture: format must be either THREE.DepthFormat or THREE.DepthStencilFormat");const u={width:t,height:e,depth:h};super(u,s,a,r,o,l,d,n,c),this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(t){return super.copy(t),this.source=new fd(Object.assign({},t.image)),this.compareFunction=t.compareFunction,this}toJSON(t){const e=super.toJSON(t);return e.compareFunction=this.compareFunction,e}}class Uf extends aa{constructor(t,e=pi,n=na,s,a,r=Qe,o=Qe,l,c=Qi){const d={width:t,height:t,depth:1},h=[d,d,d,d,d,d];super(t,t,e,n,s,a,r,o,l,c),this.image=h,this.isCubeDepthTexture=!0,this.isCubeTexture=!0}get images(){return this.image}set images(t){this.image=t}}class Ff extends cn{constructor(t=null){super(),this.sourceTexture=t,this.isExternalTexture=!0}copy(t){return super.copy(t),this.sourceTexture=t.sourceTexture,this}}class ai extends ge{constructor(t=1,e=1,n=1,s=1,a=1,r=1){super(),this.type="BoxGeometry",this.parameters={width:t,height:e,depth:n,widthSegments:s,heightSegments:a,depthSegments:r};const o=this;s=Math.floor(s),a=Math.floor(a),r=Math.floor(r);const l=[],c=[],d=[],h=[];let u=0,f=0;g("z","y","x",-1,-1,n,e,t,r,a,0),g("z","y","x",1,-1,n,e,-t,r,a,1),g("x","z","y",1,1,t,n,e,s,r,2),g("x","z","y",1,-1,t,n,-e,s,r,3),g("x","y","z",1,-1,t,e,n,s,a,4),g("x","y","z",-1,-1,t,e,-n,s,a,5),this.setIndex(l),this.setAttribute("position",new se(c,3)),this.setAttribute("normal",new se(d,3)),this.setAttribute("uv",new se(h,2));function g(x,m,p,y,A,b,w,E,v,S,P){const R=b/v,N=w/S,F=b/2,H=w/2,L=E/2,$=v+1,X=S+1;let z=0,et=0;const V=new D;for(let Q=0;Q<X;Q++){const nt=Q*N-H;for(let Et=0;Et<$;Et++){const $t=Et*R-F;V[x]=$t*y,V[m]=nt*A,V[p]=L,c.push(V.x,V.y,V.z),V[x]=0,V[m]=0,V[p]=E>0?1:-1,d.push(V.x,V.y,V.z),h.push(Et/v),h.push(1-Q/S),z+=1}}for(let Q=0;Q<S;Q++)for(let nt=0;nt<v;nt++){const Et=u+nt+$*Q,$t=u+nt+$*(Q+1),K=u+(nt+1)+$*(Q+1),xt=u+(nt+1)+$*Q;l.push(Et,$t,xt),l.push($t,K,xt),et+=6}o.addGroup(f,et,P),f+=et,u+=z}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new ai(t.width,t.height,t.depth,t.widthSegments,t.heightSegments,t.depthSegments)}}class zo extends ge{constructor(t=1,e=32,n=0,s=Math.PI*2){super(),this.type="CircleGeometry",this.parameters={radius:t,segments:e,thetaStart:n,thetaLength:s},e=Math.max(3,e);const a=[],r=[],o=[],l=[],c=new D,d=new It;r.push(0,0,0),o.push(0,0,1),l.push(.5,.5);for(let h=0,u=3;h<=e;h++,u+=3){const f=n+h/e*s;c.x=t*Math.cos(f),c.y=t*Math.sin(f),r.push(c.x,c.y,c.z),o.push(0,0,1),d.x=(r[u]/t+1)/2,d.y=(r[u+1]/t+1)/2,l.push(d.x,d.y)}for(let h=1;h<=e;h++)a.push(h,h+1,0);this.setIndex(a),this.setAttribute("position",new se(r,3)),this.setAttribute("normal",new se(o,3)),this.setAttribute("uv",new se(l,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new zo(t.radius,t.segments,t.thetaStart,t.thetaLength)}}class bn extends ge{constructor(t=1,e=1,n=1,s=32,a=1,r=!1,o=0,l=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:t,radiusBottom:e,height:n,radialSegments:s,heightSegments:a,openEnded:r,thetaStart:o,thetaLength:l};const c=this;s=Math.floor(s),a=Math.floor(a);const d=[],h=[],u=[],f=[];let g=0;const x=[],m=n/2;let p=0;y(),r===!1&&(t>0&&A(!0),e>0&&A(!1)),this.setIndex(d),this.setAttribute("position",new se(h,3)),this.setAttribute("normal",new se(u,3)),this.setAttribute("uv",new se(f,2));function y(){const b=new D,w=new D;let E=0;const v=(e-t)/n;for(let S=0;S<=a;S++){const P=[],R=S/a,N=R*(e-t)+t;for(let F=0;F<=s;F++){const H=F/s,L=H*l+o,$=Math.sin(L),X=Math.cos(L);w.x=N*$,w.y=-R*n+m,w.z=N*X,h.push(w.x,w.y,w.z),b.set($,v,X).normalize(),u.push(b.x,b.y,b.z),f.push(H,1-R),P.push(g++)}x.push(P)}for(let S=0;S<s;S++)for(let P=0;P<a;P++){const R=x[P][S],N=x[P+1][S],F=x[P+1][S+1],H=x[P][S+1];(t>0||P!==0)&&(d.push(R,N,H),E+=3),(e>0||P!==a-1)&&(d.push(N,F,H),E+=3)}c.addGroup(p,E,0),p+=E}function A(b){const w=g,E=new It,v=new D;let S=0;const P=b===!0?t:e,R=b===!0?1:-1;for(let F=1;F<=s;F++)h.push(0,m*R,0),u.push(0,R,0),f.push(.5,.5),g++;const N=g;for(let F=0;F<=s;F++){const L=F/s*l+o,$=Math.cos(L),X=Math.sin(L);v.x=P*X,v.y=m*R,v.z=P*$,h.push(v.x,v.y,v.z),u.push(0,R,0),E.x=$*.5+.5,E.y=X*.5*R+.5,f.push(E.x,E.y),g++}for(let F=0;F<s;F++){const H=w+F,L=N+F;b===!0?d.push(L,L+1,H):d.push(L+1,L,H),S+=3}c.addGroup(p,S,b===!0?1:2),p+=S}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new bn(t.radiusTop,t.radiusBottom,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}}class $n extends bn{constructor(t=1,e=1,n=32,s=1,a=!1,r=0,o=Math.PI*2){super(0,t,e,n,s,a,r,o),this.type="ConeGeometry",this.parameters={radius:t,height:e,radialSegments:n,heightSegments:s,openEnded:a,thetaStart:r,thetaLength:o}}static fromJSON(t){return new $n(t.radius,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}}class Ja extends ge{constructor(t=[],e=[],n=1,s=0){super(),this.type="PolyhedronGeometry",this.parameters={vertices:t,indices:e,radius:n,detail:s};const a=[],r=[];o(s),c(n),d(),this.setAttribute("position",new se(a,3)),this.setAttribute("normal",new se(a.slice(),3)),this.setAttribute("uv",new se(r,2)),s===0?this.computeVertexNormals():this.normalizeNormals();function o(y){const A=new D,b=new D,w=new D;for(let E=0;E<e.length;E+=3)f(e[E+0],A),f(e[E+1],b),f(e[E+2],w),l(A,b,w,y)}function l(y,A,b,w){const E=w+1,v=[];for(let S=0;S<=E;S++){v[S]=[];const P=y.clone().lerp(b,S/E),R=A.clone().lerp(b,S/E),N=E-S;for(let F=0;F<=N;F++)F===0&&S===E?v[S][F]=P:v[S][F]=P.clone().lerp(R,F/N)}for(let S=0;S<E;S++)for(let P=0;P<2*(E-S)-1;P++){const R=Math.floor(P/2);P%2===0?(u(v[S][R+1]),u(v[S+1][R]),u(v[S][R])):(u(v[S][R+1]),u(v[S+1][R+1]),u(v[S+1][R]))}}function c(y){const A=new D;for(let b=0;b<a.length;b+=3)A.x=a[b+0],A.y=a[b+1],A.z=a[b+2],A.normalize().multiplyScalar(y),a[b+0]=A.x,a[b+1]=A.y,a[b+2]=A.z}function d(){const y=new D;for(let A=0;A<a.length;A+=3){y.x=a[A+0],y.y=a[A+1],y.z=a[A+2];const b=m(y)/2/Math.PI+.5,w=p(y)/Math.PI+.5;r.push(b,1-w)}g(),h()}function h(){for(let y=0;y<r.length;y+=6){const A=r[y+0],b=r[y+2],w=r[y+4],E=Math.max(A,b,w),v=Math.min(A,b,w);E>.9&&v<.1&&(A<.2&&(r[y+0]+=1),b<.2&&(r[y+2]+=1),w<.2&&(r[y+4]+=1))}}function u(y){a.push(y.x,y.y,y.z)}function f(y,A){const b=y*3;A.x=t[b+0],A.y=t[b+1],A.z=t[b+2]}function g(){const y=new D,A=new D,b=new D,w=new D,E=new It,v=new It,S=new It;for(let P=0,R=0;P<a.length;P+=9,R+=6){y.set(a[P+0],a[P+1],a[P+2]),A.set(a[P+3],a[P+4],a[P+5]),b.set(a[P+6],a[P+7],a[P+8]),E.set(r[R+0],r[R+1]),v.set(r[R+2],r[R+3]),S.set(r[R+4],r[R+5]),w.copy(y).add(A).add(b).divideScalar(3);const N=m(w);x(E,R+0,y,N),x(v,R+2,A,N),x(S,R+4,b,N)}}function x(y,A,b,w){w<0&&y.x===1&&(r[A]=y.x-1),b.x===0&&b.z===0&&(r[A]=w/2/Math.PI+.5)}function m(y){return Math.atan2(y.z,-y.x)}function p(y){return Math.atan2(-y.y,Math.sqrt(y.x*y.x+y.z*y.z))}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new Ja(t.vertices,t.indices,t.radius,t.detail)}}class ra extends Ja{constructor(t=1,e=0){const n=(1+Math.sqrt(5))/2,s=1/n,a=[-1,-1,-1,-1,-1,1,-1,1,-1,-1,1,1,1,-1,-1,1,-1,1,1,1,-1,1,1,1,0,-s,-n,0,-s,n,0,s,-n,0,s,n,-s,-n,0,-s,n,0,s,-n,0,s,n,0,-n,0,-s,n,0,-s,-n,0,s,n,0,s],r=[3,11,7,3,7,15,3,15,13,7,19,17,7,17,6,7,6,15,17,4,8,17,8,10,17,10,6,8,0,16,8,16,2,8,2,10,0,12,1,0,1,18,0,18,16,6,10,2,6,2,13,6,13,15,2,16,18,2,18,3,2,3,13,18,1,9,18,9,11,18,11,3,4,14,12,4,12,0,4,0,8,11,9,5,11,5,19,11,19,7,19,5,14,19,14,4,19,4,17,1,12,14,1,14,5,1,5,9];super(a,r,t,e),this.type="DodecahedronGeometry",this.parameters={radius:t,detail:e}}static fromJSON(t){return new ra(t.radius,t.detail)}}const Rr=new D,Cr=new D,Rl=new D,Pr=new wn;class w0 extends ge{constructor(t=null,e=1){if(super(),this.type="EdgesGeometry",this.parameters={geometry:t,thresholdAngle:e},t!==null){const s=Math.pow(10,4),a=Math.cos(Ys*e),r=t.getIndex(),o=t.getAttribute("position"),l=r?r.count:o.count,c=[0,0,0],d=["a","b","c"],h=new Array(3),u=new Map,f=[];for(let g=0;g<l;g+=3){r?(c[0]=r.getX(g),c[1]=r.getX(g+1),c[2]=r.getX(g+2)):(c[0]=g,c[1]=g+1,c[2]=g+2);const{a:x,b:m,c:p}=Pr;if(x.fromBufferAttribute(o,c[0]),m.fromBufferAttribute(o,c[1]),p.fromBufferAttribute(o,c[2]),Pr.getNormal(Rl),h[0]=`${Math.round(x.x*s)},${Math.round(x.y*s)},${Math.round(x.z*s)}`,h[1]=`${Math.round(m.x*s)},${Math.round(m.y*s)},${Math.round(m.z*s)}`,h[2]=`${Math.round(p.x*s)},${Math.round(p.y*s)},${Math.round(p.z*s)}`,!(h[0]===h[1]||h[1]===h[2]||h[2]===h[0]))for(let y=0;y<3;y++){const A=(y+1)%3,b=h[y],w=h[A],E=Pr[d[y]],v=Pr[d[A]],S=`${b}_${w}`,P=`${w}_${b}`,R=u.get(P);R?(Rl.dot(R.normal)<=a&&(f.push(E.x,E.y,E.z),f.push(v.x,v.y,v.z)),u.set(P,null)):u.has(S)||u.set(S,{index0:c[y],index1:c[A],normal:Rl.clone()})}}for(const g of u.values())if(g){const{index0:x,index1:m}=g;Rr.fromBufferAttribute(o,x),Cr.fromBufferAttribute(o,m),f.push(Rr.x,Rr.y,Rr.z),f.push(Cr.x,Cr.y,Cr.z)}this.setAttribute("position",new se(f,3))}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}}class Hn extends Ja{constructor(t=1,e=0){const n=(1+Math.sqrt(5))/2,s=[-1,n,0,1,n,0,-1,-n,0,1,-n,0,0,-1,n,0,1,n,0,-1,-n,0,1,-n,n,0,-1,n,0,1,-n,0,-1,-n,0,1],a=[0,11,5,0,5,1,0,1,7,0,7,10,0,10,11,1,5,9,5,11,4,11,10,2,10,7,6,7,1,8,3,9,4,3,4,2,3,2,6,3,6,8,3,8,9,4,9,5,2,4,11,6,2,10,8,6,7,9,8,1];super(s,a,t,e),this.type="IcosahedronGeometry",this.parameters={radius:t,detail:e}}static fromJSON(t){return new Hn(t.radius,t.detail)}}class fi extends Ja{constructor(t=1,e=0){const n=[1,0,0,-1,0,0,0,1,0,0,-1,0,0,0,1,0,0,-1],s=[0,2,4,0,4,3,0,3,5,0,5,2,1,2,5,1,5,3,1,3,4,1,4,2];super(n,s,t,e),this.type="OctahedronGeometry",this.parameters={radius:t,detail:e}}static fromJSON(t){return new fi(t.radius,t.detail)}}class ws extends ge{constructor(t=1,e=1,n=1,s=1){super(),this.type="PlaneGeometry",this.parameters={width:t,height:e,widthSegments:n,heightSegments:s};const a=t/2,r=e/2,o=Math.floor(n),l=Math.floor(s),c=o+1,d=l+1,h=t/o,u=e/l,f=[],g=[],x=[],m=[];for(let p=0;p<d;p++){const y=p*u-r;for(let A=0;A<c;A++){const b=A*h-a;g.push(b,-y,0),x.push(0,0,1),m.push(A/o),m.push(1-p/l)}}for(let p=0;p<l;p++)for(let y=0;y<o;y++){const A=y+c*p,b=y+c*(p+1),w=y+1+c*(p+1),E=y+1+c*p;f.push(A,b,E),f.push(b,w,E)}this.setIndex(f),this.setAttribute("position",new se(g,3)),this.setAttribute("normal",new se(x,3)),this.setAttribute("uv",new se(m,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new ws(t.width,t.height,t.widthSegments,t.heightSegments)}}class $o extends ge{constructor(t=.5,e=1,n=32,s=1,a=0,r=Math.PI*2){super(),this.type="RingGeometry",this.parameters={innerRadius:t,outerRadius:e,thetaSegments:n,phiSegments:s,thetaStart:a,thetaLength:r},n=Math.max(3,n),s=Math.max(1,s);const o=[],l=[],c=[],d=[];let h=t;const u=(e-t)/s,f=new D,g=new It;for(let x=0;x<=s;x++){for(let m=0;m<=n;m++){const p=a+m/n*r;f.x=h*Math.cos(p),f.y=h*Math.sin(p),l.push(f.x,f.y,f.z),c.push(0,0,1),g.x=(f.x/e+1)/2,g.y=(f.y/e+1)/2,d.push(g.x,g.y)}h+=u}for(let x=0;x<s;x++){const m=x*(n+1);for(let p=0;p<n;p++){const y=p+m,A=y,b=y+n+1,w=y+n+2,E=y+1;o.push(A,b,E),o.push(b,w,E)}}this.setIndex(o),this.setAttribute("position",new se(l,3)),this.setAttribute("normal",new se(c,3)),this.setAttribute("uv",new se(d,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new $o(t.innerRadius,t.outerRadius,t.thetaSegments,t.phiSegments,t.thetaStart,t.thetaLength)}}class Oe extends ge{constructor(t=1,e=32,n=16,s=0,a=Math.PI*2,r=0,o=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:t,widthSegments:e,heightSegments:n,phiStart:s,phiLength:a,thetaStart:r,thetaLength:o},e=Math.max(3,Math.floor(e)),n=Math.max(2,Math.floor(n));const l=Math.min(r+o,Math.PI);let c=0;const d=[],h=new D,u=new D,f=[],g=[],x=[],m=[];for(let p=0;p<=n;p++){const y=[],A=p/n,b=r+A*o,w=t*Math.cos(b),E=Math.sqrt(t*t-w*w);let v=0;p===0&&r===0?v=.5/e:p===n&&l===Math.PI&&(v=-.5/e);for(let S=0;S<=e;S++){const P=S/e,R=s+P*a;h.x=-E*Math.cos(R),h.y=w,h.z=E*Math.sin(R),g.push(h.x,h.y,h.z),u.copy(h).normalize(),x.push(u.x,u.y,u.z),m.push(P+v,1-A),y.push(c++)}d.push(y)}for(let p=0;p<n;p++)for(let y=0;y<e;y++){const A=d[p][y+1],b=d[p][y],w=d[p+1][y],E=d[p+1][y+1];(p!==0||r>0)&&f.push(A,b,E),(p!==n-1||l<Math.PI)&&f.push(b,w,E)}this.setIndex(f),this.setAttribute("position",new se(g,3)),this.setAttribute("normal",new se(x,3)),this.setAttribute("uv",new se(m,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new Oe(t.radius,t.widthSegments,t.heightSegments,t.phiStart,t.phiLength,t.thetaStart,t.thetaLength)}}class tn extends ge{constructor(t=1,e=.4,n=12,s=48,a=Math.PI*2,r=0,o=Math.PI*2){super(),this.type="TorusGeometry",this.parameters={radius:t,tube:e,radialSegments:n,tubularSegments:s,arc:a,thetaStart:r,thetaLength:o},n=Math.floor(n),s=Math.floor(s);const l=[],c=[],d=[],h=[],u=new D,f=new D,g=new D;for(let x=0;x<=n;x++){const m=r+x/n*o;for(let p=0;p<=s;p++){const y=p/s*a;f.x=(t+e*Math.cos(m))*Math.cos(y),f.y=(t+e*Math.cos(m))*Math.sin(y),f.z=e*Math.sin(m),c.push(f.x,f.y,f.z),u.x=t*Math.cos(y),u.y=t*Math.sin(y),g.subVectors(f,u).normalize(),d.push(g.x,g.y,g.z),h.push(p/s),h.push(x/n)}}for(let x=1;x<=n;x++)for(let m=1;m<=s;m++){const p=(s+1)*x+m-1,y=(s+1)*(x-1)+m-1,A=(s+1)*(x-1)+m,b=(s+1)*x+m;l.push(p,y,b),l.push(y,A,b)}this.setIndex(l),this.setAttribute("position",new se(c,3)),this.setAttribute("normal",new se(d,3)),this.setAttribute("uv",new se(h,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new tn(t.radius,t.tube,t.radialSegments,t.tubularSegments,t.arc,t.thetaStart,t.thetaLength)}}function oa(i){const t={};for(const e in i){t[e]={};for(const n in i[e]){const s=i[e][n];if(Th(s))s.isRenderTargetTexture?(Ut("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),t[e][n]=null):t[e][n]=s.clone();else if(Array.isArray(s))if(Th(s[0])){const a=[];for(let r=0,o=s.length;r<o;r++)a[r]=s[r].clone();t[e][n]=a}else t[e][n]=s.slice();else t[e][n]=s}}return t}function un(i){const t={};for(let e=0;e<i.length;e++){const n=oa(i[e]);for(const s in n)t[s]=n[s]}return t}function Th(i){return i&&(i.isColor||i.isMatrix3||i.isMatrix4||i.isVector2||i.isVector3||i.isVector4||i.isTexture||i.isQuaternion)}function E0(i){const t=[];for(let e=0;e<i.length;e++)t.push(i[e].clone());return t}function Of(i){const t=i.getRenderTarget();return t===null?i.outputColorSpace:t.isXRRenderTarget===!0?t.texture.colorSpace:te.workingColorSpace}const A0={clone:oa,merge:un};var T0=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,R0=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class En extends Ui{constructor(t){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=T0,this.fragmentShader=R0,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,t!==void 0&&this.setValues(t)}copy(t){return super.copy(t),this.fragmentShader=t.fragmentShader,this.vertexShader=t.vertexShader,this.uniforms=oa(t.uniforms),this.uniformsGroups=E0(t.uniformsGroups),this.defines=Object.assign({},t.defines),this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.fog=t.fog,this.lights=t.lights,this.clipping=t.clipping,this.extensions=Object.assign({},t.extensions),this.glslVersion=t.glslVersion,this.defaultAttributeValues=Object.assign({},t.defaultAttributeValues),this.index0AttributeName=t.index0AttributeName,this.uniformsNeedUpdate=t.uniformsNeedUpdate,this}toJSON(t){const e=super.toJSON(t);e.glslVersion=this.glslVersion,e.uniforms={};for(const s in this.uniforms){const r=this.uniforms[s].value;r&&r.isTexture?e.uniforms[s]={type:"t",value:r.toJSON(t).uuid}:r&&r.isColor?e.uniforms[s]={type:"c",value:r.getHex()}:r&&r.isVector2?e.uniforms[s]={type:"v2",value:r.toArray()}:r&&r.isVector3?e.uniforms[s]={type:"v3",value:r.toArray()}:r&&r.isVector4?e.uniforms[s]={type:"v4",value:r.toArray()}:r&&r.isMatrix3?e.uniforms[s]={type:"m3",value:r.toArray()}:r&&r.isMatrix4?e.uniforms[s]={type:"m4",value:r.toArray()}:e.uniforms[s]={value:r}}Object.keys(this.defines).length>0&&(e.defines=this.defines),e.vertexShader=this.vertexShader,e.fragmentShader=this.fragmentShader,e.lights=this.lights,e.clipping=this.clipping;const n={};for(const s in this.extensions)this.extensions[s]===!0&&(n[s]=!0);return Object.keys(n).length>0&&(e.extensions=n),e}fromJSON(t,e){if(super.fromJSON(t,e),t.uniforms!==void 0)for(const n in t.uniforms){const s=t.uniforms[n];switch(this.uniforms[n]={},s.type){case"t":this.uniforms[n].value=e[s.value]||null;break;case"c":this.uniforms[n].value=new Rt().setHex(s.value);break;case"v2":this.uniforms[n].value=new It().fromArray(s.value);break;case"v3":this.uniforms[n].value=new D().fromArray(s.value);break;case"v4":this.uniforms[n].value=new Ae().fromArray(s.value);break;case"m3":this.uniforms[n].value=new Bt().fromArray(s.value);break;case"m4":this.uniforms[n].value=new ee().fromArray(s.value);break;default:this.uniforms[n].value=s.value}}if(t.defines!==void 0&&(this.defines=t.defines),t.vertexShader!==void 0&&(this.vertexShader=t.vertexShader),t.fragmentShader!==void 0&&(this.fragmentShader=t.fragmentShader),t.glslVersion!==void 0&&(this.glslVersion=t.glslVersion),t.extensions!==void 0)for(const n in t.extensions)this.extensions[n]=t.extensions[n];return t.lights!==void 0&&(this.lights=t.lights),t.clipping!==void 0&&(this.clipping=t.clipping),this}}class C0 extends En{constructor(t){super(t),this.isRawShaderMaterial=!0,this.type="RawShaderMaterial"}}class ln extends Ui{constructor(t){super(),this.isMeshStandardMaterial=!0,this.type="MeshStandardMaterial",this.defines={STANDARD:""},this.color=new Rt(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new Rt(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=ro,this.normalScale=new It(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new zn,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.defines={STANDARD:""},this.color.copy(t.color),this.roughness=t.roughness,this.metalness=t.metalness,this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.emissive.copy(t.emissive),this.emissiveMap=t.emissiveMap,this.emissiveIntensity=t.emissiveIntensity,this.bumpMap=t.bumpMap,this.bumpScale=t.bumpScale,this.normalMap=t.normalMap,this.normalMapType=t.normalMapType,this.normalScale.copy(t.normalScale),this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.roughnessMap=t.roughnessMap,this.metalnessMap=t.metalnessMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapRotation.copy(t.envMapRotation),this.envMapIntensity=t.envMapIntensity,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.flatShading=t.flatShading,this.fog=t.fog,this}}class P0 extends Ui{constructor(t){super(),this.isMeshLambertMaterial=!0,this.type="MeshLambertMaterial",this.color=new Rt(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new Rt(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=ro,this.normalScale=new It(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new zn,this.combine=ed,this.reflectivity=1,this.envMapIntensity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.emissive.copy(t.emissive),this.emissiveMap=t.emissiveMap,this.emissiveIntensity=t.emissiveIntensity,this.bumpMap=t.bumpMap,this.bumpScale=t.bumpScale,this.normalMap=t.normalMap,this.normalMapType=t.normalMapType,this.normalScale.copy(t.normalScale),this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.specularMap=t.specularMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapRotation.copy(t.envMapRotation),this.combine=t.combine,this.reflectivity=t.reflectivity,this.envMapIntensity=t.envMapIntensity,this.refractionRatio=t.refractionRatio,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.flatShading=t.flatShading,this.fog=t.fog,this}}class L0 extends Ui{constructor(t){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=Rm,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(t)}copy(t){return super.copy(t),this.depthPacking=t.depthPacking,this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this}}class D0 extends Ui{constructor(t){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(t)}copy(t){return super.copy(t),this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this}}class Ho extends Ie{static registerNode(t){this.prototype._lightNode=t}constructor(t,e=1){super(),this.isLight=!0,this.type="Light",this.color=new Rt(t),this.intensity=e}copy(t,e){return super.copy(t,e),this.color.copy(t.color),this.intensity=t.intensity,this}toJSON(t){const e=super.toJSON(t);return e.object.color=this.color.getHex(),e.object.intensity=this.intensity,e}}class Bf extends Ho{constructor(t,e,n){super(t,n),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(Ie.DEFAULT_UP),this.updateMatrix(),this.groundColor=new Rt(e)}copy(t,e){return super.copy(t,e),this.groundColor.copy(t.groundColor),this}toJSON(t){const e=super.toJSON(t);return e.object.groundColor=this.groundColor.getHex(),e}}const Cl=new ee,Rh=new D,Ch=new D;class kf{constructor(t){this.camera=t,this.intensity=1,this.bias=0,this.biasNode=null,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new It(512,512),this.mapType=xn,this.map=null,this.mapPass=null,this.matrix=new ee,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new Va,this._frameExtents=new It(1,1),this._viewportCount=1,this._viewports=[new Ae(0,0,1,1)]}getViewportCount(){return this._viewportCount}getCamera(){return this.camera}getFrustum(){return this._frustum}updateMatrices(t){const e=this.camera;Rh.setFromMatrixPosition(t.matrixWorld),e.position.copy(Rh),Ch.setFromMatrixPosition(t.target.matrixWorld),e.lookAt(Ch),e.updateMatrixWorld(),this._updateMatrix(e,this.matrix,this._frustum)}_updateMatrix(t,e,n,s){Cl.multiplyMatrices(t.projectionMatrix,t.matrixWorldInverse),n.setFromProjectionMatrix(Cl,t.coordinateSystem,t.reversedDepth);const a=this._frameExtents,r=s?s.z/a.x:1,o=s?s.w/a.y:1,l=s?s.x/a.x:0,c=s?s.y/a.y:0;t.coordinateSystem===Ha||t.reversedDepth?e.set(.5*r,0,0,.5*r+l,0,.5*o,0,.5*o+c,0,0,1,0,0,0,0,1):e.set(.5*r,0,0,.5*r+l,0,.5*o,0,.5*o+c,0,0,.5,.5,0,0,0,1),e.multiply(Cl)}getViewport(t){return this._viewports[t]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(t){return this.camera=t.camera.clone(),this.intensity=t.intensity,this.bias=t.bias,this.radius=t.radius,this.autoUpdate=t.autoUpdate,this.needsUpdate=t.needsUpdate,this.normalBias=t.normalBias,this.blurSamples=t.blurSamples,this.mapSize.copy(t.mapSize),this.mapType=t.mapType,this.biasNode=t.biasNode,this}clone(){return new this.constructor().copy(this)}toJSON(){const t={};return t.intensity=this.intensity,t.bias=this.bias,t.normalBias=this.normalBias,t.radius=this.radius,t.blurSamples=this.blurSamples,t.mapSize=this.mapSize.toArray(),t.mapType=this.mapType,t.camera=this.camera.toJSON(!1).object,delete t.camera.matrix,t}}const Lr=new D,Dr=new Ni,oi=new D;class zf extends Ie{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new ee,this.projectionMatrix=new ee,this.projectionMatrixInverse=new ee,this.coordinateSystem=ei,this._reversedDepth=!1}get reversedDepth(){return this._reversedDepth}copy(t,e){return super.copy(t,e),this.matrixWorldInverse.copy(t.matrixWorldInverse),this.projectionMatrix.copy(t.projectionMatrix),this.projectionMatrixInverse.copy(t.projectionMatrixInverse),this.coordinateSystem=t.coordinateSystem,this}getWorldDirection(t){return super.getWorldDirection(t).negate()}updateMatrixWorld(t){super.updateMatrixWorld(t),this.matrixWorld.decompose(Lr,Dr,oi),oi.x===1&&oi.y===1&&oi.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(Lr,Dr,oi.set(1,1,1)).invert()}updateWorldMatrix(t,e,n=!1){super.updateWorldMatrix(t,e,n),this.matrixWorld.decompose(Lr,Dr,oi),oi.x===1&&oi.y===1&&oi.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(Lr,Dr,oi.set(1,1,1)).invert()}clone(){return new this.constructor().copy(this)}}const Hi=new D,Ph=new It,Lh=new It;class gn extends zf{constructor(t=50,e=1,n=.1,s=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=t,this.zoom=1,this.near=n,this.far=s,this.focus=10,this.aspect=e,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.fov=t.fov,this.zoom=t.zoom,this.near=t.near,this.far=t.far,this.focus=t.focus,this.aspect=t.aspect,this.view=t.view===null?null:Object.assign({},t.view),this.filmGauge=t.filmGauge,this.filmOffset=t.filmOffset,this}setFocalLength(t){const e=.5*this.getFilmHeight()/t;this.fov=Ga*2*Math.atan(e),this.updateProjectionMatrix()}getFocalLength(){const t=Math.tan(Ys*.5*this.fov);return .5*this.getFilmHeight()/t}getEffectiveFOV(){return Ga*2*Math.atan(Math.tan(Ys*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(t,e,n){Hi.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),e.set(Hi.x,Hi.y).multiplyScalar(-t/Hi.z),Hi.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),n.set(Hi.x,Hi.y).multiplyScalar(-t/Hi.z)}getViewSize(t,e){return this.getViewBounds(t,Ph,Lh),e.subVectors(Lh,Ph)}setViewOffset(t,e,n,s,a,r){this.aspect=t/e,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=n,this.view.offsetY=s,this.view.width=a,this.view.height=r,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const t=this.near;let e=t*Math.tan(Ys*.5*this.fov)/this.zoom,n=2*e,s=this.aspect*n,a=-.5*s;const r=this.view;if(this.view!==null&&this.view.enabled){const l=r.fullWidth,c=r.fullHeight;a+=r.offsetX*s/l,e-=r.offsetY*n/c,s*=r.width/l,n*=r.height/c}const o=this.filmOffset;o!==0&&(a+=t*o/this.getFilmWidth()),this.projectionMatrix.makePerspective(a,a+s,e,e-n,t,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){const e=super.toJSON(t);return e.object.fov=this.fov,e.object.zoom=this.zoom,e.object.near=this.near,e.object.far=this.far,e.object.focus=this.focus,e.object.aspect=this.aspect,this.view!==null&&(e.object.view=Object.assign({},this.view)),e.object.filmGauge=this.filmGauge,e.object.filmOffset=this.filmOffset,e}}class I0 extends kf{constructor(){super(new gn(90,1,.5,500)),this.isPointLightShadow=!0}}class $f extends Ho{constructor(t,e,n=0,s=2){super(t,e),this.isPointLight=!0,this.type="PointLight",this.distance=n,this.decay=s,this.shadow=new I0}get power(){return this.intensity*4*Math.PI}set power(t){this.intensity=t/(4*Math.PI)}dispose(){super.dispose(),this.shadow.dispose()}copy(t,e){return super.copy(t,e),this.distance=t.distance,this.decay=t.decay,this.shadow=t.shadow.clone(),this}toJSON(t){const e=super.toJSON(t);return e.object.distance=this.distance,e.object.decay=this.decay,e.object.shadow=this.shadow.toJSON(),e}}class vd extends zf{constructor(t=-1,e=1,n=1,s=-1,a=.1,r=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=t,this.right=e,this.top=n,this.bottom=s,this.near=a,this.far=r,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.left=t.left,this.right=t.right,this.top=t.top,this.bottom=t.bottom,this.near=t.near,this.far=t.far,this.zoom=t.zoom,this.view=t.view===null?null:Object.assign({},t.view),this}setViewOffset(t,e,n,s,a,r){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=n,this.view.offsetY=s,this.view.width=a,this.view.height=r,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const t=(this.right-this.left)/(2*this.zoom),e=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,s=(this.top+this.bottom)/2;let a=n-t,r=n+t,o=s+e,l=s-e;if(this.view!==null&&this.view.enabled){const c=(this.right-this.left)/this.view.fullWidth/this.zoom,d=(this.top-this.bottom)/this.view.fullHeight/this.zoom;a+=c*this.view.offsetX,r=a+c*this.view.width,o-=d*this.view.offsetY,l=o-d*this.view.height}this.projectionMatrix.makeOrthographic(a,r,o,l,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){const e=super.toJSON(t);return e.object.zoom=this.zoom,e.object.left=this.left,e.object.right=this.right,e.object.top=this.top,e.object.bottom=this.bottom,e.object.near=this.near,e.object.far=this.far,this.view!==null&&(e.object.view=Object.assign({},this.view)),e}}class N0 extends kf{constructor(){super(new vd(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}}class xo extends Ho{constructor(t,e){super(t,e),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(Ie.DEFAULT_UP),this.updateMatrix(),this.target=new Ie,this.shadow=new N0}dispose(){super.dispose(),this.shadow.dispose()}copy(t){return super.copy(t),this.target=t.target.clone(),this.shadow=t.shadow.clone(),this}toJSON(t){const e=super.toJSON(t);return e.object.shadow=this.shadow.toJSON(),e.object.target=this.target.uuid,e}}class Hf extends Ho{constructor(t,e){super(t,e),this.isAmbientLight=!0,this.type="AmbientLight"}}const $s=-90,Hs=1;class Ic extends Ie{constructor(t,e,n){super(),this.type="CubeCamera",this.renderTarget=n,this.coordinateSystem=null,this.activeMipmapLevel=0;const s=new gn($s,Hs,t,e);s.layers=this.layers,this.add(s);const a=new gn($s,Hs,t,e);a.layers=this.layers,this.add(a);const r=new gn($s,Hs,t,e);r.layers=this.layers,this.add(r);const o=new gn($s,Hs,t,e);o.layers=this.layers,this.add(o);const l=new gn($s,Hs,t,e);l.layers=this.layers,this.add(l);const c=new gn($s,Hs,t,e);c.layers=this.layers,this.add(c)}updateCoordinateSystem(){const t=this.coordinateSystem,e=this.children.concat(),[n,s,a,r,o,l]=e;for(const c of e)this.remove(c);if(t===ei)n.up.set(0,1,0),n.lookAt(1,0,0),s.up.set(0,1,0),s.lookAt(-1,0,0),a.up.set(0,0,-1),a.lookAt(0,1,0),r.up.set(0,0,1),r.lookAt(0,-1,0),o.up.set(0,1,0),o.lookAt(0,0,1),l.up.set(0,1,0),l.lookAt(0,0,-1);else if(t===Ha)n.up.set(0,-1,0),n.lookAt(-1,0,0),s.up.set(0,-1,0),s.lookAt(1,0,0),a.up.set(0,0,1),a.lookAt(0,1,0),r.up.set(0,0,-1),r.lookAt(0,-1,0),o.up.set(0,-1,0),o.lookAt(0,0,1),l.up.set(0,-1,0),l.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+t);for(const c of e)this.add(c),c.updateMatrixWorld()}update(t,e){this.parent===null&&this.updateMatrixWorld();const{renderTarget:n,activeMipmapLevel:s}=this;this.coordinateSystem!==t.coordinateSystem&&(this.coordinateSystem=t.coordinateSystem,this.updateCoordinateSystem());const[a,r,o,l,c,d]=this.children,h=t.getRenderTarget(),u=t.getActiveCubeFace(),f=t.getActiveMipmapLevel(),g=t.xr.enabled;t.xr.enabled=!1;const x=n.texture.mipmapsAutoUpdate;n.texture.mipmapsAutoUpdate=!1;let m=!1;t.isWebGLRenderer===!0?m=t.state.buffers.depth.getReversed():m=t.reversedDepthBuffer,t.setRenderTarget(n,0,s),m&&t.autoClear===!1&&t.clearDepth(),t.render(e,a),t.setRenderTarget(n,1,s),m&&t.autoClear===!1&&t.clearDepth(),t.render(e,r),t.setRenderTarget(n,2,s),m&&t.autoClear===!1&&t.clearDepth(),t.render(e,o),t.setRenderTarget(n,3,s),m&&t.autoClear===!1&&t.clearDepth(),t.render(e,l),t.setRenderTarget(n,4,s),m&&t.autoClear===!1&&t.clearDepth(),t.render(e,c),n.texture.mipmapsAutoUpdate=x,t.setRenderTarget(n,5,s),m&&t.autoClear===!1&&t.clearDepth(),t.render(e,d),t.setRenderTarget(h,u,f),t.xr.enabled=g,n.texture.needsPMREMUpdate=!0}}class U0 extends gn{constructor(t=[]){super(),this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=t,this.perCameraFrustumCulled=!1}}const Dh=new ee;class Gf{constructor(t,e,n=0,s=1/0){this.ray=new ko(t,e),this.near=n,this.far=s,this.camera=null,this.layers=new pd,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(t,e){this.ray.set(t,e)}setFromCamera(t,e){e.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(e.matrixWorld),this.ray.direction.set(t.x,t.y,.5).unproject(e).sub(this.ray.origin).normalize(),this.camera=e):e.isOrthographicCamera?(this.ray.origin.set(t.x,t.y,e.projectionMatrix.elements[14]).unproject(e),this.ray.direction.set(0,0,-1).transformDirection(e.matrixWorld),this.camera=e):ie("Raycaster: Unsupported camera type: "+e.type)}setFromXRController(t){return Dh.identity().extractRotation(t.matrixWorld),this.ray.origin.setFromMatrixPosition(t.matrixWorld),this.ray.direction.set(0,0,-1).applyMatrix4(Dh),this}intersectObject(t,e=!0,n=[]){return Nc(t,this,n,e),n.sort(Ih),n}intersectObjects(t,e=!0,n=[]){for(let s=0,a=t.length;s<a;s++)Nc(t[s],this,n,e);return n.sort(Ih),n}}function Ih(i,t){return i.distance-t.distance}function Nc(i,t,e,n){let s=!0;if(i.layers.test(t.layers)&&i.raycast(t,e)===!1&&(s=!1),s===!0&&n===!0){const a=i.children;for(let r=0,o=a.length;r<o;r++)Nc(a[r],t,e,!0)}}function Nh(i,t,e,n){const s=F0(n);switch(e){case yf:return i*t;case rd:return i*t/s.components*s.byteLength;case od:return i*t/s.components*s.byteLength;case ms:return i*t*2/s.components*s.byteLength;case ld:return i*t*2/s.components*s.byteLength;case bf:return i*t*3/s.components*s.byteLength;case hi:return i*t*4/s.components*s.byteLength;case cd:return i*t*4/s.components*s.byteLength;case Xr:case qr:return Math.floor((i+3)/4)*Math.floor((t+3)/4)*8;case Yr:case Kr:return Math.floor((i+3)/4)*Math.floor((t+3)/4)*16;case nc:case sc:return Math.max(i,16)*Math.max(t,8)/4;case ec:case ic:return Math.max(i,8)*Math.max(t,8)/2;case ac:case rc:case lc:case cc:return Math.floor((i+3)/4)*Math.floor((t+3)/4)*8;case oc:case so:case dc:return Math.floor((i+3)/4)*Math.floor((t+3)/4)*16;case hc:return Math.floor((i+3)/4)*Math.floor((t+3)/4)*16;case uc:return Math.floor((i+4)/5)*Math.floor((t+3)/4)*16;case fc:return Math.floor((i+4)/5)*Math.floor((t+4)/5)*16;case pc:return Math.floor((i+5)/6)*Math.floor((t+4)/5)*16;case mc:return Math.floor((i+5)/6)*Math.floor((t+5)/6)*16;case gc:return Math.floor((i+7)/8)*Math.floor((t+4)/5)*16;case vc:return Math.floor((i+7)/8)*Math.floor((t+5)/6)*16;case xc:return Math.floor((i+7)/8)*Math.floor((t+7)/8)*16;case yc:return Math.floor((i+9)/10)*Math.floor((t+4)/5)*16;case bc:return Math.floor((i+9)/10)*Math.floor((t+5)/6)*16;case _c:return Math.floor((i+9)/10)*Math.floor((t+7)/8)*16;case Mc:return Math.floor((i+9)/10)*Math.floor((t+9)/10)*16;case Sc:return Math.floor((i+11)/12)*Math.floor((t+9)/10)*16;case wc:return Math.floor((i+11)/12)*Math.floor((t+11)/12)*16;case Ec:case Ac:case Tc:return Math.ceil(i/4)*Math.ceil(t/4)*16;case Rc:case Cc:return Math.ceil(i/4)*Math.ceil(t/4)*8;case ao:case Pc:return Math.ceil(i/4)*Math.ceil(t/4)*16}throw new Error(`Unable to determine texture byte length for ${e} format.`)}function F0(i){switch(i){case xn:case mf:return{byteLength:1,components:1};case $a:case gf:case mi:return{byteLength:2,components:1};case sd:case ad:return{byteLength:2,components:4};case pi:case id:case ti:return{byteLength:4,components:1};case vf:case xf:return{byteLength:4,components:3}}throw new Error(`THREE.TextureUtils: Unknown texture type ${i}.`)}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:td}}));typeof window<"u"&&(window.__THREE__?Ut("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=td);function Vf(){let i=null,t=!1,e=null,n=null;function s(a,r){n=i.requestAnimationFrame(s),e(a,r)}return{start:function(){t!==!0&&e!==null&&i!==null&&(n=i.requestAnimationFrame(s),t=!0)},stop:function(){i!==null&&i.cancelAnimationFrame(n),t=!1},setAnimationLoop:function(a){e=a},setContext:function(a){i=a}}}function O0(i){const t=new WeakMap;function e(o,l){const c=o.array,d=o.usage,h=c.byteLength,u=i.createBuffer();i.bindBuffer(l,u),i.bufferData(l,c,d),o.onUploadCallback();let f;if(c instanceof Float32Array)f=i.FLOAT;else if(typeof Float16Array<"u"&&c instanceof Float16Array)f=i.HALF_FLOAT;else if(c instanceof Uint16Array)o.isFloat16BufferAttribute?f=i.HALF_FLOAT:f=i.UNSIGNED_SHORT;else if(c instanceof Int16Array)f=i.SHORT;else if(c instanceof Uint32Array)f=i.UNSIGNED_INT;else if(c instanceof Int32Array)f=i.INT;else if(c instanceof Int8Array)f=i.BYTE;else if(c instanceof Uint8Array)f=i.UNSIGNED_BYTE;else if(c instanceof Uint8ClampedArray)f=i.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+c);return{buffer:u,type:f,bytesPerElement:c.BYTES_PER_ELEMENT,version:o.version,size:h}}function n(o,l,c){const d=l.array,h=l.updateRanges;if(i.bindBuffer(c,o),h.length===0)i.bufferSubData(c,0,d);else{h.sort((f,g)=>f.start-g.start);let u=0;for(let f=1;f<h.length;f++){const g=h[u],x=h[f];x.start<=g.start+g.count+1?g.count=Math.max(g.count,x.start+x.count-g.start):(++u,h[u]=x)}h.length=u+1;for(let f=0,g=h.length;f<g;f++){const x=h[f];i.bufferSubData(c,x.start*d.BYTES_PER_ELEMENT,d,x.start,x.count)}l.clearUpdateRanges()}l.onUploadCallback()}function s(o){return o.isInterleavedBufferAttribute&&(o=o.data),t.get(o)}function a(o){o.isInterleavedBufferAttribute&&(o=o.data);const l=t.get(o);l&&(i.deleteBuffer(l.buffer),t.delete(o))}function r(o,l){if(o.isInterleavedBufferAttribute&&(o=o.data),o.isGLBufferAttribute){const d=t.get(o);(!d||d.version<o.version)&&t.set(o,{buffer:o.buffer,type:o.type,bytesPerElement:o.elementSize,version:o.version});return}const c=t.get(o);if(c===void 0)t.set(o,e(o,l));else if(c.version<o.version){if(c.size!==o.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");n(c.buffer,o,l),c.version=o.version}}return{get:s,remove:a,update:r}}var B0=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,k0=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,z0=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,$0=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,H0=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,G0=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,V0=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,W0=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,X0=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec4 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 );
	}
#endif`,q0=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,Y0=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,K0=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,Z0=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,J0=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,j0=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,Q0=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,tg=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,eg=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,ng=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,ig=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#endif`,sg=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#endif`,ag=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec4 vColor;
#endif`,rg=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec4( 1.0 );
#endif
#ifdef USE_COLOR_ALPHA
	vColor *= color;
#elif defined( USE_COLOR )
	vColor.rgb *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.rgb *= instanceColor.rgb;
#endif
#ifdef USE_BATCHING_COLOR
	vColor *= getBatchingColor( getIndirectIndex( gl_DrawID ) );
#endif`,og=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
#define inverseTransformDirection transformDirectionByInverseViewMatrix
vec3 transformNormalByInverseViewMatrix( in vec3 normal, in mat4 viewMatrix ) {
	return normalize( ( vec4( normal, 0.0 ) * viewMatrix ).xyz );
}
vec3 transformDirectionByInverseViewMatrix( in vec3 dir, in mat4 viewMatrix ) {
	return normalize( ( vec4( dir, 0.0 ) * viewMatrix ).xyz );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,lg=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
#endif`,cg=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,dg=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,hg=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,ug=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,fg="gl_FragColor = linearToOutputTexel( gl_FragColor );",pg=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,mg=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * reflectVec );
		#ifdef ENVMAP_BLENDING_MULTIPLY
			outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_MIX )
			outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_ADD )
			outgoingLight += envColor.xyz * specularStrength * reflectivity;
		#endif
	#endif
#endif`,gg=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform mat3 envMapRotation;
	uniform samplerCube envMap;
	#ifdef ENVMAP_TYPE_PMREM
		float roughnessToMip( const in float roughness ) {
			float r = clamp( roughness, 0.0, 1.0 );
			return ENVMAP_MAX_LOD * r * ( 2.0 - r );
		}
	#endif
#endif`,vg=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,xg=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,yg=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,bg=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,_g=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,Mg=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,Sg=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,wg=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,Eg=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,Ag=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,Tg=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,Rg=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_SUN_LIGHTS > 0
	struct SunLight {
		vec3 direction;
		vec3 color;
	};
	uniform SunLight sunLights[ NUM_SUN_LIGHTS ];
	void getSunLightInfo( const in SunLight sunLight, out IncidentLight light ) {
		light.color = sunLight.color;
		light.direction = sunLight.direction;
		light.visible = true;
	}
#endif
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif
#include <lightprobes_pars_fragment>`,Cg=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_PMREM
			vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
			vec4 envMapColor = textureLod( envMap, envMapRotation * worldNormal, ENVMAP_MAX_LOD );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_PMREM
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, pow4( roughness ) ) );
			reflectVec = transformDirectionByInverseViewMatrix( reflectVec, viewMatrix );
			vec4 envMapColor = textureLod( envMap, envMapRotation * reflectVec, roughnessToMip( roughness ) );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_RETROREFLECTION
		vec3 getIBLRetroRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
			#ifdef ENVMAP_TYPE_PMREM
				vec3 retroVec = normalize( mix( viewDir, normal, pow4( roughness ) ) );
				retroVec = transformDirectionByInverseViewMatrix( retroVec, viewMatrix );
				vec4 envMapColor = textureLod( envMap, envMapRotation * retroVec, roughnessToMip( roughness ) );
				return envMapColor.rgb * envMapIntensity;
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_PMREM
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
		#ifdef USE_RETROREFLECTION
			vec3 getIBLAnisotropyRetroRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
				#ifdef ENVMAP_TYPE_PMREM
					vec3 bentNormal = cross( bitangent, viewDir );
					bentNormal = normalize( cross( bentNormal, bitangent ) );
					bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
					return getIBLRetroRadiance( viewDir, bentNormal, roughness );
				#else
					return vec3( 0.0 );
				#endif
			}
		#endif
	#endif
#endif`,Pg=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,Lg=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,Dg=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,Ig=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,Ng=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.diffuseContribution = diffuseColor.rgb * ( 1.0 - metalnessFactor );
material.metalness = metalnessFactor;
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.045 );
material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef USE_DIFFUSE_ROUGHNESS
	float diffuseRoughnessFactor = diffuseRoughness;
	#ifdef USE_DIFFUSE_ROUGHNESSMAP
		diffuseRoughnessFactor *= texture2D( diffuseRoughnessMap, vDiffuseRoughnessMapUv ).r;
	#endif
	material.diffuseRoughness = saturate( diffuseRoughnessFactor );
#endif
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor;
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = vec3( 0.04 );
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.045 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_RETROREFLECTION
	material.retroreflectivity = retroreflectivity;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.0001, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,Ug=`uniform sampler2D dfgLUT;
struct PhysicalMaterial {
	vec3 diffuseColor;
	vec3 diffuseContribution;
	vec3 specularColor;
	vec3 specularColorBlended;
	float roughness;
	float metalness;
	float specularF90;
	float dispersion;
	vec2 dfg;
	vec3 multiScatteringCompensation;
	#ifdef USE_DIFFUSE_ROUGHNESS
		float diffuseRoughness;
	#endif
	#ifdef USE_RETROREFLECTION
		float retroreflectivity;
	#endif
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0Dielectric;
		vec3 iridescenceF0Metallic;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
#ifdef USE_DIFFUSE_ROUGHNESS
	const float EON_EPSILON = 1e-7;
	float FON_DirectionalAlbedo( const in float mu, const in float roughness, const in float A ) {
		float muComp = 1.0 - mu;
		float gOverPi = muComp * ( 0.0571085289 + muComp * ( 0.491881867 + muComp * ( - 0.332181442 + muComp * 0.0714429953 ) ) );
		return A * ( 1.0 + roughness * gOverPi );
	}
	vec3 BRDF_EON( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 diffuseColor, const in float roughness ) {
		vec3 rho = saturate( diffuseColor );
		if ( roughness <= EON_EPSILON ) return BRDF_Lambert( rho );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float s = dot( lightDir, viewDir ) - dotNL * dotNV;
		float sOverT = ( s > 0.0 ) ? s / max( max( dotNL, dotNV ), EON_EPSILON ) : s;
		float A = 1.0 / ( 1.0 + ( 0.5 - 2.0 / ( 3.0 * PI ) ) * roughness );
		vec3 singleScatter = rho * RECIPROCAL_PI * A * ( 1.0 + roughness * sOverT );
		float averageAlbedo = A * ( 1.0 + ( 2.0 / 3.0 - 28.0 / ( 15.0 * PI ) ) * roughness );
		float albedoV = FON_DirectionalAlbedo( dotNV, roughness, A );
		float albedoL = FON_DirectionalAlbedo( dotNL, roughness, A );
		vec3 rhoMultiScatter = rho * rho * averageAlbedo / max( vec3( EON_EPSILON ), vec3( 1.0 ) - rho * ( 1.0 - averageAlbedo ) );
		vec3 multiScatter = rhoMultiScatter * RECIPROCAL_PI
			* max( EON_EPSILON, 1.0 - albedoV )
			* max( EON_EPSILON, 1.0 - albedoL )
			/ max( EON_EPSILON, 1.0 - averageAlbedo );
		return singleScatter + multiScatter;
	}
	vec3 EON_DirectionalAlbedo( const in vec3 diffuseColor, const in float roughness, const in float dotNV ) {
		vec3 rho = saturate( diffuseColor );
		if ( roughness <= EON_EPSILON ) return rho;
		float A = 1.0 / ( 1.0 + ( 0.5 - 2.0 / ( 3.0 * PI ) ) * roughness );
		float directionalAlbedo = FON_DirectionalAlbedo( dotNV, roughness, A );
		float averageAlbedo = A * ( 1.0 + ( 2.0 / 3.0 - 28.0 / ( 15.0 * PI ) ) * roughness );
		vec3 rhoMultiScatter = rho * rho * averageAlbedo / max( vec3( EON_EPSILON ), vec3( 1.0 ) - rho * ( 1.0 - averageAlbedo ) );
		return rho * directionalAlbedo + rhoMultiScatter * ( 1.0 - directionalAlbedo );
	}
#endif
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		return 0.5 / max( gv + gl, EPSILON );
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = max( material.clearcoatRoughness, 0.045 );
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColorBlended;
	float f90 = material.specularF90;
	float roughness = max( material.roughness, 0.045 );
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float alphaT = max( material.alphaT, alpha );
		float V = V_GGX_SmithCorrelated_Anisotropic( alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transpose( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float rInv = 1.0 / ( roughness + 0.1 );
	float a = -1.9362 + 1.0678 * roughness + 0.4573 * r2 - 0.8469 * rInv;
	float b = -0.6014 + 0.5538 * roughness - 0.4670 * r2 - 0.1255 * rInv;
	float DG = exp( a * dotNV + b );
	return saturate( DG );
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec2 fab, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec2 fab, const in vec3 specularColor, const in float specularF90, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColorBlended * t2.x + ( material.specularF90 - material.specularColorBlended ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseContribution * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
		#ifdef USE_CLEARCOAT
			vec3 Ncc = geometryClearcoatNormal;
			vec2 uvClearcoat = LTC_Uv( Ncc, viewDir, material.clearcoatRoughness );
			vec4 t1Clearcoat = texture2D( ltc_1, uvClearcoat );
			vec4 t2Clearcoat = texture2D( ltc_2, uvClearcoat );
			mat3 mInvClearcoat = mat3(
				vec3( t1Clearcoat.x, 0, t1Clearcoat.y ),
				vec3(             0, 1,             0 ),
				vec3( t1Clearcoat.z, 0, t1Clearcoat.w )
			);
			vec3 fresnelClearcoat = material.clearcoatF0 * t2Clearcoat.x + ( material.clearcoatF90 - material.clearcoatF0 ) * t2Clearcoat.y;
			clearcoatSpecularDirect += lightColor * fresnelClearcoat * LTC_Evaluate( Ncc, viewDir, position, mInvClearcoat, rectCoords );
		#endif
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
 
 		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
 
 		float sheenAlbedoV = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
 		float sheenAlbedoL = IBLSheenBRDF( geometryNormal, directLight.direction, material.sheenRoughness );
 
 		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * max( sheenAlbedoV, sheenAlbedoL );
 
 		irradiance *= sheenEnergyComp;
 
 	#endif
	vec3 specularBRDF = BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	#ifdef USE_RETROREFLECTION
		vec3 retroViewDir = reflect( - geometryViewDir, geometryNormal );
		vec3 retroSpecularBRDF = BRDF_GGX( directLight.direction, retroViewDir, geometryNormal, material );
		specularBRDF = mix( specularBRDF, retroSpecularBRDF, saturate( material.retroreflectivity ) );
	#endif
	reflectedLight.directSpecular += irradiance * specularBRDF * material.multiScatteringCompensation;
	vec3 halfDir = normalize( directLight.direction + geometryViewDir );
	float dotVH = saturate( dot( geometryViewDir, halfDir ) );
	vec3 F = F_Schlick( material.specularColor, material.specularF90, dotVH );
	#ifdef USE_RETROREFLECTION
		vec3 retroHalfDir = normalize( directLight.direction + retroViewDir );
		float dotRetroVH = saturate( dot( retroViewDir, retroHalfDir ) );
		vec3 retroF = F_Schlick( material.specularColor, material.specularF90, dotRetroVH );
		F = mix( F, retroF, saturate( material.retroreflectivity ) );
	#endif
	#ifdef USE_DIFFUSE_ROUGHNESS
		vec3 diffuseBRDF = BRDF_EON( directLight.direction, geometryViewDir, geometryNormal, material.diffuseColor, material.diffuseRoughness ) * ( 1.0 - material.metalness );
	#else
		vec3 diffuseBRDF = BRDF_Lambert( material.diffuseContribution );
	#endif
	reflectedLight.directDiffuse += irradiance * diffuseBRDF * ( 1.0 - F );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( material.dfg, material.specularColor, material.specularF90, material.iridescence, material.iridescenceF0Dielectric, singleScattering, multiScattering );
	#else
		computeMultiscattering( material.dfg, material.specularColor, material.specularF90, singleScattering, multiScattering );
	#endif
	#ifdef USE_DIFFUSE_ROUGHNESS
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		vec3 diffuseAlbedo = EON_DirectionalAlbedo( material.diffuseColor, material.diffuseRoughness, dotNV ) * ( 1.0 - material.metalness );
		vec3 diffuse = irradiance * RECIPROCAL_PI * diffuseAlbedo * ( 1.0 - singleScattering - multiScattering );
	#else
		vec3 diffuse = irradiance * BRDF_Lambert( material.diffuseContribution ) * ( 1.0 - singleScattering - multiScattering );
	#endif
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		sheenSpecularIndirect += irradiance * material.sheenColor * sheenAlbedo * RECIPROCAL_PI;
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		diffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectDiffuse += diffuse;
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness ) * RECIPROCAL_PI;
 	#endif
	vec3 singleScatteringDielectric = vec3( 0.0 );
	vec3 multiScatteringDielectric = vec3( 0.0 );
	vec3 singleScatteringMetallic = vec3( 0.0 );
	vec3 multiScatteringMetallic = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( material.dfg, material.specularColor, material.specularF90, material.iridescence, material.iridescenceF0Dielectric, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscatteringIridescence( material.dfg, material.diffuseColor, material.specularF90, material.iridescence, material.iridescenceF0Metallic, singleScatteringMetallic, multiScatteringMetallic );
	#else
		computeMultiscattering( material.dfg, material.specularColor, material.specularF90, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscattering( material.dfg, material.diffuseColor, material.specularF90, singleScatteringMetallic, multiScatteringMetallic );
	#endif
	vec3 singleScattering = mix( singleScatteringDielectric, singleScatteringMetallic, material.metalness );
	vec3 multiScattering = mix( multiScatteringDielectric, multiScatteringMetallic, material.metalness );
	vec3 totalScatteringDielectric = singleScatteringDielectric + multiScatteringDielectric;
	#ifdef USE_DIFFUSE_ROUGHNESS
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		vec3 diffuse = EON_DirectionalAlbedo( material.diffuseColor, material.diffuseRoughness, dotNV ) * ( 1.0 - material.metalness ) * ( 1.0 - totalScatteringDielectric );
	#else
		vec3 diffuse = material.diffuseContribution * ( 1.0 - totalScatteringDielectric );
	#endif
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	vec3 indirectSpecular = radiance * singleScattering;
	indirectSpecular += multiScattering * cosineWeightedIrradiance;
	vec3 indirectDiffuse = diffuse * cosineWeightedIrradiance;
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		indirectSpecular *= sheenEnergyComp;
		indirectDiffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectSpecular += indirectSpecular;
	reflectedLight.indirectDiffuse += indirectDiffuse;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,Fg=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		vec3 iridescenceFresnelDielectric = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		vec3 iridescenceFresnelMetallic = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.diffuseColor );
		material.iridescenceFresnel = mix( iridescenceFresnelDielectric, iridescenceFresnelMetallic, material.metalness );
		material.iridescenceF0Dielectric = Schlick_to_F0( iridescenceFresnelDielectric, 1.0, dotNVi );
		material.iridescenceF0Metallic = Schlick_to_F0( iridescenceFresnelMetallic, 1.0, dotNVi );
	}
#endif
#ifdef STANDARD
	float dotNVms = saturate( dot( geometryNormal, geometryViewDir ) );
	material.dfg = texture2D( dfgLUT, vec2( material.roughness, dotNVms ) ).rg;
	#if ( NUM_SUN_LIGHTS > 0 || NUM_DIR_LIGHTS > 0 || NUM_POINT_LIGHTS > 0 || NUM_SPOT_LIGHTS > 0 )
		float EssMs = material.dfg.x + material.dfg.y;
		material.multiScatteringCompensation = 1.0 + material.specularColorBlended * ( 1.0 / EssMs - 1.0 );
	#endif
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS ) && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SUN_LIGHTS > 0 ) && defined( RE_Direct )
	SunLight sunLight;
	#if defined( USE_SHADOWMAP ) && NUM_SUN_LIGHT_SHADOWS > 0
	SunLightShadow sunLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SUN_LIGHTS; i ++ ) {
		sunLight = sunLights[ i ];
		getSunLightInfo( sunLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SUN_LIGHT_SHADOWS )
		sunLightShadow = sunLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getSunShadow( sunShadowMap[ i ], sunLightShadow, UNROLLED_LOOP_INDEX ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_LIGHT_PROBE_GRIDS > 0
		vec3 probeWorldPos = ( ( vec4( geometryPosition, 1.0 ) - viewMatrix[ 3 ] ) * viewMatrix ).xyz;
		vec3 probeWorldNormal = transformNormalByInverseViewMatrix( geometryNormal, viewMatrix );
		int probeGrid = - 1;
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_LIGHT_PROBE_GRIDS; i ++ ) {
			if ( isInsideLightProbeGrid( probeWorldPos, probeWorldNormal, probesMin[ i ], probesMax[ i ], probesResolution[ i ] ) ) probeGrid = UNROLLED_LOOP_INDEX;
		}
		#pragma unroll_loop_end
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_LIGHT_PROBE_GRIDS; i ++ ) {
			if ( probeGrid == UNROLLED_LOOP_INDEX ) irradiance += getLightProbeGridIrradiance( probesSH[ i ], probesMin[ i ], probesMax[ i ], probesResolution[ i ], probeWorldPos, probeWorldNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,Og=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( ENVMAP_TYPE_PMREM )
		#if defined( STANDARD ) || defined( LAMBERT ) || defined( PHONG )
			iblIrradiance += getIBLIrradiance( geometryNormal );
		#endif
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		vec3 iblRadiance = getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		vec3 iblRadiance = getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_RETROREFLECTION
		#ifdef USE_ANISOTROPY
			vec3 retroIBLRadiance = getIBLAnisotropyRetroRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
		#else
			vec3 retroIBLRadiance = getIBLRetroRadiance( geometryViewDir, geometryNormal, material.roughness );
		#endif
		iblRadiance = mix( iblRadiance, retroIBLRadiance, saturate( material.retroreflectivity ) );
	#endif
	radiance += iblRadiance;
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,Bg=`#if defined( RE_IndirectDiffuse )
	#if defined( LAMBERT ) || defined( PHONG )
		irradiance += iblIrradiance;
	#endif
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,kg=`#if NUM_LIGHT_PROBE_GRIDS > 0
uniform highp sampler3D probesSH[ NUM_LIGHT_PROBE_GRIDS ];
uniform vec3 probesMin[ NUM_LIGHT_PROBE_GRIDS ];
uniform vec3 probesMax[ NUM_LIGHT_PROBE_GRIDS ];
uniform vec3 probesResolution[ NUM_LIGHT_PROBE_GRIDS ];
bool isInsideLightProbeGrid( vec3 worldPos, vec3 worldNormal, vec3 probesMin, vec3 probesMax, vec3 probesResolution ) {
	vec3 spacing = ( probesMax - probesMin ) / probesResolution;
	vec3 samplePos = worldPos + worldNormal * spacing * 0.5;
	vec3 margin = spacing * 0.01;
	return all( greaterThanEqual( samplePos, probesMin - margin ) ) && all( lessThanEqual( samplePos, probesMax + margin ) );
}
vec3 getLightProbeGridIrradiance( highp sampler3D probesSH, vec3 probesMin, vec3 probesMax, vec3 probesResolution, vec3 worldPos, vec3 worldNormal ) {
	vec3 res = probesResolution;
	vec3 gridRange = probesMax - probesMin;
	vec3 probeSpacing = gridRange / res;
	vec3 samplePos = worldPos + worldNormal * probeSpacing * 0.5;
	vec3 uvw = clamp( ( samplePos - probesMin ) / gridRange, 0.5 / res, 1.0 - 0.5 / res );
	float nz          = res.z;
	float paddedSlices = nz + 2.0;
	float atlasDepth  = 7.0 * paddedSlices;
	float uvZBase     = uvw.z * nz + 1.0;
	vec4 s0 = texture( probesSH, vec3( uvw.xy, ( uvZBase                       ) / atlasDepth ) );
	vec4 s1 = texture( probesSH, vec3( uvw.xy, ( uvZBase +       paddedSlices   ) / atlasDepth ) );
	vec4 s2 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 2.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s3 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 3.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s4 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 4.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s5 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 5.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s6 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 6.0 * paddedSlices   ) / atlasDepth ) );
	vec3 c0 = s0.xyz;
	vec3 c1 = vec3( s0.w, s1.xy );
	vec3 c2 = vec3( s1.zw, s2.x );
	vec3 c3 = s2.yzw;
	vec3 c4 = s3.xyz;
	vec3 c5 = vec3( s3.w, s4.xy );
	vec3 c6 = vec3( s4.zw, s5.x );
	vec3 c7 = s5.yzw;
	vec3 c8 = s6.xyz;
	float x = worldNormal.x, y = worldNormal.y, z = worldNormal.z;
	vec3 result = c0 * 0.886227;
	result += c1 * 2.0 * 0.511664 * y;
	result += c2 * 2.0 * 0.511664 * z;
	result += c3 * 2.0 * 0.511664 * x;
	result += c4 * 2.0 * 0.429043 * x * y;
	result += c5 * 2.0 * 0.429043 * y * z;
	result += c6 * ( 0.743125 * z * z - 0.247708 );
	result += c7 * 2.0 * 0.429043 * x * z;
	result += c8 * 0.429043 * ( x * x - y * y );
	return max( result, vec3( 0.0 ) );
}
#endif`,zg=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,$g=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,Hg=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,Gg=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,Vg=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,Wg=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,Xg=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,qg=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Yg=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,Kg=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,Zg=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,Jg=`#if defined( USE_MORPHCOLORS )
	#if defined( USE_COLOR_ALPHA )
		vColor *= morphTargetBaseInfluence;
	#elif defined( USE_COLOR )
		vColor.rgb *= morphTargetBaseInfluence;
	#endif
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor.rgb += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,jg=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,Qg=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,tv=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,ev=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#ifdef DOUBLE_SIDED
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#ifdef DOUBLE_SIDED
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,nv=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#if defined( USE_PACKED_NORMALMAP )
		mapN = vec3( mapN.xy, sqrt( saturate( 1.0 - dot( mapN.xy, mapN.xy ) ) ) );
	#endif
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,iv=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,sv=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,av=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
		#ifdef FLIP_SIDED
			vBitangent = - vBitangent;
		#endif
	#endif
#endif`,rv=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,ov=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,lv=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,cv=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,dv=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,hv=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,uv=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	#ifdef USE_REVERSED_DEPTH_BUFFER
	
		return depth * ( far - near ) - far;
	#else
		return depth * ( near - far ) - near;
	#endif
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	
	#ifdef USE_REVERSED_DEPTH_BUFFER
		return ( near * far ) / ( ( near - far ) * depth - near );
	#else
		return ( near * far ) / ( ( far - near ) * depth - far );
	#endif
}`,fv=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,pv=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,mv=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,gv=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,vv=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,xv=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,yv=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
		#define SUN_LIGHT_CASCADES 2
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow sunShadowMap[ NUM_SUN_LIGHT_SHADOWS ];
		#else
			uniform sampler2D sunShadowMap[ NUM_SUN_LIGHT_SHADOWS ];
		#endif
		uniform mat4 sunShadowMatrix[ NUM_SUN_LIGHT_SHADOWS * SUN_LIGHT_CASCADES ];
		uniform vec4 sunShadowCascade[ NUM_SUN_LIGHT_SHADOWS * SUN_LIGHT_CASCADES ];
		varying vec4 vSunShadowWorldPosition;
		varying vec3 vSunShadowWorldNormal;
		struct SunLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SunLightShadow sunLightShadows[ NUM_SUN_LIGHT_SHADOWS ];
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#else
			uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#endif
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#else
			uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#endif
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform samplerCubeShadow pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#elif defined( SHADOWMAP_TYPE_BASIC )
			uniform samplerCube pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#endif
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float interleavedGradientNoise( vec2 position ) {
			return fract( 52.9829189 * fract( dot( position, vec2( 0.06711056, 0.00583715 ) ) ) );
		}
		vec2 vogelDiskSample( int sampleIndex, int samplesCount, float phi ) {
			const float goldenAngle = 2.399963229728653;
			float r = sqrt( ( float( sampleIndex ) + 0.5 ) / float( samplesCount ) );
			float theta = float( sampleIndex ) * goldenAngle + phi;
			return vec2( cos( theta ), sin( theta ) ) * r;
		}
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float getShadow( sampler2DShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
				vec2 radius = shadowRadius * texelSize;
				float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
				shadow = (
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 0, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 1, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 2, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 3, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 4, 5, phi ) * radius, shadowCoord.z ) )
				) * 0.2;
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#elif defined( SHADOWMAP_TYPE_VSM )
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 distribution = texture2D( shadowMap, shadowCoord.xy ).rg;
				float mean = distribution.x;
				float variance = distribution.y * distribution.y;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					float hard_shadow = step( mean, shadowCoord.z );
				#else
					float hard_shadow = step( shadowCoord.z, mean );
				#endif
				
				if ( hard_shadow == 1.0 ) {
					shadow = 1.0;
				} else {
					variance = max( variance, 0.0000001 );
					float d = shadowCoord.z - mean;
					float p_max = variance / ( variance + d * d );
					p_max = clamp( ( p_max - 0.3 ) / 0.65, 0.0, 1.0 );
					shadow = max( hard_shadow, p_max );
				}
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#else
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				float depth = texture2D( shadowMap, shadowCoord.xy ).r;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					shadow = step( depth, shadowCoord.z );
				#else
					shadow = step( shadowCoord.z, depth );
				#endif
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#endif
	#if NUM_SUN_LIGHT_SHADOWS > 0
		float getSunShadow(
			#if defined( SHADOWMAP_TYPE_PCF )
				sampler2DShadow shadowMap,
			#else
				sampler2D shadowMap,
			#endif
			SunLightShadow sunLightShadow,
			int shadowIndex
		) {
			vec4 shadowWorldPosition = vec4( vSunShadowWorldPosition.xyz + vSunShadowWorldNormal * sunLightShadow.shadowNormalBias, 1.0 );
			float viewDepth = vSunShadowWorldPosition.w;
			int cascadeOffset = shadowIndex * SUN_LIGHT_CASCADES;
			float shadow = 1.0;
			for ( int i = SUN_LIGHT_CASCADES - 1; i >= 0; i -- ) {
				vec4 cascade = sunShadowCascade[ cascadeOffset + i ];
				if ( viewDepth >= cascade.x && viewDepth < cascade.y ) {
					float cascadeShadow = getShadow(
						shadowMap,
						sunLightShadow.shadowMapSize,
						sunLightShadow.shadowIntensity,
						sunLightShadow.shadowBias,
						sunLightShadow.shadowRadius,
						sunShadowMatrix[ cascadeOffset + i ] * shadowWorldPosition
					);
					shadow = mix( cascadeShadow, shadow, smoothstep( cascade.z, cascade.y, viewDepth ) );
				}
			}
			return shadow;
		}
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	#if defined( SHADOWMAP_TYPE_PCF )
	float getPointShadow( samplerCubeShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 bd3D = normalize( lightToPosition );
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			float lightDistance = length( lightToPosition );
			float depthRange = shadowCameraFar - shadowCameraNear;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				float depthA = - shadowCameraNear / depthRange - shadowBias;
				float depthB = shadowCameraNear * shadowCameraFar / ( depthRange * lightDistance );
			#else
				float depthA = shadowCameraFar / depthRange + shadowBias;
				float depthB = - shadowCameraNear * shadowCameraFar / ( depthRange * lightDistance );
			#endif
			float texelSize = shadowRadius / shadowMapSize.x;
			vec3 absDir = abs( bd3D );
			vec3 tangent = absDir.x > absDir.z ? vec3( 0.0, 1.0, 0.0 ) : vec3( 1.0, 0.0, 0.0 );
			tangent = normalize( cross( bd3D, tangent ) );
			vec3 bitangent = cross( bd3D, tangent );
			float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
			shadow = 0.0;
			for ( int i = 0; i < 5; i ++ ) {
				vec2 offset = vogelDiskSample( i, 5, phi );
				vec3 direction = bd3D + ( tangent * offset.x + bitangent * offset.y ) * texelSize;
				vec3 absDirection = abs( direction );
				float dp = depthA + depthB / max( max( absDirection.x, absDirection.y ), absDirection.z );
				shadow += texture( shadowMap, vec4( direction, dp ) );
			}
			shadow *= 0.2;
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#elif defined( SHADOWMAP_TYPE_BASIC )
	float getPointShadow( samplerCube shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			float depth = textureCube( shadowMap, bd3D ).r;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				depth = 1.0 - depth;
			#endif
			shadow = step( dp, depth );
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#endif
	#endif
#endif`,bv=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
		varying vec4 vSunShadowWorldPosition;
		varying vec3 vSunShadowWorldNormal;
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,_v=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_SUN_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	#ifdef HAS_NORMAL
		vec3 shadowWorldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
	#else
		vec3 shadowWorldNormal = vec3( 0.0 );
	#endif
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_SUN_LIGHT_SHADOWS > 0
		vSunShadowWorldPosition = vec4( worldPosition.xyz, - mvPosition.z );
		vSunShadowWorldNormal = shadowWorldNormal;
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,Mv=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
	SunLightShadow sunLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SUN_LIGHT_SHADOWS; i ++ ) {
		sunLight = sunLightShadows[ i ];
		shadow *= receiveShadow ? getSunShadow( sunShadowMap[ i ], sunLight, UNROLLED_LOOP_INDEX ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0 && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,Sv=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,wv=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,Ev=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,Av=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,Tv=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,Rv=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,Cv=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,Pv=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,Lv=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseContribution, material.specularColorBlended, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,Dv=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,Iv=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_DIFFUSE_ROUGHNESSMAP
	varying vec2 vDiffuseRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Nv=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_DIFFUSE_ROUGHNESSMAP
	uniform mat3 diffuseRoughnessMapTransform;
	varying vec2 vDiffuseRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Uv=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DIFFUSE_ROUGHNESSMAP
	vDiffuseRoughnessMapUv = ( diffuseRoughnessMapTransform * vec3( DIFFUSE_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,Fv=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const Ov=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,Bv=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,kv=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,zv=`uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <envmap_common_pars_fragment>
void main() {
	#ifdef ENVMAP_TYPE_PMREM
		vec4 texColor = textureLod( envMap, backgroundRotation * vWorldDirection, roughnessToMip( backgroundBlurriness ) );
	#else
		vec4 texColor = textureCube( envMap, backgroundRotation * vWorldDirection );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,$v=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Hv=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Gv=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,Vv=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,Wv=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,Xv=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = vec4( dist, 0.0, 0.0, 1.0 );
}`,qv=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,Yv=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Kv=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Zv=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Jv=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,jv=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Qv=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,tx=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,ex=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,nx=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,ix=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,sx=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( normalize( normal ) * 0.5 + 0.5, diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,ax=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,rx=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,ox=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,lx=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DIFFUSE_ROUGHNESS
	uniform float diffuseRoughness;
	#ifdef USE_DIFFUSE_ROUGHNESSMAP
		uniform sampler2D diffuseRoughnessMap;
	#endif
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_RETROREFLECTION
	uniform float retroreflectivity;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
 
		outgoingLight = outgoingLight + sheenSpecularDirect + sheenSpecularIndirect;
 
 	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,cx=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,dx=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,hx=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,ux=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,fx=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,px=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,mx=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,gx=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Xt={alphahash_fragment:B0,alphahash_pars_fragment:k0,alphamap_fragment:z0,alphamap_pars_fragment:$0,alphatest_fragment:H0,alphatest_pars_fragment:G0,aomap_fragment:V0,aomap_pars_fragment:W0,batching_pars_vertex:X0,batching_vertex:q0,begin_vertex:Y0,beginnormal_vertex:K0,bsdfs:Z0,iridescence_fragment:J0,bumpmap_pars_fragment:j0,clipping_planes_fragment:Q0,clipping_planes_pars_fragment:tg,clipping_planes_pars_vertex:eg,clipping_planes_vertex:ng,color_fragment:ig,color_pars_fragment:sg,color_pars_vertex:ag,color_vertex:rg,common:og,defaultnormal_vertex:lg,displacementmap_pars_vertex:cg,displacementmap_vertex:dg,emissivemap_fragment:hg,emissivemap_pars_fragment:ug,colorspace_fragment:fg,colorspace_pars_fragment:pg,envmap_fragment:mg,envmap_common_pars_fragment:gg,envmap_pars_fragment:vg,envmap_pars_vertex:xg,envmap_physical_pars_fragment:Cg,envmap_vertex:yg,fog_vertex:bg,fog_pars_vertex:_g,fog_fragment:Mg,fog_pars_fragment:Sg,gradientmap_pars_fragment:wg,lightmap_pars_fragment:Eg,lights_lambert_fragment:Ag,lights_lambert_pars_fragment:Tg,lights_pars_begin:Rg,lights_toon_fragment:Pg,lights_toon_pars_fragment:Lg,lights_phong_fragment:Dg,lights_phong_pars_fragment:Ig,lights_physical_fragment:Ng,lights_physical_pars_fragment:Ug,lights_fragment_begin:Fg,lights_fragment_maps:Og,lights_fragment_end:Bg,lightprobes_pars_fragment:kg,logdepthbuf_fragment:zg,logdepthbuf_pars_fragment:$g,logdepthbuf_pars_vertex:Hg,logdepthbuf_vertex:Gg,map_fragment:Vg,map_pars_fragment:Wg,map_particle_fragment:Xg,map_particle_pars_fragment:qg,metalnessmap_fragment:Yg,metalnessmap_pars_fragment:Kg,morphinstance_vertex:Zg,morphcolor_vertex:Jg,morphnormal_vertex:jg,morphtarget_pars_vertex:Qg,morphtarget_vertex:tv,normal_fragment_begin:ev,normal_fragment_maps:nv,normal_pars_fragment:iv,normal_pars_vertex:sv,normal_vertex:av,normalmap_pars_fragment:rv,clearcoat_normal_fragment_begin:ov,clearcoat_normal_fragment_maps:lv,clearcoat_pars_fragment:cv,iridescence_pars_fragment:dv,opaque_fragment:hv,packing:uv,premultiplied_alpha_fragment:fv,project_vertex:pv,dithering_fragment:mv,dithering_pars_fragment:gv,roughnessmap_fragment:vv,roughnessmap_pars_fragment:xv,shadowmap_pars_fragment:yv,shadowmap_pars_vertex:bv,shadowmap_vertex:_v,shadowmask_pars_fragment:Mv,skinbase_vertex:Sv,skinning_pars_vertex:wv,skinning_vertex:Ev,skinnormal_vertex:Av,specularmap_fragment:Tv,specularmap_pars_fragment:Rv,tonemapping_fragment:Cv,tonemapping_pars_fragment:Pv,transmission_fragment:Lv,transmission_pars_fragment:Dv,uv_pars_fragment:Iv,uv_pars_vertex:Nv,uv_vertex:Uv,worldpos_vertex:Fv,background_vert:Ov,background_frag:Bv,backgroundCube_vert:kv,backgroundCube_frag:zv,cube_vert:$v,cube_frag:Hv,depth_vert:Gv,depth_frag:Vv,distance_vert:Wv,distance_frag:Xv,equirect_vert:qv,equirect_frag:Yv,linedashed_vert:Kv,linedashed_frag:Zv,meshbasic_vert:Jv,meshbasic_frag:jv,meshlambert_vert:Qv,meshlambert_frag:tx,meshmatcap_vert:ex,meshmatcap_frag:nx,meshnormal_vert:ix,meshnormal_frag:sx,meshphong_vert:ax,meshphong_frag:rx,meshphysical_vert:ox,meshphysical_frag:lx,meshtoon_vert:cx,meshtoon_frag:dx,points_vert:hx,points_frag:ux,shadow_vert:fx,shadow_frag:px,sprite_vert:mx,sprite_frag:gx},vt={common:{diffuse:{value:new Rt(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new Bt},alphaMap:{value:null},alphaMapTransform:{value:new Bt},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new Bt}},envmap:{envMap:{value:null},envMapRotation:{value:new Bt},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98},dfgLUT:{value:null}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new Bt}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new Bt}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new Bt},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new Bt},normalScale:{value:new It(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new Bt},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new Bt}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new Bt}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new Bt}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new Rt(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},sunLights:{value:[],properties:{direction:{},color:{}}},sunLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},sunShadowMatrix:{value:[]},sunShadowCascade:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null},probesSH:{value:[]},probesMin:{value:[]},probesMax:{value:[]},probesResolution:{value:[]}},points:{diffuse:{value:new Rt(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new Bt},alphaTest:{value:0},uvTransform:{value:new Bt}},sprite:{diffuse:{value:new Rt(16777215)},opacity:{value:1},center:{value:new It(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new Bt},alphaMap:{value:null},alphaMapTransform:{value:new Bt},alphaTest:{value:0}}},ci={basic:{uniforms:un([vt.common,vt.specularmap,vt.envmap,vt.aomap,vt.lightmap,vt.fog]),vertexShader:Xt.meshbasic_vert,fragmentShader:Xt.meshbasic_frag},lambert:{uniforms:un([vt.common,vt.specularmap,vt.envmap,vt.aomap,vt.lightmap,vt.emissivemap,vt.bumpmap,vt.normalmap,vt.displacementmap,vt.fog,vt.lights,{emissive:{value:new Rt(0)},envMapIntensity:{value:1}}]),vertexShader:Xt.meshlambert_vert,fragmentShader:Xt.meshlambert_frag},phong:{uniforms:un([vt.common,vt.specularmap,vt.envmap,vt.aomap,vt.lightmap,vt.emissivemap,vt.bumpmap,vt.normalmap,vt.displacementmap,vt.fog,vt.lights,{emissive:{value:new Rt(0)},specular:{value:new Rt(1118481)},shininess:{value:30},envMapIntensity:{value:1}}]),vertexShader:Xt.meshphong_vert,fragmentShader:Xt.meshphong_frag},standard:{uniforms:un([vt.common,vt.envmap,vt.aomap,vt.lightmap,vt.emissivemap,vt.bumpmap,vt.normalmap,vt.displacementmap,vt.roughnessmap,vt.metalnessmap,vt.fog,vt.lights,{emissive:{value:new Rt(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:Xt.meshphysical_vert,fragmentShader:Xt.meshphysical_frag},toon:{uniforms:un([vt.common,vt.aomap,vt.lightmap,vt.emissivemap,vt.bumpmap,vt.normalmap,vt.displacementmap,vt.gradientmap,vt.fog,vt.lights,{emissive:{value:new Rt(0)}}]),vertexShader:Xt.meshtoon_vert,fragmentShader:Xt.meshtoon_frag},matcap:{uniforms:un([vt.common,vt.bumpmap,vt.normalmap,vt.displacementmap,vt.fog,{matcap:{value:null}}]),vertexShader:Xt.meshmatcap_vert,fragmentShader:Xt.meshmatcap_frag},points:{uniforms:un([vt.points,vt.fog]),vertexShader:Xt.points_vert,fragmentShader:Xt.points_frag},dashed:{uniforms:un([vt.common,vt.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:Xt.linedashed_vert,fragmentShader:Xt.linedashed_frag},depth:{uniforms:un([vt.common,vt.displacementmap]),vertexShader:Xt.depth_vert,fragmentShader:Xt.depth_frag},normal:{uniforms:un([vt.common,vt.bumpmap,vt.normalmap,vt.displacementmap,{opacity:{value:1}}]),vertexShader:Xt.meshnormal_vert,fragmentShader:Xt.meshnormal_frag},sprite:{uniforms:un([vt.sprite,vt.fog]),vertexShader:Xt.sprite_vert,fragmentShader:Xt.sprite_frag},background:{uniforms:{uvTransform:{value:new Bt},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:Xt.background_vert,fragmentShader:Xt.background_frag},backgroundCube:{uniforms:{envMap:{value:null},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new Bt}},vertexShader:Xt.backgroundCube_vert,fragmentShader:Xt.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:Xt.cube_vert,fragmentShader:Xt.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:Xt.equirect_vert,fragmentShader:Xt.equirect_frag},distance:{uniforms:un([vt.common,vt.displacementmap,{referencePosition:{value:new D},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:Xt.distance_vert,fragmentShader:Xt.distance_frag},shadow:{uniforms:un([vt.lights,vt.fog,{color:{value:new Rt(0)},opacity:{value:1}}]),vertexShader:Xt.shadow_vert,fragmentShader:Xt.shadow_frag}};ci.physical={uniforms:un([ci.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new Bt},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new Bt},clearcoatNormalScale:{value:new It(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new Bt},diffuseRoughness:{value:0},diffuseRoughnessMap:{value:null},diffuseRoughnessMapTransform:{value:new Bt},dispersion:{value:0},retroreflectivity:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new Bt},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new Bt},sheen:{value:0},sheenColor:{value:new Rt(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new Bt},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new Bt},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new Bt},transmissionSamplerSize:{value:new It},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new Bt},attenuationDistance:{value:0},attenuationColor:{value:new Rt(0)},specularColor:{value:new Rt(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new Bt},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new Bt},anisotropyVector:{value:new It},anisotropyMap:{value:null},anisotropyMapTransform:{value:new Bt}}]),vertexShader:Xt.meshphysical_vert,fragmentShader:Xt.meshphysical_frag};const Ir={r:0,b:0,g:0},vx=new ee,Wf=new Bt;Wf.set(-1,0,0,0,1,0,0,0,1);function xx(i,t,e,n,s,a){const r=new Rt(0);let o=s===!0?0:1,l,c,d=null,h=0,u=null;function f(y){let A=y.isScene===!0?y.background:null;if(A&&A.isTexture){const b=y.backgroundBlurriness>0;A=t.get(A,b)}return A}function g(y){let A=!1;const b=f(y);b===null?m(r,o):b&&b.isColor&&(m(b,1),A=!0);const w=i.xr.getEnvironmentBlendMode();w==="additive"?e.buffers.color.setClear(0,0,0,1,a):w==="alpha-blend"&&e.buffers.color.setClear(0,0,0,0,a),(i.autoClear||A)&&(e.buffers.depth.setTest(!0),e.buffers.depth.setMask(!0),e.buffers.color.setMask(!0),i.clear(i.autoClearColor,i.autoClearDepth,i.autoClearStencil))}function x(y,A){const b=f(A);b&&b.isCubeTexture?(c===void 0&&(c=new Pt(new ai(1,1,1),new En({name:"BackgroundCubeMaterial",uniforms:oa(ci.backgroundCube.uniforms),vertexShader:ci.backgroundCube.vertexShader,fragmentShader:ci.backgroundCube.fragmentShader,side:en,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),c.geometry.deleteAttribute("normal"),c.geometry.deleteAttribute("uv"),c.onBeforeRender=function(w,E,v){this.matrixWorld.copyPosition(v.matrixWorld)},Object.defineProperty(c.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),n.update(c)),c.material.uniforms.envMap.value=b,c.material.uniforms.backgroundBlurriness.value=A.backgroundBlurriness,c.material.uniforms.backgroundIntensity.value=A.backgroundIntensity,c.material.uniforms.backgroundRotation.value.setFromMatrix4(vx.makeRotationFromEuler(A.backgroundRotation)).transpose(),b.isRenderTargetTexture===!1&&c.material.uniforms.backgroundRotation.value.premultiply(Wf),c.material.toneMapped=te.getTransfer(b.colorSpace)!==le,(d!==b||h!==b.version||u!==i.toneMapping)&&(c.material.needsUpdate=!0,d=b,h=b.version,u=i.toneMapping),c.layers.enableAll(),y.unshift(c,c.geometry,c.material,0,0,null)):b&&b.isTexture&&(l===void 0&&(l=new Pt(new ws(2,2),new En({name:"BackgroundMaterial",uniforms:oa(ci.background.uniforms),vertexShader:ci.background.vertexShader,fragmentShader:ci.background.fragmentShader,side:ps,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),l.geometry.deleteAttribute("normal"),Object.defineProperty(l.material,"map",{get:function(){return this.uniforms.t2D.value}}),n.update(l)),l.material.uniforms.t2D.value=b,l.material.uniforms.backgroundIntensity.value=A.backgroundIntensity,l.material.toneMapped=te.getTransfer(b.colorSpace)!==le,b.matrixAutoUpdate===!0&&b.updateMatrix(),l.material.uniforms.uvTransform.value.copy(b.matrix),(d!==b||h!==b.version||u!==i.toneMapping)&&(l.material.needsUpdate=!0,d=b,h=b.version,u=i.toneMapping),l.layers.enableAll(),y.unshift(l,l.geometry,l.material,0,0,null))}function m(y,A){y.getRGB(Ir,Of(i)),e.buffers.color.setClear(Ir.r,Ir.g,Ir.b,A,a)}function p(){c!==void 0&&(c.geometry.dispose(),c.material.dispose(),c=void 0),l!==void 0&&(l.geometry.dispose(),l.material.dispose(),l=void 0)}return{getClearColor:function(){return r},setClearColor:function(y,A=1){r.set(y),o=A,m(r,o)},getClearAlpha:function(){return o},setClearAlpha:function(y){o=y,m(r,o)},render:g,addToRenderList:x,dispose:p}}function yx(i,t){const e=i.getParameter(i.MAX_VERTEX_ATTRIBS),n={},s=u(null);let a=s,r=!1;function o(N,F,H,L,$){let X=!1;const z=h(N,L,H,F);a!==z&&(a=z,c(a.object)),X=f(N,L,H,$),X&&g(N,L,H,$),$!==null&&t.update($,i.ELEMENT_ARRAY_BUFFER),(X||r)&&(r=!1,b(N,F,H,L),$!==null&&i.bindBuffer(i.ELEMENT_ARRAY_BUFFER,t.get($).buffer))}function l(){return i.createVertexArray()}function c(N){return i.bindVertexArray(N)}function d(N){return i.deleteVertexArray(N)}function h(N,F,H,L){const $=L.wireframe===!0;let X=n[F.id];X===void 0&&(X={},n[F.id]=X);const z=N.isInstancedMesh===!0?N.id:0;let et=X[z];et===void 0&&(et={},X[z]=et);let V=et[H.id];V===void 0&&(V={},et[H.id]=V);let Q=V[$];return Q===void 0&&(Q=u(l()),V[$]=Q),Q}function u(N){const F=[],H=[],L=[];for(let $=0;$<e;$++)F[$]=0,H[$]=0,L[$]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:F,enabledAttributes:H,attributeDivisors:L,object:N,attributes:{},index:null}}function f(N,F,H,L){const $=a.attributes,X=F.attributes;let z=0;const et=H.getAttributes();for(const V in et)if(et[V].location>=0){const nt=$[V];let Et=X[V];if(Et===void 0&&(V==="instanceMatrix"&&N.instanceMatrix&&(Et=N.instanceMatrix),V==="instanceColor"&&N.instanceColor&&(Et=N.instanceColor)),nt===void 0||nt.attribute!==Et||Et&&nt.data!==Et.data)return!0;z++}return a.attributesNum!==z||a.index!==L}function g(N,F,H,L){const $={},X=F.attributes;let z=0;const et=H.getAttributes();for(const V in et)if(et[V].location>=0){let nt=X[V];nt===void 0&&(V==="instanceMatrix"&&N.instanceMatrix&&(nt=N.instanceMatrix),V==="instanceColor"&&N.instanceColor&&(nt=N.instanceColor));const Et={};Et.attribute=nt,nt&&nt.data&&(Et.data=nt.data),$[V]=Et,z++}a.attributes=$,a.attributesNum=z,a.index=L}function x(){const N=a.newAttributes;for(let F=0,H=N.length;F<H;F++)N[F]=0}function m(N){p(N,0)}function p(N,F){const H=a.newAttributes,L=a.enabledAttributes,$=a.attributeDivisors;H[N]=1,L[N]===0&&(i.enableVertexAttribArray(N),L[N]=1),$[N]!==F&&(i.vertexAttribDivisor(N,F),$[N]=F)}function y(){const N=a.newAttributes,F=a.enabledAttributes;for(let H=0,L=F.length;H<L;H++)F[H]!==N[H]&&(i.disableVertexAttribArray(H),F[H]=0)}function A(N,F,H,L,$,X,z){z===!0?i.vertexAttribIPointer(N,F,H,$,X):i.vertexAttribPointer(N,F,H,L,$,X)}function b(N,F,H,L){x();const $=L.attributes,X=H.getAttributes(),z=F.defaultAttributeValues;for(const et in X){const V=X[et];if(V.location>=0){let Q=$[et];if(Q===void 0&&(et==="instanceMatrix"&&N.instanceMatrix&&(Q=N.instanceMatrix),et==="instanceColor"&&N.instanceColor&&(Q=N.instanceColor)),Q!==void 0){const nt=Q.normalized,Et=Q.itemSize,$t=t.get(Q);if($t===void 0)continue;const K=$t.buffer,xt=$t.type,Mt=$t.bytesPerElement,Lt=xt===i.INT||xt===i.UNSIGNED_INT||Q.gpuType===id;if(Q.isInterleavedBufferAttribute){const yt=Q.data,Gt=yt.isInterleavedBuffer===!0?yt.stride:yt.itemSize,Pe=Q.offset;if(yt.isInstancedInterleavedBuffer||yt.isInstancedBufferAttribute){for(let Nt=0;Nt<V.locationSize;Nt++)p(V.location+Nt,yt.meshPerAttribute);N.isInstancedMesh!==!0&&L._maxInstanceCount===void 0&&(L._maxInstanceCount=yt.meshPerAttribute*yt.count)}else for(let Nt=0;Nt<V.locationSize;Nt++)m(V.location+Nt);i.bindBuffer(i.ARRAY_BUFFER,K);for(let Nt=0;Nt<V.locationSize;Nt++)A(V.location+Nt,Et/V.locationSize,xt,nt,Gt*Mt,(Pe+Et/V.locationSize*Nt)*Mt,Lt)}else{if(Q.isInstancedBufferAttribute){for(let yt=0;yt<V.locationSize;yt++)p(V.location+yt,Q.meshPerAttribute);N.isInstancedMesh!==!0&&L._maxInstanceCount===void 0&&(L._maxInstanceCount=Q.meshPerAttribute*Q.count)}else for(let yt=0;yt<V.locationSize;yt++)m(V.location+yt);i.bindBuffer(i.ARRAY_BUFFER,K);for(let yt=0;yt<V.locationSize;yt++)A(V.location+yt,Et/V.locationSize,xt,nt,Et*Mt,Et/V.locationSize*yt*Mt,Lt)}}else if(z!==void 0){const nt=z[et];if(nt!==void 0)switch(nt.length){case 2:i.vertexAttrib2fv(V.location,nt);break;case 3:i.vertexAttrib3fv(V.location,nt);break;case 4:i.vertexAttrib4fv(V.location,nt);break;default:i.vertexAttrib1fv(V.location,nt)}}}}y()}function w(){P();for(const N in n){const F=n[N];for(const H in F){const L=F[H];for(const $ in L){const X=L[$];for(const z in X)d(X[z].object),delete X[z];delete L[$]}}delete n[N]}}function E(N){if(n[N.id]===void 0)return;const F=n[N.id];for(const H in F){const L=F[H];for(const $ in L){const X=L[$];for(const z in X)d(X[z].object),delete X[z];delete L[$]}}delete n[N.id]}function v(N){for(const F in n){const H=n[F];for(const L in H){const $=H[L];if($[N.id]===void 0)continue;const X=$[N.id];for(const z in X)d(X[z].object),delete X[z];delete $[N.id]}}}function S(N){for(const F in n){const H=n[F],L=N.isInstancedMesh===!0?N.id:0,$=H[L];if($!==void 0){for(const X in $){const z=$[X];for(const et in z)d(z[et].object),delete z[et];delete $[X]}delete H[L],Object.keys(H).length===0&&delete n[F]}}}function P(){R(),r=!0,a!==s&&(a=s,c(a.object))}function R(){s.geometry=null,s.program=null,s.wireframe=!1}return{setup:o,reset:P,resetDefaultState:R,dispose:w,releaseStatesOfGeometry:E,releaseStatesOfObject:S,releaseStatesOfProgram:v,initAttributes:x,enableAttribute:m,disableUnusedAttributes:y}}function bx(i,t,e){let n;function s(l){n=l}function a(l,c){i.drawArrays(n,l,c),e.update(c,n,1)}function r(l,c,d){d!==0&&(i.drawArraysInstanced(n,l,c,d),e.update(c,n,d))}function o(l,c,d){if(d===0)return;t.get("WEBGL_multi_draw").multiDrawArraysWEBGL(n,l,0,c,0,d);let u=0;for(let f=0;f<d;f++)u+=c[f];e.update(u,n,1)}this.setMode=s,this.render=a,this.renderInstances=r,this.renderMultiDraw=o}function _x(i,t,e,n){let s;function a(){if(s!==void 0)return s;if(t.has("EXT_texture_filter_anisotropic")===!0){const v=t.get("EXT_texture_filter_anisotropic");s=i.getParameter(v.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else s=0;return s}function r(v){return!(v!==hi&&n.convert(v)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_FORMAT))}function o(v){const S=v===mi&&(t.has("EXT_color_buffer_half_float")||t.has("EXT_color_buffer_float"));return!(v!==xn&&v!==ti&&!S&&n.convert(v)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_TYPE))}function l(v){if(v==="highp"){if(i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.HIGH_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.HIGH_FLOAT).precision>0)return"highp";v="mediump"}return v==="mediump"&&i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.MEDIUM_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let c=e.precision!==void 0?e.precision:"highp";const d=l(c);d!==c&&(Ut("WebGLRenderer:",c,"not supported, using",d,"instead."),c=d);const h=e.reversedDepthBuffer===!0&&t.has("EXT_clip_control"),u=e.logarithmicDepthBuffer===!0&&h===!1;e.reversedDepthBuffer===!0&&h===!1&&Ut("WebGLRenderer: Unable to use reversed depth buffer due to missing EXT_clip_control extension. Fallback to default depth buffer."),e.logarithmicDepthBuffer===!0&&h===!0&&Ut("WebGLRenderer: Logarithmic depth buffer is ignored when reversed depth buffer is enabled.");const f=i.getParameter(i.MAX_TEXTURE_IMAGE_UNITS),g=i.getParameter(i.MAX_VERTEX_TEXTURE_IMAGE_UNITS),x=i.getParameter(i.MAX_TEXTURE_SIZE),m=i.getParameter(i.MAX_CUBE_MAP_TEXTURE_SIZE),p=i.getParameter(i.MAX_VERTEX_ATTRIBS),y=i.getParameter(i.MAX_VERTEX_UNIFORM_VECTORS),A=i.getParameter(i.MAX_VARYING_VECTORS),b=i.getParameter(i.MAX_FRAGMENT_UNIFORM_VECTORS),w=i.getParameter(i.MAX_SAMPLES),E=i.getParameter(i.SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:a,getMaxPrecision:l,textureFormatReadable:r,textureTypeReadable:o,precision:c,logarithmicDepthBuffer:u,reversedDepthBuffer:h,maxTextures:f,maxVertexTextures:g,maxTextureSize:x,maxCubemapSize:m,maxAttributes:p,maxVertexUniforms:y,maxVaryings:A,maxFragmentUniforms:b,maxSamples:w,samples:E}}function Mx(i){const t=this;let e=null,n=0,s=!1,a=!1;const r=new Ei,o=new Bt,l={value:null,needsUpdate:!1};this.uniform=l,this.numPlanes=0,this.numIntersection=0,this.init=function(h,u){const f=h.length!==0||u||n!==0||s;return s=u,n=h.length,f},this.beginShadows=function(){a=!0,d(null)},this.endShadows=function(){a=!1},this.setGlobalState=function(h,u){e=d(h,u,0)},this.setState=function(h,u,f){const g=h.clippingPlanes,x=h.clipIntersection,m=h.clipShadows,p=i.get(h);if(!s||g===null||g.length===0||a&&!m)a?d(null):c();else{const y=a?0:n,A=y*4;let b=p.clippingState||null;l.value=b,b=d(g,u,A,f);for(let w=0;w!==A;++w)b[w]=e[w];p.clippingState=b,this.numIntersection=x?this.numPlanes:0,this.numPlanes+=y}};function c(){l.value!==e&&(l.value=e,l.needsUpdate=n>0),t.numPlanes=n,t.numIntersection=0}function d(h,u,f,g){const x=h!==null?h.length:0;let m=null;if(x!==0){if(m=l.value,g!==!0||m===null){const p=f+x*4,y=u.matrixWorldInverse;o.getNormalMatrix(y),(m===null||m.length<p)&&(m=new Float32Array(p));for(let A=0,b=f;A!==x;++A,b+=4)r.copy(h[A]).applyMatrix4(y,o),r.normal.toArray(m,b),m[b+3]=r.constant}l.value=m,l.needsUpdate=!0}return t.numPlanes=x,t.numIntersection=0,m}}class xd extends Bn{constructor(t=1,e={}){super(t,t,e),this.isWebGLCubeRenderTarget=!0;const n={width:t,height:t,depth:1},s=[n,n,n,n,n,n];this.texture=new Nf(s),this._setTextureOptions(e),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(t,e){this.texture.type=e.type,this.texture.colorSpace=e.colorSpace,this.texture.generateMipmaps=e.generateMipmaps,this.texture.minFilter=e.minFilter,this.texture.magFilter=e.magFilter;const n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},s=new ai(5,5,5),a=new En({name:"CubemapFromEquirect",uniforms:oa(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:en,blending:qs});a.uniforms.tEquirect.value=e;const r=new Pt(s,a),o=e.minFilter;return e.minFilter===Pi&&(e.minFilter=pn),new Ic(1,10,this).update(t,r),e.minFilter=o,r.geometry.dispose(),r.material.dispose(),this}clear(t,e=!0,n=!0,s=!0){const a=t.getRenderTarget();for(let r=0;r<6;r++)t.setRenderTarget(this,r),t.clear(e,n,s);t.setRenderTarget(a)}}const Uh=256,Sx=3,wx=20,Xf=256,qf=16,Ex=3,Ax=new D,Tx=new Rt;class yo{constructor(t){this._renderer=t,this._cubeSize=0,this._sourceTarget=null,this._cubeCamera=new Ic(1,10,null),this._boxMesh=new Pt(new ai(5,5,5),null),this._cubemapMaterial=null,this._equirectMaterial=null,this._blurMaterial=null,this._ggxMaterial=null,this._integrationMaterial=null}fromScene(t,e=0,n=.1,s=100,a={}){const{size:r=256,position:o=Ax}=a,l=this._renderer;this._setSize(r);const c=this._allocateTarget(),d=this._getSourceTarget(!0);e>0&&(d.texture.mipmapsAutoUpdate=!1);const h=l.autoClear,u=l.autoClearColor,f=l.autoClearDepth,g=l.autoClearStencil,x=t.background;l.autoClear=!0,l.autoClearColor=!0,l.autoClearDepth=!0,l.autoClearStencil=!0,x===null&&(t.background=l.getClearColor(Tx));const m=new Ic(n,s,d);return m.position.copy(o),m.update(l,t),l.autoClear=h,l.autoClearColor=u,l.autoClearDepth=f,l.autoClearStencil=g,t.background=x,e>0&&(d.texture.mipmapsAutoUpdate=!0,this._blur(c,e)),this._applyPMREM(c),c}fromEquirectangular(t,e=null){return this._fromTexture(t,e)}fromCubemap(t,e=null){return this._fromTexture(t,e)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=Bh(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=Oh(),this._compileMaterial(this._equirectMaterial))}dispose(){this._sourceTarget!==null&&this._sourceTarget.dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose(),this._blurMaterial!==null&&this._blurMaterial.dispose(),this._ggxMaterial!==null&&this._ggxMaterial.dispose(),this._integrationMaterial!==null&&this._integrationMaterial.dispose(),this._boxMesh.geometry.dispose()}static lodToRoughness(t,e){return e>0?1-Math.sqrt(1-t/e):0}_setSize(t){this._cubeSize=Math.max(Uh,Af(t))}_fromTexture(t,e){t.mapping===na||t.mapping===za?this._setSize(t.image.length===0?Uh:t.image[0].width||t.image[0].image.width):this._setSize(t.image.width/4);const n=e||this._allocateTarget();return this._textureToCubemap(t),this._applyPMREM(n),n}_allocateTarget(){const t=this._cubeSize,e=Fh(t,!1,!1),n=Math.log2(t)-Sx;for(let s=0;s<=n;s++)e.texture.mipmaps.push({width:t>>s,height:t>>s});return e.texture.name="PMREM",e.texture.isPMREMTexture=!0,e}_getSourceTarget(t=!1){const e=this._cubeSize,n=this._sourceTarget;return(n===null||n.width!==e||t&&n.depthBuffer===!1)&&(n!==null&&n.dispose(),this._sourceTarget=Fh(e,!0,t)),this._sourceTarget}_compileMaterial(t){this._boxMesh.material=t,this._renderer.compile(this._boxMesh,this._cubeCamera.children[0])}_renderCube(t,e,n){const s=this._boxMesh,a=this._cubeCamera;s.material=n,a.renderTarget=t,a.activeMipmapLevel=e;const r=t.width>>e;t.viewport.set(0,0,r,r),a.update(this._renderer,s),t.viewport.set(0,0,t.width,t.height)}_textureToCubemap(t){let e;t.mapping===na||t.mapping===za?(this._cubemapMaterial===null&&(this._cubemapMaterial=Bh()),e=this._cubemapMaterial,e.uniforms.flipEnvMap.value=t.isRenderTargetTexture===!1?-1:1):(this._equirectMaterial===null&&(this._equirectMaterial=Oh()),e=this._equirectMaterial),e.uniforms.envMap.value=t,this._renderCube(this._getSourceTarget(),0,e)}_applyPMREM(t){this._ggxMaterial===null&&(this._ggxMaterial=Rx(),this._integrationMaterial=Cx());const e=this._cubeSize,n=t.texture.mipmaps.length-1,s=this._ggxMaterial.uniforms;s.envMap.value=this._sourceTarget.texture;const a=this._integrationMaterial.uniforms;a.envMap.value=this._sourceTarget.texture,a.sourceLod.value=Math.log2(e/qf);for(let r=0;r<=n;r++){const o=yo.lodToRoughness(r,n);if(r>n-Ex)a.roughness.value=o,this._renderCube(t,r,this._integrationMaterial);else{const l=o>0?Math.log2(e)+.5*Math.log2(6/(Xf*Math.pow(o,4)))+.5:0;s.roughness.value=o,s.lodBias.value=l,this._renderCube(t,r,this._ggxMaterial)}}}_blur(t,e){this._blurMaterial===null&&(this._blurMaterial=Px());const n=this._blurMaterial,s=n.uniforms,a=this._sourceTarget;s.sigma.value=Math.min(e,Math.PI)/Math.SQRT2,s.envMap.value=a.texture,this._renderCube(t,0,n),s.envMap.value=t.texture,this._renderCube(a,0,n)}}function Fh(i,t,e){return new xd(i,{minFilter:Pi,generateMipmaps:t,type:mi,colorSpace:oo,depthBuffer:e})}function ja(i,t,e){return new En({name:i,uniforms:t,vertexShader:Xt.cube_vert,fragmentShader:e,side:en,blending:qs,depthTest:!1,depthWrite:!1})}function Rx(){return ja("PMREMGGXConvolution",{envMap:{value:null},roughness:{value:0},lodBias:{value:0}},`

		#define GGX_SAMPLES ${Xf}u

		varying vec3 vWorldDirection;

		uniform samplerCube envMap;
		uniform float roughness;
		uniform float lodBias;

		#include <common>

		// Van der Corput radical inverse
		float radicalInverse_VdC( uint bits ) {

			bits = ( bits << 16u ) | ( bits >> 16u );
			bits = ( ( bits & 0x55555555u ) << 1u ) | ( ( bits & 0xAAAAAAAAu ) >> 1u );
			bits = ( ( bits & 0x33333333u ) << 2u ) | ( ( bits & 0xCCCCCCCCu ) >> 2u );
			bits = ( ( bits & 0x0F0F0F0Fu ) << 4u ) | ( ( bits & 0xF0F0F0F0u ) >> 4u );
			bits = ( ( bits & 0x00FF00FFu ) << 8u ) | ( ( bits & 0xFF00FF00u ) >> 8u );
			return float( bits ) * 2.3283064365386963e-10; // / 0x100000000

		}

		// Hammersley sequence
		vec2 hammersley( uint i, uint N ) {

			return vec2( float( i ) / float( N ), radicalInverse_VdC( i ) );

		}

		void main() {

			vec3 N = normalize( vWorldDirection );

			// For very low roughness, just sample the environment directly
			if ( roughness < 0.001 ) {

				gl_FragColor = vec4( textureLod( envMap, N, 0.0 ).rgb, 1.0 );
				return;

			}

			float alpha = roughness * roughness;
			float alpha2 = alpha * alpha;

			// Tangent space basis for VNDF sampling
			vec3 up = abs( N.z ) < 0.999 ? vec3( 0.0, 0.0, 1.0 ) : vec3( 1.0, 0.0, 0.0 );
			vec3 tangent = normalize( cross( up, N ) );
			vec3 bitangent = cross( N, tangent );

			vec3 prefilteredColor = vec3( 0.0 );
			float totalWeight = 0.0;

			for ( uint i = 0u; i < GGX_SAMPLES; i ++ ) {

				vec2 Xi = hammersley( i, GGX_SAMPLES );

				// With V = N, sample the reflected direction directly.
				float invQ = 1.0 / ( 1.0 - Xi.x + alpha2 * Xi.x );
				float NdotL = ( 1.0 - Xi.x - alpha2 * Xi.x ) * invQ;

				if ( NdotL > 0.0 ) {

					float phi = 2.0 * PI * Xi.y;
					float sinTheta = 2.0 * alpha * sqrt( Xi.x * ( 1.0 - Xi.x ) ) * invQ;
					vec3 L = N * NdotL + ( tangent * cos( phi ) + bitangent * sin( phi ) ) * sinTheta;

					// Match the source mip to the sample's solid angle. The terms
					// independent of the sample are precomputed in lodBias.
					float d = alpha2 * invQ;
					float lod = max( log2( d ) + lodBias, 0.0 );

					// Weight by NdotL for the split-sum approximation
					prefilteredColor += textureLod( envMap, L, lod ).rgb * NdotL;
					totalWeight += NdotL;

				}

			}

			gl_FragColor = vec4( prefilteredColor / totalWeight, 1.0 );

		}
	`)}function Cx(){return ja("PMREMGGXIntegration",{envMap:{value:null},roughness:{value:0},sourceLod:{value:0},sourceSize:{value:qf}},`

		varying vec3 vWorldDirection;

		uniform samplerCube envMap;
		uniform float roughness;
		uniform float sourceLod;
		uniform int sourceSize;

		void main() {

			vec3 N = normalize( vWorldDirection );

			float alpha = roughness * roughness;
			float alpha2 = alpha * alpha;

			float texelSize = 2.0 / float( sourceSize );

			vec3 prefilteredColor = vec3( 0.0 );
			float totalWeight = 0.0;

			// Pair opposite texels: only the one in N's hemisphere contributes.
			for ( int face = 0; face < 3; face ++ ) {

				for ( int y = 0; y < sourceSize; y ++ ) {

					for ( int x = 0; x < sourceSize; x ++ ) {

						vec2 uv = ( vec2( x, y ) + 0.5 ) * texelSize - 1.0;
						vec3 texelDirection = face == 0 ? vec3( 1.0, uv ) : ( face == 1 ? vec3( uv.x, 1.0, uv.y ) : vec3( uv, 1.0 ) );

						float invDistance = inversesqrt( 1.0 + dot( uv, uv ) );
						float NdotL = dot( N, texelDirection );
						texelDirection *= NdotL < 0.0 ? - 1.0 : 1.0;
						NdotL = abs( NdotL ) * invDistance;

						// With V = N, NdotH squared is ( 1 + NdotL ) / 2. Common factors
						// in the GGX distribution and texel solid angle cancel when normalized.
						float d = 1.0 + alpha2 + ( alpha2 - 1.0 ) * NdotL;
						float weight = NdotL * invDistance * invDistance * invDistance / ( d * d );

						prefilteredColor += textureLod( envMap, texelDirection, sourceLod ).rgb * weight;
						totalWeight += weight;

					}

				}

			}

			gl_FragColor = vec4( prefilteredColor / totalWeight, 1.0 );

		}
	`)}function Px(){return ja("PMREMSphericalGaussianBlur",{envMap:{value:null},sigma:{value:0}},`

		#define SAMPLES ${wx}
		#define GOLDEN_ANGLE 2.39996322973

		varying vec3 vWorldDirection;

		uniform samplerCube envMap;
		uniform float sigma;

		#include <common>

		void main() {

			vec3 outputDirection = normalize( vWorldDirection );

			vec3 up = abs( outputDirection.z ) < 0.999 ? vec3( 0.0, 0.0, 1.0 ) : vec3( 1.0, 0.0, 0.0 );
			vec3 tangent = normalize( cross( up, outputDirection ) );
			vec3 bitangent = cross( outputDirection, tangent );

			// Truncate the kernel at three standard deviations or at the antipode.
			float thetaMax = min( 3.0 * sigma, PI );
			float truncation = 1.0 - exp( - 0.5 * thetaMax * thetaMax / ( sigma * sigma ) );

			vec3 accumColor = vec3( 0.0 );
			float accumWeight = 0.0;

			for ( int i = 0; i < SAMPLES; i ++ ) {

				// Stratified inverse-CDF sampling of the Gaussian, placed on a golden-angle spiral.
				float stratum = ( float( i ) + 0.5 ) / float( SAMPLES );
				float theta = sigma * sqrt( - 2.0 * log( 1.0 - stratum * truncation ) );
				float phi = float( i ) * GOLDEN_ANGLE;

				vec3 offset = cos( phi ) * tangent + sin( phi ) * bitangent;
				vec3 sampleDirection = cos( theta ) * outputDirection + sin( theta ) * offset;

				// Correct the planar sample density to solid angle.
				float weight = sin( theta ) / theta;

				accumColor += weight * textureLod( envMap, sampleDirection, 0.0 ).rgb;
				accumWeight += weight;

			}

			gl_FragColor = vec4( accumColor / accumWeight, 1.0 );

		}
	`)}function Oh(){return ja("PMREMEquirectangularToCubemap",{envMap:{value:null}},`

		varying vec3 vWorldDirection;

		uniform sampler2D envMap;

		#include <common>

		void main() {

			// Average four subpixel samples to preserve small, bright features.
			vec3 direction = normalize( vWorldDirection );
			vec3 dx = dFdx( direction ) * 0.25;
			vec3 dy = dFdy( direction ) * 0.25;

			vec3 color = textureLod( envMap, equirectUv( normalize( direction - dx - dy ) ), 0.0 ).rgb;
			color += textureLod( envMap, equirectUv( normalize( direction + dx - dy ) ), 0.0 ).rgb;
			color += textureLod( envMap, equirectUv( normalize( direction - dx + dy ) ), 0.0 ).rgb;
			color += textureLod( envMap, equirectUv( normalize( direction + dx + dy ) ), 0.0 ).rgb;
			gl_FragColor = vec4( color * 0.25, 1.0 );

		}
	`)}function Bh(){return ja("PMREMCubemapToCubemap",{envMap:{value:null},flipEnvMap:{value:-1}},`

		varying vec3 vWorldDirection;

		uniform samplerCube envMap;
		uniform float flipEnvMap;

		void main() {

			gl_FragColor = vec4( textureCube( envMap, vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) ).rgb, 1.0 );

		}
	`)}function Lx(i){let t=new WeakMap,e=new WeakMap,n=null;function s(u,f=!1){return u==null?null:f?r(u):a(u)}function a(u){if(u&&u.isTexture){const f=u.mapping;if(f===nl||f===il)if(t.has(u)){const g=t.get(u).texture;return o(g,u.mapping)}else{const g=u.image;if(g&&g.height>0){const x=new xd(g.height);return x.fromEquirectangularTexture(i,u),t.set(u,x),u.addEventListener("dispose",c),o(x.texture,u.mapping)}else return null}}return u}function r(u){if(u&&u.isTexture&&u.isPMREMTexture!==!0){const f=u.mapping,g=f===nl||f===il,x=f===na||f===za;if(g||x){let m=e.get(u);const p=m!==void 0?m.texture.pmremVersion:0;if(u.isRenderTargetTexture&&u.pmremVersion!==p)return n===null&&(n=new yo(i)),m=g?n.fromEquirectangular(u,m):n.fromCubemap(u,m),m.texture.pmremVersion=u.pmremVersion,e.set(u,m),m.texture;if(m!==void 0)return m.texture;{const y=u.image;return g&&y&&y.height>0||x&&y&&l(y)?(n===null&&(n=new yo(i)),m=g?n.fromEquirectangular(u):n.fromCubemap(u),m.texture.pmremVersion=u.pmremVersion,e.set(u,m),u.addEventListener("dispose",d),m.texture):null}}}return u}function o(u,f){return f===nl?u.mapping=na:f===il&&(u.mapping=za),u}function l(u){let f=0;const g=6;for(let x=0;x<g;x++)u[x]!==void 0&&f++;return f===g}function c(u){const f=u.target;f.removeEventListener("dispose",c);const g=t.get(f);g!==void 0&&(t.delete(f),g.dispose())}function d(u){const f=u.target;f.removeEventListener("dispose",d);const g=e.get(f);g!==void 0&&(e.delete(f),g.dispose())}function h(){t=new WeakMap,e=new WeakMap,n!==null&&(n.dispose(),n=null)}return{get:s,dispose:h}}function Dx(i){const t={};function e(n){if(t[n]!==void 0)return t[n];const s=i.getExtension(n);return t[n]=s,s}return{has:function(n){return e(n)!==null},init:function(){e("EXT_color_buffer_float"),e("WEBGL_clip_cull_distance"),e("OES_texture_float_linear"),e("EXT_color_buffer_half_float"),e("WEBGL_multisampled_render_to_texture"),e("WEBGL_render_shared_exponent")},get:function(n){const s=e(n);return s===null&&Zr("WebGLRenderer: "+n+" extension not supported."),s}}}function Ix(i,t,e,n){const s={},a=new WeakMap,r=new FinalizationRegistry(g=>delete s[g]);function o(g){l(g.target)}function l(g){g.index!==null&&t.remove(g.index);for(const m in g.attributes)t.remove(g.attributes[m]);g.removeEventListener("dispose",o),delete s[g.id],r.unregister(g);const x=a.get(g);x&&(t.remove(x),a.delete(g)),n.releaseStatesOfGeometry(g),g.isInstancedBufferGeometry===!0&&delete g._maxInstanceCount,e.memory.geometries--}function c(g,x){return s[x.id]!==void 0||(x.addEventListener("dispose",o),s[x.id]=new WeakRef(x),r.register(x,x.id,x),e.memory.geometries++),x}function d(g){const x=g.attributes;for(const m in x)t.update(x[m],i.ARRAY_BUFFER)}function h(g){const x=g.index,m=g.attributes.position;let p=0;if(m===void 0)return;const y=x!==null?x.array.length:m.array.length/3-1,A=m.count>=65535?Pf:Cf,b=new A(Math.ceil(y/3)*6,1),w=b.array;if(x!==null){const v=x.array;p=x.version;for(let S=0,P=0;S<y;S+=3){const R=v[S+0],N=v[S+1],F=v[S+2];w[P++]=R,w[P++]=N,w[P++]=N,w[P++]=F,w[P++]=F,w[P++]=R}}else{p=m.version;for(let v=0,S=0;v<y;v+=3){const P=v+0,R=v+1,N=v+2;w[S++]=P,w[S++]=R,w[S++]=R,w[S++]=N,w[S++]=N,w[S++]=P}}b.version=p;const E=a.get(g);E&&t.remove(E),a.set(g,b)}function u(g){const x=a.get(g);if(x){const m=g.index;m!==null&&x.version<m.version&&h(g)}else h(g);return a.get(g)}function f(){for(const g in s){const x=s[g].deref();x!==void 0&&l(x)}}return{get:c,update:d,getWireframeAttribute:u,dispose:f}}function Nx(i,t,e){let n;function s(h){n=h}let a,r;function o(h){a=h.type,r=h.bytesPerElement}function l(h,u){i.drawElements(n,u,a,h*r),e.update(u,n,1)}function c(h,u,f){f!==0&&(i.drawElementsInstanced(n,u,a,h*r,f),e.update(u,n,f))}function d(h,u,f){if(f===0)return;t.get("WEBGL_multi_draw").multiDrawElementsWEBGL(n,u,0,a,h,0,f);let x=0;for(let m=0;m<f;m++)x+=u[m];e.update(x,n,1)}this.setMode=s,this.setIndex=o,this.render=l,this.renderInstances=c,this.renderMultiDraw=d}function Ux(i){const t={geometries:0,textures:0},e={frame:0,calls:0,triangles:0,points:0,lines:0};function n(a,r,o){switch(e.calls++,r){case i.TRIANGLES:e.triangles+=o*(a/3);break;case i.LINES:e.lines+=o*(a/2);break;case i.LINE_STRIP:e.lines+=o*(a-1);break;case i.LINE_LOOP:e.lines+=o*a;break;case i.POINTS:e.points+=o*a;break;default:ie("WebGLInfo: Unknown draw mode:",r);break}}function s(){e.calls=0,e.triangles=0,e.points=0,e.lines=0}return{memory:t,render:e,programs:null,autoReset:!0,reset:s,update:n}}function Fx(i,t,e){const n=new WeakMap,s=new Ae;function a(r,o,l){const c=r.morphTargetInfluences,d=o.morphAttributes.position||o.morphAttributes.normal||o.morphAttributes.color,h=d!==void 0?d.length:0;let u=n.get(o);if(u===void 0||u.count!==h){let R=function(){S.dispose(),n.delete(o),o.removeEventListener("dispose",R)};var f=R;u!==void 0&&u.texture.dispose();const g=o.morphAttributes.position!==void 0,x=o.morphAttributes.normal!==void 0,m=o.morphAttributes.color!==void 0,p=o.morphAttributes.position||[],y=o.morphAttributes.normal||[],A=o.morphAttributes.color||[];let b=0;g===!0&&(b=1),x===!0&&(b=2),m===!0&&(b=3);let w=o.attributes.position.count*b,E=1;w>t.maxTextureSize&&(E=Math.ceil(w/t.maxTextureSize),w=t.maxTextureSize);const v=new Float32Array(w*E*4*h),S=new Tf(v,w,E,h);S.type=ti,S.needsUpdate=!0;const P=b*4;for(let N=0;N<h;N++){const F=p[N],H=y[N],L=A[N],$=w*E*4*N;for(let X=0;X<F.count;X++){const z=X*P;g===!0&&(s.fromBufferAttribute(F,X),v[$+z+0]=s.x,v[$+z+1]=s.y,v[$+z+2]=s.z,v[$+z+3]=0),x===!0&&(s.fromBufferAttribute(H,X),v[$+z+4]=s.x,v[$+z+5]=s.y,v[$+z+6]=s.z,v[$+z+7]=0),m===!0&&(s.fromBufferAttribute(L,X),v[$+z+8]=s.x,v[$+z+9]=s.y,v[$+z+10]=s.z,v[$+z+11]=L.itemSize===4?s.w:1)}}u={count:h,texture:S,size:new It(w,E)},n.set(o,u),o.addEventListener("dispose",R)}if(r.isInstancedMesh===!0&&r.morphTexture!==null)l.getUniforms().setValue(i,"morphTexture",r.morphTexture,e);else{let g=0;for(let m=0;m<c.length;m++)g+=c[m];const x=o.morphTargetsRelative?1:1-g;l.getUniforms().setValue(i,"morphTargetBaseInfluence",x),l.getUniforms().setValue(i,"morphTargetInfluences",c)}l.getUniforms().setValue(i,"morphTargetsTexture",u.texture,e),l.getUniforms().setValue(i,"morphTargetsTextureSize",u.size)}return{update:a}}function Ox(i,t,e,n,s){let a=new WeakMap;function r(c){const d=s.render.frame,h=c.geometry,u=t.get(c,h);if(a.get(u)!==d&&(t.update(u),a.set(u,d)),c.isInstancedMesh&&(c.hasEventListener("dispose",l)===!1&&c.addEventListener("dispose",l),a.get(c)!==d&&(e.update(c.instanceMatrix,i.ARRAY_BUFFER),c.instanceColor!==null&&e.update(c.instanceColor,i.ARRAY_BUFFER),a.set(c,d))),c.isSkinnedMesh){const f=c.skeleton;a.get(f)!==d&&(f.update(),a.set(f,d))}return u}function o(){a=new WeakMap}function l(c){const d=c.target;d.removeEventListener("dispose",l),n.releaseStatesOfObject(d),e.remove(d.instanceMatrix),d.instanceColor!==null&&e.remove(d.instanceColor)}return{update:r,dispose:o}}const Bx={[lf]:"LINEAR_TONE_MAPPING",[cf]:"REINHARD_TONE_MAPPING",[df]:"CINEON_TONE_MAPPING",[nd]:"ACES_FILMIC_TONE_MAPPING",[uf]:"AGX_TONE_MAPPING",[ff]:"NEUTRAL_TONE_MAPPING",[hf]:"CUSTOM_TONE_MAPPING"};function kx(i,t,e,n,s,a){const r=new Bn(t,e,{type:i,depthBuffer:s,stencilBuffer:a,samples:n?4:0,storeMultisampledDepthBuffer:!1,storeMultisampledStencilBuffer:!1,resolveDepthBuffer:!1,resolveStencilBuffer:!1});let o=null,l=null,c=null;const d=new ge;d.setAttribute("position",new se([-1,3,0,-1,-1,0,3,-1,0],3)),d.setAttribute("uv",new se([0,2,0,0,2,0],2));const h=new C0({uniforms:{tDiffuse:{value:null}},vertexShader:`
			precision highp float;

			uniform mat4 modelViewMatrix;
			uniform mat4 projectionMatrix;

			attribute vec3 position;
			attribute vec2 uv;

			varying vec2 vUv;

			void main() {
				vUv = uv;
				gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
			}`,fragmentShader:`
			precision highp float;

			uniform sampler2D tDiffuse;

			varying vec2 vUv;

			#include <tonemapping_pars_fragment>
			#include <colorspace_pars_fragment>

			void main() {
				gl_FragColor = texture2D( tDiffuse, vUv );

				#ifdef LINEAR_TONE_MAPPING
					gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );
				#elif defined( REINHARD_TONE_MAPPING )
					gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );
				#elif defined( CINEON_TONE_MAPPING )
					gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );
				#elif defined( ACES_FILMIC_TONE_MAPPING )
					gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );
				#elif defined( AGX_TONE_MAPPING )
					gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );
				#elif defined( NEUTRAL_TONE_MAPPING )
					gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );
				#elif defined( CUSTOM_TONE_MAPPING )
					gl_FragColor.rgb = CustomToneMapping( gl_FragColor.rgb );
				#endif

				#ifdef SRGB_TRANSFER
					gl_FragColor = sRGBTransferOETF( gl_FragColor );
				#endif
			}`,depthTest:!1,depthWrite:!1}),u=new Pt(d,h),f=new vd(-1,1,1,-1,0,1);let g=null,x=null,m=!1,p,y=null,A=[],b=!1;this.setSize=function(w,E){r.setSize(w,E),o!==null&&o.setSize(w,E),l!==null&&l.setSize(w,E);for(let v=0;v<A.length;v++){const S=A[v];S.setSize&&S.setSize(w,E)}},this.setEffects=function(w){A=w,b=A.length>0&&A[0].isRenderPass===!0;const E=r.width,v=r.height;A.length>0&&o===null&&(o=new Bn(E,v,{type:mi,depthBuffer:!1,stencilBuffer:!1}),l=new Bn(E,v,{type:mi,depthBuffer:!1,stencilBuffer:!1}));const S=s===!0&&A.some(P=>P.needsDepthTexture===!0);S!==(r.depthTexture!==null)&&(S===!0&&c===null&&(c=new aa(E,v),a===!0&&(c.format=Yi,c.type=ia)),r.dispose(),r.depthTexture=S?c:null,r.resolveDepthBuffer=S,r.storeMultisampledDepthBuffer=S);for(let P=0;P<A.length;P++){const R=A[P];R.setSize&&R.setSize(E,v),S&&R.needsDepthTexture===!0&&R.setDepthTexture&&R.setDepthTexture(c)}},this.begin=function(w,E){if(m||w.toneMapping===Di&&A.length===0)return!1;if(y=E,E!==null){const v=E.width,S=E.height;(r.width!==v||r.height!==S)&&this.setSize(v,S)}return b===!1&&w.setRenderTarget(r),p=w.toneMapping,w.toneMapping=Di,!0},this.hasRenderPass=function(){return b},this.end=function(w,E){w.toneMapping=p,m=!0;let v=r,S=o;for(let P=0;P<A.length;P++){const R=A[P];R.enabled!==!1&&(R.render(w,S,v,E),R.needsSwap!==!1&&(v=S,S=S===o?l:o))}if(g!==w.outputColorSpace||x!==w.toneMapping){g=w.outputColorSpace,x=w.toneMapping,h.defines={},te.getTransfer(g)===le&&(h.defines.SRGB_TRANSFER="");const P=Bx[x];P&&(h.defines[P]=""),h.needsUpdate=!0}h.uniforms.tDiffuse.value=v.texture,w.setRenderTarget(y),w.render(u,f),y=null,m=!1},this.isCompositing=function(){return m},this.dispose=function(){r.dispose(),o!==null&&o.dispose(),l!==null&&l.dispose(),d.dispose(),h.dispose()}}const Yf=new cn,Kf=new aa(1,1),Zf=new Uf(1),Jf=new Tf,jf=new r0,Qf=new Nf,kh=[],zh=[],$h=new Float32Array(16),Hh=new Float32Array(9),Gh=new Float32Array(4);function ca(i,t,e){const n=i[0];if(n<=0||n>0)return i;const s=t*e;let a=kh[s];if(a===void 0&&(a=new Float32Array(s),kh[s]=a),t!==0){n.toArray(a,0);for(let r=1,o=0;r!==t;++r)o+=e,i[r].toArray(a,o)}return a}function Be(i,t){if(i.length!==t.length)return!1;for(let e=0,n=i.length;e<n;e++)if(i[e]!==t[e])return!1;return!0}function ke(i,t){for(let e=0,n=t.length;e<n;e++)i[e]=t[e]}function Go(i,t){let e=zh[t];e===void 0&&(e=new Int32Array(t),zh[t]=e);for(let n=0;n!==t;++n)e[n]=i.allocateTextureUnit();return e}function zx(i,t){const e=this.cache;e[0]!==t&&(i.uniform1f(this.addr,t),e[0]=t)}function $x(i,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(i.uniform2f(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Be(e,t))return;i.uniform2fv(this.addr,t),ke(e,t)}}function Hx(i,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(i.uniform3f(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else if(t.r!==void 0)(e[0]!==t.r||e[1]!==t.g||e[2]!==t.b)&&(i.uniform3f(this.addr,t.r,t.g,t.b),e[0]=t.r,e[1]=t.g,e[2]=t.b);else{if(Be(e,t))return;i.uniform3fv(this.addr,t),ke(e,t)}}function Gx(i,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(i.uniform4f(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Be(e,t))return;i.uniform4fv(this.addr,t),ke(e,t)}}function Vx(i,t){const e=this.cache,n=t.elements;if(n===void 0){if(Be(e,t))return;i.uniformMatrix2fv(this.addr,!1,t),ke(e,t)}else{if(Be(e,n))return;Gh.set(n),i.uniformMatrix2fv(this.addr,!1,Gh),ke(e,n)}}function Wx(i,t){const e=this.cache,n=t.elements;if(n===void 0){if(Be(e,t))return;i.uniformMatrix3fv(this.addr,!1,t),ke(e,t)}else{if(Be(e,n))return;Hh.set(n),i.uniformMatrix3fv(this.addr,!1,Hh),ke(e,n)}}function Xx(i,t){const e=this.cache,n=t.elements;if(n===void 0){if(Be(e,t))return;i.uniformMatrix4fv(this.addr,!1,t),ke(e,t)}else{if(Be(e,n))return;$h.set(n),i.uniformMatrix4fv(this.addr,!1,$h),ke(e,n)}}function qx(i,t){const e=this.cache;e[0]!==t&&(i.uniform1i(this.addr,t),e[0]=t)}function Yx(i,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(i.uniform2i(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Be(e,t))return;i.uniform2iv(this.addr,t),ke(e,t)}}function Kx(i,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(i.uniform3i(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(Be(e,t))return;i.uniform3iv(this.addr,t),ke(e,t)}}function Zx(i,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(i.uniform4i(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Be(e,t))return;i.uniform4iv(this.addr,t),ke(e,t)}}function Jx(i,t){const e=this.cache;e[0]!==t&&(i.uniform1ui(this.addr,t),e[0]=t)}function jx(i,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(i.uniform2ui(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Be(e,t))return;i.uniform2uiv(this.addr,t),ke(e,t)}}function Qx(i,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(i.uniform3ui(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(Be(e,t))return;i.uniform3uiv(this.addr,t),ke(e,t)}}function ty(i,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(i.uniform4ui(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Be(e,t))return;i.uniform4uiv(this.addr,t),ke(e,t)}}function Vo(i){return i.version===0&&(i.compareFunction=Sf,i.needsUpdate=!0),i}function ey(i,t,e){const n=this.cache,s=e.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s);let a;this.type===i.SAMPLER_2D_SHADOW?a=Vo(Kf):a=Yf,e.setTexture2D(t||a,s)}function ny(i,t,e){const n=this.cache,s=e.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),e.setTexture3D(t||jf,s)}function iy(i,t,e){const n=this.cache,s=e.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s);let a;this.type===i.SAMPLER_CUBE_SHADOW?a=Vo(Zf):a=Qf,e.setTextureCube(t||a,s)}function sy(i,t,e){const n=this.cache,s=e.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),e.setTexture2DArray(t||Jf,s)}function ay(i){switch(i){case 5126:return zx;case 35664:return $x;case 35665:return Hx;case 35666:return Gx;case 35674:return Vx;case 35675:return Wx;case 35676:return Xx;case 5124:case 35670:return qx;case 35667:case 35671:return Yx;case 35668:case 35672:return Kx;case 35669:case 35673:return Zx;case 5125:return Jx;case 36294:return jx;case 36295:return Qx;case 36296:return ty;case 35678:case 36198:case 36298:case 36306:case 35682:return ey;case 35679:case 36299:case 36307:return ny;case 35680:case 36300:case 36308:case 36293:return iy;case 36289:case 36303:case 36311:case 36292:return sy}}function ry(i,t){i.uniform1fv(this.addr,t)}function oy(i,t){const e=ca(t,this.size,2);i.uniform2fv(this.addr,e)}function ly(i,t){const e=ca(t,this.size,3);i.uniform3fv(this.addr,e)}function cy(i,t){const e=ca(t,this.size,4);i.uniform4fv(this.addr,e)}function dy(i,t){const e=ca(t,this.size,4);i.uniformMatrix2fv(this.addr,!1,e)}function hy(i,t){const e=ca(t,this.size,9);i.uniformMatrix3fv(this.addr,!1,e)}function uy(i,t){const e=ca(t,this.size,16);i.uniformMatrix4fv(this.addr,!1,e)}function fy(i,t){i.uniform1iv(this.addr,t)}function py(i,t){i.uniform2iv(this.addr,t)}function my(i,t){i.uniform3iv(this.addr,t)}function gy(i,t){i.uniform4iv(this.addr,t)}function vy(i,t){i.uniform1uiv(this.addr,t)}function xy(i,t){i.uniform2uiv(this.addr,t)}function yy(i,t){i.uniform3uiv(this.addr,t)}function by(i,t){i.uniform4uiv(this.addr,t)}function _y(i,t,e){const n=this.cache,s=t.length,a=Go(e,s);Be(n,a)||(i.uniform1iv(this.addr,a),ke(n,a));let r;this.type===i.SAMPLER_2D_SHADOW?r=Vo(Kf):r=Yf;for(let o=0;o!==s;++o)e.setTexture2D(t[o]||r,a[o])}function My(i,t,e){const n=this.cache,s=t.length,a=Go(e,s);Be(n,a)||(i.uniform1iv(this.addr,a),ke(n,a));for(let r=0;r!==s;++r)e.setTexture3D(t[r]||jf,a[r])}function Sy(i,t,e){const n=this.cache,s=t.length,a=Go(e,s);Be(n,a)||(i.uniform1iv(this.addr,a),ke(n,a));let r;this.type===i.SAMPLER_CUBE_SHADOW?r=Vo(Zf):r=Qf;for(let o=0;o!==s;++o)e.setTextureCube(t[o]||r,a[o])}function wy(i,t,e){const n=this.cache,s=t.length,a=Go(e,s);Be(n,a)||(i.uniform1iv(this.addr,a),ke(n,a));for(let r=0;r!==s;++r)e.setTexture2DArray(t[r]||Jf,a[r])}function Ey(i){switch(i){case 5126:return ry;case 35664:return oy;case 35665:return ly;case 35666:return cy;case 35674:return dy;case 35675:return hy;case 35676:return uy;case 5124:case 35670:return fy;case 35667:case 35671:return py;case 35668:case 35672:return my;case 35669:case 35673:return gy;case 5125:return vy;case 36294:return xy;case 36295:return yy;case 36296:return by;case 35678:case 36198:case 36298:case 36306:case 35682:return _y;case 35679:case 36299:case 36307:return My;case 35680:case 36300:case 36308:case 36293:return Sy;case 36289:case 36303:case 36311:case 36292:return wy}}class Ay{constructor(t,e,n){this.id=t,this.addr=n,this.cache=[],this.type=e.type,this.setValue=ay(e.type)}}class Ty{constructor(t,e,n){this.id=t,this.addr=n,this.cache=[],this.type=e.type,this.size=e.size,this.setValue=Ey(e.type)}}class Ry{constructor(t){this.id=t,this.seq=[],this.map={}}setValue(t,e,n){const s=this.seq;for(let a=0,r=s.length;a!==r;++a){const o=s[a];o.setValue(t,e[o.id],n)}}}const Pl=/(\w+)(\])?(\[|\.)?/g;function Vh(i,t){i.seq.push(t),i.map[t.id]=t}function Cy(i,t,e){const n=i.name,s=n.length;for(Pl.lastIndex=0;;){const a=Pl.exec(n),r=Pl.lastIndex;let o=a[1];const l=a[2]==="]",c=a[3];if(l&&(o=o|0),c===void 0||c==="["&&r+2===s){Vh(e,c===void 0?new Ay(o,i,t):new Ty(o,i,t));break}else{let h=e.map[o];h===void 0&&(h=new Ry(o),Vh(e,h)),e=h}}}class Jr{constructor(t,e){this.seq=[],this.map={};const n=t.getProgramParameter(e,t.ACTIVE_UNIFORMS);for(let r=0;r<n;++r){const o=t.getActiveUniform(e,r),l=t.getUniformLocation(e,o.name);Cy(o,l,this)}const s=[],a=[];for(const r of this.seq)r.type===t.SAMPLER_2D_SHADOW||r.type===t.SAMPLER_CUBE_SHADOW||r.type===t.SAMPLER_2D_ARRAY_SHADOW?s.push(r):a.push(r);s.length>0&&(this.seq=s.concat(a))}setValue(t,e,n,s){const a=this.map[e];a!==void 0&&a.setValue(t,n,s)}setOptional(t,e,n){const s=e[n];s!==void 0&&this.setValue(t,n,s)}static upload(t,e,n,s){for(let a=0,r=e.length;a!==r;++a){const o=e[a],l=n[o.id];l.needsUpdate!==!1&&o.setValue(t,l.value,s)}}static seqWithValue(t,e){const n=[];for(let s=0,a=t.length;s!==a;++s){const r=t[s];r.id in e&&n.push(r)}return n}}function Wh(i,t,e){const n=i.createShader(t);return i.shaderSource(n,e),i.compileShader(n),n}const Py=37297;let Ly=0;function Dy(i,t){const e=i.split(`
`),n=[],s=Math.max(t-6,0),a=Math.min(t+6,e.length);for(let r=s;r<a;r++){const o=r+1;n.push(`${o===t?">":" "} ${o}: ${e[r]}`)}return n.join(`
`)}const Xh=new Bt;function Iy(i){te._getMatrix(Xh,te.workingColorSpace,i);const t=`mat3( ${Xh.elements.map(e=>e.toFixed(4))} )`;switch(te.getTransfer(i)){case lo:return[t,"LinearTransferOETF"];case le:return[t,"sRGBTransferOETF"];default:return Ut("WebGLProgram: Unsupported color space: ",i),[t,"LinearTransferOETF"]}}function qh(i,t,e){const n=i.getShaderParameter(t,i.COMPILE_STATUS),a=(i.getShaderInfoLog(t)||"").trim();if(n&&a==="")return"";const r=/ERROR: 0:(\d+)/.exec(a);if(r){const o=parseInt(r[1]);return e.toUpperCase()+`

`+a+`

`+Dy(i.getShaderSource(t),o)}else return a}function Ny(i,t){const e=Iy(t);return[`vec4 ${i}( vec4 value ) {`,`	return ${e[1]}( vec4( ${e[0]} * value.rgb, value.a ) );`,"}"].join(`
`)}const Uy={[lf]:"Linear",[cf]:"Reinhard",[df]:"Cineon",[nd]:"ACESFilmic",[uf]:"AgX",[ff]:"Neutral",[hf]:"Custom"};function Fy(i,t){const e=Uy[t];return e===void 0?(Ut("WebGLProgram: Unsupported toneMapping:",t),"vec3 "+i+"( vec3 color ) { return LinearToneMapping( color ); }"):"vec3 "+i+"( vec3 color ) { return "+e+"ToneMapping( color ); }"}const Nr=new D;function Oy(){te.getLuminanceCoefficients(Nr);const i=Nr.x.toFixed(4),t=Nr.y.toFixed(4),e=Nr.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${i}, ${t}, ${e} );`,"	return dot( weights, rgb );","}"].join(`
`)}function By(i){return[i.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",i.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(Ea).join(`
`)}function ky(i){const t=[];for(const e in i){const n=i[e];n!==!1&&t.push("#define "+e+" "+n)}return t.join(`
`)}function zy(i,t){const e={},n=i.getProgramParameter(t,i.ACTIVE_ATTRIBUTES);for(let s=0;s<n;s++){const a=i.getActiveAttrib(t,s),r=a.name;let o=1;a.type===i.FLOAT_MAT2&&(o=2),a.type===i.FLOAT_MAT3&&(o=3),a.type===i.FLOAT_MAT4&&(o=4),e[r]={type:a.type,location:i.getAttribLocation(t,r),locationSize:o}}return e}function Ea(i){return i!==""}function Yh(i,t){const e=t.numSpotLightShadows+t.numSpotLightMaps-t.numSpotLightShadowsWithMaps;return i.replace(/NUM_SUN_LIGHTS/g,t.numSunLights).replace(/NUM_DIR_LIGHTS/g,t.numDirLights).replace(/NUM_SPOT_LIGHTS/g,t.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,t.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,e).replace(/NUM_RECT_AREA_LIGHTS/g,t.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,t.numPointLights).replace(/NUM_HEMI_LIGHTS/g,t.numHemiLights).replace(/NUM_SUN_LIGHT_SHADOWS/g,t.numSunLightShadows).replace(/NUM_DIR_LIGHT_SHADOWS/g,t.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,t.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,t.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,t.numPointLightShadows).replace(/NUM_LIGHT_PROBE_GRIDS/g,t.numLightProbeGrids)}function Kh(i,t){return i.replace(/NUM_CLIPPING_PLANES/g,t.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,t.numClippingPlanes-t.numClipIntersection)}const $y=/^[ \t]*#include +<([\w\d./]+)>/gm;function Uc(i){return i.replace($y,Hy)}function Hy(i,t){const e=Xt[t];if(e===void 0)throw new Error("THREE.WebGLProgram: Can not resolve #include <"+t+">");return Uc(e)}const Gy=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function Zh(i){return i.replace(Gy,Vy)}function Vy(i,t,e,n){let s="";for(let a=parseInt(t);a<parseInt(e);a++)s+=n.replace(/\[\s*i\s*\]/g,"[ "+a+" ]").replace(/UNROLLED_LOOP_INDEX/g,a);return s}function Jh(i){let t=`precision ${i.precision} float;
	precision ${i.precision} int;
	precision ${i.precision} sampler2D;
	precision ${i.precision} samplerCube;
	precision ${i.precision} sampler3D;
	precision ${i.precision} sampler2DArray;
	precision ${i.precision} sampler2DShadow;
	precision ${i.precision} samplerCubeShadow;
	precision ${i.precision} sampler2DArrayShadow;
	precision ${i.precision} isampler2D;
	precision ${i.precision} isampler3D;
	precision ${i.precision} isamplerCube;
	precision ${i.precision} isampler2DArray;
	precision ${i.precision} usampler2D;
	precision ${i.precision} usampler3D;
	precision ${i.precision} usamplerCube;
	precision ${i.precision} usampler2DArray;
	`;return i.precision==="highp"?t+=`
#define HIGH_PRECISION`:i.precision==="mediump"?t+=`
#define MEDIUM_PRECISION`:i.precision==="lowp"&&(t+=`
#define LOW_PRECISION`),t}const Wy={[Wr]:"SHADOWMAP_TYPE_PCF",[wa]:"SHADOWMAP_TYPE_VSM"};function Xy(i){return Wy[i.shadowMapType]||"SHADOWMAP_TYPE_BASIC"}const qy={[za]:"ENVMAP_MODE_REFRACTION"};function Yy(i){return i.envMap===!1?"ENVMAP_MODE_REFLECTION":qy[i.envMapMode]||"ENVMAP_MODE_REFLECTION"}const Ky={[ed]:"ENVMAP_BLENDING_MULTIPLY",[Em]:"ENVMAP_BLENDING_MIX",[Am]:"ENVMAP_BLENDING_ADD"};function Zy(i){return i.envMap===!1?"ENVMAP_BLENDING_NONE":Ky[i.combine]||"ENVMAP_BLENDING_NONE"}function Jy(i,t,e,n){const s=i.getContext(),a=e.defines;let r=e.vertexShader,o=e.fragmentShader;const l=Xy(e),c=e.envMapPMREM===!0?"ENVMAP_TYPE_PMREM":"ENVMAP_TYPE_CUBE",d=Yy(e),h=Zy(e),u=By(e),f=ky(a),g=s.createProgram();let x,m,p=e.glslVersion?"#version "+e.glslVersion+`
`:"";e.isRawShaderMaterial?(x=["#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,f].filter(Ea).join(`
`),x.length>0&&(x+=`
`),m=["#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,f].filter(Ea).join(`
`),m.length>0&&(m+=`
`)):(x=[Jh(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,f,e.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",e.batching?"#define USE_BATCHING":"",e.batchingColor?"#define USE_BATCHING_COLOR":"",e.instancing?"#define USE_INSTANCING":"",e.instancingColor?"#define USE_INSTANCING_COLOR":"",e.instancingMorph?"#define USE_INSTANCING_MORPH":"",e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.map?"#define USE_MAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+d:"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.displacementMap?"#define USE_DISPLACEMENTMAP":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.diffuseRoughnessMap?"#define USE_DIFFUSE_ROUGHNESSMAP":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.mapUv?"#define MAP_UV "+e.mapUv:"",e.alphaMapUv?"#define ALPHAMAP_UV "+e.alphaMapUv:"",e.lightMapUv?"#define LIGHTMAP_UV "+e.lightMapUv:"",e.aoMapUv?"#define AOMAP_UV "+e.aoMapUv:"",e.emissiveMapUv?"#define EMISSIVEMAP_UV "+e.emissiveMapUv:"",e.bumpMapUv?"#define BUMPMAP_UV "+e.bumpMapUv:"",e.normalMapUv?"#define NORMALMAP_UV "+e.normalMapUv:"",e.displacementMapUv?"#define DISPLACEMENTMAP_UV "+e.displacementMapUv:"",e.metalnessMapUv?"#define METALNESSMAP_UV "+e.metalnessMapUv:"",e.roughnessMapUv?"#define ROUGHNESSMAP_UV "+e.roughnessMapUv:"",e.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+e.anisotropyMapUv:"",e.clearcoatMapUv?"#define CLEARCOATMAP_UV "+e.clearcoatMapUv:"",e.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+e.clearcoatNormalMapUv:"",e.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+e.clearcoatRoughnessMapUv:"",e.diffuseRoughnessMapUv?"#define DIFFUSE_ROUGHNESSMAP_UV "+e.diffuseRoughnessMapUv:"",e.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+e.iridescenceMapUv:"",e.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+e.iridescenceThicknessMapUv:"",e.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+e.sheenColorMapUv:"",e.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+e.sheenRoughnessMapUv:"",e.specularMapUv?"#define SPECULARMAP_UV "+e.specularMapUv:"",e.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+e.specularColorMapUv:"",e.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+e.specularIntensityMapUv:"",e.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+e.transmissionMapUv:"",e.thicknessMapUv?"#define THICKNESSMAP_UV "+e.thicknessMapUv:"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexNormals?"#define HAS_NORMAL":"",e.vertexColors?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.flatShading?"#define FLAT_SHADED":"",e.skinning?"#define USE_SKINNING":"",e.morphTargets?"#define USE_MORPHTARGETS":"",e.morphNormals&&e.flatShading===!1?"#define USE_MORPHNORMALS":"",e.morphColors?"#define USE_MORPHCOLORS":"",e.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+e.morphTextureStride:"",e.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+e.morphTargetsCount:"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+l:"",e.sizeAttenuation?"#define USE_SIZEATTENUATION":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",e.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(Ea).join(`
`),m=[Jh(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,f,e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",e.map?"#define USE_MAP":"",e.matcap?"#define USE_MATCAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+c:"",e.envMap?"#define "+d:"",e.envMap?"#define "+h:"",e.envMapPMREM?"#define ENVMAP_MAX_LOD "+e.envMapMaxLod+".0":"",e.envMapPMREM?"#define ENVMAP_SIZE "+e.envMapSize+".0":"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.packedNormalMap?"#define USE_PACKED_NORMALMAP":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoat?"#define USE_CLEARCOAT":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.diffuseRoughness?"#define USE_DIFFUSE_ROUGHNESS":"",e.diffuseRoughnessMap?"#define USE_DIFFUSE_ROUGHNESSMAP":"",e.dispersion?"#define USE_DISPERSION":"",e.retroreflection?"#define USE_RETROREFLECTION":"",e.iridescence?"#define USE_IRIDESCENCE":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaTest?"#define USE_ALPHATEST":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.sheen?"#define USE_SHEEN":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors||e.instancingColor?"#define USE_COLOR":"",e.vertexAlphas||e.batchingColor?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.gradientMap?"#define USE_GRADIENTMAP":"",e.flatShading?"#define FLAT_SHADED":"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+l:"",e.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",e.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",e.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",e.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",e.toneMapping!==Di?"#define TONE_MAPPING":"",e.toneMapping!==Di?Xt.tonemapping_pars_fragment:"",e.toneMapping!==Di?Fy("toneMapping",e.toneMapping):"",e.dithering?"#define DITHERING":"",e.opaque?"#define OPAQUE":"",Xt.colorspace_pars_fragment,Ny("linearToOutputTexel",e.outputColorSpace),Oy(),e.useDepthPacking?"#define DEPTH_PACKING "+e.depthPacking:"",`
`].filter(Ea).join(`
`)),r=Uc(r),r=Yh(r,e),r=Kh(r,e),o=Uc(o),o=Yh(o,e),o=Kh(o,e),r=Zh(r),o=Zh(o),e.isRawShaderMaterial!==!0&&(p=`#version 300 es
`,x=[u,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+x,m=["#define varying in",e.glslVersion===Zd?"":"layout(location = 0) out highp vec4 pc_fragColor;",e.glslVersion===Zd?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+m);const y=p+x+r,A=p+m+o,b=Wh(s,s.VERTEX_SHADER,y),w=Wh(s,s.FRAGMENT_SHADER,A);s.attachShader(g,b),s.attachShader(g,w),e.index0AttributeName!==void 0?s.bindAttribLocation(g,0,e.index0AttributeName):e.hasPositionAttribute===!0&&s.bindAttribLocation(g,0,"position"),s.linkProgram(g);function E(R){if(i.debug.checkShaderErrors){const N=s.getProgramInfoLog(g)||"",F=s.getShaderInfoLog(b)||"",H=s.getShaderInfoLog(w)||"",L=N.trim(),$=F.trim(),X=H.trim();let z=!0,et=!0;if(s.getProgramParameter(g,s.LINK_STATUS)===!1)if(z=!1,typeof i.debug.onShaderError=="function")i.debug.onShaderError(s,g,b,w);else{const V=qh(s,b,"vertex"),Q=qh(s,w,"fragment");ie("WebGLProgram: Shader Error "+s.getError()+" - VALIDATE_STATUS "+s.getProgramParameter(g,s.VALIDATE_STATUS)+`

Material Name: `+R.name+`
Material Type: `+R.type+`

Program Info Log: `+L+`
`+V+`
`+Q)}else L!==""?Ut("WebGLProgram: Program Info Log:",L):($===""||X==="")&&(et=!1);et&&(R.diagnostics={runnable:z,programLog:L,vertexShader:{log:$,prefix:x},fragmentShader:{log:X,prefix:m}})}s.deleteShader(b),s.deleteShader(w),v=new Jr(s,g),S=zy(s,g)}let v;this.getUniforms=function(){return v===void 0&&E(this),v};let S;this.getAttributes=function(){return S===void 0&&E(this),S};let P=e.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return P===!1&&(P=s.getProgramParameter(g,Py)),P},this.destroy=function(){n.releaseStatesOfProgram(this),s.deleteProgram(g),this.program=void 0},this.type=e.shaderType,this.name=e.shaderName,this.id=Ly++,this.cacheKey=t,this.usedTimes=1,this.program=g,this.vertexShader=b,this.fragmentShader=w,this}let jy=0;class Qy{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(t,e,n){const s=this._getShaderCacheForMaterial(t);return s.has(e)===!1&&(s.add(e),e.usedTimes++),s.has(n)===!1&&(s.add(n),n.usedTimes++),this}remove(t){const e=this.materialCache.get(t);for(const n of e)n.usedTimes--,n.usedTimes===0&&this.shaderCache.delete(n.code);return this.materialCache.delete(t),this}getVertexShaderStage(t){return this._getShaderStage(t.vertexShader)}getFragmentShaderStage(t){return this._getShaderStage(t.fragmentShader)}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(t){const e=this.materialCache;let n=e.get(t);return n===void 0&&(n=new Set,e.set(t,n)),n}_getShaderStage(t){const e=this.shaderCache;let n=e.get(t);return n===void 0&&(n=new tb(t),e.set(t,n)),n}}class tb{constructor(t){this.id=jy++,this.code=t,this.usedTimes=0}}function eb(i){return i===ms||i===so||i===ao}function nb(i,t,e,n,s,a){const r=new pd,o=new Qy,l=new Set,c=[],d=new Map,h=n.logarithmicDepthBuffer,u={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distance",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function f(v){return l.add(v),v===0?"uv":`uv${v}`}function g(v,S,P,R,N,F){const H=R.fog,L=N.geometry,$=v.isMeshStandardMaterial||v.isMeshLambertMaterial||v.isMeshPhongMaterial?R.environment:null,X=v.isMeshStandardMaterial||v.isMeshLambertMaterial&&!v.envMap||v.isMeshPhongMaterial&&!v.envMap,z=t.get(v.envMap||$,X),et=u[v.type];let V=n.precision;v.precision!==null&&(V=n.getMaxPrecision(v.precision),V!==v.precision&&Ut("WebGLProgram.getParameters:",v.precision,"not supported, using",V,"instead."));const Q=L.morphAttributes.position||L.morphAttributes.normal||L.morphAttributes.color,nt=Q!==void 0?Q.length:0;let Et=0;L.morphAttributes.position!==void 0&&(Et=1),L.morphAttributes.normal!==void 0&&(Et=2),L.morphAttributes.color!==void 0&&(Et=3);let $t,K,xt,Mt;if(et){const gt=ci[et];$t=gt.vertexShader,K=gt.fragmentShader}else{$t=v.vertexShader,K=v.fragmentShader;const gt=o.getVertexShaderStage(v),oe=o.getFragmentShaderStage(v);o.update(v,gt,oe),xt=gt.id,Mt=oe.id}const Lt=i.getRenderTarget(),yt=i.state.buffers.depth.getReversed(),Gt=N.isInstancedMesh===!0,Pe=N.isBatchedMesh===!0,Nt=!!v.map,re=!!v.matcap,de=!!z,Kt=de&&z.isPMREMTexture===!0,Ke=!!v.aoMap,Ue=!!v.lightMap,mn=!!v.bumpMap&&v.wireframe===!1,Se=!!v.normalMap,ri=!!v.displacementMap,ze=!!v.emissiveMap,Pn=!!v.metalnessMap,Ln=!!v.roughnessMap,Dn=v.anisotropy>0,U=v.clearcoat>0,In=v.diffuseRoughness>0,be=v.dispersion>0,_e=v.retroreflectivity>0,mt=v.iridescence>0,Fe=v.sheen>0,Dt=v.transmission>0,Ot=Dn&&!!v.anisotropyMap,T=U&&!!v.clearcoatMap,_=U&&!!v.clearcoatNormalMap,B=U&&!!v.clearcoatRoughnessMap,it=In&&!!v.diffuseRoughnessMap,J=mt&&!!v.iridescenceMap,ot=mt&&!!v.iridescenceThicknessMap,ft=Fe&&!!v.sheenColorMap,q=Fe&&!!v.sheenRoughnessMap,Y=!!v.specularMap,ct=!!v.specularColorMap,C=!!v.specularIntensityMap,Z=Dt&&!!v.transmissionMap,W=Dt&&!!v.thicknessMap,dt=!!v.gradientMap,rt=!!v.alphaMap,lt=v.alphaTest>0,Tt=!!v.alphaHash,Wt=!!v.extensions;let at=Di;v.toneMapped&&(Lt===null||Lt.isXRRenderTarget===!0)&&(at=i.toneMapping);const Ct=Kt?z.isCompressedCubeTexture?z.image[0].mipmaps:z.mipmaps:null,Vt={shaderID:et,shaderType:v.type,shaderName:v.name,vertexShader:$t,fragmentShader:K,defines:v.defines,customVertexShaderID:xt,customFragmentShaderID:Mt,isRawShaderMaterial:v.isRawShaderMaterial===!0,glslVersion:v.glslVersion,precision:V,batching:Pe,batchingColor:Pe&&N._colorsTexture!==null,instancing:Gt,instancingColor:Gt&&N.instanceColor!==null,instancingMorph:Gt&&N.morphTexture!==null,outputColorSpace:Lt===null?i.outputColorSpace:Lt.isXRRenderTarget===!0?Lt.texture.colorSpace:te.workingColorSpace,alphaToCoverage:!!v.alphaToCoverage,map:Nt,matcap:re,envMap:de,envMapMode:de&&z.mapping,envMapPMREM:Kt,envMapMaxLod:Kt?Ct.length-1:null,envMapSize:Kt?Ct[0].width:null,aoMap:Ke,lightMap:Ue,bumpMap:mn,normalMap:Se,displacementMap:ri,emissiveMap:ze,normalMapObjectSpace:Se&&v.normalMapType===Cm,normalMapTangentSpace:Se&&v.normalMapType===ro,packedNormalMap:Se&&v.normalMapType===ro&&eb(v.normalMap.format),metalnessMap:Pn,roughnessMap:Ln,anisotropy:Dn,anisotropyMap:Ot,clearcoat:U,clearcoatMap:T,clearcoatNormalMap:_,clearcoatRoughnessMap:B,diffuseRoughness:In,diffuseRoughnessMap:it,dispersion:be,retroreflection:_e,iridescence:mt,iridescenceMap:J,iridescenceThicknessMap:ot,sheen:Fe,sheenColorMap:ft,sheenRoughnessMap:q,specularMap:Y,specularColorMap:ct,specularIntensityMap:C,transmission:Dt,transmissionMap:Z,thicknessMap:W,gradientMap:dt,opaque:v.transparent===!1&&v.blending===Ia&&v.alphaToCoverage===!1,alphaMap:rt,alphaTest:lt,alphaHash:Tt,combine:v.combine,mapUv:Nt&&f(v.map.channel),aoMapUv:Ke&&f(v.aoMap.channel),lightMapUv:Ue&&f(v.lightMap.channel),bumpMapUv:mn&&f(v.bumpMap.channel),normalMapUv:Se&&f(v.normalMap.channel),displacementMapUv:ri&&f(v.displacementMap.channel),emissiveMapUv:ze&&f(v.emissiveMap.channel),metalnessMapUv:Pn&&f(v.metalnessMap.channel),roughnessMapUv:Ln&&f(v.roughnessMap.channel),anisotropyMapUv:Ot&&f(v.anisotropyMap.channel),clearcoatMapUv:T&&f(v.clearcoatMap.channel),clearcoatNormalMapUv:_&&f(v.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:B&&f(v.clearcoatRoughnessMap.channel),diffuseRoughnessMapUv:it&&f(v.diffuseRoughnessMap.channel),iridescenceMapUv:J&&f(v.iridescenceMap.channel),iridescenceThicknessMapUv:ot&&f(v.iridescenceThicknessMap.channel),sheenColorMapUv:ft&&f(v.sheenColorMap.channel),sheenRoughnessMapUv:q&&f(v.sheenRoughnessMap.channel),specularMapUv:Y&&f(v.specularMap.channel),specularColorMapUv:ct&&f(v.specularColorMap.channel),specularIntensityMapUv:C&&f(v.specularIntensityMap.channel),transmissionMapUv:Z&&f(v.transmissionMap.channel),thicknessMapUv:W&&f(v.thicknessMap.channel),alphaMapUv:rt&&f(v.alphaMap.channel),vertexTangents:!!L.attributes.tangent&&(Se||Dn),vertexNormals:!!L.attributes.normal,vertexColors:v.vertexColors,vertexAlphas:v.vertexColors===!0&&!!L.attributes.color&&L.attributes.color.itemSize===4,pointsUvs:N.isPoints===!0&&!!L.attributes.uv&&(Nt||rt),fog:!!H,useFog:v.fog===!0,fogExp2:!!H&&H.isFogExp2,flatShading:v.wireframe===!1&&(v.flatShading===!0||L.attributes.normal===void 0&&Se===!1&&(v.isMeshLambertMaterial||v.isMeshPhongMaterial||v.isMeshStandardMaterial||v.isMeshPhysicalMaterial)),sizeAttenuation:v.sizeAttenuation===!0,logarithmicDepthBuffer:h,reversedDepthBuffer:yt,skinning:N.isSkinnedMesh===!0,hasPositionAttribute:L.attributes.position!==void 0,morphTargets:L.morphAttributes.position!==void 0,morphNormals:L.morphAttributes.normal!==void 0,morphColors:L.morphAttributes.color!==void 0,morphTargetsCount:nt,morphTextureStride:Et,numSunLights:S.sun.length,numDirLights:S.directional.length,numPointLights:S.point.length,numSpotLights:S.spot.length,numSpotLightMaps:S.spotLightMap.length,numRectAreaLights:S.rectArea.length,numHemiLights:S.hemi.length,numSunLightShadows:S.sunShadowMap.length,numDirLightShadows:S.directionalShadowMap.length,numPointLightShadows:S.pointShadowMap.length,numSpotLightShadows:S.spotShadowMap.length,numSpotLightShadowsWithMaps:S.numSpotLightShadowsWithMaps,numLightProbes:S.numLightProbes,numLightProbeGrids:F.filter(gt=>gt.texture!==null).length,numClippingPlanes:a.numPlanes,numClipIntersection:a.numIntersection,dithering:v.dithering,shadowMapEnabled:i.shadowMap.enabled&&P.length>0,shadowMapType:i.shadowMap.type,toneMapping:at,decodeVideoTexture:Nt&&v.map.isVideoTexture===!0&&te.getTransfer(v.map.colorSpace)===le,decodeVideoTextureEmissive:ze&&v.emissiveMap.isVideoTexture===!0&&te.getTransfer(v.emissiveMap.colorSpace)===le,premultipliedAlpha:v.premultipliedAlpha,doubleSided:v.side===Un,flipSided:v.side===en,useDepthPacking:v.depthPacking>=0,depthPacking:v.depthPacking||0,index0AttributeName:v.index0AttributeName,extensionClipCullDistance:Wt&&v.extensions.clipCullDistance===!0&&e.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(Wt&&v.extensions.multiDraw===!0||Pe)&&e.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:e.has("KHR_parallel_shader_compile"),customProgramCacheKey:v.customProgramCacheKey()};return Vt.vertexUv1s=l.has(1),Vt.vertexUv2s=l.has(2),Vt.vertexUv3s=l.has(3),l.clear(),Vt}function x(v){const S=[];if(v.shaderID?S.push(v.shaderID):(S.push(v.customVertexShaderID),S.push(v.customFragmentShaderID)),v.defines!==void 0)for(const P in v.defines)S.push(P),S.push(v.defines[P]);return v.isRawShaderMaterial===!1&&(m(S,v),p(S,v),S.push(i.outputColorSpace)),S.push(v.customProgramCacheKey),S.join()}function m(v,S){v.push(S.precision),v.push(S.outputColorSpace),v.push(S.envMapMode),v.push(S.envMapPMREM),v.push(S.envMapMaxLod),v.push(S.envMapSize),v.push(S.mapUv),v.push(S.alphaMapUv),v.push(S.lightMapUv),v.push(S.aoMapUv),v.push(S.bumpMapUv),v.push(S.normalMapUv),v.push(S.displacementMapUv),v.push(S.emissiveMapUv),v.push(S.metalnessMapUv),v.push(S.roughnessMapUv),v.push(S.anisotropyMapUv),v.push(S.clearcoatMapUv),v.push(S.clearcoatNormalMapUv),v.push(S.clearcoatRoughnessMapUv),v.push(S.diffuseRoughnessMapUv),v.push(S.iridescenceMapUv),v.push(S.iridescenceThicknessMapUv),v.push(S.sheenColorMapUv),v.push(S.sheenRoughnessMapUv),v.push(S.specularMapUv),v.push(S.specularColorMapUv),v.push(S.specularIntensityMapUv),v.push(S.transmissionMapUv),v.push(S.thicknessMapUv),v.push(S.combine),v.push(S.fogExp2),v.push(S.sizeAttenuation),v.push(S.morphTargetsCount),v.push(S.numSunLights),v.push(S.numDirLights),v.push(S.numPointLights),v.push(S.numSpotLights),v.push(S.numSpotLightMaps),v.push(S.numHemiLights),v.push(S.numRectAreaLights),v.push(S.numSunLightShadows),v.push(S.numDirLightShadows),v.push(S.numPointLightShadows),v.push(S.numSpotLightShadows),v.push(S.numSpotLightShadowsWithMaps),v.push(S.numLightProbes),v.push(S.numLightProbeGrids),v.push(S.shadowMapType),v.push(S.toneMapping),v.push(S.numClippingPlanes),v.push(S.numClipIntersection),v.push(S.depthPacking)}function p(v,S){r.disableAll(),S.instancing&&r.enable(0),S.instancingColor&&r.enable(1),S.instancingMorph&&r.enable(2),S.matcap&&r.enable(3),S.envMap&&r.enable(4),S.normalMapObjectSpace&&r.enable(5),S.normalMapTangentSpace&&r.enable(6),S.clearcoat&&r.enable(7),S.iridescence&&r.enable(8),S.alphaTest&&r.enable(9),S.vertexColors&&r.enable(10),S.vertexAlphas&&r.enable(11),S.vertexUv1s&&r.enable(12),S.vertexUv2s&&r.enable(13),S.vertexUv3s&&r.enable(14),S.vertexTangents&&r.enable(15),S.anisotropy&&r.enable(16),S.alphaHash&&r.enable(17),S.batching&&r.enable(18),S.dispersion&&r.enable(19),S.retroreflection&&r.enable(24),S.diffuseRoughness&&r.enable(25),S.batchingColor&&r.enable(20),S.gradientMap&&r.enable(21),S.packedNormalMap&&r.enable(22),S.vertexNormals&&r.enable(23),v.push(r.mask),r.disableAll(),S.fog&&r.enable(0),S.useFog&&r.enable(1),S.flatShading&&r.enable(2),S.logarithmicDepthBuffer&&r.enable(3),S.reversedDepthBuffer&&r.enable(4),S.skinning&&r.enable(5),S.morphTargets&&r.enable(6),S.morphNormals&&r.enable(7),S.morphColors&&r.enable(8),S.premultipliedAlpha&&r.enable(9),S.shadowMapEnabled&&r.enable(10),S.doubleSided&&r.enable(11),S.flipSided&&r.enable(12),S.useDepthPacking&&r.enable(13),S.dithering&&r.enable(14),S.transmission&&r.enable(15),S.sheen&&r.enable(16),S.opaque&&r.enable(17),S.pointsUvs&&r.enable(18),S.decodeVideoTexture&&r.enable(19),S.decodeVideoTextureEmissive&&r.enable(20),S.alphaToCoverage&&r.enable(21),S.numLightProbeGrids>0&&r.enable(22),S.hasPositionAttribute&&r.enable(23),v.push(r.mask)}function y(v){const S=u[v.type];let P;if(S){const R=ci[S];P=A0.clone(R.uniforms)}else P=v.uniforms;return P}function A(v,S){let P=d.get(S);return P!==void 0?++P.usedTimes:(P=new Jy(i,S,v,s),c.push(P),d.set(S,P)),P}function b(v){if(--v.usedTimes===0){const S=c.indexOf(v);c[S]=c[c.length-1],c.pop(),d.delete(v.cacheKey),v.destroy()}}function w(v){o.remove(v)}function E(){o.dispose()}return{getParameters:g,getProgramCacheKey:x,getUniforms:y,acquireProgram:A,releaseProgram:b,releaseShaderCache:w,programs:c,dispose:E}}function ib(){let i=new WeakMap;function t(r){return i.has(r)}function e(r){let o=i.get(r);return o===void 0&&(o={},i.set(r,o)),o}function n(r){i.delete(r)}function s(r,o,l){i.get(r)[o]=l}function a(){i=new WeakMap}return{has:t,get:e,remove:n,update:s,dispose:a}}function sb(i,t){return i.groupOrder!==t.groupOrder?i.groupOrder-t.groupOrder:i.renderOrder!==t.renderOrder?i.renderOrder-t.renderOrder:i.material.id!==t.material.id?i.material.id-t.material.id:i.materialVariant!==t.materialVariant?i.materialVariant-t.materialVariant:i.z!==t.z?i.z-t.z:i.id-t.id}function jh(i,t){return i.groupOrder!==t.groupOrder?i.groupOrder-t.groupOrder:i.renderOrder!==t.renderOrder?i.renderOrder-t.renderOrder:i.z!==t.z?t.z-i.z:i.id-t.id}function Qh(){const i=[];let t=0;const e=[],n=[],s=[];function a(){t=0,e.length=0,n.length=0,s.length=0}function r(u){let f=0;return u.isInstancedMesh&&(f+=2),u.isSkinnedMesh&&(f+=1),f}function o(u,f,g,x,m,p){let y=i[t];return y===void 0?(y={id:u.id,object:u,geometry:f,material:g,materialVariant:r(u),groupOrder:x,renderOrder:u.renderOrder,z:m,group:p},i[t]=y):(y.id=u.id,y.object=u,y.geometry=f,y.material=g,y.materialVariant=r(u),y.groupOrder=x,y.renderOrder=u.renderOrder,y.z=m,y.group=p),t++,y}function l(u,f,g,x,m,p,y){y.reversedDepth===!0&&(m=-m);const A=o(u,f,g,x,m,p);g.transmission>0?n.push(A):g.transparent===!0?s.push(A):e.push(A)}function c(u,f,g,x,m,p){const y=o(u,f,g,x,m,p);g.transmission>0?n.unshift(y):g.transparent===!0?s.unshift(y):e.unshift(y)}function d(u,f){e.length>1&&e.sort(u||sb),n.length>1&&n.sort(f||jh),s.length>1&&s.sort(f||jh)}function h(){for(let u=t,f=i.length;u<f;u++){const g=i[u];if(g.id===null)break;g.id=null,g.object=null,g.geometry=null,g.material=null,g.group=null}}return{opaque:e,transmissive:n,transparent:s,init:a,push:l,unshift:c,finish:h,sort:d}}function ab(){let i=new WeakMap;function t(n,s){const a=i.get(n);let r;return a===void 0?(r=new Qh,i.set(n,[r])):s>=a.length?(r=new Qh,a.push(r)):r=a[s],r}function e(){i=new WeakMap}return{get:t,dispose:e}}function rb(){const i={};return{get:function(t){if(i[t.id]!==void 0)return i[t.id];let e;switch(t.type){case"SunLight":case"DirectionalLight":e={direction:new D,color:new Rt};break;case"SpotLight":e={position:new D,direction:new D,color:new Rt,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":e={position:new D,color:new Rt,distance:0,decay:0};break;case"HemisphereLight":e={direction:new D,skyColor:new Rt,groundColor:new Rt};break;case"RectAreaLight":e={color:new Rt,position:new D,halfWidth:new D,halfHeight:new D};break}return i[t.id]=e,e}}}function ob(){const i={};return{get:function(t){if(i[t.id]!==void 0)return i[t.id];let e;switch(t.type){case"SunLight":case"DirectionalLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new It};break;case"SpotLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new It};break;case"PointLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new It,shadowCameraNear:1,shadowCameraFar:1e3};break}return i[t.id]=e,e}}}let lb=0;function cb(i,t){return(t.castShadow?2:0)-(i.castShadow?2:0)+(t.map?1:0)-(i.map?1:0)}function db(i){const t=new rb,e=ob(),n={version:0,hash:{sunLength:-1,directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numSunShadows:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],sun:[],sunShadow:[],sunShadowMap:[],sunShadowMatrix:[],sunShadowCascade:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let c=0;c<9;c++)n.probe.push(new D);const s=new D,a=new ee,r=new ee;function o(c){let d=0,h=0,u=0;for(let F=0;F<9;F++)n.probe[F].set(0,0,0);let f=0,g=0,x=0,m=0,p=0,y=0,A=0,b=0,w=0,E=0,v=0,S=0,P=0,R=0;c.sort(cb);for(let F=0,H=c.length;F<H;F++){const L=c[F],$=L.color,X=L.intensity,z=L.distance;let et=null;if(L.shadow&&L.shadow.map&&(L.shadow.map.texture.format===ms?et=L.shadow.map.texture:et=L.shadow.map.depthTexture||L.shadow.map.texture),L.isAmbientLight)d+=$.r*X,h+=$.g*X,u+=$.b*X;else if(L.isLightProbe){for(let V=0;V<9;V++)n.probe[V].addScaledVector(L.sh.coefficients[V],X);R++}else if(L.isSunLight){const V=t.get(L);if(V.color.copy(L.color).multiplyScalar(L.intensity),L.castShadow){const Q=L.shadow,nt=e.get(L);nt.shadowIntensity=Q.intensity,nt.shadowBias=Q.bias,nt.shadowNormalBias=Q.normalBias,nt.shadowRadius=Q.radius,nt.shadowMapSize.copy(Q.mapSize).multiply(Q.getFrameExtents()),n.sunShadow[g]=nt,n.sunShadowMap[g]=et;const Et=Q.getViewportCount();for(let $t=0;$t<Et;$t++)n.sunShadowMatrix[x+$t]=Q.getMatrix($t),n.sunShadowCascade[x+$t]=Q._cascadeData[$t];x+=Et,g++}n.sun[f]=V,f++}else if(L.isDirectionalLight){const V=t.get(L);if(V.color.copy(L.color).multiplyScalar(L.intensity),L.castShadow){const Q=L.shadow,nt=e.get(L);nt.shadowIntensity=Q.intensity,nt.shadowBias=Q.bias,nt.shadowNormalBias=Q.normalBias,nt.shadowRadius=Q.radius,nt.shadowMapSize=Q.mapSize,n.directionalShadow[m]=nt,n.directionalShadowMap[m]=et,n.directionalShadowMatrix[m]=L.shadow.matrix,w++}n.directional[m]=V,m++}else if(L.isSpotLight){const V=t.get(L);V.position.setFromMatrixPosition(L.matrixWorld),V.color.copy($).multiplyScalar(X),V.distance=z,V.coneCos=Math.cos(L.angle),V.penumbraCos=Math.cos(L.angle*(1-L.penumbra)),V.decay=L.decay,n.spot[y]=V;const Q=L.shadow;if(L.map&&(n.spotLightMap[S]=L.map,S++,Q.updateMatrices(L),L.castShadow&&P++),n.spotLightMatrix[y]=Q.matrix,L.castShadow){const nt=e.get(L);nt.shadowIntensity=Q.intensity,nt.shadowBias=Q.bias,nt.shadowNormalBias=Q.normalBias,nt.shadowRadius=Q.radius,nt.shadowMapSize=Q.mapSize,n.spotShadow[y]=nt,n.spotShadowMap[y]=et,v++}y++}else if(L.isRectAreaLight){const V=t.get(L);V.color.copy($).multiplyScalar(X),V.halfWidth.set(L.width*.5,0,0),V.halfHeight.set(0,L.height*.5,0),n.rectArea[A]=V,A++}else if(L.isPointLight){const V=t.get(L);if(V.color.copy(L.color).multiplyScalar(L.intensity),V.distance=L.distance,V.decay=L.decay,L.castShadow){const Q=L.shadow,nt=e.get(L);nt.shadowIntensity=Q.intensity,nt.shadowBias=Q.bias,nt.shadowNormalBias=Q.normalBias,nt.shadowRadius=Q.radius,nt.shadowMapSize=Q.mapSize,nt.shadowCameraNear=Q.camera.near,nt.shadowCameraFar=Q.camera.far,n.pointShadow[p]=nt,n.pointShadowMap[p]=et,n.pointShadowMatrix[p]=L.shadow.matrix,E++}n.point[p]=V,p++}else if(L.isHemisphereLight){const V=t.get(L);V.skyColor.copy(L.color).multiplyScalar(X),V.groundColor.copy(L.groundColor).multiplyScalar(X),n.hemi[b]=V,b++}}A>0&&(i.has("OES_texture_float_linear")===!0?(n.rectAreaLTC1=vt.LTC_FLOAT_1,n.rectAreaLTC2=vt.LTC_FLOAT_2):(n.rectAreaLTC1=vt.LTC_HALF_1,n.rectAreaLTC2=vt.LTC_HALF_2)),n.ambient[0]=d,n.ambient[1]=h,n.ambient[2]=u;const N=n.hash;(N.sunLength!==f||N.directionalLength!==m||N.pointLength!==p||N.spotLength!==y||N.rectAreaLength!==A||N.hemiLength!==b||N.numSunShadows!==g||N.numDirectionalShadows!==w||N.numPointShadows!==E||N.numSpotShadows!==v||N.numSpotMaps!==S||N.numLightProbes!==R)&&(n.sun.length=f,n.directional.length=m,n.spot.length=y,n.rectArea.length=A,n.point.length=p,n.hemi.length=b,n.sunShadow.length=g,n.sunShadowMap.length=g,n.sunShadowMatrix.length=x,n.sunShadowCascade.length=x,n.directionalShadow.length=w,n.directionalShadowMap.length=w,n.directionalShadowMatrix.length=w,n.pointShadow.length=E,n.pointShadowMap.length=E,n.pointShadowMatrix.length=E,n.spotShadow.length=v,n.spotShadowMap.length=v,n.spotLightMatrix.length=v+S-P,n.spotLightMap.length=S,n.numSpotLightShadowsWithMaps=P,n.numLightProbes=R,N.sunLength=f,N.directionalLength=m,N.pointLength=p,N.spotLength=y,N.rectAreaLength=A,N.hemiLength=b,N.numSunShadows=g,N.numDirectionalShadows=w,N.numPointShadows=E,N.numSpotShadows=v,N.numSpotMaps=S,N.numLightProbes=R,n.version=lb++)}function l(c,d){let h=0,u=0,f=0,g=0,x=0,m=0;const p=d.matrixWorldInverse;for(let y=0,A=c.length;y<A;y++){const b=c[y];if(b.isSunLight){const w=n.sun[h];w.direction.setFromMatrixPosition(b.matrixWorld),w.direction.transformDirection(p),h++}else if(b.isDirectionalLight){const w=n.directional[u];w.direction.setFromMatrixPosition(b.matrixWorld),s.setFromMatrixPosition(b.target.matrixWorld),w.direction.sub(s),w.direction.transformDirection(p),u++}else if(b.isSpotLight){const w=n.spot[g];w.position.setFromMatrixPosition(b.matrixWorld),w.position.applyMatrix4(p),w.direction.setFromMatrixPosition(b.matrixWorld),s.setFromMatrixPosition(b.target.matrixWorld),w.direction.sub(s),w.direction.transformDirection(p),g++}else if(b.isRectAreaLight){const w=n.rectArea[x];w.position.setFromMatrixPosition(b.matrixWorld),w.position.applyMatrix4(p),r.identity(),a.copy(b.matrixWorld),a.premultiply(p),r.extractRotation(a),w.halfWidth.set(b.width*.5,0,0),w.halfHeight.set(0,b.height*.5,0),w.halfWidth.applyMatrix4(r),w.halfHeight.applyMatrix4(r),x++}else if(b.isPointLight){const w=n.point[f];w.position.setFromMatrixPosition(b.matrixWorld),w.position.applyMatrix4(p),f++}else if(b.isHemisphereLight){const w=n.hemi[m];w.direction.setFromMatrixPosition(b.matrixWorld),w.direction.transformDirection(p),m++}}}return{setup:o,setupView:l,state:n}}function tu(i){const t=new db(i),e=[],n=[],s=[];function a(h){d.camera=h,e.length=0,n.length=0,s.length=0}function r(h){h.isLightProbeGrid?s.push(h):e.push(h)}function o(h){n.push(h)}function l(){t.setup(e),s.sort((h,u)=>h.priority-u.priority||h.id-u.id)}function c(h){t.setupView(e,h)}const d={lightsArray:e,shadowsArray:n,lightProbeGridArray:s,camera:null,lights:t,transmissionRenderTarget:{},textureUnits:0};return{init:a,state:d,setupLights:l,setupLightsView:c,pushLight:r,pushShadow:o}}function hb(i){let t=new WeakMap;function e(s,a=0){const r=t.get(s);let o;return r===void 0?(o=new tu(i),t.set(s,[o])):a>=r.length?(o=new tu(i),r.push(o)):o=r[a],o}function n(){t=new WeakMap}return{get:e,dispose:n}}const ub=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,fb=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ).rg;
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ).r;
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( max( 0.0, squared_mean - mean * mean ) );
	gl_FragColor = vec4( mean, std_dev, 0.0, 1.0 );
}`,pb=[new D(1,0,0),new D(-1,0,0),new D(0,1,0),new D(0,-1,0),new D(0,0,1),new D(0,0,-1)],mb=[new D(0,-1,0),new D(0,-1,0),new D(0,0,1),new D(0,0,-1),new D(0,-1,0),new D(0,-1,0)],eu=new ee,_a=new D,Ll=new D;function gb(i,t,e){let n=new Va;const s=new It,a=new It,r=new Ae,o=new L0,l=new D0,c={},d=e.maxTextureSize,h={[ps]:en,[en]:ps,[Un]:Un},u=new En({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new It},radius:{value:4}},vertexShader:ub,fragmentShader:fb}),f=u.clone();f.defines.HORIZONTAL_PASS=1;const g=new ge;g.setAttribute("position",new Ne(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const x=new Pt(g,u),m=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=Wr;let p=this.type;this.render=function(E,v,S){if(m.enabled===!1||m.autoUpdate===!1&&m.needsUpdate===!1||E.length===0)return;this.type===af&&(Ut("WebGLShadowMap: PCFSoftShadowMap has been removed. Using PCFShadowMap instead."),this.type=Wr);const P=i.getRenderTarget(),R=i.getActiveCubeFace(),N=i.getActiveMipmapLevel(),F=i.state;F.setBlending(qs),F.buffers.depth.getReversed()===!0?F.buffers.color.setClear(0,0,0,0):F.buffers.color.setClear(1,1,1,1),F.buffers.depth.setTest(!0),F.setScissorTest(!1);const H=p!==this.type;H&&v.traverse(function(L){L.material&&(Array.isArray(L.material)?L.material.forEach($=>$.needsUpdate=!0):L.material.needsUpdate=!0)});for(let L=0,$=E.length;L<$;L++){const X=E[L],z=X.shadow;if(z===void 0){Ut("WebGLShadowMap:",X,"has no shadow.");continue}if(z.autoUpdate===!1&&z.needsUpdate===!1)continue;s.copy(z.mapSize);const et=z.getFrameExtents();s.multiply(et),a.copy(z.mapSize),(s.x>d||s.y>d)&&(s.x>d&&(a.x=Math.floor(d/et.x),s.x=a.x*et.x,z.mapSize.x=a.x),s.y>d&&(a.y=Math.floor(d/et.y),s.y=a.y*et.y,z.mapSize.y=a.y));const V=i.state.buffers.depth.getReversed();if(z.camera._reversedDepth=V,z.map===null||H===!0){if(z.map!==null&&(z.map.depthTexture!==null&&(z.map.depthTexture.dispose(),z.map.depthTexture=null),z.map.dispose()),this.type===wa){if(X.isPointLight){Ut("WebGLShadowMap: VSM shadow maps are not supported for PointLights. Use PCF or BasicShadowMap instead.");continue}z.map=new Bn(s.x,s.y,{format:ms,type:mi,minFilter:pn,magFilter:pn,generateMipmaps:!1}),z.map.texture.name=X.name+".shadowMap",z.map.depthTexture=new aa(s.x,s.y,ti),z.map.depthTexture.name=X.name+".shadowMapDepth",z.map.depthTexture.format=Qi,z.map.depthTexture.compareFunction=null,z.map.depthTexture.minFilter=Qe,z.map.depthTexture.magFilter=Qe}else X.isPointLight?(z.map=new xd(s.x),z.map.depthTexture=new Uf(s.x,pi)):(z.map=new Bn(s.x,s.y),z.map.depthTexture=new aa(s.x,s.y,pi)),z.map.depthTexture.name=X.name+".shadowMap",z.map.depthTexture.format=Qi,this.type===Wr?(z.map.depthTexture.compareFunction=V?Mf:_f,z.map.depthTexture.minFilter=pn,z.map.depthTexture.magFilter=pn):(z.map.depthTexture.compareFunction=null,z.map.depthTexture.minFilter=Qe,z.map.depthTexture.magFilter=Qe);z.camera.updateProjectionMatrix()}z.map.isWebGLCubeRenderTarget!==!0&&(z.map.width!==s.x||z.map.height!==s.y)&&z.map.setSize(s.x,s.y);const Q=z.map.isWebGLCubeRenderTarget?6:z.getViewportCount();X.isPointLight!==!0&&z.updateMatrices(X,S);const nt=(z.camera.layers.mask&4294967294)!==0?z.camera.layers:S.layers;for(let Et=0;Et<Q;Et++){const $t=z.getCamera(Et);if(X.isPointLight){const K=z.camera,xt=z.matrix,Mt=X.distance||K.far;Mt!==K.far&&(K.far=Mt,K.updateProjectionMatrix()),_a.setFromMatrixPosition(X.matrixWorld),K.position.copy(_a),Ll.copy(K.position),Ll.add(pb[Et]),K.up.copy(mb[Et]),K.lookAt(Ll),K.updateMatrixWorld(),xt.makeTranslation(-_a.x,-_a.y,-_a.z),eu.multiplyMatrices(K.projectionMatrix,K.matrixWorldInverse),z._frustum.setFromProjectionMatrix(eu,K.coordinateSystem,K.reversedDepth)}if(z.map.isWebGLCubeRenderTarget)i.setRenderTarget(z.map,Et),i.clear();else{Et===0&&(i.setRenderTarget(z.map),i.clear());const K=z.getViewport(Et);r.set(a.x*K.x,a.y*K.y,a.x*K.z,a.y*K.w),F.viewport(r)}n=z.getFrustum(Et),b(v,S,$t,X,nt,this.type)}z.isPointLightShadow!==!0&&this.type===wa&&y(z,S),z.needsUpdate=!1}p=this.type,m.needsUpdate=!1,i.setRenderTarget(P,R,N)};function y(E,v){const S=t.update(x);u.defines.VSM_SAMPLES!==E.blurSamples&&(u.defines.VSM_SAMPLES=E.blurSamples,f.defines.VSM_SAMPLES=E.blurSamples,u.needsUpdate=!0,f.needsUpdate=!0),E.mapPass===null?E.mapPass=new Bn(s.x,s.y,{format:ms,type:mi}):(E.mapPass.width!==E.map.width||E.mapPass.height!==E.map.height)&&E.mapPass.setSize(E.map.width,E.map.height),u.uniforms.shadow_pass.value=E.map.depthTexture,u.uniforms.resolution.value.set(E.map.width,E.map.height),u.uniforms.radius.value=E.radius,i.setRenderTarget(E.mapPass),i.clear(),i.renderBufferDirect(v,null,S,u,x,null),f.uniforms.shadow_pass.value=E.mapPass.texture,f.uniforms.resolution.value.set(E.map.width,E.map.height),f.uniforms.radius.value=E.radius,i.setRenderTarget(E.map),i.clear(),i.renderBufferDirect(v,null,S,f,x,null)}function A(E,v,S,P){let R=null;const N=S.isPointLight===!0?E.customDistanceMaterial:E.customDepthMaterial;if(N!==void 0)R=N;else if(R=S.isPointLight===!0?l:o,i.localClippingEnabled&&v.clipShadows===!0&&Array.isArray(v.clippingPlanes)&&v.clippingPlanes.length!==0||v.displacementMap&&v.displacementScale!==0||v.alphaMap&&v.alphaTest>0||v.map&&v.alphaTest>0||v.alphaToCoverage===!0){const F=R.uuid,H=v.uuid;let L=c[F];L===void 0&&(L={},c[F]=L);let $=L[H];$===void 0&&($=R.clone(),L[H]=$,v.addEventListener("dispose",w)),R=$}if(R.visible=v.visible,R.wireframe=v.wireframe,P===wa?R.side=v.shadowSide!==null?v.shadowSide:v.side:R.side=v.shadowSide!==null?v.shadowSide:h[v.side],R.alphaMap=v.alphaMap,R.alphaTest=v.alphaToCoverage===!0?.5:v.alphaTest,R.map=v.map,R.clipShadows=v.clipShadows,R.clippingPlanes=v.clippingPlanes,R.clipIntersection=v.clipIntersection,R.displacementMap=v.displacementMap,R.displacementScale=v.displacementScale,R.displacementBias=v.displacementBias,R.wireframeLinewidth=v.wireframeLinewidth,R.linewidth=v.linewidth,S.isPointLight===!0&&R.isMeshDistanceMaterial===!0){const F=i.properties.get(R);F.light=S}return R}function b(E,v,S,P,R,N){if(E.visible===!1)return;if(E.layers.test(R)&&(E.isMesh||E.isLine||E.isPoints)&&(E.castShadow||E.receiveShadow&&N===wa)&&(!E.frustumCulled||E.intersectsFrustum(n))){E.modelViewMatrix.multiplyMatrices(S.matrixWorldInverse,E.matrixWorld);const L=t.update(E),$=E.material;if(Array.isArray($)){const X=L.groups;for(let z=0,et=X.length;z<et;z++){const V=X[z],Q=$[V.materialIndex];if(Q&&Q.visible){const nt=A(E,Q,P,N);E.onBeforeShadow(i,E,v,S,L,nt,V),i.renderBufferDirect(S,null,L,nt,E,V),E.onAfterShadow(i,E,v,S,L,nt,V)}}}else if($.visible){const X=A(E,$,P,N);E.onBeforeShadow(i,E,v,S,L,X,null),i.renderBufferDirect(S,null,L,X,E,null),E.onAfterShadow(i,E,v,S,L,X,null)}}const H=E.children;for(let L=0,$=H.length;L<$;L++)b(H[L],v,S,P,R,N)}function w(E){E.target.removeEventListener("dispose",w);for(const S in c){const P=c[S],R=E.target.uuid;R in P&&(P[R].dispose(),delete P[R])}}}function vb(i,t){function e(){let C=!1;const Z=new Ae;let W=null;const dt=new Ae(0,0,0,0);return{setMask:function(rt){W!==rt&&!C&&(i.colorMask(rt,rt,rt,rt),W=rt)},setLocked:function(rt){C=rt},setClear:function(rt,lt,Tt,Wt,at){at===!0&&(rt*=Wt,lt*=Wt,Tt*=Wt),Z.set(rt,lt,Tt,Wt),dt.equals(Z)===!1&&(i.clearColor(rt,lt,Tt,Wt),dt.copy(Z))},reset:function(){C=!1,W=null,dt.set(-1,0,0,0)}}}function n(){let C=!1,Z=!1,W=null,dt=null,rt=null;return{setReversed:function(lt){if(Z!==lt){const Tt=t.get("EXT_clip_control");lt?Tt.clipControlEXT(Tt.LOWER_LEFT_EXT,Tt.ZERO_TO_ONE_EXT):Tt.clipControlEXT(Tt.LOWER_LEFT_EXT,Tt.NEGATIVE_ONE_TO_ONE_EXT),Z=lt;const Wt=rt;rt=null,this.setClear(Wt)}},getReversed:function(){return Z},setTest:function(lt){lt?yt(i.DEPTH_TEST):Gt(i.DEPTH_TEST)},setMask:function(lt){W!==lt&&!C&&(i.depthMask(lt),W=lt)},setFunc:function(lt){if(Z&&(lt=km[lt]),dt!==lt){switch(lt){case ql:i.depthFunc(i.NEVER);break;case Yl:i.depthFunc(i.ALWAYS);break;case Kl:i.depthFunc(i.LESS);break;case ka:i.depthFunc(i.LEQUAL);break;case Zl:i.depthFunc(i.EQUAL);break;case Jl:i.depthFunc(i.GEQUAL);break;case jl:i.depthFunc(i.GREATER);break;case Ql:i.depthFunc(i.NOTEQUAL);break;default:i.depthFunc(i.LEQUAL)}dt=lt}},setLocked:function(lt){C=lt},setClear:function(lt){rt!==lt&&(rt=lt,Z&&(lt=1-lt),i.clearDepth(lt))},reset:function(){C=!1,W=null,dt=null,rt=null,Z=!1}}}function s(){let C=!1,Z=null,W=null,dt=null,rt=null,lt=null,Tt=null,Wt=null,at=null;return{setTest:function(Ct){C||(Ct?yt(i.STENCIL_TEST):Gt(i.STENCIL_TEST))},setMask:function(Ct){Z!==Ct&&!C&&(i.stencilMask(Ct),Z=Ct)},setFunc:function(Ct,Vt,gt){(W!==Ct||dt!==Vt||rt!==gt)&&(i.stencilFunc(Ct,Vt,gt),W=Ct,dt=Vt,rt=gt)},setOp:function(Ct,Vt,gt){(lt!==Ct||Tt!==Vt||Wt!==gt)&&(i.stencilOp(Ct,Vt,gt),lt=Ct,Tt=Vt,Wt=gt)},setLocked:function(Ct){C=Ct},setClear:function(Ct){at!==Ct&&(i.clearStencil(Ct),at=Ct)},reset:function(){C=!1,Z=null,W=null,dt=null,rt=null,lt=null,Tt=null,Wt=null,at=null}}}const a=new e,r=new n,o=new s;let l={};const c=new WeakMap;let d={},h={},u={},f=new WeakMap,g=[],x=null,m=!1,p=null,y=null,A=null,b=null,w=null,E=null,v=null,S=new Rt(0,0,0),P=0,R=!1,N=null,F=null,H=null,L=null,$=null;const X=i.getParameter(i.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let z=!1,et=0;const V=i.getParameter(i.VERSION);V.indexOf("WebGL")!==-1?(et=parseFloat(/^WebGL (\d)/.exec(V)[1]),z=et>=1):V.indexOf("OpenGL ES")!==-1&&(et=parseFloat(/^OpenGL ES (\d)/.exec(V)[1]),z=et>=2);let Q=null,nt={};const Et=i.getParameter(i.SCISSOR_BOX),$t=i.getParameter(i.VIEWPORT),K=new Ae().fromArray(Et),xt=new Ae().fromArray($t);function Mt(C,Z,W,dt){const rt=new Uint8Array(4),lt=i.createTexture();i.bindTexture(C,lt),i.texParameteri(C,i.TEXTURE_MIN_FILTER,i.NEAREST),i.texParameteri(C,i.TEXTURE_MAG_FILTER,i.NEAREST);for(let Tt=0;Tt<W;Tt++)C===i.TEXTURE_3D||C===i.TEXTURE_2D_ARRAY?i.texImage3D(Z,0,i.RGBA,1,1,dt,0,i.RGBA,i.UNSIGNED_BYTE,rt):i.texImage2D(Z+Tt,0,i.RGBA,1,1,0,i.RGBA,i.UNSIGNED_BYTE,rt);return lt}const Lt={};Lt[i.TEXTURE_2D]=Mt(i.TEXTURE_2D,i.TEXTURE_2D,1),Lt[i.TEXTURE_CUBE_MAP]=Mt(i.TEXTURE_CUBE_MAP,i.TEXTURE_CUBE_MAP_POSITIVE_X,6),Lt[i.TEXTURE_2D_ARRAY]=Mt(i.TEXTURE_2D_ARRAY,i.TEXTURE_2D_ARRAY,1,1),Lt[i.TEXTURE_3D]=Mt(i.TEXTURE_3D,i.TEXTURE_3D,1,1),a.setClear(0,0,0,1),r.setClear(1),o.setClear(0),yt(i.DEPTH_TEST),r.setFunc(ka),mn(!1),Se(qd),yt(i.CULL_FACE),Ke(qs);function yt(C){d[C]!==!0&&(i.enable(C),d[C]=!0)}function Gt(C){d[C]!==!1&&(i.disable(C),d[C]=!1)}function Pe(C,Z){return u[C]!==Z?(i.bindFramebuffer(C,Z),u[C]=Z,C===i.DRAW_FRAMEBUFFER&&(u[i.FRAMEBUFFER]=Z),C===i.FRAMEBUFFER&&(u[i.DRAW_FRAMEBUFFER]=Z),!0):!1}function Nt(C,Z){let W=g,dt=!1;if(C){W=f.get(Z),W===void 0&&(W=[],f.set(Z,W));const rt=C.textures;if(W.length!==rt.length||W[0]!==i.COLOR_ATTACHMENT0){for(let lt=0,Tt=rt.length;lt<Tt;lt++)W[lt]=i.COLOR_ATTACHMENT0+lt;W.length=rt.length,dt=!0}}else W[0]!==i.BACK&&(W[0]=i.BACK,dt=!0);dt&&i.drawBuffers(W)}function re(C){return x!==C?(i.useProgram(C),x=C,!0):!1}const de={[Vs]:i.FUNC_ADD,[lm]:i.FUNC_SUBTRACT,[cm]:i.FUNC_REVERSE_SUBTRACT};de[dm]=i.MIN,de[hm]=i.MAX;const Kt={[um]:i.ZERO,[fm]:i.ONE,[pm]:i.SRC_COLOR,[rf]:i.SRC_ALPHA,[bm]:i.SRC_ALPHA_SATURATE,[xm]:i.DST_COLOR,[gm]:i.DST_ALPHA,[mm]:i.ONE_MINUS_SRC_COLOR,[of]:i.ONE_MINUS_SRC_ALPHA,[ym]:i.ONE_MINUS_DST_COLOR,[vm]:i.ONE_MINUS_DST_ALPHA,[_m]:i.CONSTANT_COLOR,[Mm]:i.ONE_MINUS_CONSTANT_COLOR,[Sm]:i.CONSTANT_ALPHA,[wm]:i.ONE_MINUS_CONSTANT_ALPHA};function Ke(C,Z,W,dt,rt,lt,Tt,Wt,at,Ct){if(C===qs){m===!0&&(Gt(i.BLEND),m=!1);return}if(m===!1&&(yt(i.BLEND),m=!0),C!==om){if(C!==p||Ct!==R){if((y!==Vs||w!==Vs)&&(i.blendEquation(i.FUNC_ADD),y=Vs,w=Vs),Ct)switch(C){case Ia:i.blendFuncSeparate(i.ONE,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case Zi:i.blendFunc(i.ONE,i.ONE);break;case Yd:i.blendFuncSeparate(i.ZERO,i.ONE_MINUS_SRC_COLOR,i.ZERO,i.ONE);break;case Kd:i.blendFuncSeparate(i.DST_COLOR,i.ONE_MINUS_SRC_ALPHA,i.ZERO,i.ONE);break;default:ie("WebGLState: Invalid blending: ",C);break}else switch(C){case Ia:i.blendFuncSeparate(i.SRC_ALPHA,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case Zi:i.blendFuncSeparate(i.SRC_ALPHA,i.ONE,i.ONE,i.ONE);break;case Yd:ie("WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true");break;case Kd:ie("WebGLState: MultiplyBlending requires material.premultipliedAlpha = true");break;default:ie("WebGLState: Invalid blending: ",C);break}A=null,b=null,E=null,v=null,S.set(0,0,0),P=0,p=C,R=Ct}return}rt=rt||Z,lt=lt||W,Tt=Tt||dt,(Z!==y||rt!==w)&&(i.blendEquationSeparate(de[Z],de[rt]),y=Z,w=rt),(W!==A||dt!==b||lt!==E||Tt!==v)&&(i.blendFuncSeparate(Kt[W],Kt[dt],Kt[lt],Kt[Tt]),A=W,b=dt,E=lt,v=Tt),(Wt.equals(S)===!1||at!==P)&&(i.blendColor(Wt.r,Wt.g,Wt.b,at),S.copy(Wt),P=at),p=C,R=!1}function Ue(C,Z){C.side===Un?Gt(i.CULL_FACE):yt(i.CULL_FACE);let W=C.side===en;Z&&(W=!W),mn(W),C.blending===Ia&&C.transparent===!1?Ke(qs):Ke(C.blending,C.blendEquation,C.blendSrc,C.blendDst,C.blendEquationAlpha,C.blendSrcAlpha,C.blendDstAlpha,C.blendColor,C.blendAlpha,C.premultipliedAlpha),r.setFunc(C.depthFunc),r.setTest(C.depthTest),r.setMask(C.depthWrite),a.setMask(C.colorWrite);const dt=C.stencilWrite;o.setTest(dt),dt&&(o.setMask(C.stencilWriteMask),o.setFunc(C.stencilFunc,C.stencilRef,C.stencilFuncMask),o.setOp(C.stencilFail,C.stencilZFail,C.stencilZPass)),ze(C.polygonOffset,C.polygonOffsetFactor,C.polygonOffsetUnits),C.alphaToCoverage===!0?yt(i.SAMPLE_ALPHA_TO_COVERAGE):Gt(i.SAMPLE_ALPHA_TO_COVERAGE)}function mn(C){N!==C&&(C?i.frontFace(i.CW):i.frontFace(i.CCW),N=C)}function Se(C){C!==am?(yt(i.CULL_FACE),C!==F&&(C===qd?i.cullFace(i.BACK):C===rm?i.cullFace(i.FRONT):i.cullFace(i.FRONT_AND_BACK))):Gt(i.CULL_FACE),F=C}function ri(C){C!==H&&(z&&i.lineWidth(C),H=C)}function ze(C,Z,W){C?(yt(i.POLYGON_OFFSET_FILL),(L!==Z||$!==W)&&(L=Z,$=W,r.getReversed()&&(Z=-Z,W=-W),i.polygonOffset(Z,W))):Gt(i.POLYGON_OFFSET_FILL)}function Pn(C){C?yt(i.SCISSOR_TEST):Gt(i.SCISSOR_TEST)}function Ln(C){C===void 0&&(C=i.TEXTURE0+X-1),Q!==C&&(i.activeTexture(C),Q=C)}function Dn(C,Z,W){W===void 0&&(Q===null?W=i.TEXTURE0+X-1:W=Q);let dt=nt[W];dt===void 0&&(dt={type:void 0,texture:void 0},nt[W]=dt),(dt.type!==C||dt.texture!==Z)&&(Q!==W&&(i.activeTexture(W),Q=W),i.bindTexture(C,Z||Lt[C]),dt.type=C,dt.texture=Z)}function U(){const C=nt[Q];C!==void 0&&C.type!==void 0&&(i.bindTexture(C.type,null),C.type=void 0,C.texture=void 0)}function In(){try{i.compressedTexImage2D(...arguments)}catch(C){ie("WebGLState:",C)}}function be(){try{i.compressedTexImage3D(...arguments)}catch(C){ie("WebGLState:",C)}}function _e(){try{i.texSubImage2D(...arguments)}catch(C){ie("WebGLState:",C)}}function mt(){try{i.texSubImage3D(...arguments)}catch(C){ie("WebGLState:",C)}}function Fe(){try{i.compressedTexSubImage2D(...arguments)}catch(C){ie("WebGLState:",C)}}function Dt(){try{i.compressedTexSubImage3D(...arguments)}catch(C){ie("WebGLState:",C)}}function Ot(){try{i.texStorage2D(...arguments)}catch(C){ie("WebGLState:",C)}}function T(){try{i.texStorage3D(...arguments)}catch(C){ie("WebGLState:",C)}}function _(){try{i.texImage2D(...arguments)}catch(C){ie("WebGLState:",C)}}function B(){try{i.texImage3D(...arguments)}catch(C){ie("WebGLState:",C)}}function it(C){return h[C]!==void 0?h[C]:i.getParameter(C)}function J(C,Z){h[C]!==Z&&(i.pixelStorei(C,Z),h[C]=Z)}function ot(C){K.equals(C)===!1&&(i.scissor(C.x,C.y,C.z,C.w),K.copy(C))}function ft(C){xt.equals(C)===!1&&(i.viewport(C.x,C.y,C.z,C.w),xt.copy(C))}function q(C,Z){let W=c.get(Z);W===void 0&&(W=new WeakMap,c.set(Z,W));let dt=W.get(C);dt===void 0&&(dt=i.getUniformBlockIndex(Z,C.name),i.uniformBlockBinding(Z,dt,dt),W.set(C,dt))}function Y(C,Z,W){const rt=c.get(Z).get(C);l[rt]!==W&&(i.bindBufferBase(i.UNIFORM_BUFFER,rt,W),l[rt]=W)}function ct(){i.disable(i.BLEND),i.disable(i.CULL_FACE),i.disable(i.DEPTH_TEST),i.disable(i.POLYGON_OFFSET_FILL),i.disable(i.SCISSOR_TEST),i.disable(i.STENCIL_TEST),i.disable(i.SAMPLE_ALPHA_TO_COVERAGE),i.blendEquation(i.FUNC_ADD),i.blendFunc(i.ONE,i.ZERO),i.blendFuncSeparate(i.ONE,i.ZERO,i.ONE,i.ZERO),i.blendColor(0,0,0,0),i.colorMask(!0,!0,!0,!0),i.clearColor(0,0,0,0),i.depthMask(!0),i.depthFunc(i.LESS),r.setReversed(!1),i.clearDepth(1),i.stencilMask(4294967295),i.stencilFunc(i.ALWAYS,0,4294967295),i.stencilOp(i.KEEP,i.KEEP,i.KEEP),i.clearStencil(0),i.cullFace(i.BACK),i.frontFace(i.CCW),i.polygonOffset(0,0),i.activeTexture(i.TEXTURE0),i.bindFramebuffer(i.FRAMEBUFFER,null),i.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),i.bindFramebuffer(i.READ_FRAMEBUFFER,null),i.useProgram(null),i.lineWidth(1),i.scissor(0,0,i.canvas.width,i.canvas.height),i.viewport(0,0,i.canvas.width,i.canvas.height),i.pixelStorei(i.PACK_ALIGNMENT,4),i.pixelStorei(i.UNPACK_ALIGNMENT,4),i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,!1),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,!1),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,i.BROWSER_DEFAULT_WEBGL),i.pixelStorei(i.PACK_ROW_LENGTH,0),i.pixelStorei(i.PACK_SKIP_PIXELS,0),i.pixelStorei(i.PACK_SKIP_ROWS,0),i.pixelStorei(i.UNPACK_ROW_LENGTH,0),i.pixelStorei(i.UNPACK_IMAGE_HEIGHT,0),i.pixelStorei(i.UNPACK_SKIP_PIXELS,0),i.pixelStorei(i.UNPACK_SKIP_ROWS,0),i.pixelStorei(i.UNPACK_SKIP_IMAGES,0),d={},h={},Q=null,nt={},u={},l={},f=new WeakMap,g=[],x=null,m=!1,p=null,y=null,A=null,b=null,w=null,E=null,v=null,S=new Rt(0,0,0),P=0,R=!1,N=null,F=null,H=null,L=null,$=null,K.set(0,0,i.canvas.width,i.canvas.height),xt.set(0,0,i.canvas.width,i.canvas.height),a.reset(),r.reset(),o.reset()}return{buffers:{color:a,depth:r,stencil:o},enable:yt,disable:Gt,bindFramebuffer:Pe,drawBuffers:Nt,useProgram:re,setBlending:Ke,setMaterial:Ue,setFlipSided:mn,setCullFace:Se,setLineWidth:ri,setPolygonOffset:ze,setScissorTest:Pn,activeTexture:Ln,bindTexture:Dn,unbindTexture:U,compressedTexImage2D:In,compressedTexImage3D:be,texImage2D:_,texImage3D:B,pixelStorei:J,getParameter:it,updateUBOMapping:q,uniformBlockBinding:Y,texStorage2D:Ot,texStorage3D:T,texSubImage2D:_e,texSubImage3D:mt,compressedTexSubImage2D:Fe,compressedTexSubImage3D:Dt,scissor:ot,viewport:ft,reset:ct}}function xb(i,t,e,n,s,a,r){const o=t.has("WEBGL_multisampled_render_to_texture")?t.get("WEBGL_multisampled_render_to_texture"):null,l=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),c=new It,d=new WeakMap,h=new Set;let u;const f=new WeakMap,g=new Set,x=new FinalizationRegistry(T=>g.delete(T));let m=!1;try{m=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function p(T,_){return m?new OffscreenCanvas(T,_):co("canvas")}function y(T,_,B){let it=1;const J=Ot(T);if((J.width>B||J.height>B)&&(it=B/Math.max(J.width,J.height)),it<1)if(typeof HTMLImageElement<"u"&&T instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&T instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&T instanceof ImageBitmap||typeof VideoFrame<"u"&&T instanceof VideoFrame){const ot=Math.floor(it*J.width),ft=Math.floor(it*J.height);u===void 0&&(u=p(ot,ft));const q=_?p(ot,ft):u;return q.width=ot,q.height=ft,q.getContext("2d").drawImage(T,0,0,ot,ft),Ut("WebGLRenderer: Texture has been resized from ("+J.width+"x"+J.height+") to ("+ot+"x"+ft+")."),q}else return"data"in T&&Ut("WebGLRenderer: Image in DataTexture is too big ("+J.width+"x"+J.height+")."),T;return T}function A(T){return T.generateMipmaps}function b(T){i.generateMipmap(T)}function w(T){return T.isWebGLCubeRenderTarget?i.TEXTURE_CUBE_MAP:T.isWebGL3DRenderTarget?i.TEXTURE_3D:T.isWebGLArrayRenderTarget||T.isCompressedArrayTexture?i.TEXTURE_2D_ARRAY:i.TEXTURE_2D}function E(T,_,B,it,J,ot=!1){if(T!==null){if(i[T]!==void 0)return i[T];Ut("WebGLRenderer: Attempt to use non-existing WebGL internal format '"+T+"'")}let ft;it&&(ft=t.get("EXT_texture_norm16"),ft||Ut("WebGLRenderer: Unable to use normalized textures without EXT_texture_norm16 extension"));let q=_;if(_===i.RED&&(B===i.FLOAT&&(q=i.R32F),B===i.HALF_FLOAT&&(q=i.R16F),B===i.UNSIGNED_BYTE&&(q=i.R8),B===i.UNSIGNED_SHORT&&ft&&(q=ft.R16_EXT),B===i.SHORT&&ft&&(q=ft.R16_SNORM_EXT)),_===i.RED_INTEGER&&(B===i.UNSIGNED_BYTE&&(q=i.R8UI),B===i.UNSIGNED_SHORT&&(q=i.R16UI),B===i.UNSIGNED_INT&&(q=i.R32UI),B===i.BYTE&&(q=i.R8I),B===i.SHORT&&(q=i.R16I),B===i.INT&&(q=i.R32I)),_===i.RG&&(B===i.FLOAT&&(q=i.RG32F),B===i.HALF_FLOAT&&(q=i.RG16F),B===i.UNSIGNED_BYTE&&(q=i.RG8),B===i.UNSIGNED_SHORT&&ft&&(q=ft.RG16_EXT),B===i.SHORT&&ft&&(q=ft.RG16_SNORM_EXT)),_===i.RG_INTEGER&&(B===i.UNSIGNED_BYTE&&(q=i.RG8UI),B===i.UNSIGNED_SHORT&&(q=i.RG16UI),B===i.UNSIGNED_INT&&(q=i.RG32UI),B===i.BYTE&&(q=i.RG8I),B===i.SHORT&&(q=i.RG16I),B===i.INT&&(q=i.RG32I)),_===i.RGB_INTEGER&&(B===i.UNSIGNED_BYTE&&(q=i.RGB8UI),B===i.UNSIGNED_SHORT&&(q=i.RGB16UI),B===i.UNSIGNED_INT&&(q=i.RGB32UI),B===i.BYTE&&(q=i.RGB8I),B===i.SHORT&&(q=i.RGB16I),B===i.INT&&(q=i.RGB32I)),_===i.RGBA_INTEGER&&(B===i.UNSIGNED_BYTE&&(q=i.RGBA8UI),B===i.UNSIGNED_SHORT&&(q=i.RGBA16UI),B===i.UNSIGNED_INT&&(q=i.RGBA32UI),B===i.BYTE&&(q=i.RGBA8I),B===i.SHORT&&(q=i.RGBA16I),B===i.INT&&(q=i.RGBA32I)),_===i.RGB&&(B===i.UNSIGNED_SHORT&&ft&&(q=ft.RGB16_EXT),B===i.SHORT&&ft&&(q=ft.RGB16_SNORM_EXT),B===i.UNSIGNED_INT_5_9_9_9_REV&&(q=i.RGB9_E5),B===i.UNSIGNED_INT_10F_11F_11F_REV&&(q=i.R11F_G11F_B10F)),_===i.RGBA){const Y=ot?lo:te.getTransfer(J);B===i.FLOAT&&(q=i.RGBA32F),B===i.HALF_FLOAT&&(q=i.RGBA16F),B===i.UNSIGNED_BYTE&&(q=Y===le?i.SRGB8_ALPHA8:i.RGBA8),B===i.UNSIGNED_SHORT&&ft&&(q=ft.RGBA16_EXT),B===i.SHORT&&ft&&(q=ft.RGBA16_SNORM_EXT),B===i.UNSIGNED_SHORT_4_4_4_4&&(q=i.RGBA4),B===i.UNSIGNED_SHORT_5_5_5_1&&(q=i.RGB5_A1)}return(q===i.R16F||q===i.R32F||q===i.RG16F||q===i.RG32F||q===i.RGBA16F||q===i.RGBA32F)&&t.get("EXT_color_buffer_float"),q}function v(T,_){let B;return T?_===null||_===pi||_===ia?B=i.DEPTH24_STENCIL8:_===ti?B=i.DEPTH32F_STENCIL8:_===$a&&(B=i.DEPTH24_STENCIL8,Ut("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):_===null||_===pi||_===ia?B=i.DEPTH_COMPONENT24:_===ti?B=i.DEPTH_COMPONENT32F:_===$a&&(B=i.DEPTH_COMPONENT16),B}function S(T,_){return A(T)===!0||T.isFramebufferTexture&&T.minFilter!==Qe&&T.minFilter!==pn?Math.log2(Math.max(_.width,_.height))+1:T.mipmaps.length>0?T.mipmaps.length:T.isCompressedTexture&&Array.isArray(T.image)?_.mipmaps.length:1}function P(T){const _=new WeakRef(T);n.get(T).__ref=_,g.add(_),x.register(T,_,_)}function R(T){const _=n.get(T).__ref;_!==void 0&&(g.delete(_),x.unregister(_))}function N(T){H(T.target)}function F(T){L(T.target)}function H(T){T.removeEventListener("dispose",N),R(T),X(T),T.isVideoTexture&&d.delete(T),T.isHTMLTexture&&h.delete(T)}function L(T){T.removeEventListener("dispose",F),R(T),et(T)}function $(){for(const T of g){const _=T.deref();_!==void 0&&(_.isRenderTarget===!0?L(_):H(_))}g.clear(),h.clear()}function X(T){const _=n.get(T);if(_.__webglInit===void 0)return;const B=T.source,it=f.get(B);if(it){const J=it[_.__cacheKey];J.usedTimes--,J.usedTimes===0&&z(T),Object.keys(it).length===0&&f.delete(B)}n.remove(T)}function z(T){const _=n.get(T);i.deleteTexture(_.__webglTexture);const B=T.source,it=f.get(B);delete it[_.__cacheKey],r.memory.textures--}function et(T){const _=n.get(T);_.__depthDisposeCallback&&_.__depthDisposeCallback();const B=T.depthTexture;if(B&&B.renderTarget===T&&H(B),T.isWebGLCubeRenderTarget)for(let J=0;J<6;J++){if(Array.isArray(_.__webglFramebuffer[J]))for(let ot=0;ot<_.__webglFramebuffer[J].length;ot++)i.deleteFramebuffer(_.__webglFramebuffer[J][ot]);else i.deleteFramebuffer(_.__webglFramebuffer[J]);_.__webglDepthbuffer&&i.deleteRenderbuffer(_.__webglDepthbuffer[J])}else{if(Array.isArray(_.__webglFramebuffer))for(let J=0;J<_.__webglFramebuffer.length;J++)i.deleteFramebuffer(_.__webglFramebuffer[J]);else i.deleteFramebuffer(_.__webglFramebuffer);if(_.__webglDepthbuffer&&i.deleteRenderbuffer(_.__webglDepthbuffer),_.__webglMultisampledFramebuffer&&i.deleteFramebuffer(_.__webglMultisampledFramebuffer),_.__webglColorRenderbuffer)for(let J=0;J<_.__webglColorRenderbuffer.length;J++)_.__webglColorRenderbuffer[J]&&i.deleteRenderbuffer(_.__webglColorRenderbuffer[J]);_.__webglDepthRenderbuffer&&i.deleteRenderbuffer(_.__webglDepthRenderbuffer)}const it=T.textures;for(let J=0,ot=it.length;J<ot;J++){const ft=n.get(it[J]);ft.__webglTexture&&(i.deleteTexture(ft.__webglTexture),r.memory.textures--),n.remove(it[J])}n.remove(T)}let V=0;function Q(){V=0}function nt(){return V}function Et(T){V=T}function $t(){const T=V;return T>=s.maxTextures&&Ut("WebGLTextures: Trying to use "+(T+1)+" texture units while this GPU supports only "+s.maxTextures),V+=1,T}function K(T){const _=[];return _.push(T.wrapS),_.push(T.wrapT),_.push(T.wrapR||0),_.push(T.magFilter),_.push(T.minFilter),_.push(T.anisotropy),_.push(T.internalFormat),_.push(T.format),_.push(T.type),_.push(T.generateMipmaps),_.push(T.mipmapsAutoUpdate),_.push(T.premultiplyAlpha),_.push(T.flipY),_.push(T.unpackAlignment),_.push(T.colorSpace),_.join()}function xt(T,_){const B=n.get(T);if(T.isVideoTexture&&Fe(T),T.isRenderTargetTexture===!1&&T.isExternalTexture!==!0&&T.version>0&&B.__version!==T.version){const it=T.image;if(it===null)Ut("WebGLRenderer: Texture marked for update but no image data found.");else if(it.complete===!1)Ut("WebGLRenderer: Texture marked for update but image is incomplete");else{Ue(B,T,_);return}}else T.isExternalTexture&&(B.__webglTexture=T.sourceTexture?T.sourceTexture:null);e.bindTexture(i.TEXTURE_2D,B.__webglTexture,i.TEXTURE0+_)}function Mt(T,_){const B=n.get(T);if(T.isRenderTargetTexture===!1&&T.version>0&&B.__version!==T.version){Ue(B,T,_);return}else T.isExternalTexture&&(B.__webglTexture=T.sourceTexture?T.sourceTexture:null);e.bindTexture(i.TEXTURE_2D_ARRAY,B.__webglTexture,i.TEXTURE0+_)}function Lt(T,_){const B=n.get(T);if(T.isRenderTargetTexture===!1&&T.version>0&&B.__version!==T.version){Ue(B,T,_);return}e.bindTexture(i.TEXTURE_3D,B.__webglTexture,i.TEXTURE0+_)}function yt(T,_){const B=n.get(T);if(T.version>0&&B.__version!==T.version){mn(B,T,_);return}e.bindTexture(i.TEXTURE_CUBE_MAP,B.__webglTexture,i.TEXTURE0+_)}const Gt={[io]:i.REPEAT,[Ci]:i.CLAMP_TO_EDGE,[tc]:i.MIRRORED_REPEAT},Pe={[Qe]:i.NEAREST,[Tm]:i.NEAREST_MIPMAP_NEAREST,[er]:i.NEAREST_MIPMAP_LINEAR,[pn]:i.LINEAR,[sl]:i.LINEAR_MIPMAP_NEAREST,[Pi]:i.LINEAR_MIPMAP_LINEAR},Nt={[Lm]:i.NEVER,[Sf]:i.ALWAYS,[Dm]:i.LESS,[_f]:i.LEQUAL,[Im]:i.EQUAL,[Mf]:i.GEQUAL,[Nm]:i.GREATER,[Um]:i.NOTEQUAL};function re(T,_){if(_.type===ti&&t.has("OES_texture_float_linear")===!1&&(_.magFilter===pn||_.magFilter===sl||_.magFilter===er||_.magFilter===Pi||_.minFilter===pn||_.minFilter===sl||_.minFilter===er||_.minFilter===Pi)&&Ut("WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),i.texParameteri(T,i.TEXTURE_WRAP_S,Gt[_.wrapS]),i.texParameteri(T,i.TEXTURE_WRAP_T,Gt[_.wrapT]),(T===i.TEXTURE_3D||T===i.TEXTURE_2D_ARRAY)&&i.texParameteri(T,i.TEXTURE_WRAP_R,Gt[_.wrapR]),i.texParameteri(T,i.TEXTURE_MAG_FILTER,Pe[_.magFilter]),i.texParameteri(T,i.TEXTURE_MIN_FILTER,Pe[_.minFilter]),_.compareFunction&&(i.texParameteri(T,i.TEXTURE_COMPARE_MODE,i.COMPARE_REF_TO_TEXTURE),i.texParameteri(T,i.TEXTURE_COMPARE_FUNC,Nt[_.compareFunction])),t.has("EXT_texture_filter_anisotropic")===!0){if(_.magFilter===Qe||_.minFilter!==er&&_.minFilter!==Pi||_.type===ti&&t.has("OES_texture_float_linear")===!1)return;if(_.anisotropy>1||n.get(_).__currentAnisotropy){const B=t.get("EXT_texture_filter_anisotropic");i.texParameterf(T,B.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(_.anisotropy,s.getMaxAnisotropy())),n.get(_).__currentAnisotropy=_.anisotropy}}}function de(T,_){let B=!1;T.__webglInit===void 0&&(T.__webglInit=!0,_.addEventListener("dispose",N),P(_));const it=_.source;let J=f.get(it);J===void 0&&(J={},f.set(it,J));const ot=K(_);if(ot!==T.__cacheKey){J[ot]===void 0&&(J[ot]={texture:i.createTexture(),usedTimes:0},r.memory.textures++,B=!0),J[ot].usedTimes++;const ft=J[T.__cacheKey];ft!==void 0&&(J[T.__cacheKey].usedTimes--,ft.usedTimes===0&&z(_)),T.__cacheKey=ot,T.__webglTexture=J[ot].texture}return B}function Kt(T,_,B){return Math.floor(Math.floor(T/B)/_)}function Ke(T,_,B,it){const ot=T.updateRanges;if(ot.length===0)e.texSubImage2D(i.TEXTURE_2D,0,0,0,_.width,_.height,B,it,_.data);else{ot.sort((C,Z)=>C.start-Z.start);let ft=0;for(let C=1;C<ot.length;C++){const Z=ot[ft],W=ot[C],dt=Z.start+Z.count,rt=Kt(W.start,_.width,4),lt=Kt(Z.start,_.width,4);W.start<=dt+1&&rt===lt&&Kt(W.start+W.count-1,_.width,4)===rt?Z.count=Math.max(Z.count,W.start+W.count-Z.start):(++ft,ot[ft]=W)}ot.length=ft+1;const q=e.getParameter(i.UNPACK_ROW_LENGTH),Y=e.getParameter(i.UNPACK_SKIP_PIXELS),ct=e.getParameter(i.UNPACK_SKIP_ROWS);e.pixelStorei(i.UNPACK_ROW_LENGTH,_.width);for(let C=0,Z=ot.length;C<Z;C++){const W=ot[C],dt=Math.floor(W.start/4),rt=Math.ceil(W.count/4),lt=dt%_.width,Tt=Math.floor(dt/_.width),Wt=rt,at=1;e.pixelStorei(i.UNPACK_SKIP_PIXELS,lt),e.pixelStorei(i.UNPACK_SKIP_ROWS,Tt),e.texSubImage2D(i.TEXTURE_2D,0,lt,Tt,Wt,at,B,it,_.data)}T.clearUpdateRanges(),e.pixelStorei(i.UNPACK_ROW_LENGTH,q),e.pixelStorei(i.UNPACK_SKIP_PIXELS,Y),e.pixelStorei(i.UNPACK_SKIP_ROWS,ct)}}function Ue(T,_,B){let it=i.TEXTURE_2D;(_.isDataArrayTexture||_.isCompressedArrayTexture)&&(it=i.TEXTURE_2D_ARRAY),_.isData3DTexture&&(it=i.TEXTURE_3D);const J=de(T,_),ot=_.source;e.bindTexture(it,T.__webglTexture,i.TEXTURE0+B);const ft=n.get(ot);if(ot.version!==ft.__version||J===!0){if(e.activeTexture(i.TEXTURE0+B),(typeof ImageBitmap<"u"&&_.image instanceof ImageBitmap)===!1){const at=te.getPrimaries(te.workingColorSpace),Ct=_.colorSpace===Ai?null:te.getPrimaries(_.colorSpace),Vt=_.colorSpace===Ai||at===Ct?i.NONE:i.BROWSER_DEFAULT_WEBGL;e.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,_.flipY),e.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,_.premultiplyAlpha),e.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,Vt)}e.pixelStorei(i.UNPACK_ALIGNMENT,_.unpackAlignment);let Y=y(_.image,!1,s.maxTextureSize);Y=Dt(_,Y);const ct=a.convert(_.format,_.colorSpace),C=a.convert(_.type);let Z=E(_.internalFormat,ct,C,_.normalized,_.colorSpace,_.isVideoTexture);re(it,_);let W;const dt=_.mipmaps,rt=_.isVideoTexture!==!0,lt=ft.__version===void 0||J===!0,Tt=ot.dataReady,Wt=S(_,Y);if(_.isDepthTexture)Z=v(_.format===Yi,_.type),lt&&(rt?e.texStorage2D(i.TEXTURE_2D,1,Z,Y.width,Y.height):e.texImage2D(i.TEXTURE_2D,0,Z,Y.width,Y.height,0,ct,C,null));else if(_.isDataTexture)if(dt.length>0){rt&&lt&&e.texStorage2D(i.TEXTURE_2D,Wt,Z,dt[0].width,dt[0].height);for(let at=0,Ct=dt.length;at<Ct;at++)W=dt[at],rt?Tt&&e.texSubImage2D(i.TEXTURE_2D,at,0,0,W.width,W.height,ct,C,W.data):e.texImage2D(i.TEXTURE_2D,at,Z,W.width,W.height,0,ct,C,W.data);_.generateMipmaps=!1}else rt?(lt&&e.texStorage2D(i.TEXTURE_2D,Wt,Z,Y.width,Y.height),Tt&&Ke(_,Y,ct,C)):e.texImage2D(i.TEXTURE_2D,0,Z,Y.width,Y.height,0,ct,C,Y.data);else if(_.isCompressedTexture)if(_.isCompressedArrayTexture){rt&&lt&&e.texStorage3D(i.TEXTURE_2D_ARRAY,Wt,Z,dt[0].width,dt[0].height,Y.depth);for(let at=0,Ct=dt.length;at<Ct;at++)if(W=dt[at],_.format!==hi)if(ct!==null)if(rt){if(Tt)if(_.layerUpdates.size>0){const Vt=Nh(W.width,W.height,_.format,_.type);for(const gt of _.layerUpdates){const oe=W.data.subarray(gt*Vt/W.data.BYTES_PER_ELEMENT,(gt+1)*Vt/W.data.BYTES_PER_ELEMENT);e.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,at,0,0,gt,W.width,W.height,1,ct,oe)}}else e.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,at,0,0,0,W.width,W.height,Y.depth,ct,W.data)}else e.compressedTexImage3D(i.TEXTURE_2D_ARRAY,at,Z,W.width,W.height,Y.depth,0,W.data,0,0);else Ut("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else rt?Tt&&e.texSubImage3D(i.TEXTURE_2D_ARRAY,at,0,0,0,W.width,W.height,Y.depth,ct,C,W.data):e.texImage3D(i.TEXTURE_2D_ARRAY,at,Z,W.width,W.height,Y.depth,0,ct,C,W.data);_.layerUpdates.size>0&&_.clearLayerUpdates()}else{rt&&lt&&e.texStorage2D(i.TEXTURE_2D,Wt,Z,dt[0].width,dt[0].height);for(let at=0,Ct=dt.length;at<Ct;at++)W=dt[at],_.format!==hi?ct!==null?rt?Tt&&e.compressedTexSubImage2D(i.TEXTURE_2D,at,0,0,W.width,W.height,ct,W.data):e.compressedTexImage2D(i.TEXTURE_2D,at,Z,W.width,W.height,0,W.data):Ut("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):rt?Tt&&e.texSubImage2D(i.TEXTURE_2D,at,0,0,W.width,W.height,ct,C,W.data):e.texImage2D(i.TEXTURE_2D,at,Z,W.width,W.height,0,ct,C,W.data)}else if(_.isDataArrayTexture)if(rt){if(lt&&e.texStorage3D(i.TEXTURE_2D_ARRAY,Wt,Z,Y.width,Y.height,Y.depth),Tt)if(_.layerUpdates.size>0){const at=Nh(Y.width,Y.height,_.format,_.type);for(const Ct of _.layerUpdates){const Vt=Y.data.subarray(Ct*at/Y.data.BYTES_PER_ELEMENT,(Ct+1)*at/Y.data.BYTES_PER_ELEMENT);e.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,Ct,Y.width,Y.height,1,ct,C,Vt)}_.clearLayerUpdates()}else e.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,0,Y.width,Y.height,Y.depth,ct,C,Y.data)}else e.texImage3D(i.TEXTURE_2D_ARRAY,0,Z,Y.width,Y.height,Y.depth,0,ct,C,Y.data);else if(_.isData3DTexture)rt?(lt&&e.texStorage3D(i.TEXTURE_3D,Wt,Z,Y.width,Y.height,Y.depth),Tt&&e.texSubImage3D(i.TEXTURE_3D,0,0,0,0,Y.width,Y.height,Y.depth,ct,C,Y.data)):e.texImage3D(i.TEXTURE_3D,0,Z,Y.width,Y.height,Y.depth,0,ct,C,Y.data);else if(_.isFramebufferTexture){if(lt)if(rt)e.texStorage2D(i.TEXTURE_2D,Wt,Z,Y.width,Y.height);else{let at=Y.width,Ct=Y.height;for(let Vt=0;Vt<Wt;Vt++)e.texImage2D(i.TEXTURE_2D,Vt,Z,at,Ct,0,ct,C,null),at>>=1,Ct>>=1}}else if(_.isHTMLTexture){if("texElementImage2D"in i){const at=i.canvas;if(at.hasAttribute("layoutsubtree")||at.setAttribute("layoutsubtree","true"),Y.parentNode!==at){at.appendChild(Y),h.add(_),at.onpaint=Ct=>{const Vt=Ct.changedElements;for(const gt of h)Vt.includes(gt.image)&&(gt.needsUpdate=!0)},at.requestPaint();return}if(i.texElementImage2D.length===3)i.texElementImage2D(i.TEXTURE_2D,i.RGBA8,Y);else{const Vt=i.RGBA,gt=i.RGBA,oe=i.UNSIGNED_BYTE;i.texElementImage2D(i.TEXTURE_2D,0,Vt,gt,oe,Y)}i.texParameteri(i.TEXTURE_2D,i.TEXTURE_MIN_FILTER,i.LINEAR),i.texParameteri(i.TEXTURE_2D,i.TEXTURE_WRAP_S,i.CLAMP_TO_EDGE),i.texParameteri(i.TEXTURE_2D,i.TEXTURE_WRAP_T,i.CLAMP_TO_EDGE)}}else if(dt.length>0){if(rt&&lt){const at=Ot(dt[0]);e.texStorage2D(i.TEXTURE_2D,Wt,Z,at.width,at.height)}for(let at=0,Ct=dt.length;at<Ct;at++)W=dt[at],rt?Tt&&e.texSubImage2D(i.TEXTURE_2D,at,0,0,ct,C,W):e.texImage2D(i.TEXTURE_2D,at,Z,ct,C,W);_.generateMipmaps=!1}else if(rt){if(lt){const at=Ot(Y);e.texStorage2D(i.TEXTURE_2D,Wt,Z,at.width,at.height)}Tt&&e.texSubImage2D(i.TEXTURE_2D,0,0,0,ct,C,Y)}else e.texImage2D(i.TEXTURE_2D,0,Z,ct,C,Y);A(_)&&_.mipmapsAutoUpdate===!0&&b(it),ft.__version=ot.version,_.onUpdate&&_.onUpdate(_)}T.__version=_.version}function mn(T,_,B){if(_.image.length!==6)return;const it=de(T,_),J=_.source;e.bindTexture(i.TEXTURE_CUBE_MAP,T.__webglTexture,i.TEXTURE0+B);const ot=n.get(J);if(J.version!==ot.__version||it===!0){e.activeTexture(i.TEXTURE0+B);const ft=te.getPrimaries(te.workingColorSpace),q=_.colorSpace===Ai?null:te.getPrimaries(_.colorSpace),Y=_.colorSpace===Ai||ft===q?i.NONE:i.BROWSER_DEFAULT_WEBGL;e.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,_.flipY),e.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,_.premultiplyAlpha),e.pixelStorei(i.UNPACK_ALIGNMENT,_.unpackAlignment),e.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,Y);const ct=_.isCompressedTexture||_.image[0].isCompressedTexture,C=_.image[0]&&_.image[0].isDataTexture,Z=[];for(let gt=0;gt<6;gt++)!ct&&!C?Z[gt]=y(_.image[gt],!0,s.maxCubemapSize):Z[gt]=C?_.image[gt].image:_.image[gt],Z[gt]=Dt(_,Z[gt]);const W=Z[0],dt=a.convert(_.format,_.colorSpace),rt=a.convert(_.type);let lt=E(_.internalFormat,dt,rt,_.normalized,_.colorSpace);const Tt=_.isVideoTexture!==!0,Wt=ot.__version===void 0||it===!0,at=J.dataReady;let Ct=S(_,W);re(i.TEXTURE_CUBE_MAP,_);let Vt;if(_.isDepthTexture){if(lt=v(_.format===Yi,_.type),Wt)if(Tt)e.texStorage2D(i.TEXTURE_CUBE_MAP,1,lt,W.width,W.height);else for(let gt=0;gt<6;gt++)e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+gt,0,lt,W.width,W.height,0,dt,rt,null)}else if(ct){Tt&&Wt&&e.texStorage2D(i.TEXTURE_CUBE_MAP,Ct,lt,W.width,W.height);for(let gt=0;gt<6;gt++){Vt=Z[gt].mipmaps;for(let oe=0;oe<Vt.length;oe++){const $e=Vt[oe];_.format!==hi?dt!==null?Tt?at&&e.compressedTexSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+gt,oe,0,0,$e.width,$e.height,dt,$e.data):e.compressedTexImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+gt,oe,lt,$e.width,$e.height,0,$e.data):Ut("WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):Tt?at&&e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+gt,oe,0,0,$e.width,$e.height,dt,rt,$e.data):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+gt,oe,lt,$e.width,$e.height,0,dt,rt,$e.data)}}}else{if(Vt=_.mipmaps,Tt&&Wt){Vt.length>0&&Ct++;const gt=Ot(Z[0]);e.texStorage2D(i.TEXTURE_CUBE_MAP,Ct,lt,gt.width,gt.height)}for(let gt=0;gt<6;gt++)if(C){Tt?at&&e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+gt,0,0,0,Z[gt].width,Z[gt].height,dt,rt,Z[gt].data):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+gt,0,lt,Z[gt].width,Z[gt].height,0,dt,rt,Z[gt].data);for(let oe=0;oe<Vt.length;oe++){const Fi=Vt[oe].image[gt].image;Tt?at&&e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+gt,oe+1,0,0,Fi.width,Fi.height,dt,rt,Fi.data):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+gt,oe+1,lt,Fi.width,Fi.height,0,dt,rt,Fi.data)}}else{Tt?at&&e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+gt,0,0,0,dt,rt,Z[gt]):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+gt,0,lt,dt,rt,Z[gt]);for(let oe=0;oe<Vt.length;oe++){const $e=Vt[oe];Tt?at&&e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+gt,oe+1,0,0,dt,rt,$e.image[gt]):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+gt,oe+1,lt,dt,rt,$e.image[gt])}}}A(_)&&_.mipmapsAutoUpdate===!0&&b(i.TEXTURE_CUBE_MAP),ot.__version=J.version,_.onUpdate&&_.onUpdate(_)}T.__version=_.version}function Se(T,_,B,it,J,ot){const ft=a.convert(B.format,B.colorSpace),q=a.convert(B.type),Y=E(B.internalFormat,ft,q,B.normalized,B.colorSpace),ct=n.get(_),C=n.get(B);if(C.__renderTarget=_,!ct.__hasExternalTextures){const Z=Math.max(1,_.width>>ot),W=Math.max(1,_.height>>ot);J===i.TEXTURE_3D||J===i.TEXTURE_2D_ARRAY?e.texImage3D(J,ot,Y,Z,W,_.depth,0,ft,q,null):e.texImage2D(J,ot,Y,Z,W,0,ft,q,null)}e.bindFramebuffer(i.FRAMEBUFFER,T),mt(_)?o.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,it,J,C.__webglTexture,0,_e(_)):(J===i.TEXTURE_2D||J>=i.TEXTURE_CUBE_MAP_POSITIVE_X&&J<=i.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&i.framebufferTexture2D(i.FRAMEBUFFER,it,J,C.__webglTexture,ot),e.bindFramebuffer(i.FRAMEBUFFER,null)}function ri(T,_,B){if(i.bindRenderbuffer(i.RENDERBUFFER,T),_.depthBuffer){const it=_.depthTexture,J=it&&it.isDepthTexture?it.type:null,ot=v(_.stencilBuffer,J),ft=_.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT;mt(_)?o.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,_e(_),ot,_.width,_.height):B?i.renderbufferStorageMultisample(i.RENDERBUFFER,_e(_),ot,_.width,_.height):i.renderbufferStorage(i.RENDERBUFFER,ot,_.width,_.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,ft,i.RENDERBUFFER,T)}else{const it=_.textures;for(let J=0;J<it.length;J++){const ot=it[J],ft=a.convert(ot.format,ot.colorSpace),q=a.convert(ot.type),Y=E(ot.internalFormat,ft,q,ot.normalized,ot.colorSpace);mt(_)?o.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,_e(_),Y,_.width,_.height):B?i.renderbufferStorageMultisample(i.RENDERBUFFER,_e(_),Y,_.width,_.height):i.renderbufferStorage(i.RENDERBUFFER,Y,_.width,_.height)}}i.bindRenderbuffer(i.RENDERBUFFER,null)}function ze(T,_,B){const it=_.isWebGLCubeRenderTarget===!0;if(e.bindFramebuffer(i.FRAMEBUFFER,T),!(_.depthTexture&&_.depthTexture.isDepthTexture))throw new Error("THREE.WebGLTextures: renderTarget.depthTexture must be an instance of THREE.DepthTexture.");const J=n.get(_.depthTexture);J.__renderTarget=_;const ot=it?_.depthTexture.image[0]:_.depthTexture.image;(!J.__webglTexture||ot.width!==_.width||ot.height!==_.height)&&(ot.width=_.width,ot.height=_.height,_.depthTexture.needsUpdate=!0),it?yt(_.depthTexture,0):xt(_.depthTexture,0);const ft=J.__webglTexture,q=_e(_),Y=it?i.TEXTURE_CUBE_MAP_POSITIVE_X+B:i.TEXTURE_2D,ct=_.depthTexture.format===Yi?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT;if(_.depthTexture.format===Qi)mt(_)?o.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,ct,Y,ft,0,q):i.framebufferTexture2D(i.FRAMEBUFFER,ct,Y,ft,0);else if(_.depthTexture.format===Yi)mt(_)?o.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,ct,Y,ft,0,q):i.framebufferTexture2D(i.FRAMEBUFFER,ct,Y,ft,0);else throw new Error("THREE.WebGLTextures: Unknown depthTexture format.")}function Pn(T){const _=n.get(T),B=T.isWebGLCubeRenderTarget===!0;if(_.__boundDepthTexture!==T.depthTexture){const it=T.depthTexture;if(_.__depthDisposeCallback&&_.__depthDisposeCallback(),it){const J=()=>{delete _.__boundDepthTexture,delete _.__depthDisposeCallback,it.removeEventListener("dispose",J)};it.addEventListener("dispose",J),_.__depthDisposeCallback=J}_.__boundDepthTexture=it}if(T.depthTexture&&!_.__autoAllocateDepthBuffer)if(B)for(let it=0;it<6;it++)ze(_.__webglFramebuffer[it],T,it);else T.texture.mipmaps.length>0?ze(_.__webglFramebuffer[0],T,0):ze(_.__webglFramebuffer,T,0);else if(B){_.__webglDepthbuffer=[];for(let it=0;it<6;it++)if(e.bindFramebuffer(i.FRAMEBUFFER,_.__webglFramebuffer[it]),_.__webglDepthbuffer[it]===void 0)_.__webglDepthbuffer[it]=i.createRenderbuffer(),ri(_.__webglDepthbuffer[it],T,!1);else{const J=T.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,ot=_.__webglDepthbuffer[it];i.bindRenderbuffer(i.RENDERBUFFER,ot),i.framebufferRenderbuffer(i.FRAMEBUFFER,J,i.RENDERBUFFER,ot)}}else if(T.texture.mipmaps.length>0?e.bindFramebuffer(i.FRAMEBUFFER,_.__webglFramebuffer[0]):e.bindFramebuffer(i.FRAMEBUFFER,_.__webglFramebuffer),_.__webglDepthbuffer===void 0)_.__webglDepthbuffer=i.createRenderbuffer(),ri(_.__webglDepthbuffer,T,!1);else{const J=T.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,ot=_.__webglDepthbuffer;i.bindRenderbuffer(i.RENDERBUFFER,ot),i.framebufferRenderbuffer(i.FRAMEBUFFER,J,i.RENDERBUFFER,ot)}e.bindFramebuffer(i.FRAMEBUFFER,null)}function Ln(T,_,B){const it=n.get(T);_!==void 0&&Se(it.__webglFramebuffer,T,T.texture,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,0),B!==void 0&&Pn(T)}function Dn(T){const _=T.texture,B=n.get(T),it=n.get(_);T.addEventListener("dispose",F),P(T);const J=T.textures,ot=T.isWebGLCubeRenderTarget===!0,ft=J.length>1;if(ft||(it.__webglTexture===void 0&&(it.__webglTexture=i.createTexture()),it.__version=_.version,r.memory.textures++),ot){B.__webglFramebuffer=[];for(let q=0;q<6;q++)if(_.mipmaps.length>0){B.__webglFramebuffer[q]=[];for(let Y=0;Y<_.mipmaps.length;Y++)B.__webglFramebuffer[q][Y]=i.createFramebuffer()}else B.__webglFramebuffer[q]=i.createFramebuffer()}else{if(_.mipmaps.length>0){B.__webglFramebuffer=[];for(let q=0;q<_.mipmaps.length;q++)B.__webglFramebuffer[q]=i.createFramebuffer()}else B.__webglFramebuffer=i.createFramebuffer();if(ft)for(let q=0,Y=J.length;q<Y;q++){const ct=n.get(J[q]);ct.__webglTexture===void 0&&(ct.__webglTexture=i.createTexture(),r.memory.textures++)}if(T.samples>0&&mt(T)===!1){B.__webglMultisampledFramebuffer=i.createFramebuffer(),B.__webglColorRenderbuffer=[],e.bindFramebuffer(i.FRAMEBUFFER,B.__webglMultisampledFramebuffer);for(let q=0;q<J.length;q++){const Y=J[q];B.__webglColorRenderbuffer[q]=i.createRenderbuffer(),i.bindRenderbuffer(i.RENDERBUFFER,B.__webglColorRenderbuffer[q]);const ct=a.convert(Y.format,Y.colorSpace),C=a.convert(Y.type),Z=E(Y.internalFormat,ct,C,Y.normalized,Y.colorSpace,T.isXRRenderTarget===!0),W=_e(T);i.renderbufferStorageMultisample(i.RENDERBUFFER,W,Z,T.width,T.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+q,i.RENDERBUFFER,B.__webglColorRenderbuffer[q])}i.bindRenderbuffer(i.RENDERBUFFER,null),T.depthBuffer&&(B.__webglDepthRenderbuffer=i.createRenderbuffer(),ri(B.__webglDepthRenderbuffer,T,!0)),e.bindFramebuffer(i.FRAMEBUFFER,null)}}if(ot){e.bindTexture(i.TEXTURE_CUBE_MAP,it.__webglTexture),re(i.TEXTURE_CUBE_MAP,_);for(let q=0;q<6;q++)if(_.mipmaps.length>0)for(let Y=0;Y<_.mipmaps.length;Y++)Se(B.__webglFramebuffer[q][Y],T,_,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+q,Y);else Se(B.__webglFramebuffer[q],T,_,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+q,0);A(_)?b(i.TEXTURE_CUBE_MAP):_.mipmaps.length>0&&i.texParameteri(i.TEXTURE_CUBE_MAP,i.TEXTURE_MAX_LEVEL,_.mipmaps.length-1),e.unbindTexture()}else if(ft){for(let q=0,Y=J.length;q<Y;q++){const ct=J[q],C=n.get(ct);let Z=i.TEXTURE_2D;(T.isWebGL3DRenderTarget||T.isWebGLArrayRenderTarget)&&(Z=T.isWebGL3DRenderTarget?i.TEXTURE_3D:i.TEXTURE_2D_ARRAY),e.bindTexture(Z,C.__webglTexture),re(Z,ct),Se(B.__webglFramebuffer,T,ct,i.COLOR_ATTACHMENT0+q,Z,0),A(ct)&&b(Z)}e.unbindTexture()}else{let q=i.TEXTURE_2D;if((T.isWebGL3DRenderTarget||T.isWebGLArrayRenderTarget)&&(q=T.isWebGL3DRenderTarget?i.TEXTURE_3D:i.TEXTURE_2D_ARRAY),e.bindTexture(q,it.__webglTexture),re(q,_),_.mipmaps.length>0)for(let Y=0;Y<_.mipmaps.length;Y++)Se(B.__webglFramebuffer[Y],T,_,i.COLOR_ATTACHMENT0,q,Y);else Se(B.__webglFramebuffer,T,_,i.COLOR_ATTACHMENT0,q,0);A(_)?b(q):_.mipmaps.length>0&&i.texParameteri(q,i.TEXTURE_MAX_LEVEL,_.mipmaps.length-1),e.unbindTexture()}T.depthBuffer&&Pn(T)}function U(T){const _=T.textures;for(let B=0,it=_.length;B<it;B++){const J=_[B];if(A(J)&&J.mipmapsAutoUpdate===!0){const ot=w(T),ft=n.get(J).__webglTexture;e.bindTexture(ot,ft),b(ot),e.unbindTexture()}}}const In=[];function be(T){if(T.samples>0){if(mt(T)===!1){const _=T.textures,B=T.width,it=T.height;let J=i.COLOR_BUFFER_BIT;const ot=T.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,ft=n.get(T),q=_.length>1;if(q)for(let ct=0;ct<_.length;ct++)e.bindFramebuffer(i.FRAMEBUFFER,ft.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+ct,i.RENDERBUFFER,null),e.bindFramebuffer(i.FRAMEBUFFER,ft.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+ct,i.TEXTURE_2D,null,0);e.bindFramebuffer(i.READ_FRAMEBUFFER,ft.__webglMultisampledFramebuffer),T.texture.mipmaps.length>0?e.bindFramebuffer(i.DRAW_FRAMEBUFFER,ft.__webglFramebuffer[0]):e.bindFramebuffer(i.DRAW_FRAMEBUFFER,ft.__webglFramebuffer);for(let ct=0;ct<_.length;ct++){if(T.resolveDepthBuffer&&(T.depthBuffer&&(J|=i.DEPTH_BUFFER_BIT),T.stencilBuffer&&T.resolveStencilBuffer&&(J|=i.STENCIL_BUFFER_BIT)),q){i.framebufferRenderbuffer(i.READ_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.RENDERBUFFER,ft.__webglColorRenderbuffer[ct]);const C=n.get(_[ct]).__webglTexture;i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,C,0)}i.blitFramebuffer(0,0,B,it,0,0,B,it,J,i.NEAREST),l===!0&&(In.length=0,In.push(i.COLOR_ATTACHMENT0+ct),T.depthBuffer&&T.storeMultisampledDepthBuffer===!1&&In.push(ot),i.invalidateFramebuffer(i.READ_FRAMEBUFFER,In))}if(e.bindFramebuffer(i.READ_FRAMEBUFFER,null),e.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),q)for(let ct=0;ct<_.length;ct++){e.bindFramebuffer(i.FRAMEBUFFER,ft.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+ct,i.RENDERBUFFER,ft.__webglColorRenderbuffer[ct]);const C=n.get(_[ct]).__webglTexture;e.bindFramebuffer(i.FRAMEBUFFER,ft.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+ct,i.TEXTURE_2D,C,0)}e.bindFramebuffer(i.DRAW_FRAMEBUFFER,ft.__webglMultisampledFramebuffer)}else if(T.depthBuffer&&T.storeMultisampledDepthBuffer===!1&&l){const _=T.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT;i.invalidateFramebuffer(i.DRAW_FRAMEBUFFER,[_])}}}function _e(T){return Math.min(s.maxSamples,T.samples)}function mt(T){const _=n.get(T);return T.samples>0&&t.has("WEBGL_multisampled_render_to_texture")===!0&&_.__useRenderToTexture!==!1}function Fe(T){const _=r.render.frame;d.get(T)!==_&&(d.set(T,_),T.update())}function Dt(T,_){const B=T.colorSpace,it=T.format,J=T.type;return T.isCompressedTexture===!0||T.isVideoTexture===!0||B!==oo&&B!==Ai&&(te.getTransfer(B)===le?(it!==hi||J!==xn)&&Ut("WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):ie("WebGLTextures: Unsupported texture color space:",B)),_}function Ot(T){return typeof HTMLImageElement<"u"&&T instanceof HTMLImageElement?(c.width=T.naturalWidth||T.width,c.height=T.naturalHeight||T.height):typeof VideoFrame<"u"&&T instanceof VideoFrame?(c.width=T.displayWidth,c.height=T.displayHeight):(c.width=T.width,c.height=T.height),c}this.allocateTextureUnit=$t,this.resetTextureUnits=Q,this.getTextureUnits=nt,this.setTextureUnits=Et,this.setTexture2D=xt,this.setTexture2DArray=Mt,this.setTexture3D=Lt,this.setTextureCube=yt,this.rebindTextures=Ln,this.setupRenderTarget=Dn,this.updateRenderTargetMipmap=U,this.updateMultisampleRenderTarget=be,this.setupDepthRenderbuffer=Pn,this.setupFrameBufferTexture=Se,this.useMultisampledRTT=mt,this.dispose=$}function yb(i,t){function e(n,s=Ai){let a;const r=te.getTransfer(s);if(n===xn)return i.UNSIGNED_BYTE;if(n===sd)return i.UNSIGNED_SHORT_4_4_4_4;if(n===ad)return i.UNSIGNED_SHORT_5_5_5_1;if(n===vf)return i.UNSIGNED_INT_5_9_9_9_REV;if(n===xf)return i.UNSIGNED_INT_10F_11F_11F_REV;if(n===mf)return i.BYTE;if(n===gf)return i.SHORT;if(n===$a)return i.UNSIGNED_SHORT;if(n===id)return i.INT;if(n===pi)return i.UNSIGNED_INT;if(n===ti)return i.FLOAT;if(n===mi)return i.HALF_FLOAT;if(n===yf)return i.ALPHA;if(n===bf)return i.RGB;if(n===hi)return i.RGBA;if(n===Qi)return i.DEPTH_COMPONENT;if(n===Yi)return i.DEPTH_STENCIL;if(n===rd)return i.RED;if(n===od)return i.RED_INTEGER;if(n===ms)return i.RG;if(n===ld)return i.RG_INTEGER;if(n===cd)return i.RGBA_INTEGER;if(n===Xr||n===qr||n===Yr||n===Kr)if(r===le)if(a=t.get("WEBGL_compressed_texture_s3tc_srgb"),a!==null){if(n===Xr)return a.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(n===qr)return a.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(n===Yr)return a.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(n===Kr)return a.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(a=t.get("WEBGL_compressed_texture_s3tc"),a!==null){if(n===Xr)return a.COMPRESSED_RGB_S3TC_DXT1_EXT;if(n===qr)return a.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(n===Yr)return a.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(n===Kr)return a.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(n===ec||n===nc||n===ic||n===sc)if(a=t.get("WEBGL_compressed_texture_pvrtc"),a!==null){if(n===ec)return a.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(n===nc)return a.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(n===ic)return a.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(n===sc)return a.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(n===ac||n===rc||n===oc||n===lc||n===cc||n===so||n===dc)if(a=t.get("WEBGL_compressed_texture_etc"),a!==null){if(n===ac||n===rc)return r===le?a.COMPRESSED_SRGB8_ETC2:a.COMPRESSED_RGB8_ETC2;if(n===oc)return r===le?a.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:a.COMPRESSED_RGBA8_ETC2_EAC;if(n===lc)return a.COMPRESSED_R11_EAC;if(n===cc)return a.COMPRESSED_SIGNED_R11_EAC;if(n===so)return a.COMPRESSED_RG11_EAC;if(n===dc)return a.COMPRESSED_SIGNED_RG11_EAC}else return null;if(n===hc||n===uc||n===fc||n===pc||n===mc||n===gc||n===vc||n===xc||n===yc||n===bc||n===_c||n===Mc||n===Sc||n===wc)if(a=t.get("WEBGL_compressed_texture_astc"),a!==null){if(n===hc)return r===le?a.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:a.COMPRESSED_RGBA_ASTC_4x4_KHR;if(n===uc)return r===le?a.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:a.COMPRESSED_RGBA_ASTC_5x4_KHR;if(n===fc)return r===le?a.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:a.COMPRESSED_RGBA_ASTC_5x5_KHR;if(n===pc)return r===le?a.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:a.COMPRESSED_RGBA_ASTC_6x5_KHR;if(n===mc)return r===le?a.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:a.COMPRESSED_RGBA_ASTC_6x6_KHR;if(n===gc)return r===le?a.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:a.COMPRESSED_RGBA_ASTC_8x5_KHR;if(n===vc)return r===le?a.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:a.COMPRESSED_RGBA_ASTC_8x6_KHR;if(n===xc)return r===le?a.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:a.COMPRESSED_RGBA_ASTC_8x8_KHR;if(n===yc)return r===le?a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:a.COMPRESSED_RGBA_ASTC_10x5_KHR;if(n===bc)return r===le?a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:a.COMPRESSED_RGBA_ASTC_10x6_KHR;if(n===_c)return r===le?a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:a.COMPRESSED_RGBA_ASTC_10x8_KHR;if(n===Mc)return r===le?a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:a.COMPRESSED_RGBA_ASTC_10x10_KHR;if(n===Sc)return r===le?a.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:a.COMPRESSED_RGBA_ASTC_12x10_KHR;if(n===wc)return r===le?a.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:a.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(n===Ec||n===Ac||n===Tc)if(a=t.get("EXT_texture_compression_bptc"),a!==null){if(n===Ec)return r===le?a.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:a.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(n===Ac)return a.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(n===Tc)return a.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(n===Rc||n===Cc||n===ao||n===Pc)if(a=t.get("EXT_texture_compression_rgtc"),a!==null){if(n===Rc)return a.COMPRESSED_RED_RGTC1_EXT;if(n===Cc)return a.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(n===ao)return a.COMPRESSED_RED_GREEN_RGTC2_EXT;if(n===Pc)return a.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return n===ia?i.UNSIGNED_INT_24_8:i[n]!==void 0?i[n]:null}return{convert:e}}const bb=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,_b=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class Mb{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(t,e){if(this.texture===null){const n=new Ff(t.texture);(t.depthNear!==e.depthNear||t.depthFar!==e.depthFar)&&(this.depthNear=t.depthNear,this.depthFar=t.depthFar),this.texture=n}}getMesh(t){if(this.texture!==null&&this.mesh===null){const e=t.cameras[0].viewport,n=new En({vertexShader:bb,fragmentShader:_b,uniforms:{depthColor:{value:this.texture},depthWidth:{value:e.z},depthHeight:{value:e.w}}});this.mesh=new Pt(new ws(20,20),n)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class Sb extends _s{constructor(t,e){super();const n=this;let s=null,a=1,r=null,o="local-floor",l=1,c=null,d=null,h=null,u=null,f=null,g=null;const x=typeof XRWebGLBinding<"u",m=new Mb,p={},y=e.getContextAttributes();let A=null,b=null;const w=[],E=[],v=new It;let S=null,P=null;const R=new gn;R.viewport=new Ae;const N=new gn;N.viewport=new Ae;const F=[R,N],H=new U0;let L=null,$=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(K){let xt=w[K];return xt===void 0&&(xt=new hl,w[K]=xt),xt.getTargetRaySpace()},this.getControllerGrip=function(K){let xt=w[K];return xt===void 0&&(xt=new hl,w[K]=xt),xt.getGripSpace()},this.getHand=function(K){let xt=w[K];return xt===void 0&&(xt=new hl,w[K]=xt),xt.getHandSpace()};function X(K){const xt=E.indexOf(K.inputSource);if(xt===-1)return;const Mt=w[xt];Mt!==void 0&&(Mt.update(K.inputSource,K.frame,c||r),Mt.dispatchEvent({type:K.type,data:K.inputSource}))}function z(){s.removeEventListener("select",X),s.removeEventListener("selectstart",X),s.removeEventListener("selectend",X),s.removeEventListener("squeeze",X),s.removeEventListener("squeezestart",X),s.removeEventListener("squeezeend",X),s.removeEventListener("end",z),s.removeEventListener("inputsourceschange",et);for(let K=0;K<w.length;K++){const xt=E[K];xt!==null&&(E[K]=null,w[K].disconnect(xt))}L=null,$=null,m.reset();for(const K in p)delete p[K];if(t.setRenderTarget(A),f=null,u=null,h=null,s=null,b=null,$t.stop(),n.isPresenting=!1,t.setPixelRatio(S),t.setSize(v.width,v.height,!1),P!==null){const K=P.camera;K.fov=P.fov,K.zoom=P.zoom,K.updateProjectionMatrix(),P=null}n.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(K){a=K,n.isPresenting===!0&&Ut("WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(K){o=K,n.isPresenting===!0&&Ut("WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return c||r},this.setReferenceSpace=function(K){c=K},this.getBaseLayer=function(){return u!==null?u:f},this.getBinding=function(){return h===null&&x&&(h=new XRWebGLBinding(s,e)),h},this.getFrame=function(){return g},this.getSession=function(){return s},this.setSession=async function(K){if(s=K,s!==null){if(A=t.getRenderTarget(),s.addEventListener("select",X),s.addEventListener("selectstart",X),s.addEventListener("selectend",X),s.addEventListener("squeeze",X),s.addEventListener("squeezestart",X),s.addEventListener("squeezeend",X),s.addEventListener("end",z),s.addEventListener("inputsourceschange",et),y.xrCompatible!==!0&&await e.makeXRCompatible(),S=t.getPixelRatio(),t.getSize(v),x&&"createProjectionLayer"in XRWebGLBinding.prototype){let Mt=null,Lt=null,yt=null;y.depth&&(yt=y.stencil?e.DEPTH24_STENCIL8:e.DEPTH_COMPONENT24,Mt=y.stencil?Yi:Qi,Lt=y.stencil?ia:pi);const Gt={colorFormat:e.RGBA8,depthFormat:yt,scaleFactor:a};h=this.getBinding(),u=h.createProjectionLayer(Gt),s.updateRenderState({layers:[u]}),t.setPixelRatio(1),t.setSize(u.textureWidth,u.textureHeight,!1),b=new Bn(u.textureWidth,u.textureHeight,{format:hi,type:xn,depthTexture:new aa(u.textureWidth,u.textureHeight,Lt,void 0,void 0,void 0,void 0,void 0,void 0,Mt),stencilBuffer:y.stencil,colorSpace:t.outputColorSpace,samples:y.antialias?4:0,resolveDepthBuffer:u.ignoreDepthValues===!1,resolveStencilBuffer:u.ignoreDepthValues===!1,storeMultisampledDepthBuffer:u.ignoreDepthValues===!1,storeMultisampledStencilBuffer:u.ignoreDepthValues===!1})}else{const Mt={antialias:y.antialias,alpha:!0,depth:y.depth,stencil:y.stencil,framebufferScaleFactor:a};f=new XRWebGLLayer(s,e,Mt),s.updateRenderState({baseLayer:f}),t.setPixelRatio(1),t.setSize(f.framebufferWidth,f.framebufferHeight,!1),b=new Bn(f.framebufferWidth,f.framebufferHeight,{format:hi,type:xn,colorSpace:t.outputColorSpace,stencilBuffer:y.stencil,resolveDepthBuffer:f.ignoreDepthValues===!1,resolveStencilBuffer:f.ignoreDepthValues===!1,storeMultisampledDepthBuffer:f.ignoreDepthValues===!1,storeMultisampledStencilBuffer:f.ignoreDepthValues===!1})}b.isXRRenderTarget=!0,this.setFoveation(l),c=null,r=await s.requestReferenceSpace(o),$t.setContext(s),$t.start(),n.isPresenting=!0,n.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(s!==null)return s.environmentBlendMode},this.getDepthTexture=function(){return m.getDepthTexture()};function et(K){for(let xt=0;xt<K.removed.length;xt++){const Mt=K.removed[xt],Lt=E.indexOf(Mt);Lt>=0&&(E[Lt]=null,w[Lt].disconnect(Mt))}for(let xt=0;xt<K.added.length;xt++){const Mt=K.added[xt];let Lt=E.indexOf(Mt);if(Lt===-1){for(let Gt=0;Gt<w.length;Gt++)if(Gt>=E.length){E.push(Mt),Lt=Gt;break}else if(E[Gt]===null){E[Gt]=Mt,Lt=Gt;break}if(Lt===-1)break}const yt=w[Lt];yt&&yt.connect(Mt)}}function V(K,xt){xt===null?K.matrixWorld.copy(K.matrix):K.matrixWorld.multiplyMatrices(xt.matrixWorld,K.matrix),K.matrixWorldInverse.copy(K.matrixWorld).invert()}this.updateCamera=function(K){if(s===null)return;let xt=K.near,Mt=K.far;m.texture!==null&&(m.depthNear>0&&(xt=m.depthNear),m.depthFar>0&&(Mt=m.depthFar)),H.near=N.near=R.near=xt,H.far=N.far=R.far=Mt,(L!==H.near||$!==H.far)&&(s.updateRenderState({depthNear:H.near,depthFar:H.far}),L=H.near,$=H.far),H.layers.mask=K.layers.mask|6,R.layers.mask=H.layers.mask&-5,N.layers.mask=H.layers.mask&-3;const Lt=K.parent,yt=H.cameras;V(H,Lt);for(let Gt=0;Gt<yt.length;Gt++)V(yt[Gt],Lt);H.projectionMatrix.copy(R.projectionMatrix),H.projectionMatrixInverse.copy(R.projectionMatrixInverse),P===null&&K.isPerspectiveCamera&&(P={camera:K,fov:K.fov,zoom:K.zoom}),Q(K,H,Lt)};function Q(K,xt,Mt){Mt===null?K.matrix.copy(xt.matrixWorld):(K.matrix.copy(Mt.matrixWorld),K.matrix.invert(),K.matrix.multiply(xt.matrixWorld)),K.matrix.decompose(K.position,K.quaternion,K.scale),K.updateMatrixWorld(!0),K.projectionMatrix.copy(xt.projectionMatrix),K.projectionMatrixInverse.copy(xt.projectionMatrixInverse),K.isPerspectiveCamera&&(K.fov=Ga*2*Math.atan(1/K.projectionMatrix.elements[5]),K.zoom=1)}this.getCamera=function(){return H},this.getFoveation=function(){if(!(u===null&&f===null))return l},this.setFoveation=function(K){l=K,u!==null&&(u.fixedFoveation=K),f!==null&&f.fixedFoveation!==void 0&&(f.fixedFoveation=K)},this.hasDepthSensing=function(){return m.texture!==null},this.getDepthSensingMesh=function(){return m.getMesh(H)},this.getCameraTexture=function(K){return p[K]};let nt=null;function Et(K,xt){if(d=xt.getViewerPose(c||r),g=xt,d!==null){const Mt=d.views;f!==null&&(t.setRenderTargetFramebuffer(b,f.framebuffer),t.setRenderTarget(b));let Lt=!1;Mt.length!==H.cameras.length&&(H.cameras.length=0,Lt=!0);for(let Nt=0;Nt<Mt.length;Nt++){const re=Mt[Nt];let de=null;if(f!==null)de=f.getViewport(re);else{const Ke=h.getViewSubImage(u,re);de=Ke.viewport,Nt===0&&(t.setRenderTargetTextures(b,Ke.colorTexture,Ke.depthStencilTexture),t.setRenderTarget(b))}let Kt=F[Nt];Kt===void 0&&(Kt=new gn,Kt.layers.enable(Nt),Kt.viewport=new Ae,F[Nt]=Kt),Kt.matrix.fromArray(re.transform.matrix),Kt.matrix.decompose(Kt.position,Kt.quaternion,Kt.scale),Kt.projectionMatrix.fromArray(re.projectionMatrix),Kt.projectionMatrixInverse.copy(Kt.projectionMatrix).invert(),Kt.viewport.set(de.x,de.y,de.width,de.height),Nt===0&&(H.matrix.copy(Kt.matrix),H.matrix.decompose(H.position,H.quaternion,H.scale)),Lt===!0&&H.cameras.push(Kt)}const yt=s.enabledFeatures;if(yt&&yt.includes("depth-sensing")&&s.depthUsage=="gpu-optimized"&&x){h=n.getBinding();const Nt=h.getDepthInformation(Mt[0]);Nt&&Nt.isValid&&Nt.texture&&m.init(Nt,s.renderState)}if(yt&&yt.includes("camera-access")&&x){t.state.unbindTexture(),h=n.getBinding();for(let Nt=0;Nt<Mt.length;Nt++){const re=Mt[Nt].camera;if(re){let de=p[re];de||(de=new Ff,p[re]=de);const Kt=h.getCameraImage(re);de.sourceTexture=Kt}}}}for(let Mt=0;Mt<w.length;Mt++){const Lt=E[Mt],yt=w[Mt];Lt!==null&&yt!==void 0&&yt.update(Lt,xt,c||r)}nt&&nt(K,xt),xt.detectedPlanes&&n.dispatchEvent({type:"planesdetected",data:xt}),g=null}const $t=new Vf;$t.setAnimationLoop(Et),this.setAnimationLoop=function(K){nt=K},this.dispose=function(){}}}const wb=new ee,tp=new Bt;tp.set(-1,0,0,0,1,0,0,0,1);function Eb(i,t){function e(m,p){m.matrixAutoUpdate===!0&&m.updateMatrix(),p.value.copy(m.matrix)}function n(m,p){p.color.getRGB(m.fogColor.value,Of(i)),p.isFog?(m.fogNear.value=p.near,m.fogFar.value=p.far):p.isFogExp2&&(m.fogDensity.value=p.density)}function s(m,p,y,A,b){p.isNodeMaterial?p.uniformsNeedUpdate=!1:p.isMeshBasicMaterial?a(m,p):p.isMeshLambertMaterial?(a(m,p),p.envMap&&(m.envMapIntensity.value=p.envMapIntensity)):p.isMeshToonMaterial?(a(m,p),h(m,p)):p.isMeshPhongMaterial?(a(m,p),d(m,p),p.envMap&&(m.envMapIntensity.value=p.envMapIntensity)):p.isMeshStandardMaterial?(a(m,p),u(m,p),p.isMeshPhysicalMaterial&&f(m,p,b)):p.isMeshMatcapMaterial?(a(m,p),g(m,p)):p.isMeshDepthMaterial?a(m,p):p.isMeshDistanceMaterial?(a(m,p),x(m,p)):p.isMeshNormalMaterial?a(m,p):p.isLineBasicMaterial?(r(m,p),p.isLineDashedMaterial&&o(m,p)):p.isPointsMaterial?l(m,p,y,A):p.isSpriteMaterial?c(m,p):p.isShadowMaterial?(m.color.value.copy(p.color),m.opacity.value=p.opacity):p.isShaderMaterial&&(p.uniformsNeedUpdate=!1)}function a(m,p){m.opacity.value=p.opacity,p.color&&m.diffuse.value.copy(p.color),p.emissive&&m.emissive.value.copy(p.emissive).multiplyScalar(p.emissiveIntensity),p.map&&(m.map.value=p.map,e(p.map,m.mapTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,e(p.alphaMap,m.alphaMapTransform)),p.bumpMap&&(m.bumpMap.value=p.bumpMap,e(p.bumpMap,m.bumpMapTransform),m.bumpScale.value=p.bumpScale,p.side===en&&(m.bumpScale.value*=-1)),p.normalMap&&(m.normalMap.value=p.normalMap,e(p.normalMap,m.normalMapTransform),m.normalScale.value.copy(p.normalScale),p.side===en&&m.normalScale.value.negate()),p.displacementMap&&(m.displacementMap.value=p.displacementMap,e(p.displacementMap,m.displacementMapTransform),m.displacementScale.value=p.displacementScale,m.displacementBias.value=p.displacementBias),p.emissiveMap&&(m.emissiveMap.value=p.emissiveMap,e(p.emissiveMap,m.emissiveMapTransform)),p.specularMap&&(m.specularMap.value=p.specularMap,e(p.specularMap,m.specularMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest);const y=t.get(p),A=y.envMap,b=y.envMapRotation;A&&(m.envMap.value=A,m.envMapRotation.value.setFromMatrix4(wb.makeRotationFromEuler(b)).transpose(),A.isCubeTexture&&A.isRenderTargetTexture===!1&&m.envMapRotation.value.premultiply(tp),m.reflectivity.value=p.reflectivity,m.ior.value=p.ior,m.refractionRatio.value=p.refractionRatio),p.lightMap&&(m.lightMap.value=p.lightMap,m.lightMapIntensity.value=p.lightMapIntensity,e(p.lightMap,m.lightMapTransform)),p.aoMap&&(m.aoMap.value=p.aoMap,m.aoMapIntensity.value=p.aoMapIntensity,e(p.aoMap,m.aoMapTransform))}function r(m,p){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,p.map&&(m.map.value=p.map,e(p.map,m.mapTransform))}function o(m,p){m.dashSize.value=p.dashSize,m.totalSize.value=p.dashSize+p.gapSize,m.scale.value=p.scale}function l(m,p,y,A){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,m.size.value=p.size*y,m.scale.value=A*.5,p.map&&(m.map.value=p.map,e(p.map,m.uvTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,e(p.alphaMap,m.alphaMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest)}function c(m,p){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,m.rotation.value=p.rotation,p.map&&(m.map.value=p.map,e(p.map,m.mapTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,e(p.alphaMap,m.alphaMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest)}function d(m,p){m.specular.value.copy(p.specular),m.shininess.value=Math.max(p.shininess,1e-4)}function h(m,p){p.gradientMap&&(m.gradientMap.value=p.gradientMap)}function u(m,p){m.metalness.value=p.metalness,p.metalnessMap&&(m.metalnessMap.value=p.metalnessMap,e(p.metalnessMap,m.metalnessMapTransform)),m.roughness.value=p.roughness,p.roughnessMap&&(m.roughnessMap.value=p.roughnessMap,e(p.roughnessMap,m.roughnessMapTransform)),p.envMap&&(m.envMapIntensity.value=p.envMapIntensity)}function f(m,p,y){m.ior.value=p.ior,p.diffuseRoughness>0&&(m.diffuseRoughness.value=p.diffuseRoughness,p.diffuseRoughnessMap&&(m.diffuseRoughnessMap.value=p.diffuseRoughnessMap,e(p.diffuseRoughnessMap,m.diffuseRoughnessMapTransform))),p.sheen>0&&(m.sheenColor.value.copy(p.sheenColor).multiplyScalar(p.sheen),m.sheenRoughness.value=p.sheenRoughness,p.sheenColorMap&&(m.sheenColorMap.value=p.sheenColorMap,e(p.sheenColorMap,m.sheenColorMapTransform)),p.sheenRoughnessMap&&(m.sheenRoughnessMap.value=p.sheenRoughnessMap,e(p.sheenRoughnessMap,m.sheenRoughnessMapTransform))),p.clearcoat>0&&(m.clearcoat.value=p.clearcoat,m.clearcoatRoughness.value=p.clearcoatRoughness,p.clearcoatMap&&(m.clearcoatMap.value=p.clearcoatMap,e(p.clearcoatMap,m.clearcoatMapTransform)),p.clearcoatRoughnessMap&&(m.clearcoatRoughnessMap.value=p.clearcoatRoughnessMap,e(p.clearcoatRoughnessMap,m.clearcoatRoughnessMapTransform)),p.clearcoatNormalMap&&(m.clearcoatNormalMap.value=p.clearcoatNormalMap,e(p.clearcoatNormalMap,m.clearcoatNormalMapTransform),m.clearcoatNormalScale.value.copy(p.clearcoatNormalScale),p.side===en&&m.clearcoatNormalScale.value.negate())),p.dispersion>0&&(m.dispersion.value=p.dispersion),p.retroreflectivity>0&&(m.retroreflectivity.value=p.retroreflectivity),p.iridescence>0&&(m.iridescence.value=p.iridescence,m.iridescenceIOR.value=p.iridescenceIOR,m.iridescenceThicknessMinimum.value=p.iridescenceThicknessMinimum,m.iridescenceThicknessMaximum.value=p.iridescenceThicknessMaximum,p.iridescenceMap&&(m.iridescenceMap.value=p.iridescenceMap,e(p.iridescenceMap,m.iridescenceMapTransform)),p.iridescenceThicknessMap&&(m.iridescenceThicknessMap.value=p.iridescenceThicknessMap,e(p.iridescenceThicknessMap,m.iridescenceThicknessMapTransform))),p.transmission>0&&(m.transmission.value=p.transmission,m.transmissionSamplerMap.value=y.texture,m.transmissionSamplerSize.value.set(y.width,y.height),p.transmissionMap&&(m.transmissionMap.value=p.transmissionMap,e(p.transmissionMap,m.transmissionMapTransform)),m.thickness.value=p.thickness,p.thicknessMap&&(m.thicknessMap.value=p.thicknessMap,e(p.thicknessMap,m.thicknessMapTransform)),m.attenuationDistance.value=p.attenuationDistance,m.attenuationColor.value.copy(p.attenuationColor)),p.anisotropy>0&&(m.anisotropyVector.value.set(p.anisotropy*Math.cos(p.anisotropyRotation),p.anisotropy*Math.sin(p.anisotropyRotation)),p.anisotropyMap&&(m.anisotropyMap.value=p.anisotropyMap,e(p.anisotropyMap,m.anisotropyMapTransform))),m.specularIntensity.value=p.specularIntensity,m.specularColor.value.copy(p.specularColor),p.specularColorMap&&(m.specularColorMap.value=p.specularColorMap,e(p.specularColorMap,m.specularColorMapTransform)),p.specularIntensityMap&&(m.specularIntensityMap.value=p.specularIntensityMap,e(p.specularIntensityMap,m.specularIntensityMapTransform))}function g(m,p){p.matcap&&(m.matcap.value=p.matcap)}function x(m,p){const y=t.get(p).light;m.referencePosition.value.setFromMatrixPosition(y.matrixWorld),m.nearDistance.value=y.shadow.camera.near,m.farDistance.value=y.shadow.camera.far}return{refreshFogUniforms:n,refreshMaterialUniforms:s}}function Ab(i,t,e,n){let s={},a={};function r(y,A){const b=A.program;n.uniformBlockBinding(y,b,s[y.id])}function o(y,A){let b=s[y.id];b===void 0&&(g(y),b=l(y),s[y.id]=b,y.addEventListener("dispose",m));const w=A.program;n.updateUBOMapping(y,w);const E=t.render.frame;a[y.id]!==E&&(c(y),a[y.id]=E)}function l(y){const A=i.createBuffer(),b=y.__size,w=y.usage;return i.bindBuffer(i.UNIFORM_BUFFER,A),i.bufferData(i.UNIFORM_BUFFER,b,w),i.bindBuffer(i.UNIFORM_BUFFER,null),A}function c(y){const A=s[y.id],b=y.uniforms,w=y.__cache;i.bindBuffer(i.UNIFORM_BUFFER,A);for(let E=0,v=b.length;E<v;E++){const S=b[E];if(Array.isArray(S))for(let P=0,R=S.length;P<R;P++)d(S[P],E,P,w);else d(S,E,0,w)}i.bindBuffer(i.UNIFORM_BUFFER,null)}function d(y,A,b,w){if(u(y,A,b,w)===!0){const E=y.__offset,v=y.value;if(Array.isArray(v)){let S=0;for(let P=0;P<v.length;P++){const R=v[P],N=x(R,!0);h(R,y.__data,S),S+=N.storage/Float32Array.BYTES_PER_ELEMENT}}else h(v,y.__data,0);i.bufferSubData(i.UNIFORM_BUFFER,E,y.__data)}}function h(y,A,b){typeof y=="number"||typeof y=="boolean"?A[b]=y:y.isMatrix3?(A[b]=y.elements[0],A[b+1]=y.elements[1],A[b+2]=y.elements[2],A[b+3]=0,A[b+4]=y.elements[3],A[b+5]=y.elements[4],A[b+6]=y.elements[5],A[b+7]=0,A[b+8]=y.elements[6],A[b+9]=y.elements[7],A[b+10]=y.elements[8],A[b+11]=0):ArrayBuffer.isView(y)?A.set(y.subarray(0,A.length-b),b):y.toArray(A,b)}function u(y,A,b,w){const E=y.value,v=A+"_"+b;if(Array.isArray(E)){w[v]===void 0&&(w[v]=[]);const S=w[v];let P=!1;for(let R=0;R<E.length;R++)f(E[R],S,R)===!0&&(P=!0);return P}return f(E,w,v)}function f(y,A,b){if(A[b]===void 0)return typeof y=="number"||typeof y=="boolean"?A[b]=y:ArrayBuffer.isView(y)?A[b]=y.slice():A[b]=y.clone(),!0;{const w=A[b];if(typeof y=="number"||typeof y=="boolean"){if(w!==y)return A[b]=y,!0}else{if(ArrayBuffer.isView(y))return!0;if(w.equals(y)===!1)return w.copy(y),!0}}return!1}function g(y){const A=y.uniforms;let b=0;const w=16;for(let v=0,S=A.length;v<S;v++){const P=Array.isArray(A[v])?A[v]:[A[v]];for(let R=0,N=P.length;R<N;R++){const F=P[R],H=Array.isArray(F.value)?F.value:[F.value],L=Array.isArray(A[v])||Array.isArray(F.value);let $=b;for(let z=0,et=H.length;z<et;z++){const V=H[z],Q=x(V,L),nt=b%w,Et=nt%Q.boundary,$t=nt+Et;b+=Et,$t!==0&&w-$t<Q.storage&&(b+=w-$t),z===0&&($=b),b+=Q.storage}const X=F.type==="int"?Int32Array:F.type==="uint"?Uint32Array:Float32Array;F.__data=new X((b-$)/Float32Array.BYTES_PER_ELEMENT),F.__offset=$}}const E=b%w;return E>0&&(b+=w-E),y.__size=b,y.__cache={},this}function x(y,A){const b={boundary:0,storage:0};return typeof y=="number"||typeof y=="boolean"?(b.boundary=4,b.storage=4):y.isVector2?(b.boundary=8,b.storage=8):y.isVector3||y.isColor?(b.boundary=16,b.storage=12):y.isVector4?(b.boundary=16,b.storage=16):y.isMatrix3?(b.boundary=16,b.storage=48):y.isMatrix4?(b.boundary=16,b.storage=64):y.isTexture?Ut("WebGLRenderer: Texture samplers can not be part of an uniforms group."):ArrayBuffer.isView(y)?(b.boundary=16,b.storage=y.byteLength):Ut("WebGLRenderer: Unsupported uniform value type.",y),A===!0&&(b.boundary=16,b.storage=Math.ceil(b.storage/16)*16),b}function m(y){const A=y.target;A.removeEventListener("dispose",m),i.deleteBuffer(s[A.id]),delete s[A.id],delete a[A.id]}function p(){for(const y in s)i.deleteBuffer(s[y]);s={},a={}}return{bind:r,update:o,dispose:p}}const Tb=new Uint16Array([12469,15057,12620,14925,13266,14620,13807,14376,14323,13990,14545,13625,14713,13328,14840,12882,14931,12528,14996,12233,15039,11829,15066,11525,15080,11295,15085,10976,15082,10705,15073,10495,13880,14564,13898,14542,13977,14430,14158,14124,14393,13732,14556,13410,14702,12996,14814,12596,14891,12291,14937,11834,14957,11489,14958,11194,14943,10803,14921,10506,14893,10278,14858,9960,14484,14039,14487,14025,14499,13941,14524,13740,14574,13468,14654,13106,14743,12678,14818,12344,14867,11893,14889,11509,14893,11180,14881,10751,14852,10428,14812,10128,14765,9754,14712,9466,14764,13480,14764,13475,14766,13440,14766,13347,14769,13070,14786,12713,14816,12387,14844,11957,14860,11549,14868,11215,14855,10751,14825,10403,14782,10044,14729,9651,14666,9352,14599,9029,14967,12835,14966,12831,14963,12804,14954,12723,14936,12564,14917,12347,14900,11958,14886,11569,14878,11247,14859,10765,14828,10401,14784,10011,14727,9600,14660,9289,14586,8893,14508,8533,15111,12234,15110,12234,15104,12216,15092,12156,15067,12010,15028,11776,14981,11500,14942,11205,14902,10752,14861,10393,14812,9991,14752,9570,14682,9252,14603,8808,14519,8445,14431,8145,15209,11449,15208,11451,15202,11451,15190,11438,15163,11384,15117,11274,15055,10979,14994,10648,14932,10343,14871,9936,14803,9532,14729,9218,14645,8742,14556,8381,14461,8020,14365,7603,15273,10603,15272,10607,15267,10619,15256,10631,15231,10614,15182,10535,15118,10389,15042,10167,14963,9787,14883,9447,14800,9115,14710,8665,14615,8318,14514,7911,14411,7507,14279,7198,15314,9675,15313,9683,15309,9712,15298,9759,15277,9797,15229,9773,15166,9668,15084,9487,14995,9274,14898,8910,14800,8539,14697,8234,14590,7790,14479,7409,14367,7067,14178,6621,15337,8619,15337,8631,15333,8677,15325,8769,15305,8871,15264,8940,15202,8909,15119,8775,15022,8565,14916,8328,14804,8009,14688,7614,14569,7287,14448,6888,14321,6483,14088,6171,15350,7402,15350,7419,15347,7480,15340,7613,15322,7804,15287,7973,15229,8057,15148,8012,15046,7846,14933,7611,14810,7357,14682,7069,14552,6656,14421,6316,14251,5948,14007,5528,15356,5942,15356,5977,15353,6119,15348,6294,15332,6551,15302,6824,15249,7044,15171,7122,15070,7050,14949,6861,14818,6611,14679,6349,14538,6067,14398,5651,14189,5311,13935,4958,15359,4123,15359,4153,15356,4296,15353,4646,15338,5160,15311,5508,15263,5829,15188,6042,15088,6094,14966,6001,14826,5796,14678,5543,14527,5287,14377,4985,14133,4586,13869,4257,15360,1563,15360,1642,15358,2076,15354,2636,15341,3350,15317,4019,15273,4429,15203,4732,15105,4911,14981,4932,14836,4818,14679,4621,14517,4386,14359,4156,14083,3795,13808,3437,15360,122,15360,137,15358,285,15355,636,15344,1274,15322,2177,15281,2765,15215,3223,15120,3451,14995,3569,14846,3567,14681,3466,14511,3305,14344,3121,14037,2800,13753,2467,15360,0,15360,1,15359,21,15355,89,15346,253,15325,479,15287,796,15225,1148,15133,1492,15008,1749,14856,1882,14685,1886,14506,1783,14324,1608,13996,1398,13702,1183]);let li=null;function Rb(){return li===null&&(li=new Df(Tb,16,16,ms,mi),li.name="DFG_LUT",li.minFilter=pn,li.magFilter=pn,li.wrapS=Ci,li.wrapT=Ci,li.generateMipmaps=!1,li.needsUpdate=!0),li}class Cb{constructor(t={}){const{canvas:e=Om(),context:n=null,depth:s=!0,stencil:a=!1,alpha:r=!1,antialias:o=!1,premultipliedAlpha:l=!0,preserveDrawingBuffer:c=!1,powerPreference:d="default",failIfMajorPerformanceCaveat:h=!1,reversedDepthBuffer:u=!1,outputBufferType:f=xn}=t;this.isWebGLRenderer=!0;let g;if(n!==null){if(typeof WebGLRenderingContext<"u"&&n instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");g=n.getContextAttributes().alpha}else g=r;const x=f,m=new Set([cd,ld,od]),p=new Set([xn,pi,$a,ia,sd,ad]),y=new Uint32Array(4),A=new Int32Array(4),b={textures:[],min:[],max:[],resolution:[]};let w=null,E=null;const v=[],S=[];let P=null;this.domElement=e,this.debug={checkShaderErrors:!0,diagnostics:{keywords:!1},onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=Di,this.toneMappingExposure=1,this.transmissionResolutionScale=1;const R=this;let N=!1,F=null,H=null,L=null,$=null;this._outputColorSpace=Je;let X=0,z=0,et=null,V=-1,Q=null;const nt=new Ae,Et=new Ae;let $t=null;const K=new Rt(0);let xt=0,Mt=e.width,Lt=e.height,yt=1,Gt=null,Pe=null;const Nt=new Ae(0,0,Mt,Lt),re=new Ae(0,0,Mt,Lt);let de=!1;const Kt=new Va,Ke=new md;let Ue=!1,mn=!1;const Se=new ee,ri=new D,ze=new Ae,Pn={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let Ln=!1;function Dn(){return et===null?yt:1}let U=n;function In(M,I){return e.getContext(M,I)}let be,_e,mt,Fe,Dt,Ot,T,_,B,it,J,ot,ft,q,Y,ct,C,Z,W,dt,rt,lt,Tt;try{const M={alpha:!0,depth:s,stencil:a,antialias:o,premultipliedAlpha:l,preserveDrawingBuffer:c,powerPreference:d,failIfMajorPerformanceCaveat:h};if("setAttribute"in e&&e.setAttribute("data-engine",`three.js r${td}`),e.addEventListener("webglcontextlost",Ct,!1),e.addEventListener("webglcontextrestored",Vt,!1),e.addEventListener("webglcontextcreationerror",gt,!1),U===null){const I="webgl2";if(U=In(I,M),U===null)throw In(I)?new Error("THREE.WebGLRenderer: Error creating WebGL context with your selected attributes."):new Error("THREE.WebGLRenderer: Error creating WebGL context.")}Wt()}catch(M){throw e.removeEventListener("webglcontextlost",Ct,!1),e.removeEventListener("webglcontextrestored",Vt,!1),e.removeEventListener("webglcontextcreationerror",gt,!1),ie("WebGLRenderer: "+M.message),M}function Wt(){be=new Dx(U),be.init(),rt=new yb(U,be),_e=new _x(U,be,t,rt),mt=new vb(U,be),_e.reversedDepthBuffer&&u&&mt.buffers.depth.setReversed(!0),H=U.createFramebuffer(),L=U.createFramebuffer(),$=U.createFramebuffer(),Fe=new Ux(U),Dt=new ib,Ot=new xb(U,be,mt,Dt,_e,rt,Fe),T=new Lx(R),_=new O0(U),lt=new yx(U,_),B=new Ix(U,_,Fe,lt),it=new Ox(U,B,_,lt,Fe),Z=new Fx(U,_e,Ot),Y=new Mx(Dt),J=new nb(R,T,be,_e,lt,Y),ot=new Eb(R,Dt),ft=new ab,q=new hb(be),C=new xx(R,T,mt,it,g,l),ct=new gb(R,it,_e),Tt=new Ab(U,Fe,_e,mt),W=new bx(U,be,Fe),dt=new Nx(U,be,Fe),Fe.programs=J.programs,R.capabilities=_e,R.extensions=be,R.properties=Dt,R.renderLists=ft,R.shadowMap=ct,R.state=mt,R.info=Fe}x!==xn&&(P=new kx(x,e.width,e.height,o,s,a));const at=new Sb(R,U);this.xr=at,this.getContext=function(){return U},this.getContextAttributes=function(){return U.getContextAttributes()},this.forceContextLoss=function(){const M=be.get("WEBGL_lose_context");M&&M.loseContext()},this.forceContextRestore=function(){const M=be.get("WEBGL_lose_context");M&&M.restoreContext()},this.getPixelRatio=function(){return yt},this.setPixelRatio=function(M){M!==void 0&&(yt=M,this.setSize(Mt,Lt,!1))},this.getSize=function(M){return M.set(Mt,Lt)},this.setSize=function(M,I,G=!0){if(at.isPresenting){Ut("WebGLRenderer: Can't change size while VR device is presenting.");return}Mt=M,Lt=I,e.width=Math.floor(M*yt),e.height=Math.floor(I*yt),G===!0&&(e.style.width=M+"px",e.style.height=I+"px"),P!==null&&P.setSize(e.width,e.height),this.setViewport(0,0,M,I)},this.getDrawingBufferSize=function(M){return M.set(Mt*yt,Lt*yt).floor()},this.setDrawingBufferSize=function(M,I,G){Mt=M,Lt=I,yt=G,e.width=Math.floor(M*G),e.height=Math.floor(I*G),this.setViewport(0,0,M,I)},this.setEffects=function(M){if(x===xn){ie("WebGLRenderer: setEffects() requires outputBufferType set to HalfFloatType or FloatType.");return}if(M){for(let I=0;I<M.length;I++)if(M[I].isOutputPass===!0){Ut("WebGLRenderer: OutputPass is not needed in setEffects(). Tone mapping and color space conversion are applied automatically.");break}}P.setEffects(M||[])},this.getCurrentViewport=function(M){return M.copy(nt)},this.getViewport=function(M){return M.copy(Nt)},this.setViewport=function(M,I,G,O){M.isVector4?Nt.set(M.x,M.y,M.z,M.w):Nt.set(M,I,G,O),mt.viewport(nt.copy(Nt).multiplyScalar(Dn()).round())},this.getScissor=function(M){return M.copy(re)},this.setScissor=function(M,I,G,O){M.isVector4?re.set(M.x,M.y,M.z,M.w):re.set(M,I,G,O),mt.scissor(Et.copy(re).multiplyScalar(Dn()).round())},this.getScissorTest=function(){return de},this.setScissorTest=function(M){mt.setScissorTest(de=M)},this.setOpaqueSort=function(M){Gt=M},this.setTransparentSort=function(M){Pe=M},this.getClearColor=function(M){return M.copy(C.getClearColor())},this.setClearColor=function(){C.setClearColor(...arguments)},this.getClearAlpha=function(){return C.getClearAlpha()},this.setClearAlpha=function(){C.setClearAlpha(...arguments)},this.clear=function(M=!0,I=!0,G=!0){let O=0;if(M){let k=!1;if(et!==null){const pt=et.texture.format;k=m.has(pt)}if(k){const pt=et.texture.type,_t=p.has(pt),ht=C.getClearColor(),bt=C.getClearAlpha(),At=ht.r,Ht=ht.g,Zt=ht.b;_t?(y[0]=At,y[1]=Ht,y[2]=Zt,y[3]=bt,U.clearBufferuiv(U.COLOR,0,y)):(A[0]=At,A[1]=Ht,A[2]=Zt,A[3]=bt,U.clearBufferiv(U.COLOR,0,A))}else O|=U.COLOR_BUFFER_BIT}I&&(O|=U.DEPTH_BUFFER_BIT,this.state.buffers.depth.setMask(!0)),G&&(O|=U.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),O!==0&&U.clear(O)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.setNodesHandler=function(M){M.setRenderer(this),F=M},this.dispose=function(){e.removeEventListener("webglcontextlost",Ct,!1),e.removeEventListener("webglcontextrestored",Vt,!1),e.removeEventListener("webglcontextcreationerror",gt,!1),C.dispose(),ft.dispose(),q.dispose(),Ot.dispose(),Dt.dispose(),T.dispose(),it.dispose(),B.dispose(),lt.dispose(),Tt.dispose(),J.dispose(),at.dispose(),at.removeEventListener("sessionstart",Id),at.removeEventListener("sessionend",Nd),is.stop()};function Ct(M){M.preventDefault(),ho("WebGLRenderer: Context Lost."),N=!0}function Vt(){ho("WebGLRenderer: Context Restored."),N=!1;const M=Fe.autoReset,I=ct.enabled,G=ct.autoUpdate,O=ct.needsUpdate,k=ct.type;Wt(),Fe.autoReset=M,ct.enabled=I,ct.autoUpdate=G,ct.needsUpdate=O,ct.type=k}function gt(M){ie("WebGLRenderer: A WebGL context could not be created. Reason: ",M.statusMessage)}function oe(M){const I=M.target;I.removeEventListener("dispose",oe),$e(I)}function $e(M){Fi(M),Dt.remove(M)}function Fi(M){const I=Dt.get(M).programs;I!==void 0&&(I.forEach(function(G){J.releaseProgram(G)}),M.isShaderMaterial&&J.releaseShaderCache(M))}this.renderBufferDirect=function(M,I,G,O,k,pt){I===null&&(I=Pn);const _t=k.isMesh&&k.matrixWorld.determinantAffine()<0,ht=Ep(M,I,G,O,k);mt.setMaterial(O,_t);let bt=G.index,At=1;if(O.wireframe===!0){if(bt=B.getWireframeAttribute(G),bt===void 0)return;At=2}const Ht=G.drawRange,Zt=G.attributes.position;let St=Ht.start*At,Jt=(Ht.start+Ht.count)*At;pt!==null&&(St=Math.max(St,pt.start*At),Jt=Math.min(Jt,(pt.start+pt.count)*At)),bt!==null?(St=Math.max(St,0),Jt=Math.min(Jt,bt.count)):Zt!=null&&(St=Math.max(St,0),Jt=Math.min(Jt,Zt.count));const Le=Jt-St;if(Le<0||Le===1/0)return;lt.setup(k,O,ht,G,bt);let ue,he=W;if(bt!==null&&(ue=_.get(bt),he=dt,he.setIndex(ue)),k.isMesh)O.wireframe===!0?(mt.setLineWidth(O.wireframeLinewidth*Dn()),he.setMode(U.LINES)):he.setMode(U.TRIANGLES);else if(k.isLine){let nn=O.linewidth;nn===void 0&&(nn=1),mt.setLineWidth(nn*Dn()),k.isLineSegments?he.setMode(U.LINES):k.isLineLoop?he.setMode(U.LINE_LOOP):he.setMode(U.LINE_STRIP)}else k.isPoints?he.setMode(U.POINTS):k.isSprite&&he.setMode(U.TRIANGLES);if(k.isBatchedMesh)if(be.get("WEBGL_multi_draw"))he.renderMultiDraw(k._multiDrawStarts,k._multiDrawCounts,k._multiDrawCount);else{const nn=k._multiDrawStarts,wt=k._multiDrawCounts,dn=k._multiDrawCount,ae=bt?_.get(bt).bytesPerElement:1,ss=Dt.get(O).currentProgram.getUniforms();for(let sn=0;sn<dn;sn++)ss.setValue(U,"_gl_DrawID",sn),he.render(nn[sn]/ae,wt[sn])}else if(k.isInstancedMesh)he.renderInstances(St,Le,k.count);else if(G.isInstancedBufferGeometry){const nn=G._maxInstanceCount!==void 0?G._maxInstanceCount:1/0,wt=Math.min(G.instanceCount,nn);he.renderInstances(St,Le,wt)}else he.render(St,Le)};function Dd(M,I,G,O){F!==null&&M.isNodeMaterial&&F.setObject(O,M),Ue===!0&&Y.setState(M,G,!1),M.transparent===!0&&M.side===Un&&M.forceSinglePass===!1?(M.side=en,M.needsUpdate=!0,da(M,I,O),M.side=ps,M.needsUpdate=!0,da(M,I,O),M.side=Un):da(M,I,O)}this.compile=function(M,I,G=null){G===null&&(G=M),F!==null&&F.renderStart(M,I,G),E=q.get(G),E.init(I),S.push(E),G.traverseVisible(function(k){k.isLight&&k.layers.test(I.layers)&&(E.pushLight(k),k.castShadow&&E.pushShadow(k))}),M!==G&&M.traverseVisible(function(k){k.isLight&&k.layers.test(I.layers)&&(E.pushLight(k),k.castShadow&&E.pushShadow(k))}),E.setupLights(),F!==null&&F.updateLights(E.state.lightsArray),mn=this.localClippingEnabled,Ue=Y.init(this.clippingPlanes,mn),Ue===!0&&Y.setGlobalState(this.clippingPlanes,I),F!==null&&ct.render(E.state.shadowsArray,G,I);const O=new Set;return M.traverse(function(k){if(!(k.isMesh||k.isPoints||k.isLine||k.isSprite))return;const pt=k.material;if(pt)if(Array.isArray(pt))for(let _t=0;_t<pt.length;_t++){const ht=pt[_t];Dd(ht,G,I,k),O.add(ht)}else Dd(pt,G,I,k),O.add(pt)}),E=S.pop(),F!==null&&F.renderEnd(),O},this.compileAsync=function(M,I,G=null){const O=this.compile(M,I,G);return new Promise(k=>{function pt(){if(O.forEach(function(_t){const bt=Dt.get(_t).currentProgram;(bt===void 0||bt.isReady())&&O.delete(_t)}),O.size===0){k(M);return}setTimeout(pt,10)}be.get("KHR_parallel_shader_compile")!==null?pt():setTimeout(pt,10)})};let Qo=null;function Sp(M){Qo&&Qo(M)}function Id(){is.stop()}function Nd(){is.start()}const is=new Vf;is.setAnimationLoop(Sp),typeof self<"u"&&is.setContext(self),this.setAnimationLoop=function(M){Qo=M,at.setAnimationLoop(M),M===null?is.stop():is.start()},at.addEventListener("sessionstart",Id),at.addEventListener("sessionend",Nd),this.render=function(M,I){if(I!==void 0&&I.isCamera!==!0){ie("WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(N===!0)return;F!==null&&F.renderStart(M,I);const G=at.enabled===!0&&at.isPresenting===!0,O=P!==null&&(et===null||G)&&P.begin(R,et);if(M.matrixWorldAutoUpdate===!0&&M.updateMatrixWorld(),I.parent===null&&I.matrixWorldAutoUpdate===!0&&I.updateMatrixWorld(),at.enabled===!0&&at.isPresenting===!0&&(P===null||P.isCompositing()===!1)&&(at.cameraAutoUpdate===!0&&at.updateCamera(I),I=at.getCamera()),M.isScene===!0&&M.onBeforeRender(R,M,I,et),E=q.get(M,S.length),E.init(I),E.state.textureUnits=Ot.getTextureUnits(),S.push(E),Se.multiplyMatrices(I.projectionMatrix,I.matrixWorldInverse),I.isArrayCamera?Ke.setFromArrayCamera(I):Kt.setFromProjectionMatrix(Se,ei,I.reversedDepth),mn=this.localClippingEnabled,Ue=Y.init(this.clippingPlanes,mn),w=ft.get(M,v.length),w.init(),v.push(w),this.info.render.frame++,at.enabled===!0&&at.isPresenting===!0){const _t=R.xr.getDepthSensingMesh();_t!==null&&tl(_t,I,-1/0,R.sortObjects)}tl(M,I,0,R.sortObjects),w.finish(),F!==null&&F.updateLights(E.state.lightsArray),R.sortObjects===!0&&w.sort(Gt,Pe),Ln=at.enabled===!1||at.isPresenting===!1||at.hasDepthSensing()===!1,Ln&&C.addToRenderList(w,M),this.info.autoReset===!0&&this.info.reset(),Ue===!0&&Y.beginShadows();const k=E.state.shadowsArray;if(ct.render(k,M,I),Ue===!0&&Y.endShadows(),(O&&P.hasRenderPass())===!1){const _t=w.opaque,ht=w.transmissive;if(E.setupLights(),I.isArrayCamera){const bt=I.cameras;if(ht.length>0)for(let At=0,Ht=bt.length;At<Ht;At++){const Zt=bt[At];Fd(_t,ht,M,Zt)}Ln&&C.render(M);for(let At=0,Ht=bt.length;At<Ht;At++){const Zt=bt[At];Ud(w,M,Zt,Zt.viewport)}}else ht.length>0&&Fd(_t,ht,M,I),Ln&&C.render(M),Ud(w,M,I)}et!==null&&z===0&&(Ot.updateMultisampleRenderTarget(et),Ot.updateRenderTargetMipmap(et)),O&&P.end(R),M.isScene===!0&&M.onAfterRender(R,M,I),lt.resetDefaultState(),V=-1,Q=null,S.pop(),S.length>0?(E=S[S.length-1],Ot.setTextureUnits(E.state.textureUnits),Ue===!0&&Y.setGlobalState(R.clippingPlanes,E.state.camera)):E=null,v.pop(),v.length>0?w=v[v.length-1]:w=null,F!==null&&F.renderEnd()};function tl(M,I,G,O){if(M.visible===!1)return;if(M.layers.test(I.layers)){if(M.isGroup)G=M.renderOrder;else if(M.isLOD)M.autoUpdate===!0&&M.update(I);else if(M.isLight)E.pushLight(M),M.castShadow&&E.pushShadow(M);else if(M.isSprite){const _t=I.isArrayCamera?Ke:Kt;if(!M.frustumCulled||M.intersectsFrustum(_t)){O&&ze.setFromMatrixPosition(M.matrixWorld).applyMatrix4(Se);const ht=it.update(M),bt=M.material;bt.visible&&w.push(M,ht,bt,G,ze.z,null,I)}}else if(M.isMesh||M.isLine||M.isPoints){const _t=I.isArrayCamera?Ke:Kt;if(!M.frustumCulled||M.intersectsFrustum(_t)){const ht=it.update(M),bt=M.material;if(O&&(M.boundingSphere!==void 0?(M.boundingSphere===null&&M.computeBoundingSphere(),ze.copy(M.boundingSphere.center)):(ht.boundingSphere===null&&ht.computeBoundingSphere(),ze.copy(ht.boundingSphere.center)),ze.applyMatrix4(M.matrixWorld).applyMatrix4(Se)),Array.isArray(bt)){const At=ht.groups;for(let Ht=0,Zt=At.length;Ht<Zt;Ht++){const St=At[Ht],Jt=bt[St.materialIndex];Jt&&Jt.visible&&w.push(M,ht,Jt,G,ze.z,St,I)}}else bt.visible&&w.push(M,ht,bt,G,ze.z,null,I)}}}const pt=M.children;for(let _t=0,ht=pt.length;_t<ht;_t++)tl(pt[_t],I,G,O)}function Ud(M,I,G,O){const{opaque:k,transmissive:pt,transparent:_t}=M;E.setupLightsView(G),Ue===!0&&Y.setGlobalState(R.clippingPlanes,G),O&&mt.viewport(nt.copy(O)),k.length>0&&Qa(k,I,G),pt.length>0&&Qa(pt,I,G),_t.length>0&&Qa(_t,I,G),mt.buffers.depth.setTest(!0),mt.buffers.depth.setMask(!0),mt.buffers.color.setMask(!0),mt.setPolygonOffset(!1)}function Fd(M,I,G,O){if((G.isScene===!0?G.overrideMaterial:null)!==null)return;if(E.state.transmissionRenderTarget[O.id]===void 0){const St=be.has("EXT_color_buffer_half_float")||be.has("EXT_color_buffer_float");E.state.transmissionRenderTarget[O.id]=new Bn(1,1,{generateMipmaps:!0,type:St?mi:xn,minFilter:Pi,samples:Math.max(4,_e.samples),stencilBuffer:a,resolveDepthBuffer:!1,resolveStencilBuffer:!1,storeMultisampledDepthBuffer:!1,storeMultisampledStencilBuffer:!1,colorSpace:te.workingColorSpace})}const pt=E.state.transmissionRenderTarget[O.id],_t=O.viewport||nt;pt.setSize(_t.z*R.transmissionResolutionScale,_t.w*R.transmissionResolutionScale);const ht=R.getRenderTarget(),bt=R.getActiveCubeFace(),At=R.getActiveMipmapLevel();R.setRenderTarget(pt),R.getClearColor(K),xt=R.getClearAlpha(),xt<1&&R.setClearColor(16777215,.5),R.clear(),Ln&&C.render(G);const Ht=R.toneMapping;R.toneMapping=Di;const Zt=O.viewport;if(O.viewport!==void 0&&(O.viewport=void 0),E.setupLightsView(O),Ue===!0&&Y.setGlobalState(R.clippingPlanes,O),Qa(M,G,O),Ot.updateMultisampleRenderTarget(pt),Ot.updateRenderTargetMipmap(pt),be.has("WEBGL_multisampled_render_to_texture")===!1){let St=!1;for(let Jt=0,Le=I.length;Jt<Le;Jt++){const ue=I[Jt],{object:he,geometry:nn,material:wt,group:dn}=ue;if(wt.side===Un&&he.layers.test(O.layers)){const ae=wt.side;wt.side=en,wt.needsUpdate=!0,Od(he,G,O,nn,wt,dn),wt.side=ae,wt.needsUpdate=!0,St=!0}}St===!0&&(Ot.updateMultisampleRenderTarget(pt),Ot.updateRenderTargetMipmap(pt))}R.setRenderTarget(ht,bt,At),R.setClearColor(K,xt),Zt!==void 0&&(O.viewport=Zt),R.toneMapping=Ht}function Qa(M,I,G){const O=I.isScene===!0?I.overrideMaterial:null;for(let k=0,pt=M.length;k<pt;k++){const _t=M[k],{object:ht,geometry:bt,group:At}=_t;let Ht=_t.material;Ht.allowOverride===!0&&O!==null&&(Ht=O),ht.layers.test(G.layers)&&Od(ht,I,G,bt,Ht,At)}}function Od(M,I,G,O,k,pt){F!==null&&k.isNodeMaterial&&F.setObject(M,k),M.onBeforeRender(R,I,G,O,k,pt),M.modelViewMatrix.multiplyMatrices(G.matrixWorldInverse,M.matrixWorld),M.normalMatrix.getNormalMatrix(M.modelViewMatrix),k.onBeforeRender(R,I,G,O,M,pt),k.transparent===!0&&k.side===Un&&k.forceSinglePass===!1?(k.side=en,k.needsUpdate=!0,R.renderBufferDirect(G,I,O,k,M,pt),k.side=ps,k.needsUpdate=!0,R.renderBufferDirect(G,I,O,k,M,pt),k.side=Un):R.renderBufferDirect(G,I,O,k,M,pt),M.onAfterRender(R,I,G,O,k,pt)}function Bd(M){let I=0;for(const G of M)G.texture!==null&&I++;return I}function da(M,I,G){I.isScene!==!0&&(I=Pn);const O=Dt.get(M),k=E.state.lights,pt=E.state.shadowsArray,_t=k.state.version,ht=J.getParameters(M,k.state,pt,I,G,E.state.lightProbeGridArray),bt=J.getProgramCacheKey(ht);let At=O.programs;O.environment=M.isMeshStandardMaterial||M.isMeshLambertMaterial||M.isMeshPhongMaterial?I.environment:null,O.fog=I.fog;const Ht=M.isMeshStandardMaterial||M.isMeshLambertMaterial&&!M.envMap||M.isMeshPhongMaterial&&!M.envMap;O.envMap=T.get(M.envMap||O.environment,Ht),O.envMapRotation=O.environment!==null&&M.envMap===null?I.environmentRotation:M.envMapRotation,At===void 0&&(M.addEventListener("dispose",oe),At=new Map,O.programs=At,O.programVariants=new Map);let Zt=At.get(bt);if(Zt!==void 0){if(O.currentProgram===Zt&&O.lightsStateVersion===_t)return zd(M,ht),Zt}else ht.uniforms=J.getUniforms(M),F!==null&&M.isNodeMaterial&&F.build(M,G,ht),M.onBeforeCompile(ht,R),Zt=J.acquireProgram(ht,bt),At.set(bt,Zt),O.uniforms=ht.uniforms;const St=O.uniforms;return(!M.isShaderMaterial&&!M.isRawShaderMaterial||M.clipping===!0)&&(St.clippingPlanes=Y.uniform),zd(M,ht),O.needsLights=Tp(M),O.lightsStateVersion=_t,O.needsLights&&(St.ambientLightColor.value=k.state.ambient,St.lightProbe.value=k.state.probe,St.sunLights.value=k.state.sun,St.sunLightShadows.value=k.state.sunShadow,St.directionalLights.value=k.state.directional,St.directionalLightShadows.value=k.state.directionalShadow,St.spotLights.value=k.state.spot,St.spotLightShadows.value=k.state.spotShadow,St.rectAreaLights.value=k.state.rectArea,St.ltc_1.value=k.state.rectAreaLTC1,St.ltc_2.value=k.state.rectAreaLTC2,St.pointLights.value=k.state.point,St.pointLightShadows.value=k.state.pointShadow,St.hemisphereLights.value=k.state.hemi,St.sunShadowMatrix.value=k.state.sunShadowMatrix,St.sunShadowCascade.value=k.state.sunShadowCascade,St.directionalShadowMatrix.value=k.state.directionalShadowMatrix,St.spotLightMatrix.value=k.state.spotLightMatrix,St.spotLightMap.value=k.state.spotLightMap,St.pointShadowMatrix.value=k.state.pointShadowMatrix),O.numLightProbeGrids=Bd(E.state.lightProbeGridArray),O.currentProgram=Zt,O.uniformsList=null,Zt}function wp(M,I,G,O,k){const pt=Dt.get(M),_t=pt.currentProgram.id+","+O+","+k;let ht=pt.programVariants.get(_t);return ht===void 0?(ht=da(M,I,G),pt.programVariants.set(_t,ht)):(pt.currentProgram=ht,pt.uniformsList=null,pt.outputColorSpace=O,pt.toneMapping=k),ht}function kd(M){if(M.uniformsList===null){const I=M.currentProgram.getUniforms();M.uniformsList=Jr.seqWithValue(I.seq,M.uniforms)}return M.uniformsList}function zd(M,I){const G=Dt.get(M);G.outputColorSpace=I.outputColorSpace,G.batching=I.batching,G.batchingColor=I.batchingColor,G.instancing=I.instancing,G.instancingColor=I.instancingColor,G.instancingMorph=I.instancingMorph,G.skinning=I.skinning,G.morphTargets=I.morphTargets,G.morphNormals=I.morphNormals,G.morphColors=I.morphColors,G.morphTargetsCount=I.morphTargetsCount,G.numClippingPlanes=I.numClippingPlanes,G.numIntersection=I.numClipIntersection,G.vertexAlphas=I.vertexAlphas,G.vertexTangents=I.vertexTangents,G.toneMapping=I.toneMapping}function Ep(M,I,G,O,k){I.isScene!==!0&&(I=Pn),Ot.resetTextureUnits();const pt=I.fog,_t=O.isMeshStandardMaterial||O.isMeshLambertMaterial||O.isMeshPhongMaterial?I.environment:null,ht=et===null?R.outputColorSpace:et.isXRRenderTarget===!0?et.texture.colorSpace:te.workingColorSpace,bt=O.isMeshStandardMaterial||O.isMeshLambertMaterial&&!O.envMap||O.isMeshPhongMaterial&&!O.envMap,At=T.get(O.envMap||_t,bt),Ht=O.vertexColors===!0&&!!G.attributes.color&&G.attributes.color.itemSize===4,Zt=!!G.attributes.tangent&&(!!O.normalMap||O.anisotropy>0),St=!!G.morphAttributes.position,Jt=!!G.morphAttributes.normal,Le=!!G.morphAttributes.color;let ue=Di;O.toneMapped&&(et===null||et.isXRRenderTarget===!0)&&(ue=R.toneMapping);const he=G.morphAttributes.position||G.morphAttributes.normal||G.morphAttributes.color,nn=he!==void 0?he.length:0,wt=Dt.get(O),dn=E.state.lights;if(Ue===!0&&(mn===!0||M!==Q)){const we=M===Q&&O.id===V;Y.setState(O,M,we)}let ae=!1,ss=!1;O.version===wt.__version?wt.needsLights&&wt.lightsStateVersion!==dn.state.version||k.isBatchedMesh&&wt.batching===!1||!k.isBatchedMesh&&wt.batching===!0||k.isBatchedMesh&&wt.batchingColor===!0&&k._colorsTexture===null||k.isBatchedMesh&&wt.batchingColor===!1&&k._colorsTexture!==null||k.isInstancedMesh&&wt.instancing===!1||!k.isInstancedMesh&&wt.instancing===!0||k.isSkinnedMesh&&wt.skinning===!1||!k.isSkinnedMesh&&wt.skinning===!0||k.isInstancedMesh&&wt.instancingColor===!0&&k.instanceColor===null||k.isInstancedMesh&&wt.instancingColor===!1&&k.instanceColor!==null||k.isInstancedMesh&&wt.instancingMorph===!0&&k.morphTexture===null||k.isInstancedMesh&&wt.instancingMorph===!1&&k.morphTexture!==null||wt.envMap!==At||O.fog===!0&&wt.fog!==pt||wt.numClippingPlanes!==void 0&&(wt.numClippingPlanes!==Y.numPlanes||wt.numIntersection!==Y.numIntersection)||wt.vertexAlphas!==Ht||wt.vertexTangents!==Zt||wt.morphTargets!==St||wt.morphNormals!==Jt||wt.morphColors!==Le||wt.morphTargetsCount!==nn||wt.numLightProbeGrids!==Bd(E.state.lightProbeGridArray)?ae=!0:(wt.outputColorSpace!==ht||wt.toneMapping!==ue)&&(ss=!0):(ae=!0,wt.__version=O.version);let sn=wt.currentProgram;(ae===!0||ss===!0)&&(sn=ss===!0?wp(O,I,k,ht,ue):da(O,I,k),F&&O.isNodeMaterial&&F.onUpdateProgram(O,sn,wt));let tr=!1,Oi=!1,as=!1;const ne=sn.getUniforms(),Ze=wt.uniforms;if(mt.useProgram(sn.program)&&(tr=!0,Oi=!0,as=!0),O.id!==V&&(V=O.id,Oi=!0),tr||Q!==M){mt.buffers.depth.getReversed()&&M.reversedDepth!==!0&&(M._reversedDepth=!0,M.updateProjectionMatrix()),ne.setValue(U,"projectionMatrix",M.projectionMatrix),ne.setValue(U,"viewMatrix",M.matrixWorldInverse);const He=ne.map.cameraPosition;He!==void 0&&He.setValue(U,ri.setFromMatrixPosition(M.matrixWorld)),_e.logarithmicDepthBuffer&&ne.setValue(U,"logDepthBufFC",2/(Math.log(M.far+1)/Math.LN2)),(O.isMeshPhongMaterial||O.isMeshToonMaterial||O.isMeshLambertMaterial||O.isMeshBasicMaterial||O.isMeshStandardMaterial||O.isShaderMaterial)&&ne.setValue(U,"isOrthographic",M.isOrthographicCamera===!0),Q!==M&&(Q=M,Oi=!0,as=!0)}if(wt.needsLights&&(dn.state.sunShadowMap.length>0&&ne.setValue(U,"sunShadowMap",dn.state.sunShadowMap,Ot),dn.state.directionalShadowMap.length>0&&ne.setValue(U,"directionalShadowMap",dn.state.directionalShadowMap,Ot),dn.state.spotShadowMap.length>0&&ne.setValue(U,"spotShadowMap",dn.state.spotShadowMap,Ot),dn.state.pointShadowMap.length>0&&ne.setValue(U,"pointShadowMap",dn.state.pointShadowMap,Ot)),k.isSkinnedMesh){ne.setOptional(U,k,"bindMatrix"),ne.setOptional(U,k,"bindMatrixInverse");const we=k.skeleton;we&&(we.boneTexture===null&&we.computeBoneTexture(),ne.setValue(U,"boneTexture",we.boneTexture,Ot))}k.isBatchedMesh&&(ne.setOptional(U,k,"batchingTexture"),ne.setValue(U,"batchingTexture",k._matricesTexture,Ot),ne.setOptional(U,k,"batchingIdTexture"),ne.setValue(U,"batchingIdTexture",k._indirectTexture,Ot),ne.setOptional(U,k,"batchingColorTexture"),k._colorsTexture!==null&&ne.setValue(U,"batchingColorTexture",k._colorsTexture,Ot));const Gn=G.morphAttributes;if((Gn.position!==void 0||Gn.normal!==void 0||Gn.color!==void 0)&&Z.update(k,G,sn),(Oi||wt.receiveShadow!==k.receiveShadow)&&(wt.receiveShadow=k.receiveShadow,ne.setValue(U,"receiveShadow",k.receiveShadow)),(O.isMeshStandardMaterial||O.isMeshLambertMaterial||O.isMeshPhongMaterial)&&O.envMap===null&&I.environment!==null&&(Ze.envMapIntensity.value=I.environmentIntensity),Ze.dfgLUT!==void 0&&(Ze.dfgLUT.value=Rb()),Oi){if(ne.setValue(U,"toneMappingExposure",R.toneMappingExposure),wt.needsLights&&Ap(Ze,as),pt&&O.fog===!0&&ot.refreshFogUniforms(Ze,pt),ot.refreshMaterialUniforms(Ze,O,yt,Lt,E.state.transmissionRenderTarget[M.id]),wt.needsLights&&wt.numLightProbeGrids>0){const we=b;let He=0;for(const gi of E.state.lightProbeGridArray)gi.texture!==null&&(we.textures[He]=gi.texture,we.min[He]=gi.boundingBox.min,we.max[He]=gi.boundingBox.max,we.resolution[He]=gi.resolution,He++);for(const gi in we)we[gi].length=He;Ze.probesSH.value=we.textures,Ze.probesMin.value=we.min,Ze.probesMax.value=we.max,Ze.probesResolution.value=we.resolution}Jr.upload(U,kd(wt),Ze,Ot)}if(O.isShaderMaterial&&O.uniformsNeedUpdate===!0&&(Jr.upload(U,kd(wt),Ze,Ot),O.uniformsNeedUpdate=!1),O.isSpriteMaterial&&ne.setValue(U,"center",k.center),ne.setValue(U,"modelViewMatrix",k.modelViewMatrix),ne.setValue(U,"normalMatrix",k.normalMatrix),ne.setValue(U,"modelMatrix",k.matrixWorld),O.uniformsGroups!==void 0){const we=O.uniformsGroups;for(let He=0,gi=we.length;He<gi;He++){const Hd=we[He];Tt.update(Hd,sn),Tt.bind(Hd,sn)}}return sn}function Ap(M,I){M.ambientLightColor.needsUpdate=I,M.lightProbe.needsUpdate=I,M.sunLights.needsUpdate=I,M.sunLightShadows.needsUpdate=I,M.directionalLights.needsUpdate=I,M.directionalLightShadows.needsUpdate=I,M.pointLights.needsUpdate=I,M.pointLightShadows.needsUpdate=I,M.spotLights.needsUpdate=I,M.spotLightShadows.needsUpdate=I,M.rectAreaLights.needsUpdate=I,M.hemisphereLights.needsUpdate=I}function Tp(M){return M.isMeshLambertMaterial||M.isMeshToonMaterial||M.isMeshPhongMaterial||M.isMeshStandardMaterial||M.isShadowMaterial||M.isShaderMaterial&&M.lights===!0}this.getActiveCubeFace=function(){return X},this.getActiveMipmapLevel=function(){return z},this.getRenderTarget=function(){return et},this.setRenderTargetTextures=function(M,I,G){const O=Dt.get(M);O.__autoAllocateDepthBuffer=M.resolveDepthBuffer===!1,O.__autoAllocateDepthBuffer===!1&&(O.__useRenderToTexture=!1),Dt.get(M.texture).__webglTexture=I,Dt.get(M.depthTexture).__webglTexture=O.__autoAllocateDepthBuffer?void 0:G,O.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(M,I){const G=Dt.get(M);G.__webglFramebuffer=I,G.__useDefaultFramebuffer=I===void 0},this.setRenderTarget=function(M,I=0,G=0){et=M,X=I,z=G;let O=null,k=!1,pt=!1;if(M){const ht=Dt.get(M);if(ht.__useDefaultFramebuffer!==void 0){mt.bindFramebuffer(U.FRAMEBUFFER,ht.__webglFramebuffer),nt.copy(M.viewport),Et.copy(M.scissor),$t=M.scissorTest,mt.viewport(nt),mt.scissor(Et),mt.setScissorTest($t),V=-1;return}else if(ht.__webglFramebuffer===void 0)Ot.setupRenderTarget(M);else if(ht.__hasExternalTextures)Ot.rebindTextures(M,Dt.get(M.texture).__webglTexture,Dt.get(M.depthTexture).__webglTexture);else if(M.depthBuffer){const Ht=M.depthTexture;if(ht.__boundDepthTexture!==Ht){if(Ht!==null&&Dt.has(Ht)&&(M.width!==Ht.image.width||M.height!==Ht.image.height))throw new Error("THREE.WebGLRenderer: Attached DepthTexture is initialized to the incorrect size.");Ot.setupDepthRenderbuffer(M)}}const bt=M.texture;(bt.isData3DTexture||bt.isDataArrayTexture||bt.isCompressedArrayTexture)&&(pt=!0);const At=Dt.get(M).__webglFramebuffer;M.isWebGLCubeRenderTarget?(Array.isArray(At[I])?O=At[I][G]:O=At[I],k=!0):M.samples>0&&Ot.useMultisampledRTT(M)===!1?O=Dt.get(M).__webglMultisampledFramebuffer:Array.isArray(At)?O=At[G]:O=At,nt.copy(M.viewport),Et.copy(M.scissor),$t=M.scissorTest}else nt.copy(Nt).multiplyScalar(yt).floor(),Et.copy(re).multiplyScalar(yt).floor(),$t=de;if(G!==0&&(O=H),mt.bindFramebuffer(U.FRAMEBUFFER,O)&&mt.drawBuffers(M,O),mt.viewport(nt),mt.scissor(Et),mt.setScissorTest($t),k){const ht=Dt.get(M.texture);U.framebufferTexture2D(U.FRAMEBUFFER,U.COLOR_ATTACHMENT0,U.TEXTURE_CUBE_MAP_POSITIVE_X+I,ht.__webglTexture,G)}else if(pt){const ht=I;for(let bt=0;bt<M.textures.length;bt++){const At=Dt.get(M.textures[bt]);U.framebufferTextureLayer(U.FRAMEBUFFER,U.COLOR_ATTACHMENT0+bt,At.__webglTexture,G,ht)}}else if(M!==null&&G!==0){const ht=Dt.get(M.texture);U.framebufferTexture2D(U.FRAMEBUFFER,U.COLOR_ATTACHMENT0,U.TEXTURE_2D,ht.__webglTexture,G)}V=-1};function $d(M){const I=Dt.get(M);return(I.__readFormat!==M.format||I.__readType!==M.type)&&(I.__readFormat=M.format,I.__readType=M.type,I.__formatReadable=_e.textureFormatReadable(M.format),I.__typeReadable=_e.textureTypeReadable(M.type)),I}this.readRenderTargetPixels=function(M,I,G,O,k,pt,_t,ht=0){if(!(M&&M.isWebGLRenderTarget)){ie("WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let bt=Dt.get(M).__webglFramebuffer;if(M.isWebGLCubeRenderTarget&&_t!==void 0&&(bt=bt[_t],Array.isArray(bt)&&(bt=bt[0])),bt){mt.bindFramebuffer(U.FRAMEBUFFER,bt);try{const At=M.textures[ht],Ht=At.format,Zt=At.type;M.textures.length>1&&U.readBuffer(U.COLOR_ATTACHMENT0+ht);const St=$d(At);if(St.__formatReadable===!1){ie("WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(St.__typeReadable===!1){ie("WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}I>=0&&I<=M.width-O&&G>=0&&G<=M.height-k&&U.readPixels(I,G,O,k,rt.convert(Ht),rt.convert(Zt),pt)}finally{const At=et!==null?Dt.get(et).__webglFramebuffer:null;mt.bindFramebuffer(U.FRAMEBUFFER,At)}}},this.readRenderTargetPixelsAsync=async function(M,I,G,O,k,pt,_t,ht=0){if(!(M&&M.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let bt=Dt.get(M).__webglFramebuffer;if(M.isWebGLCubeRenderTarget&&_t!==void 0&&(bt=bt[_t],Array.isArray(bt)&&(bt=bt[0])),bt)if(I>=0&&I<=M.width-O&&G>=0&&G<=M.height-k){mt.bindFramebuffer(U.FRAMEBUFFER,bt);const At=M.textures[ht],Ht=At.format,Zt=At.type;M.textures.length>1&&U.readBuffer(U.COLOR_ATTACHMENT0+ht);const St=$d(At);if(St.__formatReadable===!1)throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(St.__typeReadable===!1)throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");const Jt=U.createBuffer();U.bindBuffer(U.PIXEL_PACK_BUFFER,Jt),U.bufferData(U.PIXEL_PACK_BUFFER,pt.byteLength,U.STREAM_READ),U.readPixels(I,G,O,k,rt.convert(Ht),rt.convert(Zt),0),U.bindBuffer(U.PIXEL_PACK_BUFFER,null);const Le=et!==null?Dt.get(et).__webglFramebuffer:null;mt.bindFramebuffer(U.FRAMEBUFFER,Le);const ue=U.fenceSync(U.SYNC_GPU_COMMANDS_COMPLETE,0);return U.flush(),await Bm(U,ue,4),U.bindBuffer(U.PIXEL_PACK_BUFFER,Jt),U.getBufferSubData(U.PIXEL_PACK_BUFFER,0,pt),U.bindBuffer(U.PIXEL_PACK_BUFFER,null),U.deleteBuffer(Jt),U.deleteSync(ue),pt}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")},this.copyFramebufferToTexture=function(M,I=null,G=0){const O=Math.pow(2,-G),k=Math.floor(M.image.width*O),pt=Math.floor(M.image.height*O),_t=I!==null?I.x:0,ht=I!==null?I.y:0;Ot.setTexture2D(M,0),U.copyTexSubImage2D(U.TEXTURE_2D,G,0,0,_t,ht,k,pt),mt.unbindTexture()},this.copyTextureToTexture=function(M,I,G=null,O=null,k=0,pt=0){let _t,ht,bt,At,Ht,Zt,St,Jt,Le;const ue=M.isCompressedTexture?M.mipmaps[pt]:M.image;if(G!==null)_t=G.max.x-G.min.x,ht=G.max.y-G.min.y,bt=G.isBox3?G.max.z-G.min.z:1,At=G.min.x,Ht=G.min.y,Zt=G.isBox3?G.min.z:0;else{const ne=Math.pow(2,-k);_t=Math.floor(ue.width*ne),ht=Math.floor(ue.height*ne),M.isDataArrayTexture?bt=ue.depth:M.isData3DTexture?bt=Math.floor(ue.depth*ne):bt=1,At=0,Ht=0,Zt=0}O!==null?(St=O.x,Jt=O.y,Le=O.z):(St=0,Jt=0,Le=0);const he=rt.convert(I.format),nn=rt.convert(I.type);let wt;I.isData3DTexture?(Ot.setTexture3D(I,0),wt=U.TEXTURE_3D):I.isDataArrayTexture||I.isCompressedArrayTexture?(Ot.setTexture2DArray(I,0),wt=U.TEXTURE_2D_ARRAY):(Ot.setTexture2D(I,0),wt=U.TEXTURE_2D),mt.activeTexture(U.TEXTURE0),mt.pixelStorei(U.UNPACK_FLIP_Y_WEBGL,I.flipY),mt.pixelStorei(U.UNPACK_PREMULTIPLY_ALPHA_WEBGL,I.premultiplyAlpha),mt.pixelStorei(U.UNPACK_ALIGNMENT,I.unpackAlignment);const dn=mt.getParameter(U.UNPACK_ROW_LENGTH),ae=mt.getParameter(U.UNPACK_IMAGE_HEIGHT),ss=mt.getParameter(U.UNPACK_SKIP_PIXELS),sn=mt.getParameter(U.UNPACK_SKIP_ROWS),tr=mt.getParameter(U.UNPACK_SKIP_IMAGES);mt.pixelStorei(U.UNPACK_ROW_LENGTH,ue.width),mt.pixelStorei(U.UNPACK_IMAGE_HEIGHT,ue.height),mt.pixelStorei(U.UNPACK_SKIP_PIXELS,At),mt.pixelStorei(U.UNPACK_SKIP_ROWS,Ht),mt.pixelStorei(U.UNPACK_SKIP_IMAGES,Zt);const Oi=M.isDataArrayTexture||M.isData3DTexture,as=I.isDataArrayTexture||I.isData3DTexture;if(M.isDepthTexture){const ne=Dt.get(M),Ze=Dt.get(I),Gn=Dt.get(ne.__renderTarget),we=Dt.get(Ze.__renderTarget);mt.bindFramebuffer(U.READ_FRAMEBUFFER,Gn.__webglFramebuffer),mt.bindFramebuffer(U.DRAW_FRAMEBUFFER,we.__webglFramebuffer);for(let He=0;He<bt;He++)Oi&&(U.framebufferTextureLayer(U.READ_FRAMEBUFFER,U.COLOR_ATTACHMENT0,Dt.get(M).__webglTexture,k,Zt+He),U.framebufferTextureLayer(U.DRAW_FRAMEBUFFER,U.COLOR_ATTACHMENT0,Dt.get(I).__webglTexture,pt,Le+He)),U.blitFramebuffer(At,Ht,At+_t,Ht+ht,St,Jt,St+_t,Jt+ht,U.DEPTH_BUFFER_BIT,U.NEAREST);mt.bindFramebuffer(U.READ_FRAMEBUFFER,null),mt.bindFramebuffer(U.DRAW_FRAMEBUFFER,null)}else if(k!==0||M.isRenderTargetTexture||Dt.has(M)){const ne=Dt.get(M),Ze=Dt.get(I);mt.bindFramebuffer(U.READ_FRAMEBUFFER,L),mt.bindFramebuffer(U.DRAW_FRAMEBUFFER,$);for(let Gn=0;Gn<bt;Gn++)Oi?U.framebufferTextureLayer(U.READ_FRAMEBUFFER,U.COLOR_ATTACHMENT0,ne.__webglTexture,k,Zt+Gn):U.framebufferTexture2D(U.READ_FRAMEBUFFER,U.COLOR_ATTACHMENT0,U.TEXTURE_2D,ne.__webglTexture,k),as?U.framebufferTextureLayer(U.DRAW_FRAMEBUFFER,U.COLOR_ATTACHMENT0,Ze.__webglTexture,pt,Le+Gn):U.framebufferTexture2D(U.DRAW_FRAMEBUFFER,U.COLOR_ATTACHMENT0,U.TEXTURE_2D,Ze.__webglTexture,pt),k!==0?U.blitFramebuffer(At,Ht,At+_t,Ht+ht,St,Jt,St+_t,Jt+ht,U.COLOR_BUFFER_BIT,U.NEAREST):as?U.copyTexSubImage3D(wt,pt,St,Jt,Le+Gn,At,Ht,_t,ht):U.copyTexSubImage2D(wt,pt,St,Jt,At,Ht,_t,ht);mt.bindFramebuffer(U.READ_FRAMEBUFFER,null),mt.bindFramebuffer(U.DRAW_FRAMEBUFFER,null)}else as?M.isDataTexture||M.isData3DTexture?U.texSubImage3D(wt,pt,St,Jt,Le,_t,ht,bt,he,nn,ue.data):I.isCompressedArrayTexture?U.compressedTexSubImage3D(wt,pt,St,Jt,Le,_t,ht,bt,he,ue.data):U.texSubImage3D(wt,pt,St,Jt,Le,_t,ht,bt,he,nn,ue):M.isDataTexture?U.texSubImage2D(U.TEXTURE_2D,pt,St,Jt,_t,ht,he,nn,ue.data):M.isCompressedTexture?U.compressedTexSubImage2D(U.TEXTURE_2D,pt,St,Jt,ue.width,ue.height,he,ue.data):U.texSubImage2D(U.TEXTURE_2D,pt,St,Jt,_t,ht,he,nn,ue);mt.pixelStorei(U.UNPACK_ROW_LENGTH,dn),mt.pixelStorei(U.UNPACK_IMAGE_HEIGHT,ae),mt.pixelStorei(U.UNPACK_SKIP_PIXELS,ss),mt.pixelStorei(U.UNPACK_SKIP_ROWS,sn),mt.pixelStorei(U.UNPACK_SKIP_IMAGES,tr),pt===0&&I.generateMipmaps===!0&&I.mipmapsAutoUpdate===!0&&U.generateMipmap(wt),mt.unbindTexture()},this.initRenderTarget=function(M){Dt.get(M).__webglFramebuffer===void 0&&Ot.setupRenderTarget(M)},this.initTexture=function(M){M.isCubeTexture?Ot.setTextureCube(M,0):M.isData3DTexture?Ot.setTexture3D(M,0):M.isDataArrayTexture||M.isCompressedArrayTexture?Ot.setTexture2DArray(M,0):Ot.setTexture2D(M,0),mt.unbindTexture()},this.resetState=function(){X=0,z=0,et=null,mt.reset(),lt.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return ei}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(t){this._outputColorSpace=t;const e=this.getContext();e.drawingBufferColorSpace=te._getDrawingBufferColorSpace(t),e.unpackColorSpace=te._getUnpackColorSpace()}}const Pb=`
vec3 mod289(vec3 x){return x-floor(x*(1.0/289.0))*289.0;} vec4 mod289(vec4 x){return x-floor(x*(1.0/289.0))*289.0;}
vec4 permute(vec4 x){return mod289(((x*34.0)+1.0)*x);} vec4 taylorInvSqrt(vec4 r){return 1.79284291400159-0.85373472095314*r;}
float snoise(vec3 v){ const vec2 C=vec2(1.0/6.0,1.0/3.0); const vec4 D=vec4(0.0,0.5,1.0,2.0);
  vec3 i=floor(v+dot(v,C.yyy)); vec3 x0=v-i+dot(i,C.xxx); vec3 g=step(x0.yzx,x0.xyz); vec3 l=1.0-g; vec3 i1=min(g.xyz,l.zxy); vec3 i2=max(g.xyz,l.zxy);
  vec3 x1=x0-i1+C.xxx; vec3 x2=x0-i2+C.yyy; vec3 x3=x0-D.yyy; i=mod289(i);
  vec4 p=permute(permute(permute(i.z+vec4(0.0,i1.z,i2.z,1.0))+i.y+vec4(0.0,i1.y,i2.y,1.0))+i.x+vec4(0.0,i1.x,i2.x,1.0));
  float n_=0.142857142857; vec3 ns=n_*D.wyz-D.xzx; vec4 j=p-49.0*floor(p*ns.z*ns.z); vec4 x_=floor(j*ns.z); vec4 y_=floor(j-7.0*x_);
  vec4 x=x_*ns.x+ns.yyyy; vec4 y=y_*ns.x+ns.yyyy; vec4 h=1.0-abs(x)-abs(y); vec4 b0=vec4(x.xy,y.xy); vec4 b1=vec4(x.zw,y.zw);
  vec4 s0=floor(b0)*2.0+1.0; vec4 s1=floor(b1)*2.0+1.0; vec4 sh=-step(h,vec4(0.0)); vec4 a0=b0.xzyw+s0.xzyw*sh.xxyy; vec4 a1=b1.xzyw+s1.xzyw*sh.zzww;
  vec3 p0=vec3(a0.xy,h.x); vec3 p1=vec3(a0.zw,h.y); vec3 p2=vec3(a1.xy,h.z); vec3 p3=vec3(a1.zw,h.w);
  vec4 norm=taylorInvSqrt(vec4(dot(p0,p0),dot(p1,p1),dot(p2,p2),dot(p3,p3))); p0*=norm.x; p1*=norm.y; p2*=norm.z; p3*=norm.w;
  vec4 m=max(0.6-vec4(dot(x0,x0),dot(x1,x1),dot(x2,x2),dot(x3,x3)),0.0); m=m*m;
  return 42.0*dot(m*m,vec4(dot(p0,x0),dot(p1,x1),dot(p2,x2),dot(p3,x3))); }
float fbm(vec3 p, int oct){ float s=0.0, a=0.5; for(int i=0;i<8;i++){ if(i>=oct) break; s+=a*snoise(p); p=p*2.03+vec3(1.7,9.2,3.1); a*=0.5; } return s; }
vec3 hash3(vec3 p){ p=fract(p*vec3(0.1031,0.1030,0.0973)); p+=dot(p,p.yxz+33.33); return fract((p.xxy+p.yxx)*p.zyx); }
float craters(vec3 p){ vec3 i=floor(p), f=fract(p); float c=0.0; for(int x=-1;x<=1;x++) for(int y=-1;y<=1;y++) for(int z=-1;z<=1;z++){ vec3 o=vec3(float(x),float(y),float(z)); vec3 h=hash3(i+o); vec3 d=o+h-f; float r=0.15+0.3*h.x; float dd=length(d)/r; if(dd<1.0){ c+= (dd<0.8? -0.6*(1.0-dd*dd*1.4) : 0.0) + (dd>=0.75 ? 0.5*(1.0-abs(dd-0.88)/0.13) : 0.0); } } return c; }`,Lb="varying vec2 vUv; void main(){ vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }",Db=`precision highp float; varying vec2 vUv; uniform int uMode; uniform float uSeed;
${Pb}
vec3 dirOf(vec2 uv){ float lon = (uv.x - 0.5) * 6.2831853; float lat = (uv.y - 0.5) * 3.1415926; return vec3(cos(lat)*cos(lon), sin(lat), cos(lat)*sin(lon)); }
void main(){ vec3 n = dirOf(vUv); vec3 p = n*1.2 + vec3(uSeed*7.31, uSeed*3.17, uSeed*1.91);
  if (uMode == 0) { // Earth albedo (rgb) + water mask (a)
    float h = fbm(p*1.6, 7) + 0.35*fbm(p*5.0, 4); float wl = 0.02; vec3 col; float water = 0.0;
    if (h < wl) { float dpt = clamp((wl-h)*3.0, 0.0, 1.0); col = mix(vec3(0.12,0.42,0.65), vec3(0.04,0.16,0.36), dpt); water = 1.0; }
    else { float e = clamp((h-wl)/0.73, 0.0, 1.0); float dry = smoothstep(0.1, 0.5, snoise(p*1.3+4.0)*0.5+0.5) * (1.0-abs(n.y));
      vec3 green = mix(vec3(0.20,0.45,0.18), vec3(0.62,0.55,0.34), dry); col = e < 0.45 ? mix(green, vec3(0.55,0.5,0.36), e/0.45) : mix(vec3(0.55,0.5,0.36), vec3(0.92,0.9,0.86), (e-0.45)/0.55); }
    float lat = abs(n.y) + 0.06*snoise(p*2.0); float ice = smoothstep(0.84, 0.89, lat); col = mix(col, vec3(0.94,0.96,1.0), ice); water *= 1.0-ice;
    gl_FragColor = vec4(col, water); }
  else if (uMode == 1) { // clouds (r), city lights (g)
    float cl = smoothstep(0.36, 0.78, fbm(n*2.2 + vec3(uSeed), 6)*0.5+0.5); cl = max(cl, smoothstep(0.55, 0.9, fbm(n*vec3(1.0,3.5,1.0)*2.0+3.0, 4)*0.5+0.5)*0.8*(1.0-abs(n.y)));
    float h = fbm(p*1.6, 7) + 0.35*fbm(p*5.0, 4); float land = smoothstep(0.03, 0.12, h-0.02);
    float region = smoothstep(0.55, 0.8, snoise(p*5.0)*0.5+0.5); float dots = smoothstep(0.6, 0.9, snoise(p*70.0)*0.5+0.5) + 0.35*smoothstep(0.7, 0.95, snoise(p*26.0)*0.5+0.5);
    gl_FragColor = vec4(cl, region*dots*land*(1.0-smoothstep(0.75, 0.9, abs(n.y))), 0.0, 1.0); }
  else if (uMode == 2) { // Moon albedo
    float h = fbm(p*1.6, 6)*0.6 + craters(n*6.0+uSeed)*0.5 + craters(n*15.0+uSeed*2.0)*0.25; float mare = smoothstep(0.1, -0.2, fbm(p*0.9+2.0, 4));
    vec3 col = mix(vec3(0.62,0.61,0.59), vec3(0.36,0.36,0.37), mare) * (0.8 + h*0.35); gl_FragColor = vec4(col, 1.0); }
  else if (uMode == 4) { // Mars albedo: rust plains, dark regions, polar caps
    float h = fbm(p*1.4, 6); float dark = smoothstep(0.05, 0.35, fbm(p*0.8+5.0, 4)); vec3 col = mix(vec3(0.78,0.42,0.24), vec3(0.42,0.2,0.13), dark) * (0.85 + h*0.25);
    float ice = smoothstep(0.86, 0.9, abs(n.y) + 0.04*snoise(p*3.0)); col = mix(col, vec3(0.95,0.93,0.9), ice); gl_FragColor = vec4(col, 1.0); }
  else { // nebula sky
    float n1 = fbm(n*1.8 + 1.3, 5)*0.5+0.5; float n2 = fbm(n*4.0 + 3.0, 4)*0.5+0.5; vec3 col = vec3(0.004,0.006,0.016) + vec3(0.12,0.22,0.5)*pow(n1, 3.4)*0.6 + vec3(0.25,0.08,0.3)*pow(n2, 4.0)*0.5;
    float band = exp(-pow(n.y*3.2 + 0.4*snoise(n*3.0), 2.0)); col += vec3(0.16,0.15,0.2)*band*(0.5+0.5*n1);
    gl_FragColor = vec4(col, 1.0); } }`;function Ma(i,t,e,n,s=1){const a=new Bn(e,n,{type:xn,generateMipmaps:!0,minFilter:Pi,magFilter:pn,wrapS:io}),r=new Bo,o=new vd(-1,1,1,-1,0,1),l=new En({vertexShader:Lb,fragmentShader:Db,uniforms:{uMode:{value:t},uSeed:{value:s}}}),c=new Pt(new ws(2,2),l);r.add(c);const d=i.getRenderTarget();return i.setRenderTarget(a),i.render(r,o),i.setRenderTarget(d),l.dispose(),c.geometry.dispose(),a.texture.colorSpace=t===1?Ai:Je,a}const nu="varying vec3 vN; varying vec3 vW; varying vec2 vUv; void main(){ vUv = uv; vN = normalize(mat3(modelMatrix)*normal); vec4 w = modelMatrix*vec4(position,1.0); vW = w.xyz; gl_Position = projectionMatrix*viewMatrix*w; }",iu=`uniform sampler2D uDay; uniform sampler2D uAux; uniform vec3 uSun; uniform float uTime; varying vec3 vN; varying vec3 vW; varying vec2 vUv;
void main(){ vec3 n = normalize(vN); vec3 v = normalize(cameraPosition - vW); float ndl = dot(n, uSun);
  vec4 day = texture2D(uDay, vUv); vec4 aux = texture2D(uAux, vUv); float cl = texture2D(uAux, vUv + vec2(uTime*0.0016, 0.0)).r;
  float diff = max(ndl, 0.0); vec3 col = day.rgb*(0.025 + diff*1.1);
  vec3 h = normalize(uSun + v); col += vec3(1.0,0.93,0.8)*pow(max(dot(n,h),0.0), 70.0)*day.a*diff*0.9;
  col = mix(col, vec3(1.0)*(0.04 + diff*1.15), cl*0.9);
  col += vec3(1.0,0.72,0.38)*aux.g*(1.0-cl*0.85)*smoothstep(0.05,-0.25,ndl)*1.6;
  float limb = pow(1.0 - max(dot(n, v), 0.0), 3.0); col += vec3(0.32,0.58,1.0)*limb*(0.15 + diff*0.95);
  col = mix(col, col*vec3(1.15,0.85,0.7), smoothstep(0.2,0.0,ndl)*smoothstep(-0.1,0.05,ndl)*0.6);
  gl_FragColor = vec4(col, 1.0); }`,su=`uniform vec3 uSun; varying vec3 vN; varying vec3 vW; void main(){ vec3 n = normalize(vN); vec3 v = normalize(cameraPosition - vW); float rim = pow(1.0 - abs(dot(n, v)), 2.6);
  float lit = clamp(dot(n, uSun)*0.9 + 0.35, 0.0, 1.0); gl_FragColor = vec4(vec3(0.35,0.62,1.0)*rim*lit*1.6, rim*lit); }`,Dl="varying vec3 vN; varying vec3 vW; varying vec2 vUv; void main(){ vUv = uv; vN = normalize(mat3(modelMatrix)*normal); vec4 w = modelMatrix*vec4(position,1.0); vW = w.xyz; gl_Position = projectionMatrix*viewMatrix*w; }",Ib="uniform sampler2D uMap; uniform vec3 uSun; varying vec3 vN; varying vec2 vUv; void main(){ float d = max(dot(normalize(vN), uSun), 0.0); gl_FragColor = vec4(texture2D(uMap, vUv).rgb*(0.02 + d*1.2), 1.0); }";class Nb{constructor(t,e,n){this.group=new Te,this.targets=[],this.worlds={},this.world="earth",this.renderer=null,this.R=0,this.sunDir=e.clone().normalize();const s=n==="high",a=s?2048:1024,r=Ma(t,0,a,a/2,1),o=Ma(t,1,a,a/2,1),l=Ma(t,2,512,256,4),c=Ma(t,3,s?1024:512,s?512:256,2);this.targets.push(r,o,l,c);const d=3e3,h=d*Math.sin(uo.degToRad(50));this.uniforms={uDay:{value:r.texture},uAux:{value:o.texture},uSun:{value:this.sunDir},uTime:{value:0}},this.earth=new Pt(new Oe(h,s?128:72,s?64:40),new En({vertexShader:nu,fragmentShader:iu,uniforms:this.uniforms})),this.earth.position.set(0,-d,0),this.earth.rotation.z=.35,this.group.add(this.earth);const u=new Pt(new Oe(h*1.03,64,32),new En({vertexShader:Dl,fragmentShader:su,uniforms:{uSun:{value:this.sunDir}},side:en,transparent:!0,blending:Zi,depthWrite:!1}));u.position.copy(this.earth.position),this.group.add(u),this.atm=u,this.renderer=t,this.R=h,this.worlds.earth=[],this.moon=new Pt(new Oe(160,40,24),new En({vertexShader:Dl,fragmentShader:Ib,uniforms:{uMap:{value:l.texture},uSun:{value:this.sunDir}}})),this.moon.position.set(-3400,900,-4200),this.group.add(this.moon);const f=new Pt(new Oe(9e3,48,24),new Me({map:c.texture,side:en,depthWrite:!1}));this.group.add(f);const g=s?3500:1800,x=new Float32Array(g*3),m=new Float32Array(g*3),p=new Rt;for(let w=0;w<g;w++){const E=Math.random()*2-1,v=Math.random()*Math.PI*2,S=Math.sqrt(1-E*E);x.set([S*Math.cos(v)*8500,E*8500,S*Math.sin(v)*8500],w*3),p.setHSL(.55+Math.random()*.15-(Math.random()<.2?.45:0),.5,.75+Math.random()*.25),m.set([p.r,p.g,p.b],w*3)}const y=new ge;y.setAttribute("position",new Ne(x,3)),y.setAttribute("color",new Ne(m,3)),this.group.add(new Wa(y,new sa({size:s?2.2:1.8,sizeAttenuation:!1,vertexColors:!0,depthWrite:!1,transparent:!0,opacity:.95})));const A=(()=>{const w=document.createElement("canvas");w.width=w.height=128;const E=w.getContext("2d"),v=E.createRadialGradient(64,64,0,64,64,64);v.addColorStop(0,"rgba(255,255,240,1)"),v.addColorStop(.12,"rgba(255,248,220,0.95)"),v.addColorStop(.35,"rgba(255,220,160,0.25)"),v.addColorStop(1,"rgba(255,200,120,0)"),E.fillStyle=v,E.fillRect(0,0,128,128);const S=new gd(w);return S.colorSpace=Je,S})(),b=new Lc(new po({map:A,depthWrite:!1,blending:Zi,transparent:!0}));b.position.copy(this.sunDir).multiplyScalar(7e3),b.scale.setScalar(1300),this.group.add(b)}setWorld(t){if(t===this.world)return;this.world=t;const e=this.renderer;if(!this.worlds[t]&&t!=="earth"){const n=Ma(e,t==="mars"?4:2,1024,512,t==="moon"?4:t==="vault"?9:5);this.targets.push(n);const s=new Pt(new Oe(this.R,96,48),new P0({map:n.texture,color:t==="vault"?new Rt(.55,.38,.85):new Rt(.62,.62,.62),emissive:t==="vault"?new Rt(.05,.02,.1):new Rt(0,0,0)}));s.position.copy(this.earth.position),s.rotation.z=.2,this.group.add(s);const a=[s];if(t==="mars"||t==="vault"){const o=new Pt(new Oe(this.R*1.02,64,32),new En({vertexShader:Dl,fragmentShader:su.replace("vec3(0.35,0.62,1.0)",t==="vault"?"vec3(0.7,0.45,1.0)":"vec3(0.95,0.6,0.42)"),uniforms:{uSun:{value:this.sunDir}},side:en,transparent:!0,blending:Zi,depthWrite:!1}));o.position.copy(s.position),this.group.add(o),a.push(o)}const r=t==="moon"?new Pt(new Oe(260,48,32),new En({vertexShader:nu,fragmentShader:iu,uniforms:this.uniforms})):new Pt(new Hn(90,2),new ln({color:"#6e6660",flatShading:!0,roughness:1}));r.position.set(-3e3,1400,-4600),this.group.add(r),a.push(r),this.worlds[t]=a}for(const[n,s]of Object.entries(this.worlds))s.forEach(a=>a.visible=n===t);this.earth.visible=t==="earth",this.atm.visible=t==="earth",this.moon.visible=t==="earth"}update(t,e){this.uniforms.uTime.value=t,this.earth.rotation.y=t*.004,this.group.position.set(e.position.x*.98,0,e.position.z*.98)}}const Ft=fe*$l,Ur={haven:{top:[.3,.55,.43],rim:[.24,.42,.5],soil:[.08,.42,.33],deep:[.07,.25,.22],rock:[.07,.28,.27],flora:"grass",peb:"#8a8f99"},moon:{top:[.6,.03,.46],rim:[.6,.03,.55],soil:[.6,.03,.4],deep:[.6,.03,.28],rock:[.6,.03,.3],flora:"pebbles",peb:"#9a9a9e"},vault:{top:[.74,.32,.24],rim:[.76,.42,.34],soil:[.74,.3,.16],deep:[.74,.25,.1],rock:[.72,.2,.14],flora:"pebbles",peb:"#b06dff"},mars:{top:[.03,.62,.36],rim:[.05,.55,.46],soil:[.03,.45,.32],deep:[.02,.35,.22],rock:[.02,.32,.24],flora:"pebbles",peb:"#6b3422"}};class Ub{constructor(){this.group=new Te,this.grid=null,this.theme="haven",this.holo=new Te,this.debris=null,this.dInfo=[],this.key="",this.flora=[],this.floraKey="",this.group.add(this.holo)}build(t,e,n="haven"){const s=t.join("|")+"#"+e.join("|")+n;if(s===this.key)return;this.key=s,this.floraKey="",this.theme=n;const a=Ur[n]||Ur.haven;for(const b of[...this.group.children])b!==this.holo&&(this.group.remove(b),Fb(b));this.holo.clear(),this.flora=[];const r=new Set(t),o=(b,w)=>b>=0&&w>=0&&b<Ft&&w<Ft&&r.has(`${Math.floor(b/fe)},${Math.floor(w/fe)}`),l=Tn(7),c=[],d=[],h=new Rt,u=(b,w,E,v,S)=>{c.push(...b,...w,...E,...b,...E,...v);for(let P=0;P<6;P++)d.push(S.r,S.g,S.b)};for(let b=0;b<Ft;b++)for(let w=0;w<Ft;w++){if(!o(b,w))continue;const E=b-Ft/2,v=w-Ft/2,S=!o(b-1,w)||!o(b+1,w)||!o(b,w-1)||!o(b,w+1),P=(l()-.5)*.05+((b+w)%2?.012:-.012),R=S?a.rim:a.top;h.setHSL(R[0]+(S?0:(l()-.5)*.02),R[1],R[2]+P),u([E,0,v],[E,0,v+1],[E+1,0,v+1],[E+1,0,v],h);const N=[[!o(b,w-1),[E+1,0,v],[E,0,v]],[!o(b,w+1),[E,0,v+1],[E+1,0,v+1]],[!o(b-1,w),[E,0,v],[E,0,v+1]],[!o(b+1,w),[E+1,0,v+1],[E+1,0,v]]];for(const[F,H,L]of N)F&&(h.setHSL(a.soil[0],a.soil[1],a.soil[2]+(l()-.5)*.04),u(H,[H[0],-.45,H[2]],[L[0],-.45,L[2]],L,h),h.setHSL(a.deep[0],a.deep[1],a.deep[2]),u([H[0],-.45,H[2]],[H[0],-.9,H[2]],[L[0],-.9,L[2]],[L[0],-.45,L[2]],h))}const f=new ge;f.setAttribute("position",new se(c,3)),f.setAttribute("color",new se(d,3)),f.computeVertexNormals();const g=new Pt(f,new ln({vertexColors:!0,roughness:.92,metalness:0,flatShading:!0}));g.receiveShadow=!0,g.name="ground",this.group.add(g);const x=new ln({vertexColors:!0,flatShading:!0,roughness:.95});for(const b of t){const[w,E]=b.split(",").map(Number),v=w*fe+fe/2-Ft/2,S=E*fe+fe/2-Ft/2,P=Tn(w*31+E*7+3),R=4+P()*3.5,N=new $n(fe*.62,R,9,4,!0);N.rotateX(Math.PI),N.translate(0,-.85-R/2,0);const F=N.attributes.position,H=new Float32Array(F.count*3);for(let X=0;X<F.count;X++){const z=F.getY(X),et=(-z-.85)/R,V=1-et*.15;F.setX(X,F.getX(X)*V+(P()-.5)*.5*(1-et)),F.setZ(X,F.getZ(X)*V+(P()-.5)*.5*(1-et)),F.setY(X,z+(P()-.5)*.35*(et>.02?1:0)),h.setHSL(a.rock[0]-et*.02,Math.max(0,a.rock[1]-et*.12),a.rock[2]-et*.12+(P()-.5)*.04),H.set([h.r,h.g,h.b],X*3)}N.setAttribute("color",new Ne(H,3)),N.computeVertexNormals();const L=new Pt(N,x);L.position.set(v,0,S),L.castShadow=!0,this.group.add(L);const $=new Pt(new fi(.22,0),new Me({color:"#7af7ff",toneMapped:!1}));$.position.set(v+(P()-.5)*3,-1.6-P()*1.4,S+(P()-.5)*3),$.scale.y=2,this.group.add($)}const m=[];for(let b=0;b<Ft;b++)for(let w=0;w<Ft;w++){if(!o(b,w)||(b+w)%2)continue;const E=b-Ft/2+.5,v=w-Ft/2+.5;o(b,w-1)||m.push(new D(E,-.2,v-.5)),o(b,w+1)||m.push(new D(E,-.2,v+.5)),o(b-1,w)||m.push(new D(E-.5,-.2,v)),o(b+1,w)||m.push(new D(E+.5,-.2,v))}if(m.length){const b=new Mr(new Oe(.06,6,4),new Me({color:"#7af7ff",toneMapped:!1}),m.length),w=new ee;m.forEach((E,v)=>{w.makeTranslation(E.x,E.y,E.z),b.setMatrixAt(v,w)}),this.group.add(b)}const p=26;this.debris=new Mr(new ra(.5,0),x.clone(),p),this.debris.material.vertexColors=!1,this.debris.material.color.set("#6b5a4a"),this.debris.castShadow=!0,this.dInfo=[];for(let b=0;b<p;b++){const w=l()*Math.PI*2,E=14+l()*12;this.dInfo.push({p:new D(Math.cos(w)*E,-3-l()*6,Math.sin(w)*E),s:.3+l()*1.1,r:l()*6,ph:l()*6})}this.group.add(this.debris);for(const b of e){const[w,E]=b.split(",").map(Number),v=w*fe+fe/2-Ft/2,S=E*fe+fe/2-Ft/2,P=new Pt(new ai(fe-.3,.08,fe-.3),new Me({color:"#4fd8ff",transparent:!0,opacity:.12,depthWrite:!1}));P.position.set(v,-.1,S),P.userData.plot=b,this.holo.add(P);const R=new wh(new w0(new ai(fe-.3,.08,fe-.3)),new mo({color:"#7af7ff",transparent:!0,opacity:.35}));R.position.copy(P.position),this.holo.add(R)}const y=[];for(let b=0;b<=Ft;b++)for(let w=0;w<Ft;w++)(o(b,w)||o(b-1,w))&&y.push(b-Ft/2,.02,w-Ft/2,b-Ft/2,.02,w+1-Ft/2);for(let b=0;b<=Ft;b++)for(let w=0;w<Ft;w++)(o(w,b)||o(w,b-1))&&y.push(w-Ft/2,.02,b-Ft/2,w+1-Ft/2,.02,b-Ft/2);const A=new ge;A.setAttribute("position",new se(y,3)),this.grid=new wh(A,new mo({color:"#ffffff",transparent:!0,opacity:.18})),this.grid.visible=!1,this.group.add(this.grid)}holoMeshes(){return this.holo.children.filter(t=>t.userData.plot)}scatter(t,e){const n=t.join("|")+"#"+[...e].sort().join(",");if(n===this.floraKey)return;this.floraKey=n,this.flora.forEach(f=>{this.group.remove(f),f.geometry.dispose()}),this.flora=[];const s=new Set(t),a=Tn(99),r=[],o=[],l=new Ni,c=new zn,d=["#ffd84a","#ff7ab8","#ffffff","#9fd0ff","#ff9a4a"];for(let f=0;f<Ft;f++)for(let g=0;g<Ft;g++){if(!s.has(`${Math.floor(f/fe)},${Math.floor(g/fe)}`)||e.has(f+","+g))continue;const x=a()<.55?1+Math.floor(a()*3):0;for(let m=0;m<x;m++){c.set(0,a()*6,(a()-.5)*.3),l.setFromEuler(c);const p=.6+a()*.7;r.push(new ee().compose(new D(f-Ft/2+.15+a()*.7,0,g-Ft/2+.15+a()*.7),l,new D(p,p*(.8+a()*.6),p)))}if(a()<.12){const m=new Rt(d[Math.floor(a()*d.length)]);o.push({m:new ee().makeTranslation(f-Ft/2+.2+a()*.6,.09,g-Ft/2+.2+a()*.6),c:m})}}const h=Ur[this.theme]||Ur.haven,u=h.flora==="pebbles";if(u&&(o.length=0),r.length){const f=u?new ra(.06,0):new $n(.045,.2,3);f.translate(0,u?.03:.1,0);const g=new Mr(f,new ln({color:u?h.peb:"#5fb04a",flatShading:!0,roughness:.9}),r.length);r.forEach((x,m)=>g.setMatrixAt(m,x)),g.receiveShadow=!0,this.group.add(g),this.flora.push(g)}if(o.length){const f=new Hn(.045,0),g=new Mr(f,new ln({color:"#ffffff",roughness:.6,emissive:"#222222"}),o.length);o.forEach((x,m)=>{g.setMatrixAt(m,x.m),g.setColorAt(m,x.c)}),this.group.add(g),this.flora.push(g)}}update(t){if(this.debris){const e=new ee,n=new Ni,s=new zn,a=new D;this.dInfo.forEach((r,o)=>{s.set(r.r+t*.1,r.r*2+t*.07,0),n.setFromEuler(s),a.setScalar(r.s),e.compose(new D(r.p.x,r.p.y+Math.sin(t*.4+r.ph)*.4,r.p.z),n,a),this.debris.setMatrixAt(o,e)}),this.debris.instanceMatrix.needsUpdate=!0}this.holo.children.forEach(e=>{const n=e.material;n&&"opacity"in n&&e.userData.plot&&(n.opacity=.05+Math.sin(t*2)*.025)})}}function Fb(i){i.traverse(t=>{const e=t;e.geometry&&e.geometry.dispose()})}function Ob(i,t=!1){const e=i[0].index!==null,n=new Set(Object.keys(i[0].attributes)),s=new Set(Object.keys(i[0].morphAttributes)),a={},r={},o=i[0].morphTargetsRelative,l=new ge;l.morphTargetsRelative=o;let c=0;for(let d=0;d<i.length;++d){const h=i[d];let u=0,f=0;if(e!==(h.index!==null))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+d+". All geometries must have compatible attributes; make sure index attribute exists among all geometries, or in none of them."),null;for(const g in h.attributes){if(!n.has(g))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+d+'. All geometries must have compatible attributes; make sure "'+g+'" attribute exists among all geometries, or in none of them.'),null;a[g]===void 0&&(a[g]=[]),a[g].push(h.attributes[g]),u++}if(u!==n.size)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+d+". Make sure all geometries have the same number of attributes."),null;if(o!==h.morphTargetsRelative)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+d+". .morphTargetsRelative must be consistent throughout all geometries."),null;for(const g in h.morphAttributes){if(!s.has(g))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+d+".  .morphAttributes must be consistent throughout all geometries."),null;if(h.morphAttributes[g].length!==i[0].morphAttributes[g].length)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+d+'. All geometries must have the same number of morph targets for the "'+g+'" morph attribute.'),null;r[g]===void 0&&(r[g]=[]),r[g].push(h.morphAttributes[g]),f++}if(f!==s.size)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+d+". Make sure all geometries have the same number of morph attributes."),null;if(t){let g;if(e)g=h.index.count;else if(h.attributes.position!==void 0)g=h.attributes.position.count;else return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+d+". The geometry must have either an index or a position attribute"),null;l.addGroup(c,g,d),c+=g}}if(e){let d=0;const h=[];for(let u=0;u<i.length;++u){const f=i[u].index;for(let g=0;g<f.count;++g)h.push(f.getX(g)+d);d+=i[u].attributes.position.count}l.setIndex(h)}for(const d in a){const h=au(a[d]);if(!h)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+d+" attribute."),null;l.setAttribute(d,h)}for(const d in r){const h=r[d][0].length;if(h!==0){l.morphAttributes=l.morphAttributes||{},l.morphAttributes[d]=[];for(let u=0;u<h;++u){const f=[];for(let x=0;x<r[d].length;++x)f.push(r[d][x][u]);const g=au(f);if(!g)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+d+" morphAttribute."),null;l.morphAttributes[d].push(g)}}}return l}function au(i){let t,e,n,s=-1,a=0;for(let c=0;c<i.length;++c){const d=i[c];if(t===void 0&&(t=d.array.constructor),t!==d.array.constructor)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.array must be of consistent array types across matching attributes."),null;if(e===void 0&&(e=d.itemSize),e!==d.itemSize)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.itemSize must be consistent across matching attributes."),null;if(n===void 0&&(n=d.normalized),n!==d.normalized)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.normalized must be consistent across matching attributes."),null;if(s===-1&&(s=d.gpuType),s!==d.gpuType)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.gpuType must be consistent across matching attributes."),null;a+=d.count*e}const r=new t(a),o=new Ne(r,e,n);let l=0;for(let c=0;c<i.length;++c){const d=i[c];if(d.isInterleavedBufferAttribute){const h=l/e;for(let u=0,f=d.count;u<f;u++)for(let g=0;g<e;g++){const x=d.getComponent(u,g);o.setComponent(u+h,g,x)}}else r.set(d.array,l);l+=d.count*e}return s!==void 0&&(o.gpuType=s),o}const Fr=new Rt,Ua={body:new ln({vertexColors:!0,flatShading:!0,roughness:.62,metalness:.12}),glow:new Me({vertexColors:!0,toneMapped:!1}),glass:new ln({vertexColors:!0,transparent:!0,opacity:.38,roughness:.08,metalness:.2,depthWrite:!1}),ghostOk:new Me({color:6160282,transparent:!0,opacity:.45,depthWrite:!1}),ghostBad:new Me({color:16734826,transparent:!0,opacity:.45,depthWrite:!1})};class Ce{constructor(){this.parts={body:[],glow:[],glass:[]}}add(t,e,n=0,s=0,a=0,r={}){let o=t.index?t.toNonIndexed():t.clone();o.attributes.uv&&o.deleteAttribute("uv"),o.attributes.uv1&&o.deleteAttribute("uv1");const l=new ee().compose(new D(n,s,a),new Ni().setFromEuler(new zn(r.rx||0,r.ry||0,r.rz||0)),new D(r.sx??1,r.sy??1,r.sz??1));o.applyMatrix4(l),Fr.set(e);const c=o.attributes.position.count,d=new Float32Array(c*3);for(let h=0;h<c;h++)d[h*3]=Fr.r,d[h*3+1]=Fr.g,d[h*3+2]=Fr.b;return o.setAttribute("color",new Ne(d,3)),this.parts[r.glow?"glow":r.glass?"glass":"body"].push(o),t.dispose(),this}box(t,e,n,s,a=0,r=0,o=0,l={}){return this.add(new ai(t,e,n),s,a,r+e/2,o,l)}cyl(t,e,n,s,a,r=0,o=0,l=0,c={}){return this.add(new bn(t,e,n,s),a,r,o+n/2,l,c)}sphere(t,e,n=0,s=0,a=0,r={}){return this.add(new Oe(t,r.w||10,r.h||7,0,Math.PI*2,0,r.theta||Math.PI),e,n,s,a,r)}build(t=""){const e=new Te;e.name=t;for(const n of["body","glow","glass"]){const s=this.parts[n];if(!s.length)continue;const a=Ob(s,!1);if(s.forEach(o=>o.dispose()),!a)continue;const r=new Pt(a,Ua[n]);r.castShadow=n==="body",r.receiveShadow=n==="body",r.userData.bucket=n,e.add(r)}return e}}const yn=(i,t)=>{const e=new Rt(i);return t<0?e.lerp(new Rt(0),-t):e.lerp(new Rt(16777215),t),"#"+e.getHexString()},ru=(i,t,e)=>"#"+new Rt(i).lerp(new Rt(t),e).getHexString(),kt={solar:{name:"Solar",color:"#ffb23e",glow:"#ffe08a",glyph:"☀",strong:["bio","cryo"],blurb:"Runs on starlight. Hums when the Sun is up."},plasma:{name:"Plasma",color:"#ff5a3c",glow:"#ffb08a",glyph:"♨",strong:["alloy","bio"],blurb:"Contained fire at ten thousand degrees."},hydro:{name:"Hydro",color:"#2f8cff",glow:"#9fd0ff",glyph:"≈",strong:["plasma","geo"],blurb:"Pumps, cleans and cools. Every colony needs water."},cryo:{name:"Cryo",color:"#7fe4ff",glow:"#dff8ff",glyph:"❄",strong:["aero","bio"],blurb:"Supercooled circuits, near absolute zero."},geo:{name:"Geo",color:"#b07a4a",glow:"#e2b48c",glyph:"▲",strong:["volt","plasma"],blurb:"Drills, diggers and regolith movers."},bio:{name:"Bio",color:"#4fcf5a",glow:"#b6ffb0",glyph:"❦",strong:["hydro","geo"],blurb:"Gardeners of greenhouses and living hulls."},volt:{name:"Volt",color:"#ffe23a",glow:"#fff6a8",glyph:"ϟ",strong:["hydro","aero"],blurb:"Lightning in a capacitor."},alloy:{name:"Alloy",color:"#9aa7b8",glow:"#e6edf5",glyph:"⚙",strong:["cryo","kinetic"],blurb:"Armour, welders and heavy lifting."},void:{name:"Void",color:"#6b3fd6",glow:"#c2a6ff",glyph:"◐",strong:["photon","neural"],blurb:"Built for the dark between stars."},photon:{name:"Photon",color:"#fff4c2",glow:"#ffffff",glyph:"✦",strong:["void","chrono"],blurb:"Lasers, lenses and light."},kinetic:{name:"Kinetic",color:"#ff7a1a",glow:"#ffc28a",glyph:"✊",strong:["alloy","gravity"],blurb:"Impact, momentum, mass drivers."},aero:{name:"Aero",color:"#b9f0e6",glow:"#ecfffb",glyph:"༄",strong:["geo","kinetic"],blurb:"Flyers and atmosphere shapers."},gravity:{name:"Gravity",color:"#3c4aa8",glow:"#9aa6ff",glyph:"◉",strong:["aero","photon"],blurb:"Bends space a little, on purpose."},chrono:{name:"Chrono",color:"#c9a2ff",glow:"#eedcff",glyph:"⧗",strong:["neural","volt"],blurb:"Clocks running a little sideways."},neural:{name:"Neural",color:"#ff6fd8",glow:"#ffc4f0",glyph:"✺",strong:["kinetic","gravity"],blurb:"Artificial minds. They learn from everything."},relic:{name:"Relic",color:"#d8b46a",glow:"#fff0c4",glyph:"⌬",relic:!0,strong:[],blurb:"Precursor make, older than our species."},aurora:{name:"Aurora",color:"#6fffc8",glow:"#d6fff0",glyph:"❈",relic:!0,strong:[],blurb:"Beauty as a power source."},arcana:{name:"Arcana",color:"#8a5cff",glow:"#d7c6ff",glyph:"✧",relic:!0,strong:[],blurb:"Technology indistinguishable from magic."},entropy:{name:"Entropy",color:"#ff3d6e",glow:"#ffb3c6",glyph:"✹",relic:!0,strong:[],blurb:"Chaos, harnessed."},joy:{name:"Joy",color:"#ffd24a",glow:"#fff2b8",glyph:"☺",relic:!0,strong:[],blurb:"Precursor machines made to be happy."},reverie:{name:"Reverie",color:"#7aa8ff",glow:"#d2e2ff",glyph:"☾",relic:!0,strong:[],blurb:"They dream in mathematics."},soul:{name:"Soul",color:"#f2f2ff",glow:"#ffffff",glyph:"❂",relic:!0,strong:[],blurb:"Something in them is alive."}},Bb=Object.keys(kt).filter(i=>!kt[i].relic),An="#c8d0da",ni="#3a4250",la="#bfe9ff",fs="#ffe9a8";function je(i,t){return new Pt(i,new Me({color:t,toneMapped:!1}))}function Wo(i,t=.7,e=.45){const n=kb(i.banner),s=new ws(t,e,8,1);s.translate(t/2,0,0);const a=new Pt(s,new ln({map:n,side:Un,roughness:.8}));a.castShadow=!0;const r=s.attributes.position.array.slice();return a.userData.wave=o=>{const l=s.attributes.position.array;for(let c=0;c<l.length;c+=3){const d=r[c];l[c+2]=Math.sin(d*7-o*4)*.06*(d/t)}s.attributes.position.needsUpdate=!0},a}const ou=new Map;function kb(i){const t=i.bg+i.fg+i.emblem,e=ou.get(t);if(e)return e;const n=document.createElement("canvas");n.width=128,n.height=80;const s=n.getContext("2d");s.fillStyle=i.bg,s.fillRect(0,0,128,80),s.fillStyle=yn(i.bg,-.25),s.fillRect(0,64,128,16),s.fillStyle=i.fg,s.translate(64,36),yd(s,i.emblem,22),s.fill();const a=new gd(n);return a.colorSpace=Je,ou.set(t,a),a}function yd(i,t,e){if(i.beginPath(),t==="star")for(let n=0;n<10;n++){const s=-Math.PI/2+n*Math.PI/5,a=n%2?e*.45:e;i.lineTo(Math.cos(s)*a,Math.sin(s)*a)}else if(t==="planet")i.arc(0,0,e*.6,0,7),i.moveTo(e,0),i.ellipse(0,0,e,e*.28,-.3,0,7);else if(t==="bolt")i.moveTo(e*.2,-e),i.lineTo(-e*.5,e*.1),i.lineTo(0,e*.1),i.lineTo(-e*.2,e),i.lineTo(e*.5,-e*.1),i.lineTo(0,-e*.1);else if(t==="gear")for(let n=0;n<16;n++){const s=n*Math.PI/8,a=n%2?e*.7:e;i.lineTo(Math.cos(s)*a,Math.sin(s)*a)}else t==="rocket"?(i.moveTo(0,-e),i.quadraticCurveTo(e*.45,-e*.3,e*.3,e*.5),i.lineTo(e*.6,e),i.lineTo(-e*.6,e),i.lineTo(-e*.3,e*.5),i.quadraticCurveTo(-e*.45,-e*.3,0,-e)):i.arc(0,0,e*.8,0,7);i.closePath()}function zb(i,t){const e=new Ce,n=t.primary,s=t.accent,a=Math.min(5,1+Math.floor((i-1)/3));e.cyl(1.95,1.95,.28,8,yn(n,-.18),0,0,0,{ry:Math.PI/8}),e.cyl(1.88,1.88,.05,8,s,0,.28,0,{ry:Math.PI/8,glow:!0});const r=1.25;for(const[x,m]of[[r,r],[-r,r],[r,-r],[-r,-r]]){const p=.55+Math.min(.5,i*.04);e.box(.85,p,.85,n,x,.33,m),e.box(.87,.07,.87,s,x,.33+p,m),e.box(.6,.09,.02,fs,x,.33+p*.55,m+.43,{glow:!0}),e.box(.02,.09,.6,fs,x+.43*Math.sign(x),.33+p*.55,m,{glow:!0})}let o=.33,l=1.15;for(let x=0;x<a;x++){const m=.62-x*.04;e.cyl(l,l*1.04,m,12,x%2?yn(n,-.08):n,0,o,0),e.cyl(l*1.03,l*1.03,.06,12,s,0,o+m-.12,0,{glow:x===a-1});for(let p=0;p<8;p++){const y=p/8*Math.PI*2;e.box(.18,.12,.02,fs,Math.cos(y)*l*1.02,o+m*.45,Math.sin(y)*l*1.02,{ry:-y+Math.PI/2,glow:!0})}o+=m,l*=.84}e.sphere(l*1.05,la,0,o,0,{theta:Math.PI/2,w:14,h:6,glass:!0}),e.sphere(l*.45,s,0,o+.05,0,{glow:!0,w:8,h:5}),i>=5&&(e.cyl(.62,.62,.05,10,ni,1.35,.3,-1.35),e.cyl(.5,.5,.06,10,"#ffcc33",1.35,.3,-1.35),e.cyl(.42,.42,.07,10,ni,1.35,.3,-1.35)),i>=8&&(e.cyl(.05,.08,.6,6,An,-1.25,.95+Math.min(.5,i*.04),1.25),e.sphere(.32,An,-1.25,1.62+Math.min(.5,i*.04),1.25,{theta:Math.PI/2,rx:Math.PI*.75}));const c=e.build("command"),d=o+l*1.05,h=new Pt(new bn(.02,.035,.9,5),Ua.body);h.position.set(0,d+.45,0),h.geometry.setAttribute("color",new Ne(new Float32Array(h.geometry.attributes.position.count*3).fill(.8),3)),c.add(h);const u=je(new Oe(.07,8,6),"#ff4a4a");u.position.set(0,d+.92,0),c.add(u);const f=new Pt(new bn(.025,.025,1.5,5),new ln({color:An}));f.position.set(-1.7,1.03,-1.7),f.castShadow=!0,c.add(f);const g=Wo(t);return g.position.set(-1.68,1.55,-1.7),c.add(g),{group:c,height:d+1,anim:x=>{u.material.color.set(Math.sin(x*3)>0?"#ff4a4a":"#3a0a0a"),g.userData.wave(x)}}}function $b(i,t){const e=new Ce,n=t.primary,s=t.accent,a=Math.min(4,1+Math.floor((i-1)/3));e.cyl(1.9,1.95,.3,6,yn(n,-.2),0,0,0,{ry:Math.PI/6}),e.cyl(1.82,1.82,.05,6,s,0,.3,0,{ry:Math.PI/6,glow:!0});for(let d=0;d<6;d++){const h=d/6*Math.PI*2;e.cyl(.42,.42,.55+Math.min(.4,i*.03),10,n,Math.cos(h)*1.25,.3,Math.sin(h)*1.25),e.sphere(.42,la,Math.cos(h)*1.25,.85+Math.min(.4,i*.03),Math.sin(h)*1.25,{theta:Math.PI/2,w:10,h:5,glass:!0})}let r=.3;for(let d=0;d<a;d++)e.cyl(.95-d*.12,1-d*.12,.5,14,d%2?yn(n,-.1):n,0,r,0),e.cyl(.98-d*.12,.98-d*.12,.06,14,s,0,r+.42,0,{glow:d===a-1}),r+=.5;e.sphere(.62,la,0,r,0,{theta:Math.PI/2,w:14,h:6,glass:!0}),e.sphere(.25,s,0,r+.05,0,{glow:!0,w:8,h:5});const o=e.build("hub"),l=new Pt(new bn(.025,.025,1.4,5),new ln({color:An}));l.position.set(-1.6,1,-1.2),o.add(l);const c=Wo(t);return c.position.set(-1.58,1.5,-1.2),o.add(c),{group:o,height:r+.9,anim:d=>c.userData.wave(d)}}function Hb(i,t,e){const n=new Ce,s=e.primary,a=(kt[t]||kt.solar).color,r=(kt[t]||kt.solar).glow;n.cyl(1.42,1.48,.22,6,yn(s,-.12),0,0,0,{ry:Math.PI/6}),n.cyl(1.36,1.36,.04,6,ru(s,a,.35),0,.22,0,{ry:Math.PI/6}),n.cyl(.62,.62,.03,16,a,0,.26,0,{glow:!0}),n.cyl(.5,.5,.035,16,yn(a,-.5),0,.26,0);const o=i>=4?6:3,l=.7+Math.min(.8,i*.07);for(let u=0;u<o;u++){const f=u/o*Math.PI*2+Math.PI/6,g=Math.cos(f)*1.18,x=Math.sin(f)*1.18;n.box(.16,l,.16,s,g,.26,x,{ry:-f}),n.box(.2,.08,.2,lu(e),g,.26+l,x,{ry:-f}),n.box(.06,l*.6,.02,a,g*.99,.26+l*.25,x*.99,{ry:-f+Math.PI/2,glow:!0})}i>=4&&n.add(new tn(1.18,.05,6,24),lu(e),0,.26+l+.06,0,{rx:Math.PI/2}),i>=7&&n.sphere(1.25,ru(r,"#ffffff",.4),0,.26,0,{theta:Math.PI/2,w:18,h:8,glass:!0});const c=2+Math.floor((i-1)/3);for(let u=0;u<c;u++){const f=u/c*Math.PI*2+.4;n.cyl(.17,.17,.03,8,yn(a,.2),Math.cos(f)*.86,.26,Math.sin(f)*.86,{glow:!0})}const d=n.build("bay"),h=je(new fi(.18,0),r);return h.position.y=.26+l+.45,h.material.transparent=!0,h.material.opacity=.85,d.add(h),{group:d,height:.26+l+.7,anim:u=>{h.rotation.y=u*1.4,h.position.y=.26+l+.45+Math.sin(u*2)*.06}}}const lu=i=>i.accent;function Gb(i,t){const e=new Ce,n=t.primary,s=t.accent,a="#9dff5a";e.box(2.7,.18,2.7,yn(n,-.2),0,0,0),e.box(1.7,1+Math.min(.4,i*.04),1.5,n,-.35,.18,-.4),e.box(1.74,.1,1.54,s,-.35,1.18+Math.min(.4,i*.04),-.4),e.box(1,.12,.02,fs,-.35,.75,.36,{glow:!0}),e.box(.4,.55,.03,ni,.25,.18,.36);const r=1+Math.min(3,Math.floor(i/3));for(let f=0;f<r;f++)e.cyl(.13,.16,.7+f*.1,8,An,-.9+f*.38,1.28,-.85),e.cyl(.15,.15,.06,8,s,-.9+f*.38,1.9+f*.1,-.85);e.box(2.2,.12,.4,ni,0,.18,.95);for(let f=0;f<5;f++)e.box(.18,.18,.22,a,-.8+f*.4,.3,.95,{glow:!0});const o=e.build("fab"),l=new Ce;l.cyl(.42,.42,1.25,14,la,0,0,0,{glass:!0}),l.cyl(.46,.46,.08,14,s,0,1.25,0),l.cyl(.46,.46,.1,14,An,0,-.02,0);const c=l.build("tank");c.position.set(.85,.18,-.55),o.add(c);const d=je(new bn(.36,.36,1,14),a);d.geometry.translate(0,.5,0),d.position.set(.85,.22,-.55),o.add(d);const h=new Te,u=new Ce;return u.box(.1,.6,.1,"#ffb23e",0,0,0),u.box(.5,.08,.08,"#ffb23e",.22,.56,0),u.box(.08,.18,.08,ni,.45,.4,0),h.add(u.build()),h.position.set(.95,.3,.6),o.add(h),{group:o,height:2.1,anim:(f,g)=>{const x=g.ready?1:g.working?.15+.7*(f*.08%1):.08;d.scale.y=uo.lerp(d.scale.y||.1,x*1.2,.08),h.rotation.y=g.working?Math.sin(f*2.4)*.9:0,d.material.color.set(g.ready&&Math.sin(f*5)>0?"#c8ff7a":a)}}}function Vb(i,t){const e=new Ce,n=t.primary,s=t.accent,a=Math.min(3,1+Math.floor((i-1)/3));e.box(2.8,.2,2.8,yn(n,-.2),0,0,0),e.box(2.6,.05,.4,"#ffcc33",0,.2,1.05),e.box(2,.6,.7,n,0,.2,-.95),e.box(2.04,.06,.74,s,0,.8,-.95),e.box(1.4,.1,.02,fs,0,.55,-.59,{glow:!0});const r=[-.85,0,.85];for(let h=0;h<3;h++){const u=h<a;e.cyl(.36,.4,.14,12,u?An:ni,r[h],.2,.15),u&&(e.cyl(.32,.32,.9,12,la,r[h],.34,.15,{glass:!0}),e.cyl(.36,.36,.08,12,s,r[h],1.24,.15))}const o=e.build("assembly"),l=new Te,c=new Ce;c.box(.08,1.5,.08,"#ffb23e",-1.3,0,-.3),c.box(2.7,.08,.08,"#ffb23e",0,1.5,-.3),c.box(.12,.3,.12,ni,0,1.22,-.3),l.add(c.build()),l.position.y=.2,o.add(l);const d=[];for(let h=0;h<3;h++){const u=je(new Hn(.17,1),"#ffffff");u.position.set(r[h],.8,.15),u.visible=!1,o.add(u),d.push(u)}return{group:o,height:1.8,anim:(h,u)=>{const f=u.cores||[];d.forEach((g,x)=>{const m=f[x];if(g.visible=!!m&&x<a,!m)return;g.material.color.set(m.color),g.rotation.y=h*(m.ready?3:1.2),g.rotation.x=h*.7;const p=m.ready?1+Math.sin(h*6)*.15:.85+Math.sin(h*2+x)*.08;g.scale.setScalar(p),g.position.y=.8+Math.sin(h*1.5+x)*.05}),l.position.x=f.some(g=>!g.ready)?Math.sin(h*.9)*.8:l.position.x*.95}}}function Wb(i,t){const e=new Ce,n=t.primary,s=t.accent;e.box(3.8,.22,2.8,yn(n,-.2),0,0,0),e.box(3.6,.04,.3,s,0,.22,1.15,{glow:!0});for(const h of[-1.25,1.25])e.cyl(.62,.7,.35,12,n,h,.22,0),e.cyl(.66,.66,.06,12,s,h,.57,0),e.sphere(.58,la,h,.62,0,{theta:Math.PI/2,w:16,h:7,glass:!0}),e.cyl(.4,.4,.03,14,"#b06dff",h,.6,0,{glow:!0});e.cyl(.22,.3,1+Math.min(.4,i*.04),10,An,0,.22,0),e.box(2,.12,.18,ni,0,.62,0),e.box(.7,.5,.6,n,0,.22,-.95),e.box(.5,.08,.02,fs,0,.5,-.64,{glow:!0});const a=e.build("fusion"),r=1.25+Math.min(.4,i*.04),o=new Te,l=new Ce;l.add(new tn(.55,.07,8,32),s),l.add(new tn(.42,.03,6,28),"#b06dff",0,0,0,{glow:!0}),o.add(l.build()),o.position.y=r,a.add(o);const c=je(new Hn(.16,1),"#e2c8ff");c.position.y=r,a.add(c);const d=je(new bn(.035,.035,2.5,6),"#d6b8ff");return d.rotation.z=Math.PI/2,d.position.y=.95,d.visible=!1,a.add(d),{group:a,height:r+.6,anim:(h,u)=>{o.rotation.x=Math.PI/2+Math.sin(h*.5)*.2,o.rotation.z=h*(u.working?4:.4),c.scale.setScalar(u.working?1+Math.sin(h*9)*.25:.7),d.visible=!!u.working,d.scale.x=1+Math.sin(h*20)*.3,c.material.color.set(u.ready?"#fff2a8":"#e2c8ff")}}}function Xb(i,t){const e=new Ce,n=t.primary,s=t.accent;e.cyl(1.9,2,.25,24,yn(n,-.2),0,0,0),e.cyl(1.7,1.7,.04,32,"#2a3446",0,.25,0),e.add(new tn(1.7,.05,6,48),s,0,.29,0,{rx:Math.PI/2,glow:!0});for(const[d,h]of[[-.8,"#4aa8ff"],[.8,"#ff5a6a"]])e.cyl(.42,.42,.03,18,h,d,.29,0,{glow:!0});const a=6+Math.min(6,i);for(let d=0;d<a;d++){const h=d/a*Math.PI*2;e.box(.14,.9+d%2*.3,.14,n,Math.cos(h)*1.75,.25,Math.sin(h)*1.75),e.box(.17,.08,.17,s,Math.cos(h)*1.75,1.15+d%2*.3,Math.sin(h)*1.75,{glow:!0})}const r=e.build("arena"),o=new Pt(new tn(1.25,.04,6,48),new Me({color:"#7af7ff",toneMapped:!1,transparent:!0,opacity:.85}));o.position.y=1.5,o.rotation.x=Math.PI/2,r.add(o);const l=Wo(t,.55,.34);l.position.set(.02,2,0);const c=new Pt(new bn(.02,.02,1,5),new ln({color:An}));return c.position.set(0,1.7,0),r.add(c,l),{group:r,height:2.3,anim:d=>{o.rotation.z=d*.8,o.position.y=1.4+Math.sin(d*1.5)*.1,l.userData.wave(d)}}}function ep(i){const t=new Ce,e=1.3+i*.35,n=.2+i*.03;if(t.cyl(n,n,e,12,"#f2f4f7",0,.2),t.add(new $n(n,.5+i*.08,12),"#ff7a3c",0,.2+e+.25+i*.04,0),t.cyl(n*1.02,n*1.02,.08,12,"#2c3340",0,.2+e*.6),i>=3)for(const s of[-1,1])t.cyl(n*.45,n*.45,e*.6,10,"#e6e9ee",s*n*1.5,.2),t.add(new $n(n*.45,.25,10),"#ff7a3c",s*n*1.5,.2+e*.6+.12,0);for(let s=0;s<4;s++){const a=s/4*Math.PI*2;t.box(.04,.35,.22,"#ff7a3c",Math.cos(a)*n,.2,Math.sin(a)*n,{ry:-a})}return t.cyl(n*.7,n*.9,.2,10,"#3a4250",0,0),{group:t.build("rocket"),height:.2+e+.7}}function qb(i,t,e){const n=new Ce,s=t.primary,a=t.accent,r=i>=9?4:i>=6?3:i>=3?2:1;n.box(2.8,.25,2.8,yn(s,-.25),0,0,0),n.cyl(.95,.95,.06,20,"#2c3340",0,.25,0),n.cyl(.8,.8,.065,20,"#ffcc33",0,.25,0),n.cyl(.66,.66,.07,20,"#2c3340",0,.25,0);const o=2.2+r*.4;n.box(.3,o,.3,s,-1.05,.25,-1);for(let d=.6;d<o;d+=.5)n.box(.62,.05,.05,a,-.78,.25+d,-1);n.box(.36,.1,.36,a,-1.05,.25+o,-1,{glow:!0}),n.box(.7,.4,.5,s,1,.25,1),n.box(.5,.08,.02,fs,1,.45,1.26,{glow:!0});const l=n.build("pad");let c=null;return e&&(c=ep(r).group,c.position.y=.3,l.add(c)),{group:l,height:.3+(e?2.2+r*.5:1.5)}}function Yb(i,t){const e=new Ce;e.cyl(.95,1,.18,10,"#3a2f4a"),e.cyl(.7,.7,.05,12,"#120a1c",0,.18);for(let r=0;r<6;r++){const o=r/6*Math.PI*2;e.add(new fi(.12,0),"#c48bff",Math.cos(o)*.45,.25,Math.sin(o)*.45,{sy:2,glass:!0})}for(const[r,o]of[[-.7,-.7],[.7,-.7],[0,.75]])e.box(.08,1.3,.08,"#c8d0da",r,.18,o);e.box(1.5,.08,.08,t.accent,0,1.45,-.7),e.box(.3,.3,.3,t.primary,0,1.2,0);const n=e.build("mine"),s=new Pt(new $n(.12,.6,8),new ln({color:"#e6b84a",metalness:.6,roughness:.3}));s.rotation.x=Math.PI,s.position.y=.75,n.add(s);const a=je(new zo(.55,20),"#b06dff");return a.rotation.x=-Math.PI/2,a.position.y=.24,a.material.transparent=!0,a.material.opacity=.6,n.add(a),{group:n,height:1.7,anim:(r,o)=>{s.rotation.y=o.working?r*12:0,s.position.y=o.working?.55+Math.sin(r*3)*.15:.75,a.material.opacity=o.ready?.6+Math.sin(r*5)*.3:.35}}}function Kb(i){const t=new Ce;t.cyl(1.3,1.45,.3,8,"#2a2236",0,0,0,{ry:Math.PI/8}),t.cyl(.9,1,.5,8,"#3a2f4a",0,.3,0,{ry:Math.PI/8}),t.cyl(.6,.6,.05,16,"#b06dff",0,.8,0,{glow:!0});for(let a=0;a<4;a++){const r=a/4*Math.PI*2+Math.PI/4;t.box(.22,1.4,.22,"#4a3d5e",Math.cos(r)*1.15,.3,Math.sin(r)*1.15),t.add(new fi(.1,0),"#e6c8ff",Math.cos(r)*1.15,1.85,Math.sin(r)*1.15,{glow:!0})}const e=t.build("forge"),n=je(new fi(.28,0),"#d6b8ff");n.position.y=1.5,e.add(n);const s=new Te;for(let a=0;a<3;a++){const r=je(new tn(.45+a*.12,.012,4,32),"#b06dff");r.rotation.x=a*1.1,s.add(r)}return s.position.y=1.5,e.add(s),{group:e,height:2.2,anim:a=>{n.rotation.y=a*1.5,n.position.y=1.5+Math.sin(a*1.4)*.08,s.children.forEach((r,o)=>{r.rotation.y=a*(.6+o*.4),r.rotation.z=a*.3*(o+1)})}}}function Zb(i,t){const e=kt[t]||kt.aurora,n=new Ce;n.cyl(1.45,1.5,.22,12,"#2a2236"),n.cyl(1.2,1.2,.04,24,"#3a2f4a",0,.22,0);const s=6+Math.min(4,Math.floor(i/3));for(let o=0;o<s;o++){const l=o/s*Math.PI*2,c=.9+o%2*.35;n.box(.22,c,.22,"#4a3d5e",Math.cos(l)*1.2,.22,Math.sin(l)*1.2,{ry:-l}),n.box(.05,c*.6,.02,e.color,Math.cos(l)*1.08,.22+c*.2,Math.sin(l)*1.08,{ry:-l+Math.PI/2,glow:!0})}n.cyl(.7,.7,.04,24,e.color,0,.26,0,{glow:!0});const a=n.build("relicbay"),r=je(new tn(.4,.03,4,6),e.glow);return r.position.y=1.4,a.add(r),{group:a,height:1.9,anim:o=>{r.rotation.y=o,r.rotation.x=Math.sin(o*.7)*.6}}}function Jb(i,t){const e=new Ce;switch(i){case"tree":{e.cyl(.05,.08,.45,6,"#7a5232"),e.add(new Hn(.32,0),"#47c95a",0,.68,0),e.add(new Hn(.22,0),"#6ee36f",.12,.88,.05);for(const[n,s,a]of[[.2,.62,.15],[-.18,.75,.12],[.05,.6,-.25]])e.sphere(.045,"#aaffee",n,s,a,{glow:!0,w:6,h:4});return{group:e.build("tree"),height:1.1}}case"rock":{const n=new ra(.32,0),s=n.attributes.position;for(let a=0;a<s.count;a++)s.setY(a,s.getY(a)*.7);return e.add(n,"#8a8f99",0,.18,0,{ry:.7}),e.add(new ra(.14,0),"#6c717b",.28,.08,.12),{group:e.build("rock"),height:.5}}case"path":return e.box(.98,.04,.98,"#cfd6df"),e.box(.86,.045,.86,"#e7ecf2"),{group:e.build("path"),height:.1};case"lamp":{e.cyl(.08,.1,.1,6,ni),e.cyl(.03,.03,.95,6,An,0,.1),e.box(.24,.04,.06,An,.1,1.02,0);const n=e.build("lamp"),s=je(new Oe(.07,8,6),"#ffe7a0");s.position.set(.2,.98,0),n.add(s);const a=new $f("#ffd890",1.2,3.2,2);return a.position.set(.2,.92,0),n.add(a),{group:n,height:1.2}}case"flag":{e.cyl(.07,.09,.08,6,ni);const n=e.build("flag"),s=new Pt(new bn(.02,.02,1.4,5),new ln({color:An}));s.position.y=.75,n.add(s);const a=Wo(t,.6,.38);return a.position.set(.02,1.25,0),n.add(a),{group:n,height:1.5,anim:r=>a.userData.wave(r)}}case"crystal":{for(const[a,r,o,l]of[[0,0,.7,.13],[.16,.08,.45,.09],[-.14,.1,.5,.1],[.05,-.16,.38,.08]])e.add(new fi(l,0),"#c48bff",a,o/2,r,{sy:o/l/2,glass:!0});e.cyl(.25,.3,.06,7,"#5d5468");const n=e.build("crystal"),s=je(new fi(.06,0),"#f0d8ff");return s.position.y=.3,n.add(s),{group:n,height:.8}}case"fountain":{e.cyl(.85,.9,.22,16,"#d9dee5"),e.cyl(.72,.72,.03,16,"#2f8cff",0,.2,0,{glass:!0}),e.cyl(.12,.16,.55,8,"#c8d0da",0,.2),e.cyl(.3,.3,.05,12,"#c8d0da",0,.75);const n=e.build("fountain"),s=new Te;for(let a=0;a<6;a++){const r=je(new tn(.28,.02,4,12,Math.PI),"#9fd8ff");r.rotation.y=a/6*Math.PI*2,r.position.y=.78,r.rotation.z=0,s.add(r)}return s.children.forEach(a=>{a.geometry.translate(.28,0,0)}),n.add(s),{group:n,height:1.2,anim:a=>{s.rotation.y=a*.6,s.scale.y=1+Math.sin(a*3)*.08}}}case"dish":{e.box(.9,.2,.9,"#9aa4b1"),e.cyl(.1,.14,.6,8,An,0,.2),e.sphere(.65,"#e9eef5",0,1.05,0,{theta:Math.PI/2.6,rx:Math.PI*.8,w:16,h:6}),e.cyl(.02,.02,.5,4,ni,.12,.95,.1,{rx:-.6});const n=e.build("dish"),s=je(new Oe(.05,6,4),"#7af7ff");return s.position.set(.22,1.32,.3),n.add(s),{group:n,height:1.6}}case"monolith":{e.box(.5,1.8,.2,"#0c0a12");for(let n=0;n<5;n++)e.box(.36,.03,.01,"#b06dff",0,.3+n*.3,.105,{glow:!0});return{group:e.build("monolith"),height:2}}case"arch":{for(const a of[-.75,.75])e.cyl(.12,.16,.12,8,"#c8d0da",a,0),e.cyl(.07,.07,.6,8,"#e9eef5",a,.12);e.add(new tn(.75,.07,8,28,Math.PI),"#e6b84a",0,.72,0),e.add(new tn(.62,.025,6,28,Math.PI),"#fff4c2",0,.72,0,{glow:!0});const n=e.build("arch"),s=new Te;for(let a=0;a<7;a++){const r=je(new fi(.04,0),"#fff4c2"),o=a/6*Math.PI;r.position.set(Math.cos(o)*.75,.72+Math.sin(o)*.75,0),s.add(r)}return n.add(s),{group:n,height:1.6,anim:a=>s.children.forEach((r,o)=>{r.scale.setScalar(.6+.6*Math.abs(Math.sin(a*2+o))),r.rotation.y=a*3})}}case"statue":return e.box(1.2,.3,1.2,"#d9dee5"),e.box(1,.5,1,"#c3cad4",0,.3),e.sphere(.38,"#e6b84a",0,1.22,0,{w:14,h:10}),e.add(new tn(.52,.05,6,24),"#e6b84a",0,1.22,0,{rx:1.2}),e.sphere(.1,"#fff4c2",0,1.26,.33,{glow:!0}),{group:e.build("statue"),height:1.8}}return e.box(.8,.4,.8,"#ff00ff"),{group:e.build("?"),height:.5}}function Fc(i,t,e,n){const s=Math.max(1,t);return i==="command"?zb(s,n):i==="hub"?$b(s,n):i==="bay"?Hb(s,e||"solar",n):i==="fab"?Gb(s,n):i==="assembly"?Vb(s,n):i==="fusion"?Wb(s,n):i==="arena"?Xb(s,n):i==="mine"?Yb(s,n):i==="forge"?Kb():i==="relicbay"?Zb(s,e||"aurora"):i==="pad"?qb(s,n,!n.noRocket):Jb(i,n)}function jb(){const i=new Ce;i.cyl(.32,.42,.7,8,"#e9eef5",0,.1),i.cyl(.43,.43,.08,8,"#ff7a3c",0,.3),i.add(new $n(.32,.4,8),"#e9eef5",0,1,0),i.box(.3,.2,.02,"#2c3340",0,.42,.37);for(let s=0;s<4;s++){const a=s/4*Math.PI*2+Math.PI/4;i.box(.05,.35,.22,"#ff7a3c",Math.cos(a)*.38,0,Math.sin(a)*.38,{ry:-a})}const t=i.build("pod"),e=je(new $n(.2,.7,8),"#ffd27a");e.rotation.x=Math.PI,e.position.y=-.3,t.add(e);const n=je(new Oe(.06,8,6),"#7cf29a");return n.position.y=1.22,t.add(n),t.userData.flame=e,t.userData.beacon=n,t}function Qb(i,t,e){const n=new Te,s=new ln({color:"#f2b233",roughness:.6,metalness:.3}),a=new bn(.035,.035,e,5),r=new bn(.025,.025,1,4),o=[-i/2+.1,i/2-.1],l=[-t/2+.1,t/2-.1];for(const d of o)for(const h of l){const u=new Pt(a,s);u.position.set(d,e/2,h),u.castShadow=!0,n.add(u)}for(let d=.4;d<e;d+=.6){for(const h of l){const u=new Pt(r,s);u.scale.y=i-.2,u.rotation.z=Math.PI/2,u.position.set(0,d,h),n.add(u)}for(const h of o){const u=new Pt(r,s);u.scale.y=t-.2,u.rotation.x=Math.PI/2,u.position.set(h,d,0),n.add(u)}}const c=new Pt(new ai(.08,.08,Math.max(i,t)*.9),s);return c.position.set(0,e+.1,0),c.name="crane",n.add(c),n}const Fn=(i=Date.now())=>{const t=new Date(i);return`${t.getFullYear()}-${String(t.getMonth()+1).padStart(2,"0")}-${String(t.getDate()).padStart(2,"0")}`},t_=(i=Date.now())=>Fn(i-864e5);function me(i){const t=i;return t.daily||(t.daily={day:0,cycle:0,last:"",streak:0,best:0,total:0,mDate:"",missions:[],mBase:{},mClaimed:[],bonus:!1,drop:Date.now()+8*6e4,drops:0,dropAt:null,spin:"",adSpin:"",ach:{}}),t.daily}const gs=i=>1+i.lvl*.6,bd={2:{dm:10,label:"Dark Matter"},6:{core:"advanced",label:"Advanced core"},9:{dm:20,label:"Dark Matter"},13:{core:"elite",label:"Elite core"},16:{dm:30,label:"Dark Matter"},20:{decor:"arch",label:"Starlight Arch"},23:{dm:40,label:"Dark Matter"},27:{core:"epic",label:"Epic core"}};function _d(i,t,e=me(i).cycle){const n=gs(i)*(1+t*.07)*(1+e*.5),s=bd[t],a=t%2?{cells:Yt(60*n)}:{credits:Yt(250*n)};s&&s.dm&&(a.dm=s.dm+e*10);const r=s&&s.core?We[Math.min(We.length-1,We.indexOf(s.core)+e)]:void 0;return{res:a,core:r,decor:s&&s.decor,label:s?s.label:""}}const Xo=(i,t=Date.now())=>me(i).last!==Fn(t);function np(i,t,e){let n=Qn.filter(r=>tt[r].rarity===t);if(t==="standard"&&!zt(i,"assembly").some(r=>r.lvl>0)){const r=n.filter(o=>bs(i,o));r.length&&(n=r)}const s=n.filter(r=>!i.dex[r]),a=s.length&&Tn(e)()<.75?s:n;return a[Math.floor(Tn(e+7)()*a.length)]}function ns(i,t,e,n=Date.now()){const s=np(i,t,e),a=zt(i,"assembly")[0];if(a&&a.lvl>0)return Eo(i,s,"gift",n),{sp:s,core:!0};const r=t==="standard"?bs(i,s):null;return r?(i.bots.push({id:Ye("b"),sp:s,lvl:1,fed:0,bay:r.id,born:n}),Hc(i,s,n),on.push({kind:"newBot",bot:i.bots[i.bots.length-1].id}),{sp:s,core:!1}):(i.cores.push({id:Ye("c"),sp:s,from:"gift",state:"waiting",at:n}),{sp:s,core:!0})}function Md(i,t,e=Date.now()){const n=zt(i,"assembly")[0];return n&&n.lvl>0?Eo(i,t,"gift",e):i.cores.push({id:Ye("c"),sp:t,from:"gift",state:"waiting",at:e}),{sp:t,core:!0}}function ip(i,t=Date.now()){const e=me(i);if(!Xo(i,t))return null;const n=_d(i,e.day);Cn(i,n.res);let s=null;n.core&&(s=ns(i,n.core,js(Fn(t))+e.total,t)),n.decor&&(i.stats["decor_"+n.decor]=(i.stats["decor_"+n.decor]||0)+1),e.streak=e.last===t_(t)?e.streak+1:1,e.best=Math.max(e.best,e.streak),e.total++,e.last=Fn(t);const a=e.day;return e.day++,e.day>=28&&(e.day=0,e.cycle++),ce(i,20+a*2),{...n,day:a,gift:s}}const e_=[{id:"collect",kind:"collects",n:()=>8,text:i=>`Collect credits from your bays ${i} times`},{id:"credits",kind:"collected",n:i=>Yt(1500*gs(i)),text:i=>`Collect ${i.toLocaleString()} credits`},{id:"harvest",kind:"harvests",n:()=>3,text:i=>`Harvest ${i} Fabricator recipes`},{id:"feed",kind:"feeds",n:()=>12,text:i=>`Feed your bots ${i} times`},{id:"craft",kind:"crafts",n:()=>4,text:i=>`Start ${i} Fabricator recipes`},{id:"upgrade",kind:"upgrades",n:()=>2,text:i=>`Start ${i} upgrades`},{id:"recruit",kind:"recruits",n:()=>1,text:()=>"Recruit a bot from the shop"},{id:"decor",kind:"decor",n:()=>2,text:i=>`Place ${i} decorations`},{id:"fuse",kind:"fusions",n:()=>1,text:()=>"Fuse two bots",need:i=>zt(i,"fusion").some(t=>t.lvl>0)},{id:"boot",kind:"boots",n:()=>1,text:()=>"Activate a core in the Assembly Bay",need:i=>zt(i,"assembly").some(t=>t.lvl>0)},{id:"drop",kind:"drops",n:()=>1,text:()=>"Open a supply drop"},{id:"launch",kind:"launches",n:()=>1,text:()=>"Launch an expedition",need:i=>zt(i,"pad").some(t=>t.lvl>0)},{id:"arena",kind:"arenaWins",n:()=>2,text:i=>`Win ${i} Arena battles`,need:i=>zt(i,"arena").some(t=>t.lvl>0)}],n_=(i,t)=>t===0?{credits:Yt(500*gs(i))}:t===1?{cells:Yt(150*gs(i))}:{dm:5};function Xa(i,t=Date.now()){const e=me(i),n=Fn(t);if(e.mDate===n)return!1;const s=Tn(js(n)^i.created>>>0),a=e_.filter(o=>!o.need||o.need(i)),r=[];for(;r.length<3&&a.length;)r.push(a.splice(Math.floor(s()*a.length),1)[0]);return e.missions=r.map((o,l)=>{const c=o.n(i);return{id:o.id,kind:o.kind,n:c,text:o.text(c),reward:n_(i,l)}}),e.mBase={...i.stats},e.mClaimed=[!1,!1,!1],e.bonus=!1,e.mDate=n,!0}const qo=(i,t)=>Math.max(0,(i.stats[t.kind]||0)-(me(i).mBase[t.kind]||0));function sp(i,t){const e=me(i),n=e.missions[t];return!n||e.mClaimed[t]||qo(i,n)<n.n?null:(e.mClaimed[t]=!0,Cn(i,n.reward),ce(i,15),n)}const Zs=i=>{const t=me(i);return t.missions.length===3&&t.mClaimed.every(Boolean)&&!t.bonus};function ap(i,t=Date.now()){const e=me(i);if(!Zs(i))return null;e.bonus=!0;const n={dm:10,cells:Yt(250*gs(i))};Cn(i,n);const s=Tn(js(e.mDate)+3)(),a=s<.35?ns(i,s<.06?"elite":"advanced",js(e.mDate)+11,t):null;return ce(i,30),{res:n,gift:a}}const qa=4*36e5,bo=2;function Oc(i,t=Date.now()){const e=me(i);for(;e.drops<bo&&t>=e.drop;)e.drops++,e.drop+=qa;e.drops>=bo&&e.drop<t&&(e.drop=t+qa)}function rp(i,t=Date.now()){const e=me(i);if(e.drops<=0)return null;e.drops--,e.drops===bo-1&&e.drop-t>qa&&(e.drop=t+qa);const n=Tn(t/1e3>>>0),s={credits:Yt(350*gs(i)*(.7+n()*.8)),cells:Yt(90*gs(i)*(.7+n()*.8))};n()<.35&&(s.dm=2+Math.floor(n()*5)),Cn(i,s);const a=n(),r=a<.12?ns(i,a<.025?"elite":a<.12&&ji(i)>=3?"advanced":"standard",t/1e3>>>0,t):null;return i.stats.drops=(i.stats.drops||0)+1,ce(i,10),{res:s,gift:r}}const Yo=(i,t=Date.now())=>me(i).spin!==Fn(t);function Bc(i,t=!1,e=Date.now()){const n=me(i);if(!t&&!Yo(i,e)||t&&n.adSpin===Fn(e))return null;const s=Tn(js(Fn(e)+(t?"ad":""))^i.created>>>0),a=s(),r=a<.04?"elite":a<.3?"advanced":"standard";t?n.adSpin=Fn(e):n.spin=Fn(e);const o=ns(i,r,s()*1e9>>>0,e);return ce(i,10),{rarity:r,...o}}const Ko=[{id:"collector",name:"Credit Collector",tiers:[1e4,2e5,5e6,1e8],stat:i=>i.stats.collected||0,unit:"credits collected"},{id:"crew",name:"Crew Chief",tiers:[5,12,25,50],stat:i=>i.bots.length,unit:"bots"},{id:"dex",name:"Botanist of Bots",tiers:[10,25,50,82],stat:i=>Gc(i),unit:"species discovered"},{id:"fuser",name:"Fusion Pioneer",tiers:[1,10,50,250],stat:i=>i.stats.fusions||0,unit:"fusions"},{id:"feeder",name:"Snack Time",tiers:[50,500,5e3,5e4],stat:i=>i.stats.feeds||0,unit:"feedings"},{id:"farmer",name:"Power Farmer",tiers:[10,100,1e3,5e3],stat:i=>i.stats.harvests||0,unit:"harvests"},{id:"builder",name:"Master Builder",tiers:[3,6,10,15],stat:i=>ji(i),unit:"Command Center level"},{id:"loyal",name:"Loyal Commander",tiers:[3,7,28,100],stat:i=>me(i).total,unit:"days logged in"},{id:"streak",name:"On a Roll",tiers:[3,7,14,30],stat:i=>me(i).best,unit:"day streak"},{id:"land",name:"Land Baron",tiers:[1,4,8,16],stat:i=>i.landBought,unit:"plots bought"},{id:"decorator",name:"Interior Designer",tiers:[5,25,75,200],stat:i=>i.stats.decor||0,unit:"decorations"},{id:"veteran",name:"Veteran",tiers:[5,15,30,60],stat:i=>i.lvl,unit:"Commander level"},{id:"champion",name:"Arena Champion",tiers:[5,50,250,1e3],stat:i=>i.stats.arenaWins||0,unit:"Arena wins"},{id:"defender",name:"Defender of the Colony",tiers:[1,10,50,200],stat:i=>i.stats.raidsWon||0,unit:"raids repelled"},{id:"explorer",name:"Explorer",tiers:[3,25,150,600],stat:i=>i.stats.expeditions||0,unit:"expeditions"},{id:"hoarder",name:"Supply Hoarder",tiers:[5,30,150,600],stat:i=>i.stats.drops||0,unit:"supply drops"}],_o=[5,15,40,100],Zo=(i,t)=>me(i).ach[t.id]||0,Ya=(i,t)=>{const e=Zo(i,t);return e<t.tiers.length&&t.stat(i)>=t.tiers[e]};function op(i,t){const e=Ko.find(s=>s.id===t);if(!e||!Ya(i,e))return null;const n=Zo(i,e);return me(i).ach[t]=n+1,i.res.dm+=_o[n],ce(i,25*(n+1)),{a:e,tier:n,dm:_o[n]}}function jr(i,t=Date.now()){const e=me(i);return{day:Xo(i,t),missions:e.missions.some((n,s)=>!e.mClaimed[s]&&qo(i,n)>=n.n)||Zs(i),ach:Ko.some(n=>Ya(i,n)),spin:Yo(i,t),drop:e.drops>0}}const i_=Object.freeze(Object.defineProperty({__proto__:null,ACHS:Ko,ACH_DM:_o,DROP_EVERY:qa,DROP_MAX:bo,SPECIAL:bd,achReady:Ya,achTier:Zo,attention:jr,bonusReady:Zs,canClaimDay:Xo,canSpin:Yo,claimAch:op,claimBonus:ap,claimDay:ip,claimMission:sp,daily:me,dateKey:Fn,dayReward:_d,giftSpecies:np,giveCore:ns,giveSpecies:Md,mProgress:qo,openDrop:rp,refreshMissions:Xa,spin:Bc,tickDrops:Oc},Symbol.toStringTag,{value:"Module"})),Kn="#2c3340",Or="#cdd5df";function Sd(i,t=1){const e=tt[i],n=kt[e.el[0]].color,s=e.el[1]?kt[e.el[1]].color:yn(n,-.35),a=qt[e.rarity].color,r=new Te,o=new Ce;let l=0;const c=x=>(r.add(x),x),d=x=>{const m=new Ce;return x(m),m.build()};let h=()=>{};switch(e.chassis){case"orb":{l=.55,o.sphere(.26,n,0,0,0,{w:14,h:10}),o.sphere(.27,s,0,0,0,{w:14,h:4,theta:Math.PI*.18}),o.sphere(.09,a,0,.02,.22,{glow:!0,w:8,h:6}),o.sphere(.05,"#ffffff",.02,.05,.27,{glow:!0,w:6,h:4});const x=c(d(m=>m.add(new tn(.38,.025,5,28),s)));x.rotation.x=Math.PI/2.4,h=m=>{x.rotation.z=m*1.8};break}case"drone":{l=.6,o.box(.34,.14,.34,n,0,-.07,0),o.sphere(.16,s,0,.05,0,{theta:Math.PI/2,w:10,h:5}),o.box(.12,.05,.02,a,0,-.01,.18,{glow:!0});const x=[];for(const[m,p]of[[.28,.28],[-.28,.28],[.28,-.28],[-.28,-.28]]){o.box(.24,.03,.04,Kn,m/2,0,p/2,{ry:Math.atan2(m,p)});const y=c(d(A=>{A.cyl(.13,.13,.012,10,Or,0,0,0,{glass:!0}),A.box(.24,.01,.03,Kn)}));y.position.set(m,.02,p),x.push(y)}h=m=>x.forEach((p,y)=>{p.rotation.y=m*30*(y%2?1:-1)});break}case"rover":{o.box(.5,.18,.36,n,0,.12,0),o.box(.3,.1,.3,s,-.05,.3,0),o.cyl(.02,.02,.22,5,Or,.12,.3,0),o.box(.14,.08,.08,Kn,.12,.52,0),o.box(.02,.04,.06,a,.19,.53,0,{glow:!0});const x=[];for(const[m,p]of[[.17,.2],[-.17,.2],[.17,-.2],[-.17,-.2]]){const y=c(d(A=>A.cyl(.09,.09,.07,10,Kn,0,-.035,0,{rx:Math.PI/2})));y.position.set(m,.09,p),x.push(y)}i==="digger"&&o.add(new $n(.08,.22,7),Or,.32,.18,0,{rz:-Math.PI/2}),i==="ember"&&o.cyl(.035,.035,.2,5,Kn,.25,.28,0,{rz:-.9}),h=(m,p)=>x.forEach(y=>{y.rotation.z=p?-m*8:0});break}case"walker":{const x=c(d(p=>{p.box(.36,.22,.3,n,0,0,0),p.box(.3,.06,.26,s,0,.22,0),p.box(.14,.05,.02,a,.06,.12,.16,{glow:!0}),p.box(.06,.05,.02,a,-.08,.12,.16,{glow:!0})}));x.position.y=.34;const m=[];for(const p of[.11,-.11]){const y=c(d(A=>{A.box(.07,.32,.07,Kn,0,-.32,0),A.box(.13,.04,.16,s,0,-.34,.02)}));y.position.set(p,.36,0),m.push(y)}h=(p,y)=>{m.forEach((A,b)=>{A.rotation.x=y?Math.sin(p*9+b*Math.PI)*.5:0}),x.position.y=.34+(y?Math.abs(Math.sin(p*9))*.03:0)};break}case"android":{const x=c(d(p=>{p.box(.24,.3,.16,n,0,0,0),p.box(.26,.06,.18,s,0,.24,0),p.sphere(.12,Or,0,.42,0,{w:10,h:8}),p.box(.18,.05,.05,a,0,.43,.09,{glow:!0}),p.sphere(.035,a,0,.12,.085,{glow:!0,w:6,h:4})}));x.position.y=.3;const m=[];for(const[p,y,A,b]of[[.16,.56,.26,s],[-.16,.56,.26,s],[.07,.3,.3,Kn],[-.07,.3,.3,Kn]]){const w=c(d(E=>E.box(.07,A,.07,b,0,-A,0)));w.position.set(p,y,0),m.push(w)}i==="sprout"&&o.add(new Hn(.08,0),"#5fdc5a",0,.86,0),h=(p,y)=>{m.forEach((A,b)=>{A.rotation.x=y?Math.sin(p*8+b%2*Math.PI+(b>1?Math.PI:0))*.55:Math.sin(p*1.5+b)*.05})};break}case"mech":{const x=c(d(p=>{p.box(.46,.34,.34,n,0,0,0),p.box(.2,.12,.2,s,0,.34,0),p.box(.16,.05,.02,a,0,.4,.105,{glow:!0});for(const y of[.29,-.29])p.box(.14,.14,.2,s,y,.16,0),p.box(.11,.3,.11,Kn,y,-.14,.02)}));x.position.y=.36;const m=[];for(const p of[.13,-.13]){const y=c(d(A=>{A.box(.12,.34,.12,Kn,0,-.34,0),A.box(.18,.05,.22,s,0,-.36,.02)}));y.position.set(p,.38,0),m.push(y)}h=(p,y)=>{m.forEach((A,b)=>{A.rotation.x=y?Math.sin(p*5+b*Math.PI)*.35:0}),x.rotation.y=y?Math.sin(p*5)*.06:0};break}case"crawler":{const x=c(d(p=>{p.sphere(.16,n,.18,0,0,{w:10,h:7}),p.sphere(.13,s,0,0,0,{w:10,h:7}),p.sphere(.11,n,-.16,0,0,{w:10,h:7}),p.sphere(.035,a,.31,.04,.06,{glow:!0,w:6,h:4}),p.sphere(.035,a,.31,.04,-.06,{glow:!0,w:6,h:4})}));x.position.y=.2;const m=[];for(let p=0;p<6;p++){const y=.16-(p>>1)*.16,A=p%2?1:-1,b=c(d(w=>w.box(.03,.03,.24,Kn,0,0,.1*A)));b.position.set(y,.18,.08*A),b.rotation.x=.5*A,m.push(b)}h=(p,y)=>m.forEach((A,b)=>{A.rotation.y=y?Math.sin(p*14+b)*.35:0});break}}const u=o.build("bot");r.add(u),(e.chassis==="orb"||e.chassis==="drone")&&(u.position.y=0);const f=new Te;for(;r.children.length;)f.add(r.children[0]);if(f.position.y=l,r.add(f),l){const x=new Pt(new zo(.22,12),new Me({color:kt[e.el[0]].glow,transparent:!0,opacity:.35,depthWrite:!1}));x.rotation.x=-Math.PI/2,x.position.y=.02,x.name="hoverGlow",r.add(x)}const g=.95+We.indexOf(e.rarity)*.08+Math.min(.25,(t-1)*.008);return r.scale.setScalar(g),r.traverse(x=>{x.isMesh&&(x.castShadow=!0)}),{group:r,hover:l,anim:(x,m)=>{h(x,m),l&&(f.position.y=l+Math.sin(x*2.2+t)*.05)}}}const ts={strike:{name:"Strike",el:"none",power:.8,desc:"A plain, honest hit."},solar:{name:"Sunburst",el:"solar",power:1,fx:"drain",desc:"Heals for a third of the damage dealt."},plasma:{name:"Plasma Torch",el:"plasma",power:1.2,fx:"burn",chance:.4,desc:"May set the target burning."},hydro:{name:"Tidal Jet",el:"hydro",power:1.15,desc:"A crushing jet of water."},cryo:{name:"Cryo Lance",el:"cryo",power:1,fx:"freeze",chance:.3,desc:"May freeze the target for a turn."},geo:{name:"Rockslide",el:"geo",power:1.25,desc:"Heavy and hard to argue with."},bio:{name:"Overgrowth",el:"bio",power:.75,fx:"heal",desc:"Strikes, then restores 18% of its hull."},volt:{name:"Arc Discharge",el:"volt",power:1.1,fx:"stun",chance:.2,desc:"May short-circuit the target."},alloy:{name:"Plate Up",el:"alloy",power:.6,fx:"shield",desc:"Hits, then halves the next blow it takes."},void:{name:"Null Pulse",el:"void",power:1.25,desc:"A wave of absolute nothing."},photon:{name:"Prism Laser",el:"photon",power:1.1,fx:"pierce",desc:"Cuts straight through shields."},kinetic:{name:"Mass Driver",el:"kinetic",power:1.45,fx:"reckless",chance:.2,desc:"Devastating, but misses one shot in five."},aero:{name:"Cyclone",el:"aero",power:1,fx:"first",desc:"Always strikes first."},gravity:{name:"Crush",el:"gravity",power:1,fx:"crush",desc:"Hits harder the healthier the target is."},chrono:{name:"Rewind",el:"chrono",power:.7,fx:"heal",desc:"Strikes, then winds back 18% of its damage."},neural:{name:"Overload",el:"neural",power:1,fx:"weaken",desc:"Lowers the target's attack by 20%."}},lp=i=>[...tt[i].el.filter(t=>ts[t]).map(t=>t),"strike"];function wd(i,t){if(i==="none")return 1;const e=t.some(s=>kt[i].strong.includes(s)),n=t.some(s=>(kt[s].strong||[]).includes(i));return e&&!n?1.35:n&&!e?.8:1}const s_={drone:14,orb:12,android:11,rover:10,crawler:9,walker:8,mech:6};function Mo(i,t,e,n){const s=ea({sp:i,lvl:t});return{sp:i,lvl:t,name:e||tt[i].name,hp:s.hp,max:s.hp,atk:Math.round(s.atk*1.6),spd:s_[tt[i].chassis]+t*.25+We.indexOf(tt[i].rarity),shield:!1,burn:0,frozen:!1,weak:0,bot:n}}const vn=i=>Math.round(i.reduce((t,e)=>{const n=ea({sp:e.sp,lvl:e.lvl});return t+Math.sqrt(n.hp*n.atk)},0));function cp(i,t,e){return{A:i,B:t,a:0,b:0,turn:0,seed:e,over:""}}function a_(i,t,e,n){const s=t==="A"?i.A[i.a]:i.B[i.b],a=t==="A"?i.B[i.b]:i.A[i.a],r=ts[e],o={side:t,who:t==="A"?i.a:i.b,target:t==="A"?i.b:i.a,move:e,dmg:0,eff:1,crit:!1,miss:!1,heal:0,status:"",ko:!1};if(s.frozen)return s.frozen=!1,o.status="frozen",o.miss=!0,o;if(r.fx==="reckless"&&n()<(r.chance||0))return o.miss=!0,o;o.eff=wd(r.el,tt[a.sp].el),o.crit=n()<.1;let l=s.atk*(1-s.weak)*r.power*o.eff*(.9+n()*.2)*(o.crit?1.5:1);return r.fx==="crush"&&(l*=.7+.6*(a.hp/a.max)),a.shield&&r.fx!=="pierce"&&(l*=.5,a.shield=!1,o.status="shielded"),o.dmg=Math.max(1,Math.round(l)),a.hp=Math.max(0,a.hp-o.dmg),r.fx==="drain"&&(o.heal=Math.round(o.dmg/3),s.hp=Math.min(s.max,s.hp+o.heal)),r.fx==="heal"&&(o.heal=Math.round(s.max*.18),s.hp=Math.min(s.max,s.hp+o.heal)),r.fx==="shield"&&(s.shield=!0),r.fx==="weaken"&&(a.weak=Math.min(.5,a.weak+.2),o.status="weakened"),(r.fx==="burn"||r.fx==="freeze"||r.fx==="stun")&&a.hp>0&&n()<(r.chance||0)&&(r.fx==="burn"?(a.burn=3,o.status="burning"):(a.frozen=!0,o.status=r.fx==="freeze"?"frozen solid":"stunned")),o.ko=a.hp<=0,o}function Il(i,t){const e=t==="A"?i.A[i.a]:i.B[i.b],n=t==="A"?i.B[i.b]:i.A[i.a];let s="strike",a=-1;for(const r of lp(e.sp)){const o=ts[r];let l=o.power*wd(o.el,tt[n.sp].el)*(o.fx==="reckless"?.8:1);(o.fx==="heal"||o.fx==="drain")&&e.hp<e.max*.45&&(l*=1.6),o.fx==="shield"&&!e.shield&&e.hp<e.max*.6&&(l+=.5),o.fx==="weaken"&&n.weak<.2&&(l+=.2),l>a&&(a=l,s=r)}return s}function r_(i,t,e){if(i.over)return[];const n=Tn(i.seed+ ++i.turn*104729),s=[],a=i.A[i.a],r=i.B[i.b],o=(ts[t].fx==="first"?100:0)+a.spd,l=(ts[e].fx==="first"?100:0)+r.spd,c=o>l||o===l&&n()<.5?[["A",t],["B",e]]:[["B",e],["A",t]];for(const[d,h]of c)(d==="A"?i.A[i.a]:i.B[i.b]).hp<=0||(d==="A"?i.B[i.b]:i.A[i.a]).hp<=0||s.push(a_(i,d,h,n));for(const[d,h]of[["A",i.A[i.a]],["B",i.B[i.b]]])if(h.hp>0&&h.burn>0){const u=Math.max(1,Math.round(h.max*.06));h.hp=Math.max(0,h.hp-u),h.burn--,s.push({side:d==="A"?"B":"A",who:-1,target:d==="A"?i.a:i.b,move:"burn",dmg:u,eff:1,crit:!1,miss:!1,heal:0,status:"burn",ko:h.hp<=0})}if(i.A[i.a].hp<=0){const d=i.A.findIndex(h=>h.hp>0);d<0?i.over="B":i.a=d}if(i.B[i.b].hp<=0){const d=i.B.findIndex(h=>h.hp>0);d<0?i.over=i.over?i.over:"A":i.b=d}return i.turn>=60&&!i.over&&(i.over=i.A.reduce((d,h)=>d+h.hp/h.max,0)>=i.B.reduce((d,h)=>d+h.hp/h.max,0)?"A":"B"),s}const Ki=[["Bronze III",0],["Bronze II",100],["Bronze I",200],["Silver III",350],["Silver II",500],["Silver I",650],["Gold III",850],["Gold II",1050],["Gold I",1250],["Platinum",1500],["Diamond",1800],["Singularity",2200]],Aa=["#cd7f32","#cd7f32","#cd7f32","#c0c8d4","#c0c8d4","#c0c8d4","#ffd36a","#ffd36a","#ffd36a","#7af7ff","#9fd0ff","#c49bff"],vs=i=>{let t=0;for(let e=0;e<Ki.length;e++)i>=Ki[e][1]&&(t=e);return t},xs=5,kc=90*6e4;function ii(i){const t=i;return t.arena||(t.arena={trophies:0,best:0,seasonBest:0,season:dp(),tickets:xs,tAt:Date.now(),wins:0,losses:0,rivals:[],rAt:0,team:[],dayWins:0,day:""}),t.arena}const dp=(i=Date.now())=>{const t=new Date(i),e=(t.getDay()+6)%7;return t.setHours(0,0,0,0),t.setDate(t.getDate()-e),`${t.getFullYear()}-${t.getMonth()+1}-${t.getDate()}`},o_=(i=Date.now())=>{const t=new Date(i),e=(t.getDay()+6)%7;return t.setHours(0,0,0,0),t.setDate(t.getDate()-e+7),t.getTime()};function hp(i,t=Date.now()){const e=ii(i);for(;e.tickets<xs&&t>=e.tAt+kc;)e.tickets++,e.tAt+=kc;e.tickets>=xs&&(e.tAt=t)}function up(i,t){const e=1+i.lvl*.5;return{dm:10+t*8,cells:Yt(300*e*(1+t*.4)),credits:Yt(800*e*(1+t*.5))}}function fp(i,t=Date.now()){const e=ii(i),n=dp(t);if(e.season===n)return null;const s=vs(e.seasonBest),a=e.seasonBest>0?up(i,s):null;return a&&Cn(i,a),e.season=n,e.trophies=Math.floor(e.trophies*.75),e.seasonBest=e.trophies,a?{league:s,reward:a}:null}const cu=["Nova","Astra","Kepler","Lumen","Vega","Orion","Tycho","Halley","Sagan","Ceres","Juno","Selene","Rhea","Titan","Helix","Zenith","Polaris","Draco","Lyra","Corvus"],du=["Station","Colony","Outpost","Haven","Reach","Spire","Hold","Landing","Array","Ring"],hu=["#1b6fd8","#d83a3a","#1f9c5a","#7a3fd6","#e08a1a","#14202e","#0fb3c9","#c9324f"],uu=["star","planet","bolt","gear","rocket","circle"];function Li(i){const t=ii(i),e=s=>tt[s.sp].alien==="relic"||!!(i.space&&i.space.exps.some(a=>a.crew.includes(s.id)));let n=t.team.map(s=>i.bots.find(a=>a.id===s)).filter(s=>!!s&&!s.stored&&!e(s));if(n.length<Math.min(3,i.bots.filter(s=>!s.stored).length)){const s=[...i.bots].filter(a=>!a.stored&&!e(a)&&!n.includes(a)).sort((a,r)=>vn([r])-vn([a]));n=[...n,...s].slice(0,3),t.team=n.map(a=>a.id)}return n.slice(0,3)}function fu(i,t=Date.now()){const e=ii(i),n=vn(Li(i).map(r=>({sp:r.sp,lvl:r.lvl}))),s=Tn(js(String(t>>>0))^i.created>>>0),a=vs(e.trophies);return e.rivals=[0,1,2].map(r=>{const o=Math.max(40,n*[.78,.98,1.2][r]*(1+a*.02)),l=Math.min(6,Math.floor(a/2)+(r===2?2:1)),c=Qn.filter(h=>We.indexOf(tt[h].rarity)<=l),d=[];for(let h=0;h<3;h++){const u=c[Math.floor(s()*c.length)];let f=1;for(;f<40&&vn([...d,{sp:u,lvl:f+1}])<=o*((h+1)/3);)f++;d.push({sp:u,lvl:f})}return{name:`${cu[Math.floor(s()*cu.length)]} ${du[Math.floor(s()*du.length)]}`,banner:{bg:hu[Math.floor(s()*hu.length)],fg:s()<.5?"#ffd23a":"#ffffff",emblem:uu[Math.floor(s()*uu.length)]},team:d,diff:r,power:vn(d)}}),e.rAt=t,e.rivals}const pp=[18,26,36];function Ta(i){const t=ii(i);return zt(i,"arena").some(e=>e.lvl>0)?t.tickets<=0?{ok:!1,why:"No battle tickets: one recharges every 90 minutes"}:Li(i).length<1?{ok:!1,why:"You need bots to fight"}:{ok:!0}:{ok:!1,why:"Build the Arena first"}}function l_(i,t,e=Date.now()){const n=ii(i);if(!Ta(i).ok)return null;const a=n.rivals[t];if(!a)return null;n.tickets===xs&&(n.tAt=e),n.tickets--;const r=Li(i).map(o=>Mo(o.sp,o.lvl,o.nick,o.id));return{bt:cp(r,a.team.map(o=>Mo(o.sp,o.lvl)),e/1e3>>>0),rival:a}}function c_(i,t,e,n=Date.now()){const s=ii(i),a=new Date(n).toDateString();s.day!==a&&(s.day=a,s.dayWins=0);const r=1+i.lvl*.5;let o,l;t?(l=pp[e],s.wins++,s.dayWins++,o={credits:Yt(300*r*(1+e*.5)),cells:Yt(80*r*(1+e*.5))},s.dayWins===1&&(o.dm=5),i.stats.arenaWins=(i.stats.arenaWins||0)+1):(l=-14,s.losses++,o={credits:Yt(60*r)});const c=vs(s.trophies);s.trophies=Math.max(0,s.trophies+l),s.best=Math.max(s.best,s.trophies),s.seasonBest=Math.max(s.seasonBest,s.trophies);const d=vs(s.trophies),h=(zt(i,"arena")[0]||{lvl:1}).lvl;for(const u of Object.keys(o))u!=="dm"&&(o[u]=Yt(o[u]*(1+.1*(h-1))));return Cn(i,o),ce(i,t?20+e*10:5),s.rivals=[],{reward:o,dt:l,promoted:d>c?d:-1,league:d}}const d_=16,mp=10*36e5,h_=2*36e5;function Jo(i){const t=i;return t.raid||(t.raid={next:Date.now()+36e5,eta:0,team:[],won:0,lost:0}),t.raid}const u_={bg:"#14080c",fg:"#ff3d5a",emblem:"circle"};function f_(i,t=Date.now()){if(i.lvl<d_)return null;const e=Jo(i);if(!e.eta&&t>=e.next){const n=vn(Li(i).map(o=>({sp:o.sp,lvl:o.lvl}))),s=Math.max(60,n*1.08),a=["krdrone","krwarrior","krdrone","krbrood"],r=[];for(let o=0;o<3;o++){const l=a[(o+Math.floor(t/36e5))%(o===2&&i.lvl>24?4:3)];let c=1;for(;c<40&&vn([...r,{sp:l,lvl:c+1}])<=s*((o+1)/3);)c++;r.push({sp:l,lvl:c})}return e.team=r,e.eta=t+h_,{kind:"warn"}}if(e.eta&&t>=e.eta){let n=0;for(const s of zt(i,"bay")){const a=Math.floor((i.bay[s.id]||0)*.5);i.bay[s.id]-=a,n+=a}return e.eta=0,e.next=t+mp,e.lost++,{kind:"hit",stolen:n}}return null}function p_(i,t=Date.now()){const e=Jo(i);if(!e.eta||!e.team.length)return null;const n=Li(i).map(a=>Mo(a.sp,a.lvl,a.nick,a.id));if(!n.length)return null;const s={name:"Kr'thul Swarm",banner:u_,team:e.team,diff:2,power:vn(e.team)};return{bt:cp(n,e.team.map(a=>Mo(a.sp,a.lvl)),t/1e3>>>0),rival:s}}function m_(i,t,e=Date.now()){const n=Jo(i),s=1+i.lvl*.5;if(n.eta=0,n.next=e+mp,t){n.won++,i.stats.raidsWon=(i.stats.raidsWon||0)+1;const r={dm:12,cells:Yt(400*s),credits:Yt(1200*s)};Cn(i,r),ce(i,60);const o=Tn(e/1e3>>>0)(),l=o<.35?o<.03?"krbrood":o<.12?"krwarrior":"krdrone":null;return{win:t,reward:r,capture:l}}n.lost++;let a=0;for(const r of zt(i,"bay")){const o=Math.floor((i.bay[r.id]||0)*.5);i.bay[r.id]-=o,a+=o}return{win:t,reward:{},capture:null,stolen:a}}const zc=new D(0,0,-260),pu=new Set(["photon","volt","solar","neural","void"]);class g_{constructor(t){this.group=new Te,this.A=[],this.B=[],this.t=0,this.anims=[],this.onImpact=()=>{};const e=new Ce;e.cyl(7.2,7.6,.6,32,"#2a3446",0,-.6),e.cyl(7,7,.06,48,"#3a4a64",0,0),e.add(new tn(6.9,.08,6,64),"#6ee7ff",0,.05,0,{rx:Math.PI/2,glow:!0}),e.add(new tn(3.2,.05,6,48),"#6ee7ff",0,.06,0,{rx:Math.PI/2,glow:!0});for(const[s,a]of[[-3.2,"#4aa8ff"],[3.2,"#ff5a6a"]])e.cyl(1.4,1.4,.05,24,a,s,.05,0,{glow:!0}),e.cyl(1.25,1.25,.06,24,"#1a2232",s,.06,0);for(let s=0;s<10;s++){const a=s/10*Math.PI*2;e.box(.3,2.2,.3,"#c8d0da",Math.cos(a)*6.6,0,Math.sin(a)*6.6),e.box(.34,.12,.34,"#6ee7ff",Math.cos(a)*6.6,2.2,Math.sin(a)*6.6,{glow:!0})}e.cyl(.1,1.2,4,10,"#3a4250",0,-4.6,0);const n=e.build("arena");n.traverse(s=>{s.isMesh&&(s.receiveShadow=!0)}),this.group.add(n),this.ring=new Pt(new tn(7.6,.03,4,96),new Me({color:"#7af7ff",transparent:!0,opacity:.18})),this.ring.rotation.x=Math.PI/2,this.ring.position.y=6,this.group.add(this.ring),this.group.position.copy(zc),t.add(this.group)}clear(){for(const t of[...this.A,...this.B])this.group.remove(t.m.group);this.A=[],this.B=[],this.anims=[]}setup(t){this.clear();const e=(s,a,r)=>{const o=s==="A"?-1:1;return r?new D(o*2.4,.1,0):new D(o*4.8,.1,a%2?1.8:-1.8)},n=(s,a,r,o)=>{const l=Sd(s.sp,s.lvl);l.group.scale.multiplyScalar(2.7);const c=e(a,r,o);return l.group.position.copy(c),l.group.rotation.y=a==="A"?Math.PI/2:-Math.PI/2,this.group.add(l.group),{m:l,home:c,ko:s.hp<=0,flash:0}};this.A=t.A.map((s,a)=>n(s,"A",a,a===t.a)),this.B=t.B.map((s,a)=>n(s,"B",a,a===t.b))}worldPos(t,e){const n=(t==="A"?this.A:this.B)[e];return n?n.m.group.position.clone().add(this.group.position).add(new D(0,1.4,0)):this.group.position.clone()}tween(t,e,n){this.anims.push({t:0,dur:t,fn:e,done:n})}play(t,e,n=1){return new Promise(s=>{let a=0;const r=()=>{if(a>=t.length){this.reposition(e,n,s);return}const o=t[a++];this.playHit(o,n,r)};r()})}playHit(t,e,n){const s=t.side==="A"?this.A:this.B,r=(t.side==="A"?this.B:this.A)[t.target];if(!r){n();return}if(t.move==="burn"){r.flash=1,this.onImpact(t,r.m.group.position.clone().add(this.group.position).add(new D(0,1.6,0))),this.tween(.35/e,()=>{},n);return}const o=s[t.who];if(!o){n();return}const l=ts[t.move].el,c=l==="none"?"#ffffff":kt[l].glow,d=o.m.group.position.clone(),h=d.clone().lerp(r.m.group.position,.18);this.tween(.18/e,u=>o.m.group.position.lerpVectors(d,h,Math.sin(u*Math.PI/2)),()=>{const u=o.m.group.position.clone().add(new D(0,1.2,0)),f=r.m.group.position.clone().add(new D(0,1.1,0));let g;if(pu.has(l)){const m=u.distanceTo(f),p=new Pt(new bn(.09,.09,m,8),new Me({color:c,toneMapped:!1,transparent:!0}));p.position.copy(u).lerp(f,.5),p.lookAt(f),p.rotateX(Math.PI/2),g=p}else g=new Pt(new Hn(.28,1),new Me({color:c,toneMapped:!1})),g.position.copy(u);this.group.add(g);const x=pu.has(l);this.tween((x?.22:.32)/e,m=>{x?(g.material.opacity=1-m*.6,g.scale.x=g.scale.z=1+Math.sin(m*30)*.3):(g.position.lerpVectors(u,f,m),g.position.y+=Math.sin(m*Math.PI)*.8,g.rotation.y+=.3)},()=>{this.group.remove(g),t.miss||(r.flash=1),this.onImpact(t,f.clone().add(this.group.position)),this.tween(.22/e,m=>o.m.group.position.lerpVectors(h,d,m),()=>{t.ko?this.knockOut(r,e,n):n()})})})}knockOut(t,e,n){t.ko=!0;const s=t.m.group,a=s.rotation.z,r=s.position.y;this.tween(.5/e,o=>{s.rotation.z=a+o*1.4*(s.position.x<0?-1:1),s.position.y=r-o*.3,s.scale.setScalar(2.7*(1-o*.35))},()=>{s.visible=!1,n()})}reposition(t,e,n){const s=[];for(const[a,r,o]of[["A",this.A,t.a],["B",this.B,t.b]]){const l=r[o];if(!l||l.ko)continue;const c=new D((a==="A"?-1:1)*2.4,.1,0);if(l.m.group.position.distanceTo(c)>.1){const d=l.m.group.position.clone();s.push(()=>this.tween(.4/e,h=>l.m.group.position.lerpVectors(d,c,h))),l.home=c}}s.forEach(a=>a()),this.tween(s.length?.45/e:.05,()=>{},n)}update(t){this.t+=t;const e=this.t;this.ring.rotation.z=e*.2;for(const n of[...this.anims]){n.t+=t;const s=Math.min(1,n.t/n.dur);n.fn(s),s>=1&&(this.anims.splice(this.anims.indexOf(n),1),n.done&&n.done())}for(const n of[...this.A,...this.B])if(!n.ko&&(n.m.anim(e,!1),n.flash>0)){n.flash=Math.max(0,n.flash-t*4);const s=2.7*(1+n.flash*.12);n.m.group.scale.setScalar(s)}}}const ye={moon:{name:"The Moon",tier:1,hours:.5,crew:1,els:["geo","solar"],dist:1.4,color:"#bdbab4",size:.32,moonOf:"earth",fact:"384,400 km away; three days by chemical rocket.",first:"Your crew plants the colony banner beside the Apollo 11 site. Helium-3 glitters in the regolith.",outpost:{res:"cells",rate:120}},neo:{name:"Near-Earth Asteroids",tier:1,hours:1,crew:2,els:["geo","alloy","gravity"],needs:"moon",dist:4.2,color:"#8a7a68",size:.18,fact:"Thousands of mountains of metal drift past Earth every year.",first:"A nickel-iron asteroid the size of a stadium. Your bots start a claim.",outpost:{res:"credits",rate:400}},mars:{name:"Mars",tier:2,hours:2,crew:2,els:["geo","plasma","cryo"],needs:"moon",dist:5.4,color:"#c2643a",size:.42,fact:"Olympus Mons is 22 km high; a day lasts 24 h 37 min.",first:"Dust devils dance across Jezero Crater as your rover crew rolls out. Ice lies a metre down.",outpost:{res:"credits",rate:700}},phobos:{name:"Phobos",tier:2,hours:2.5,crew:2,els:["gravity","alloy"],needs:"mars",dist:5.9,color:"#6e6660",size:.14,moonOf:"mars",fact:"Orbits Mars three times a day, slowly spiralling inwards.",first:"A perfect depot site: one shove and cargo falls to Mars.",outpost:{res:"cells",rate:260}},ceres:{name:"Ceres",tier:2,hours:4,crew:2,els:["cryo","hydro","geo"],needs:"neo",dist:7.4,color:"#7a7570",size:.24,fact:"The largest object in the asteroid belt, with salt-bright craters.",first:"Occator Crater's bright salts are brine frozen in place. Water for the whole belt.",outpost:{res:"credits",rate:1300}},europa:{name:"Europa",tier:3,hours:6,crew:3,els:["cryo","hydro","bio"],needs:"ceres",dist:10.5,color:"#d8ccb4",size:.2,moonOf:"jupiter",fact:"An ocean of salt water under 20 km of ice.",first:"The deep probe melts through the ice. Something down there glows.",outpost:{res:"cells",rate:900}},ganymede:{name:"Ganymede",tier:3,hours:6,crew:3,els:["gravity","volt","cryo"],needs:"ceres",dist:10.9,color:"#a39889",size:.26,moonOf:"jupiter",fact:"The largest moon in the Solar System, with its own magnetic field.",first:"Aurorae ripple over the ice plains. Jupiter fills half the sky.",outpost:{res:"credits",rate:2400}},titan:{name:"Titan",tier:4,hours:8,crew:3,els:["hydro","bio","aero"],needs:"europa",dist:13.6,color:"#d08a3a",size:.3,moonOf:"saturn",fact:"Thick orange skies and lakes of liquid methane.",first:"Your drone crew glides down through orange haze onto the shore of Kraken Mare.",outpost:{res:"credits",rate:4200}},enceladus:{name:"Enceladus",tier:4,hours:10,crew:3,els:["cryo","neural","hydro"],needs:"titan",dist:14.1,color:"#f2f8fd",size:.16,moonOf:"saturn",fact:"Geysers at its south pole spray an ocean into space.",first:"Your bots fly straight through a geyser plume and sample an alien ocean.",outpost:{res:"dm",rate:2}},proxima:{star:!0,alien:"veyari",ly:4.2,angle:.6,name:"Proxima Centauri b",tier:5,hours:16,crew:3,els:["void","photon","gravity"],needs:"pluto",dist:28,color:"#ff9a6a",size:.35,fact:"The nearest star to the Sun: a red dwarf with a rocky world in its habitable zone.",first:"On a tidally locked world, crystal gardens grow along the twilight line. Their gardeners, the Veyari, have been waiting for you.",outpost:{res:"dm",rate:6}},barnard:{star:!0,alien:"synod",ly:6,angle:1.7,name:"Barnard's Star",tier:5,hours:18,crew:3,els:["cryo","chrono","gravity"],needs:"proxima",dist:30,color:"#ff7a5a",size:.32,fact:"An ancient red dwarf racing across our sky faster than any other star.",first:'A frozen planet humming with machinery. The Synod, a parliament of machines, opens a channel: "We have been expecting your bots."',outpost:{res:"dm",rate:7}},tauceti:{star:!0,alien:"mycelar",ly:12,angle:2.9,name:"Tau Ceti e",tier:5,hours:20,crew:3,els:["bio","hydro","neural"],needs:"barnard",dist:32,color:"#ffe08a",size:.34,fact:"A Sun-like star with a debris disc and several super-Earths.",first:"A whole continent is one fungal mind, the Mycelar. It sings to your crew through their sensors.",outpost:{res:"dm",rate:8}},trappist:{star:!0,alien:"oshoru",ly:40,angle:4.1,name:"TRAPPIST-1e",tier:5,hours:24,crew:3,els:["hydro","aero","kinetic"],needs:"tauceti",dist:34,color:"#ff6a5a",size:.3,fact:"Seven Earth-sized worlds orbit one tiny star; three could hold oceans.",first:"An ocean world. The Oshoru, a young sea-faring people, swim up to greet your landing craft.",outpost:{res:"dm",rate:9}},epseri:{star:!0,alien:"lumenchoir",ly:10.5,angle:5.2,name:"Epsilon Eridani",tier:5,hours:24,crew:3,els:["photon","solar","neural"],needs:"trappist",dist:36,color:"#ffd27a",size:.36,fact:"A young, restless star wrapped in asteroid belts.",first:"Something old is broadcasting here. The Lumen, beings of pure light, have been listening to Earth for a century.",outpost:{res:"dm",rate:12}},pluto:{name:"Pluto",tier:4,hours:12,crew:3,els:["cryo","void","chrono"],needs:"enceladus",dist:18.5,color:"#d9c4a8",size:.2,fact:"A heart-shaped glacier of nitrogen ice, 6 billion km from the Sun.",first:"At the edge of the Solar System your crew looks back. The Sun is just a bright star. Beyond: the real stars.",outpost:{res:"dm",rate:4}}},si=[...Object.keys(ye).filter(i=>!ye[i].star),...Object.keys(ye).filter(i=>ye[i].star)],v_=[{id:"mercury",dist:2.2,color:"#9a948d",size:.16},{id:"venus",dist:3.1,color:"#d9b77a",size:.3},{id:"earth",dist:4,color:"#3f7fd8",size:.32},{id:"jupiter",dist:10.7,color:"#d6b48a",size:.95},{id:"saturn",dist:13.8,color:"#e6d3a3",size:.8,ring:!0},{id:"uranus",dist:16.4,color:"#a6dce4",size:.5},{id:"neptune",dist:17.6,color:"#3a6ed8",size:.48}],ys=[{name:"Kestrel",pad:1},{name:"Meridian",pad:3},{name:"Colossus",pad:6},{name:"Leviathan",pad:9},{name:"Starship",pad:10}],Xi=i=>ys.filter(t=>i>=t.pad).length,Js=i=>1+Math.floor(i/4);function Xe(i){const t=i;return t.space||(t.space={visits:{},exps:[],outposts:{}}),t.space}const Ed=i=>zt(i,"pad")[0],mu=(i,t)=>Xe(i).exps.some(e=>e.crew.includes(t)),$c=(i,t)=>{const e=ye[t];return!e.needs||(Xe(i).visits[e.needs]||0)>0},gp=i=>Math.round(120*Math.pow(2.1,si.indexOf(i)*.6+ye[i].tier-1));function Ad(i,t,e){const n=ye[t],s=Math.round(e.reduce((r,o)=>{const l=ea(o);return r+Math.sqrt(l.hp*l.atk)},0)),a=e.reduce((r,o)=>r+tt[o.sp].el.filter(l=>n.els.includes(l)).length,0);return{power:s,match:a,mult:Math.min(2.5,(.55+.45*Math.min(1.6,s/gp(t)))*(1+.15*a))}}function vp(i,t,e){const n=Ed(i),s=ye[t];if(!n||n.lvl<1)return{ok:!1,why:"Build the Launch Pad first"};if(Ee(i,n.id,"build"))return{ok:!1,why:"The Launch Pad is being upgraded"};if(!$c(i,t))return{ok:!1,why:`Visit ${ye[s.needs].name} first`};if(Xi(n.lvl)<s.tier)return{ok:!1,why:`Needs a ${ys[s.tier-1].name} rocket (Launch Pad level ${ys[s.tier-1].pad})`};if(Xe(i).exps.length>=Js(n.lvl))return{ok:!1,why:"Every rocket is out: wait for one to return"};if(Xe(i).exps.some(r=>r.dest===t))return{ok:!1,why:"A crew is already on its way there"};if(!e.length)return{ok:!1,why:"Pick a crew"};if(e.some(r=>{const o=i.bots.find(l=>l.id===r);return!o||tt[o.sp].alien==="relic"}))return{ok:!1,why:"Relic AIs never leave the Vault"};if(e.length>s.crew)return{ok:!1,why:`At most ${s.crew} bots`};const a=Yt(150*Math.pow(2.3,si.indexOf(t)*.55));return i.res.credits<a?{ok:!1,why:"Not enough credits for fuel",cost:a}:{ok:!0,cost:a}}function x_(i,t,e,n=Date.now()){const s=vp(i,t,e);if(!s.ok)return s;i.res.credits-=s.cost||0;const a=e.map(l=>i.bots.find(c=>c.id===l)).filter(Boolean);for(const l of a)delete l.post;const r=Ad(i,t,a),o={id:Ye("e"),dest:t,crew:e,start:n,end:n+ye[t].hours*36e5,power:r.power,match:r.match};return Xe(i).exps.push(o),i.stats.launches=(i.stats.launches||0)+1,ce(i,20+si.indexOf(t)*6),on.push({kind:"launch",dest:t}),{...s,exp:o}}const y_=i=>ye[i].hours*3600;function xp(i,t){const e=ye[t.dest],n=si.indexOf(t.dest),s=t.crew.map(u=>i.bots.find(f=>f.id===u)).filter(u=>!!u),a=Ad(i,t.dest,s),r=Tn(t.start/1e3>>>0),o=a.mult*(1+i.lvl*.25)*Math.pow(1.3,n),l={credits:Yt(400*o*e.hours),cells:Yt(110*o*e.hours)};r()<.35+.05*e.tier&&(l.dm=2+Math.round(r()*4*e.tier));const c=!(Xe(i).visits[t.dest]>0);c&&(l.dm=(l.dm||0)+10+n*5);const d=r(),h=d<.02*e.tier?"epic":d<.08*e.tier?"elite":d<.3?"advanced":null;return{res:l,rarity:h,first:c,alien:c&&e.alien?e.alien:null}}function b_(i,t=Date.now()){const e=Xe(i),n=[];for(const s of[...e.exps]){if(s.end>t)continue;const a=xp(i,s);Cn(i,a.res);const r=a.alien?Md(i,a.alien,s.end):a.rarity?ns(i,a.rarity,s.start/1e3>>>0,s.end):null;e.visits[s.dest]=(e.visits[s.dest]||0)+1,e.exps=e.exps.filter(o=>o!==s),i.stats.expeditions=(i.stats.expeditions||0)+1,ce(i,25+si.indexOf(s.dest)*8),n.push({exp:s,res:a.res,gift:r,first:a.first}),on.push({kind:"expBack",dest:s.dest})}for(const[s,a]of Object.entries(e.outposts)){const r=(t-a.t)/1e3;if(a.t=t,r<=0)continue;const o=yp(s,a.lvl);a.buf=Math.min(o,a.buf+So(s,a.lvl)*r/3600)}return n}const So=(i,t)=>ye[i].outpost.rate*(1+.5*(t-1)),yp=(i,t)=>So(i,t)*8,__=(i,t)=>Yt(2e3*Math.pow(2.2,si.indexOf(i)*.6)*Math.pow(2,t));function bp(i,t){const e=Xe(i).outposts[t],n=e?e.lvl:0;if(!(Xe(i).visits[t]>0))return{ok:!1,why:"Send an expedition there first"};if(n>=10)return{ok:!1,why:"Maximum level"};const s=__(t,n);return i.res.credits<s?{ok:!1,why:"Not enough credits",cost:s}:{ok:!0,cost:s}}function M_(i,t,e=Date.now()){const n=bp(i,t);if(!n.ok)return n;i.res.credits-=n.cost||0;const s=Xe(i),a=s.outposts[t];return a?a.lvl++:s.outposts[t]={lvl:1,buf:0,t:e},i.stats.outposts=Object.keys(s.outposts).length,ce(i,40),n}function S_(i,t){const e=Xe(i).outposts[t];if(!e)return 0;const n=Math.floor(e.buf);return n<=0?0:(e.buf-=n,i.res[ye[t].outpost.res]+=n,n)}const w_={mercury:.4,venus:2.2,earth:4.1,neo:3.5,mars:5.3,ceres:1.2,jupiter:2.6,saturn:.9,uranus:3.9,neptune:5.6,pluto:4.6};class E_{constructor(t){this.canvas=t,this.scene=new Bo,this.camera=new gn(40,1,.1,2e3),this.bodies=new Map,this.picks=[],this.ships=new Map,this.yaw=.6,this.dist=34,this.t=0,this.active=!1,this.ray=new Gf,this.onPick=()=>{},this.scene.add(new Hf("#556070",.6));const e=new $f("#fff2d8",3.2,0,0);this.scene.add(e);const n=new Pt(new Oe(1.1,32,20),new Me({color:"#ffd27a",toneMapped:!1}));this.scene.add(n);const s=new Lc(new po({map:gu(),color:"#ffcf7a",blending:Zi,depthWrite:!1,transparent:!0}));s.scale.setScalar(7),this.scene.add(s);const a=1500,r=new Float32Array(a*3);for(let f=0;f<a;f++){const g=Math.random()*2-1,x=Math.random()*6.283,m=Math.sqrt(1-g*g);r.set([m*Math.cos(x)*600,g*600,m*Math.sin(x)*600],f*3)}const o=new ge;o.setAttribute("position",new Ne(r,3)),this.scene.add(new Wa(o,new sa({size:1.6,sizeAttenuation:!1,color:"#cfe0ff"})));const l=(f,g=.18)=>{const x=[];for(let m=0;m<=128;m++){const p=m/128*Math.PI*2;x.push(new D(Math.cos(p)*f,0,Math.sin(p)*f))}return new If(new ge().setFromPoints(x),new mo({color:"#6ee7ff",transparent:!0,opacity:g}))},c=(f,g,x,m,p=!1)=>{const y=new Te,A=new Hn(m,3),b=new Float32Array(A.attributes.position.count*3),w=new Rt(x),E=new Rt;for(let P=0;P<A.attributes.position.count;P++){const R=A.attributes.position.getY(P)/m,N=Math.sin(R*9+P*.37)*.06;E.copy(w).offsetHSL(0,0,N+(Math.random()-.5)*.05),b.set([E.r,E.g,E.b],P*3)}A.setAttribute("color",new Ne(b,3));const v=new Pt(A,new ln({vertexColors:!0,roughness:.85,flatShading:!0}));if(y.add(v),p){const P=new Pt(new $o(m*1.4,m*2.3,48),new Me({color:"#d9c79a",side:Un,transparent:!0,opacity:.6}));P.rotation.x=-Math.PI/2.3,y.add(P)}const S=w_[f]??Math.random()*6;return y.position.set(Math.cos(S)*g,0,Math.sin(S)*g),y.userData={r:g,a:S,speed:.08/Math.pow(g,1.5),size:m},this.scene.add(y),this.bodies.set(f,y),y};for(const f of v_)this.scene.add(l(f.dist)),c(f.id,f.dist,f.color,f.size,!!f.ring);const d=700,h=new Float32Array(d*3);for(let f=0;f<d;f++){const g=Math.random()*6.283,x=6.6+Math.random()*1.5;h.set([Math.cos(g)*x,(Math.random()-.5)*.25,Math.sin(g)*x],f*3)}const u=new ge;u.setAttribute("position",new Ne(h,3)),this.scene.add(new Wa(u,new sa({size:.05,color:"#a89880"})));for(const f of si){const g=ye[f];let x;if(g.star){const p=new Te,y=new Pt(new Oe(g.size,16,10),new Me({color:g.color,toneMapped:!1}));p.add(y);const A=new Lc(new po({map:gu(),color:g.color,blending:Zi,depthWrite:!1,transparent:!0}));A.scale.setScalar(g.size*9),p.add(A),p.position.set(Math.cos(g.angle||0)*g.dist,1.5,Math.sin(g.angle||0)*g.dist),this.scene.add(p),x=p}else if(g.moonOf){const p=this.bodies.get(g.moonOf),y=new Te,A=new Pt(new Hn(g.size,2),new ln({color:g.color,roughness:.9,flatShading:!0})),b=(p.children[0].geometry.boundingSphere,0);y.add(A);const w=p.userData.size||.4;A.position.x=w+.45+si.indexOf(f)%3*.25+b,y.userData={spin:.6+si.indexOf(f)%4*.25,mesh:A},p.add(y),x=A}else this.scene.add(l(g.dist,.1)),x=c(f,g.dist,g.color,g.size);const m=new Pt(new Oe(Math.max(.5,g.size*2),8,6),new Me({visible:!1}));m.userData.id=f,x.add(m),this.picks.push(m),this.bodies.set(f,x)}this.input()}input(){let t=null,e=!1,n=0;const s=new Map;this.canvas.addEventListener("pointerdown",a=>{if(this.active&&(s.set(a.pointerId,{x:a.clientX,y:a.clientY}),t={x:a.clientX,y:a.clientY,id:a.pointerId},e=!1,s.size===2)){const[r,o]=[...s.values()];n=Math.hypot(r.x-o.x,r.y-o.y)}}),this.canvas.addEventListener("pointermove",a=>{if(!this.active||!t)return;const r=s.get(a.pointerId);if(!r)return;const o=a.clientX-r.x;if(r.x=a.clientX,r.y=a.clientY,Math.hypot(a.clientX-t.x,a.clientY-t.y)>7&&(e=!0),s.size===2){const[l,c]=[...s.values()],d=Math.hypot(l.x-c.x,l.y-c.y);n&&(this.dist=Math.min(60,Math.max(10,this.dist*n/d))),n=d}else e&&(this.yaw-=o*.006)}),this.canvas.addEventListener("pointerup",a=>{this.active&&(s.delete(a.pointerId),t&&!e&&s.size===0&&this.tap(a.clientX,a.clientY),s.size||(t=null))}),this.canvas.addEventListener("wheel",a=>{this.active&&(this.dist=Math.min(60,Math.max(10,this.dist*Math.pow(1.0015,a.deltaY))))},{passive:!0})}tap(t,e){const n=this.canvas.getBoundingClientRect();this.ray.setFromCamera(new It((t-n.left)/n.width*2-1,-((e-n.top)/n.height)*2+1),this.camera);const s=this.ray.intersectObjects(this.picks,!1)[0];s&&this.onPick(s.object.userData.id)}worldPos(t){const e=this.bodies.get(t),n=new D;return e&&e.getWorldPosition(n),n}project(t){const e=t.clone().project(this.camera),n=this.canvas.getBoundingClientRect();return{x:n.left+(e.x*.5+.5)*n.width,y:n.top+(-e.y*.5+.5)*n.height,vis:e.z<1}}focus(t){const e=this.worldPos(t);this.yaw=Math.atan2(e.x,e.z)}syncShips(t,e){const n=new Set;for(const s of t){n.add(s.id);let a=this.ships.get(s.id);a||(a=new Pt(new $n(.12,.4,6),new Me({color:"#7cf29a",toneMapped:!1})),this.scene.add(a),this.ships.set(s.id,a));const r=Math.min(1,Math.max(0,(e-s.start)/(s.end-s.start))),o=this.worldPos("earth"),l=this.worldPos(s.dest),c=o.clone().lerp(l,.5);c.y+=o.distanceTo(l)*.3;const d=new D().copy(o).multiplyScalar((1-r)*(1-r)).addScaledVector(c,2*r*(1-r)).addScaledVector(l,r*r),h=new D().copy(o).multiplyScalar((1-r-.01)**2).addScaledVector(c,2*(r+.01)*(1-r-.01)).addScaledVector(l,(r+.01)**2);a.position.copy(d),a.lookAt(h),a.rotateX(Math.PI/2)}for(const[s,a]of this.ships)n.has(s)||(this.scene.remove(a),this.ships.delete(s))}frame(t,e){this.t+=t;const n=this.canvas.clientWidth||innerWidth,s=this.canvas.clientHeight||innerHeight;this.camera.aspect!==n/s&&(this.camera.aspect=n/s,this.camera.updateProjectionMatrix());for(const[,o]of this.bodies){const l=o.userData;l&&l.r&&(l.a+=l.speed*t,o.position.set(Math.cos(l.a)*l.r,0,Math.sin(l.a)*l.r),o.rotation.y+=t*.3),o.children.forEach(c=>{c.userData&&c.userData.spin&&(c.rotation.y+=t*c.userData.spin)})}const a=.95,r=this.dist*(n/s<.8?1.5:1);this.camera.position.set(Math.sin(this.yaw)*Math.cos(a)*r,Math.sin(a)*r,Math.cos(this.yaw)*Math.cos(a)*r),this.camera.lookAt(0,0,0),e.render(this.scene,this.camera)}}let Br=null;function gu(){if(Br)return Br;const i=document.createElement("canvas");i.width=i.height=128;const t=i.getContext("2d"),e=t.createRadialGradient(64,64,0,64,64,64);return e.addColorStop(0,"rgba(255,240,200,1)"),e.addColorStop(.2,"rgba(255,210,120,0.6)"),e.addColorStop(1,"rgba(255,180,80,0)"),t.fillStyle=e,t.fillRect(0,0,128,128),Br=new gd(i),Br}class A_{constructor(t,e){this.canvas=t,this.scene=new Bo,this.island=new Ub,this.views=new Map,this.bots=new Map,this.cam={x:0,z:1,dist:30,yaw:Math.PI/4,tx:0,tz:1,tdist:30,tyaw:Math.PI/4},this.ghost=null,this.ghostObj=null,this.ghostFoot=null,this.selected=null,this.t=0,this.ray=new Gf,this.ptr=new It,this.fx=[],this.onTap=()=>{},this.pod=null,this.podPick=null,this.podY=0,this.mode="island",this.system=null,this.rockets=[],this.arena=null,this.saved=null,this.onGhostMove=()=>{},this.look={primary:"#e9eef5",accent:"#22c7e8",banner:{bg:"#1b6fd8",fg:"#ffd23a",emblem:"star"}};const n=/Android|iPhone|iPad|iPod/i.test(navigator.userAgent)||navigator.maxTouchPoints>1&&Math.min(screen.width,screen.height)<820;this.quality=e==="auto"?n?"low":"high":e,this.renderer=new Cb({canvas:t,antialias:this.quality==="high",powerPreference:"high-performance"}),this.renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,this.quality==="high"?2:1.5)),this.renderer.outputColorSpace=Je,this.renderer.toneMapping=nd,this.renderer.toneMappingExposure=1.05,this.renderer.shadowMap.enabled=!0,this.renderer.shadowMap.type=af,this.camera=new gn(30,1,1,16e3);const s=new D(-.55,.62,.42).normalize();this.sun=new xo("#fff3df",2.7),this.sun.position.copy(s).multiplyScalar(40),this.sun.castShadow=!0;const a=this.quality==="high"?2048:1024;this.sun.shadow.mapSize.set(a,a);const r=this.sun.shadow.camera;r.left=-22,r.right=22,r.top=22,r.bottom=-22,r.near=1,r.far=110,this.sun.shadow.bias=-5e-4,this.sun.shadow.normalBias=.02,this.scene.add(this.sun,this.sun.target),this.scene.add(new Bf("#bcd8ff","#3a2a22",.85)),this.scene.add(new Hf("#405070",.35));const o=new xo("#7ab6ff",.6);o.position.set(30,10,-30),this.scene.add(o),this.backdrop=new Nb(this.renderer,s,this.quality),this.scene.add(this.backdrop.group),this.scene.add(this.island.group),this.selRing=new Pt(new $o(.9,1,48),new Me({color:"#6ee7ff",transparent:!0,opacity:.9,depthWrite:!1,side:Un})),this.selRing.rotation.x=-Math.PI/2,this.selRing.visible=!1,this.scene.add(this.selRing),this.resize(),window.addEventListener("resize",()=>this.resize()),this.input()}openMap(){this.system||(this.system=new E_(this.canvas)),this.system.active=!0,this.mode="map",this.select(null)}closeMap(){this.system&&(this.system.active=!1),this.mode="island"}launchFx(t,e){const n=this.views.get(t);if(!n)return;const s=ep(e);s.group.position.copy(n.root.position),s.group.position.y=.3;const a=new Pt(new $n(.25,1.4,10),new Me({color:"#ffd27a",toneMapped:!1}));a.rotation.x=Math.PI,a.position.y=-.6,s.group.add(a);const r=160,o=new Float32Array(r*3).fill(0),l=new Float32Array(r*3),c=new ge;c.setAttribute("position",new Ne(o,3));const d=new Wa(c,new sa({color:"#d8dde4",size:.6,transparent:!0,opacity:.75,depthWrite:!1}));this.scene.add(s.group,d),this.rockets.push({g:s.group,t:0,smoke:d,v:l})}enterArena(){this.arena||(this.arena=new g_(this.scene)),this.mode="arena",this.saved={x:this.cam.tx,z:this.cam.tz,dist:this.cam.tdist,yaw:this.cam.tyaw},this.cam.tx=zc.x,this.cam.tz=zc.z+.8,this.cam.tdist=19,this.cam.tyaw=0,this.select(null)}exitArena(){this.mode="island",this.saved&&(this.cam.tx=this.saved.x,this.cam.tz=this.saved.z,this.cam.tdist=this.saved.dist,this.cam.tyaw=this.saved.yaw)}resize(){const t=this.canvas.clientWidth||window.innerWidth,e=this.canvas.clientHeight||window.innerHeight;this.renderer.setSize(t,e,!1),this.camera.aspect=t/e,this.camera.updateProjectionMatrix()}placeCamera(){const t=this.cam,e=.18;t.x+=(t.tx-t.x)*e,t.z+=(t.tz-t.z)*e,t.dist+=(t.tdist-t.dist)*e,t.yaw+=(t.tyaw-t.yaw)*e;const n=uo.degToRad(this.mode==="arena"?32:uo.lerp(56,34,jn((t.dist-14)/52))),s=this.camera.aspect<.8?this.mode==="arena"?1.6:1.35:1,a=t.dist*s;this.camera.position.set(t.x+Math.sin(t.yaw)*Math.cos(n)*a,Math.sin(n)*a,t.z+Math.cos(t.yaw)*Math.cos(n)*a),this.camera.lookAt(t.x,0,t.z),this.sun.target.position.set(t.x,0,t.z),this.sun.position.set(t.x-.55*40,.62*40,t.z+.42*40)}focus(t,e,n){this.cam.tx=t,this.cam.tz=e,n&&(this.cam.tdist=n)}clampCam(){const t=this.cam,e=Ft/2+2;t.tx=jn(t.tx,-e,e),t.tz=jn(t.tz,-e,e),t.tdist=jn(t.tdist,12,66)}groundAt(t,e){const n=this.canvas.getBoundingClientRect();this.ptr.set((t-n.left)/n.width*2-1,-((e-n.top)/n.height)*2+1),this.ray.setFromCamera(this.ptr,this.camera);const s=new D;return this.ray.ray.intersectPlane(new Ei(new D(0,1,0),0),s)?s:null}input(){const t=this.canvas,e=new Map;let n=!1,s=0,a=null,r=!1;const o=()=>{const[c,d]=[...e.values()];return{d:Math.hypot(c.x-d.x,c.y-d.y),a:Math.atan2(d.y-c.y,d.x-c.x),cx:(c.x+d.x)/2,cy:(c.y+d.y)/2}};t.addEventListener("pointerdown",c=>{if(this.mode!=="arena"&&(t.setPointerCapture(c.pointerId),e.set(c.pointerId,{x:c.clientX,y:c.clientY,sx:c.clientX,sy:c.clientY}),n=!1,s=performance.now(),e.size===2&&(a=o()),r=!1,this.ghost&&e.size===1)){const d=this.groundAt(c.clientX,c.clientY);if(d){const[h,u]=fn({t:this.ghost.t,r:this.ghost.r}),f=this.ghost.x-Ft/2,g=this.ghost.z-Ft/2;d.x>=f-.5&&d.x<=f+h+.5&&d.z>=g-.5&&d.z<=g+u+.5&&(r=!0)}}}),t.addEventListener("pointermove",c=>{const d=e.get(c.pointerId);if(!d)return;const h=c.clientX-d.x,u=c.clientY-d.y;if(d.x=c.clientX,d.y=c.clientY,Math.hypot(d.x-d.sx,d.y-d.sy)>7&&(n=!0),!!n){if(e.size===1){if(r&&this.ghost){this.ghostTo(c.clientX,c.clientY);return}if(c.buttons===2){this.cam.tyaw-=h*.008;return}const f=this.cam.dist*.0021*(this.camera.aspect<.8?1.35:1),g=Math.cos(this.cam.yaw),x=Math.sin(this.cam.yaw);this.cam.tx-=(h*g+u*x*1.25)*f,this.cam.tz-=(-h*x+u*g*1.25)*f,this.clampCam()}else if(e.size===2&&a){const f=o();this.cam.tdist*=a.d/Math.max(1,f.d),this.cam.tyaw-=f.a-a.a,a=f,this.clampCam()}}});const l=c=>{const d=e.get(c.pointerId);e.delete(c.pointerId),e.size<2&&(a=null),!(!d||n||c.button===2)&&(performance.now()-s>600||this.tap(c.clientX,c.clientY))};t.addEventListener("pointerup",l),t.addEventListener("pointercancel",c=>e.delete(c.pointerId)),t.addEventListener("contextmenu",c=>c.preventDefault()),t.addEventListener("wheel",c=>{c.preventDefault(),this.mode!=="arena"&&(this.cam.tdist*=Math.pow(1.0015,c.deltaY),this.clampCam())},{passive:!1}),window.addEventListener("keydown",c=>{c.target.tagName!=="INPUT"&&((c.key==="q"||c.key==="Q")&&(this.cam.tyaw+=Math.PI/4),(c.key==="e"||c.key==="E")&&(this.cam.tyaw-=Math.PI/4))})}tap(t,e){if(this.ghost){this.ghostTo(t,e);return}const n=this.canvas.getBoundingClientRect();if(this.ptr.set((t-n.left)/n.width*2-1,-((e-n.top)/n.height)*2+1),this.ray.setFromCamera(this.ptr,this.camera),this.podPick&&this.pod&&this.pod.visible&&this.ray.intersectObject(this.podPick,!1)[0]){this.onTap({drop:!0});return}const s=this.ray.intersectObjects([...this.bots.values()].map(c=>c.pick),!1)[0];if(s){this.onTap({bot:s.object.userData.bot});return}const a=[...this.views.values()].map(c=>c.pick),r=this.ray.intersectObjects(a,!1)[0];if(r){this.onTap({item:r.object.userData.item});return}const o=this.ray.intersectObjects(this.island.holoMeshes(),!1)[0];if(o){this.onTap({plot:o.object.userData.plot});return}const l=this.groundAt(t,e);this.onTap(l?{tile:[Math.floor(l.x+Ft/2),Math.floor(l.z+Ft/2)]}:{})}startGhost(t){this.ghost=t,this.island.grid.visible=!0,this.rebuildGhost()}endGhost(){this.ghost=null,this.ghostObj&&this.scene.remove(this.ghostObj),this.ghostObj=null,this.island.grid.visible=!1}ghostTo(t,e){const n=this.groundAt(t,e);if(!n||!this.ghost)return;const[s,a]=fn({t:this.ghost.t,r:this.ghost.r}),r=Math.round(n.x+Ft/2-s/2),o=Math.round(n.z+Ft/2-a/2);(r!==this.ghost.x||o!==this.ghost.z)&&(this.ghost.x=r,this.ghost.z=o,this.onGhostMove())}rotateGhost(){this.ghost&&(this.ghost.r=(this.ghost.r+1)%4,this.rebuildGhost(),this.onGhostMove())}rebuildGhost(){this.ghostObj&&this.scene.remove(this.ghostObj);const t=this.ghost,[e,n]=fn({t:t.t,r:t.r}),s=new Te,a=Fc(t.t,1,t.el,this.look);a.group.rotation.y=-t.r*Math.PI/2,a.group.traverse(r=>{const o=r;o.isMesh&&(o.castShadow=!1)}),s.add(a.group),this.ghostFoot=new Pt(new ws(e,n),Ua.ghostOk),this.ghostFoot.rotation.x=-Math.PI/2,this.ghostFoot.position.y=.04,s.add(this.ghostFoot),this.ghostObj=s,this.scene.add(s)}setGhostOk(t){this.ghost&&(this.ghost.ok=t),this.ghostFoot&&(this.ghostFoot.material=t?Ua.ghostOk:Ua.ghostBad)}sync(t){this.look={primary:t.paint.primary,accent:t.paint.accent,banner:t.banner};const e=JSON.stringify(this.look),n=[];for(let c=0;c<5;c++)for(let d=0;d<5;d++){const h=`${c},${d}`;No(t,h)==="buyable"&&n.push(h)}const s=kn(t);this.island.build(s.plots,n,Sn[t.at]?Sn[t.at].theme:"haven"),this.backdrop.setWorld(Sn[t.at]?Sn[t.at].world:"earth");const a=new Set;for(const c of s.items){const[d,h]=fn(c);for(let u=c.x;u<c.x+d;u++)for(let f=c.z;f<c.z+h;f++)a.add(u+","+f)}this.island.scatter(s.plots,a);const r=new Set;for(const c of s.items){r.add(c.id);const d=Ee(t,c.id,"build"),h=c.t==="pad"&&Xe(t).exps.length<Js(c.lvl)?1:0,u=`${c.t}|${c.lvl}|${c.el}|${c.r}|${e}|${d?1:0}|${h}`;let f=this.views.get(c.id);(!f||f.key!==u)&&(f&&this.scene.remove(f.root),f=this.makeView(c,u,!!d,c.t==="pad"&&!h),this.views.set(c.id,f)),this.ghost&&this.ghost.move===c.id?f.root.visible=!1:f.root.visible=!0}for(const[c,d]of this.views)r.has(c)||(this.scene.remove(d.root),this.views.delete(c));const o=new Set;for(const c of t.bots){const d=c.post||c.bay;if(!d||Ba(t,c))continue;const h=Re(t,d);if(!h||Ji(t,d)!==t.at)continue;o.add(c.id);const u=`${c.sp}|${Math.floor(c.lvl/5)}`;let f=this.bots.get(c.id);if(!f||f.key!==u){f&&this.scene.remove(f.model.group);const g=Sd(c.sp,c.lvl),x=this.centerOf(h),m=new D(x.x+(Math.random()-.5)*1.6,.26,x.z+(Math.random()-.5)*1.6),p=new Pt(new Oe(.45,8,6),new Me({visible:!1}));p.position.y=.45,p.userData.bot=c.id,g.group.add(p),g.group.position.copy(m),this.scene.add(g.group),f={key:u,model:g,pos:m,target:m.clone(),wait:Math.random()*2,bay:d,pick:p},this.bots.set(c.id,f)}f.bay!==d&&(f.bay=d,f.wait=0)}for(const[c,d]of this.bots)o.has(c)||(this.scene.remove(d.model.group),this.bots.delete(c));const l=me(t);l.drops>0&&l.dropAt?(this.pod||(this.pod=jb(),this.podPick=new Pt(new ai(1,1.6,1),new Me({visible:!1})),this.podPick.position.y=.6,this.pod.add(this.podPick),this.pod.traverse(c=>{c.isMesh&&(c.castShadow=!0)}),this.scene.add(this.pod),this.podY=30),this.pod.position.set(l.dropAt[0]+.5-Ft/2,this.pod.position.y,l.dropAt[1]+.5-Ft/2),this.pod.visible=!0):this.pod&&(this.pod.visible=!1,this.scene.remove(this.pod),this.pod=null)}podTop(){return this.pod&&this.pod.visible?new D(this.pod.position.x,this.pod.position.y+1.6,this.pod.position.z):null}centerOf(t){const[e,n]=fn(t);return new D(t.x+e/2-Ft/2,0,t.z+n/2-Ft/2)}topOf(t){const e=this.views.get(t);if(!e)return null;const n=e.root.position.clone();return n.y=e.model.height+.3,n}makeView(t,e,n,s=!1){const a=new Te,r=Fc(t.t,t.lvl,t.el,s?{...this.look,noRocket:!0}:this.look);r.group.rotation.y=-t.r*Math.PI/2,a.add(r.group);const[o,l]=fn(t);a.position.copy(this.centerOf(t));const c=new Pt(new ai(o*.95,Math.max(.6,r.height),l*.95),new Me({visible:!1}));c.position.y=Math.max(.6,r.height)/2,c.userData.item=t.id,a.add(c);let d;return n&&(d=Qb(o,l,Math.max(.8,r.height*.8)),a.add(d),t.lvl===0&&(r.group.scale.y=.25)),this.scene.add(a),{key:e,root:a,model:r,pick:c,scaf:d}}select(t,e){if(this.selected=t,this.selRing.visible=!!t,t&&e){const n=Re(e,t);if(!n)return;const[s,a]=fn(n),r=this.centerOf(n);this.selRing.position.set(r.x,.05,r.z),this.selRing.scale.setScalar(Math.max(s,a)*.72)}}burst(t,e,n=26){const s=new Float32Array(n*3),a=new Float32Array(n*3);for(let l=0;l<n;l++){s.set([t.x,t.y,t.z],l*3);const c=Math.random()*Math.PI*2,d=Math.random();a.set([Math.cos(c)*d*2.2,2+Math.random()*3,Math.sin(c)*d*2.2],l*3)}const r=new ge;r.setAttribute("position",new Ne(s,3));const o=new Wa(r,new sa({color:e,size:.22,transparent:!0,depthWrite:!1,blending:Zi}));this.scene.add(o),this.fx.push({pts:o,v:a,life:1})}project(t){const e=new D(t.x,t.y,t.z).project(this.camera),n=this.canvas.getBoundingClientRect();return{x:n.left+(e.x*.5+.5)*n.width,y:n.top+(-e.y*.5+.5)*n.height,vis:e.z<1&&e.z>-1}}frame(t,e){this.t+=t;const n=this.t;if(this.mode==="map"&&this.system){this.system.syncShips(Xe(e).exps,Date.now()),this.system.frame(t,this.renderer);return}for(const s of[...this.rockets]){s.t+=t;const a=Math.min(60,s.t*s.t*2.2);s.g.position.y=.3+a,s.g.rotation.y+=t*.4;const r=s.smoke.geometry.attributes.position;for(let o=0;o<r.count;o++)r.getY(o)===0&&Math.random()<.3&&s.t<3?(r.setXYZ(o,s.g.position.x,s.g.position.y-.4,s.g.position.z),s.v.set([(Math.random()-.5)*1.2,-.5-Math.random(),(Math.random()-.5)*1.2],o*3)):r.getY(o)!==0&&(r.setXYZ(o,r.getX(o)+s.v[o*3]*t,Math.max(.05,r.getY(o)+s.v[o*3+1]*t),r.getZ(o)+s.v[o*3+2]*t),s.v[o*3]*=.98,s.v[o*3+2]*=.98);r.needsUpdate=!0,s.smoke.material.opacity=Math.max(0,.75-Math.max(0,s.t-3)*.25),s.t>6&&(this.scene.remove(s.g,s.smoke),s.smoke.geometry.dispose(),this.rockets.splice(this.rockets.indexOf(s),1))}this.mode==="arena"&&(this.cam.tyaw=Math.sin(n*.15)*.35,this.arena?.update(t)),this.placeCamera(),this.backdrop.update(n,this.camera),this.island.update(n);for(const[s,a]of this.views){const r=!!(Ee(e,s,"craft")||Ee(e,s,"fuse")),o=Re(e,s),l=o&&o.t==="assembly"?e.cores.filter(c=>c.state!=="waiting").map(c=>({color:qt[tt[c.sp].rarity].color,ready:c.state==="ready"})):void 0;if(a.model.anim?.(n,{working:r,ready:e.ready[s]?1:0,cores:l}),a.scaf){const c=a.scaf.getObjectByName("crane");c&&(c.rotation.y=n*.8)}}for(const[,s]of this.bots){const a=Re(e,s.bay);if(!a)continue;const r=this.centerOf(a),o=s.target.clone().sub(s.pos);o.y=0;const l=o.length();let c=!1;if(l>.05){c=!0,o.normalize(),s.pos.addScaledVector(o,Math.min(l,t*(l>2?2.2:.7))),s.pos.y+=(s.target.y-s.pos.y)*Math.min(1,t*4);const d=Math.atan2(o.x,o.z),h=s.model.group;let u=d-h.rotation.y;u=Math.atan2(Math.sin(u),Math.cos(u)),h.rotation.y+=u*Math.min(1,t*6)}else if(s.wait-=t,s.wait<=0){const d=Math.random()*Math.PI*2,h=a.t==="bay"||a.t==="relicbay",[u,f]=fn(a),g=h?.35+Math.random()*.75:Math.max(u,f)/2+.25+Math.random()*.3;s.target.set(r.x+Math.cos(d)*g,h?.26:0,r.z+Math.sin(d)*g),s.wait=(h?1.5:3)+Math.random()*4}s.model.group.position.copy(s.pos),s.model.anim(n,c)}if(this.selRing.visible&&(this.selRing.material.opacity=.55+Math.sin(n*4)*.3),this.pod&&this.pod.visible){this.podY=Math.max(0,this.podY-t*Math.max(4,this.podY*1.6)),this.pod.position.y=this.podY;const s=this.pod.userData.flame;s.visible=this.podY>.05,s.scale.y=.8+Math.random()*.5,this.pod.userData.beacon.material.color.set(Math.sin(n*5)>0?"#7cf29a":"#1a4a2a"),this.pod.rotation.y+=t*(this.podY>0?2:0)}if(this.ghost&&this.ghostObj){const[s,a]=fn({t:this.ghost.t,r:this.ghost.r});this.ghostObj.position.set(this.ghost.x+s/2-Ft/2,.02+Math.sin(n*5)*.03,this.ghost.z+a/2-Ft/2)}for(const s of[...this.fx]){s.life-=t*1.1;const a=s.pts.geometry.attributes.position;for(let r=0;r<a.count;r++)s.v[r*3+1]-=t*6,a.setXYZ(r,a.getX(r)+s.v[r*3]*t,a.getY(r)+s.v[r*3+1]*t,a.getZ(r)+s.v[r*3+2]*t);a.needsUpdate=!0,s.pts.material.opacity=Math.max(0,s.life),s.life<=0&&(this.scene.remove(s.pts),s.pts.geometry.dispose(),this.fx.splice(this.fx.indexOf(s),1))}this.renderer.render(this.scene,this.camera)}}class T_{constructor(t){this.renderer=t,this.scene=new Bo,this.cam=new gn(30,1,.1,100),this.cache=new Map,this.size=192,this.rt=new Bn(this.size,this.size,{samples:4}),this.rt.texture.colorSpace=Je;const e=new xo("#fff3df",2.6);e.position.set(-3,5,4),this.scene.add(e,new Bf("#cfe4ff","#3a2a22",1.1));const n=new xo("#7ab6ff",.9);n.position.set(4,2,-4),this.scene.add(n)}shoot(t,e,n,s){const a=this.cache.get(e);if(a)return a;this.scene.add(t),this.cam.position.set(n*.7,s+n*.55,n*.85),this.cam.lookAt(0,s*.45,0);const r=this.renderer.getRenderTarget(),o=this.renderer.getClearColor(new Rt),l=this.renderer.getClearAlpha(),c=this.renderer.shadowMap.enabled;this.renderer.setClearColor(0,0),this.renderer.setRenderTarget(this.rt),this.renderer.clear(),this.renderer.render(this.scene,this.cam);const d=new Uint8Array(this.size*this.size*4);this.renderer.readRenderTargetPixels(this.rt,0,0,this.size,this.size,d),this.renderer.setRenderTarget(r),this.renderer.setClearColor(o,l),this.renderer.shadowMap.enabled=c,this.scene.remove(t);const h=document.createElement("canvas");h.width=h.height=this.size;const u=h.getContext("2d"),f=u.createImageData(this.size,this.size);for(let x=0;x<this.size;x++)f.data.set(d.subarray((this.size-1-x)*this.size*4,(this.size-x)*this.size*4),x*this.size*4);u.putImageData(f,0,0);const g=h.toDataURL("image/png");return this.cache.set(e,g),g}building(t,e,n,s){const a=Fc(t,e,n,s),[r,o]=Qt[t].size,l=Math.max(r,o);return this.shoot(a.group,`b|${t}|${e}|${n}|${s.primary}${s.accent}${s.banner.bg}${s.banner.fg}${s.banner.emblem}`,l*1.55+.8,Math.max(.6,a.height*.6))}bot(t){const e=Sd(t,1);e.group.rotation.y=.5;const n=e.group.getObjectByName("hoverGlow");return n&&(n.visible=!1),this.shoot(e.group,`bot|${t}`,1.75,.55)}}const ds={credits:'<span class="ic cr">C</span>',cells:'<span class="ic ce">⚡</span>',dm:'<span class="ic dm">◆</span>'},kr=i=>`<span class="els">${i.map(t=>`<span class="el" style="background:${kt[t].color}" title="${kt[t].name}">${kt[t].glyph}</span>`).join("")}</span>`,zr=i=>{const t=qt[tt[i].rarity];return`<span class="rar" style="color:${t.color}">${t.name}</span>`},Gs=i=>i.t==="bay"?`${kt[i.el].name} Bay`:Qt[i.t].name;class R_{constructor(t){this.ui=t,this.fuseA=null,this.fuseB=null,this.dexR="all",this.picking=null}get s(){return this.ui.app.s}get app(){return this.ui.app}img(t,e=!0,n=0){return`<img src="${this.app.studio.bot(t)}" alt="" style="${n?`width:${n}px;height:${n}px;`:""}${e?"":"filter:brightness(0) opacity(0.55)"}">`}botPanel(t){const e=this.s,n=tt[t.sp],s=ea(t),a=Do(t.lvl);let r=0;for(let l=t.fed;l<4;l++)r+=a;const o=t.post?`Helping at the ${Gs(Re(e,t.post))}`:t.stored?"In storage (not earning)":t.bay?`Lives in the ${Gs(Re(e,t.bay))}`:"";return`<button class="ibtn x" data-a="deselect">✕</button><div class="row" style="align-items:flex-start;gap:12px"><div class="pic" style="width:96px;height:96px;border-radius:16px;background:radial-gradient(circle at 50% 40%, ${kt[n.el[0]].color}66, transparent 70%);flex:none;display:grid;place-items:center;overflow:hidden">${this.img(t.sp,!0,96)}</div>
      <div class="grow"><h2>${ut(t.nick||n.name)} <button class="btn small" data-a="rename" data-bot="${t.id}" style="min-height:26px;padding:2px 8px">✎</button></h2><div class="sub">${t.nick?ut(n.name)+" · ":""}${zr(t.sp)} · ${kr(n.el)}</div>
      <div class="sub">Level ${t.lvl}<span class="pips">${[0,1,2,3].map(l=>`<i class="${l<t.fed?"on":""}"></i>`).join("")}</span></div><div class="sub">${ut(o)}</div></div></div>
      <p class="desc">${ut(n.desc)}</p><table class="stats"><tr><td>Earns</td><td>${t.post||t.stored?"<s>":""}${ds.credits} ${st(wi(t))}/min${t.post||t.stored?"</s>":""}</td></tr><tr><td>Hull · attack</td><td>${st(s.hp)} · ${st(s.atk)}</td></tr><tr><td>Moves from</td><td>${n.el.map(l=>kt[l].name).join(", ")}</td></tr></table>
      ${t.lvl<Lo?`<div class="row"><button class="btn green small grow" data-a="feed" data-bot="${t.id}"><span class="cost" data-cost="cells:${a}">${ds.cells}${st(a)}</span> Feed</button><button class="btn green small grow" data-a="feedLvl" data-bot="${t.id}"><span class="cost" data-cost="cells:${r}">${ds.cells}${st(r)}</span> To level ${t.lvl+1}</button></div>`:'<p class="sub">Maximum level.</p>'}
      <div class="row" style="margin-top:8px">${t.stored?`<button class="btn small" data-a="unstore" data-bot="${t.id}">⬆ Activate</button>`:`<button class="btn small" data-a="pickBay" data-bot="${t.id}">⇄ Move</button>${t.post?`<button class="btn small" data-a="unpost" data-bot="${t.id}">↩ Back to bay</button>`:`<button class="btn small" data-a="pickPost" data-bot="${t.id}">🛠 Help a building</button>`}<button class="btn small" data-a="store" data-bot="${t.id}">❄ Store</button>`}
      <button class="btn small" data-a="release" data-bot="${t.id}">Release (${ds.credits}${st(Ru(t))})</button></div>`}helpersHTML(t){if(!Si[t.t]||t.lvl<1)return"";const e=this.s,n=to(e,t.id),s=Qs(t.lvl),a=Za(e,t);return`<div class="sub" style="margin-top:10px">Helpers · +${Math.round(a*100)}% ${Xd[t.t]} · best: ${Si[t.t].map(r=>kt[r].glyph).join(" ")} bots</div><div class="row">${n.map(r=>`<button class="btn small" data-a="selBot" data-bot="${r.id}" style="padding:2px 8px 2px 2px"><img src="${this.app.studio.bot(r.sp)}" style="width:30px;height:30px">L${r.lvl}</button>`).join("")}${n.length<s?`<button class="btn small" data-a="pickHelper" data-id="${t.id}">＋ Add helper (${n.length}/${s})</button>`:""}</div>`}fusionHTML(t){const e=this.s,n=Ee(e,t.id,"fuse");let s="";if(n){const a=ui((n.end-Date.now())/1e3);s+=`<div class="row" style="justify-content:center;gap:16px;margin:6px 0">${(n.parents||[]).map(r=>{const o=e.bots.find(l=>l.id===r);return o?`<div style="width:70px;text-align:center">${this.img(o.sp,!0,64)}<div class="sub" style="margin:0">L${o.lvl}</div></div>`:""}).join('<b style="font-size:24px">+</b>')}</div>
      <p class="desc" style="text-align:center">Fusing… the new core's rarity is revealed when it is done.</p><div class="bar"><i data-bar="${n.id}"></i></div><div class="row" style="margin-top:8px"><b class="grow" data-left="${n.id}"></b><button class="btn gold small" data-a="finish" data-job="${n.id}" data-dm="${n.id}">${a?`${ds.dm}${a} Finish now`:"Finish (free)"}</button></div>`}else{const a=e.bots.find(l=>l.id===this.fuseA),r=e.bots.find(l=>l.id===this.fuseB),o=(l,c)=>`<button class="card" data-a="pickFuse" data-slot="${c}" style="width:46%;align-items:center;min-height:120px">${l?`${this.img(l.sp,!0,72)}<b>${ut(l.nick||tt[l.sp].name)}</b><span class="sub" style="margin:0">L${l.lvl} ${kr(tt[l.sp].el)}</span>`:`<span style="font-size:34px;opacity:.6">＋</span><span class="sub" style="margin:0">Pick a bot<br>(level ${qi}+)</span>`}</button>`;if(s+=`<p class="desc">Fuse two bots of level ${qi} or more. Both parents stay with you; the child's elements come from both.</p><div class="row" style="justify-content:space-between">${o(a,"A")}${o(r,"B")}</div>`,a&&r&&a!==r){const l=Eu(a,r),c=Au(e,t,a.id,r.id);s+=`<div class="sub" style="margin-top:10px">Possible results</div><div class="bots" style="grid-template-columns:repeat(auto-fill,minmax(92px,1fr))">${l.map(d=>{const h=!!e.dex[d.sp];return`<div class="rec"><div style="width:56px;height:56px">${this.img(d.sp,h,56)}</div><b>${h?ut(tt[d.sp].name):"???"}</b>${zr(d.sp)}<span class="out" style="font-size:13px">${(d.p*100).toFixed(d.p<.1?1:0)}%</span></div>`}).join("")}</div>
          <div class="row" style="margin-top:8px"><span class="grow"><span class="cost ${e.res.credits<(c.cost||0)?"short":""}" data-cost="credits:${c.cost||Hl(a,r)}">${ds.credits}${st(c.cost||Hl(a,r))}</span> · ${pe(Gl(e,t,l[l.length-1].sp))}–${pe(Gl(e,t,l[0].sp))}</span><button class="btn gold" data-a="fuse" data-id="${t.id}" ${c.ok?"":"disabled"}>🧬 Fuse</button></div>${c.ok?"":`<p class="why">${ut(c.why||"")}</p>`}`}}return s+this.helpersHTML(t)}assemblyHTML(t){const e=this.s,n=e.cores.map(s=>{const a=e.jobs.find(l=>l.kind==="boot"&&l.core===s.id),r=qt[tt[s.sp].rarity],o=`<div class="pic" style="width:48px;height:48px;border-radius:50%;background:radial-gradient(circle at 40% 35%, #fff, ${r.color} 45%, ${r.color}55 70%, transparent 72%)"></div>`;if(s.state==="ready")return`<div class="botc">${o}<div><b style="color:${r.color}">${r.name} core</b><div class="meta">Booted: ready to activate</div></div><button class="btn gold small" data-a="activate" data-core="${s.id}">Activate</button></div>`;if(a){const l=ui((a.end-Date.now())/1e3);return`<div class="botc">${o}<div><b style="color:${r.color}">${r.name} core</b><div class="meta">Booting · <span data-left="${a.id}">${pe((a.end-Date.now())/1e3)}</span></div><div class="bar" style="margin-top:4px"><i data-bar="${a.id}"></i></div></div><button class="btn gold small" data-a="finish" data-job="${a.id}" data-dm="${a.id}">${l?`${ds.dm}${l}`:"Free"}</button></div>`}return`<div class="botc">${o}<div><b style="color:${r.color}">${r.name} core</b><div class="meta">Queued: waiting for a free pod</div></div><span></span></div>`}).join("");return`<p class="desc">${Fa(t.lvl)} pod${Fa(t.lvl)>1?"s":""} boot cores side by side. Cores arrive from the shop (Advanced bots), the Fusion Lab and events.</p><div class="bots">${n||'<p class="desc">No cores right now.</p>'}</div>`+this.helpersHTML(t)}picker(t,e){this.ui.modal(`<h1 style="font-size:20px">${t}</h1><div class="bots" style="max-height:56vh;overflow:auto;text-align:left">${e||'<p class="desc">Nobody fits yet.</p>'}</div><button class="btn" data-a="closeModal" style="margin-top:10px">Cancel</button>`)}pickRow(t,e,n="",s="Pick"){const a=tt[t.sp];return`<div class="botc"><div class="pic">${this.img(t.sp)}</div><div><b>${ut(t.nick||a.name)}</b> ${kr(a.el)}<div class="meta">${zr(t.sp)} · L${t.lvl}${t.post?" · helping":""}${t.stored?" · stored":""}</div></div><button class="btn small gold" data-a="${e}" data-bot="${t.id}" ${n}>${s}</button></div>`}dexHTML(){const t=this.s,e=Gc(t),n=We.map(a=>[a,Qn.filter(r=>tt[r].rarity===a).length,Qn.filter(r=>tt[r].rarity===a&&t.dex[r]).length]),s=Qn.filter(a=>this.dexR==="all"||tt[a].rarity===this.dexR);return`<div class="head"><h1>Botdex</h1><span class="sub">${e} / ${Qn.length} discovered</span><button class="ibtn" data-a="close">✕</button></div>
      <div class="tabs"><button class="tab ${this.dexR==="all"?"on":""}" data-a="dexR" data-r="all">All</button>${n.map(([a,r,o])=>`<button class="tab ${this.dexR===a?"on":""}" data-a="dexR" data-r="${a}" style="color:${qt[a].color}">${qt[a].name} ${o}/${r}</button>`).join("")}</div>
      <div class="body"><p class="sub" style="text-align:center">Every new species pays Dark Matter (${wu.map((a,r)=>`<span style="color:${qt[We[r]].color}">${a}</span>`).join(" · ")} by rarity). Elements are shown so you can plan fusions.</p>
      <div class="grid" style="grid-template-columns:repeat(auto-fill,minmax(132px,1fr))">${s.map(a=>{const r=tt[a],o=!!t.dex[a],l=o?`${t.bots.filter(c=>c.sp===a).length} owned`:r.alien==="contact"?"First contact":r.alien==="swarm"?"Defeat the Swarm":r.price?`Shop · level ${r.unlock}`:r.el.length>1?"Fusion":"";return`<div class="card" style="align-items:center;text-align:center;gap:3px;${o?"":"opacity:.8"}"><div class="thumb" style="height:96px;width:100%">${this.img(a,o)}</div><b>${o?ut(r.name):"???"}</b>${zr(a)}${kr(r.el)}<span class="sub" style="margin:0">${l}</span></div>`}).join("")}</div></div>`}act(t,e){const n=this.s,s=this.app,a=this.ui,r=e.dataset.bot?n.bots.find(o=>o.id===e.dataset.bot):void 0;switch(t){case"selBot":return r&&(a.closeModal(),a.selectBot(r.id),s.audio.play("tap")),!0;case"feedLvl":if(r){let o=!1,l=0;for(;r.fed>0||!o;){const c=Yc(n,r);if(!c.ok){l||a.deny(c.why);break}if(l++,c.lvlUp){o=!0;break}}if(l){s.audio.play(o?"done":"feed");const c=e.getBoundingClientRect();a.popText(c.left+c.width/2,c.top,o?`Level ${r.lvl}!`:`+${l} feeds`,o?"#ffd36a":"#9dff5a"),s.changed(),a.renderPanel()}}return!0;case"rename":if(r){const o=prompt("Name this bot",r.nick||tt[r.sp].name);if(o!==null){const l=o.trim().slice(0,18);l&&l!==tt[r.sp].name?r.nick=l:delete r.nick,s.changed(),a.renderPanel()}}return!0;case"pickBay":if(r){const o=zt(n,"bay").filter(l=>l.lvl>0&&l.el&&tt[r.sp].el.includes(l.el)&&l.id!==r.bay);this.ui.modal(`<h1 style="font-size:20px">Move ${ut(r.nick||tt[r.sp].name)}</h1><div class="bots" style="text-align:left">${o.map(l=>{const c=Rn(n,l.id).length,d=Jn(l.lvl);return`<div class="botc"><div class="pic" style="background:${kt[l.el].color}44">${kt[l.el].glyph}</div><div><b>${Gs(l)}</b><div class="meta">Level ${l.lvl} · ${c}/${d} bots</div></div><button class="btn small gold" data-a="moveTo" data-bot="${r.id}" data-id="${l.id}" ${c<d?"":"disabled"}>Move</button></div>`}).join("")||`<p class="desc">No other ${tt[r.sp].el.map(l=>kt[l].name).join("/")} Bay yet.</p>`}</div><button class="btn" data-a="closeModal" style="margin-top:10px">Cancel</button>`)}return!0;case"moveTo":return r&&e.dataset.id&&(Ku(n,r,e.dataset.id)?(delete r.post,s.audio.play("place"),a.closeModal(),s.changed(),a.renderPanel()):a.deny("That bay is full")),!0;case"pickPost":if(r){const o=Ro(n).filter(l=>Si[l.t]&&l.lvl>0);this.ui.modal(`<h1 style="font-size:20px">Where should ${ut(r.nick||tt[r.sp].name)} help?</h1><p class="sub">A helper stops earning credits while it works. Bots with a matching element help 50% more.</p><div class="bots" style="text-align:left">${o.map(l=>{const c=Tu(n,r,l),d=tt[r.sp].el.some(h=>Si[l.t].includes(h));return`<div class="botc"><div class="pic" style="background:rgba(110,231,255,.12)">${{command:"🏛",fab:"⚡",fusion:"🧬",assembly:"🤖"}[l.t]||"🏗"}</div><div><b>${Gs(l)}</b><div class="meta">${Xd[l.t]}${d?' · <b style="color:#7cf29a">element match</b>':""} · ${to(n,l.id).length}/${Qs(l.lvl)}</div></div><button class="btn small gold" data-a="postTo" data-bot="${r.id}" data-id="${l.id}" ${c.ok?"":"disabled"}>Assign</button></div>`}).join("")}</div><button class="btn" data-a="closeModal" style="margin-top:10px">Cancel</button>`)}return!0;case"postTo":if(r&&e.dataset.id){const o=Re(n,e.dataset.id),l=Bp(n,r,o);l.ok?(s.audio.play("place"),a.closeModal(),s.changed(),a.renderPanel(),a.toast(`${r.nick||tt[r.sp].name} is now helping at the ${Gs(o)}`,"good")):a.deny(l.why)}return!0;case"pickHelper":{const o=Re(n,e.dataset.id||"");if(!o)return!0;const l=n.bots.filter(c=>!c.stored&&c.post!==o.id).sort((c,d)=>Number(tt[d.sp].el.some(h=>Si[o.t].includes(h)))-Number(tt[c.sp].el.some(h=>Si[o.t].includes(h)))||d.lvl-c.lvl);return this.picker(`Helper for the ${Gs(o)}`,l.map(c=>this.pickRow(c,"postTo",`data-id="${o.id}"`,tt[c.sp].el.some(d=>Si[o.t].includes(d))?"Assign ★":"Assign")).join("")),!0}case"unpost":return r&&(kp(r),s.changed(),a.renderPanel(),s.audio.play("tap")),!0;case"store":return r&&(zp(n,r),s.changed(),a.renderPanel(),s.audio.play("tap"),a.toast("Stored: it stops earning until you activate it","")),!0;case"unstore":if(r){const o=$p(n,r);o.ok?(s.audio.play("place"),s.changed(),a.renderPanel()):a.deny(o.why)}return!0;case"release":if(r){if(!e.dataset.sure)return e.dataset.sure="1",e.innerHTML="Tap again to release",!0;const o=Hp(n,r);o.ok?(s.audio.play("buy"),a.select(null),s.changed(),a.toast(`Released for ${st(o.cost||0)} credits`,"gold")):a.deny(o.why)}return!0;case"pickFuse":{const o=e.dataset.slot,l=o==="A"?this.fuseB:this.fuseA,c=n.bots.filter(d=>d.lvl>=qi&&d.id!==l).sort((d,h)=>We.indexOf(tt[h.sp].rarity)-We.indexOf(tt[d.sp].rarity)||h.lvl-d.lvl);return this.picking={kind:"fuse",ctx:o},this.picker(`Parent ${o}`,c.map(d=>this.pickRow(d,"fusePick",`data-slot="${o}"`)).join("")||`<p class="desc">No bots at level ${qi} yet: feed your crew Power Cells.</p>`),!0}case"fusePick":return r&&(e.dataset.slot==="A"?this.fuseA=r.id:this.fuseB=r.id,a.closeModal(),a.renderPanel(),s.audio.play("tap")),!0;case"fuse":{const o=Re(n,e.dataset.id||"");if(!o||!this.fuseA||!this.fuseB)return!0;const l=Up(n,o,this.fuseA,this.fuseB);return l.ok?(s.audio.play("build"),this.fuseA=this.fuseB=null,s.changed(),a.renderPanel(),a.toast("Fusion started","good")):a.deny(l.why),!0}case"activate":{const o=Op(n,e.dataset.core||"");return o.ok&&o.bot?(s.audio.play("levelup"),s.changed(),a.renderPanel(),a.newBot(o.bot),o.bot.stored&&a.toast("No room in a matching bay: it waits in storage","gold")):a.deny(o.why),!0}case"dexR":return this.dexR=e.dataset.r||"all",a.renderOver(),s.audio.play("tap"),!0}return!1}}const Ra={credits:'<span class="ic cr">C</span>',cells:'<span class="ic ce">⚡</span>',dm:'<span class="ic dm">◆</span>'},$r=i=>Object.entries(i).filter(([,t])=>t>0).map(([t,e])=>`<span class="cost">${Ra[t]||""}${st(e)}</span>`).join(" "),vu=(i,t=34)=>`<span style="display:inline-block;width:${t}px;height:${t}px;border-radius:50%;background:radial-gradient(circle at 40% 35%, #fff, ${qt[i].color} 45%, ${qt[i].color}55 70%, transparent 72%);vertical-align:middle"></span>`;class C_{constructor(t){this.ui=t,this.tab="calendar"}get s(){return this.ui.app.s}get app(){return this.ui.app}hudHTML(){const t=this.s,e=jr(t),n=me(t),s=o=>o?'<i class="rdot"></i>':"",a=t.raid;return`${a&&a.eta?`<button class="chip raid" data-a="raid">⚠ Swarm ${pe((a.eta-Date.now())/1e3)}</button>`:""}<button class="ibtn" data-a="daily" title="Daily rewards">📅${s(e.day||e.missions||e.ach)}</button><button class="ibtn" data-a="spin" title="Free daily core">🎁${s(e.spin)}</button><button class="chip ${n.drops?"hot":""}" data-a="drop" title="Supply drop">📦 <span id="dropT">${n.drops?`Open${n.drops>1?" ×"+n.drops:""}!`:pe((n.drop-Date.now())/1e3)}</span></button>`}overHTML(){const t=this.s,e=me(t),n=jr(t),s=[["calendar","Calendar",n.day],["missions","Missions",n.missions],["ach","Achievements",n.ach]];let a="";if(this.tab==="calendar"){const r=Xo(t);a=`<div class="row" style="justify-content:center;gap:18px;margin-bottom:10px"><div class="ox" style="font-size:18px">🔥 ${e.streak} day streak</div><div class="sub" style="margin:0">Best ${e.best} · ${e.total} days in all${e.cycle?` · cycle ${e.cycle+1}`:""}</div></div>
        <p class="sub" style="text-align:center">Rewards grow every day. Miss a day and the calendar simply waits for you: it never resets.</p><div class="cal">${Array.from({length:28},(o,l)=>{const c=_d(t,l),d=l<e.day,h=l===e.day&&r,u=c.core?vu(c.core,30):c.decor?'<span style="font-size:26px">🌟</span>':c.res.dm&&!c.res.credits&&!c.res.cells?'<span style="font-size:22px">◆</span>':"";return`<div class="day ${d?"done":""} ${h?"today":""} ${bd[l]?"special":""}" ${h?'data-a="claimDay"':""}><b>Day ${l+1}</b>${u}<span class="dr">${$r(c.res)}</span>${c.label?`<span class="lbl">${ut(c.label)}</span>`:""}${d?'<span class="tick">✓</span>':""}</div>`}).join("")}</div>
        ${r?`<div class="row" style="justify-content:center;margin-top:12px"><button class="btn gold" data-a="claimDay">Claim day ${e.day+1}</button>${this.app.platform.adsAvailable?'<button class="btn" data-a="claimDayAd">▶ Watch an ad: double it</button>':""}</div>`:`<p class="sub" style="text-align:center;margin-top:12px">Come back tomorrow for day ${e.day+1}.</p>`}`}else this.tab==="missions"?(Xa(t),a=`<p class="sub" style="text-align:center">New missions every day. Finish all three for the bonus chest.</p><div class="bots" style="max-width:520px;margin:0 auto">${e.missions.map((r,o)=>{const l=Math.min(r.n,qo(t,r)),c=l>=r.n,d=e.mClaimed[o];return`<div class="botc" style="grid-template-columns:1fr auto"><div><b>${ut(r.text)}</b><div class="bar" style="margin:6px 0 4px"><i style="width:${l/r.n*100}%"></i></div><div class="meta">${st(l)} / ${st(r.n)} · reward ${$r(r.reward)}</div></div>${d?'<span class="sub">✓ Done</span>':`<button class="btn ${c?"gold":""} small" data-a="claimMission" data-i="${o}" ${c?"":"disabled"}>Claim</button>`}</div>`}).join("")}
        <div class="botc chest ${Zs(t)?"ready":""}" style="grid-template-columns:54px 1fr auto"><div style="font-size:36px;text-align:center">🧰</div><div><b>Bonus chest</b><div class="meta">Dark Matter, Power Cells and a chance of an Advanced or Elite core</div></div>${e.bonus?'<span class="sub">✓ Opened</span>':`<button class="btn ${Zs(t)?"gold":""} small" data-a="claimBonus" ${Zs(t)?"":"disabled"}>Open</button>`}</div></div>`):a=`<div class="bots" style="max-width:620px;margin:0 auto">${Ko.map(r=>{const o=Zo(t,r),l=r.stat(t),c=o>=r.tiers.length,d=r.tiers[Math.min(o,r.tiers.length-1)];return`<div class="botc" style="grid-template-columns:44px 1fr auto"><div style="font:700 16px Oxanium;text-align:center;color:${["#9aa7b8","#cd7f32","#c0c8d4","#ffd36a","#7af7ff"][o]}">${["☆","★","★★","★★★","✦"][o]}</div><div><b>${ut(r.name)}</b> <span class="sub">tier ${Math.min(o+1,r.tiers.length)}/${r.tiers.length}</span><div class="bar" style="margin:5px 0 3px"><i style="width:${c?100:Math.min(100,l/d*100)}%"></i></div><div class="meta">${st(l)} / ${st(d)} ${ut(r.unit)}</div></div>
          ${c?'<span class="sub">Complete</span>':`<button class="btn ${Ya(t,r)?"gold":""} small" data-a="claimAch" data-id="${r.id}" ${Ya(t,r)?"":"disabled"}>${Ra.dm}${_o[o]}</button>`}</div>`}).join("")}</div>`;return`<div class="head"><h1>Daily</h1><button class="ibtn" data-a="close">✕</button></div><div class="tabs">${s.map(([r,o,l])=>`<button class="tab ${this.tab===r?"on":""}" data-a="dtab" data-t="${r}">${o}${l?' <i class="rdot" style="position:static;display:inline-block"></i>':""}</button>`).join("")}</div><div class="body">${a}</div>`}giftLine(t){if(!t)return"";const e=tt[t.sp].rarity;return`<div class="gift" style="--rc:${qt[e].color}">${vu(e,40)}<span><b style="color:${qt[e].color}">${qt[e].name} core!</b><br><span class="sub" style="margin:0">${t.core?zt(this.s,"assembly").some(n=>n.lvl>0)?"Booting in the Assembly Bay":"Waits for your Assembly Bay":"Joined your crew"}</span></span></div>`}dropReveal(t){const e=Object.entries(t.res).map(([n,s],a)=>`<div class="loot" style="animation-delay:${.25+a*.22}s">${Ra[n].replace('class="ic','style="width:38px;height:38px;font-size:18px" class="ic')}<b>+${st(s)}</b></div>`).join("");this.ui.modal(`<div class="ox sub" style="letter-spacing:.2em">SUPPLY DROP</div><div style="font-size:64px;line-height:1;margin:6px 0;animation:zoom .5s">📦</div><div class="lootrow">${e}</div>${t.gift?`<div style="animation:zoom .4s ${.3+Object.keys(t.res).length*.22}s both">${this.giftLine(t.gift)}</div>`:""}<button class="btn gold" data-a="closeModal" style="min-width:160px;margin-top:12px">Nice!</button>`,!0)}spinReveal(t){const e=Qn.filter(h=>["standard","advanced","elite"].includes(tt[h].rarity)),n=34,s=29,a=[];for(let h=0;h<n;h++){const u=h===s?t.sp:e[Math.floor(Math.random()*e.length)],f=tt[u].rarity;a.push(`<div class="rc" style="--rc:${qt[f].color}"><img src="${this.app.studio.bot(u)}"></div>`)}this.ui.modal(`<div class="ox sub" style="letter-spacing:.2em">DAILY CORE</div><div class="reel"><div class="strip" id="strip">${a.join("")}</div><div class="needle"></div></div><div id="spinRes" style="min-height:96px"></div><button class="btn gold hidden" id="spinOk" data-a="closeModal" style="min-width:160px">Collect</button>`);const r=document.getElementById("strip"),o=96;requestAnimationFrame(()=>{r.style.transition="transform 4.2s cubic-bezier(.12,.62,.16,1)";const h=r.parentElement.clientWidth;r.style.transform=`translateX(${-2784+h/2-o/2}px)`});let l=0;const c=()=>{const h=new DOMMatrix(getComputedStyle(r).transform),u=Math.floor(-h.m41/o);u!==l&&(l=u,this.app.audio.play("tap"))},d=window.setInterval(c,30);window.setTimeout(()=>{clearInterval(d);const h=tt[t.sp],u=qt[h.rarity];this.app.audio.play(We.indexOf(h.rarity)>=1?"levelup":"claim"),document.getElementById("spinRes").innerHTML=`<h1 style="color:${u.color};margin:10px 0 2px">${ut(h.name)}</h1><div class="rar" style="color:${u.color}">${u.name}${this.s.dex[t.sp]&&Date.now()-this.s.dex[t.sp]<6e3?" · NEW SPECIES":""}</div><p class="sub">${t.core?zt(this.s,"assembly").some(f=>f.lvl>0)?"Its core is booting in the Assembly Bay.":"Its core waits for your Assembly Bay (Commander level 4).":"It joined your crew."}</p>`,document.getElementById("spinOk").classList.remove("hidden")},4300)}offlineReport(t,e){const n=jr(this.s),s=[];return e.credits>=1&&s.push(`${Ra.credits} <b>${st(e.credits)}</b> credits waiting in ${e.bays} bay${e.bays>1?"s":""}`),e.ready&&s.push(`${Ra.cells} <b>${e.ready}</b> fabricator recipe${e.ready>1?"s":""} ready to harvest`),e.built&&s.push(`🏗 <b>${e.built}</b> construction${e.built>1?"s":""} finished`),e.cores&&s.push(`🤖 <b>${e.cores}</b> core${e.cores>1?"s":""} booted and ready`),n.drop&&s.push("📦 A supply drop has landed"),n.day&&s.push("📅 Today's calendar reward is waiting"),n.spin&&s.push("🎁 Your free daily core is ready"),s.length?(this.ui.modal(`<div class="ox sub" style="letter-spacing:.2em">WELCOME BACK</div><h1>While you were away</h1><p class="sub">${pe(t/1e3)} in orbit. Your crew kept working.</p><div class="report">${s.map(a=>`<div>${a}</div>`).join("")}</div>${e.credits>=1||e.ready?'<button class="btn gold" data-a="collectAll" style="min-width:180px">Collect everything</button>':`<button class="btn gold" data-a="closeModal">Let's go</button>`}`,!0),!0):!1}act(t,e){const n=this.s,s=this.app,a=this.ui;switch(t){case"daily":return Xa(n),a.openOver("daily"),s.audio.play("tap"),!0;case"dtab":return this.tab=e.dataset.t,a.renderOver(),s.audio.play("tap"),!0;case"claimDay":case"claimDayAd":{const r=o=>{const l={...n.res},c=ip(n);if(!c)return;o&&Cn(n,c.res),s.audio.play("claim"),s.changed(),a.renderOver(),a.renderHud();const d={};for(const h of["credits","cells","dm"]){const u=n.res[h]-l[h];u>0&&(d[h]=u)}a.modal(`<div class="ox sub" style="letter-spacing:.2em">DAY ${c.day+1}</div><h1>Daily reward</h1><div class="rewards">${$r(d)}</div>${this.giftLine(c.gift)}${c.decor?'<div class="gift"><span style="font-size:36px">🌟</span><span><b>Starlight Arch</b><br><span class="sub" style="margin:0">An exclusive decoration: place it from Shop → Decor</span></span></div>':""}<p class="sub">🔥 ${me(n).streak} day streak</p><button class="btn gold" data-a="closeModal" style="min-width:160px">Thanks!</button>`,!0)};return t==="claimDayAd"?s.platform.rewarded(()=>s.audio.setMuted(!0)).then(o=>{s.audio.setMuted(s.platform.muted()),r(o)}):r(!1),!0}case"claimMission":{const r=sp(n,+(e.dataset.i||0));if(r){s.audio.play("claim");const o=e.getBoundingClientRect();for(const l of Object.keys(r.reward))a.flyTo(l,o.left+o.width/2,o.top);s.changed(),a.renderOver()}return!0}case"claimBonus":{const r=ap(n);return r&&(s.audio.play("levelup"),s.changed(),a.renderOver(),a.modal(`<div class="ox sub" style="letter-spacing:.2em">ALL MISSIONS DONE</div><div style="font-size:60px;line-height:1">🧰</div><h1>Bonus chest</h1><div class="rewards">${$r(r.res)}</div>${this.giftLine(r.gift)}<button class="btn gold" data-a="closeModal" style="min-width:160px">Awesome!</button>`,!0)),!0}case"claimAch":{const r=op(n,e.dataset.id||"");return r&&(s.audio.play("claim"),a.toast(`${r.a.name} tier ${r.tier+1}: +${r.dm} Dark Matter`,"gold"),s.changed(),a.renderOver()),!0}case"spin":{if(!Yo(n))return s.platform.adsAvailable&&me(n).adSpin!==Fn()?a.modal(`<h1>Daily core</h1><p class="desc">You have used today's free spin. Watch a short ad for one more?</p><div class="row" style="justify-content:center"><button class="btn" data-a="closeModal">No thanks</button><button class="btn gold" data-a="spinAd">▶ Watch ad</button></div>`):a.toast("Your next free core is ready tomorrow",""),!0;const r=Bc(n);return r&&(s.changed(),this.spinReveal(r)),!0}case"spinAd":return a.closeModal(),s.platform.rewarded(()=>s.audio.setMuted(!0)).then(r=>{if(s.audio.setMuted(s.platform.muted()),!r)return;const o=Bc(n,!0);o&&(s.changed(),this.spinReveal(o))}),!0;case"drop":{const r=rp(n);return r?(s.audio.play("harvest"),s.changed(),this.dropReveal(r),!0):(a.toast(`The next supply drop lands in ${pe((me(n).drop-Date.now())/1e3)}`,""),!0)}case"collectAll":{let r=0,o=0;for(const l of zt(n,"bay"))r+=Zc(n,l);for(const l of zt(n,"fab"))o+=Jc(n,l);return a.closeModal(),s.audio.play("collect",r),r&&a.toast(`Collected ${st(r)} credits${o?` and ${st(o)} Power Cells`:""}`,"gold"),s.changed(),!0}}return!1}}const P_={credits:'<span class="ic cr">C</span>',cells:'<span class="ic ce">⚡</span>',dm:'<span class="ic dm">◆</span>'},Nl=i=>Object.entries(i).filter(([,t])=>t>0).map(([t,e])=>`<span class="cost">${P_[t]||""}${st(e)}</span>`).join(" "),Ul=i=>`<span class="els">${i.map(t=>`<span class="el" style="background:${kt[t].color}">${kt[t].glyph}</span>`).join("")}</span>`;class L_{constructor(t){this.ui=t,this.fight=null}startRaid(){const t=p_(this.s);if(!t){this.ui.deny("No raid to defend against");return}this.ui.closeModal(),this.fight={...t,busy:!1,auto:!1,speed:1,raid:!0},this.ui.closeOver(),this.ui.select(null);const e=this.app.world;e.enterArena(),e.arena.setup(t.bt),e.arena.onImpact=(n,s)=>this.impact(n,s),this.app.audio.play("whoosh"),this.app.changed(),this.renderHUD(),document.body.classList.add("fighting")}get s(){return this.ui.app.s}get app(){return this.ui.app}banner(t,e=48){const n=document.createElement("canvas");n.width=96,n.height=60;const s=n.getContext("2d");return s.fillStyle=t.bg,s.fillRect(0,0,96,60),s.fillStyle=t.fg,s.translate(48,30),yd(s,t.emblem,20),s.fill(),`<img src="${n.toDataURL()}" style="width:${e}px;height:${e*60/96}px;border-radius:5px">`}overHTML(){const t=this.s,e=ii(t);hp(t);const n=vs(e.trophies),s=Ki[n+1];e.rivals.length||fu(t);const a=Li(t),r=vn(a.map(d=>({sp:d.sp,lvl:d.lvl}))),o=Ki[n][1],l=s?s[1]:o+1,c=s?(e.trophies-o)/(l-o)*100:100;return`<div class="head"><h1>Arena</h1><span class="chip">🎟 ${e.tickets}/${xs}${e.tickets<xs?` · +1 in ${pe((e.tAt+kc-Date.now())/1e3)}`:""}</span><button class="ibtn" data-a="close">✕</button></div><div class="body" style="max-width:820px;margin:0 auto;width:100%">
      <div class="card" style="flex-direction:row;align-items:center;gap:14px"><div style="font:700 40px Oxanium;color:${Aa[n]};text-shadow:0 0 18px ${Aa[n]}88">🏆</div><div class="grow"><b style="font-size:18px;color:${Aa[n]}">${Ki[n][0]}</b> <span class="sub">${st(e.trophies)} trophies · best ${st(e.best)} · ${e.wins}W ${e.losses}L</span>
        <div class="bar gold" style="margin:6px 0"><i style="width:${c}%"></i></div><div class="sub" style="margin:0">${s?`${s[1]-e.trophies} to ${s[0]}`:"Top league!"} · season ends in ${pe((o_()-Date.now())/1e3)} · reward: ${Nl(up(t,vs(e.seasonBest)))}</div></div></div>
      <h3 class="ox" style="margin:14px 0 6px">Your team <span class="sub">power ${st(r)}</span></h3><div class="row">${[0,1,2].map(d=>{const h=a[d];return`<button class="card" data-a="pickTeam" data-i="${d}" style="width:32%;align-items:center;min-height:120px">${h?`<img src="${this.app.studio.bot(h.sp)}" style="width:70px;height:70px"><b>${ut(h.nick||tt[h.sp].name)}</b><span class="sub" style="margin:0">L${h.lvl} ${Ul(tt[h.sp].el)}</span>`:'<span style="font-size:30px;opacity:.5">＋</span>'}</button>`}).join("")}</div>
      <h3 class="ox" style="margin:14px 0 6px">Rival colonies <button class="btn small" data-a="rerollRivals" style="margin-left:8px">↻ New rivals</button></h3><div class="bots">${e.rivals.map((d,h)=>`<div class="botc" style="grid-template-columns:56px 1fr auto">${this.banner(d.banner,56)}<div><b>${ut(d.name)}</b> <span class="rar" style="color:${["#7cf29a","#ffd36a","#ff6b7a"][d.diff]}">${["Easy","Even","Hard"][d.diff]}</span><div class="row" style="gap:2px;margin:3px 0">${d.team.map(u=>`<img src="${this.app.studio.bot(u.sp)}" title="${tt[u.sp].name} L${u.lvl}" style="width:34px;height:34px">`).join("")}<span class="sub" style="margin:0 0 0 6px">power ${st(d.power)}</span></div><div class="meta">Win: +${pp[d.diff]} 🏆 and rewards</div></div><button class="btn gold small" data-a="fight" data-i="${h}" ${Ta(t).ok?"":"disabled"}>⚔ Fight</button></div>`).join("")}</div>
      ${Ta(t).ok?"":`<p class="why" style="text-align:center">${ut(Ta(t).why||"")}</p>`}<p class="sub" style="text-align:center">Rivals are rival colonies matched to your team's power. Element matchups matter: a super-effective move hits 35% harder.</p></div>`}start(t){const e=l_(this.s,t);if(!e){this.ui.deny(Ta(this.s).why);return}this.fight={...e,busy:!1,auto:!1,speed:1},this.ui.closeOver(),this.ui.select(null);const n=this.app.world;n.enterArena(),n.arena.setup(e.bt),n.arena.onImpact=(s,a)=>this.impact(s,a),this.app.audio.play("whoosh"),this.app.changed(),this.renderHUD(),document.body.classList.add("fighting")}impact(t,e){const n=this.app.world.project(e),s=this.app.world;if(t.move==="burn"){this.ui.popText(n.x,n.y,`-${st(t.dmg)} 🔥`,"#ff9a4a");return}if(t.miss){this.ui.popText(n.x,n.y,t.status==="frozen"?"Frozen!":"Miss!","#9fd0ff"),this.app.audio.play("deny");return}this.ui.popText(n.x,n.y-10,`-${st(t.dmg)}${t.crit?"!":""}`,t.eff>1?"#ffd36a":t.eff<1?"#9aa7b8":"#ffffff"),t.eff!==1&&setTimeout(()=>this.ui.popText(n.x,n.y-34,t.eff>1?"Super effective!":"Resisted",t.eff>1?"#ffd36a":"#9aa7b8"),120),t.status&&t.status!=="shielded"&&setTimeout(()=>this.ui.popText(n.x+30,n.y+10,t.status,"#c49bff"),220),t.heal&&this.ui.popText(n.x-40,n.y-40,`+${st(t.heal)}`,"#7cf29a"),s.burst(new D(e.x,e.y,e.z),D_(t.move),t.crit?34:20),this.app.audio.play(t.crit?"build":"tap"),this.renderHUD()}renderHUD(){const t=document.getElementById("battle"),e=this.fight;if(!e){t.classList.add("hidden");return}t.classList.remove("hidden");const n=e.bt,s=n.A[n.a],a=n.B[n.b],r=(l,c,d,h)=>{const u=l[c];return`<div class="bside ${d?"r":""}"><div class="bname"><b>${ut(u.name)}</b> <span class="sub" style="margin:0">L${u.lvl}</span> ${Ul(tt[u.sp].el)}${u.shield?" 🛡":""}${u.burn?" 🔥":""}${u.frozen?" ❄":""}</div><div class="hp"><i style="width:${u.hp/u.max*100}%;background:${u.hp/u.max>.5?"#5fdc7a":u.hp/u.max>.25?"#ffd36a":"#ff6b7a"}"></i><span>${st(u.hp)} / ${st(u.max)}</span></div><div class="bench">${l.map((f,g)=>`<i class="${f.hp<=0?"ko":g===c?"on":""}"></i>`).join("")}<span class="sub" style="margin:0 6px">${ut(h)}</span></div></div>`},o=lp(s.sp).map(l=>{const c=ts[l],d=wd(c.el,tt[a.sp].el),h=c.el==="none"?"#9aa7b8":kt[c.el].color;return`<button class="mv" data-a="move" data-m="${l}" ${e.busy||n.over?"disabled":""} style="--mc:${h}" title="${ut(c.desc)}"><b>${ut(c.name)}</b><span>${c.el==="none"?"Neutral":kt[c.el].name}${d>1?' · <em class="se">super effective</em>':d<1?' · <em class="re">resisted</em>':""}</span></button>`}).join("");t.innerHTML=`<div class="btop">${r(n.A,n.a,!1,this.s.name)}<div class="vs">VS</div>${r(n.B,n.b,!0,e.rival.name)}</div><div class="bbot"><div class="moves">${o}</div><div class="bopts"><button class="btn small ${e.auto?"gold":""}" data-a="autoBattle">⚡ Auto</button><button class="btn small" data-a="battleSpeed">${e.speed}×</button><button class="btn small" data-a="forfeit">Forfeit</button></div></div>`}async turn(t){const e=this.fight;if(!e||e.busy||e.bt.over)return;e.busy=!0,this.renderHUD();const n=e.bt,s=r_(n,t,Il(n,"B"));if(await this.app.world.arena.play(s,n,e.speed),e.busy=!1,n.over){this.end(n.over==="A");return}this.renderHUD(),e.auto&&setTimeout(()=>this.turn(Il(n,"A")),250/e.speed)}end(t){const e=this.fight;if(e.raid){this.endRaid(t);return}const n=c_(this.s,t,e.rival.diff);this.app.audio.play(t?"levelup":"deny"),this.app.changed(),setTimeout(()=>{this.ui.modal(`<div class="ox sub" style="letter-spacing:.2em">${t?"VICTORY":"DEFEAT"}</div><div class="big" style="color:${t?"#ffd36a":"#ff6b7a"}">${t?"🏆":"💥"}</div><h1>${t?`You beat ${ut(e.rival.name)}!`:`${ut(e.rival.name)} won this time`}</h1>
      <div class="rewards"><span class="cost" style="color:${n.dt>0?"#7cf29a":"#ff6b7a"}">${n.dt>0?"+":""}${n.dt} 🏆</span>${Nl(n.reward)}</div>${n.promoted>=0?`<p class="desc" style="color:${Aa[n.promoted]};font:700 18px Oxanium">Promoted to ${Ki[n.promoted][0]}!</p>`:""}${t?"":'<p class="sub">Tip: feed your team, fuse rarer bots, and pick moves that are super effective against your rival.</p>'}
      <div class="row" style="justify-content:center"><button class="btn" data-a="leaveArena">Back to the colony</button><button class="btn gold" data-a="arenaAgain">Arena</button></div>`,t)},500/e.speed)}endRaid(t){const e=m_(this.s,t),n=e.capture?this.giveCapture(e.capture):null;this.app.audio.play(t?"levelup":"deny"),this.app.changed(),setTimeout(()=>this.ui.modal(`<div class="ox sub" style="letter-spacing:.2em">${t?"RAID REPELLED":"THE SWARM BROKE THROUGH"}</div><div class="big" style="color:${t?"#7cf29a":"#ff6b7a"}">${t?"🛡":"🔥"}</div><h1>${t?"The colony is safe!":"They raided your bays"}</h1>
      ${t?`<div class="rewards">${Nl(e.reward)}</div>${n?`<p class="desc" style="color:#c49bff">You captured and reprogrammed a ${ut(tt[e.capture].name)}! Its core is booting.</p>`:""}`:`<p class="desc">The Swarm carried off ${st(e.stolen||0)} credits from your bays. Level up your crew and fuse stronger bots before the next raid.</p>`}
      <button class="btn gold" data-a="leaveArena">Back to the colony</button>`,t),500/(this.fight?this.fight.speed:1))}giveCapture(t){const e=window.__daily;return e?e.giveSpecies(this.s,t):null}leave(){this.fight=null,this.renderHUD(),document.body.classList.remove("fighting"),this.app.world.exitArena(),this.ui.closeModal(),this.app.changed()}act(t,e){const n=this.s,s=this.app,a=this.ui;switch(t){case"arena":return zt(n,"arena").some(r=>r.lvl>0)?(fp(n),a.openOver("arena"),s.audio.play("tap"),!0):(a.openOver("shop","buildings"),a.toast("Build the Arena first (Commander level 6)","gold"),!0);case"fight":return this.start(+(e.dataset.i||0)),!0;case"rerollRivals":return fu(n),a.renderOver(),s.audio.play("tap"),!0;case"pickTeam":{const r=+(e.dataset.i||0);ii(n);const o=Li(n).map(c=>c.id),l=n.bots.filter(c=>!c.stored).sort((c,d)=>vn([{sp:d.sp,lvl:d.lvl}])-vn([{sp:c.sp,lvl:c.lvl}]));return a.modal(`<h1 style="font-size:20px">Team slot ${r+1}</h1><div class="bots" style="max-height:56vh;overflow:auto;text-align:left">${l.map(c=>`<div class="botc"><div class="pic"><img src="${s.studio.bot(c.sp)}"></div><div><b>${ut(c.nick||tt[c.sp].name)}</b> ${Ul(tt[c.sp].el)}<div class="meta"><span class="rar" style="color:${qt[tt[c.sp].rarity].color}">${qt[tt[c.sp].rarity].name}</span> · L${c.lvl} · power ${st(vn([{sp:c.sp,lvl:c.lvl}]))}</div></div><button class="btn small gold" data-a="setTeam" data-i="${r}" data-bot="${c.id}" ${o[r]===c.id?"disabled":""}>${o.includes(c.id)?"Swap":"Pick"}</button></div>`).join("")}</div><button class="btn" data-a="closeModal" style="margin-top:10px">Cancel</button>`),!0}case"setTeam":{const r=ii(n),o=Li(n).map(h=>h.id),l=e.dataset.bot,c=+(e.dataset.i||0),d=o.indexOf(l);return d>=0&&(o[d]=o[c]),o[c]=l,r.team=o.filter(Boolean),r.rivals=[],a.closeModal(),a.renderOver(),s.audio.play("tap"),!0}case"move":return this.turn(e.dataset.m||"strike"),!0;case"raid":{const r=Jo(n);return r.eta&&a.modal(`<div class="ox sub" style="letter-spacing:.2em;color:#ff6b7a">⚠ SWARM RAID INCOMING</div><h1>The Kr'thul are coming</h1><p class="desc">A Swarm raiding party arrives in <b>${pe((r.eta-Date.now())/1e3)}</b>. Defend the colony with your Arena team, or they will carry off half the credits waiting in your bays.</p><div class="row" style="justify-content:center;gap:4px;margin:8px 0">${r.team.map(o=>`<div style="text-align:center"><img src="${s.studio.bot(o.sp)}" style="width:64px;height:64px"><div class="sub" style="margin:0">L${o.lvl}</div></div>`).join("")}</div><p class="sub">Swarm power ${st(vn(r.team))} · your team ${st(vn(Li(n).map(o=>({sp:o.sp,lvl:o.lvl}))))}</p><div class="row" style="justify-content:center"><button class="btn" data-a="closeModal">Later</button><button class="btn gold" data-a="defendRaid">🛡 Defend now</button></div>`),!0}case"defendRaid":return this.startRaid(),!0;case"autoBattle":return this.fight&&(this.fight.auto=!this.fight.auto,this.renderHUD(),this.fight.auto&&!this.fight.busy&&this.turn(Il(this.fight.bt,"A"))),!0;case"battleSpeed":return this.fight&&(this.fight.speed=this.fight.speed===1?2:this.fight.speed===2?3:1,this.renderHUD()),!0;case"forfeit":return this.fight&&!this.fight.busy&&(this.fight.bt.over="B",this.end(!1)),!0;case"leaveArena":return this.leave(),!0;case"arenaAgain":return this.leave(),setTimeout(()=>this.act("arena",e),200),!0}return!1}}const D_=i=>{const t=ts[i];return!t||t.el==="none"?"#ffffff":kt[t.el].glow},Vi={credits:'<span class="ic cr">C</span>',cells:'<span class="ic ce">⚡</span>',dm:'<span class="ic dm">◆</span>'},xu=i=>Object.entries(i).filter(([,t])=>t>0).map(([t,e])=>`<span class="cost">${Vi[t]||""}${st(e)}</span>`).join(" "),Fl=i=>`<span class="els">${i.map(t=>`<span class="el" style="background:${kt[t].color}" title="${kt[t].name}">${kt[t].glyph}</span>`).join("")}</span>`;class I_{constructor(t){this.ui=t,this.dest=null,this.crew={},this.labels=new Map}get s(){return this.ui.app.s}get app(){return this.ui.app}open(){this.app.world.openMap(),document.body.classList.add("mapview"),this.ui.select(null),this.render(),this.app.audio.play("whoosh");const t=this.app.world.system;t.onPick=e=>{this.dest=e,this.app.audio.play("tap"),this.render()}}close(){this.app.world.closeMap(),document.body.classList.remove("mapview"),this.dest=null,document.getElementById("mapui").classList.add("hidden"),this.labels.forEach(t=>t.remove()),this.labels.clear(),document.getElementById("panel").classList.add("hidden"),this.app.changed()}render(){const t=document.getElementById("mapui");t.classList.remove("hidden");const e=Xe(this.s),n=Ed(this.s);t.innerHTML=`<div class="maptop"><button class="btn small" data-a="closeMap">← Colony</button><h2 class="ox" style="margin:0 8px;flex:1">The Solar System</h2><span class="chip">🚀 ${n&&n.lvl?`${e.exps.length}/${Js(n.lvl)} · ${ys[Xi(n.lvl)-1].name}`:"No Launch Pad"}</span></div>
      <div class="exps">${e.exps.map(s=>`<button class="expc" data-a="mapDest" data-d="${s.dest}"><b>${ut(ye[s.dest].name)}</b><span data-exp="${s.id}">${pe((s.end-Date.now())/1e3)}</span><div class="bar"><i data-expbar="${s.id}" style="width:${jn((Date.now()-s.start)/(s.end-s.start))*100}%"></i></div></button>`).join("")}</div>`,this.panel()}frame(){if(this.app.world.mode!=="map")return;const t=this.app.world.system;if(!t)return;const e=Xe(this.s),n=Date.now();for(const s of si){let a=this.labels.get(s);a||(a=document.createElement("div"),a.className="plabel",a.dataset.a="mapDest",a.dataset.d=s,document.body.appendChild(a),this.labels.set(s,a));const r=$c(this.s,s),o=e.visits[s]||0,l=e.outposts[s],c=e.exps.find(u=>u.dest===s),d=`<b>${ut(ye[s].name)}</b>${c?`<i>🚀 ${pe((c.end-n)/1e3)}</i>`:l&&l.buf>=1?`<i class="ready">${Vi[ye[s].outpost.res]}${st(l.buf)}</i>`:r?o?`<i>✓ ${o}</i>`:'<i class="new">new</i>':"<i>🔒</i>"}`;a.dataset.h!==d&&(a.innerHTML=d,a.dataset.h=d),a.classList.toggle("sel",this.dest===s),a.classList.toggle("locked",!r);const h=t.project(t.worldPos(s));a.style.left=h.x+"px",a.style.top=h.y+"px",a.style.display=h.vis?"":"none"}document.querySelectorAll("[data-exp]").forEach(s=>{const a=e.exps.find(r=>r.id===s.dataset.exp);a&&(s.textContent=pe((a.end-n)/1e3))}),document.querySelectorAll("[data-expbar]").forEach(s=>{const a=e.exps.find(r=>r.id===s.dataset.expbar);a&&(s.style.width=jn((n-a.start)/(a.end-a.start))*100+"%")})}crewOf(t){const e=(this.crew[t]||[]).filter(n=>{const s=this.s.bots.find(a=>a.id===n);return s&&!s.stored&&!mu(this.s,n)});return this.crew[t]=e,e}panel(){const t=document.getElementById("panel");if(!this.dest){t.classList.add("hidden");return}t.classList.remove("hidden");const e=this.s,n=this.dest,s=ye[n],a=Xe(e),r=a.exps.find(l=>l.dest===n);let o=`<button class="ibtn x" data-a="mapDest" data-d="">✕</button><h2>${ut(s.name)}</h2><div class="sub">${ys[s.tier-1].name} rocket · ${pe(y_(n))} · crew of up to ${s.crew} · ${a.visits[n]?`visited ${a.visits[n]}×`:"never visited"}</div><p class="desc">${ut(s.fact)}</p>`;if(!$c(e,n))o+=`<p class="why">🔒 Visit ${ut(ye[s.needs].name)} first.</p>`;else if(r){const l=ui((r.end-Date.now())/1e3);o+=`<p class="desc">A crew is on the way: ${r.crew.map(c=>{const d=e.bots.find(h=>h.id===c);return d?ut(d.nick||tt[d.sp].name):""}).join(", ")}.</p><div class="bar"><i data-expbar="${r.id}"></i></div><div class="row" style="margin-top:8px"><b class="grow" data-exp="${r.id}">${pe((r.end-Date.now())/1e3)}</b><button class="btn gold small" data-a="finishExp" data-e="${r.id}">${l?`${Vi.dm}${l} Bring them home`:"Return now (free)"}</button></div>`}else{const l=this.crewOf(n),c=l.map(u=>e.bots.find(f=>f.id===u)),d=Ad(e,n,c),h=vp(e,n,l);if(o+=`<div class="sub">Favoured elements ${Fl(s.els)} (each match +15% haul)</div><div class="row" style="margin:8px 0">${Array.from({length:s.crew},(u,f)=>{const g=c[f];return`<button class="card" data-a="pickCrew" data-i="${f}" style="width:31%;min-height:96px;align-items:center;padding:6px">${g?`<img src="${this.app.studio.bot(g.sp)}" style="width:52px;height:52px"><b style="font-size:12px">${ut(g.nick||tt[g.sp].name)}</b><span class="sub" style="margin:0">L${g.lvl} ${Fl(tt[g.sp].el)}</span>`:'<span style="font-size:24px;opacity:.5">＋</span><span class="sub" style="margin:0">Crew</span>'}</button>`}).join("")}</div>`,c.length){const u=xp(e,{dest:n,crew:l,start:0});o+=`<div class="sub">Crew power ${st(d.power)} vs ${st(gp(n))} · ${d.match} element match${d.match===1?"":"es"} · haul ×${d.mult.toFixed(2)}</div><div class="sub">Expected: ${xu({credits:u.res.credits,cells:u.res.cells})} + Dark Matter and core chances${a.visits[n]>0?"":' · <b style="color:#ffd36a">first-visit bonus</b>'}</div>`}o+=`<div class="row" style="margin-top:8px"><span class="grow">${h.cost!==void 0?`<span class="cost ${e.res.credits<(h.cost||0)?"short":""}">${Vi.credits}${st(h.cost||0)}</span> fuel`:""}</span><button class="btn gold" data-a="launchExp" ${h.ok?"":"disabled"}>🚀 Launch</button></div>${h.ok?"":`<p class="why">${ut(h.why||"")}</p>`}<p class="sub">The crew is away for the whole trip: they don't earn, help or fight until they're back.</p>`}if(a.visits[n]>0){const l=a.outposts[n],c=bp(e,n),d=s.outpost.res;o+=`<div class="sub" style="margin-top:10px;border-top:1px solid var(--line);padding-top:8px">Outpost ${l?`level ${l.lvl} · ${Vi[d]} ${st(So(n,l.lvl))}/h · store ${st(l.buf)} / ${st(yp(n,l.lvl))}`:`· earns ${Vi[d]} ${st(So(n,1))} per hour, even while you're away`}</div>
      <div class="row">${l?`<button class="btn green small" data-a="collectOutpost" ${l.buf>=1?"":"disabled"}>Collect ${Vi[d]}${st(l.buf)}</button>`:""}<button class="btn small" data-a="buildOutpost" ${c.ok?"":"disabled"}>${l?"⬆ Upgrade":"🏗 Build outpost"} ${c.cost!==void 0?`<span class="cost">${Vi.credits}${st(c.cost)}</span>`:""}</button></div>`}t.innerHTML=o}reveal(t){const e=ye[t.exp.dest],n=t.exp.crew.map(a=>this.s.bots.find(r=>r.id===a)).filter(Boolean),s=t.gift?(()=>{const a=tt[t.gift.sp].rarity;return`<div class="gift" style="--rc:${qt[a].color}"><span style="font-size:30px">🤖</span><span><b style="color:${qt[a].color}">${qt[a].name} core found!</b><br><span class="sub" style="margin:0">Salvaged on ${ut(e.name)}</span></span></div>`})():"";this.ui.modal(`<div class="ox sub" style="letter-spacing:.2em">${t.first&&e.alien?"FIRST CONTACT":"EXPEDITION RETURNED"}</div><h1>${ut(e.name)}</h1><div class="row" style="justify-content:center;gap:4px">${n.map(a=>`<img src="${this.app.studio.bot(a.sp)}" style="width:54px;height:54px">`).join("")}</div>${t.first?`<p class="desc" style="font-style:italic">“${ut(e.first)}”</p>`:""}<div class="rewards">${xu(t.res)}</div>${s}${t.first&&e.alien?`<p class="desc" style="color:#c49bff">★ First contact! An alliance with this civilisation adds 5% to every bot's earnings.</p>`:""}${t.first?'<p class="sub">First visit! You can now build an outpost here.</p>':""}<button class="btn gold" data-a="closeModal" style="min-width:160px">Welcome home</button>`,!0)}act(t,e){const n=this.s,s=this.app,a=this.ui;switch(t){case"space":return this.open(),!0;case"closeMap":return this.close(),s.audio.play("tap"),!0;case"mapDest":return this.dest=e.dataset.d||null,this.dest&&s.world.system?.focus(this.dest),this.render(),s.audio.play("tap"),!0;case"pickCrew":{const r=this.dest,o=+(e.dataset.i||0),l=this.crewOf(r),c=ye[r],d=n.bots.filter(h=>!h.stored&&!mu(n,h.id)&&tt[h.sp].alien!=="relic").sort((h,u)=>tt[u.sp].el.filter(f=>c.els.includes(f)).length-tt[h.sp].el.filter(f=>c.els.includes(f)).length||ea(u).atk-ea(h).atk);return a.modal(`<h1 style="font-size:20px">Crew for ${ut(c.name)}</h1><div class="bots" style="max-height:56vh;overflow:auto;text-align:left">${d.map(h=>{const u=tt[h.sp].el.filter(f=>c.els.includes(f)).length;return`<div class="botc"><div class="pic"><img src="${s.studio.bot(h.sp)}"></div><div><b>${ut(h.nick||tt[h.sp].name)}</b> ${Fl(tt[h.sp].el)}<div class="meta">L${h.lvl}${u?` · <b style="color:#7cf29a">${u} match${u>1?"es":""}</b>`:""}${h.post?" · helping":""}</div></div><button class="btn small gold" data-a="setCrew" data-i="${o}" data-bot="${h.id}">${l.includes(h.id)?"Swap":"Pick"}</button></div>`}).join("")}</div><div class="row" style="justify-content:center;margin-top:10px">${l[o]?`<button class="btn" data-a="setCrew" data-i="${o}" data-bot="">Remove</button>`:""}<button class="btn" data-a="closeModal">Cancel</button></div>`),!0}case"setCrew":{const r=this.dest,o=+(e.dataset.i||0),l=e.dataset.bot||"",c=[...this.crewOf(r)],d=c.indexOf(l);return d>=0&&c.splice(d,1),l?c.splice(Math.min(o,c.length),0,l):c.splice(o,1),this.crew[r]=c.slice(0,ye[r].crew),a.closeModal(),this.panel(),s.audio.play("tap"),!0}case"launchExp":{const r=this.dest,o=x_(n,r,this.crewOf(r));return o.ok?(this.crew[r]=[],s.audio.play("build"),s.changed(),this.render(),a.toast(`The crew is on its way to ${ye[r].name}`,"good")):a.deny(o.why),!0}case"finishExp":{const r=Xe(n).exps.find(l=>l.id===e.dataset.e);if(!r)return!0;const o=ui((r.end-Date.now())/1e3);return n.res.dm<o?(a.deny("Not enough Dark Matter"),!0):(n.res.dm-=o,r.end=Date.now(),s.changed(),!0)}case"buildOutpost":{const r=M_(n,this.dest);return r.ok?(s.audio.play("build"),s.changed(),this.panel(),a.toast("Outpost ready: it earns while you are away","good")):a.deny(r.why),!0}case"collectOutpost":{const r=S_(n,this.dest);if(r){s.audio.play("collect",r);const o=e.getBoundingClientRect();a.flyTo(ye[this.dest].outpost.res,o.left+o.width/2,o.top,6),s.changed(),this.panel()}return!0}}return!1}}const _p={collects:[2,"collect from a bay"],harvests:[6,"harvest a recipe"],feeds:[1,"feed a bot"],fusions:[30,"fuse two bots"],boots:[15,"activate a core"],arenaWins:[20,"win an Arena battle"],expeditions:[25,"complete an expedition"],decor:[3,"place a decoration"],drops:[10,"open a supply drop"],raidsWon:[40,"repel a Swarm raid"],upgrades:[8,"start an upgrade"]},Hr=[{id:"solstice",name:"Solar Solstice",tagline:"The Sun is at its brightest: every solar panel sings.",color:"#ffb23e",icon:"☀",featured:["collects","harvests"],bot:"solstice"},{id:"cup",name:"Arena Cup",tagline:"Rival colonies gather in orbit for the season's grand tournament.",color:"#ff5a6a",icon:"🏆",featured:["arenaWins","raidsWon"],bot:"champion"},{id:"deep",name:"Deep Space Week",tagline:"Launch windows are wide open. Fill the sky with rockets.",color:"#4aa8ff",icon:"🚀",featured:["expeditions","drops"],bot:"voyager"},{id:"fusion",name:"Fusion Frenzy",tagline:"The Fusion Lab hums day and night. Strange new cores appear.",color:"#b06dff",icon:"🧬",featured:["fusions","boots"],bot:"chimera"},{id:"garden",name:"Garden Gala",tagline:"The colony blooms. Decorate, feed and grow.",color:"#4fcf5a",icon:"🌸",featured:["decor","feeds"],bot:"blossom"},{id:"forge",name:"Forge Fest",tagline:"Builder drones work double shifts. Raise the skyline.",color:"#ff7a1a",icon:"🔨",featured:["upgrades","harvests"],bot:"anvil"}],us=[60,150,300,500,800,1200,1700,2400],Ol=7*864e5,Bl=Date.UTC(2026,0,5);function Ka(i=Date.now()){const t=Math.floor((i-Bl)/Ol);return{def:Hr[(t%Hr.length+Hr.length)%Hr.length],week:t,start:Bl+t*Ol,end:Bl+(t+1)*Ol}}function jo(i,t=Date.now()){const e=i,n=Ka(t);return(!e.event||e.event.week!==n.week)&&(e.event={week:n.week,base:{...i.stats},claimed:[]}),e.event}function Td(i,t=Date.now()){const e=Ka(t),n=jo(i,t);let s=0;for(const[a,[r]]of Object.entries(_p))s+=Math.max(0,(i.stats[a]||0)-(n.base[a]||0))*r*(e.def.featured.includes(a)?3:1);return s}function Mp(i,t,e){const n=1+i.lvl*.4;return t===us.length-1?{label:"Exclusive bot",bot:e.bot}:t===3?{label:"Elite core",core:"elite"}:t===5?{label:"Epic core",core:"epic"}:{label:t%2?"Dark Matter":"Supplies",res:t%2?{dm:10+t*5}:{credits:Yt(1500*n*(1+t)),cells:Yt(400*n*(1+t))}}}function N_(i,t,e=Date.now()){const n=Ka(e),s=jo(i,e);if(s.claimed.includes(t)||Td(i,e)<us[t])return null;const a=Mp(i,t,n.def);s.claimed.push(t);let r=null;return a.res&&Cn(i,a.res),a.core&&(r=ns(i,a.core,n.week*31+t,e)),a.bot&&(r=Md(i,a.bot,e)),ce(i,30+t*10),i.stats.eventSteps=(i.stats.eventSteps||0)+1,{r:a,gift:r}}const U_=(i,t=Date.now())=>{const e=jo(i,t),n=Td(i,t);return us.some((s,a)=>n>=s&&!e.claimed.includes(a))},Mi={credits:'<span class="ic cr">C</span>',dm:'<span class="ic dm">◆</span>',iridium:'<span class="ic ir">✦</span>'},Gi=(i,t,e=22)=>`<span class="gem t${t}" style="--gc:${Ve[i].color};width:${e}px;height:${e}px"></span>`;class F_{constructor(t){this.ui=t,this.digColor="aurora"}get s(){return this.ui.app.s}get app(){return this.ui.app}eventChip(){const t=Ka(),e=U_(this.s);return`<button class="chip ev" data-a="event" style="--ec:${t.def.color}">${t.def.icon} ${ut(t.def.name)} · ${pe((t.end-Date.now())/1e3)}${e?'<i class="rdot"></i>':""}</button>`}eventHTML(){const t=this.s,e=Ka(),n=jo(t),s=Td(t),a=e.def,r=us[us.length-1],o=tt[a.bot];return`<div class="head"><h1>${a.icon} ${ut(a.name)}</h1><span class="chip">ends in ${pe((e.end-Date.now())/1e3)}</span><button class="ibtn" data-a="close">✕</button></div><div class="body" style="max-width:760px;margin:0 auto;width:100%">
      <div class="card evhero" style="--ec:${a.color}"><div class="row" style="align-items:center;gap:14px"><img src="${this.app.studio.bot(a.bot)}" style="width:120px;height:120px"><div class="grow"><div class="ox sub" style="letter-spacing:.15em;color:${a.color}">THIS WEEK'S EXCLUSIVE</div><h2 style="margin:2px 0">${ut(o.name)}</h2><span class="rar" style="color:${qt[o.rarity].color}">${qt[o.rarity].name}</span><p class="desc">${ut(a.tagline)} Reach the top of the track to win it: it never comes back in the shop.</p></div></div></div>
      <div class="row" style="margin:12px 0 4px"><b class="ox grow" style="font-size:20px">🎟 ${st(s)} tokens</b><span class="sub">${n.claimed.length}/${us.length} rewards</span></div><div class="bar gold"><i style="width:${Math.min(100,s/r*100)}%"></i></div>
      <div class="track">${us.map((l,c)=>{const d=Mp(t,c,a),h=n.claimed.includes(c),u=s>=l;return`<div class="ms ${h?"got":u?"ok":""}"><b>${st(l)}</b><span>${d.bot?`<img src="${this.app.studio.bot(d.bot)}" style="width:40px;height:40px">`:d.core?"🤖":d.res?d.res.dm?"◆":"📦":""}</span><i>${ut(d.label)}</i>${h?"<em>✓</em>":u?`<button class="btn gold small" data-a="claimMs" data-i="${c}">Claim</button>`:""}</div>`}).join("")}</div>
      <h3 class="ox" style="margin:14px 0 6px">How to earn tokens</h3><div class="earn">${Object.entries(_p).map(([l,[c,d]])=>{const h=a.featured.includes(l);return`<div class="${h?"feat":""}"><span>${ut(d)}</span><b>+${c*(h?3:1)}</b>${h?"<em>×3 this week</em>":""}</div>`}).join("")}</div>
      <p class="sub" style="text-align:center">A new event starts every Monday. Six themes rotate, each with its own exclusive bot.</p></div>`}crystalsHTML(){const t=qe(this.s).crystals;return`<table class="gems"><tr><td></td>${el.map(e=>`<th>${e}</th>`).join("")}</tr>${Pa.map(e=>`<tr><td><b style="color:${Ve[e].color}">${Ve[e].name}</b></td>${t[e].map((n,s)=>`<td>${Gi(e,s,18)} ${st(n)}</td>`).join("")}</tr>`).join("")}</table>`}mineHTML(t){const e=this.s,n=qe(e).ready[t.id],s=Ee(e,t.id,"dig");if(n)return`<div class="row"><span class="grow desc">${Gi(n.color,0)} ${st(n.n)} ${Ve[n.color].name} shards are ready.</span><button class="btn green" data-a="collectMine" data-id="${t.id}">Collect</button></div>`;if(s){const a=ui((s.end-Date.now())/1e3);return`<p class="desc">Digging for ${Ve[s.sp||"aurora"].name} shards…</p><div class="bar"><i data-bar="${s.id}"></i></div><div class="row" style="margin-top:8px"><b class="grow" data-left="${s.id}"></b><button class="btn gold small" data-a="finish" data-job="${s.id}" data-dm="${s.id}">${a?`${Mi.dm}${a} Finish now`:"Finish (free)"}</button></div>`}return`<p class="desc">Pick a crystal colour, then a dig. Credits buy digging time; deeper digs pay more shards.</p><div class="row">${Pa.map(a=>`<button class="btn small ${this.digColor===a?"gold":""}" data-a="digColor" data-c="${a}">${Gi(a,0,16)} ${Ve[a].name}</button>`).join("")}</div>
      <div class="recipes">${Ao.map((a,r)=>`<div class="rec"><b>${ut(a.name)}</b><span class="out" style="color:${Ve[this.digColor].color}">${Gi(this.digColor,0,16)} ${Cu(a.shards,t.lvl)}</span><span class="sub">${pe(a.sec)}</span><button class="btn small" data-a="dig" data-id="${t.id}" data-i="${r}"><span class="cost" data-cost="credits:${a.cost}">${Mi.credits}${st(a.cost)}</span></button></div>`).join("")}</div>`}forgeHTML(){const t=this.s,e=qe(t).crystals;return`<p class="desc">Four crystals of a tier and some Iridium make one of the next tier. You have ${Mi.iridium} ${st(t.res.iridium||0)} Iridium.</p>
    <table class="gems"><tr><td></td>${el.slice(0,3).map((n,s)=>`<th>${n} → ${el[s+1]}<br><span class="sub" style="margin:0">${Mi.iridium}${Pu(s)}</span></th>`).join("")}</tr>${Pa.map(n=>`<tr><td><b style="color:${Ve[n].color}">${Ve[n].name}</b></td>${[0,1,2].map(s=>{const a=Du(t,n,s).ok;return`<td><button class="btn small ${a?"gold":""}" data-a="forge" data-c="${n}" data-t="${s}" ${a?"":"disabled"}>${Gi(n,s,14)}${e[n][s]}/${eo} → ${Gi(n,s+1,14)}</button></td>`}).join("")}</tr>`).join("")}</table>`}relicHTML(t){const e=this.s,n=t.el||"aurora",s=Rn(e,t.id),a=Jn(t.lvl),r=e.bay[t.id]||0,o=Qn.filter(l=>tt[l].alien==="relic"&&tt[l].el[0]===n);return`<div class="row"><div class="grow"><div class="bar" id="relbar"><i style="width:${r/Oa(t)*100}%;background:linear-gradient(90deg,#c49bff,#8a5cff)"></i></div></div><b>${Mi.iridium} <span id="relv">${st(r)} / ${st(Oa(t))}</span></b><button class="btn gold small" id="relc" data-a="collect" data-id="${t.id}" ${r>=1?"":"disabled"}>Collect</button></div>
      <div class="sub">${Mi.iridium} ${(Math.round(Fu(e,t.id)*600)/10).toLocaleString("en-US")} Iridium per minute · ${s.length}/${a} Relic AIs</div>
      <div class="bots">${s.map(l=>{const c=Uu(e,l),d=l.lvl<5?Wc[l.lvl-1]:null;return`<div class="botc"><div class="pic" style="background:radial-gradient(circle, ${kt[n].color}55, transparent 70%)"><img src="${this.app.studio.bot(l.sp)}"></div><div><b>${ut(tt[l.sp].name)}</b> <span style="color:#ffd36a">${"★".repeat(l.lvl)}${"☆".repeat(5-l.lvl)}</span><div class="meta">${Mi.iridium} ${Wl(We.indexOf(tt[l.sp].rarity),l.lvl).toFixed(1)}/min</div></div>
          ${d?`<button class="btn small ${c.ok?"gold":""}" data-a="evolve" data-bot="${l.id}" ${c.ok?"":"disabled"}>⬆ ${Gi(n,d[0],14)}${d[1]}</button>`:'<span class="sub">MAX</span>'}</div>`}).join("")||'<p class="desc">No Relic AIs here yet.</p>'}</div>
      <div class="sub" style="margin-top:10px">Summon ${/^[AEIOU]/.test(kt[n].name)?"an":"a"} ${kt[n].name} Relic AI</div><div class="bots">${o.map((l,c)=>{const[d,h]=Vc[c],u=Nu(e,l);return`<div class="botc"><div class="pic"><img src="${this.app.studio.bot(l)}" style="${e.dex[l]?"":"filter:brightness(0) opacity(.55)"}"></div><div><b>${e.dex[l]?ut(tt[l].name):"???"}</b> <span class="rar" style="color:${qt[tt[l].rarity].color}">${["Minor","Major","Prime"][c]}</span><div class="meta">earns ${Mi.iridium} ${Wl(We.indexOf(tt[l].rarity),1).toFixed(1)}/min at one star</div></div><button class="btn small ${u.ok?"gold":""}" data-a="summon" data-sp="${l}" ${u.ok?"":"disabled"} title="${ut(u.why||"")}">${Gi(n,d,14)}${h}</button></div>`}).join("")}</div>`}act(t,e){const n=this.s,s=this.app,a=this.ui,r=e.dataset.id?Re(n,e.dataset.id):void 0;switch(t){case"event":return a.openOver("event"),s.audio.play("tap"),!0;case"claimMs":{const o=N_(n,+(e.dataset.i||0));return o&&(s.audio.play(o.r.bot?"levelup":"claim"),s.changed(),a.renderOver(),o.r.bot?a.toast(`${tt[o.r.bot].name} is yours! Its core is booting.`,"gold"):o.gift&&a.toast("A core is booting in the Assembly Bay","gold")),!0}case"crystals":return a.modal(`<h1 style="font-size:20px">Relic crystals</h1>${this.crystalsHTML()}<p class="sub">${Mi.iridium} ${st(n.res.iridium||0)} Iridium</p><button class="btn" data-a="closeModal">Close</button>`),!0;case"digColor":return this.digColor=e.dataset.c||"aurora",a.renderPanel(),s.audio.play("tap"),!0;case"dig":if(r){const o=qp(n,r,+(e.dataset.i||0),this.digColor);o.ok?(s.audio.play("build"),s.changed(),a.renderPanel()):a.deny(o.why)}return!0;case"collectMine":if(r){const o=Lu(n,r);if(o){s.audio.play("harvest");const l=e.getBoundingClientRect();a.popText(l.left+l.width/2,l.top,`+${o.n} ${Ve[o.color].name}`,Ve[o.color].color),s.changed(),a.renderPanel()}}return!0;case"forge":{const o=Kp(n,e.dataset.c||"aurora",+(e.dataset.t||0));return o.ok?(s.audio.play("done"),s.changed(),a.renderPanel()):a.deny(o.why),!0}case"summon":{const o=Zp(n,e.dataset.sp||"");return o.ok&&o.bot?(s.audio.play("levelup"),s.changed(),a.renderPanel(),a.newBot(o.bot)):a.deny(o.why),!0}case"evolve":{const o=n.bots.find(c=>c.id===e.dataset.bot);if(!o)return!0;const l=Jp(n,o);return l.ok?(s.audio.play("levelup"),s.changed(),a.renderPanel(),a.toast(`${tt[o.sp].name} evolved to ${o.lvl} stars!`,"gold")):a.deny(l.why),!0}}return!1}}const ve={credits:'<span class="ic cr">C</span>',cells:'<span class="ic ce">⚡</span>',dm:'<span class="ic dm">◆</span>',iridium:'<span class="ic ir">✦</span>'},yu=(i,t)=>Object.entries(i).filter(([,e])=>e>0).map(([e,n])=>`<span class="cost ">${ve[e]||""}${st(n)}</span>`).join(" "),Gr=i=>`<span class="els">${i.map(t=>`<span class="el" style="background:${kt[t].color}" title="${kt[t].name}">${kt[t].glyph}</span>`).join("")}</span>`,O_=Bb,bu=[["#e9eef5","#22c7e8"],["#f4efe6","#ff7a3c"],["#dfe7d8","#4fcf5a"],["#2e3644","#ffd23a"],["#f2e8f7","#b06dff"],["#e6f1ff","#2f6bff"],["#3b2f2f","#ff4f6a"],["#fff6dc","#c9902a"]],B_=["#1b6fd8","#d83a3a","#1f9c5a","#7a3fd6","#e08a1a","#14202e","#e6e6ea","#0fb3c9"],k_=["star","planet","bolt","gear","rocket","circle"];class z_{constructor(t){this.app=t,this.sel=null,this.selBot=null,this.tab="bays",this.over="",this.bubbles=new Map,this.lastRes={credits:0,cells:0,dm:0},this.panelKey="",this.tick=0,this.dailyKey="",this.objKey="",this.crew=new R_(this),this.daily=new C_(this),this.arena=new L_(this),this.space=new I_(this),this.vault=new F_(this),document.addEventListener("click",e=>{const n=e.target.closest("[data-a]");n&&(e.stopPropagation(),this.act(n.dataset.a,n))}),document.addEventListener("input",e=>{const n=e.target;n.dataset.set&&this.app.setSetting(n.dataset.set,n.type==="range"?+n.value:n.value),n.id==="cname"&&(this.s.name=n.value.slice(0,24)||"New Haven",this.renderHud())}),this.renderHud(),this.renderNav(),this.renderObj()}get s(){return this.app.s}get world(){return this.app.world}renderHud(){const t=this.s,e=t.xp/Sa(t)*100;xe("#hud").innerHTML=`<div class="lvl" title="Commander level"><div class="badge" style="--p:${e}%"><b>${t.lvl}</b></div><div class="nm"><b>${ut(t.name)}</b><i>${st(t.xp)} / ${st(Sa(t))} XP</i></div></div>
      <button class="chip" data-a="islands" title="Your islands">${{home:"🌍",moon:"🌕",mars:"🔴"}[t.at]||"🌍"} ${ut(t.at==="home"?t.name:Sn[t.at].name)} ▾</button>
      <div class="res" id="r-credits">${ve.credits}<span class="v">${st(t.res.credits)}</span></div><div class="res" id="r-cells">${ve.cells}<span class="v">${st(t.res.cells)}</span></div><div class="res" id="r-dm">${ve.dm}<span class="v">${st(t.res.dm)}</span></div>${t.islands.vault?`<div class="res" id="r-iridium" data-a="crystals" title="Iridium and crystals"><span class="ic ir">✦</span><span class="v">${st(t.res.iridium||0)}</span></div>`:""}
      <div class="sp"></div><span id="dailyHud" class="row" style="gap:6px;flex-wrap:nowrap">${this.vault.eventChip()}${this.daily.hudHTML()}</span><button class="ibtn" data-a="zoomout" title="Overview">🛰</button><button class="ibtn" data-a="settings" title="Settings">⚙</button>`}updHud(){const t=this.s;for(const n of["credits","cells","dm","iridium"]){const s=Math.floor(t.res[n]||0);if(s!==Math.floor(this.lastRes[n]||0)){const a=xe(`#r-${n}`);a&&(a.querySelector(".v").textContent=st(s),s>(this.lastRes[n]||0)&&(a.classList.remove("bump"),a.offsetWidth,a.classList.add("bump"))),this.lastRes[n]=s}}const e=xe(".lvl .badge");if(e){e.style.setProperty("--p",t.xp/Sa(t)*100+"%"),e.querySelector("b").textContent=String(t.lvl);const n=xe(".lvl .nm i");n&&(n.textContent=`${st(t.xp)} / ${st(Sa(t))} XP`)}}renderNav(){xe("#nav").innerHTML='<button data-a="shop" id="n-shop"><span class="g">🛒</span>Shop</button><button data-a="bots"><span class="g">🤖</span>Crew</button><button data-a="dex"><span class="g">📖</span>Botdex</button><button data-a="arena"><span class="g">⚔</span>Arena</button><button data-a="space"><span class="g">🚀</span>Space</button><button data-a="custom"><span class="g">🎨</span>Style</button>'}renderObj(){const t=this.s,e=Da(t),n=xe("#obj");if(!e){n.classList.add("hidden");return}n.classList.remove("hidden");const s=no(t,e);n.classList.toggle("done",s),n.innerHTML=`<div class="t">Mission ${t.obj.i+1} of ${Qr.length}</div><p>${ut(e.text)}</p><div class="rw">Reward: ${yu(e.reward)}</div>${s?'<button class="btn gold claim" data-a="claim">✓ Claim reward</button>':""}`}frame(){if(this.tick++,this.updHud(),this.placeBubbles(),this.space.frame(),this.tick%20===0){const t=this.vault.eventChip()+this.daily.hudHTML();if(t!==this.dailyKey){this.dailyKey=t;const e=xe("#dailyHud");e&&(e.innerHTML=t)}}this.tick%15===0&&(this.refreshPanel(),this.renderObjIfChanged(),(this.over==="shop"||this.over==="bots")&&this.refreshOverCosts())}renderObjIfChanged(){const t=Da(this.s),e=(t?t.id:"-")+(t&&no(this.s,t)?1:0);e!==this.objKey&&(this.objKey=e,this.renderObj())}placeBubbles(){const t=this.s,e=this.world,n=new Set,s=xe("#bubbles"),a=(r,o,l,c,d,h)=>{if(!o)return;n.add(r);let u=this.bubbles.get(r);u||(u=document.createElement("div"),u.className="bub",d&&(u.dataset.a=d,h&&(u.dataset.id=h)),s.appendChild(u),this.bubbles.set(r,u)),u.dataset.h!==l+c&&(u.innerHTML=l,u.className="bub "+c,u.dataset.h=l+c);const f=e.project(o);u.style.left=f.x+"px",u.style.top=f.y+"px",u.style.display=f.vis&&!e.ghost&&e.mode==="island"?"":"none"};for(const r of kn(t).items){const o=e.topOf(r.id),l=Ee(t,r.id,"build");if(l){const c=(l.end-Date.now())/1e3,d=jn(1-(l.end-Date.now())/(l.end-l.start));a("t"+r.id,o,`<span>${c>0?pe(c):"Done!"}</span><div class="bar"><i style="width:${d*100}%"></i></div>`,"timer","select",r.id);continue}if(r.t==="bay"){const c=Math.floor(t.bay[r.id]||0);c>=1&&a("c"+r.id,o,`${ve.credits}${st(c)}`,c>=Wi(r,t)*.98?"full":"","collect",r.id)}if(r.t==="fab"){const c=t.ready[r.id],d=Ee(t,r.id,"craft");if(c)a("r"+r.id,o,`${ve.cells}+${st(c.cells)}`,"ready","harvest",r.id);else if(d){const h=jn(1-(d.end-Date.now())/(d.end-d.start));a("t"+r.id,o,`<span>${pe((d.end-Date.now())/1e3)}</span><div class="bar cell"><i style="width:${h*100}%"></i></div>`,"timer","select",r.id)}else r.lvl>0&&a("i"+r.id,o,`${ve.cells}<span>Idle</span>`,"","select",r.id)}if(r.t==="relicbay"){const c=Math.floor(t.bay[r.id]||0);c>=1&&a("c"+r.id,o,`<span class="ic ir">✦</span>${st(c)}`,c>=Oa(r)*.98?"full":"","collect",r.id)}if(r.t==="mine"&&r.lvl>0){const c=qe(t).ready[r.id],d=Ee(t,r.id,"dig");if(c)a("r"+r.id,o,`💎 <span>+${c.n}</span>`,"ready","collectMine",r.id);else if(d){const h=jn(1-(d.end-Date.now())/(d.end-d.start));a("t"+r.id,o,`<span>💎 ${pe((d.end-Date.now())/1e3)}</span><div class="bar"><i style="width:${h*100}%"></i></div>`,"timer","select",r.id)}else a("i"+r.id,o,"💎 <span>Idle</span>","","select",r.id)}if(r.t==="assembly"&&r.lvl>0){const c=t.cores.filter(d=>d.state==="ready").length;c&&a("a"+r.id,o,`🤖 <span>${c} ready!</span>`,"ready","select",r.id)}if(r.t==="fusion"&&r.lvl>0){const c=Ee(t,r.id,"fuse");if(c){const d=jn(1-(c.end-Date.now())/(c.end-c.start));a("t"+r.id,o,`<span>🧬 ${pe((c.end-Date.now())/1e3)}</span><div class="bar"><i style="width:${d*100}%"></i></div>`,"timer","select",r.id)}else t.bots.filter(d=>d.lvl>=qi).length>=2&&a("i"+r.id,o,"🧬 <span>Fuse</span>","","select",r.id)}}for(let r=0;r<5;r++)for(let o=0;o<5;o++){const l=`${r},${o}`;if(No(t,l)!=="buyable")continue;const c={x:r*fe+fe/2-Ft/2,y:.4,z:o*fe+fe/2-Ft/2},d=Da(t);t.lvl>=Fo(t)&&(e.cam.tdist>40||d&&d.kind==="land")&&a("p"+l,c,`＋ ${ve.credits}${st(Uo(t))}`,"plot","plot",l)}for(const[r,o]of this.bubbles)n.has(r)||(o.remove(),this.bubbles.delete(r))}select(t){this.sel=t,this.selBot=null,this.world.select(t,this.s),this.panelKey="",this.renderPanel()}selectBot(t){this.sel=null,this.selBot=t,this.world.select(null),this.panelKey="",this.renderPanel()}panelSig(){const t=this.s;if(this.selBot){const s=t.bots.find(a=>a.id===this.selBot);return s?["bot",s.id,s.lvl,s.fed,s.post,s.bay,s.stored,s.nick].join("|"):""}const e=this.sel?Re(t,this.sel):null;if(!e)return"";const n=t.jobs.filter(s=>s.item===e.id).map(s=>s.id+s.kind).join();return[e.id,e.lvl,e.r,n,e.t==="bay"?Rn(t,e.id).map(s=>s.id+s.lvl+s.fed+(s.post||"")).join():"",t.ready[e.id]?1:0,t.lvl,ji(t),Po(t),to(t,e.id).map(s=>s.id).join(),e.t==="assembly"?t.cores.map(s=>s.id+s.state).join():"",this.crew.fuseA,this.crew.fuseB,e.t==="mine"?JSON.stringify(qe(t).ready[e.id]||"")+this.vault.digColor:"",e.t==="forge"||e.t==="relicbay"?JSON.stringify(qe(t).crystals)+Rn(t,e.id).map(s=>s.id+s.lvl).join()+Math.floor((t.res.iridium||0)/10):""].join("|")}refreshPanel(){if(!this.sel&&!this.selBot)return;if(this.panelSig()!==this.panelKey){this.renderPanel();return}const e=this.s;if(this.selBot){Es("#panel [data-cost]").forEach(s=>{const[a,r]=s.dataset.cost.split(":");s.classList.toggle("short",e.res[a]<+r)});return}const n=Re(e,this.sel);if(n){if(Es("#panel [data-left]").forEach(s=>{const a=e.jobs.find(r=>r.id===s.dataset.left);a&&(s.textContent=pe((a.end-Date.now())/1e3))}),Es("#panel [data-bar]").forEach(s=>{const a=e.jobs.find(r=>r.id===s.dataset.bar);a&&(s.style.width=jn(1-(a.end-Date.now())/(a.end-a.start))*100+"%")}),Es("#panel [data-dm]").forEach(s=>{const a=e.jobs.find(r=>r.id===s.dataset.dm);if(a){const r=ui((a.end-Date.now())/1e3);s.innerHTML=r?`${ve.dm}${r} Finish now`:"Finish (free)"}}),n.t==="bay"){const s=xe("#panel .bar.gold i"),a=xe("#panel #bayv"),r=e.bay[n.id]||0;s&&(s.style.width=r/Wi(n,e)*100+"%"),a&&(a.textContent=`${st(r)} / ${st(Wi(n,e))}`)}if(n.t==="relicbay"){const s=xe("#panel #relbar i"),a=xe("#panel #relv"),r=xe("#panel #relc"),o=e.bay[n.id]||0,l=Oa(n);s&&(s.style.width=o/l*100+"%"),a&&(a.textContent=`${st(o)} / ${st(l)}`),r&&(r.disabled=o<1)}Es("#panel [data-cost]").forEach(s=>{const[a,r]=s.dataset.cost.split(":");s.classList.toggle("short",e.res[a]<+r)})}}renderPanel(){const t=xe("#panel"),e=this.s,n=this.selBot?e.bots.find(l=>l.id===this.selBot):null;if(n){t.classList.remove("hidden"),this.panelKey=this.panelSig(),t.innerHTML=this.crew.botPanel(n);return}const s=this.sel?Re(e,this.sel):null;if(!s){t.classList.add("hidden");return}t.classList.remove("hidden"),this.panelKey=this.panelSig();const a=Qt[s.t],r=Ee(e,s.id,"build");let o=`<button class="ibtn x" data-a="deselect">✕</button><h2>${ut(s.t==="bay"?`${kt[s.el].name} Bay`:a.name)}</h2><div class="sub">${a.cat==="decor"?"Decoration":`Level ${s.lvl} / ${zu(e,s)}`}</div>`;if(r){const l=ui((r.end-Date.now())/1e3);o+=`<p class="desc">${s.lvl===0?"Under construction":`Upgrading to level ${r.lvl}`}: builder drones at work.</p><div class="bar"><i data-bar="${r.id}"></i></div><div class="row" style="margin-top:8px"><b class="grow" data-left="${r.id}"></b><button class="btn gold small" data-a="finish" data-job="${r.id}" data-dm="${r.id}">${l?`${ve.dm}${l} Finish now`:"Finish (free)"}</button></div>`}else if(s.t==="hub")o+=`<p class="desc">${ut(a.desc)}</p>${Sn[e.at]&&Sn[e.at].perk?`<p class="desc" style="color:#7cf29a">★ ${ut(Sn[e.at].perk)}</p>`:""}<table class="stats"><tr><td>Bays allowed here</td><td>${Ca(s.lvl)}</td></tr><tr><td>Fabricators allowed here</td><td>${Ws(s.lvl)}</td></tr><tr><td>Max building level here</td><td>${s.lvl}</td></tr></table>`+this.upgradeRow(s)+this.moveRow(s);else if(s.t==="command"){const l=s.lvl+1;o+=`<p class="desc">${ut(a.desc)}</p><table class="stats"><tr><td>Bays allowed</td><td>${Ca(s.lvl)}</td></tr><tr><td>Fabricators allowed</td><td>${Ws(s.lvl)}</td></tr><tr><td>Max building level</td><td>${s.lvl}</td></tr><tr><td>Builder drones</td><td>${e.builders}</td></tr></table>`,s.lvl<a.max&&(o+=`<div class="sub">Level ${l}: ${Ca(l)} bays · ${Ws(l)} fabricators · buildings to level ${l}${Xs[l]>e.lvl?` · needs Commander level ${Xs[l]}`:""}</div>`),o+=this.upgradeRow(s)+this.crew.helpersHTML(s)+`<div class="row" style="margin-top:8px"><button class="btn small" data-a="custom">🎨 Colony style</button><button class="btn small" data-a="move" data-id="${s.id}">✥ Move</button></div>`}else if(s.t==="mine")o+=this.vault.mineHTML(s)+this.upgradeRow(s,s.lvl<a.max?`Level ${s.lvl+1}: +15% shards per dig`:"")+this.moveRow(s);else if(s.t==="forge")o+=this.vault.forgeHTML()+this.moveRow(s);else if(s.t==="relicbay")o+=this.vault.relicHTML(s)+this.upgradeRow(s,s.lvl<a.max?`Level ${s.lvl+1}: holds more Iridium${Jn(s.lvl+1)>Jn(s.lvl)?`, ${Jn(s.lvl+1)} Relic AIs`:""}`:"")+this.moveRow(s);else if(s.t==="pad"){const l=Xe(e);o+=`<p class="desc">${ut(a.desc)}</p><table class="stats"><tr><td>Rocket</td><td>${ys[Xi(s.lvl)-1].name} (tier ${Xi(s.lvl)})</td></tr><tr><td>Launch slots</td><td>${l.exps.length} / ${Js(s.lvl)} in use</td></tr><tr><td>Worlds visited</td><td>${Object.keys(l.visits).length} / ${si.length}</td></tr></table><button class="btn gold" data-a="space" style="width:100%">🚀 Open the Solar System</button>`+this.upgradeRow(s,s.lvl<a.max?`Level ${s.lvl+1}${Xi(s.lvl+1)>Xi(s.lvl)?`: the ${ys[Xi(s.lvl+1)-1].name} rocket`:""}${Js(s.lvl+1)>Js(s.lvl)?", +1 launch slot":""}`:"")+this.moveRow(s)}else if(s.t==="arena"){const l=ii(e),c=vs(l.trophies);o+=`<p class="desc">${ut(a.desc)}</p><div class="row"><b class="grow" style="color:${Aa[c]}">🏆 ${Ki[c][0]} · ${st(l.trophies)}</b><span class="chip">🎟 ${l.tickets}/${xs}</span></div><button class="btn gold" data-a="arena" style="width:100%;margin-top:8px">⚔ Enter the Arena</button>`+this.upgradeRow(s,s.lvl<a.max?`Level ${s.lvl+1}: battle rewards +${s.lvl*10}%`:"")+this.moveRow(s)}else if(s.t==="assembly"||s.t==="fusion")o+=(s.t==="assembly"?this.crew.assemblyHTML(s):this.crew.fusionHTML(s))+this.upgradeRow(s,s.lvl<a.max?s.t==="assembly"?`Level ${s.lvl+1}: boots 5% faster${Fa(s.lvl+1)>Fa(s.lvl)?", +1 pod":""}${Qs(s.lvl+1)>Qs(s.lvl)?", +1 helper slot":""}`:`Level ${s.lvl+1}: fuses 5% faster`:"")+this.moveRow(s);else if(s.t==="bay"){const l=Rn(e,s.id),c=Jn(s.lvl),d=e.bay[s.id]||0,h=Io(e,s.id)*60;o+=`<div class="row"><div class="grow"><div class="bar gold"><i style="width:${d/Wi(s,e)*100}%"></i></div></div><b id="bayv">${st(d)} / ${st(Wi(s,e))}</b></div><div class="row" style="margin:6px 0"><span class="grow sub">${ve.credits} ${st(h)} per minute · ${l.length}/${c} bots</span><button class="btn gold small" data-a="collect" data-id="${s.id}" ${d>=1?"":"disabled"}>Collect</button></div>`,o+=`<div class="bots">${l.map(u=>this.botCard(u)).join("")||'<p class="desc">No bots yet. Recruit one in the Shop.</p>'}</div>`,l.length<c&&(o+=`<button class="btn small" style="margin-top:8px;width:100%" data-a="shop" data-tab="bots">＋ Recruit a ${kt[s.el].name} bot</button>`),o+=this.upgradeRow(s,s.lvl<a.max?`Level ${s.lvl+1}: holds ${st(sf(s.lvl+1))} credits${Jn(s.lvl+1)>c?`, ${Jn(s.lvl+1)} bots`:""}`:"")+this.moveRow(s)}else if(s.t==="fab"){const l=e.ready[s.id],c=Ee(e,s.id,"craft");if(l)o+=`<div class="row"><span class="grow desc">${st(l.cells)} Power Cells are ready.</span><button class="btn green" data-a="harvest" data-id="${s.id}">${ve.cells} Harvest</button></div>`;else if(c){const d=ta[c.recipe||0],h=ui((c.end-Date.now())/1e3);o+=`<p class="desc">Printing <b>${ut(d.name)}</b></p><div class="bar cell"><i data-bar="${c.id}"></i></div><div class="row" style="margin-top:8px"><b class="grow" data-left="${c.id}"></b><button class="btn gold small" data-a="finish" data-job="${c.id}" data-dm="${c.id}">${h?`${ve.dm}${h} Finish now`:"Finish (free)"}</button></div>`}else o+=`<p class="desc">Pick a recipe. Longer recipes make more cells per credit: choose one that finishes when you'll be back.</p><div class="recipes">${Zu(s).map(d=>`<div class="rec ${d.open?"":"locked"}"><b>${ut(d.name)}</b><span class="out">⚡${st(d.out)}</span><span class="sub">${pe(d.sec)}</span>${d.open?`<button class="btn small" data-a="craft" data-id="${s.id}" data-r="${d.i}"><span class="cost" data-cost="credits:${d.cost}">${ve.credits}${st(d.cost)}</span></button>`:`<span class="why">Level ${d.lvl}</span>`}</div>`).join("")}</div>`;o+=this.upgradeRow(s,s.lvl<a.max?`Level ${s.lvl+1}: +10% cells${ta.some(d=>d.lvl===s.lvl+1)?", a new recipe":""}`:"")+this.crew.helpersHTML(s)+this.moveRow(s)}else o+=`<p class="desc">${ut(a.desc)}</p><div class="row"><button class="btn small" data-a="move" data-id="${s.id}">✥ Move</button><button class="btn small" data-a="sell" data-id="${s.id}">Sell (${ve.credits}${st(Math.floor(a.buildCost(0)*.5))})</button></div>`;t.innerHTML=o}moveRow(t){return`<div class="row" style="margin-top:8px"><button class="btn small" data-a="move" data-id="${t.id}">✥ Move</button></div>`}upgradeRow(t,e=""){const n=this.s,s=Qt[t.t];if(t.lvl>=s.max)return'<p class="sub">Maximum level.</p>';const a=qc(n,t);return`${e?`<div class="sub">${e}</div>`:""}<div class="row" style="margin-top:8px"><span class="grow">${a.cost?`<span class="cost ${n.res.credits<a.cost?"short":""}" data-cost="credits:${a.cost}">${ve.credits}${st(a.cost)}</span> · ${pe(a.time||0)}`:""}</span><button class="btn gold" data-a="upgrade" data-id="${t.id}" ${a.ok?"":"disabled"}>⬆ Upgrade</button></div>${a.ok?"":`<p class="why">${ut(a.why||"")}</p>`}`}botCard(t,e=!1){const n=this.s,s=tt[t.sp],a=Do(t.lvl),r=e&&t.bay?Re(n,t.bay):null;return`<div class="botc"><div class="pic" data-a="selBot" data-bot="${t.id}" style="cursor:pointer;background:radial-gradient(circle at 50% 40%, ${kt[s.el[0]].color}55, transparent 70%)"><img src="${this.app.studio.bot(t.sp)}" alt=""></div>
      <div><b data-a="selBot" data-bot="${t.id}" style="cursor:pointer">${ut(t.nick||s.name)}</b> ${Gr(s.el)}<div class="meta"><span class="rar" style="color:${qt[s.rarity].color}">${qt[s.rarity].name}</span> · Level ${t.lvl}<span class="pips">${[0,1,2,3].map(o=>`<i class="${o<t.fed?"on":""}"></i>`).join("")}</span></div><div class="meta">${t.post?"🛠 helping":t.stored?"❄ stored":`${ve.credits} ${st(wi(t))}/min`}${r?` · ${kt[r.el].name} Bay`:""}</div></div>
      ${t.lvl<Lo?`<button class="btn small green" data-a="feed" data-bot="${t.id}"><span class="cost" data-cost="cells:${a}">${ve.cells}${st(a)}</span></button>`:'<span class="sub">MAX</span>'}</div>`}openOver(t,e){this.over=t,e&&(this.tab=e),this.select(null),this.renderOver(),this.app.platform.gameplayStop()}closeOver(){this.over="",xe("#over").classList.add("hidden"),this.app.platform.gameplayStart()}renderOver(){const t=xe("#over");t.classList.remove("hidden");const e=this.s;if(this.over==="shop"){const n=e.at==="vault"?[["vault","Vault"],["decor","Decor"]]:[["bays","Bays"],["bots","Bots"],["buildings","Buildings"],["decor","Decor"]];e.at==="vault"&&!["vault","decor"].includes(this.tab)&&(this.tab="vault"),e.at!=="vault"&&this.tab==="vault"&&(this.tab="bays");let s="";this.tab==="bays"?s=O_.map(a=>{const r=Zn(e,"bay",a),o=zt(e,"bay").filter(l=>l.el===a).length;return this.shopCard(this.app.studio.building("bay",1,a,this.world.look),`${kt[a].name} Bay`,`${kt[a].blurb} ${o?`You have ${o}.`:""}`,r,`data-a="buyB" data-t="bay" data-el="${a}"`,Gr([a]))}).join(""):this.tab==="bots"?s=Qn.filter(a=>tt[a].price).map(a=>{const r=tt[a],o=Kc(e,a),l=e.bots.filter(c=>c.sp===a).length;return this.shopCard(this.app.studio.bot(a),r.name,r.desc+(r.rarity!=="standard"?` Boots in the Assembly Bay (${pe(qt[r.rarity].assembly*.5)}).`:""),o,`data-a="recruit" data-sp="${a}"`,`${Gr(r.el)} <span class="rar" style="color:${qt[r.rarity].color}">${qt[r.rarity].name}</span> · ${st(wi({sp:a,lvl:1}))}/min${l?` · owned ${l}`:""}${e.dex[a]?"":' · <b style="color:#ffd36a">new</b>'}`,(r.unlock||1)>e.lvl)}).join(""):this.tab==="vault"?s=[...["mine","forge"].map(a=>{const r=Zn(e,a);return this.shopCard(this.app.studio.building(a,1,void 0,this.world.look),Qt[a].name,Qt[a].desc,r,`data-a="buyB" data-t="${a}"`)}),...Object.keys(Ve).map(a=>{const r=Zn(e,"relicbay",a);return this.shopCard(this.app.studio.building("relicbay",1,a,this.world.look),`${Ve[a].name} Sanctum`,`Wakes ${Ve[a].name} Relic AIs. They earn Iridium here.`,r,`data-a="buyB" data-t="relicbay" data-el="${a}"`)}),(()=>{const a=Zn(e,"monolith");return this.shopCard(this.app.studio.building("monolith",1,void 0,this.world.look),Qt.monolith.name,Qt.monolith.desc,a,'data-a="buyB" data-t="monolith"')})()].join(""):this.tab==="buildings"?s=["fab","assembly","fusion"].map(a=>{const r=Zn(e,a);return this.shopCard(this.app.studio.building(a,1,void 0,this.world.look),Qt[a].name,Qt[a].desc,r,`data-a="buyB" data-t="${a}"`,a==="fab"?`${zt(e,a).length}/${Ws(ji(e))} built`:zt(e,a).length?"Built":`Unlocks at Commander level ${Qt[a].unlock}`,Qt[a].unlock>e.lvl)}).join(""):s=[...e.stats.decor_arch?["arch"]:[],...Wd.filter(a=>Qt[a].cat==="decor"&&!Qt[a].vault)].map(a=>{const r=Zn(e,a);return this.shopCard(this.app.studio.building(a,1,void 0,this.world.look),Qt[a].name,Qt[a].desc,r,`data-a="buyB" data-t="${a}"`,"",Qt[a].unlock>e.lvl)}).join(""),t.innerHTML=`<div class="head"><h1>Shop</h1><div class="res">${ve.credits}<span>${st(e.res.credits)}</span></div><button class="ibtn" data-a="close">✕</button></div><div class="tabs">${n.map(([a,r])=>`<button class="tab ${this.tab===a?"on":""}" data-a="tab" data-tab="${a}">${r}</button>`).join("")}</div><div class="body"><div class="grid">${s}</div></div>`}else if(this.over==="bots"){const n=[...e.bots].sort((r,o)=>wi(o)-wi(r)),s=e.bots.reduce((r,o)=>r+wi(o),0),a=e.cores.length?`<div class="botc" style="grid-template-columns:54px 1fr auto;border-color:var(--gold)"><div style="font-size:30px;text-align:center">🤖</div><div><b>${e.cores.length} core${e.cores.length>1?"s":""} waiting</b><div class="meta">${e.cores.map(r=>`<span style="color:${qt[tt[r.sp].rarity].color}">●</span>`).join(" ")} ${zt(e,"assembly").some(r=>r.lvl>0)?"in the Assembly Bay":"Build the Assembly Bay (Commander level 4) to boot them"}</div></div><span></span></div>`:"";t.innerHTML=`<div class="head"><h1>Your crew</h1><span class="sub">${e.bots.length} bots · ${ve.credits} ${st(s)}/min</span><button class="ibtn" data-a="close">✕</button></div><div class="body"><div class="bots" style="max-width:640px;margin:0 auto">${a}${n.map(r=>this.botCard(r,!0)).join("")}</div></div>`}else if(this.over==="custom")t.innerHTML=this.customHTML();else if(this.over==="dex")t.innerHTML=this.crew.dexHTML();else if(this.over==="daily")t.innerHTML=this.daily.overHTML();else if(this.over==="arena")t.innerHTML=this.arena.overHTML();else if(this.over==="event")t.innerHTML=this.vault.eventHTML();else if(this.over==="settings"){const n=e.settings;t.innerHTML=`<div class="head"><h1>Settings</h1><button class="ibtn" data-a="close">✕</button></div><div class="body"><div class="card" style="max-width:420px;margin:0 auto;gap:12px">
      <label>Sound effects <input type="range" min="0" max="1" step="0.05" value="${n.sfx}" data-set="sfx" style="width:100%"></label><label>Music <input type="range" min="0" max="1" step="0.05" value="${n.music}" data-set="music" style="width:100%"></label>
      <label>Graphics <select data-set="quality" style="width:100%;padding:8px;border-radius:8px;background:#0d1a2e;color:#fff;border:1px solid var(--line)">${["auto","high","low"].map(s=>`<option ${n.quality===s?"selected":""}>${s}</option>`).join("")}</select></label>
      <p class="sub">Starward 3D · version ${this.app.version} · web build. Your colony runs in real time, even while you are away.</p><button class="btn" data-a="reset">Reset progress</button></div></div>`}}shopCard(t,e,n,s,a,r="",o=!1){return`<div class="card ${o?"locked":""}"><div class="thumb"><img src="${t}" alt=""></div><b>${ut(e)}</b>${r?`<div class="sub" style="margin:0">${r}</div>`:""}<p class="desc">${ut(n)}</p>
      <button class="btn ${s.ok?"gold":""} small" ${a} ${s.ok?"":"disabled"}>${o?"🔒 ":""}${s.cost!==void 0?`<span class="cost" data-cost="credits:${s.cost}">${ve.credits}${st(s.cost)}</span>`:"Free"}</button>${s.ok?"":`<span class="why">${ut(s.why||"")}</span>`}</div>`}refreshOverCosts(){Es("#over [data-cost]").forEach(t=>{const[e,n]=t.dataset.cost.split(":");t.classList.toggle("short",this.s.res[e]<+n)})}customHTML(){const t=this.s,e=this.bannerSVG(t.banner);return`<div class="head"><h1>Colony style</h1><button class="ibtn" data-a="close">✕</button></div><div class="body"><div class="card" style="max-width:520px;margin:0 auto;gap:12px">
      <label class="ox">Colony name<input id="cname" value="${ut(t.name)}" maxlength="24" style="width:100%;margin-top:6px;padding:10px;border-radius:10px;border:1px solid var(--line);background:#0d1a2e;color:#fff;font:600 16px Barlow"></label>
      <div><div class="ox">Paint scheme</div><div class="row" style="margin-top:6px">${bu.map(([n,s],a)=>`<button data-a="paint" data-i="${a}" style="width:46px;height:46px;border-radius:12px;border:2px solid ${t.paint.primary===n&&t.paint.accent===s?"#fff":"transparent"};background:linear-gradient(135deg, ${n} 55%, ${s} 55%)"></button>`).join("")}</div></div>
      <div><div class="ox">Banner</div><div class="row" style="margin-top:6px;align-items:flex-start"><div style="width:120px">${e}</div><div class="grow"><div class="row">${B_.map(n=>`<button data-a="bannerBg" data-c="${n}" style="width:30px;height:30px;border-radius:8px;background:${n};border:2px solid ${t.banner.bg===n?"#fff":"transparent"}"></button>`).join("")}</div>
        <div class="row" style="margin-top:6px">${["#ffd23a","#ffffff","#14202e","#ff4f6a","#6ee7ff","#7cf29a"].map(n=>`<button data-a="bannerFg" data-c="${n}" style="width:30px;height:30px;border-radius:50%;background:${n};border:2px solid ${t.banner.fg===n?"#6ee7ff":"rgba(255,255,255,0.2)"}"></button>`).join("")}</div>
        <div class="row" style="margin-top:6px">${k_.map(n=>`<button class="btn small ${t.banner.emblem===n?"gold":""}" data-a="emblem" data-e="${n}">${this.bannerSVG({bg:"transparent",fg:"#ffffff",emblem:n},22)}</button>`).join("")}</div></div></div></div>
      <p class="sub">Your paint scheme recolours every building's trim; your banner flies over the Command Center and on every Colony Flag. More decorations, paints and banner parts unlock as you level up.</p></div></div>`}bannerSVG(t,e=120){const n=document.createElement("canvas");n.width=128,n.height=80;const s=n.getContext("2d");return t.bg!=="transparent"&&(s.fillStyle=t.bg,s.fillRect(0,0,128,80)),s.fillStyle=t.fg,s.translate(64,40),yd(s,t.emblem,26),s.fill(),`<img src="${n.toDataURL()}" style="width:${e}px;height:${e*80/128}px;border-radius:6px;display:block">`}renderPlace(){const t=xe("#place"),e=this.world.ghost;if(!e){t.classList.add("hidden");return}t.classList.remove("hidden");const n=Qt[e.t],s=e.move?null:Zn(this.s,e.t,e.el);t.innerHTML=`<span class="lbl">${ut(e.t==="bay"?`${kt[e.el].name} Bay`:n.name)}${s&&s.cost?` · ${ve.credits}${st(s.cost)}`:""}</span><button class="btn small" data-a="placeRot">⟳ Rotate</button><button class="btn small" data-a="placeCancel">✕</button><button class="btn green small" data-a="placeOk" ${e.ok?"":"disabled"}>✓ ${e.move?"Place":"Build"}</button>`}toast(t,e=""){const n=document.createElement("div");n.className="toast "+e,n.textContent=t,xe("#toasts").appendChild(n),setTimeout(()=>n.remove(),2600)}popText(t,e,n,s){const a=document.createElement("div");a.className="pop",a.style.left=t+"px",a.style.top=e+"px",a.style.color=s,a.textContent=n,document.body.appendChild(a),setTimeout(()=>a.remove(),1100)}flyTo(t,e,n,s=6){const a=xe(`#r-${t}`);if(!a)return;const r=a.getBoundingClientRect();for(let o=0;o<s;o++){const l=document.createElement("div");l.className="fly",l.innerHTML=ve[t].replace('class="ic','style="width:26px;height:26px" class="ic'),l.style.left=e-13+(Math.random()-.5)*40+"px",l.style.top=n-13+(Math.random()-.5)*30+"px",document.body.appendChild(l),setTimeout(()=>{l.style.transform=`translate(${r.left+13-parseFloat(l.style.left)}px, ${r.top+13-parseFloat(l.style.top)}px) scale(0.6)`,l.style.opacity="0.4"},30+o*45),setTimeout(()=>l.remove(),800+o*45)}}modal(t,e=!1){const n=xe("#modal");n.innerHTML=`${e?'<div class="rays"></div>':""}<div class="box">${t}</div>`,n.classList.remove("hidden"),this.app.platform.gameplayStop()}closeModal(){xe("#modal").classList.add("hidden"),xe("#modal").innerHTML="",this.over||this.app.platform.gameplayStart()}levelUp(t,e,n=null){const s=[...Qn.filter(a=>tt[a].unlock===t).map(a=>tt[a].name),...Wd.filter(a=>Qt[a].unlock===t).map(a=>Qt[a].name)];this.modal(`<div class="ox sub" style="letter-spacing:.2em">COMMANDER LEVEL</div><div class="big">${t}</div><h1>Level up!</h1><div class="rewards">${yu(e)}</div>${n?`<div class="sub" style="margin:0">Milestone bonus</div>${this.daily.giftLine(n)}`:""}${s.length?`<p class="desc">Unlocked: <b>${s.map(ut).join(", ")}</b></p>`:""}${Xs.indexOf(t)>1?`<p class="desc">You can now upgrade the Command Center to level ${Xs.indexOf(t)}.</p>`:""}<button class="btn gold" data-a="closeModal" style="margin-top:8px;min-width:160px">Awesome!</button>`,!0)}newBot(t){const e=tt[t.sp],n=Date.now()-(this.s.dex[t.sp]||0)<4e3&&Object.keys(this.s.dex).length>1,s=qt[e.rarity].color,a=We.indexOf(e.rarity);this.modal(`<div class="ox sub" style="letter-spacing:.2em;color:${s}">${n?"★ NEW SPECIES DISCOVERED ★":"NEW CREWMATE"}</div>${a>=2?`<div style="position:absolute;inset:0;border-radius:22px;box-shadow:inset 0 0 60px ${s}66;pointer-events:none"></div>`:""}<img src="${this.app.studio.bot(t.sp)}" style="width:180px;height:180px;margin:-6px auto -10px;display:block"><h1>${ut(e.name)}</h1><div>${Gr(e.el)} <span class="rar" style="color:${qt[e.rarity].color}">${qt[e.rarity].name}</span></div><p class="desc">${ut(e.desc)}</p><p class="sub">Earns ${ve.credits} ${st(wi(t))} per minute. Feed it Power Cells to level it up.</p><button class="btn gold" data-a="closeModal" style="min-width:160px">Welcome aboard!</button>`,!0)}act(t,e){const n=this.app,s=this.s;if(n.audio.unlock(),this.crew.act(t,e)||this.daily.act(t,e)||this.arena.act(t,e)||this.space.act(t,e)||this.vault.act(t,e))return;const a=e.dataset.id||"",r=a?Re(s,a):void 0;switch(t){case"shop":this.openOver("shop",e.dataset.tab||this.tab),n.audio.play("tap");break;case"bots":this.openOver("bots"),n.audio.play("tap");break;case"dex":this.openOver("dex"),n.audio.play("tap");break;case"custom":this.openOver("custom"),n.audio.play("tap");break;case"settings":this.openOver("settings"),n.audio.play("tap");break;case"close":this.closeOver(),n.audio.play("tap");break;case"tab":this.tab=e.dataset.tab,this.renderOver(),n.audio.play("tap");break;case"islands":{const o=Vp.map(l=>{const c=Sn[l],d=!!s.islands[l],h=d?null:Qc(s,l);return`<div class="botc" style="grid-template-columns:54px 1fr auto"><div style="font-size:34px;text-align:center">${{home:"🌍",moon:"🌕",mars:"🔴"}[l]}</div><div><b>${ut(l==="home"?s.name:c.name)}</b>${s.at===l?' <span class="tag" style="color:#7cf29a">you are here</span>':""}<div class="meta">${ut(c.blurb)}</div>${c.perk?`<div class="meta" style="color:#7cf29a">★ ${ut(c.perk)}</div>`:""}${!d&&h&&!h.ok?`<div class="why" style="margin:2px 0 0">${ut(h.why||"")}</div>`:""}</div>
            ${d?s.at===l?"<span></span>":`<button class="btn gold small" data-a="travel" data-k="${l}">Travel</button>`:`<button class="btn ${h&&h.ok?"gold":""} small" data-a="foundIsland" data-k="${l}" ${h&&h.ok?"":"disabled"}>Found ${ve.credits}${st(c.cost||0)}</button>`}</div>`}).join("");this.modal(`<h1 style="font-size:22px">Your islands</h1><p class="sub">Every island keeps working while you are elsewhere: bays fill and recipes finish everywhere.</p><div class="bots" style="text-align:left">${o}</div><button class="btn" data-a="closeModal" style="margin-top:10px">Close</button>`),n.audio.play("tap");break}case"travel":this.closeModal(),n.travel(e.dataset.k);break;case"foundIsland":{const o=ef(s,e.dataset.k);this.closeModal(),o.ok?n.travel(e.dataset.k,!0):this.deny(o.why);break}case"zoomout":this.world.focus(0,1,this.world.cam.tdist>45?30:58),n.audio.play("whoosh");break;case"deselect":this.select(null),this.selBot=null,this.renderPanel();break;case"select":a&&(this.select(a),n.audio.play("tap"));break;case"collect":r&&n.collect(r);break;case"harvest":r&&n.harvest(r);break;case"craft":if(r){const o=ju(s,r,+e.dataset.r);o.ok?(n.audio.play("buy"),n.changed(),this.renderPanel()):this.deny(o.why)}break;case"upgrade":if(r){const o=$u(s,r);o.ok?(n.audio.play("build"),n.changed(),this.renderPanel()):this.deny(o.why)}break;case"finish":{const o=s.jobs.find(l=>l.id===e.dataset.job);o&&Xu(s,o)?(n.audio.play("done"),n.changed(),this.renderPanel()):this.deny("Not enough Dark Matter");break}case"feed":{const o=s.bots.find(c=>c.id===e.dataset.bot);if(!o)break;const l=Yc(s,o);if(l.ok){n.audio.play(l.lvlUp?"done":"feed");const c=e.getBoundingClientRect();this.popText(c.left+c.width/2,c.top,l.lvlUp?`Level ${o.lvl}!`:"+XP",l.lvlUp?"#ffd36a":"#9dff5a"),n.changed(),this.over==="bots"?this.renderOver():this.renderPanel()}else this.deny(l.why);break}case"recruit":{const o=Yu(s,e.dataset.sp);if(o.ok&&o.core){n.audio.play("buy"),this.closeOver(),n.changed();const l=zt(s,"assembly")[0];if(l){const c=this.world.centerOf(l);this.world.focus(c.x,c.z),this.select(l.id)}this.toast("The core is booting in the Assembly Bay","good");break}if(o.ok&&o.bot){n.audio.play("buy"),this.closeOver(),n.changed(),this.newBot(o.bot);const l=Re(s,o.bot.bay);if(l){const c=this.world.centerOf(l);this.world.focus(c.x,c.z)}}else this.deny(o.why);break}case"buyB":{const o=e.dataset.t,l=e.dataset.el,c=Zn(s,o,l);if(!c.ok){this.deny(c.why);break}this.closeOver(),n.startPlacing({t:o,el:l,r:0,x:0,z:0,ok:!1});break}case"move":r&&(this.select(null),n.startPlacing({t:r.t,el:r.el,r:r.r,x:r.x,z:r.z,move:r.id,ok:!0}));break;case"sell":r&&Wu(s,r)&&(n.audio.play("buy"),this.select(null),n.changed());break;case"placeRot":this.world.rotateGhost(),n.audio.play("tap");break;case"placeCancel":n.endPlacing(),n.audio.play("tap");break;case"placeOk":n.confirmPlacing();break;case"plot":n.askPlot(a);break;case"buyPlot":{const o=Qu(s,e.dataset.k);this.closeModal(),o.ok?(n.audio.play("levelup"),n.changed(),this.toast("The island grows!","gold")):this.deny(o.why);break}case"claim":{const o=tf(s);if(o){n.audio.play("claim");const l=e.getBoundingClientRect();for(const c of Object.keys(o.reward))this.flyTo(c,l.left+l.width/2,l.top);n.changed(),this.renderObj()}break}case"closeModal":this.closeModal(),n.audio.play("tap");break;case"paint":{const[o,l]=bu[+e.dataset.i];s.paint={primary:o,accent:l},n.changed(),this.renderOver(),n.audio.play("tap");break}case"bannerBg":s.banner={...s.banner,bg:e.dataset.c},n.changed(),this.renderOver(),n.audio.play("tap");break;case"bannerFg":s.banner={...s.banner,fg:e.dataset.c},n.changed(),this.renderOver(),n.audio.play("tap");break;case"emblem":s.banner={...s.banner,emblem:e.dataset.e},n.changed(),this.renderOver(),n.audio.play("tap");break;case"reset":e.dataset.sure?n.reset():(e.dataset.sure="1",e.textContent="Tap again to erase your colony");break}}deny(t){this.toast(t||"Not possible","bad"),this.app.audio.play("deny")}}class $_{constructor(){this.ctx=null,this.out=null,this.vol=.8,this.mvol=.45,this.muted=!1,this.music=null,this.timer=0}unlock(){if(this.ctx){this.ctx.state==="suspended"&&this.ctx.resume();return}try{this.ctx=new(window.AudioContext||window.webkitAudioContext),this.out=this.ctx.createGain(),this.out.gain.value=this.muted?0:this.vol,this.out.connect(this.ctx.destination)}catch{this.ctx=null}}setVolume(t){this.vol=t,this.out&&(this.out.gain.value=this.muted?0:t)}setMuted(t){this.muted=t,this.out&&(this.out.gain.value=t?0:this.vol),this.music&&(this.music.bus.gain.value=t?0:this.mvol*.4)}tone(t,e,n,s="sine",a=.2,r=0){const o=this.ctx,l=o.createOscillator(),c=o.createGain();l.type=s,l.frequency.setValueAtTime(t,e),r&&l.frequency.exponentialRampToValueAtTime(Math.max(30,t*r),e+n),c.gain.setValueAtTime(0,e),c.gain.linearRampToValueAtTime(a,e+.008),c.gain.exponentialRampToValueAtTime(1e-4,e+n),l.connect(c),c.connect(this.out),l.start(e),l.stop(e+n+.05)}noise(t,e,n=.2,s=800){const a=this.ctx,r=a.createBuffer(1,Math.floor(a.sampleRate*e),a.sampleRate),o=r.getChannelData(0);for(let h=0;h<o.length;h++)o[h]=(Math.random()*2-1)*(1-h/o.length);const l=a.createBufferSource();l.buffer=r;const c=a.createBiquadFilter();c.type="lowpass",c.frequency.value=s;const d=a.createGain();d.gain.value=n,l.connect(c),c.connect(d),d.connect(this.out),l.start(t)}play(t,e=1){if(!this.ctx||!this.out||this.muted)return;const n=this.ctx.currentTime;switch(t){case"tap":this.tone(880,n,.06,"triangle",.08);break;case"collect":{const s=Math.min(6,2+Math.floor(Math.log10(Math.max(1,e))));[0,4,7,12,16,19].slice(0,s).forEach((a,r)=>this.tone(988*Math.pow(2,a/12),n+r*.055,.22,"triangle",.12));break}case"harvest":[0,5,9].forEach((s,a)=>this.tone(660*Math.pow(2,s/12),n+a*.06,.2,"square",.05)),this.tone(1320,n+.2,.3,"sine",.08);break;case"build":this.noise(n,.12,.25,500),this.tone(120,n,.18,"sine",.3,.5);break;case"place":this.tone(220,n,.12,"sine",.25,.6),this.noise(n,.08,.15,1200);break;case"done":[0,4,7,12].forEach((s,a)=>this.tone(523*Math.pow(2,s/12),n+a*.08,.3,"triangle",.12));break;case"feed":this.tone(300,n,.15,"sawtooth",.06,2.2),this.tone(600,n+.05,.12,"square",.04,1.6);break;case"levelup":[0,4,7,12,16,19,24].forEach((s,a)=>this.tone(392*Math.pow(2,s/12),n+a*.07,.5,"triangle",.13)),[0,4,7].forEach(s=>this.tone(784*Math.pow(2,s/12),n+.55,.9,"sine",.09));break;case"deny":this.tone(180,n,.16,"square",.07,.7);break;case"buy":this.tone(660,n,.1,"triangle",.1),this.tone(990,n+.08,.18,"triangle",.1);break;case"claim":[0,7,12].forEach((s,a)=>this.tone(659*Math.pow(2,s/12),n+a*.07,.35,"triangle",.12));break;case"whoosh":this.noise(n,.35,.18,2400);break}}setMusic(t){this.mvol=t,this.music?this.music.bus.gain.setTargetAtTime(this.muted?0:t*.4,this.ctx.currentTime,.4):t>0&&this.startMusic()}startMusic(){if(!this.ctx||this.music||this.mvol<=0)return;const t=this.ctx,e=t.createGain();e.gain.value=0,e.gain.setTargetAtTime(this.muted?0:this.mvol*.4,t.currentTime,2),e.connect(t.destination);const n=t.createBiquadFilter();n.type="lowpass",n.frequency.value=1200,n.connect(e),this.music={bus:e,next:t.currentTime+.5,chord:0,lp:n},this.timer=window.setInterval(()=>this.tick(),300)}tick(){const t=this.ctx,e=this.music;if(!t||!e||t.state!=="running")return;const n=t.currentTime;if(n<e.next)return;const s=[[261.63,329.63,392,493.88],[220,261.63,329.63,392],[174.61,220,261.63,329.63],[196,246.94,293.66,392],[233.08,293.66,349.23,440]],a=s[e.chord%s.length];e.chord+=1+(Math.random()<.25?1:0);const r=9;for(const o of a)for(const l of[-6,5]){const c=t.createOscillator();c.type="sawtooth",c.frequency.value=o/2,c.detune.value=l;const d=t.createGain();d.gain.setValueAtTime(0,n),d.gain.linearRampToValueAtTime(.011,n+3),d.gain.setValueAtTime(.011,n+r-2.5),d.gain.linearRampToValueAtTime(0,n+r+1),c.connect(d),d.connect(e.lp),c.start(n),c.stop(n+r+1.5)}for(let o=0;o<3;o++){const l=a[Math.floor(Math.random()*a.length)]*2,c=t.createOscillator();c.type="sine",c.frequency.value=l;const d=t.createGain(),h=n+1+o*2.4+Math.random();d.gain.setValueAtTime(0,h),d.gain.linearRampToValueAtTime(.03,h+.01),d.gain.exponentialRampToValueAtTime(1e-4,h+2.5),c.connect(d),d.connect(e.bus),c.start(h),c.stop(h+2.6)}e.lp.frequency.setTargetAtTime(800+Math.random()*900,n,3),e.next=n+r-1.5}}const Vr="starward3d_v1";class H_{constructor(){this.version="0.2",this.platform=Rp,this.audio=new $_,this.last=performance.now(),this.saveAt=0,this.queue=[],this.dayCheck=0,this.spaceCheck=0}async boot(){await this.platform.init(),this.platform.loadingStart();const t=this.platform.load(Vr);let e;try{e=t?Dp(JSON.parse(t)):zl()}catch(c){console.warn("save unreadable, starting fresh",c),e=zl()}this.s=e;const n=Date.now()-(e.last||Date.now());La(e,Date.now());const s=on.filter(c=>c.kind==="built").length;on.length=0,Oc(e),Xa(e);const a=zt(e,"bay").map(c=>Math.floor(e.bay[c.id]||0)).filter(c=>c>=1),r={credits:a.reduce((c,d)=>c+d,0),bays:a.length,ready:Object.keys(e.ready).length,cores:e.cores.filter(c=>c.state==="ready").length,built:s};this.world=new A_(xe("#gl"),e.settings.quality),this.studio=new T_(this.world.renderer),this.ui=new z_(this),this.audio.setVolume(e.settings.sfx),this.audio.mvol=e.settings.music,this.platform.onMute=c=>this.audio.setMuted(c),this.platform.muted()&&this.audio.setMuted(!0),this.world.onTap=c=>this.tapped(c),this.world.onGhostMove=()=>this.validatePlacing(),this.world.sync(e);const o=zt(e,"command")[0];if(o){const c=this.world.centerOf(o);this.world.cam.x=this.world.cam.tx=c.x-1,this.world.cam.z=this.world.cam.tz=c.z+1}document.addEventListener("pointerdown",()=>{this.audio.unlock(),this.audio.setMusic(this.s.settings.music)},{once:!0}),document.addEventListener("visibilitychange",()=>{document.hidden?this.save():La(this.s,Date.now())}),window.addEventListener("pagehide",()=>this.save()),requestAnimationFrame(c=>this.loop(c)),this.platform.loadingStop();const l=xe("#load");l.style.opacity="0",setTimeout(()=>l.remove(),500),this.platform.gameplayStart(),t&&n>10*6e4&&setTimeout(()=>this.enqueue(()=>this.ui.daily.offlineReport(n,r)),600),t||setTimeout(()=>this.ui.modal(`<div class="ox sub" style="letter-spacing:.2em">WELCOME, COMMANDER</div><h1>${ut(e.name)}</h1><p class="desc">An asteroid in low Earth orbit, a Command Center, a fabricator and one small, cheerful robot named Helio. Everything else is up to you.</p><p class="desc">Your bots earn credits in their bays. Tap a bay to collect, print Power Cells, feed your crew and grow the colony.</p><button class="btn gold" data-a="closeModal" style="min-width:180px">Let's go!</button>`,!0),400),window.__app=this,window.__G=sm,window.__daily=i_}loop(t){const e=Math.min(.05,(t-this.last)/1e3);this.last=t;const n=Date.now();if(La(this.s,n),Oc(this.s,n),n>this.spaceCheck){this.spaceCheck=n+1e3;for(const s of b_(this.s,n))this.changed(),this.enqueue(()=>this.ui.space.reveal(s))}if(n>this.dayCheck){this.dayCheck=n+5e3,Xa(this.s,n),this.placeDrop(),hp(this.s,n);const s=f_(this.s,n);s&&s.kind==="warn"&&(this.audio.play("deny"),this.ui.toast("⚠ A Kr'thul raid is coming: defend your colony!","bad"),this.platform.notify("raid",Date.now()+6e4,"Swarm raid incoming!","The Kr'thul arrive in 2 hours. Defend your colony!")),s&&s.kind==="hit"&&this.enqueue(()=>this.ui.modal(`<div class="ox sub" style="letter-spacing:.2em;color:#ff6b7a">RAID</div><div class="big">🔥</div><h1>The Swarm raided the colony</h1><p class="desc">Nobody stood in their way. They carried off ${st(s.stolen)} credits from your bays.</p><p class="sub">Next time, tap the red Swarm warning at the top and defend with your Arena team.</p><button class="btn gold" data-a="closeModal">We'll be ready</button>`));const a=fp(this.s,n);a&&this.enqueue(()=>this.ui.modal(`<div class="ox sub" style="letter-spacing:.2em">ARENA SEASON ENDED</div><div class="big">🏆</div><h1>${Ki[a.league][0]}</h1><p class="desc">Your best league this season. Here are your rewards:</p><div class="rewards">${Object.entries(a.reward).map(([r,o])=>`<span class="cost">${r==="dm"?"◆":r==="cells"?"⚡":"C"} ${st(o)}</span>`).join(" ")}</div><button class="btn gold" data-a="closeModal">Collect</button>`,!0))}this.drain(),this.world.frame(e,this.s),this.ui.frame(),n>this.saveAt&&(this.saveAt=n+1e4,this.save()),requestAnimationFrame(s=>this.loop(s))}drain(){for(;on.length;){const t=on.shift();if(t.kind==="levelup"){this.audio.play("levelup"),this.platform.happytime();const e=t.lvl%5===0?ns(this.s,t.lvl%10===0?"advanced":"standard",t.lvl*7919+(this.s.created>>>0)):null;this.enqueue(()=>this.ui.levelUp(t.lvl,t.reward,e)),this.ui.renderHud()}else if(t.kind==="built"){this.audio.play("done"),this.world.topOf(t.item),this.changed();const e=Re(this.s,t.item);if(e){const n=this.world.topOf(e.id);n&&this.world.burst(n,"#ffd36a",30),this.ui.toast(`${e.t==="bay"?"Bay":Qt[e.t].name} ${t.first?"is ready":`reached level ${t.lvl}`}!`,"good")}}else if(t.kind==="crafted")this.changed();else if(t.kind==="discover")this.ui.toast(`New species in the Botdex: +${t.dm} Dark Matter`,"gold");else if(t.kind==="fused")this.audio.play("done"),this.changed(),this.ui.toast(`Fusion complete: a ${qt[tt[t.sp].rarity].name} core is in the Assembly Bay`,"gold");else if(t.kind==="booted")this.audio.play("claim"),this.changed(),this.ui.toast(`A ${qt[tt[t.sp].rarity].name} core has booted: activate it in the Assembly Bay`,"good");else if(t.kind==="core")this.changed();else if(t.kind==="launch"){const e=Ed(this.s);this.changed(),e&&(this.world.launchFx(e.id,Xi(e.lvl)),this.audio.play("whoosh"))}else if(t.kind==="expBack")this.audio.play("levelup"),this.changed();else if(t.kind==="land")this.changed();else if(t.kind==="dug"){this.audio.play("done"),this.changed();const e=this.world.topOf(t.item);e&&this.world.burst(e,"#c49bff",24),this.ui.toast("Crystals dug up: tap the mine to collect","good")}else if(t.kind==="evolved"){this.audio.play("levelup"),this.platform.happytime(),this.changed();const e=this.s.bots.find(n=>n.id===t.bot);e&&this.ui.toast(`${ut(tt[e.sp].name)} evolved to ${"★".repeat(t.stars)}`,"gold")}}this.queue.length&&xe("#modal").classList.contains("hidden")&&this.queue.shift()()}enqueue(t){this.queue.push(t)}placeDrop(){const t=me(this.s);if(t.drops<=0){t.dropAt&&(t.dropAt=null,this.world.sync(this.s));return}if(t.dropAt&&hs(this.s,t.dropAt[0],t.dropAt[1],1,1)){this.world.podTop()||this.world.sync(this.s);return}const e=zt(this.s,"command")[0],n=e?e.x+2:15,s=e?e.z+2:15;let a=null,r=1e9;for(let o=0;o<30;o++)for(let l=0;l<30;l++){if(!hs(this.s,o,l,1,1))continue;const c=Math.abs(Math.hypot(o-n,l-s)-4.5);c<r&&(r=c,a=[o,l])}t.dropAt=a,this.world.sync(this.s)}changed(){this.world.sync(this.s),this.ui.renderObjIfChanged(),this.saveAt=Math.min(this.saveAt,Date.now()+1500)}save(){try{this.platform.save(Vr,JSON.stringify(this.s))}catch{}this.notifications()}notifications(){if(this.platform.name!=="mobile")return;const t=this.s,e=Date.now();let n=1/0;for(const o of zt(t,"bay")){const l=Io(t,o.id);l>0&&(n=Math.min(n,e+(Wi(o,t)-(t.bay[o.id]||0))/l*1e3))}isFinite(n)&&this.platform.notify("bays",n,"Your bays are full","Your crew has filled their bays with credits. Come and collect!");const s=t.jobs.filter(o=>o.kind==="craft").map(o=>o.end).sort()[0];s&&this.platform.notify("fab",s,"Power Cells ready","Your Fabricator has finished printing.");const a=me(t);this.platform.notify("drop",a.drops?e+36e5:a.drop,"A supply drop has landed","Open it before the next one arrives.");const r=new Date;r.setDate(r.getDate()+1),r.setHours(19,0,0,0),this.platform.notify("daily",r.getTime(),"Your daily reward is waiting",`Day ${a.day+1} of your calendar is ready. Keep the streak going!`)}tapped(t){this.audio.unlock();const e=this.s;if(t.drop){const n=this.world.podTop();this.ui.daily.act("drop",document.body),n&&this.world.burst(n,"#7cf29a",40),this.placeDrop();return}if(t.bot){this.ui.selectBot(t.bot),this.audio.play("tap");return}if(t.item){const n=Re(e,t.item);if(!n)return;if(n.t==="bay"&&(e.bay[n.id]||0)>=1&&!Ee(e,n.id,"build")){this.collect(n),this.ui.sel!==n.id&&this.ui.select(n.id);return}if(n.t==="fab"&&e.ready[n.id]){this.harvest(n),this.ui.select(n.id);return}if(n.t==="mine"&&qe(e).ready[n.id]){const s=Lu(e,n);if(s){this.audio.play("harvest");const a=this.world.topOf(n.id);if(a){this.world.burst(a,Ve[s.color].color,26);const r=this.world.project(a);this.ui.popText(r.x,r.y-10,`+${s.n} ${Ve[s.color].name}`,Ve[s.color].color)}this.changed()}this.ui.sel!==n.id?this.ui.select(n.id):this.ui.renderPanel();return}if(n.t==="relicbay"&&(e.bay[n.id]||0)>=1){this.collect(n),this.ui.sel!==n.id&&this.ui.select(n.id);return}this.ui.select(this.ui.sel===n.id?null:n.id),this.audio.play("tap");return}if(t.plot){this.askPlot(t.plot);return}this.ui.select(null)}collect(t){const e=Zc(this.s,t);if(!e)return;this.audio.play("collect",e);const n=t.t==="relicbay",s=n?"#c49bff":"#ffd36a",a=this.world.topOf(t.id);if(a){this.world.burst(a,s,18+Math.min(30,Math.floor(Math.log10(e)*6)));const r=this.world.project(a);this.ui.popText(r.x,r.y-10,`+${st(e)}${n?" ✦":""}`,s),this.ui.flyTo(n?"iridium":"credits",r.x,r.y,Math.min(9,3+Math.floor(Math.log10(e)*2)))}this.changed(),this.ui.renderPanel()}harvest(t){const e=Jc(this.s,t);if(!e)return;this.audio.play("harvest");const n=this.world.topOf(t.id);if(n){this.world.burst(n,"#9dff5a",26);const s=this.world.project(n);this.ui.popText(s.x,s.y-10,`+${st(e)} ⚡`,"#9dff5a"),this.ui.flyTo("cells",s.x,s.y,6)}this.changed(),this.ui.renderPanel()}askPlot(t){const e=this.s,n=jc(e,t),s=Uo(e),a=Fo(e);this.ui.modal(`<div class="ox sub" style="letter-spacing:.2em">EXPAND THE ISLAND</div><h1>New land</h1><p class="desc">Tow in another 6×6 slab of asteroid and bolt it to your island: room for more bays, fabricators and decorations.</p><div class="rewards"><span class="cost ${e.res.credits<s?"short":""}"><span class="ic cr">C</span>${st(s)}</span></div>${n.ok?"":`<p class="why">${ut(n.why||"")}</p>`}<div class="row" style="justify-content:center"><button class="btn" data-a="closeModal">Not now</button><button class="btn gold" data-a="buyPlot" data-k="${t}" ${n.ok?"":"disabled"}>Expand</button></div>${e.lvl<a?`<p class="sub">Reach Commander level ${a} to expand.</p>`:""}`)}startPlacing(t){const e=this.s;if(!t.move){const[n,s]=fn({t:t.t,r:t.r}),a=Math.round(this.world.cam.tx+15-n/2),r=Math.round(this.world.cam.tz+15-s/2);let o=null,l=1e9;for(let c=0;c<30;c++)for(let d=0;d<30;d++)if(hs(e,c,d,n,s)){const h=(c-a)**2+(d-r)**2;h<l&&(l=h,o=[c,d])}if(!o){this.ui.deny("No free space: expand the island or move things around");return}[t.x,t.z]=o}this.world.startGhost(t),this.world.sync(e),this.validatePlacing(),this.ui.select(null),this.audio.play("tap")}validatePlacing(){const t=this.world.ghost;if(!t)return;const[e,n]=fn({t:t.t,r:t.r});this.world.setGhostOk(hs(this.s,t.x,t.z,e,n,t.move)),this.ui.renderPlace()}confirmPlacing(){const t=this.world.ghost;if(!t||!t.ok)return;const e=this.s;if(t.move){const a=Re(e,t.move);a&&Vu(e,a,t.x,t.z,t.r)&&(this.audio.play("place"),this.endPlacing(),this.changed(),this.ui.select(a.id));return}const n=ku(e,t.t,t.x,t.z,t.r,t.el);if(!n.ok){this.ui.deny(n.why);return}this.audio.play(Qt[t.t].cat==="decor"?"place":"build"),this.changed();const s=n.item?this.world.topOf(n.item.id):null;if(s&&this.world.burst(s,"#6ee7ff",16),Qt[t.t].cat==="decor"&&Zn(e,t.t).ok){this.validatePlacing(),this.ui.renderPlace();return}this.endPlacing(),n.item&&Qt[t.t].cat!=="decor"&&this.ui.select(n.item.id)}endPlacing(){this.world.endGhost(),this.world.sync(this.s),this.ui.renderPlace()}travel(t,e=!1){const n=this.s;if(!e&&!nf(n,t))return;this.ui.select(null),this.audio.play("whoosh");const s=document.createElement("div");s.className="warp",document.body.appendChild(s),setTimeout(()=>{this.world.sync(n);const a=Xc(n,n.at==="home"?"command":"hub")[0];if(a){const r=this.world.centerOf(a);this.world.cam.x=this.world.cam.tx=r.x-1,this.world.cam.z=this.world.cam.tz=r.z+1}this.ui.renderHud(),this.placeDrop()},250),setTimeout(()=>s.remove(),900),e&&setTimeout(()=>this.ui.modal(`<div class="ox sub" style="letter-spacing:.2em">NEW ISLAND</div><h1>${ut(Sn[t].name)}</h1><p class="desc">${ut(Sn[t].blurb)}</p><p class="desc" style="color:#7cf29a">★ ${ut(Sn[t].perk||"")}</p><p class="sub">Build bays and fabricators here: bots of any element can live on any island. Use the island button at the top to travel.</p><button class="btn gold" data-a="closeModal">Let's build</button>`,!0),700),this.changed()}setSetting(t,e){this.s.settings[t]=e,t==="sfx"&&this.audio.setVolume(e),t==="music"&&this.audio.setMusic(e),t==="quality"&&(this.save(),this.ui.toast("Graphics change applies after a reload","gold")),this.save()}reset(){this.platform.save(Vr,"");try{localStorage.removeItem(Vr)}catch{}location.reload()}}new H_().boot().catch(i=>{console.error(i);const t=document.getElementById("load");t&&(t.innerHTML='<div style="text-align:center;padding:20px"><div class="logo">STARWARD</div><p>Your device could not start WebGL. Try another browser.</p></div>')});
