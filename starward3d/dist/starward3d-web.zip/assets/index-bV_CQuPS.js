(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const s of document.querySelectorAll('link[rel="modulepreload"]'))n(s);new MutationObserver(s=>{for(const a of s)if(a.type==="childList")for(const r of a.addedNodes)r.tagName==="LINK"&&r.rel==="modulepreload"&&n(r)}).observe(document,{childList:!0,subtree:!0});function t(s){const a={};return s.integrity&&(a.integrity=s.integrity),s.referrerPolicy&&(a.referrerPolicy=s.referrerPolicy),s.crossOrigin==="use-credentials"?a.credentials="include":s.crossOrigin==="anonymous"?a.credentials="omit":a.credentials="same-origin",a}function n(s){if(s.ep)return;s.ep=!0;const a=t(s);fetch(s.href,a)}})();const Zd={save(i,e){try{localStorage.setItem(i,e)}catch{}},load(i){try{return localStorage.getItem(i)}catch{return null}}},Fp={name:"web",adsAvailable:!1,onMute:null,async init(){},loadingStart(){},loadingStop(){},gameplayStart(){},gameplayStop(){},happytime(){},async rewarded(){return!1},async midgame(){return!1},save:Zd.save,load:Zd.load,muted:()=>!1,notify(){},cancelNotify(){}},ni=(i,e=0,t=1)=>i<e?e:i>t?t:i;function se(i){if(!isFinite(i))return"∞";const e=Math.abs(i);if(e<1e3)return String(Math.floor(i));const t=["K","M","B","T","Qa","Qi"];let n=-1,s=e;for(;s>=1e3&&n<t.length-1;)s/=1e3,n++;return(i<0?"-":"")+(s>=100?Math.floor(s):s>=10?s.toFixed(1).replace(/\.0$/,""):s.toFixed(2).replace(/\.?0+$/,""))+t[n]}function xt(i){if(i=Math.max(0,Math.ceil(i)),i<60)return i+"s";const e=Math.floor(i/86400),t=Math.floor(i%86400/3600),n=Math.floor(i%3600/60),s=i%60;return e?`${e}d ${t}h`:t?`${t}h ${n}m`:s&&n<10?`${n}m ${s}s`:`${n}m`}const re=i=>String(i).replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]);function Ln(i){let e=i>>>0;return()=>{e=e+1831565813|0;let t=Math.imul(e^e>>>15,1|e);return t=t+Math.imul(t^t>>>7,61|t)^t,((t^t>>>14)>>>0)/4294967296}}function ea(i){let e=2166136261;for(let t=0;t<i.length;t++)e^=i.charCodeAt(t),e=Math.imul(e,16777619);return e>>>0}let Op=0;const Jt=(i="x")=>i+Date.now().toString(36)+(Op++).toString(36)+Math.floor(Math.random()*1296).toString(36),vt=(i,e=document)=>e.querySelector(i),Ts=(i,e=document)=>Array.from(e.querySelectorAll(i)),Ye=i=>{if(i<100)return Math.round(i);const e=Math.pow(10,Math.floor(Math.log10(i))-1);return Math.round(i/e)*e},kp=100,Yl=i=>Math.round(40*Math.pow(i,1.85)),Bp=i=>({dm:3+Math.floor(i/5),credits:100*i}),ro=[{id:"a1",text:"Tap the Solar Bay to collect the credits Helio earned",kind:"collect",n:1,reward:{credits:150},hint:"bay"},{id:"a2",text:"Start a recipe at the Fabricator",kind:"craft",n:1,reward:{cells:20},hint:"fab"},{id:"a3",text:"Harvest Power Cells from the Fabricator",kind:"harvest",n:1,reward:{credits:100},hint:"fab"},{id:"a4",text:"Feed Helio until it reaches level 2",kind:"botLevel",n:2,reward:{cells:40,dm:5},hint:"bay"},{id:"a5",text:"Recruit Ember from the Shop (Bots tab)",kind:"ownSpecies",t:"ember",reward:{credits:200},hint:"shop"},{id:"a6",text:"Build a Plasma Bay so Ember has a home",kind:"bayEl",t:"plasma",reward:{credits:250},hint:"shop"},{id:"a7",text:"Upgrade the Command Center to level 2",kind:"cc",n:2,reward:{dm:10,credits:300},hint:"command"},{id:"a8",text:"Place a decoration (Shop → Decor)",kind:"decor",n:1,reward:{credits:150}},{id:"a9",text:"Raise any bot to level 4",kind:"botLevel",n:4,reward:{cells:150,dm:10}},{id:"a10",text:"Upgrade a Bay to level 2 (more credit storage)",kind:"bayLevel",n:2,reward:{credits:500}},{id:"a11",text:"Expand the island: buy a new plot of land",kind:"land",n:1,reward:{dm:15}},{id:"a12",text:"Run 4 bots",kind:"bots",n:4,reward:{credits:800}},{id:"a13",text:"Reach Commander level 6",kind:"level",n:6,reward:{dm:20}},{id:"a14",text:"Upgrade the Command Center to level 4",kind:"cc",n:4,reward:{credits:2500,dm:15}},{id:"b1",text:"Build the Assembly Bay (Shop → Buildings)",kind:"build",t:"assembly",reward:{credits:1e3,dm:10}},{id:"b2",text:"Post a bot as a helper at the Fabricator (tap a bot)",kind:"helper",reward:{cells:300}},{id:"b3",text:"Build the Fusion Lab",kind:"build",t:"fusion",reward:{credits:1500,dm:15}},{id:"b4",text:"Fuse two level-4 bots in the Fusion Lab",kind:"fusions",n:1,reward:{cells:400,dm:10}},{id:"b5",text:"Boot the new core in the Assembly Bay and activate it",kind:"boots",n:1,reward:{credits:1500}},{id:"a15",text:"Recruit an Advanced hybrid bot",kind:"rarity",t:"advanced",reward:{dm:30}},{id:"b6",text:"Discover 12 species in the Botdex",kind:"dex",n:12,reward:{dm:25}},{id:"b7",text:"Upgrade the Command Center to level 6",kind:"cc",n:6,reward:{credits:8e3,dm:20}},{id:"b8",text:"Fuse an Elite bot (three elements)",kind:"rarity",t:"elite",reward:{dm:40}},{id:"b9",text:"Discover 25 species",kind:"dex",n:25,reward:{dm:40}},{id:"b10",text:"Fuse an Epic bot",kind:"rarity",t:"epic",reward:{dm:60}},{id:"c1",text:"Build the Arena (Shop → Buildings)",kind:"build",t:"arena",reward:{credits:3e3,dm:15}},{id:"c2",text:"Win your first Arena battle",kind:"arenaWins",n:1,reward:{cells:500,dm:15}},{id:"c3",text:"Reach the Silver league",kind:"trophies",n:350,reward:{dm:30}},{id:"b11",text:"Reach Commander level 20",kind:"level",n:20,reward:{dm:50}},{id:"d1",text:"Build the Launch Pad (Shop → Buildings)",kind:"build",t:"pad",reward:{credits:6e3,dm:20}},{id:"d2",text:"Send a bot crew to the Moon (Space)",kind:"visit",t:"moon",reward:{cells:1500,dm:15}},{id:"d3",text:"Build an outpost on a world you have visited",kind:"outposts",n:1,reward:{credits:8e3}},{id:"c4",text:"Reach the Gold league",kind:"trophies",n:850,reward:{dm:60}},{id:"e1",text:"Found Tranquility Base on the Moon (island button, top left)",kind:"island",t:"moon",reward:{credits:2e4,dm:30}},{id:"e2",text:"Build a Bay on the Moon",kind:"bayOn",t:"moon",reward:{cells:5e3}},{id:"d4",text:"Land a crew on Mars",kind:"visit",t:"mars",reward:{dm:40}},{id:"e3",text:"Found Bradbury Landing on Mars",kind:"island",t:"mars",reward:{credits:1e5,dm:60}},{id:"d5",text:"Reach Europa's hidden ocean",kind:"visit",t:"europa",reward:{dm:60}},{id:"d6",text:"Reach Pluto, the edge of the Solar System",kind:"visit",t:"pluto",reward:{dm:120}},{id:"f1",text:"Repel a Kr'thul raid (tap the red Swarm warning)",kind:"raids",n:1,reward:{dm:40,cells:8e3}},{id:"f2",text:"Make first contact at Proxima Centauri (Starship, Launch Pad level 10)",kind:"visit",t:"proxima",reward:{dm:150}},{id:"h1",text:"Claim a reward in this week's event (event button, top right)",kind:"eventSteps",n:1,reward:{dm:25}},{id:"f3",text:"Meet all five civilisations",kind:"visit",t:"epseri",reward:{dm:300}},{id:"g1",text:"Found the Precursor Vault (island button)",kind:"island",t:"vault",reward:{dm:200}},{id:"g2",text:"Summon your first Relic AI",kind:"relics",n:1,reward:{dm:100}},{id:"g3",text:"Forge relic crystals at the Relic Forge twice",kind:"forged",n:2,reward:{dm:150}},{id:"g4",text:"Run six Relic AIs",kind:"relics",n:6,reward:{dm:300}}],Eu=1;function Kl(i=Date.now()){const e=(r,o,l,c=1,d)=>({id:Jt("i"),t:r,x:o,z:l,r:0,lvl:c,...d?{el:d}:{}}),t=e("command",13,13),n=e("bay",8,9,1,"solar"),s=e("fab",19,9);return{v:Eu,created:i,last:i,name:"New Haven",res:{credits:600,cells:30,dm:25,iridium:0},xp:0,lvl:1,islands:{home:{plots:["1,1","2,1","3,1","1,2","2,2","3,2","1,3","2,3","3,3"],bought:0,items:[t,n,s,e("tree",12,9),e("tree",17,18),e("rock",8,19),e("tree",9,18),e("path",14,17),e("path",15,17),e("path",14,18),e("path",15,18)]}},at:"home",bots:[{id:Jt("b"),sp:"helio",lvl:1,fed:0,bay:n.id,born:i}],jobs:[],cores:[],dex:{helio:i},bay:{[n.id]:120},ready:{},obj:{i:0,claimed:{}},stats:{},settings:{sfx:.8,music:.45,quality:"auto"},paint:{primary:"#e9eef5",accent:"#22c7e8"},banner:{bg:"#1b6fd8",fg:"#ffd23a",emblem:"star"},builders:2,landBought:0,tut:0}}function zp(i){const e=Kl(i.created||Date.now()),t=i;t.isl&&!t.islands&&(t.islands={home:{plots:t.isl.plots,items:t.isl.items,bought:t.landBought||0}},t.at="home",delete t.isl);for(const s in e)t[s]===void 0&&(t[s]=e[s]);for(const s in e.settings)t.settings[s]===void 0&&(t.settings[s]=e.settings[s]);t.res.iridium===void 0&&(t.res.iridium=0);for(const s of i.bots)i.dex[s.sp]||(i.dex[s.sp]=s.born||Date.now());const n=ro.findIndex(s=>!i.obj.claimed[s.id]);return i.obj.i=n<0?ro.length:n,i.v=Eu,i}const Jd=[3,20,60,180,600,1800,3600,2*3600,4*3600,8*3600,12*3600,16*3600,24*3600,36*3600,48*3600],Kn=(i,e=0)=>Jd[Math.min(Jd.length-1,Math.max(0,i-1+e))],en=(i,e,t,n,s)=>({name:i,size:e,cat:"decor",max:1,unlock:n,desc:s,buildCost:()=>t,upCost:()=>0,time:()=>0}),Qe={command:{name:"Command Center",size:[4,4],cat:"core",max:15,unique:!0,unlock:1,desc:"The heart of your colony. Its level sets how far every other building can grow, and how many Bays and Fabricators you can run.",buildCost:()=>0,upCost:i=>Ye(400*Math.pow(2.05,i-1)),time:i=>Kn(i,0)},hub:{name:"Colony Hub",size:[4,4],cat:"core",max:13,unlock:1,desc:"The heart of an off-world island. Its level caps every building here, and it stays two levels below your Command Center.",buildCost:()=>0,upCost:i=>Ye(900*Math.pow(2.05,i-1)),time:i=>Kn(i,1)},bay:{name:"Bot Bay",size:[3,3],cat:"bay",max:10,unlock:1,desc:"Home and charging dock for bots of its element. Bots earn credits here; the bay holds them until you collect.",buildCost:i=>Ye(150*Math.pow(1.6,i)),upCost:i=>Ye(250*Math.pow(1.9,i-1)),time:i=>Kn(i,-1)},fab:{name:"Fabricator",size:[3,3],cat:"production",max:10,unlock:1,desc:"Prints Power Cells for your bots. Pick a recipe that matches when you will be back.",buildCost:i=>Ye(300*Math.pow(2.4,i)),upCost:i=>Ye(400*Math.pow(1.95,i-1)),time:i=>Kn(i,-1)},assembly:{name:"Assembly Bay",size:[3,3],cat:"production",max:10,unique:!0,unlock:4,desc:"Boots new bot cores: from the shop, from the Fusion Lab and from events. More levels boot more cores at once, faster.",buildCost:()=>1500,upCost:i=>Ye(1800*Math.pow(1.9,i-1)),time:i=>Kn(i,0)},fusion:{name:"Fusion Lab",size:[4,3],cat:"production",max:10,unique:!0,unlock:5,desc:"Fuses two bots of level 4 or more into a new core. The child may take after either parent, or be a hybrid of both: sometimes a rarer one.",buildCost:()=>3e3,upCost:i=>Ye(3500*Math.pow(1.9,i-1)),time:i=>Kn(i,1)},arena:{name:"Arena",size:[4,4],cat:"production",max:10,unique:!0,unlock:6,desc:"Your gateway to the holo-arena in orbit: pick three bots and battle rival colonies for trophies, rewards and league glory.",buildCost:()=>5e3,upCost:i=>Ye(5e3*Math.pow(1.9,i-1)),time:i=>Kn(i,1)},pad:{name:"Launch Pad",size:[3,3],cat:"production",max:10,unique:!0,unlock:10,desc:"Rockets crewed by your bots fly expeditions across the Solar System. Higher levels unlock bigger rockets (further worlds) and more launch slots.",buildCost:()=>12e3,upCost:i=>Ye(12e3*Math.pow(1.85,i-1)),time:i=>Kn(i,1)},mine:{vault:!0,name:"Crystal Mine",size:[2,2],cat:"production",max:10,unlock:27,desc:"Digs relic crystals out of the Precursor bedrock. Pick a colour and a dig; deeper digs take longer and pay more.",buildCost:i=>Ye(6e4*Math.pow(1.8,i)),upCost:i=>Ye(5e4*Math.pow(1.8,i-1)),time:i=>Kn(i,2)},forge:{vault:!0,name:"Relic Forge",size:[3,3],cat:"production",max:1,unique:!0,unlock:27,desc:"Fuses four relic crystals and some Iridium into one of the next tier.",buildCost:()=>12e4,upCost:()=>0,time:i=>Kn(i,4)},relicbay:{vault:!0,name:"Relic Sanctum",size:[3,3],cat:"bay",max:10,unlock:27,desc:"An ancient arch that wakes Relic AIs of its element. They earn Iridium here.",buildCost:i=>Ye(9e4*Math.pow(1.7,i)),upCost:i=>Ye(8e4*Math.pow(1.85,i-1)),time:i=>Kn(i,2)},monolith:{...en("Precursor Monolith",[1,1],2e4,27,"A black monolith covered in moving glyphs."),vault:!0},tree:en("Holo Tree",[1,1],40,1,"A glowing tree grown from engineered moss and fibre optics."),rock:en("Moon Rock",[1,1],30,1,"A souvenir boulder. Every colony keeps one."),path:en("Walkway",[1,1],10,1,"A paved tile for paths and plazas."),lamp:en("Lumen Post",[1,1],60,2,"A tall lamp with a soft, warm glow."),flag:en("Colony Flag",[1,1],100,3,"Flies your colony colours."),crystal:en("Crystal Cluster",[1,1],250,4,"Grown in microgravity, sold by the kilo."),fountain:en("Gravity Fountain",[2,2],600,5,"Water arcing in a gentle artificial gravity well."),dish:en("Dish Array",[2,2],900,7,"Listening to the stars, mostly for show."),statue:en("Bot Statue",[2,2],1500,9,"A golden monument. Tap it to choose which of your bots stands on the plinth."),bench:en("Park Bench",[1,1],80,2,"Somewhere for the crew to sit and watch Earth turn."),topiary:en("Topiary Bot",[1,1],150,3,"A hedge clipped into the shape of a friendly robot."),sign:en("Neon Sign",[2,1],800,6,"Your colony name in flickering neon. Rename your colony in Style."),turbine:en("Wind Turbine",[1,1],700,8,"Orbital winds are mostly imaginary. The turbine does not mind."),beacon:en("Holo Beacon",[1,1],1100,10,"Projects your banner emblem as a slowly turning hologram."),pond:en("Koi Pond",[2,2],1400,11,"Three koi, one lily, endless circles."),arch:{...en("Starlight Arch",[2,1],0,1,"A ring of light that only loyal commanders own. Earned on day 21 of the login calendar."),exclusive:"calendar"}},jd=["bay","fab","assembly","fusion","arena","pad","tree","rock","path","lamp","flag","crystal","bench","topiary","fountain","sign","turbine","dish","statue","beacon","pond"],La=i=>2+i,qs=i=>1+Math.floor(i/3),Ys=[0,0,2,3,5,7,9,12,15,18,21,25,29,33,38,44],ti=i=>2+Math.floor((i-1)/3),Au=i=>Ye(400*Math.pow(2,i-1)),Si={command:["alloy","geo","kinetic"],fab:["solar","volt","plasma"],fusion:["neural","chrono","photon"],assembly:["alloy","neural","volt"]},Qd={command:"construction speed",fab:"Power Cells per recipe",fusion:"fusion speed",assembly:"boot speed"},ta=i=>1+(i>=5?1:0)+(i>=9?1:0),ka=i=>1+Math.floor((Math.max(1,i)-1)/3),na=[{name:"Quick Charge",sec:30,cells:12,cost:20,xp:1,lvl:1},{name:"Standard Cells",sec:300,cells:60,cost:80,xp:3,lvl:1},{name:"Battery Pack",sec:1800,cells:240,cost:300,xp:8,lvl:2},{name:"Power Core",sec:7200,cells:700,cost:900,xp:20,lvl:3},{name:"Fusion Rod",sec:8*3600,cells:2200,cost:2600,xp:50,lvl:5},{name:"Star Battery",sec:24*3600,cells:6e3,cost:6500,xp:120,lvl:7}],Tu=(i,e)=>Math.round(i.cells*(1+.1*(e-1))),yt=6,Zl=5,$p=i=>Ye(800*Math.pow(2,i)),Hp=i=>3+i*2,j=(i,e,t,n,s,a,r)=>({name:i,el:e,rarity:t,chassis:n,desc:s,...a?{price:a,unlock:r}:{}}),Q={helio:j("Helio",["solar"],"standard","orb","A floating solar collector with a sunny disposition. Your first crewmate.",300,1),ember:j("Ember",["plasma"],"standard","rover","Welds hull plates with a plasma torch it is very proud of.",350,1),tidepool:j("Tidepool",["hydro"],"standard","crawler","Recycles every drop of water on the island. Twice.",400,2),frostbyte:j("Frostbyte",["cryo"],"standard","walker","Keeps the servers cold and the jokes colder.",450,3),digger:j("Digger",["geo"],"standard","rover","Has never met a rock it could not move.",500,3),sprout:j("Sprout",["bio"],"standard","android","Talks to the greenhouse plants. They grow faster.",550,4),sparky:j("Sparky",["volt"],"standard","drone","A hyperactive power drone. Do not let it near the coffee.",600,4),bolt:j("Bolt",["alloy"],"standard","mech","Lifts girders, opens jars, never complains.",700,5),zephyr:j("Zephyr",["aero"],"standard","drone","Rides the ventilation currents for fun.",800,5),lumen:j("Lumen",["photon"],"standard","drone","A flying floodlight that loves an audience.",900,6),brawler:j("Brawler",["kinetic"],"standard","mech","Built for demolition, adores being useful.",1e3,6),anchor:j("Anchor",["gravity"],"standard","walker","Heavier than it looks, calmer than it sounds.",1200,7),umbra:j("Umbra",["void"],"standard","orb","Absorbs stray light. Prefers the night shift.",1400,7),tick:j("Tick",["chrono"],"standard","android","Always exactly on time, sometimes slightly early.",1600,8),cortex:j("Cortex",["neural"],"standard","orb","A small AI that asks a lot of questions.",1800,8),solarflare:j("Solarflare",["solar","plasma"],"advanced","drone","Catches sunlight, throws it back as fire.",2600,9),thunderhead:j("Thunderhead",["volt","hydro"],"advanced","orb","A storm in a sphere. Crackles when it is happy.",3200,10),magmaw:j("Magmaw",["geo","plasma"],"advanced","crawler","Eats rock, breathes lava, purrs.",3800,11),greenhouse:j("Greenhouse",["bio","solar"],"advanced","android","A walking garden that photosynthesises on the job.",4400,12),glacier:j("Glacier",["cryo","alloy"],"advanced","mech","Ice-armoured and unhurried. Nothing gets past.",5e3,13),floe:j("Floe",["hydro","cryo"],"advanced","crawler","Skates across frozen reservoirs, clearing them.",5600,14),quarry:j("Quarry",["geo","alloy"],"advanced","mech","Turns asteroids into neatly stacked bricks.",6200,15),mangrove:j("Mangrove",["bio","hydro"],"advanced","walker","Grows roots into the water pipes. On purpose.",6900,16),dynamo:j("Dynamo",["volt","alloy"],"advanced","rover","A rolling generator with a lot of torque.",7600,17),eclipse:j("Eclipse",["void","photon"],"advanced","orb","Half light, half dark, entirely mysterious.",8400,18),rampart:j("Rampart",["kinetic","alloy"],"advanced","mech","A wall that walks. Very reassuring.",9200,19),stormkite:j("Stormkite",["aero","volt"],"advanced","drone","Flies into lightning to recharge.",1e4,20),monolith:j("Monolith",["gravity","geo"],"advanced","walker","Stands perfectly still for days. Then dances.",11e3,21),paradox:j("Paradox",["chrono","neural"],"advanced","android","Remembers things that have not happened yet.",12e3,22),synapse:j("Synapse",["neural","volt"],"advanced","orb","Thinks in lightning. Talks in puns.",13e3,23),blizzard:j("Blizzard",["aero","cryo"],"advanced","drone","Brings its own weather everywhere it goes.",14e3,24),prism:j("Prism",["photon","solar"],"advanced","orb","Splits starlight into every colour it knows.",15e3,25),undertow:j("Undertow",["void","gravity"],"advanced","crawler","Pulls things in. Gently. Usually.",16e3,26),blastforge:j("Blastforge",["plasma","kinetic"],"advanced","mech","Forges hull plates with controlled explosions.",17500,27),rootbound:j("Rootbound",["bio","geo"],"advanced","walker","Plants a tree with every step.",19e3,28),rainmaker:j("Rainmaker",["hydro","aero"],"advanced","drone","Seeds clouds over the greenhouses.",20500,29),sundial:j("Sundial",["chrono","photon"],"advanced","android","Tells time by the shadows it casts.",22e3,30),mycelium:j("Mycelium",["neural","bio"],"advanced","crawler","A network of thinking fungus in a shell.",24e3,31),orbiter:j("Orbiter",["gravity","aero"],"advanced","orb","Has its own small moon. It is very attached.",26e3,32),permafrost:j("Permafrost",["cryo","void"],"advanced","walker","Cold enough to freeze light.",28e3,33),arcjet:j("Arcjet",["volt","plasma"],"advanced","rover","Rides a cushion of ionised air.",3e4,34),mirrorplate:j("Mirrorplate",["alloy","photon"],"advanced","mech","Polished so well it reflects your mood.",32e3,35),striker:j("Striker",["kinetic","aero"],"advanced","drone","Fast, precise, slightly showing off.",34e3,36),pendulum:j("Pendulum",["chrono","gravity"],"advanced","walker","Swings between moments.",36e3,37),oracle:j("Oracle",["neural","photon"],"advanced","orb","Answers questions before you ask them.",38e3,38),mudlark:j("Mudlark",["geo","hydro"],"advanced","rover","Happiest up to its axles in wet regolith.",4e4,39),sunvolt:j("Sunvolt",["solar","volt"],"advanced","rover","Charges in sunlight, discharges in enthusiasm.",42e3,40),phantom:j("Phantom",["void","neural"],"advanced","android","Appears on cameras that are switched off.",45e3,41),thermocline:j("Thermocline",["plasma","cryo"],"advanced","crawler","Hot on one side, frozen on the other.",48e3,42),corona:j("Corona",["solar","plasma","photon"],"elite","orb","A miniature star on a leash."),tsunami:j("Tsunami",["hydro","kinetic","aero"],"elite","crawler","Moves like a wave and hits like one too."),tectonic:j("Tectonic",["geo","gravity","kinetic"],"elite","mech","Rearranges continents for practice."),verdant:j("Verdant",["bio","solar","hydro"],"elite","android","Terraforms a garden wherever it stands."),tesla:j("Tesla",["volt","alloy","neural"],"elite","android","An inventor bot with a coil for a heart."),borealis:j("Borealis",["cryo","photon","aero"],"elite","drone","Paints the polar sky in green fire."),nightshade:j("Nightshade",["void","bio","neural"],"elite","crawler","Beautiful, clever, best kept at arm's length."),chronoforge:j("Chronoforge",["chrono","plasma","alloy"],"elite","mech","Forges parts it will need tomorrow."),gravwell:j("Gravwell",["gravity","void","hydro"],"elite","orb","A floating whirlpool that hums."),overclock:j("Overclock",["volt","chrono","kinetic"],"elite","rover","Runs every process twice as fast. Including naps."),dreadnought:j("Dreadnought",["alloy","kinetic","gravity"],"elite","mech","Armour plate all the way down."),lumina:j("Lumina",["photon","bio","neural"],"elite","android","A gardener that glows in the dark."),supernova:j("Supernova",["solar","plasma","gravity","photon"],"epic","orb","Contains a star's last breath, politely."),leviathan:j("Leviathan",["hydro","cryo","gravity","kinetic"],"epic","crawler","The deep-ocean bot of Europa legends."),titanforge:j("Titanforge",["alloy","geo","plasma","kinetic"],"epic","mech","Builds space stations single-handed. It has four hands."),gaia:j("Gaia",["bio","geo","hydro","solar"],"epic","android","Turns dead rock into living soil."),tempest:j("Tempest",["aero","volt","hydro","cryo"],"epic","drone","A hurricane that follows instructions."),eventide:j("Eventide",["void","chrono","photon"],"epic","orb","Lives in the moment between day and night."),hivemind:j("Hivemind",["neural","bio","alloy","volt"],"epic","crawler","A thousand tiny minds in one shell."),starweaver:j("Starweaver",["photon","gravity","aero"],"epic","drone","Spins light sails from starlight."),quasar:j("Quasar",["volt","void","photon","gravity"],"epic","orb","Brighter than a galaxy, smaller than a fridge."),juggernaut:j("Juggernaut",["kinetic","alloy","gravity","geo"],"epic","mech","Unstoppable. Literally: nobody has tried."),solaris:j("Solaris Prime",["solar","photon","plasma","neural"],"legendary","android","The first AI to dream of the Sun, and then build one."),abyssal:j("Abyssal",["void","hydro","gravity","cryo"],"legendary","crawler","From the dark oceans beneath Enceladus."),chronarch:j("Chronarch",["chrono","neural","photon","void"],"legendary","android","Keeper of every second the colony has lived."),colossus:j("Colossus",["alloy","kinetic","geo","gravity"],"legendary","mech","A walking fortress the size of a hab block."),seraph:j("Seraph",["aero","photon","bio","solar"],"legendary","drone","Six wings of light, one gentle voice."),voltaic:j("Voltaic Storm",["volt","aero","plasma","kinetic"],"legendary","orb","Lightning that learned to fly."),omega:j("Omega Protocol",["neural","alloy","chrono","kinetic"],"prototype","mech","The last line of code anyone wrote by hand."),genesis:j("Genesis Engine",["bio","solar","hydro","geo"],"prototype","android","Makes worlds. Small ones, for now."),horizon:j("Event Horizon",["gravity","void","chrono","photon"],"prototype","orb","Nothing it looks at can look away."),architect:j("The Architect",["neural","chrono","gravity","photon"],"singularity","orb","It designed itself. Then it designed the rest."),primemover:j("Prime Mover",["kinetic","plasma","solar","gravity"],"singularity","mech","The engine at the start of everything."),veyari:{...j("Veyari Gardener",["bio","photon","void"],"legendary","android","A crystalline gardener from Proxima b, a gift from the Veyari to seal first contact."),alien:"contact"},synod:{...j("Synod Envoy",["alloy","neural","chrono"],"legendary","mech","A delegate of the machine Synod of Barnard's Star. It votes on everything."),alien:"contact"},mycelar:{...j("Mycelar Sporeling",["bio","neural","hydro"],"epic","crawler","A fragment of Tau Ceti's singing fungal mind, curious about everything."),alien:"contact"},oshoru:{...j("Oshoru Swimmer",["hydro","aero","kinetic"],"epic","orb","A young Oshoru from TRAPPIST-1e, sent to see the stars."),alien:"contact"},lumenchoir:{...j("Lumen Choir",["photon","solar","neural"],"prototype","orb","A being of pure light from Epsilon Eridani. It hums in harmonies."),alien:"contact"},krdrone:{...j("Kr'thul Drone",["void","kinetic"],"advanced","crawler","A Swarm drone, captured and reprogrammed. Still a little bitey."),alien:"swarm"},krwarrior:{...j("Kr'thul Warrior",["void","kinetic","plasma"],"elite","crawler","A Swarm warrior that now fights for the colony."),alien:"swarm"},solstice:{...j("Solstice Seraph",["solar","photon","aero"],"legendary","drone","Born in the light of the Solar Solstice. It never casts a shadow."),alien:"event"},champion:{...j("Arena Champion",["kinetic","alloy","photon"],"legendary","mech","Forged for the Arena Cup. It bows before every fight."),alien:"event"},voyager:{...j("Deep Voyager",["gravity","void","aero"],"legendary","orb","A Deep Space Week veteran that has seen the edge of the Solar System."),alien:"event"},chimera:{...j("Chimera Core",["neural","bio","plasma","chrono"],"legendary","crawler","A happy accident of the Fusion Frenzy. Nobody is quite sure what it is."),alien:"event"},blossom:{...j("Blossom Sentinel",["bio","hydro","photon"],"legendary","android","Guardian of the Garden Gala. Flowers open as it passes."),alien:"event"},anvil:{...j("Anvil Titan",["alloy","plasma","geo"],"legendary","mech","Built during Forge Fest by every builder drone at once."),alien:"event"},aurorawisp:{...j("Aurora Wisp",["aurora","relic","bio"],"epic","orb","A Precursor intelligence of Aurora, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},aurorawarden:{...j("Aurora Warden",["aurora","relic","photon"],"legendary","android","A Precursor intelligence of Aurora, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},auroraprime:{...j("Aurora Prime",["aurora","relic","solar"],"prototype","drone","A Precursor intelligence of Aurora, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},arcanaglyph:{...j("Arcana Glyph",["arcana","relic","neural"],"epic","orb","A Precursor intelligence of Arcana, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},arcanamagus:{...j("Arcana Magus",["arcana","relic","chrono"],"legendary","android","A Precursor intelligence of Arcana, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},arcanaprime:{...j("Arcana Prime",["arcana","relic","void"],"prototype","orb","A Precursor intelligence of Arcana, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},entropyspark:{...j("Entropy Spark",["entropy","relic","plasma"],"epic","crawler","A Precursor intelligence of Entropy, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},entropyreaver:{...j("Entropy Reaver",["entropy","relic","kinetic"],"legendary","mech","A Precursor intelligence of Entropy, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},entropyprime:{...j("Entropy Prime",["entropy","relic","gravity"],"prototype","orb","A Precursor intelligence of Entropy, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},joysprite:{...j("Joy Sprite",["joy","relic","aero"],"epic","drone","A Precursor intelligence of Joy, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},joyjester:{...j("Joy Jester",["joy","relic","volt"],"legendary","android","A Precursor intelligence of Joy, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},joyprime:{...j("Joy Prime",["joy","relic","photon"],"prototype","orb","A Precursor intelligence of Joy, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},reveriedrifter:{...j("Reverie Drifter",["reverie","relic","cryo"],"epic","orb","A Precursor intelligence of Reverie, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},reverieoracle:{...j("Reverie Oracle",["reverie","relic","neural"],"legendary","android","A Precursor intelligence of Reverie, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},reverieprime:{...j("Reverie Prime",["reverie","relic","hydro"],"prototype","drone","A Precursor intelligence of Reverie, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},soulember:{...j("Soul Ember",["soul","relic","solar"],"epic","orb","A Precursor intelligence of Soul, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},soulkeeper:{...j("Soul Keeper",["soul","relic","geo"],"legendary","mech","A Precursor intelligence of Soul, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},soulprime:{...j("Soul Prime",["soul","relic","chrono"],"prototype","android","A Precursor intelligence of Soul, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},krbrood:{...j("Kr'thul Brood",["void","bio","gravity","kinetic"],"epic","crawler","A living Swarm carrier. It keeps trying to adopt the other bots."),alien:"swarm"}},$n=Object.keys(Q),We={standard:{name:"Standard",color:"#b9c3cf",earn:10,power:1,fuseChance:1,assembly:30},advanced:{name:"Advanced",color:"#5fdc7a",earn:15,power:1.2,fuseChance:.6,assembly:600},elite:{name:"Elite",color:"#4aa8ff",earn:22,power:1.45,fuseChance:.35,assembly:3600},epic:{name:"Epic",color:"#b06dff",earn:34,power:1.75,fuseChance:.18,assembly:4*3600},legendary:{name:"Legendary",color:"#ffa53a",earn:52,power:2.1,fuseChance:.08,assembly:12*3600},prototype:{name:"Prototype",color:"#ff4f6a",earn:80,power:2.6,fuseChance:.035,assembly:24*3600},singularity:{name:"Singularity",color:"#7af7ff",earn:125,power:3.2,fuseChance:.015,assembly:48*3600}},Ct=Object.keys(We),di=i=>Ct.indexOf(Q[i].rarity),Ru=[2,4,8,15,30,60,120];function jc(i,e,t=Date.now()){if(i.dex[e])return!1;i.dex[e]=t;const n=Ru[di(e)];return i.res.dm+=n,hn.push({kind:"discover",sp:e,dm:n}),!0}const Qc=i=>Object.keys(i.dex).filter(e=>Q[e]).length;function ia(i){const e=Q[i.sp],t=We[e.rarity].power,n=1+.1*(e.el.length-1);return{hp:Math.round((120+32*(i.lvl-1))*t*n),atk:Math.round((20+5.5*(i.lvl-1))*t*n)}}const Zi=4;function Cu(i,e){const t=Q[i.sp],n=Q[e.sp],s=new Set([...t.el,...n.el]),a=di(i.sp),r=di(e.sp),o=Math.min(a,r),l=Math.max(a,r),c=[];for(const h of $n){const u=Q[h],f=Ct.indexOf(u.rarity),g=h===i.sp||h===e.sp;u.alien&&!g||!g&&(!u.el.every(y=>s.has(y))||!u.el.some(y=>t.el.includes(y))||!u.el.some(y=>n.el.includes(y))||u.el.length<2||f<(o>=2?o:o-1)||f===3&&l<1||f===4&&o<2||f===5&&o<3||f===6&&o<4||f>l+2)||c.push({sp:h,w:We[u.rarity].fuseChance*(g?1.3:1)})}const d=c.reduce((h,u)=>h+u.w,0);return c.map(h=>({sp:h.sp,p:h.w/d})).sort((h,u)=>di(u.sp)-di(h.sp)||u.p-h.p)}const Jl=(i,e)=>{const t=di(i.sp),n=di(e.sp);return Math.round(120*(1+t)*(1+n)*Math.pow(1.7,Math.max(t,n)))};function tr(i,e){const t=Si[e.t]||[];let n=0;for(const s of i.bots){if(s.post!==e.id)continue;const a=Q[s.sp],r=(.04+.006*s.lvl)*Math.sqrt(We[a.rarity].power)*(a.el.some(o=>t.includes(o))?1.5:1);n+=r}return Math.min(.6,n)}const jl=(i,e,t)=>Math.round(We[Q[t].rarity].assembly*(1-.05*(e.lvl-1))*(1-tr(i,e)));function Pu(i,e,t,n){if(e.lvl<1||At(i,e.id,"build"))return{ok:!1,why:"The Fusion Lab is under construction"};if(At(i,e.id,"fuse"))return{ok:!1,why:"Already fusing"};const s=i.bots.find(o=>o.id===t),a=i.bots.find(o=>o.id===n);if(!s||!a)return{ok:!1,why:"Pick two bots"};if(s===a)return{ok:!1,why:"Pick two different bots"};if(s.lvl<Zi||a.lvl<Zi)return{ok:!1,why:`Both bots need level ${Zi}`};if(za(i,s)||za(i,a))return{ok:!1,why:"A parent is away on an expedition"};if(Q[s.sp].alien==="relic"||Q[a.sp].alien==="relic")return{ok:!1,why:"Relic AIs cannot be fused"};const r=Jl(s,a);return i.res.credits<r?{ok:!1,why:"Not enough credits",cost:r}:{ok:!0,cost:r}}function Gp(i,e,t,n,s=Date.now(),a=Math.random){const r=Pu(i,e,t,n);if(!r.ok)return r;const o=i.bots.find(f=>f.id===t),l=i.bots.find(f=>f.id===n);i.res.credits-=r.cost||0;const c=Cu(o,l);let d=a(),h=c[0].sp;for(const f of c){if(d<f.p){h=f.sp;break}d-=f.p}const u=jl(i,e,h);return i.jobs.push({id:Jt("j"),kind:"fuse",item:e.id,start:s,end:s+u*1e3,sp:h,parents:[t,n]}),i.stats.fusions=(i.stats.fusions||0)+1,dt(i,15+10*di(h)),{...r,time:u,sp:h}}const Vp=(i,e,t)=>Math.round(We[Q[t].rarity].assembly*.5*(1-.05*(e.lvl-1))*(1-tr(i,e)));function Do(i,e,t,n=Date.now()){const s={id:Jt("c"),sp:e,from:t,state:"waiting",at:n};return i.cores.push(s),Ql(i,n),hn.push({kind:"core",core:s.id,sp:e}),s}function Ql(i,e=Date.now()){const t=ze(i,"assembly")[0];if(!t||t.lvl<1||At(i,t.id,"build"))return;let n=i.jobs.filter(s=>s.kind==="boot").length;for(const s of i.cores){if(n>=ka(t.lvl))break;s.state==="waiting"&&(s.state="booting",i.jobs.push({id:Jt("j"),kind:"boot",item:t.id,start:e,end:e+Vp(i,t,s.sp)*1e3,core:s.id}),n++)}}function Wp(i,e,t=Date.now()){const n=i.cores.find(r=>r.id===e);if(!n||n.state!=="ready")return{ok:!1,why:"Still booting"};const s=ws(i,n.sp),a={id:Jt("b"),sp:n.sp,lvl:1,fed:0,bay:s?s.id:null,born:t,...s?{}:{stored:!0}};return i.bots.push(a),i.cores=i.cores.filter(r=>r!==n),jc(i,n.sp,t),i.stats.boots=(i.stats.boots||0)+1,dt(i,10+12*di(n.sp)),hn.push({kind:"newBot",bot:a.id}),{ok:!0,bot:a}}function ws(i,e,t){const n=Q[e].el;return ze(i,"bay").filter(s=>s.lvl>0&&s.el&&n.includes(s.el)&&s.id!==t&&Dn(i,s.id).length<ti(s.lvl)).sort((s,a)=>Dn(i,s.id).length-Dn(i,a.id).length)[0]}const oo=(i,e)=>i.bots.filter(t=>t.post===e);function Lu(i,e,t){return Si[t.t]?t.lvl<1?{ok:!1,why:"Under construction"}:Q[e.sp].alien==="relic"?{ok:!1,why:"Relic AIs stay in their Sanctum"}:e.stored?{ok:!1,why:"Activate it from storage first"}:za(i,e)?{ok:!1,why:"Away on an expedition"}:e.post===t.id?{ok:!1,why:"Already helping here"}:oo(i,t.id).length>=ta(t.lvl)?{ok:!1,why:`All ${ta(t.lvl)} helper slots are taken`}:{ok:!0}:{ok:!1,why:"Bots cannot help here"}}function Xp(i,e,t){const n=Lu(i,e,t);return n.ok&&(e.post=t.id,i.stats.posts=(i.stats.posts||0)+1),n}function qp(i){delete i.post}function Yp(i,e){e.bay=null,e.stored=!0,delete e.post}function Kp(i,e){const t=ws(i,e.sp);return t?(e.bay=t.id,delete e.stored,{ok:!0}):{ok:!1,why:`No room: build or upgrade a ${Q[e.sp].el.map(n=>n[0].toUpperCase()+n.slice(1)).join("/")} Bay`}}const Du=i=>Math.round((Q[i.sp].price||2e3*Math.pow(3,di(i.sp)))*.25*(1+.1*(i.lvl-1)));function Zp(i,e){if(i.bots.length<=1)return{ok:!1,why:"You need at least one bot"};i.bots=i.bots.filter(n=>n!==e);const t=Du(e);return i.res.credits+=t,{ok:!0,cost:t}}const Jp=(i,e)=>i.cores.find(t=>t.id===e),Bt={home:{name:"Home orbit",theme:"haven",world:"earth",blurb:"Your first island, in low Earth orbit."},moon:{name:"Tranquility Base",theme:"moon",world:"moon",needs:"moon",level:14,cost:6e4,perk:"Low gravity: bays here hold 50% more credits",blurb:"An island of grey regolith floating above the Moon, with Earth hanging in the black sky."},vault:{name:"The Precursor Vault",theme:"vault",world:"vault",needs:"epseri",level:27,cost:15e5,perk:"Relic crystals, the Forge and Relic AIs that earn Iridium",blurb:"A shard of the Precursors' world, found beyond Epsilon Eridani: violet ground veined with light."},mars:{name:"Bradbury Landing",theme:"mars",world:"mars",needs:"mars",level:22,cost:4e5,perk:"Rich regolith: Fabricators here print 30% more cells",blurb:"Rust-red ground above the plains of Mars, with Phobos racing overhead."}},jp=["home","moon","mars","vault"],Kt={aurora:{name:"Aurora",color:"#6fffc8"},arcana:{name:"Arcana",color:"#8a5cff"},entropy:{name:"Entropy",color:"#ff3d6e"},joy:{name:"Joy",color:"#ffd24a"},reverie:{name:"Reverie",color:"#7aa8ff"},soul:{name:"Soul",color:"#f2f2ff"}},Da=Object.keys(Kt),dl=["Shard","Crystal","Gem","Prism"],Io=[{name:"Surface dig",sec:600,shards:4,cost:4e3},{name:"Deep dig",sec:2*3600,shards:18,cost:15e3},{name:"Core dig",sec:8*3600,shards:60,cost:42e3}],Iu=(i,e)=>Math.round(i*(1+.15*(e-1))),lo=4,Nu=i=>[30,120,400][i]||0,ed=[[0,30],[2,8],[3,6]],td=[[1,10],[1,25],[2,12],[3,8]],ec=(i,e)=>[0,0,0,2.5,4,7,10][i]*(1+.6*(e-1)),Qp=i=>Math.round(300*Math.pow(1.7,i-1));function Zt(i){const e=i;return e.vault||(e.vault={crystals:Object.fromEntries(Da.map(t=>[t,[0,0,0,0]])),ready:{}}),e.vault}const No=i=>Q[i].alien==="relic",Ri=i=>Q[i].el[0],tc=i=>Ct.indexOf(Q[i].rarity)-3;function em(i,e,t,n){const s=Io[t];return!s||!Da.includes(n)?{ok:!1}:e.lvl<1||At(i,e.id,"build")?{ok:!1,why:"Under construction"}:At(i,e.id,"dig")?{ok:!1,why:"Already digging"}:Zt(i).ready[e.id]?{ok:!1,why:"Collect the crystals first"}:i.res.credits<s.cost?{ok:!1,why:"Not enough credits",cost:s.cost}:{ok:!0,cost:s.cost,time:s.sec}}function tm(i,e,t,n,s=Date.now()){const a=em(i,e,t,n);return a.ok&&(i.res.credits-=a.cost||0,i.jobs.push({id:Jt("j"),kind:"dig",item:e.id,start:s,end:s+Io[t].sec*1e3,recipe:t,sp:n}),i.stats.digs=(i.stats.digs||0)+1),a}function nm(i,e,t,n){Zt(i).ready[e.id]={color:n,n:Iu(Io[t].shards,Math.max(1,e.lvl))},hn.push({kind:"dug",item:e.id})}function Uu(i,e){const t=Zt(i).ready[e.id];return t?(delete Zt(i).ready[e.id],Zt(i).crystals[t.color][0]+=t.n,dt(i,5+Math.round(t.n/4)),t):null}function Fu(i,e,t){const n=Zt(i);if(!ze(i,"forge").some(a=>a.lvl>0))return{ok:!1,why:"Build the Relic Forge"};if(t>=3)return{ok:!1,why:"Prisms are the highest tier"};if(n.crystals[e][t]<lo)return{ok:!1,why:`Needs ${lo}`};const s=Nu(t);return(i.res.iridium||0)<s?{ok:!1,why:"Not enough Iridium",cost:s}:{ok:!0,cost:s}}function im(i,e,t){const n=Fu(i,e,t);if(!n.ok)return n;const s=Zt(i);return s.crystals[e][t]-=lo,s.crystals[e][t+1]++,i.res.iridium=(i.res.iridium||0)-(n.cost||0),dt(i,10*(t+1)),i.stats.forged=(i.stats.forged||0)+1,n}const Ou=(i,e)=>ze(i,"relicbay").filter(t=>t.lvl>0&&t.el===Ri(e)&&Dn(i,t.id).length<ti(t.lvl))[0];function ku(i,e){if(!No(e))return{ok:!1};const[t,n]=ed[tc(e)],s=Zt(i).crystals[Ri(e)][t];return Ou(i,e)?s<n?{ok:!1,why:`Needs ${n} ${Ri(e)} ${["shards","crystals","gems","prisms"][t]}`}:{ok:!0}:{ok:!1,why:`Needs a ${Ri(e)[0].toUpperCase()+Ri(e).slice(1)} Relic Sanctum with room`}}function sm(i,e,t=Date.now()){const n=ku(i,e);if(!n.ok)return n;const[s,a]=ed[tc(e)];Zt(i).crystals[Ri(e)][s]-=a;const r={id:Jt("b"),sp:e,lvl:1,fed:0,bay:Ou(i,e).id,born:t};return i.bots.push(r),i.dex[e]||(i.dex[e]=t,i.res.dm+=40,hn.push({kind:"discover",sp:e,dm:40})),dt(i,80+tc(e)*60),hn.push({kind:"newBot",bot:r.id}),{...n,bot:r}}function Bu(i,e){if(!No(e.sp))return{ok:!1};if(e.lvl>=5)return{ok:!1,why:"Five stars: fully evolved"};const[t,n]=td[e.lvl-1];return Zt(i).crystals[Ri(e.sp)][t]<n?{ok:!1,why:`Needs ${n} ${Ri(e.sp)} ${["shards","crystals","gems","prisms"][t]}`}:{ok:!0}}function am(i,e){const t=Bu(i,e);if(!t.ok)return t;const[n,s]=td[e.lvl-1];return Zt(i).crystals[Ri(e.sp)][n]-=s,e.lvl++,dt(i,60*e.lvl),hn.push({kind:"evolved",bot:e.id,stars:e.lvl}),t}const zu=(i,e)=>Dn(i,e).reduce((t,n)=>t+ec(Ct.indexOf(Q[n.sp].rarity),n.lvl),0)/60,Ba=i=>Qp(Math.max(1,i.lvl)),hn=[],Ci=i=>{hn.push(i)},rm=(i,e)=>Object.entries(e).every(([t,n])=>i.res[t]>=(n||0)),om=(i,e)=>{for(const[t,n]of Object.entries(e))i.res[t]-=n||0},Un=(i,e)=>{for(const[t,n]of Object.entries(e))t in i.res&&(i.res[t]+=n)},Gn=(i,e,t=1)=>{i.stats[e]=(i.stats[e]||0)+t};function dt(i,e){if(!(e<=0))for(i.xp+=e;i.lvl<kp&&i.xp>=Yl(i.lvl);){i.xp-=Yl(i.lvl),i.lvl++;const t=Bp(i.lvl);Un(i,t),Ci({kind:"levelup",lvl:i.lvl,reward:t})}}const En=i=>i.islands[i.at]||i.islands.home,Uo=i=>Object.values(i.islands).flatMap(e=>e.items),ze=(i,e)=>Uo(i).filter(t=>t.t===e),nd=(i,e)=>En(i).items.filter(t=>t.t===e),Rt=(i,e)=>Uo(i).find(t=>t.id===e),es=(i,e)=>Object.keys(i.islands).find(t=>i.islands[t].items.some(n=>n.id===e))||"home",ts=i=>(ze(i,"command")[0]||{lvl:1}).lvl,Fo=(i,e=i.at)=>{const t=i.islands[e],n=t&&t.items.find(s=>s.t==="command"||s.t==="hub");return n?Math.max(1,n.lvl):1},gn=i=>{const[e,t]=Qe[i.t].size;return i.r%2?[t,e]:[e,t]},$u=(i,e)=>`${Math.floor(i/yt)},${Math.floor(e/yt)}`,Hu=(i,e,t)=>e>=0&&t>=0&&e<yt*Zl&&t<yt*Zl&&En(i).plots.includes($u(e,t));function ps(i,e,t,n,s,a){for(let r=e;r<e+n;r++)for(let o=t;o<t+s;o++)if(!Hu(i,r,o))return!1;for(const r of En(i).items){if(r.id===a)continue;const[o,l]=gn(r);if(e<r.x+o&&e+n>r.x&&t<r.z+l&&t+s>r.z)return!1}return!0}const Oo=i=>i.jobs.filter(e=>e.kind==="build").length,At=(i,e,t)=>i.jobs.find(n=>n.item===e&&(!t||n.kind===t));function ei(i,e,t){const n=Qe[e];if(!n)return{ok:!1,why:"Unknown"};if(n.exclusive){const c=i.stats["decor_"+e]||0;return ze(i,e).length<c?{ok:!0,cost:0,time:0}:{ok:!1,why:c?"All placed":"Earned from the login calendar",cost:0}}if(i.lvl<n.unlock)return{ok:!1,why:`Commander level ${n.unlock}`,cost:n.buildCost(ze(i,e).length)};if(n.vault&&i.at!=="vault")return{ok:!1,why:"Only in the Precursor Vault"};const s=n.unique?ze(i,e).length:nd(i,e).length,a=Fo(i);if(n.unique&&s)return{ok:!1,why:"Already built"};if(e==="hub")return{ok:!1,why:"Every new island comes with its Colony Hub"};const r=i.at==="home"?"Command Center":"Colony Hub";if(e==="bay"&&s>=La(a))return{ok:!1,why:`Bay limit here (${La(a)}): upgrade the ${r}`};if(e==="fab"&&s>=qs(a))return{ok:!1,why:`Fabricator limit here (${qs(a)}): upgrade the ${r}`};const o=e==="bay"&&t&&!ze(i,"bay").some(c=>c.el===t)?Math.round(n.buildCost(Math.max(0,s-1))*.7):n.buildCost(s),l=Math.round(n.time(1)*qu(i));return l>0&&Oo(i)>=i.builders?{ok:!1,why:"All builder drones are busy",cost:o,time:l}:i.res.credits<o?{ok:!1,why:"Not enough credits",cost:o,time:l}:{ok:!0,cost:o,time:l}}function Gu(i,e,t,n,s,a,r=Date.now()){const o=ei(i,e,a);if(!o.ok)return o;const l={id:Jt("i"),t:e,x:t,z:n,r:s,lvl:o.time?0:1,...a?{el:a}:{}},[c,d]=gn(l);return ps(i,t,n,c,d)?(i.res.credits-=o.cost||0,En(i).items.push(l),Gn(i,"built"),o.time?i.jobs.push({id:Jt("j"),kind:"build",item:l.id,start:r,end:r+o.time*1e3,lvl:1}):(dt(i,Xu(o.cost||0)),Qe[e].cat==="decor"&&Gn(i,"decor")),e==="bay"&&(i.bay[l.id]=0),{...o,item:l}):{ok:!1,why:"Something is in the way"}}const Vu=(i,e)=>e.t==="command"?Qe.command.max:e.t==="hub"?Math.min(Qe.hub.max,Math.max(1,ts(i)-2)):Math.min(Qe[e.t].max,Fo(i,es(i,e.id)));function id(i,e){const t=Qe[e.t];if(t.cat==="decor")return{ok:!1,why:"Decorations do not upgrade"};if(At(i,e.id,"build"))return{ok:!1,why:"Under construction"};if(e.lvl>=t.max)return{ok:!1,why:"Maximum level"};if(e.t==="hub"&&e.lvl>=ts(i)-2)return{ok:!1,why:`Colony Hubs stay two levels below the Command Center (level ${e.lvl+3} needed)`};if(e.t!=="command"&&e.t!=="hub"&&e.lvl>=Fo(i,es(i,e.id)))return{ok:!1,why:`Upgrade the ${es(i,e.id)==="home"?"Command Center":"Colony Hub"} to level ${e.lvl+1} first`};if(e.t==="command"&&i.lvl<Ys[e.lvl+1])return{ok:!1,why:`Commander level ${Ys[e.lvl+1]} needed`};if(e.t==="fab"&&At(i,e.id,"craft"))return{ok:!1,why:"Finish or harvest the recipe first"};const n=t.upCost(e.lvl),s=Math.round(t.time(e.lvl+1)*(e.t==="command"?1:qu(i)));return Oo(i)>=i.builders?{ok:!1,why:"All builder drones are busy",cost:n,time:s}:i.res.credits<n?{ok:!1,why:"Not enough credits",cost:n,time:s}:{ok:!0,cost:n,time:s}}function Wu(i,e,t=Date.now()){const n=id(i,e);return n.ok&&(i.res.credits-=n.cost||0,Gn(i,"upgrades"),i.jobs.push({id:Jt("j"),kind:"build",item:e.id,start:t,end:t+(n.time||0)*1e3,lvl:e.lvl+1})),n}const Xu=i=>Math.max(5,Math.round(i/15)),qu=i=>{const e=ze(i,"command")[0];return e?1-tr(i,e):1};function Yu(i,e,t,n,s){const[a,r]=gn({t:e.t,r:s});return ps(i,t,n,a,r,e.id)?(e.x=t,e.z=n,e.r=s,!0):!1}function Ku(i,e){if(Qe[e.t].cat!=="decor"||Qe[e.t].exclusive)return!1;const t=i.islands[es(i,e.id)];return t.items=t.items.filter(n=>n!==e),i.res.credits+=Math.floor(Qe[e.t].buildCost(0)*.5),!0}const ui=i=>i<=60?0:Math.ceil(1.1*Math.pow(i/60,.7));function Zu(i,e,t=Date.now()){const n=ui((e.end-t)/1e3);return i.res.dm<n?!1:(i.res.dm-=n,e.end=t,Ia(i,t),!0)}const Ei=i=>{const e=Q[i.sp];return We[e.rarity].earn*(1+.15*(e.el.length-1))*(1+.35*(i.lvl-1))},ko=40,Bo=i=>Math.round(4*Math.pow(1.33,i-1)),Dn=(i,e)=>i.bots.filter(t=>t.bay===e),Ju=(i,e)=>!!(i.space&&i.space.exps.some(t=>t.crew.includes(e.id))),lm=i=>{const e=i.space;if(!e)return 1;let t=0;for(const n of["proxima","barnard","tauceti","trappist","epseri"])e.visits[n]>0&&t++;return 1+.05*t},zo=(i,e)=>Dn(i,e).filter(t=>!t.post&&!Ju(i,t)).reduce((t,n)=>t+Ei(n),0)/60*lm(i),za=Ju,Yi=(i,e)=>Au(Math.max(1,i.lvl))*(e&&es(e,i.id)==="moon"?1.5:1);function sd(i,e){if(No(e.sp))return{ok:!1,why:"Relic AIs evolve with crystals, not cells"};if(e.lvl>=ko)return{ok:!1,why:"Maximum level"};const t=Bo(e.lvl);if(i.res.cells<t)return{ok:!1,why:"Not enough Power Cells",cost:t};i.res.cells-=t,e.fed++,Gn(i,"feeds"),dt(i,1+Math.floor(e.lvl/4));let n=!1;return e.fed>=4&&(e.fed=0,e.lvl++,n=!0,Ci({kind:"botLevel",bot:e.id,lvl:e.lvl})),{ok:!0,cost:t,lvlUp:n}}function ad(i,e){const t=Q[e];if(!t||!t.price)return{ok:!1,why:"Not for sale"};const n=i.bots.filter(a=>a.sp===e).length,s=Math.round(t.price*(1+.5*n));if(i.lvl<(t.unlock||1))return{ok:!1,why:`Commander level ${t.unlock}`,cost:s};if(t.rarity!=="standard"){const a=ze(i,"assembly")[0];if(!a||a.lvl<1)return{ok:!1,why:"Build the Assembly Bay first: rarer bots boot there",cost:s}}else if(!ws(i,e)){const a=t.el.map(o=>o[0].toUpperCase()+o.slice(1));return{ok:!1,why:ze(i,"bay").some(o=>o.el&&t.el.includes(o.el))?`No room: upgrade or add a ${a.join("/")} Bay`:`Build a ${a.join(" or ")} Bay first`,cost:s}}return i.res.credits<s?{ok:!1,why:"Not enough credits",cost:s}:{ok:!0,cost:s}}function ju(i,e,t=Date.now()){const n=ad(i,e);if(!n.ok)return n;if(i.res.credits-=n.cost||0,Gn(i,"recruits"),dt(i,10+Math.round((n.cost||0)/50)),Q[e].rarity!=="standard"){const r=Do(i,e,"shop",t);return{...n,core:r.id}}const s=ws(i,e),a={id:Jt("b"),sp:e,lvl:1,fed:0,bay:s.id,born:t};return i.bots.push(a),jc(i,e,t),Ci({kind:"newBot",bot:a.id}),{...n,bot:a}}function Qu(i,e,t){const n=Rt(i,t);return!n||!n.el||!Q[e.sp].el.includes(n.el)||e.bay===t||Dn(i,t).length>=ti(n.lvl)?!1:(e.bay=t,delete e.stored,!0)}function rd(i,e){const t=Math.floor(i.bay[e.id]||0);if(t<=0)return 0;if(i.bay[e.id]-=t,e.t==="relicbay")return i.res.iridium=(i.res.iridium||0)+t,Gn(i,"iridium",t),t;i.res.credits+=t,Gn(i,"collects"),Gn(i,"collected",t);const n=(i.stats.xpFrac||0)+t/50,s=Math.floor(n);return i.stats.xpFrac=n-s,dt(i,s),t}const ef=i=>na.map((e,t)=>({...e,i:t,open:Math.max(1,i.lvl)>=e.lvl,out:Tu(e,Math.max(1,i.lvl))}));function tf(i,e,t){const n=na[t];return n?e.lvl<1||At(i,e.id,"build")?{ok:!1,why:"Under construction"}:At(i,e.id,"craft")?{ok:!1,why:"Already printing"}:i.ready[e.id]?{ok:!1,why:"Harvest first"}:e.lvl<n.lvl?{ok:!1,why:`Fabricator level ${n.lvl}`}:i.res.credits<n.cost?{ok:!1,why:"Not enough credits",cost:n.cost}:{ok:!0,cost:n.cost,time:n.sec}:{ok:!1}}function nf(i,e,t,n=Date.now()){const s=tf(i,e,t);return s.ok&&(i.res.credits-=s.cost||0,Gn(i,"crafts"),i.jobs.push({id:Jt("j"),kind:"craft",item:e.id,start:n,end:n+na[t].sec*1e3,recipe:t})),s}function od(i,e){const t=i.ready[e.id];return t?(delete i.ready[e.id],i.res.cells+=t.cells,dt(i,t.xp),Gn(i,"harvests"),t.cells):0}function $o(i,e){const t=En(i).plots;if(t.includes(e))return"open";const[n,s]=e.split(",").map(Number);return[[1,0],[-1,0],[0,1],[0,-1]].some(([a,r])=>t.includes(`${n+a},${s+r}`))?"buyable":"far"}const cm={home:1,moon:4,mars:12},Ho=i=>Math.round($p(En(i).bought)*(cm[i.at]||1)),Go=i=>Hp(En(i).bought)+(i.at==="moon"?10:i.at==="mars"?18:0);function ld(i,e){if($o(i,e)!=="buyable")return{ok:!1,why:"Expand next to your island"};const t=Ho(i),n=Go(i);return i.lvl<n?{ok:!1,why:`Commander level ${n}`,cost:t}:i.res.credits<t?{ok:!1,why:"Not enough credits",cost:t}:{ok:!0,cost:t}}function sf(i,e){const t=ld(i,e);return t.ok&&(i.res.credits-=t.cost||0,En(i).plots.push(e),En(i).bought++,i.landBought++,Gn(i,"land"),dt(i,25+i.landBought*10),Ci({kind:"land",key:e})),t}function dm(i,e){i.jobs=i.jobs.filter(n=>n!==e);const t=Rt(i,e.item);if(t){if(e.kind==="build"){const n=t.lvl===0;t.lvl=e.lvl||t.lvl+1;const s=Qe[t.t];dt(i,Xu(n?s.buildCost(0):s.upCost(t.lvl-1))),Ci({kind:"built",item:t.id,lvl:t.lvl,first:n}),t.t==="assembly"&&Ql(i,e.end)}if(e.kind==="craft"){const n=na[e.recipe||0];i.ready[t.id]={cells:Math.round(Tu(n,Math.max(1,t.lvl))*(1+tr(i,t))*(es(i,t.id)==="mars"?1.3:1)),xp:n.xp},Ci({kind:"crafted",item:t.id})}if(e.kind==="fuse"&&e.sp){const n=Do(i,e.sp,"fusion",e.end);Ci({kind:"fused",item:t.id,core:n.id,sp:e.sp})}if(e.kind==="dig"&&nm(i,t,e.recipe||0,e.sp||"aurora"),e.kind==="boot"){const n=Jp(i,e.core);n&&(n.state="ready",Ci({kind:"booted",core:n.id,sp:n.sp})),Ql(i,e.end)}}}function Ia(i,e=Date.now()){let t=i.last||e;if(e<t){i.last=e;return}for(;;){const n=i.jobs.filter(a=>a.end<=e).sort((a,r)=>a.end-r.end)[0],s=n?Math.max(t,n.end):e;if(hm(i,(s-t)/1e3),t=s,!n)break;dm(i,n)}i.last=e}function hm(i,e){if(!(e<=0)){for(const t of ze(i,"relicbay")){if(t.lvl<1)continue;const n=Ba(t),s=i.bay[t.id]||0;s<n&&(i.bay[t.id]=Math.min(n,s+zu(i,t.id)*e))}for(const t of ze(i,"bay")){if(t.lvl<1)continue;const n=Yi(t,i),s=i.bay[t.id]||0;s>=n||(i.bay[t.id]=Math.min(n,s+zo(i,t.id)*e))}}}function co(i,e){switch(e.kind){case"collect":return(i.stats.collects||0)>=(e.n||1);case"craft":return(i.stats.crafts||0)>=(e.n||1);case"harvest":return(i.stats.harvests||0)>=(e.n||1);case"botLevel":return i.bots.some(t=>t.lvl>=(e.n||1));case"ownSpecies":return i.bots.some(t=>t.sp===e.t);case"bayEl":return ze(i,"bay").some(t=>t.el===e.t&&t.lvl>0);case"cc":return ts(i)>=(e.n||1);case"decor":return(i.stats.decor||0)>=(e.n||1);case"bayLevel":return ze(i,"bay").some(t=>t.lvl>=(e.n||1));case"land":return i.landBought>=(e.n||1);case"bots":return i.bots.length>=(e.n||1);case"level":return i.lvl>=(e.n||1);case"rarity":return i.bots.some(t=>Q[t.sp].rarity===e.t);case"build":return ze(i,e.t||"").some(t=>t.lvl>0);case"fusions":return(i.stats.fusions||0)>=(e.n||1);case"boots":return(i.stats.boots||0)>=(e.n||1);case"helper":return i.bots.some(t=>!!t.post);case"dex":return Qc(i)>=(e.n||1);case"arenaWins":return(i.stats.arenaWins||0)>=(e.n||1);case"visit":return!!(i.space&&i.space.visits[e.t||""]>0);case"outposts":return(i.stats.outposts||0)>=(e.n||1);case"island":return!!i.islands[e.t||""];case"raids":return(i.stats.raidsWon||0)>=(e.n||1);case"relics":return i.bots.filter(t=>No(t.sp)).length>=(e.n||1);case"forged":return(i.stats.forged||0)>=(e.n||1);case"eventSteps":return(i.stats.eventSteps||0)>=(e.n||1);case"bayOn":return!!(i.islands[e.t||""]&&i.islands[e.t||""].items.some(t=>t.t==="bay"&&t.lvl>0));case"trophies":return(i.arena&&i.arena.best||0)>=(e.n||1)}return!1}const Na=i=>ro[i.obj.i]||null;function af(i){const e=Na(i);return!e||!co(i,e)?null:(Un(i,e.reward),i.obj.claimed[e.id]=Date.now(),i.obj.i++,dt(i,10+i.obj.i*3),e)}const Ea=i=>Yl(i.lvl);function cd(i,e){const t=Bt[e];return!t||!t.cost?{ok:!1,why:"Unknown"}:i.islands[e]?{ok:!1,why:"Already founded"}:i.space&&i.space.visits[t.needs||""]>0?i.lvl<(t.level||1)?{ok:!1,why:`Commander level ${t.level}`,cost:t.cost}:i.res.credits<t.cost?{ok:!1,why:"Not enough credits",cost:t.cost}:{ok:!0,cost:t.cost}:{ok:!1,why:`Send an expedition to ${{moon:"the Moon",mars:"Mars",epseri:"Epsilon Eridani"}[t.needs||""]||t.needs} first`}}function rf(i,e){const t=cd(i,e);if(!t.ok)return t;i.res.credits-=t.cost||0;const n=(s,a,r)=>({id:Jt("i"),t:s,x:a,z:r,r:0,lvl:1});return i.islands[e]={plots:["1,1","2,1","3,1","1,2","2,2","3,2","1,3","2,3","3,3"],bought:0,items:[n("hub",13,13),n("rock",9,9),n("rock",19,18),n("rock",8,17),n("crystal",18,9)]},i.at=e,Gn(i,"islands"),dt(i,150),Ci({kind:"founded",key:e}),t}function of(i,e){return i.islands[e]?(i.at=e,!0):!1}const lf=i=>Au(i),um=Object.freeze(Object.defineProperty({__proto__:null,BOT_MAX:ko,addXp:dt,advance:Ia,allItems:Uo,areaFree:ps,bayCap:Yi,bayCapAt:lf,bayRate:zo,botEarn:Ei,botsIn:Dn,build:Gu,buildersBusy:Oo,buyPlot:sf,canBuild:ei,canBuyPlot:ld,canCraft:tf,canFound:cd,canPay:rm,canRecruit:ad,canUpgrade:id,ccLevel:ts,claimStep:af,collectBay:rd,craft:nf,currentStep:Na,dims:gn,dmCost:ui,events:hn,feed:sd,feedCost:Bo,finishNow:Zu,found:rf,give:Un,harvest:od,here:En,homeFor:ws,hubLevel:Fo,islandOf:es,item:Rt,itemsHere:nd,itemsOf:ze,jobOf:At,maxLevelOf:Vu,moveBot:Qu,moveItem:Yu,onMission:za,pay:om,plotCost:Ho,plotLevel:Go,plotOf:$u,plotState:$o,recipesFor:ef,recruit:ju,sellDecor:Ku,stepDone:co,tileOpen:Hu,travel:of,upgrade:Wu,xpNeedOf:Ea},Symbol.toStringTag,{value:"Module"}));const dd="187",fm=0,eh=1,pm=2,Jr=1,cf=2,Aa=3,vs=0,rn=1,Mn=2,Ks=0,Ua=1,fi=2,th=3,nh=4,mm=5,Xs=100,gm=101,vm=102,ym=103,xm=104,bm=200,_m=201,Mm=202,wm=203,df=204,hf=205,Sm=206,Em=207,Am=208,Tm=209,Rm=210,Cm=211,Pm=212,Lm=213,Dm=214,nc=0,ic=1,sc=2,$a=3,ac=4,rc=5,oc=6,lc=7,hd=0,Im=1,Nm=2,Ii=0,uf=1,ff=2,pf=3,ud=4,mf=5,gf=6,vf=7,yf=300,sa=301,Ha=302,hl=303,ul=304,ho=1e3,Pi=1001,cc=1002,sn=1003,Um=1004,or=1005,vn=1006,fl=1007,Li=1008,wn=1009,xf=1010,bf=1011,Ga=1012,fd=1013,mi=1014,ii=1015,gi=1016,pd=1017,md=1018,aa=1020,_f=35902,Mf=35899,wf=1021,Sf=1022,hi=1023,ns=1026,Ji=1027,gd=1028,vd=1029,ys=1030,yd=1031,xd=1033,jr=33776,Qr=33777,eo=33778,to=33779,dc=35840,hc=35841,uc=35842,fc=35843,pc=36196,mc=37492,gc=37496,vc=37488,yc=37489,uo=37490,xc=37491,bc=37808,_c=37809,Mc=37810,wc=37811,Sc=37812,Ec=37813,Ac=37814,Tc=37815,Rc=37816,Cc=37817,Pc=37818,Lc=37819,Dc=37820,Ic=37821,Nc=36492,Uc=36494,Fc=36495,Oc=36283,kc=36284,fo=36285,Bc=36286,Fm=3200,po=0,Om=1,Ti="",zt="srgb",mo="srgb-linear",go="linear",lt="srgb",pl=7680,km=519,Bm=512,zm=513,$m=514,Ef=515,Hm=516,Gm=517,Af=518,Tf=519,Rf=35044,ih="300 es",si=2e3,Va=2001;function Vm(i){for(let e=i.length-1;e>=0;--e)if(i[e]>=65535)return!0;return!1}function vo(i){return document.createElementNS("http://www.w3.org/1999/xhtml",i)}function Wm(){const i=vo("canvas");return i.style.display="block",i}const sh={};function yo(...i){const e="THREE."+i.shift();console.log(e,...i)}function Cf(i){const e=i[0];if(typeof e=="string"&&e.startsWith("TSL:")){const t=i[1];t&&t.isStackTrace?i[0]+=" "+t.getLocation():i[1]='Stack trace not available. Enable "THREE.Node.captureStackTrace" to capture stack traces.'}return i}function Ue(...i){i=Cf(i);const e="THREE."+i.shift();{const t=i[0];t&&t.isStackTrace?console.warn(t.getError(e)):console.warn(e,...i)}}function it(...i){i=Cf(i);const e="THREE."+i.shift();{const t=i[0];t&&t.isStackTrace?console.error(t.getError(e)):console.error(e,...i)}}function no(...i){const e=i.join(" ");e in sh||(sh[e]=!0,Ue(...i))}function Xm(i,e,t){return new Promise(function(n,s){function a(){switch(i.clientWaitSync(e,i.SYNC_FLUSH_COMMANDS_BIT,0)){case i.WAIT_FAILED:s();break;case i.TIMEOUT_EXPIRED:setTimeout(a,t);break;default:n()}}setTimeout(a,t)})}const qm={[nc]:nc,[sc]:oc,[ac]:ac,[$a]:rc,[ic]:ic,[oc]:sc,[lc]:lc,[rc]:$a};class Ss{addEventListener(e,t){this._listeners===void 0&&(this._listeners={});const n=this._listeners;n[e]===void 0&&(n[e]=[]),n[e].indexOf(t)===-1&&n[e].push(t)}hasEventListener(e,t){const n=this._listeners;return n===void 0?!1:n[e]!==void 0&&n[e].indexOf(t)!==-1}removeEventListener(e,t){const n=this._listeners;if(n===void 0)return;const s=n[e];if(s!==void 0){const a=s.indexOf(t);a!==-1&&s.splice(a,1)}}dispatchEvent(e){const t=this._listeners;if(t===void 0)return;const n=t[e.type];if(n!==void 0){e.target=this;const s=n.slice(0);for(let a=0,r=s.length;a<r;a++)s[a].call(this,e);e.target=null}}}const cn=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"];let ah=1234567;const Zs=Math.PI/180,Wa=180/Math.PI;function ss(){const i=Math.random()*4294967295|0,e=Math.random()*4294967295|0,t=Math.random()*4294967295|0,n=Math.random()*4294967295|0;return(cn[i&255]+cn[i>>8&255]+cn[i>>16&255]+cn[i>>24&255]+"-"+cn[e&255]+cn[e>>8&255]+"-"+cn[e>>16&15|64]+cn[e>>24&255]+"-"+cn[t&63|128]+cn[t>>8&255]+"-"+cn[t>>16&255]+cn[t>>24&255]+cn[n&255]+cn[n>>8&255]+cn[n>>16&255]+cn[n>>24&255]).toLowerCase()}function je(i,e,t){return Math.max(e,Math.min(t,i))}function bd(i,e){return(i%e+e)%e}function Ym(i,e,t,n,s){return n+(i-e)*(s-n)/(t-e)}function Km(i,e,t){return i!==e?(t-i)/(e-i):0}function Fa(i,e,t){return(1-t)*i+t*e}function Zm(i,e,t,n){return Fa(i,e,1-Math.exp(-t*n))}function Jm(i,e=1){return e-Math.abs(bd(i,e*2)-e)}function jm(i,e,t){return i<=e?0:i>=t?1:(i=(i-e)/(t-e),i*i*(3-2*i))}function Qm(i,e,t){return i<=e?0:i>=t?1:(i=(i-e)/(t-e),i*i*i*(i*(i*6-15)+10))}function e0(i,e){return i+Math.floor(Math.random()*(e-i+1))}function t0(i,e){return i+Math.random()*(e-i)}function n0(i){return i*(.5-Math.random())}function i0(i){i!==void 0&&(ah=i);let e=ah+=1831565813;return e=Math.imul(e^e>>>15,e|1),e^=e+Math.imul(e^e>>>7,e|61),((e^e>>>14)>>>0)/4294967296}function s0(i){return i*Zs}function a0(i){return i*Wa}function r0(i){return i>0&&Number.isInteger(i)&&2**Math.round(Math.log2(i))===i}function o0(i){return Math.pow(2,Math.ceil(Math.log(i)/Math.LN2))}function Pf(i){return Math.pow(2,Math.floor(Math.log(i)/Math.LN2))}function l0(i,e,t,n,s){const a=Math.cos,r=Math.sin,o=a(t/2),l=r(t/2),c=a((e+n)/2),d=r((e+n)/2),h=a((e-n)/2),u=r((e-n)/2),f=a((n-e)/2),g=r((n-e)/2);switch(s){case"XYX":i.set(o*d,l*h,l*u,o*c);break;case"YZY":i.set(l*u,o*d,l*h,o*c);break;case"ZXZ":i.set(l*h,l*u,o*d,o*c);break;case"XZX":i.set(o*d,l*g,l*f,o*c);break;case"YXY":i.set(l*f,o*d,l*g,o*c);break;case"ZYZ":i.set(l*g,l*f,o*d,o*c);break;default:Ue("MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+s)}}function Vo(i){switch(i.constructor){case Uint32Array:return 4294967295;case Uint16Array:return 65535;case Uint8Array:case Uint8ClampedArray:return 255;case Int32Array:return 2147483647;case Int16Array:return 32767;case Int8Array:return 127;default:return}}function _d(i,e){if(e.constructor===Float32Array)return i;const t=Vo(e);if(t===void 0)throw new Error("THREE.MathUtils: Invalid component type.");return Math.max(i/t,-1)}function Md(i,e){if(e.constructor===Float32Array)return i;const t=Vo(e);if(t===void 0)throw new Error("THREE.MathUtils: Invalid component type.");return Math.round(i*t)}const xo={DEG2RAD:Zs,RAD2DEG:Wa,generateUUID:ss,clamp:je,euclideanModulo:bd,mapLinear:Ym,inverseLerp:Km,lerp:Fa,damp:Zm,pingpong:Jm,smoothstep:jm,smootherstep:Qm,randInt:e0,randFloat:t0,randFloatSpread:n0,seededRandom:i0,degToRad:s0,radToDeg:a0,isPowerOfTwo:r0,ceilPowerOfTwo:o0,floorPowerOfTwo:Pf,setQuaternionFromProperEuler:l0,normalize:Md,denormalize:_d},Ud=class Ud{constructor(e=0,t=0){this.x=e,this.y=t}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,t){return this.x=e,this.y=t,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;default:throw new Error("THREE.Vector2: index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw new Error("THREE.Vector2: index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){const t=this.x,n=this.y,s=e.elements;return this.x=s[0]*t+s[3]*n+s[6],this.y=s[1]*t+s[4]*n+s[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,t){return this.x=je(this.x,e.x,t.x),this.y=je(this.y,e.y,t.y),this}clampScalar(e,t){return this.x=je(this.x,e,t),this.y=je(this.y,e,t),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(je(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const n=this.dot(e)/t;return Math.acos(je(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,n=this.y-e.y;return t*t+n*n}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this}rotateAround(e,t){const n=Math.cos(t),s=Math.sin(t),a=this.x-e.x,r=this.y-e.y;return this.x=a*n-r*s+e.x,this.y=a*s+r*n+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}};Ud.prototype.isVector2=!0;let Ie=Ud;class Ui{constructor(e=0,t=0,n=0,s=1){this.isQuaternion=!0,this._x=e,this._y=t,this._z=n,this._w=s}static slerpFlat(e,t,n,s,a,r,o){let l=n[s+0],c=n[s+1],d=n[s+2],h=n[s+3],u=a[r+0],f=a[r+1],g=a[r+2],y=a[r+3];if(h!==y||l!==u||c!==f||d!==g){let m=l*u+c*f+d*g+h*y;m<0&&(u=-u,f=-f,g=-g,y=-y,m=-m);let p=1-o;if(m<.9995){const x=Math.acos(m),A=Math.sin(x);p=Math.sin(p*x)/A,o=Math.sin(o*x)/A,l=l*p+u*o,c=c*p+f*o,d=d*p+g*o,h=h*p+y*o}else{l=l*p+u*o,c=c*p+f*o,d=d*p+g*o,h=h*p+y*o;const x=1/Math.sqrt(l*l+c*c+d*d+h*h);l*=x,c*=x,d*=x,h*=x}}e[t]=l,e[t+1]=c,e[t+2]=d,e[t+3]=h}static multiplyQuaternionsFlat(e,t,n,s,a,r){const o=n[s],l=n[s+1],c=n[s+2],d=n[s+3],h=a[r],u=a[r+1],f=a[r+2],g=a[r+3];return e[t]=o*g+d*h+l*f-c*u,e[t+1]=l*g+d*u+c*h-o*f,e[t+2]=c*g+d*f+o*u-l*h,e[t+3]=d*g-o*h-l*u-c*f,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,t,n,s){return this._x=e,this._y=t,this._z=n,this._w=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,t=!0){const n=e._x,s=e._y,a=e._z,r=e._order,o=Math.cos,l=Math.sin,c=o(n/2),d=o(s/2),h=o(a/2),u=l(n/2),f=l(s/2),g=l(a/2);switch(r){case"XYZ":this._x=u*d*h+c*f*g,this._y=c*f*h-u*d*g,this._z=c*d*g+u*f*h,this._w=c*d*h-u*f*g;break;case"YXZ":this._x=u*d*h+c*f*g,this._y=c*f*h-u*d*g,this._z=c*d*g-u*f*h,this._w=c*d*h+u*f*g;break;case"ZXY":this._x=u*d*h-c*f*g,this._y=c*f*h+u*d*g,this._z=c*d*g+u*f*h,this._w=c*d*h-u*f*g;break;case"ZYX":this._x=u*d*h-c*f*g,this._y=c*f*h+u*d*g,this._z=c*d*g-u*f*h,this._w=c*d*h+u*f*g;break;case"YZX":this._x=u*d*h+c*f*g,this._y=c*f*h+u*d*g,this._z=c*d*g-u*f*h,this._w=c*d*h-u*f*g;break;case"XZY":this._x=u*d*h-c*f*g,this._y=c*f*h-u*d*g,this._z=c*d*g+u*f*h,this._w=c*d*h+u*f*g;break;default:Ue("Quaternion: .setFromEuler() encountered an unknown order: "+r)}return t===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,t){const n=t/2,s=Math.sin(n);return this._x=e.x*s,this._y=e.y*s,this._z=e.z*s,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(e){const t=e.elements,n=t[0],s=t[4],a=t[8],r=t[1],o=t[5],l=t[9],c=t[2],d=t[6],h=t[10],u=n+o+h;if(u>0){const f=.5/Math.sqrt(u+1);this._w=.25/f,this._x=(d-l)*f,this._y=(a-c)*f,this._z=(r-s)*f}else if(n>o&&n>h){const f=2*Math.sqrt(1+n-o-h);this._w=(d-l)/f,this._x=.25*f,this._y=(s+r)/f,this._z=(a+c)/f}else if(o>h){const f=2*Math.sqrt(1+o-n-h);this._w=(a-c)/f,this._x=(s+r)/f,this._y=.25*f,this._z=(l+d)/f}else{const f=2*Math.sqrt(1+h-n-o);this._w=(r-s)/f,this._x=(a+c)/f,this._y=(l+d)/f,this._z=.25*f}return this._onChangeCallback(),this}setFromUnitVectors(e,t){let n=e.dot(t)+1;return n<1e-8?(n=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=n):(this._x=0,this._y=-e.z,this._z=e.y,this._w=n)):(this._x=e.y*t.z-e.z*t.y,this._y=e.z*t.x-e.x*t.z,this._z=e.x*t.y-e.y*t.x,this._w=n),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(je(this.dot(e),-1,1)))}rotateTowards(e,t){const n=this.angleTo(e);if(n===0)return this;const s=Math.min(1,t/n);return this.slerp(e,s),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,t){const n=e._x,s=e._y,a=e._z,r=e._w,o=t._x,l=t._y,c=t._z,d=t._w;return this._x=n*d+r*o+s*c-a*l,this._y=s*d+r*l+a*o-n*c,this._z=a*d+r*c+n*l-s*o,this._w=r*d-n*o-s*l-a*c,this._onChangeCallback(),this}slerp(e,t){let n=e._x,s=e._y,a=e._z,r=e._w,o=this.dot(e);o<0&&(n=-n,s=-s,a=-a,r=-r,o=-o);let l=1-t;if(o<.9995){const c=Math.acos(o),d=Math.sin(c);l=Math.sin(l*c)/d,t=Math.sin(t*c)/d,this._x=this._x*l+n*t,this._y=this._y*l+s*t,this._z=this._z*l+a*t,this._w=this._w*l+r*t,this._onChangeCallback()}else this._x=this._x*l+n*t,this._y=this._y*l+s*t,this._z=this._z*l+a*t,this._w=this._w*l+r*t,this.normalize();return this}slerpQuaternions(e,t,n){return this.copy(e).slerp(t,n)}random(){const e=2*Math.PI*Math.random(),t=2*Math.PI*Math.random(),n=Math.random(),s=Math.sqrt(1-n),a=Math.sqrt(n);return this.set(s*Math.sin(e),s*Math.cos(e),a*Math.sin(t),a*Math.cos(t))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,t=0){return this._x=e[t],this._y=e[t+1],this._z=e[t+2],this._w=e[t+3],this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._w,e}fromBufferAttribute(e,t){return this._x=e.getX(t),this._y=e.getY(t),this._z=e.getZ(t),this._w=e.getW(t),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}const Fd=class Fd{constructor(e=0,t=0,n=0){this.x=e,this.y=t,this.z=n}set(e,t,n){return n===void 0&&(n=this.z),this.x=e,this.y=t,this.z=n,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;default:throw new Error("THREE.Vector3: index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("THREE.Vector3: index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,t){return this.x=e.x*t.x,this.y=e.y*t.y,this.z=e.z*t.z,this}applyEuler(e){return this.applyQuaternion(rh.setFromEuler(e))}applyAxisAngle(e,t){return this.applyQuaternion(rh.setFromAxisAngle(e,t))}applyMatrix3(e){const t=this.x,n=this.y,s=this.z,a=e.elements;return this.x=a[0]*t+a[3]*n+a[6]*s,this.y=a[1]*t+a[4]*n+a[7]*s,this.z=a[2]*t+a[5]*n+a[8]*s,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){const t=this.x,n=this.y,s=this.z,a=e.elements,r=1/(a[3]*t+a[7]*n+a[11]*s+a[15]);return this.x=(a[0]*t+a[4]*n+a[8]*s+a[12])*r,this.y=(a[1]*t+a[5]*n+a[9]*s+a[13])*r,this.z=(a[2]*t+a[6]*n+a[10]*s+a[14])*r,this}applyQuaternion(e){const t=this.x,n=this.y,s=this.z,a=e.x,r=e.y,o=e.z,l=e.w,c=2*(r*s-o*n),d=2*(o*t-a*s),h=2*(a*n-r*t);return this.x=t+l*c+r*h-o*d,this.y=n+l*d+o*c-a*h,this.z=s+l*h+a*d-r*c,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){const t=this.x,n=this.y,s=this.z,a=e.elements;return this.x=a[0]*t+a[4]*n+a[8]*s,this.y=a[1]*t+a[5]*n+a[9]*s,this.z=a[2]*t+a[6]*n+a[10]*s,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,t){return this.x=je(this.x,e.x,t.x),this.y=je(this.y,e.y,t.y),this.z=je(this.z,e.z,t.z),this}clampScalar(e,t){return this.x=je(this.x,e,t),this.y=je(this.y,e,t),this.z=je(this.z,e,t),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(je(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,t){const n=e.x,s=e.y,a=e.z,r=t.x,o=t.y,l=t.z;return this.x=s*l-a*o,this.y=a*r-n*l,this.z=n*o-s*r,this}projectOnVector(e){const t=e.lengthSq();if(t===0)return this.set(0,0,0);const n=e.dot(this)/t;return this.copy(e).multiplyScalar(n)}projectOnPlane(e){return ml.copy(this).projectOnVector(e),this.sub(ml)}reflect(e){return this.sub(ml.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const n=this.dot(e)/t;return Math.acos(je(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,n=this.y-e.y,s=this.z-e.z;return t*t+n*n+s*s}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,t,n){const s=Math.sin(t)*e;return this.x=s*Math.sin(n),this.y=Math.cos(t)*e,this.z=s*Math.cos(n),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,t,n){return this.x=e*Math.sin(t),this.y=n,this.z=e*Math.cos(t),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this}setFromMatrixScale(e){const t=this.setFromMatrixColumn(e,0).length(),n=this.setFromMatrixColumn(e,1).length(),s=this.setFromMatrixColumn(e,2).length();return this.x=t,this.y=n,this.z=s,this}setFromMatrixColumn(e,t){return this.fromArray(e.elements,t*4)}setFromMatrix3Column(e,t){return this.fromArray(e.elements,t*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const e=Math.random()*Math.PI*2,t=Math.random()*2-1,n=Math.sqrt(1-t*t);return this.x=n*Math.cos(e),this.y=t,this.z=n*Math.sin(e),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}};Fd.prototype.isVector3=!0;let D=Fd;const ml=new D,rh=new Ui,Od=class Od{constructor(e,t,n,s,a,r,o,l,c){this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,t,n,s,a,r,o,l,c)}set(e,t,n,s,a,r,o,l,c){const d=this.elements;return d[0]=e,d[1]=s,d[2]=o,d[3]=t,d[4]=a,d[5]=l,d[6]=n,d[7]=r,d[8]=c,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){const t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],this}extractBasis(e,t,n){return e.setFromMatrix3Column(this,0),t.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(e){const t=e.elements;return this.set(t[0],t[4],t[8],t[1],t[5],t[9],t[2],t[6],t[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const n=e.elements,s=t.elements,a=this.elements,r=n[0],o=n[3],l=n[6],c=n[1],d=n[4],h=n[7],u=n[2],f=n[5],g=n[8],y=s[0],m=s[3],p=s[6],x=s[1],A=s[4],b=s[7],E=s[2],S=s[5],v=s[8];return a[0]=r*y+o*x+l*E,a[3]=r*m+o*A+l*S,a[6]=r*p+o*b+l*v,a[1]=c*y+d*x+h*E,a[4]=c*m+d*A+h*S,a[7]=c*p+d*b+h*v,a[2]=u*y+f*x+g*E,a[5]=u*m+f*A+g*S,a[8]=u*p+f*b+g*v,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[3]*=e,t[6]*=e,t[1]*=e,t[4]*=e,t[7]*=e,t[2]*=e,t[5]*=e,t[8]*=e,this}determinant(){const e=this.elements,t=e[0],n=e[1],s=e[2],a=e[3],r=e[4],o=e[5],l=e[6],c=e[7],d=e[8];return t*r*d-t*o*c-n*a*d+n*o*l+s*a*c-s*r*l}invert(){const e=this.elements,t=e[0],n=e[1],s=e[2],a=e[3],r=e[4],o=e[5],l=e[6],c=e[7],d=e[8],h=d*r-o*c,u=o*l-d*a,f=c*a-r*l,g=t*h+n*u+s*f;if(g===0)return this.set(0,0,0,0,0,0,0,0,0);const y=1/g;return e[0]=h*y,e[1]=(s*c-d*n)*y,e[2]=(o*n-s*r)*y,e[3]=u*y,e[4]=(d*t-s*l)*y,e[5]=(s*a-o*t)*y,e[6]=f*y,e[7]=(n*l-c*t)*y,e[8]=(r*t-n*a)*y,this}transpose(){let e;const t=this.elements;return e=t[1],t[1]=t[3],t[3]=e,e=t[2],t[2]=t[6],t[6]=e,e=t[5],t[5]=t[7],t[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){const t=this.elements;return e[0]=t[0],e[1]=t[3],e[2]=t[6],e[3]=t[1],e[4]=t[4],e[5]=t[7],e[6]=t[2],e[7]=t[5],e[8]=t[8],this}setUvTransform(e,t,n,s,a,r,o){const l=Math.cos(a),c=Math.sin(a);return this.set(n*l,n*c,-n*(l*r+c*o)+r+e,-s*c,s*l,-s*(-c*r+l*o)+o+t,0,0,1),this}scale(e,t){return no("Matrix3: .scale() is deprecated. Use .makeScale() instead."),this.premultiply(gl.makeScale(e,t)),this}rotate(e){return no("Matrix3: .rotate() is deprecated. Use .makeRotation() instead."),this.premultiply(gl.makeRotation(-e)),this}translate(e,t){return no("Matrix3: .translate() is deprecated. Use .makeTranslation() instead."),this.premultiply(gl.makeTranslation(e,t)),this}makeTranslation(e,t){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,t,0,0,1),this}makeRotation(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,n,t,0,0,0,1),this}makeScale(e,t){return this.set(e,0,0,0,t,0,0,0,1),this}equals(e){const t=this.elements,n=e.elements;for(let s=0;s<9;s++)if(t[s]!==n[s])return!1;return!0}fromArray(e,t=0){for(let n=0;n<9;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){const n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e}clone(){return new this.constructor().fromArray(this.elements)}};Od.prototype.isMatrix3=!0;let ke=Od;const gl=new ke,oh=new ke().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),lh=new ke().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function c0(){const i={enabled:!0,workingColorSpace:mo,spaces:{},convert:function(s,a,r){return this.enabled===!1||a===r||!a||!r||(this.spaces[a].transfer===lt&&(s.r=Ni(s.r),s.g=Ni(s.g),s.b=Ni(s.b)),this.spaces[a].primaries!==this.spaces[r].primaries&&(s.applyMatrix3(this.spaces[a].toXYZ),s.applyMatrix3(this.spaces[r].fromXYZ)),this.spaces[r].transfer===lt&&(s.r=Js(s.r),s.g=Js(s.g),s.b=Js(s.b))),s},workingToColorSpace:function(s,a){return this.convert(s,this.workingColorSpace,a)},colorSpaceToWorking:function(s,a){return this.convert(s,a,this.workingColorSpace)},getPrimaries:function(s){return this.spaces[s].primaries},getTransfer:function(s){return s===Ti?go:this.spaces[s].transfer},getToneMappingMode:function(s){return this.spaces[s].outputColorSpaceConfig.toneMappingMode||"standard"},getLuminanceCoefficients:function(s,a=this.workingColorSpace){return s.fromArray(this.spaces[a].luminanceCoefficients)},define:function(s){Object.assign(this.spaces,s)},_getMatrix:function(s,a,r){return s.copy(this.spaces[r].fromXYZ).multiply(this.spaces[a].toXYZ)},_getDrawingBufferColorSpace:function(s){return this.spaces[s].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(s=this.workingColorSpace){return this.spaces[s].workingColorSpaceConfig.unpackColorSpace}},e=[.64,.33,.3,.6,.15,.06],t=[.2126,.7152,.0722],n=[.3127,.329];return i.define({[mo]:{primaries:e,whitePoint:n,transfer:go,toXYZ:oh,fromXYZ:lh,luminanceCoefficients:t,workingColorSpaceConfig:{unpackColorSpace:zt},outputColorSpaceConfig:{drawingBufferColorSpace:zt}},[zt]:{primaries:e,whitePoint:n,transfer:lt,toXYZ:oh,fromXYZ:lh,luminanceCoefficients:t,outputColorSpaceConfig:{drawingBufferColorSpace:zt}}}),i}const et=c0();function Ni(i){return i<.04045?i*.0773993808:Math.pow(i*.9478672986+.0521327014,2.4)}function Js(i){return i<.0031308?i*12.92:1.055*Math.pow(i,.41666)-.055}let Rs;class d0{static getDataURL(e,t="image/png"){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>"u")return e.src;let n;if(e instanceof HTMLCanvasElement)n=e;else{Rs===void 0&&(Rs=vo("canvas")),Rs.width=e.width,Rs.height=e.height;const s=Rs.getContext("2d");e instanceof ImageData?s.putImageData(e,0,0):s.drawImage(e,0,0,e.width,e.height),n=Rs}return n.toDataURL(t)}static sRGBToLinear(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){const t=vo("canvas");t.width=e.width,t.height=e.height;const n=t.getContext("2d");n.drawImage(e,0,0,e.width,e.height);const s=n.getImageData(0,0,e.width,e.height),a=s.data;for(let r=0;r<a.length;r++)a[r]=Ni(a[r]/255)*255;return n.putImageData(s,0,0),t}else if(e.data){const t=e.data.slice(0);for(let n=0;n<t.length;n++)t instanceof Uint8Array||t instanceof Uint8ClampedArray?t[n]=Math.floor(Ni(t[n]/255)*255):t[n]=Ni(t[n]);return{data:t,width:e.width,height:e.height}}else return Ue("ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}}let h0=0;class wd{constructor(e=null){this.isTextureSource=!0,Object.defineProperty(this,"id",{value:h0++}),this.uuid=ss(),this.data=e,this.dataReady=!0,this.version=0}getSize(e){const t=this.data;return typeof HTMLVideoElement<"u"&&t instanceof HTMLVideoElement?e.set(t.videoWidth,t.videoHeight,0):typeof VideoFrame<"u"&&t instanceof VideoFrame?e.set(t.displayWidth,t.displayHeight,0):t!==null?e.set(t.width||0,t.height||0,t.depth||0):e.set(0,0,0),e}set needsUpdate(e){e===!0&&this.version++}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.images[this.uuid]!==void 0)return e.images[this.uuid];const n={uuid:this.uuid,url:""},s=this.data;if(s!==null){let a;if(Array.isArray(s)){a=[];for(let r=0,o=s.length;r<o;r++)s[r].isDataTexture?a.push(vl(s[r].image)):a.push(vl(s[r]))}else a=vl(s);n.url=a}return t||(e.images[this.uuid]=n),n}}function vl(i){return typeof HTMLImageElement<"u"&&i instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&i instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&i instanceof ImageBitmap?d0.getDataURL(i):i.data?{data:Array.from(i.data),width:i.width,height:i.height,type:i.data.constructor.name}:(Ue("Texture: Unable to serialize Texture."),{})}let u0=0;const yl=new D;class un extends Ss{constructor(e=un.DEFAULT_IMAGE,t=un.DEFAULT_MAPPING,n=Pi,s=Pi,a=vn,r=Li,o=hi,l=wn,c=un.DEFAULT_ANISOTROPY,d=Ti){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:u0++}),this.uuid=ss(),this.name="",this.source=new wd(e),this.mipmaps=[],this.mapping=t,this.channel=0,this.wrapS=n,this.wrapT=s,this.magFilter=a,this.minFilter=r,this.anisotropy=c,this.format=o,this.internalFormat=null,this.type=l,this.offset=new Ie(0,0),this.repeat=new Ie(1,1),this.center=new Ie(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new ke,this.generateMipmaps=!0,this.mipmapsAutoUpdate=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=d,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(e&&e.depth&&e.depth>1),this.pmremVersion=0,this.isPMREMTexture=!1,this.normalized=!1}get width(){return this.source.getSize(yl).x}get height(){return this.source.getSize(yl).y}get depth(){return this.source.getSize(yl).z}get image(){return this.source.data}set image(e){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.normalized=e.normalized,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.mipmapsAutoUpdate=e.mipmapsAutoUpdate,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.renderTarget=e.renderTarget,this.isRenderTargetTexture=e.isRenderTargetTexture,this.isPMREMTexture=e.isPMREMTexture,this.isArrayTexture=e.isArrayTexture,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}setValues(e){for(const t in e){const n=e[t];if(n===void 0){Ue(`Texture.setValues(): parameter '${t}' has value of undefined.`);continue}const s=this[t];if(s===void 0){Ue(`Texture.setValues(): property '${t}' does not exist.`);continue}s&&n&&s.isVector2&&n.isVector2||s&&n&&s.isVector3&&n.isVector3||s&&n&&s.isMatrix3&&n.isMatrix3?s.copy(n):this[t]=n}}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];const n={metadata:{version:4.7,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,normalized:this.normalized,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,mipmapsAutoUpdate:this.mipmapsAutoUpdate,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),t||(e.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(e){if(this.mapping!==yf)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case ho:e.x=e.x-Math.floor(e.x);break;case Pi:e.x=e.x<0?0:1;break;case cc:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x=e.x-Math.floor(e.x);break}if(e.y<0||e.y>1)switch(this.wrapT){case ho:e.y=e.y-Math.floor(e.y);break;case Pi:e.y=e.y<0?0:1;break;case cc:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y=e.y-Math.floor(e.y);break}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(e){e===!0&&this.pmremVersion++}}un.DEFAULT_IMAGE=null;un.DEFAULT_MAPPING=yf;un.DEFAULT_ANISOTROPY=1;const kd=class kd{constructor(e=0,t=0,n=0,s=1){this.x=e,this.y=t,this.z=n,this.w=s}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,t,n,s){return this.x=e,this.y=t,this.z=n,this.w=s,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;case 3:this.w=t;break;default:throw new Error("THREE.Vector4: index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("THREE.Vector4: index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w!==void 0?e.w:1,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this.w=e.w+t.w,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this.w+=e.w*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this.w=e.w-t.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){const t=this.x,n=this.y,s=this.z,a=this.w,r=e.elements;return this.x=r[0]*t+r[4]*n+r[8]*s+r[12]*a,this.y=r[1]*t+r[5]*n+r[9]*s+r[13]*a,this.z=r[2]*t+r[6]*n+r[10]*s+r[14]*a,this.w=r[3]*t+r[7]*n+r[11]*s+r[15]*a,this}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this.w/=e.w,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);const t=Math.sqrt(1-e.w*e.w);return t<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/t,this.y=e.y/t,this.z=e.z/t),this}setAxisAngleFromRotationMatrix(e){let t,n,s,a;const l=e.elements,c=l[0],d=l[4],h=l[8],u=l[1],f=l[5],g=l[9],y=l[2],m=l[6],p=l[10];if(Math.abs(d-u)<.01&&Math.abs(h-y)<.01&&Math.abs(g-m)<.01){if(Math.abs(d+u)<.1&&Math.abs(h+y)<.1&&Math.abs(g+m)<.1&&Math.abs(c+f+p-3)<.1)return this.set(1,0,0,0),this;t=Math.PI;const A=(c+1)/2,b=(f+1)/2,E=(p+1)/2,S=(d+u)/4,v=(h+y)/4,w=(g+m)/4;return A>b&&A>E?A<.01?(n=0,s=.707106781,a=.707106781):(n=Math.sqrt(A),s=S/n,a=v/n):b>E?b<.01?(n=.707106781,s=0,a=.707106781):(s=Math.sqrt(b),n=S/s,a=w/s):E<.01?(n=.707106781,s=.707106781,a=0):(a=Math.sqrt(E),n=v/a,s=w/a),this.set(n,s,a,t),this}let x=Math.sqrt((m-g)*(m-g)+(h-y)*(h-y)+(u-d)*(u-d));return Math.abs(x)<.001&&(x=1),this.x=(m-g)/x,this.y=(h-y)/x,this.z=(u-d)/x,this.w=Math.acos((c+f+p-1)/2),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this.w=t[15],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,t){return this.x=je(this.x,e.x,t.x),this.y=je(this.y,e.y,t.y),this.z=je(this.z,e.z,t.z),this.w=je(this.w,e.w,t.w),this}clampScalar(e,t){return this.x=je(this.x,e,t),this.y=je(this.y,e,t),this.z=je(this.z,e,t),this.w=je(this.w,e,t),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(je(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this.w+=(e.w-this.w)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this.w=e.w+(t.w-e.w)*n,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this.w=e[t+3],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e[t+3]=this.w,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this.w=e.getW(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}};kd.prototype.isVector4=!0;let Tt=kd;class f0 extends Ss{constructor(e=1,t=1,n={}){super(),n=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:vn,depthBuffer:!0,stencilBuffer:!1,resolveColorBuffer:!0,resolveDepthBuffer:!0,resolveStencilBuffer:!0,storeMultisampledColorBuffer:!0,storeMultisampledDepthBuffer:!0,storeMultisampledStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1,useArrayDepthTexture:!1},n),this.isRenderTarget=!0,this.width=e,this.height=t,this.depth=n.depth,this.scissor=new Tt(0,0,e,t),this.scissorTest=!1,this.viewport=new Tt(0,0,e,t),this.textures=[];const s=n.count;for(let a=0;a<s;a++)this.textures[a]=new un({width:e,height:t,depth:n.depth}),this.textures[a].isRenderTargetTexture=!0,this.textures[a].renderTarget=this;this._setTextureOptions(n),this.depthBuffer=n.depthBuffer,this.stencilBuffer=n.stencilBuffer,this.resolveColorBuffer=n.resolveColorBuffer,this.resolveDepthBuffer=n.resolveDepthBuffer,this.resolveStencilBuffer=n.resolveStencilBuffer,this.storeMultisampledColorBuffer=n.storeMultisampledColorBuffer,this.storeMultisampledDepthBuffer=n.storeMultisampledDepthBuffer,this.storeMultisampledStencilBuffer=n.storeMultisampledStencilBuffer,this._depthTexture=null,this.depthTexture=n.depthTexture,this.samples=n.samples,this.multiview=n.multiview,this.useArrayDepthTexture=n.useArrayDepthTexture}_setTextureOptions(e={}){const t={minFilter:vn,generateMipmaps:!1,flipY:!1,internalFormat:null};e.mapping!==void 0&&(t.mapping=e.mapping),e.wrapS!==void 0&&(t.wrapS=e.wrapS),e.wrapT!==void 0&&(t.wrapT=e.wrapT),e.wrapR!==void 0&&(t.wrapR=e.wrapR),e.magFilter!==void 0&&(t.magFilter=e.magFilter),e.minFilter!==void 0&&(t.minFilter=e.minFilter),e.format!==void 0&&(t.format=e.format),e.type!==void 0&&(t.type=e.type),e.anisotropy!==void 0&&(t.anisotropy=e.anisotropy),e.colorSpace!==void 0&&(t.colorSpace=e.colorSpace),e.flipY!==void 0&&(t.flipY=e.flipY),e.generateMipmaps!==void 0&&(t.generateMipmaps=e.generateMipmaps),e.mipmapsAutoUpdate!==void 0&&(t.mipmapsAutoUpdate=e.mipmapsAutoUpdate),e.internalFormat!==void 0&&(t.internalFormat=e.internalFormat);for(let n=0;n<this.textures.length;n++)this.textures[n].setValues(t)}get texture(){return this.textures[0]}set texture(e){this.textures[0]=e}set depthTexture(e){this._depthTexture!==null&&this._depthTexture.renderTarget===this&&(this._depthTexture.renderTarget=null),e!==null&&e.renderTarget===null&&(e.renderTarget=this),this._depthTexture=e}get depthTexture(){return this._depthTexture}setSize(e,t,n=1){if(this.width!==e||this.height!==t||this.depth!==n){this.width=e,this.height=t,this.depth=n;for(let s=0,a=this.textures.length;s<a;s++)this.textures[s].image.width=e,this.textures[s].image.height=t,this.textures[s].image.depth=n,this.textures[s].isData3DTexture!==!0&&(this.textures[s].isArrayTexture=this.textures[s].image.depth>1);this.dispose()}this.viewport.set(0,0,e,t),this.scissor.set(0,0,e,t)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.textures.length=0;for(let t=0,n=e.textures.length;t<n;t++){this.textures[t]=e.textures[t].clone(),this.textures[t].isRenderTargetTexture=!0,this.textures[t].renderTarget=this;const s=Object.assign({},e.textures[t].image);this.textures[t].source=new wd(s)}if(this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,this.resolveColorBuffer=e.resolveColorBuffer,this.resolveDepthBuffer=e.resolveDepthBuffer,this.resolveStencilBuffer=e.resolveStencilBuffer,this.storeMultisampledColorBuffer=e.storeMultisampledColorBuffer,this.storeMultisampledDepthBuffer=e.storeMultisampledDepthBuffer,this.storeMultisampledStencilBuffer=e.storeMultisampledStencilBuffer,e.depthTexture!==null)if(e.depthTexture.renderTarget===e){const t=e.depthTexture.clone();t.renderTarget=null,this.depthTexture=t}else this.depthTexture=e.depthTexture;else this.depthTexture=null;return this.samples=e.samples,this.multiview=e.multiview,this.useArrayDepthTexture=e.useArrayDepthTexture,this}dispose(){this.dispatchEvent({type:"dispose"})}}class Vn extends f0{constructor(e=1,t=1,n={}){super(e,t,n),this.isWebGLRenderTarget=!0}}class Lf extends un{constructor(e=null,t=1,n=1,s=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:t,height:n,depth:s},this.magFilter=sn,this.minFilter=sn,this.wrapR=Pi,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}copy(e){return super.copy(e),this.wrapR=e.wrapR,this}addLayerUpdate(e){this.layerUpdates.add(e)}clearLayerUpdates(){this.layerUpdates.clear()}}class p0 extends un{constructor(e=null,t=1,n=1,s=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:t,height:n,depth:s},this.magFilter=sn,this.minFilter=sn,this.wrapR=Pi,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}copy(e){return super.copy(e),this.wrapR=e.wrapR,this}}const Lo=class Lo{constructor(e,t,n,s,a,r,o,l,c,d,h,u,f,g,y,m){this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,t,n,s,a,r,o,l,c,d,h,u,f,g,y,m)}set(e,t,n,s,a,r,o,l,c,d,h,u,f,g,y,m){const p=this.elements;return p[0]=e,p[4]=t,p[8]=n,p[12]=s,p[1]=a,p[5]=r,p[9]=o,p[13]=l,p[2]=c,p[6]=d,p[10]=h,p[14]=u,p[3]=f,p[7]=g,p[11]=y,p[15]=m,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new Lo().fromArray(this.elements)}copy(e){const t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],t[9]=n[9],t[10]=n[10],t[11]=n[11],t[12]=n[12],t[13]=n[13],t[14]=n[14],t[15]=n[15],this}copyPosition(e){const t=this.elements,n=e.elements;return t[12]=n[12],t[13]=n[13],t[14]=n[14],this}setFromMatrix3(e){const t=e.elements;return this.set(t[0],t[3],t[6],0,t[1],t[4],t[7],0,t[2],t[5],t[8],0,0,0,0,1),this}extractBasis(e,t,n){return this.determinantAffine()===0?(e.set(1,0,0),t.set(0,1,0),n.set(0,0,1),this):(e.setFromMatrixColumn(this,0),t.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this)}makeBasis(e,t,n){return this.set(e.x,t.x,n.x,0,e.y,t.y,n.y,0,e.z,t.z,n.z,0,0,0,0,1),this}extractRotation(e){if(e.determinantAffine()===0)return this.identity();const t=this.elements,n=e.elements,s=1/Cs.setFromMatrixColumn(e,0).length(),a=1/Cs.setFromMatrixColumn(e,1).length(),r=1/Cs.setFromMatrixColumn(e,2).length();return t[0]=n[0]*s,t[1]=n[1]*s,t[2]=n[2]*s,t[3]=0,t[4]=n[4]*a,t[5]=n[5]*a,t[6]=n[6]*a,t[7]=0,t[8]=n[8]*r,t[9]=n[9]*r,t[10]=n[10]*r,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromEuler(e){const t=this.elements,n=e.x,s=e.y,a=e.z,r=Math.cos(n),o=Math.sin(n),l=Math.cos(s),c=Math.sin(s),d=Math.cos(a),h=Math.sin(a);if(e.order==="XYZ"){const u=r*d,f=r*h,g=o*d,y=o*h;t[0]=l*d,t[4]=-l*h,t[8]=c,t[1]=f+g*c,t[5]=u-y*c,t[9]=-o*l,t[2]=y-u*c,t[6]=g+f*c,t[10]=r*l}else if(e.order==="YXZ"){const u=l*d,f=l*h,g=c*d,y=c*h;t[0]=u+y*o,t[4]=g*o-f,t[8]=r*c,t[1]=r*h,t[5]=r*d,t[9]=-o,t[2]=f*o-g,t[6]=y+u*o,t[10]=r*l}else if(e.order==="ZXY"){const u=l*d,f=l*h,g=c*d,y=c*h;t[0]=u-y*o,t[4]=-r*h,t[8]=g+f*o,t[1]=f+g*o,t[5]=r*d,t[9]=y-u*o,t[2]=-r*c,t[6]=o,t[10]=r*l}else if(e.order==="ZYX"){const u=r*d,f=r*h,g=o*d,y=o*h;t[0]=l*d,t[4]=g*c-f,t[8]=u*c+y,t[1]=l*h,t[5]=y*c+u,t[9]=f*c-g,t[2]=-c,t[6]=o*l,t[10]=r*l}else if(e.order==="YZX"){const u=r*l,f=r*c,g=o*l,y=o*c;t[0]=l*d,t[4]=y-u*h,t[8]=g*h+f,t[1]=h,t[5]=r*d,t[9]=-o*d,t[2]=-c*d,t[6]=f*h+g,t[10]=u-y*h}else if(e.order==="XZY"){const u=r*l,f=r*c,g=o*l,y=o*c;t[0]=l*d,t[4]=-h,t[8]=c*d,t[1]=u*h+y,t[5]=r*d,t[9]=f*h-g,t[2]=g*h-f,t[6]=o*d,t[10]=y*h+u}return t[3]=0,t[7]=0,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromQuaternion(e){return this.compose(m0,e,g0)}lookAt(e,t,n){const s=this.elements;return Tn.subVectors(e,t),Tn.lengthSq()===0&&(Tn.z=1),Tn.normalize(),zi.crossVectors(n,Tn),zi.lengthSq()===0&&(Math.abs(n.z)===1?Tn.x+=1e-4:Tn.z+=1e-4,Tn.normalize(),zi.crossVectors(n,Tn)),zi.normalize(),lr.crossVectors(Tn,zi),s[0]=zi.x,s[4]=lr.x,s[8]=Tn.x,s[1]=zi.y,s[5]=lr.y,s[9]=Tn.y,s[2]=zi.z,s[6]=lr.z,s[10]=Tn.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const n=e.elements,s=t.elements,a=this.elements,r=n[0],o=n[4],l=n[8],c=n[12],d=n[1],h=n[5],u=n[9],f=n[13],g=n[2],y=n[6],m=n[10],p=n[14],x=n[3],A=n[7],b=n[11],E=n[15],S=s[0],v=s[4],w=s[8],P=s[12],R=s[1],N=s[5],F=s[9],G=s[13],L=s[2],z=s[6],X=s[10],$=s[14],te=s[3],V=s[7],ee=s[11],ne=s[15];return a[0]=r*S+o*R+l*L+c*te,a[4]=r*v+o*N+l*z+c*V,a[8]=r*w+o*F+l*X+c*ee,a[12]=r*P+o*G+l*$+c*ne,a[1]=d*S+h*R+u*L+f*te,a[5]=d*v+h*N+u*z+f*V,a[9]=d*w+h*F+u*X+f*ee,a[13]=d*P+h*G+u*$+f*ne,a[2]=g*S+y*R+m*L+p*te,a[6]=g*v+y*N+m*z+p*V,a[10]=g*w+y*F+m*X+p*ee,a[14]=g*P+y*G+m*$+p*ne,a[3]=x*S+A*R+b*L+E*te,a[7]=x*v+A*N+b*z+E*V,a[11]=x*w+A*F+b*X+E*ee,a[15]=x*P+A*G+b*$+E*ne,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[4]*=e,t[8]*=e,t[12]*=e,t[1]*=e,t[5]*=e,t[9]*=e,t[13]*=e,t[2]*=e,t[6]*=e,t[10]*=e,t[14]*=e,t[3]*=e,t[7]*=e,t[11]*=e,t[15]*=e,this}determinant(){const e=this.elements,t=e[0],n=e[4],s=e[8],a=e[12],r=e[1],o=e[5],l=e[9],c=e[13],d=e[2],h=e[6],u=e[10],f=e[14],g=e[3],y=e[7],m=e[11],p=e[15],x=l*f-c*u,A=o*f-c*h,b=o*u-l*h,E=r*f-c*d,S=r*u-l*d,v=r*h-o*d;return t*(y*x-m*A+p*b)-n*(g*x-m*E+p*S)+s*(g*A-y*E+p*v)-a*(g*b-y*S+m*v)}determinantAffine(){const e=this.elements,t=e[0],n=e[4],s=e[8],a=e[1],r=e[5],o=e[9],l=e[2],c=e[6],d=e[10];return t*(r*d-o*c)-n*(a*d-o*l)+s*(a*c-r*l)}transpose(){const e=this.elements;let t;return t=e[1],e[1]=e[4],e[4]=t,t=e[2],e[2]=e[8],e[8]=t,t=e[6],e[6]=e[9],e[9]=t,t=e[3],e[3]=e[12],e[12]=t,t=e[7],e[7]=e[13],e[13]=t,t=e[11],e[11]=e[14],e[14]=t,this}setPosition(e,t,n){const s=this.elements;return e.isVector3?(s[12]=e.x,s[13]=e.y,s[14]=e.z):(s[12]=e,s[13]=t,s[14]=n),this}invert(){const e=this.elements,t=e[0],n=e[1],s=e[2],a=e[3],r=e[4],o=e[5],l=e[6],c=e[7],d=e[8],h=e[9],u=e[10],f=e[11],g=e[12],y=e[13],m=e[14],p=e[15],x=t*o-n*r,A=t*l-s*r,b=t*c-a*r,E=n*l-s*o,S=n*c-a*o,v=s*c-a*l,w=d*y-h*g,P=d*m-u*g,R=d*p-f*g,N=h*m-u*y,F=h*p-f*y,G=u*p-f*m,L=x*G-A*F+b*N+E*R-S*P+v*w;if(L===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const z=1/L;return e[0]=(o*G-l*F+c*N)*z,e[1]=(s*F-n*G-a*N)*z,e[2]=(y*v-m*S+p*E)*z,e[3]=(u*S-h*v-f*E)*z,e[4]=(l*R-r*G-c*P)*z,e[5]=(t*G-s*R+a*P)*z,e[6]=(m*b-g*v-p*A)*z,e[7]=(d*v-u*b+f*A)*z,e[8]=(r*F-o*R+c*w)*z,e[9]=(n*R-t*F-a*w)*z,e[10]=(g*S-y*b+p*x)*z,e[11]=(h*b-d*S-f*x)*z,e[12]=(o*P-r*N-l*w)*z,e[13]=(t*N-n*P+s*w)*z,e[14]=(y*A-g*E-m*x)*z,e[15]=(d*E-h*A+u*x)*z,this}scale(e){const t=this.elements,n=e.x,s=e.y,a=e.z;return t[0]*=n,t[4]*=s,t[8]*=a,t[1]*=n,t[5]*=s,t[9]*=a,t[2]*=n,t[6]*=s,t[10]*=a,t[3]*=n,t[7]*=s,t[11]*=a,this}getMaxScaleOnAxis(){const e=this.elements,t=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],n=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],s=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(t,n,s))}makeTranslation(e,t,n){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,t,0,0,1,n,0,0,0,1),this}makeRotationX(e){const t=Math.cos(e),n=Math.sin(e);return this.set(1,0,0,0,0,t,-n,0,0,n,t,0,0,0,0,1),this}makeRotationY(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,0,n,0,0,1,0,0,-n,0,t,0,0,0,0,1),this}makeRotationZ(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,0,n,t,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,t){const n=Math.cos(t),s=Math.sin(t),a=1-n,r=e.x,o=e.y,l=e.z,c=a*r,d=a*o;return this.set(c*r+n,c*o-s*l,c*l+s*o,0,c*o+s*l,d*o+n,d*l-s*r,0,c*l-s*o,d*l+s*r,a*l*l+n,0,0,0,0,1),this}makeScale(e,t,n){return this.set(e,0,0,0,0,t,0,0,0,0,n,0,0,0,0,1),this}makeShear(e,t,n,s,a,r){return this.set(1,n,a,0,e,1,r,0,t,s,1,0,0,0,0,1),this}compose(e,t,n){const s=this.elements,a=t._x,r=t._y,o=t._z,l=t._w,c=a+a,d=r+r,h=o+o,u=a*c,f=a*d,g=a*h,y=r*d,m=r*h,p=o*h,x=l*c,A=l*d,b=l*h,E=n.x,S=n.y,v=n.z;return s[0]=(1-(y+p))*E,s[1]=(f+b)*E,s[2]=(g-A)*E,s[3]=0,s[4]=(f-b)*S,s[5]=(1-(u+p))*S,s[6]=(m+x)*S,s[7]=0,s[8]=(g+A)*v,s[9]=(m-x)*v,s[10]=(1-(u+y))*v,s[11]=0,s[12]=e.x,s[13]=e.y,s[14]=e.z,s[15]=1,this}decompose(e,t,n){const s=this.elements;e.x=s[12],e.y=s[13],e.z=s[14];const a=this.determinantAffine();if(a===0)return n.set(1,1,1),t.identity(),this;let r=Cs.set(s[0],s[1],s[2]).length();const o=Cs.set(s[4],s[5],s[6]).length(),l=Cs.set(s[8],s[9],s[10]).length();a<0&&(r=-r),Zn.copy(this);const c=1/r,d=1/o,h=1/l;return Zn.elements[0]*=c,Zn.elements[1]*=c,Zn.elements[2]*=c,Zn.elements[4]*=d,Zn.elements[5]*=d,Zn.elements[6]*=d,Zn.elements[8]*=h,Zn.elements[9]*=h,Zn.elements[10]*=h,t.setFromRotationMatrix(Zn),n.x=r,n.y=o,n.z=l,this}makePerspective(e,t,n,s,a,r,o=si,l=!1){const c=this.elements,d=2*a/(t-e),h=2*a/(n-s),u=(t+e)/(t-e),f=(n+s)/(n-s);let g,y;if(l)g=a/(r-a),y=r*a/(r-a);else if(o===si)g=-(r+a)/(r-a),y=-2*r*a/(r-a);else if(o===Va)g=-r/(r-a),y=-r*a/(r-a);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+o);return c[0]=d,c[4]=0,c[8]=u,c[12]=0,c[1]=0,c[5]=h,c[9]=f,c[13]=0,c[2]=0,c[6]=0,c[10]=g,c[14]=y,c[3]=0,c[7]=0,c[11]=-1,c[15]=0,this}makeOrthographic(e,t,n,s,a,r,o=si,l=!1){const c=this.elements,d=2/(t-e),h=2/(n-s),u=-(t+e)/(t-e),f=-(n+s)/(n-s);let g,y;if(l)g=1/(r-a),y=r/(r-a);else if(o===si)g=-2/(r-a),y=-(r+a)/(r-a);else if(o===Va)g=-1/(r-a),y=-a/(r-a);else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+o);return c[0]=d,c[4]=0,c[8]=0,c[12]=u,c[1]=0,c[5]=h,c[9]=0,c[13]=f,c[2]=0,c[6]=0,c[10]=g,c[14]=y,c[3]=0,c[7]=0,c[11]=0,c[15]=1,this}equals(e){const t=this.elements,n=e.elements;for(let s=0;s<16;s++)if(t[s]!==n[s])return!1;return!0}fromArray(e,t=0){for(let n=0;n<16;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){const n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e[t+9]=n[9],e[t+10]=n[10],e[t+11]=n[11],e[t+12]=n[12],e[t+13]=n[13],e[t+14]=n[14],e[t+15]=n[15],e}};Lo.prototype.isMatrix4=!0;let tt=Lo;const Cs=new D,Zn=new tt,m0=new D(0,0,0),g0=new D(1,1,1),zi=new D,lr=new D,Tn=new D,ch=new tt,dh=new Ui;class Wn{constructor(e=0,t=0,n=0,s=Wn.DEFAULT_ORDER){this.isEuler=!0,this._x=e,this._y=t,this._z=n,this._order=s}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,t,n,s=this._order){return this._x=e,this._y=t,this._z=n,this._order=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,t=this._order,n=!0){const s=e.elements,a=s[0],r=s[4],o=s[8],l=s[1],c=s[5],d=s[9],h=s[2],u=s[6],f=s[10];switch(t){case"XYZ":this._y=Math.asin(je(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(-d,f),this._z=Math.atan2(-r,a)):(this._x=Math.atan2(u,c),this._z=0);break;case"YXZ":this._x=Math.asin(-je(d,-1,1)),Math.abs(d)<.9999999?(this._y=Math.atan2(o,f),this._z=Math.atan2(l,c)):(this._y=Math.atan2(-h,a),this._z=0);break;case"ZXY":this._x=Math.asin(je(u,-1,1)),Math.abs(u)<.9999999?(this._y=Math.atan2(-h,f),this._z=Math.atan2(-r,c)):(this._y=0,this._z=Math.atan2(l,a));break;case"ZYX":this._y=Math.asin(-je(h,-1,1)),Math.abs(h)<.9999999?(this._x=Math.atan2(u,f),this._z=Math.atan2(l,a)):(this._x=0,this._z=Math.atan2(-r,c));break;case"YZX":this._z=Math.asin(je(l,-1,1)),Math.abs(l)<.9999999?(this._x=Math.atan2(-d,c),this._y=Math.atan2(-h,a)):(this._x=0,this._y=Math.atan2(o,f));break;case"XZY":this._z=Math.asin(-je(r,-1,1)),Math.abs(r)<.9999999?(this._x=Math.atan2(u,c),this._y=Math.atan2(o,a)):(this._x=Math.atan2(-d,f),this._y=0);break;default:Ue("Euler: .setFromRotationMatrix() encountered an unknown order: "+t)}return this._order=t,n===!0&&this._onChangeCallback(),this}setFromQuaternion(e,t,n){return ch.makeRotationFromQuaternion(e),this.setFromRotationMatrix(ch,t,n)}setFromVector3(e,t=this._order){return this.set(e.x,e.y,e.z,t)}reorder(e){return dh.setFromEuler(this),this.setFromQuaternion(dh,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}Wn.DEFAULT_ORDER="XYZ";class Sd{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return(this.mask&(1<<e|0))!==0}}let v0=0;const hh=new D,Ps=new Ui,yi=new tt,cr=new D,fa=new D,y0=new D,x0=new Ui,uh=new D(1,0,0),fh=new D(0,1,0),ph=new D(0,0,1),mh={type:"added"},b0={type:"removed"},Ls={type:"childadded",child:null},xl={type:"childremoved",child:null};class Ut extends Ss{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:v0++}),this.uuid=ss(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=Ut.DEFAULT_UP.clone();const e=new D,t=new Wn,n=new Ui,s=new D(1,1,1);function a(){n.setFromEuler(t,!1)}function r(){t.setFromQuaternion(n,void 0,!1)}t._onChange(a),n._onChange(r),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:e},rotation:{configurable:!0,enumerable:!0,value:t},quaternion:{configurable:!0,enumerable:!0,value:n},scale:{configurable:!0,enumerable:!0,value:s},modelViewMatrix:{value:new tt},normalMatrix:{value:new ke}}),this.matrix=new tt,this.matrixWorld=new tt,this.matrixAutoUpdate=Ut.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=Ut.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new Sd,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.static=!1,this.userData={},this.pivot=null}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale),this.pivot!==null&&this.position.copy(this.pivot).applyMatrix4(this.matrix).sub(this.pivot)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,t){this.quaternion.setFromAxisAngle(e,t)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,t){return Ps.setFromAxisAngle(e,t),this.quaternion.multiply(Ps),this}rotateOnWorldAxis(e,t){return Ps.setFromAxisAngle(e,t),this.quaternion.premultiply(Ps),this}rotateX(e){return this.rotateOnAxis(uh,e)}rotateY(e){return this.rotateOnAxis(fh,e)}rotateZ(e){return this.rotateOnAxis(ph,e)}translateOnAxis(e,t){return hh.copy(e).applyQuaternion(this.quaternion),this.position.add(hh.multiplyScalar(t)),this}translateX(e){return this.translateOnAxis(uh,e)}translateY(e){return this.translateOnAxis(fh,e)}translateZ(e){return this.translateOnAxis(ph,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(yi.copy(this.matrixWorld).invert())}lookAt(e,t,n){e.isVector3?cr.copy(e):cr.set(e,t,n);const s=this.parent;this.updateWorldMatrix(!0,!1),fa.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?yi.lookAt(fa,cr,this.up):yi.lookAt(cr,fa,this.up),this.quaternion.setFromRotationMatrix(yi),s&&(yi.extractRotation(s.matrixWorld),Ps.setFromRotationMatrix(yi),this.quaternion.premultiply(Ps.invert()))}add(e){if(arguments.length>1){for(let t=0;t<arguments.length;t++)this.add(arguments[t]);return this}return e===this?(it("Object3D.add: object can't be added as a child of itself.",e),this):(e&&e.isObject3D?(e.removeFromParent(),e.parent=this,this.children.push(e),e.dispatchEvent(mh),Ls.child=e,this.dispatchEvent(Ls),Ls.child=null):it("Object3D.add: object not an instance of THREE.Object3D.",e),this)}remove(e){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.remove(arguments[n]);return this}const t=this.children.indexOf(e);return t!==-1&&(e.parent=null,this.children.splice(t,1),e.dispatchEvent(b0),xl.child=e,this.dispatchEvent(xl),xl.child=null),this}removeFromParent(){const e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),yi.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),yi.multiply(e.parent.matrixWorld)),e.applyMatrix4(yi),e.removeFromParent(),e.parent=this,this.children.push(e),e.updateWorldMatrix(!1,!0),e.dispatchEvent(mh),Ls.child=e,this.dispatchEvent(Ls),Ls.child=null,this}getObjectById(e){return this.getObjectByProperty("id",e)}getObjectByName(e){return this.getObjectByProperty("name",e)}getObjectByProperty(e,t){if(this[e]===t)return this;for(let n=0,s=this.children.length;n<s;n++){const r=this.children[n].getObjectByProperty(e,t);if(r!==void 0)return r}}getObjectsByProperty(e,t,n=[]){this[e]===t&&n.push(this);const s=this.children;for(let a=0,r=s.length;a<r;a++)s[a].getObjectsByProperty(e,t,n);return n}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(fa,e,y0),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(fa,x0,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);const t=this.matrixWorld.elements;return e.set(t[8],t[9],t[10]).normalize()}raycast(){}intersectsFrustum(){return!0}traverse(e){e(this);const t=this.children;for(let n=0,s=t.length;n<s;n++)t[n].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);const t=this.children;for(let n=0,s=t.length;n<s;n++)t[n].traverseVisible(e)}traverseAncestors(e){const t=this.parent;t!==null&&(e(t),t.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale);const e=this.pivot;if(e!==null){const t=e.x,n=e.y,s=e.z,a=this.matrix.elements;a[12]+=t-a[0]*t-a[4]*n-a[8]*s,a[13]+=n-a[1]*t-a[5]*n-a[9]*s,a[14]+=s-a[2]*t-a[6]*n-a[10]*s}this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,e=!0);const t=this.children;for(let n=0,s=t.length;n<s;n++)t[n].updateMatrixWorld(e)}updateWorldMatrix(e,t,n=!1){const s=this.parent;if(e===!0&&s!==null&&s.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||n)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,n=!0),t===!0){const a=this.children;for(let r=0,o=a.length;r<o;r++)a[r].updateWorldMatrix(!1,!0,n)}}toJSON(e){const t=e===void 0||typeof e=="string",n={};t&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.7,type:"Object",generator:"Object3D.toJSON"});const s={};s.uuid=this.uuid,s.type=this.type,s.name=this.name,s.castShadow=this.castShadow,s.receiveShadow=this.receiveShadow,s.visible=this.visible,s.frustumCulled=this.frustumCulled,s.renderOrder=this.renderOrder,s.static=this.static,s.matrixAutoUpdate=this.matrixAutoUpdate,Object.keys(this.userData).length>0&&(s.userData=this.userData),s.layers=this.layers.mask,s.matrix=this.matrix.toArray(),s.up=this.up.toArray(),this.pivot!==null&&(s.pivot=this.pivot.toArray()),this.morphTargetDictionary!==void 0&&(s.morphTargetDictionary=Object.assign({},this.morphTargetDictionary)),this.morphTargetInfluences!==void 0&&(s.morphTargetInfluences=this.morphTargetInfluences.slice()),this.isInstancedMesh&&(s.type="InstancedMesh",s.count=this.count,s.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(s.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(s.type="BatchedMesh",s.perObjectFrustumCulled=this.perObjectFrustumCulled,s.sortObjects=this.sortObjects,s.drawRanges=this._drawRanges,s.reservedRanges=this._reservedRanges,s.geometryInfo=this._geometryInfo.map(o=>({...o,boundingBox:o.boundingBox?o.boundingBox.toJSON():void 0,boundingSphere:o.boundingSphere?o.boundingSphere.toJSON():void 0})),s.instanceInfo=this._instanceInfo.map(o=>({...o})),s.availableInstanceIds=this._availableInstanceIds.slice(),s.availableGeometryIds=this._availableGeometryIds.slice(),s.nextIndexStart=this._nextIndexStart,s.nextVertexStart=this._nextVertexStart,s.geometryCount=this._geometryCount,s.maxInstanceCount=this._maxInstanceCount,s.maxVertexCount=this._maxVertexCount,s.maxIndexCount=this._maxIndexCount,s.geometryInitialized=this._geometryInitialized,s.matricesTexture=this._matricesTexture.toJSON(e),s.indirectTexture=this._indirectTexture.toJSON(e),this._colorsTexture!==null&&(s.colorsTexture=this._colorsTexture.toJSON(e)),this.boundingSphere!==null&&(s.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(s.boundingBox=this.boundingBox.toJSON()));function a(o,l){return o[l.uuid]===void 0&&(o[l.uuid]=l.toJSON(e)),l.uuid}if(this.isScene)this.background&&(this.background.isColor?s.background=this.background.toJSON():this.background.isTexture&&(s.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(s.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){s.geometry=a(e.geometries,this.geometry);const o=this.geometry.parameters;if(o!==void 0&&o.shapes!==void 0){const l=o.shapes;if(Array.isArray(l))for(let c=0,d=l.length;c<d;c++){const h=l[c];a(e.shapes,h)}else a(e.shapes,l)}}if(this.isSkinnedMesh&&(s.bindMode=this.bindMode,s.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(a(e.skeletons,this.skeleton),s.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const o=[];for(let l=0,c=this.material.length;l<c;l++)o.push(a(e.materials,this.material[l]));s.material=o}else s.material=a(e.materials,this.material);if(this.children.length>0){s.children=[];for(let o=0;o<this.children.length;o++)s.children.push(this.children[o].toJSON(e).object)}if(this.animations.length>0){s.animations=[];for(let o=0;o<this.animations.length;o++){const l=this.animations[o];s.animations.push(a(e.animations,l))}}if(t){const o=r(e.geometries),l=r(e.materials),c=r(e.textures),d=r(e.images),h=r(e.shapes),u=r(e.skeletons),f=r(e.animations),g=r(e.nodes);o.length>0&&(n.geometries=o),l.length>0&&(n.materials=l),c.length>0&&(n.textures=c),d.length>0&&(n.images=d),h.length>0&&(n.shapes=h),u.length>0&&(n.skeletons=u),f.length>0&&(n.animations=f),g.length>0&&(n.nodes=g)}return n.object=s,n;function r(o){const l=[];for(const c in o){const d=o[c];delete d.metadata,l.push(d)}return l}}clone(e){return new this.constructor().copy(this,e)}copy(e,t=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.pivot=e.pivot!==null?e.pivot.clone():null,this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.static=e.static,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),t===!0)for(let n=0;n<e.children.length;n++){const s=e.children[n];this.add(s.clone())}return this}dispose(){this.dispatchEvent({type:"dispose"})}}Ut.DEFAULT_UP=new D(0,1,0);Ut.DEFAULT_MATRIX_AUTO_UPDATE=!0;Ut.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;class _t extends Ut{constructor(){super(),this.isGroup=!0,this.type="Group"}}const _0={type:"move"};class bl{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new _t,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new _t,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new D,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new D),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new _t,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new D,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new D,this._grip.eventsEnabled=!1),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){const t=this._hand;if(t)for(const n of e.hand.values())this._getHandJoint(t,n)}return this.dispatchEvent({type:"connected",data:e}),this}disconnect(e){return this.dispatchEvent({type:"disconnected",data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,t,n){let s=null,a=null,r=null;const o=this._targetRay,l=this._grip,c=this._hand;if(e&&t.session.visibilityState!=="visible-blurred"){if(c&&e.hand){r=!0;for(const y of e.hand.values()){const m=t.getJointPose(y,n),p=this._getHandJoint(c,y);m!==null&&(p.matrix.fromArray(m.transform.matrix),p.matrix.decompose(p.position,p.quaternion,p.scale),p.matrixWorldNeedsUpdate=!0,p.jointRadius=m.radius),p.visible=m!==null}const d=c.joints["index-finger-tip"],h=c.joints["thumb-tip"],u=d.position.distanceTo(h.position),f=.02,g=.005;c.inputState.pinching&&u>f+g?(c.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:e.handedness,target:this})):!c.inputState.pinching&&u<=f-g&&(c.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:e.handedness,target:this}))}else l!==null&&e.gripSpace&&(a=t.getPose(e.gripSpace,n),a!==null&&(l.matrix.fromArray(a.transform.matrix),l.matrix.decompose(l.position,l.quaternion,l.scale),l.matrixWorldNeedsUpdate=!0,a.linearVelocity?(l.hasLinearVelocity=!0,l.linearVelocity.copy(a.linearVelocity)):l.hasLinearVelocity=!1,a.angularVelocity?(l.hasAngularVelocity=!0,l.angularVelocity.copy(a.angularVelocity)):l.hasAngularVelocity=!1,l.eventsEnabled&&l.dispatchEvent({type:"gripUpdated",data:e,target:this})));o!==null&&(s=t.getPose(e.targetRaySpace,n),s===null&&a!==null&&(s=a),s!==null&&(o.matrix.fromArray(s.transform.matrix),o.matrix.decompose(o.position,o.quaternion,o.scale),o.matrixWorldNeedsUpdate=!0,s.linearVelocity?(o.hasLinearVelocity=!0,o.linearVelocity.copy(s.linearVelocity)):o.hasLinearVelocity=!1,s.angularVelocity?(o.hasAngularVelocity=!0,o.angularVelocity.copy(s.angularVelocity)):o.hasAngularVelocity=!1,this.dispatchEvent(_0)))}return o!==null&&(o.visible=s!==null),l!==null&&(l.visible=a!==null),c!==null&&(c.visible=r!==null),this}_getHandJoint(e,t){if(e.joints[t.jointName]===void 0){const n=new _t;n.matrixAutoUpdate=!1,n.visible=!1,e.joints[t.jointName]=n,e.add(n)}return e.joints[t.jointName]}}const Df={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},$i={h:0,s:0,l:0},dr={h:0,s:0,l:0};function _l(i,e,t){return t<0&&(t+=1),t>1&&(t-=1),t<1/6?i+(e-i)*6*t:t<1/2?e:t<2/3?i+(e-i)*6*(2/3-t):i}class Ce{constructor(e,t,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,t,n)}set(e,t,n){if(t===void 0&&n===void 0){const s=e;s&&s.isColor?this.copy(s):typeof s=="number"?this.setHex(s):typeof s=="string"&&this.setStyle(s)}else this.setRGB(e,t,n);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,t=zt){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,et.colorSpaceToWorking(this,t),this}setRGB(e,t,n,s=et.workingColorSpace){return this.r=e,this.g=t,this.b=n,et.colorSpaceToWorking(this,s),this}setHSL(e,t,n,s=et.workingColorSpace){if(e=bd(e,1),t=je(t,0,1),n=je(n,0,1),t===0)this.r=this.g=this.b=n;else{const a=n<=.5?n*(1+t):n+t-n*t,r=2*n-a;this.r=_l(r,a,e+1/3),this.g=_l(r,a,e),this.b=_l(r,a,e-1/3)}return et.colorSpaceToWorking(this,s),this}setStyle(e,t=zt){function n(a){a!==void 0&&parseFloat(a)<1&&Ue("Color: Alpha component of "+e+" will be ignored.")}let s;if(s=/^(\w+)\(([^\)]*)\)/.exec(e)){let a;const r=s[1],o=s[2];switch(r){case"rgb":case"rgba":if(a=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d+(?:\.\d+)?|\.\d+)\s*)?$/.exec(o))return n(a[4]),this.setRGB(Math.min(255,parseInt(a[1],10))/255,Math.min(255,parseInt(a[2],10))/255,Math.min(255,parseInt(a[3],10))/255,t);if(a=/^\s*(\d+(?:\.\d+)?|\.\d+)\%\s*,\s*(\d+(?:\.\d+)?|\.\d+)\%\s*,\s*(\d+(?:\.\d+)?|\.\d+)\%\s*(?:,\s*(\d+(?:\.\d+)?|\.\d+)\s*)?$/.exec(o))return n(a[4]),this.setRGB(Math.min(100,parseFloat(a[1]))/100,Math.min(100,parseFloat(a[2]))/100,Math.min(100,parseFloat(a[3]))/100,t);break;case"hsl":case"hsla":if(a=/^\s*([+-]?(?:\d+(?:\.\d+)?|\.\d+))\s*,\s*(\d+(?:\.\d+)?|\.\d+)\%\s*,\s*(\d+(?:\.\d+)?|\.\d+)\%\s*(?:,\s*(\d+(?:\.\d+)?|\.\d+)\s*)?$/.exec(o))return n(a[4]),this.setHSL(parseFloat(a[1])/360,parseFloat(a[2])/100,parseFloat(a[3])/100,t);break;default:Ue("Color: Unknown color model "+e)}}else if(s=/^\#([A-Fa-f\d]+)$/.exec(e)){const a=s[1],r=a.length;if(r===3)return this.setRGB(parseInt(a.charAt(0),16)/15,parseInt(a.charAt(1),16)/15,parseInt(a.charAt(2),16)/15,t);if(r===6)return this.setHex(parseInt(a,16),t);Ue("Color: Invalid hex color "+e)}else if(e&&e.length>0)return this.setColorName(e,t);return this}setColorName(e,t=zt){const n=Df[e.toLowerCase()];return n!==void 0?this.setHex(n,t):Ue("Color: Unknown color "+e),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=Ni(e.r),this.g=Ni(e.g),this.b=Ni(e.b),this}copyLinearToSRGB(e){return this.r=Js(e.r),this.g=Js(e.g),this.b=Js(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=zt){return et.workingToColorSpace(dn.copy(this),e),Math.round(je(dn.r*255,0,255))*65536+Math.round(je(dn.g*255,0,255))*256+Math.round(je(dn.b*255,0,255))}getHexString(e=zt){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,t=et.workingColorSpace){et.workingToColorSpace(dn.copy(this),t);const n=dn.r,s=dn.g,a=dn.b,r=Math.max(n,s,a),o=Math.min(n,s,a);let l,c;const d=(o+r)/2;if(o===r)l=0,c=0;else{const h=r-o;switch(c=d<=.5?h/(r+o):h/(2-r-o),r){case n:l=(s-a)/h+(s<a?6:0);break;case s:l=(a-n)/h+2;break;case a:l=(n-s)/h+4;break}l/=6}return e.h=l,e.s=c,e.l=d,e}getRGB(e,t=et.workingColorSpace){return et.workingToColorSpace(dn.copy(this),t),e.r=dn.r,e.g=dn.g,e.b=dn.b,e}getStyle(e=zt){et.workingToColorSpace(dn.copy(this),e);const t=dn.r,n=dn.g,s=dn.b;return e!==zt?`color(${e} ${t.toFixed(3)} ${n.toFixed(3)} ${s.toFixed(3)})`:`rgb(${Math.round(t*255)},${Math.round(n*255)},${Math.round(s*255)})`}offsetHSL(e,t,n){return this.getHSL($i),this.setHSL($i.h+e,$i.s+t,$i.l+n)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,t){return this.r=e.r+t.r,this.g=e.g+t.g,this.b=e.b+t.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,t){return this.r+=(e.r-this.r)*t,this.g+=(e.g-this.g)*t,this.b+=(e.b-this.b)*t,this}lerpColors(e,t,n){return this.r=e.r+(t.r-e.r)*n,this.g=e.g+(t.g-e.g)*n,this.b=e.b+(t.b-e.b)*n,this}lerpHSL(e,t){this.getHSL($i),e.getHSL(dr);const n=Fa($i.h,dr.h,t),s=Fa($i.s,dr.s,t),a=Fa($i.l,dr.l,t);return this.setHSL(n,s,a),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){const t=this.r,n=this.g,s=this.b,a=e.elements;return this.r=a[0]*t+a[3]*n+a[6]*s,this.g=a[1]*t+a[4]*n+a[7]*s,this.b=a[2]*t+a[5]*n+a[8]*s,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,t=0){return this.r=e[t],this.g=e[t+1],this.b=e[t+2],this}toArray(e=[],t=0){return e[t]=this.r,e[t+1]=this.g,e[t+2]=this.b,e}fromBufferAttribute(e,t){return this.r=e.getX(t),this.g=e.getY(t),this.b=e.getZ(t),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const dn=new Ce;Ce.NAMES=Df;class Wo extends Ut{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new Wn,this.environmentIntensity=1,this.environmentRotation=new Wn,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(e,t){return super.copy(e,t),this.background=e.background!==null?e.background.clone():null,this.environment=e.environment!==null?e.environment.clone():null,this.fog=e.fog!==null?e.fog.clone():null,this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,this.backgroundRotation.copy(e.backgroundRotation),this.environmentIntensity=e.environmentIntensity,this.environmentRotation.copy(e.environmentRotation),this.overrideMaterial=e.overrideMaterial!==null?e.overrideMaterial.clone():null,this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){const t=super.toJSON(e);return this.fog!==null&&(t.object.fog=this.fog.toJSON()),t.object.backgroundBlurriness=this.backgroundBlurriness,t.object.backgroundIntensity=this.backgroundIntensity,t.object.backgroundRotation=this.backgroundRotation.toArray(),t.object.environmentIntensity=this.environmentIntensity,t.object.environmentRotation=this.environmentRotation.toArray(),t}}const Jn=new D,xi=new D,Ml=new D,bi=new D,Ds=new D,Is=new D,gh=new D,wl=new D,Sl=new D,El=new D,Al=new Tt,Tl=new Tt,Rl=new Tt;class Cn{constructor(e=new D,t=new D,n=new D){this.a=e,this.b=t,this.c=n}static getNormal(e,t,n,s){s.subVectors(n,t),Jn.subVectors(e,t),s.cross(Jn);const a=s.lengthSq();return a>0?s.multiplyScalar(1/Math.sqrt(a)):s.set(0,0,0)}static getBarycoord(e,t,n,s,a){Jn.subVectors(s,t),xi.subVectors(n,t),Ml.subVectors(e,t);const r=Jn.dot(Jn),o=Jn.dot(xi),l=Jn.dot(Ml),c=xi.dot(xi),d=xi.dot(Ml),h=r*c-o*o;if(h===0)return a.set(0,0,0),null;const u=1/h,f=(c*l-o*d)*u,g=(r*d-o*l)*u;return a.set(1-f-g,g,f)}static containsPoint(e,t,n,s){return this.getBarycoord(e,t,n,s,bi)===null?!1:bi.x>=0&&bi.y>=0&&bi.x+bi.y<=1}static getInterpolation(e,t,n,s,a,r,o,l){return this.getBarycoord(e,t,n,s,bi)===null?(l.x=0,l.y=0,"z"in l&&(l.z=0),"w"in l&&(l.w=0),null):(l.setScalar(0),l.addScaledVector(a,bi.x),l.addScaledVector(r,bi.y),l.addScaledVector(o,bi.z),l)}static getInterpolatedAttribute(e,t,n,s,a,r){return Al.setScalar(0),Tl.setScalar(0),Rl.setScalar(0),Al.fromBufferAttribute(e,t),Tl.fromBufferAttribute(e,n),Rl.fromBufferAttribute(e,s),r.setScalar(0),r.addScaledVector(Al,a.x),r.addScaledVector(Tl,a.y),r.addScaledVector(Rl,a.z),r}static isFrontFacing(e,t,n,s){return Jn.subVectors(n,t),xi.subVectors(e,t),Jn.cross(xi).dot(s)<0}set(e,t,n){return this.a.copy(e),this.b.copy(t),this.c.copy(n),this}setFromPointsAndIndices(e,t,n,s){return this.a.copy(e[t]),this.b.copy(e[n]),this.c.copy(e[s]),this}setFromAttributeAndIndices(e,t,n,s){return this.a.fromBufferAttribute(e,t),this.b.fromBufferAttribute(e,n),this.c.fromBufferAttribute(e,s),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return Jn.subVectors(this.c,this.b),xi.subVectors(this.a,this.b),Jn.cross(xi).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(e){return Cn.getNormal(this.a,this.b,this.c,e)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(e,t){return Cn.getBarycoord(e,this.a,this.b,this.c,t)}getInterpolation(e,t,n,s,a){return Cn.getInterpolation(e,this.a,this.b,this.c,t,n,s,a)}containsPoint(e){return Cn.containsPoint(e,this.a,this.b,this.c)}isFrontFacing(e){return Cn.isFrontFacing(this.a,this.b,this.c,e)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,t){const n=this.a,s=this.b,a=this.c;let r,o;Ds.subVectors(s,n),Is.subVectors(a,n),wl.subVectors(e,n);const l=Ds.dot(wl),c=Is.dot(wl);if(l<=0&&c<=0)return t.copy(n);Sl.subVectors(e,s);const d=Ds.dot(Sl),h=Is.dot(Sl);if(d>=0&&h<=d)return t.copy(s);const u=l*h-d*c;if(u<=0&&l>=0&&d<=0&&l-d>0)return r=l/(l-d),t.copy(n).addScaledVector(Ds,r);El.subVectors(e,a);const f=Ds.dot(El),g=Is.dot(El);if(g>=0&&f<=g)return t.copy(a);const y=f*c-l*g;if(y<=0&&c>=0&&g<=0)return o=c/(c-g),t.copy(n).addScaledVector(Is,o);const m=d*g-f*h;if(m<=0&&h-d>=0&&f-g>=0)return gh.subVectors(a,s),o=(h-d)/(h-d+(f-g)),t.copy(s).addScaledVector(gh,o);const p=1/(m+y+u);return r=y*p,o=u*p,t.copy(n).addScaledVector(Ds,r).addScaledVector(Is,o)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}}class Es{constructor(e=new D(1/0,1/0,1/0),t=new D(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromArray(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t+=3)this.expandByPoint(jn.fromArray(e,t));return this}setFromBufferAttribute(e){this.makeEmpty();for(let t=0,n=e.count;t<n;t++)this.expandByPoint(jn.fromBufferAttribute(e,t));return this}setFromPoints(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){const n=jn.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(n),this.max.copy(e).add(n),this}setFromObject(e,t=!1){return this.makeEmpty(),this.expandByObject(e,t)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,t=!1){e.updateWorldMatrix(!1,!1);const n=e.geometry;if(n!==void 0){const a=n.getAttribute("position");if(t===!0&&a!==void 0&&e.isInstancedMesh!==!0&&e.isBatchedMesh!==!0)for(let r=0,o=a.count;r<o;r++)e.isMesh===!0?e.getVertexPosition(r,jn):jn.fromBufferAttribute(a,r),jn.applyMatrix4(e.matrixWorld),this.expandByPoint(jn);else e.boundingBox!==void 0?(e.boundingBox===null&&e.computeBoundingBox(),hr.copy(e.boundingBox)):(n.boundingBox===null&&n.computeBoundingBox(),hr.copy(n.boundingBox)),hr.applyMatrix4(e.matrixWorld),this.union(hr)}const s=e.children;for(let a=0,r=s.length;a<r;a++)this.expandByObject(s[a],t);return this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y&&e.z>=this.min.z&&e.z<=this.max.z}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y&&e.max.z>=this.min.z&&e.min.z<=this.max.z}intersectsSphere(e){return this.clampPoint(e.center,jn),jn.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let t,n;return e.normal.x>0?(t=e.normal.x*this.min.x,n=e.normal.x*this.max.x):(t=e.normal.x*this.max.x,n=e.normal.x*this.min.x),e.normal.y>0?(t+=e.normal.y*this.min.y,n+=e.normal.y*this.max.y):(t+=e.normal.y*this.max.y,n+=e.normal.y*this.min.y),e.normal.z>0?(t+=e.normal.z*this.min.z,n+=e.normal.z*this.max.z):(t+=e.normal.z*this.max.z,n+=e.normal.z*this.min.z),t<=-e.constant&&n>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(pa),ur.subVectors(this.max,pa),Ns.subVectors(e.a,pa),Us.subVectors(e.b,pa),Fs.subVectors(e.c,pa),Hi.subVectors(Us,Ns),Gi.subVectors(Fs,Us),cs.subVectors(Ns,Fs);let t=[0,-Hi.z,Hi.y,0,-Gi.z,Gi.y,0,-cs.z,cs.y,Hi.z,0,-Hi.x,Gi.z,0,-Gi.x,cs.z,0,-cs.x,-Hi.y,Hi.x,0,-Gi.y,Gi.x,0,-cs.y,cs.x,0];return!Cl(t,Ns,Us,Fs,ur)||(t=[1,0,0,0,1,0,0,0,1],!Cl(t,Ns,Us,Fs,ur))?!1:(fr.crossVectors(Hi,Gi),t=[fr.x,fr.y,fr.z],Cl(t,Ns,Us,Fs,ur))}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,jn).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize(jn).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()?this:(_i[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),_i[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),_i[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),_i[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),_i[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),_i[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),_i[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),_i[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(_i),this)}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(e){return this.min.fromArray(e.min),this.max.fromArray(e.max),this}}const _i=[new D,new D,new D,new D,new D,new D,new D,new D],jn=new D,hr=new Es,Ns=new D,Us=new D,Fs=new D,Hi=new D,Gi=new D,cs=new D,pa=new D,ur=new D,fr=new D,ds=new D;function Cl(i,e,t,n,s){for(let a=0,r=i.length-3;a<=r;a+=3){ds.fromArray(i,a);const o=s.x*Math.abs(ds.x)+s.y*Math.abs(ds.y)+s.z*Math.abs(ds.z),l=e.dot(ds),c=t.dot(ds),d=n.dot(ds);if(Math.max(-Math.max(l,c,d),Math.min(l,c,d))>o)return!1}return!0}const It=new D,pr=new Ie;let M0=0;class Ft extends Ss{constructor(e,t,n=!1){if(super(),Array.isArray(e))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:M0++}),this.name="",this.array=e,this.itemSize=t,this.count=e!==void 0?e.length/t:0,this.normalized=n,this.usage=Rf,this.updateRanges=[],this.gpuType=ii,this.version=0,this._normalizationScale=e!==void 0?Vo(e):void 0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this._normalizationScale=e._normalizationScale,this}copyAt(e,t,n){e*=this.itemSize,n*=t.itemSize;for(let s=0,a=this.itemSize;s<a;s++)this.array[e+s]=t.array[n+s];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let t=0,n=this.count;t<n;t++)pr.fromBufferAttribute(this,t),pr.applyMatrix3(e),this.setXY(t,pr.x,pr.y);else if(this.itemSize===3)for(let t=0,n=this.count;t<n;t++)It.fromBufferAttribute(this,t),It.applyMatrix3(e),this.setXYZ(t,It.x,It.y,It.z);return this}applyMatrix4(e){for(let t=0,n=this.count;t<n;t++)It.fromBufferAttribute(this,t),It.applyMatrix4(e),this.setXYZ(t,It.x,It.y,It.z);return this}applyNormalMatrix(e){for(let t=0,n=this.count;t<n;t++)It.fromBufferAttribute(this,t),It.applyNormalMatrix(e),this.setXYZ(t,It.x,It.y,It.z);return this}transformDirection(e){for(let t=0,n=this.count;t<n;t++)It.fromBufferAttribute(this,t),It.transformDirection(e),this.setXYZ(t,It.x,It.y,It.z);return this}set(e,t=0){return this.array.set(e,t),this}getComponent(e,t){let n=this.array[e*this.itemSize+t];return this.normalized&&(n=this._denormalize(n)),n}setComponent(e,t,n){return this.normalized&&(n=this._normalize(n)),this.array[e*this.itemSize+t]=n,this}getX(e){let t=this.array[e*this.itemSize];return this.normalized&&(t=this._denormalize(t)),t}setX(e,t){return this.normalized&&(t=this._normalize(t)),this.array[e*this.itemSize]=t,this}getY(e){let t=this.array[e*this.itemSize+1];return this.normalized&&(t=this._denormalize(t)),t}setY(e,t){return this.normalized&&(t=this._normalize(t)),this.array[e*this.itemSize+1]=t,this}getZ(e){let t=this.array[e*this.itemSize+2];return this.normalized&&(t=this._denormalize(t)),t}setZ(e,t){return this.normalized&&(t=this._normalize(t)),this.array[e*this.itemSize+2]=t,this}getW(e){let t=this.array[e*this.itemSize+3];return this.normalized&&(t=this._denormalize(t)),t}setW(e,t){return this.normalized&&(t=this._normalize(t)),this.array[e*this.itemSize+3]=t,this}setXY(e,t,n){return e*=this.itemSize,this.normalized&&(t=this._normalize(t),n=this._normalize(n)),this.array[e+0]=t,this.array[e+1]=n,this}setXYZ(e,t,n,s){return e*=this.itemSize,this.normalized&&(t=this._normalize(t),n=this._normalize(n),s=this._normalize(s)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=s,this}setXYZW(e,t,n,s,a){return e*=this.itemSize,this.normalized&&(t=this._normalize(t),n=this._normalize(n),s=this._normalize(s),a=this._normalize(a)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=s,this.array[e+3]=a,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return e.name=this.name,e.usage=this.usage,e.gpuType=this.gpuType,e}dispose(){this.dispatchEvent({type:"dispose"})}_denormalize(e){const t=this._normalizationScale;return t!==void 0?Math.max(e/t,-1):_d(e,this.array)}_normalize(e){const t=this._normalizationScale;return t!==void 0?Math.round(e*t):Md(e,this.array)}}class If extends Ft{constructor(e,t,n){super(new Uint16Array(e),t,n)}}class Nf extends Ft{constructor(e,t,n){super(new Uint32Array(e),t,n)}}class st extends Ft{constructor(e,t,n){super(new Float32Array(e),t,n)}}const w0=new Es,ma=new D,Pl=new D;class As{constructor(e=new D,t=-1){this.isSphere=!0,this.center=e,this.radius=t}set(e,t){return this.center.copy(e),this.radius=t,this}setFromPoints(e,t){const n=this.center;t!==void 0?n.copy(t):w0.setFromPoints(e).getCenter(n);let s=0;for(let a=0,r=e.length;a<r;a++)s=Math.max(s,n.distanceToSquared(e[a]));return this.radius=Math.sqrt(s),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){const t=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=t*t}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,t){const n=this.center.distanceToSquared(e);return t.copy(e),n>this.radius*this.radius&&(t.sub(this.center).normalize(),t.multiplyScalar(this.radius).add(this.center)),t}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;ma.subVectors(e,this.center);const t=ma.lengthSq();if(t>this.radius*this.radius){const n=Math.sqrt(t),s=(n-this.radius)*.5;this.center.addScaledVector(ma,s/n),this.radius+=s}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(Pl.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(ma.copy(e.center).add(Pl)),this.expandByPoint(ma.copy(e.center).sub(Pl))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(e){return this.radius=e.radius,this.center.fromArray(e.center),this}}let S0=0;const zn=new tt,Ll=new Ut,Os=new D,Rn=new Es,ga=new Es,Yt=new D;class bt extends Ss{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:S0++}),this.uuid=ss(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.indirectOffset=0,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={},this._transformed=!1}getIndex(){return this.index}setIndex(e){return Array.isArray(e)?this.index=new(Vm(e)?Nf:If)(e,1):this.index=e,this}setIndirect(e,t=0){return this.indirect=e,this.indirectOffset=t,this}getIndirect(){return this.indirect}getAttribute(e){return this.attributes[e]}setAttribute(e,t){return this.attributes[e]=t,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,t,n=0){this.groups.push({start:e,count:t,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(e,t){this.drawRange.start=e,this.drawRange.count=t}applyMatrix4(e){const t=this.attributes.position;t!==void 0&&(t.applyMatrix4(e),t.needsUpdate=!0);const n=this.attributes.normal;if(n!==void 0){const a=new ke().getNormalMatrix(e);n.applyNormalMatrix(a),n.needsUpdate=!0}const s=this.attributes.tangent;return s!==void 0&&(s.transformDirection(e),s.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this._transformed=!0,this}applyQuaternion(e){return zn.makeRotationFromQuaternion(e),this.applyMatrix4(zn),this}rotateX(e){return zn.makeRotationX(e),this.applyMatrix4(zn),this}rotateY(e){return zn.makeRotationY(e),this.applyMatrix4(zn),this}rotateZ(e){return zn.makeRotationZ(e),this.applyMatrix4(zn),this}translate(e,t,n){return zn.makeTranslation(e,t,n),this.applyMatrix4(zn),this}scale(e,t,n){return zn.makeScale(e,t,n),this.applyMatrix4(zn),this}lookAt(e){return Ll.lookAt(e),Ll.updateMatrix(),this.applyMatrix4(Ll.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Os).negate(),this.translate(Os.x,Os.y,Os.z),this}setFromPoints(e){const t=this.getAttribute("position");if(t===void 0){const n=[];for(let s=0,a=e.length;s<a;s++){const r=e[s];n.push(r.x,r.y,r.z||0)}this.setAttribute("position",new st(n,3))}else{const n=Math.min(e.length,t.count);for(let s=0;s<n;s++){const a=e[s];t.setXYZ(s,a.x,a.y,a.z||0)}e.length>t.count&&Ue("BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),t.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new Es);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){it("BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new D(-1/0,-1/0,-1/0),new D(1/0,1/0,1/0));return}if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),t)for(let n=0,s=t.length;n<s;n++){const a=t[n];Rn.setFromBufferAttribute(a),this.morphTargetsRelative?(Yt.addVectors(this.boundingBox.min,Rn.min),this.boundingBox.expandByPoint(Yt),Yt.addVectors(this.boundingBox.max,Rn.max),this.boundingBox.expandByPoint(Yt)):(this.boundingBox.expandByPoint(Rn.min),this.boundingBox.expandByPoint(Rn.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&it('BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new As);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){it("BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new D,1/0);return}if(e){const n=this.boundingSphere.center;if(Rn.setFromBufferAttribute(e),t)for(let a=0,r=t.length;a<r;a++){const o=t[a];ga.setFromBufferAttribute(o),this.morphTargetsRelative?(Yt.addVectors(Rn.min,ga.min),Rn.expandByPoint(Yt),Yt.addVectors(Rn.max,ga.max),Rn.expandByPoint(Yt)):(Rn.expandByPoint(ga.min),Rn.expandByPoint(ga.max))}Rn.getCenter(n);let s=0;for(let a=0,r=e.count;a<r;a++)Yt.fromBufferAttribute(e,a),s=Math.max(s,n.distanceToSquared(Yt));if(t)for(let a=0,r=t.length;a<r;a++){const o=t[a],l=this.morphTargetsRelative;for(let c=0,d=o.count;c<d;c++)Yt.fromBufferAttribute(o,c),l&&(Os.fromBufferAttribute(e,c),Yt.add(Os)),s=Math.max(s,n.distanceToSquared(Yt))}this.boundingSphere.radius=Math.sqrt(s),isNaN(this.boundingSphere.radius)&&it('BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const e=this.index,t=this.attributes;if(e===null||t.position===void 0||t.normal===void 0||t.uv===void 0){it("BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const n=t.position,s=t.normal,a=t.uv;let r=this.getAttribute("tangent");(r===void 0||r.count!==n.count)&&(r=new Ft(new Float32Array(4*n.count),4),this.setAttribute("tangent",r));const o=[],l=[],c=new Uint8Array(n.count);for(let P=0;P<n.count;P++)o[P]=new D,l[P]=new D;const d=new D,h=new D,u=new D,f=new Ie,g=new Ie,y=new Ie,m=new D,p=new D;function x(P,R,N){c[P]=c[R]=c[N]=1,d.fromBufferAttribute(n,P),h.fromBufferAttribute(n,R),u.fromBufferAttribute(n,N),f.fromBufferAttribute(a,P),g.fromBufferAttribute(a,R),y.fromBufferAttribute(a,N),h.sub(d),u.sub(d),g.sub(f),y.sub(f);const F=1/(g.x*y.y-y.x*g.y);isFinite(F)&&(m.copy(h).multiplyScalar(y.y).addScaledVector(u,-g.y).multiplyScalar(F),p.copy(u).multiplyScalar(g.x).addScaledVector(h,-y.x).multiplyScalar(F),o[P].add(m),o[R].add(m),o[N].add(m),l[P].add(p),l[R].add(p),l[N].add(p))}let A=this.groups;A.length===0&&(A=[{start:0,count:e.count}]);for(let P=0,R=A.length;P<R;++P){const N=A[P],F=N.start,G=N.count;for(let L=F,z=F+G;L<z;L+=3)x(e.getX(L+0),e.getX(L+1),e.getX(L+2))}const b=new D,E=new D,S=new D,v=new D;function w(P){S.fromBufferAttribute(s,P),v.copy(S);const R=o[P];b.copy(R),b.sub(S.multiplyScalar(S.dot(R))).normalize(),E.crossVectors(v,R);const F=E.dot(l[P])<0?-1:1;r.setXYZW(P,b.x,b.y,b.z,F)}for(let P=0,R=n.count;P<R;++P)c[P]&&w(P);this._transformed=!0}computeVertexNormals(){const e=this.index,t=this.getAttribute("position");if(t!==void 0){let n=this.getAttribute("normal");if(n===void 0||n.count!==t.count)n=new Ft(new Float32Array(t.count*3),3),this.setAttribute("normal",n);else for(let u=0,f=n.count;u<f;u++)n.setXYZ(u,0,0,0);const s=new D,a=new D,r=new D,o=new D,l=new D,c=new D,d=new D,h=new D;if(e)for(let u=0,f=e.count;u<f;u+=3){const g=e.getX(u+0),y=e.getX(u+1),m=e.getX(u+2);s.fromBufferAttribute(t,g),a.fromBufferAttribute(t,y),r.fromBufferAttribute(t,m),d.subVectors(r,a),h.subVectors(s,a),d.cross(h),o.fromBufferAttribute(n,g),l.fromBufferAttribute(n,y),c.fromBufferAttribute(n,m),o.add(d),l.add(d),c.add(d),n.setXYZ(g,o.x,o.y,o.z),n.setXYZ(y,l.x,l.y,l.z),n.setXYZ(m,c.x,c.y,c.z)}else for(let u=0,f=t.count;u<f;u+=3)s.fromBufferAttribute(t,u+0),a.fromBufferAttribute(t,u+1),r.fromBufferAttribute(t,u+2),d.subVectors(r,a),h.subVectors(s,a),d.cross(h),n.setXYZ(u+0,d.x,d.y,d.z),n.setXYZ(u+1,d.x,d.y,d.z),n.setXYZ(u+2,d.x,d.y,d.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){const e=this.attributes.normal;for(let t=0,n=e.count;t<n;t++)Yt.fromBufferAttribute(e,t),Yt.normalize(),e.setXYZ(t,Yt.x,Yt.y,Yt.z)}toNonIndexed(){function e(o,l){const c=o.array,d=o.itemSize,h=o.normalized,u=new c.constructor(l.length*d);let f=0,g=0;for(let y=0,m=l.length;y<m;y++){o.isInterleavedBufferAttribute?f=l[y]*o.data.stride+o.offset:f=l[y]*d;for(let p=0;p<d;p++)u[g++]=c[f++]}return new Ft(u,d,h)}if(this.index===null)return Ue("BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const t=new bt,n=this.index.array,s=this.attributes;for(const o in s){const l=s[o],c=e(l,n);t.setAttribute(o,c)}const a=this.morphAttributes;for(const o in a){const l=[],c=a[o];for(let d=0,h=c.length;d<h;d++){const u=c[d],f=e(u,n);l.push(f)}t.morphAttributes[o]=l}t.morphTargetsRelative=this.morphTargetsRelative;const r=this.groups;for(let o=0,l=r.length;o<l;o++){const c=r[o];t.addGroup(c.start,c.count,c.materialIndex)}return t}toJSON(){const e={metadata:{version:4.7,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(e.uuid=this.uuid,e.type=this.parameters!==void 0&&this._transformed===!0?"BufferGeometry":this.type,e.name=this.name,Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0&&this._transformed!==!0){const l=this.parameters;for(const c in l)l[c]!==void 0&&(e[c]=l[c]);return e}e.data={attributes:{}};const t=this.index;t!==null&&(e.data.index={type:t.array.constructor.name,array:Array.prototype.slice.call(t.array)});const n=this.attributes;for(const l in n){const c=n[l];e.data.attributes[l]=c.toJSON(e.data)}const s={};let a=!1;for(const l in this.morphAttributes){const c=this.morphAttributes[l],d=[];for(let h=0,u=c.length;h<u;h++){const f=c[h];d.push(f.toJSON(e.data))}d.length>0&&(s[l]=d,a=!0)}a&&(e.data.morphAttributes=s,e.data.morphTargetsRelative=this.morphTargetsRelative);const r=this.groups;r.length>0&&(e.data.groups=JSON.parse(JSON.stringify(r)));const o=this.boundingSphere;return o!==null&&(e.data.boundingSphere=o.toJSON()),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const t={};this.name=e.name;const n=e.index;n!==null&&this.setIndex(n.clone());const s=e.attributes;for(const c in s){const d=s[c];this.setAttribute(c,d.clone(t))}const a=e.morphAttributes;for(const c in a){const d=[],h=a[c];for(let u=0,f=h.length;u<f;u++)d.push(h[u].clone(t));this.morphAttributes[c]=d}this.morphTargetsRelative=e.morphTargetsRelative;const r=e.groups;for(let c=0,d=r.length;c<d;c++){const h=r[c];this.addGroup(h.start,h.count,h.materialIndex)}const o=e.boundingBox;o!==null&&(this.boundingBox=o.clone());const l=e.boundingSphere;return l!==null&&(this.boundingSphere=l.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this._transformed=e._transformed,this}dispose(){this.dispatchEvent({type:"dispose"})}}class E0{constructor(e,t){this.isInterleavedBuffer=!0,this.array=e,this.stride=t,this.count=e!==void 0?e.length/t:0,this.usage=Rf,this.updateRanges=[],this.version=0,this.uuid=ss()}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.array=new e.array.constructor(e.array),this.count=e.count,this.stride=e.stride,this.usage=e.usage,this}copyAt(e,t,n){e*=this.stride,n*=t.stride;for(let s=0,a=this.stride;s<a;s++)this.array[e+s]=t.array[n+s];return this}set(e,t=0){return this.array.set(e,t),this}clone(e){e.arrayBuffers===void 0&&(e.arrayBuffers={});const t=vh(this.array);e.arrayBuffers[t]===void 0&&(e.arrayBuffers[t]=this.array.slice(0).buffer);const n=new this.array.constructor(e.arrayBuffers[t]),s=new this.constructor(n,this.stride);return s.setUsage(this.usage),s}onUpload(e){return this.onUploadCallback=e,this}toJSON(e){e.arrayBuffers===void 0&&(e.arrayBuffers={});const t=vh(this.array);e.arrayBuffers[t]===void 0&&(e.arrayBuffers[t]=Array.from(new Uint32Array(this.array.slice(0).buffer)));const n={uuid:this.uuid,buffer:t,type:this.array.constructor.name,stride:this.stride};return n.usage=this.usage,n}}function vh(i){return i.buffer._uuid===void 0&&(i.buffer._uuid=ss()),i.byteOffset===0&&i.byteLength===i.buffer.byteLength?i.buffer._uuid:i.buffer._uuid+":"+i.byteOffset+":"+i.byteLength}const pn=new D;class bo{constructor(e,t,n,s=!1){this.isInterleavedBufferAttribute=!0,this.name="",this.data=e,this.itemSize=t,this.offset=n,this.normalized=s,this._normalizationScale=e!==void 0?Vo(e.array):void 0}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(e){this.data.needsUpdate=e}applyMatrix4(e){for(let t=0,n=this.data.count;t<n;t++)pn.fromBufferAttribute(this,t),pn.applyMatrix4(e),this.setXYZ(t,pn.x,pn.y,pn.z);return this}applyNormalMatrix(e){for(let t=0,n=this.count;t<n;t++)pn.fromBufferAttribute(this,t),pn.applyNormalMatrix(e),this.setXYZ(t,pn.x,pn.y,pn.z);return this}transformDirection(e){for(let t=0,n=this.count;t<n;t++)pn.fromBufferAttribute(this,t),pn.transformDirection(e),this.setXYZ(t,pn.x,pn.y,pn.z);return this}getComponent(e,t){let n=this.array[e*this.data.stride+this.offset+t];return this.normalized&&(n=this._denormalize(n)),n}setComponent(e,t,n){return this.normalized&&(n=this._normalize(n)),this.data.array[e*this.data.stride+this.offset+t]=n,this}setX(e,t){return this.normalized&&(t=this._normalize(t)),this.data.array[e*this.data.stride+this.offset]=t,this}setY(e,t){return this.normalized&&(t=this._normalize(t)),this.data.array[e*this.data.stride+this.offset+1]=t,this}setZ(e,t){return this.normalized&&(t=this._normalize(t)),this.data.array[e*this.data.stride+this.offset+2]=t,this}setW(e,t){return this.normalized&&(t=this._normalize(t)),this.data.array[e*this.data.stride+this.offset+3]=t,this}getX(e){let t=this.data.array[e*this.data.stride+this.offset];return this.normalized&&(t=this._denormalize(t)),t}getY(e){let t=this.data.array[e*this.data.stride+this.offset+1];return this.normalized&&(t=this._denormalize(t)),t}getZ(e){let t=this.data.array[e*this.data.stride+this.offset+2];return this.normalized&&(t=this._denormalize(t)),t}getW(e){let t=this.data.array[e*this.data.stride+this.offset+3];return this.normalized&&(t=this._denormalize(t)),t}setXY(e,t,n){return e=e*this.data.stride+this.offset,this.normalized&&(t=this._normalize(t),n=this._normalize(n)),this.data.array[e+0]=t,this.data.array[e+1]=n,this}setXYZ(e,t,n,s){return e=e*this.data.stride+this.offset,this.normalized&&(t=this._normalize(t),n=this._normalize(n),s=this._normalize(s)),this.data.array[e+0]=t,this.data.array[e+1]=n,this.data.array[e+2]=s,this}setXYZW(e,t,n,s,a){return e=e*this.data.stride+this.offset,this.normalized&&(t=this._normalize(t),n=this._normalize(n),s=this._normalize(s),a=this._normalize(a)),this.data.array[e+0]=t,this.data.array[e+1]=n,this.data.array[e+2]=s,this.data.array[e+3]=a,this}clone(e){if(e===void 0){yo("InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");const t=[];for(let n=0;n<this.count;n++){const s=n*this.data.stride+this.offset;for(let a=0;a<this.itemSize;a++)t.push(this.data.array[s+a])}return new Ft(new this.array.constructor(t),this.itemSize,this.normalized)}else return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.clone(e)),new bo(e.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(e){if(e===void 0){yo("InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");const t=[];for(let n=0;n<this.count;n++){const s=n*this.data.stride+this.offset;for(let a=0;a<this.itemSize;a++)t.push(this.data.array[s+a])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:t,normalized:this.normalized}}else return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.toJSON(e)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}_denormalize(e){const t=this._normalizationScale;return t!==void 0?Math.max(e/t,-1):_d(e,this.data.array)}_normalize(e){const t=this._normalizationScale;return t!==void 0?Math.round(e*t):Md(e,this.data.array)}}const Dl=new D,A0=new D,T0=new ke;class Ai{constructor(e=new D(1,0,0),t=0){this.isPlane=!0,this.normal=e,this.constant=t}set(e,t){return this.normal.copy(e),this.constant=t,this}setComponents(e,t,n,s){return this.normal.set(e,t,n),this.constant=s,this}setFromNormalAndCoplanarPoint(e,t){return this.normal.copy(e),this.constant=-t.dot(this.normal),this}setFromCoplanarPoints(e,t,n){const s=Dl.subVectors(n,t).cross(A0.subVectors(e,t)).normalize();return this.setFromNormalAndCoplanarPoint(s,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){const e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,t){return t.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,t,n=!0){const s=e.delta(Dl),a=this.normal.dot(s);if(a===0)return this.distanceToPoint(e.start)===0?t.copy(e.start):null;const r=-(e.start.dot(this.normal)+this.constant)/a;return n===!0&&(r<0||r>1)?null:t.copy(e.start).addScaledVector(s,r)}intersectsLine(e){const t=this.distanceToPoint(e.start),n=this.distanceToPoint(e.end);return t<0&&n>0||n<0&&t>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,t){const n=t||T0.getNormalMatrix(e),s=this.coplanarPoint(Dl).applyMatrix4(e),a=this.normal.applyMatrix3(n).normalize();return this.constant=-s.dot(a),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}toJSON(){return{normal:this.normal.toArray(),constant:this.constant}}fromJSON(e){return this.normal.fromArray(e.normal),this.constant=e.constant,this}}let R0=0;class Oi extends Ss{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:R0++}),this.uuid=ss(),this.name="",this.type="Material",this.blending=Ua,this.side=vs,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=df,this.blendDst=hf,this.blendEquation=Xs,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new Ce(0,0,0),this.blendAlpha=0,this.depthFunc=$a,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=km,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=pl,this.stencilZFail=pl,this.stencilZPass=pl,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(const t in e){const n=e[t];if(n===void 0){Ue(`Material: parameter '${t}' has value of undefined.`);continue}const s=this[t];if(s===void 0){Ue(`Material: '${t}' is not a property of THREE.${this.type}.`);continue}s&&s.isColor?s.set(n):s&&s.isVector2&&n&&n.isVector2||s&&s.isEuler&&n&&n.isEuler||s&&s.isVector3&&n&&n.isVector3?s.copy(n):this[t]=n}}toJSON(e){const t=e===void 0||typeof e=="string";t&&(e={textures:{},images:{}});const n={metadata:{version:4.7,type:"Material",generator:"Material.toJSON"}};n.uuid=this.uuid,n.type=this.type,n.blending=this.blending,n.side=this.side,n.shadowSide=this.shadowSide,n.vertexColors=this.vertexColors,n.opacity=this.opacity,n.transparent=this.transparent,n.blendSrc=this.blendSrc,n.blendDst=this.blendDst,n.blendEquation=this.blendEquation,n.blendSrcAlpha=this.blendSrcAlpha,n.blendDstAlpha=this.blendDstAlpha,n.blendEquationAlpha=this.blendEquationAlpha,n.blendColor=this.blendColor.getHex(),n.blendAlpha=this.blendAlpha,n.depthFunc=this.depthFunc,n.depthTest=this.depthTest,n.depthWrite=this.depthWrite,n.colorWrite=this.colorWrite,n.clipIntersection=this.clipIntersection,n.clipShadows=this.clipShadows,n.stencilWriteMask=this.stencilWriteMask,n.stencilFunc=this.stencilFunc,n.stencilRef=this.stencilRef,n.stencilFuncMask=this.stencilFuncMask,n.stencilFail=this.stencilFail,n.stencilZFail=this.stencilZFail,n.stencilZPass=this.stencilZPass,n.stencilWrite=this.stencilWrite,n.polygonOffset=this.polygonOffset,n.polygonOffsetFactor=this.polygonOffsetFactor,n.polygonOffsetUnits=this.polygonOffsetUnits,n.dithering=this.dithering,n.alphaTest=this.alphaTest,n.alphaHash=this.alphaHash,n.alphaToCoverage=this.alphaToCoverage,n.premultipliedAlpha=this.premultipliedAlpha,n.forceSinglePass=this.forceSinglePass,n.allowOverride=this.allowOverride,n.visible=this.visible,n.toneMapped=this.toneMapped,n.name=this.name,this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.diffuseRoughness!==void 0&&(n.diffuseRoughness=this.diffuseRoughness),this.diffuseRoughnessMap&&this.diffuseRoughnessMap.isTexture&&(n.diffuseRoughnessMap=this.diffuseRoughnessMap.toJSON(e).uuid),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.sheenColorMap&&this.sheenColorMap.isTexture&&(n.sheenColorMap=this.sheenColorMap.toJSON(e).uuid),this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture&&(n.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(e).uuid),this.dispersion!==void 0&&(n.dispersion=this.dispersion),this.retroreflectivity!==void 0&&(n.retroreflectivity=this.retroreflectivity),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessMinimum!==void 0&&(n.iridescenceThicknessMinimum=this.iridescenceThicknessMinimum),this.iridescenceThicknessMaximum!==void 0&&(n.iridescenceThicknessMaximum=this.iridescenceThicknessMaximum),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(e).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(e).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(e).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(e).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(e).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapRotation!==void 0&&(n.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),Array.isArray(this.clippingPlanes)&&this.clippingPlanes.length>0&&(n.clippingPlanes=this.clippingPlanes.map(a=>a.toJSON())),this.rotation!==void 0&&(n.rotation=this.rotation),this.depthPacking!==void 0&&(n.depthPacking=this.depthPacking),this.linewidth!==void 0&&(n.linewidth=this.linewidth),this.linecap!==void 0&&(n.linecap=this.linecap),this.linejoin!==void 0&&(n.linejoin=this.linejoin),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.wireframe!==void 0&&(n.wireframe=this.wireframe),this.wireframeLinewidth!==void 0&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!==void 0&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!==void 0&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading!==void 0&&(n.flatShading=this.flatShading),this.fog!==void 0&&(n.fog=this.fog),Object.keys(this.userData).length>0&&(n.userData=this.userData);function s(a){const r=[];for(const o in a){const l=a[o];delete l.metadata,r.push(l)}return r}if(t){const a=s(e.textures),r=s(e.images);a.length>0&&(n.textures=a),r.length>0&&(n.images=r)}return n}fromJSON(e,t){if(e.uuid!==void 0&&(this.uuid=e.uuid),e.name!==void 0&&(this.name=e.name),e.color!==void 0&&this.color!==void 0&&this.color.setHex(e.color),e.roughness!==void 0&&(this.roughness=e.roughness),e.metalness!==void 0&&(this.metalness=e.metalness),e.sheen!==void 0&&(this.sheen=e.sheen),e.sheenColor!==void 0&&(this.sheenColor=new Ce().setHex(e.sheenColor)),e.sheenRoughness!==void 0&&(this.sheenRoughness=e.sheenRoughness),e.emissive!==void 0&&this.emissive!==void 0&&this.emissive.setHex(e.emissive),e.specular!==void 0&&this.specular!==void 0&&this.specular.setHex(e.specular),e.specularIntensity!==void 0&&(this.specularIntensity=e.specularIntensity),e.specularColor!==void 0&&this.specularColor!==void 0&&this.specularColor.setHex(e.specularColor),e.shininess!==void 0&&(this.shininess=e.shininess),e.clearcoat!==void 0&&(this.clearcoat=e.clearcoat),e.clearcoatRoughness!==void 0&&(this.clearcoatRoughness=e.clearcoatRoughness),e.diffuseRoughness!==void 0&&(this.diffuseRoughness=e.diffuseRoughness),e.dispersion!==void 0&&(this.dispersion=e.dispersion),e.retroreflectivity!==void 0&&(this.retroreflectivity=e.retroreflectivity),e.iridescence!==void 0&&(this.iridescence=e.iridescence),e.iridescenceIOR!==void 0&&(this.iridescenceIOR=e.iridescenceIOR),e.iridescenceThicknessMinimum!==void 0&&(this.iridescenceThicknessMinimum=e.iridescenceThicknessMinimum),e.iridescenceThicknessMaximum!==void 0&&(this.iridescenceThicknessMaximum=e.iridescenceThicknessMaximum),e.iridescenceThicknessRange!==void 0&&(this.iridescenceThicknessMinimum=e.iridescenceThicknessRange[0],this.iridescenceThicknessMaximum=e.iridescenceThicknessRange[1]),e.transmission!==void 0&&(this.transmission=e.transmission),e.thickness!==void 0&&(this.thickness=e.thickness),e.attenuationDistance!==void 0&&(this.attenuationDistance=e.attenuationDistance),e.attenuationColor!==void 0&&this.attenuationColor!==void 0&&this.attenuationColor.setHex(e.attenuationColor),e.anisotropy!==void 0&&(this.anisotropy=e.anisotropy),e.anisotropyRotation!==void 0&&(this.anisotropyRotation=e.anisotropyRotation),e.fog!==void 0&&(this.fog=e.fog),e.flatShading!==void 0&&(this.flatShading=e.flatShading),e.blending!==void 0&&(this.blending=e.blending),e.combine!==void 0&&(this.combine=e.combine),e.side!==void 0&&(this.side=e.side),e.shadowSide!==void 0&&(this.shadowSide=e.shadowSide),e.opacity!==void 0&&(this.opacity=e.opacity),e.transparent!==void 0&&(this.transparent=e.transparent),e.alphaTest!==void 0&&(this.alphaTest=e.alphaTest),e.alphaHash!==void 0&&(this.alphaHash=e.alphaHash),e.depthFunc!==void 0&&(this.depthFunc=e.depthFunc),e.depthTest!==void 0&&(this.depthTest=e.depthTest),e.depthWrite!==void 0&&(this.depthWrite=e.depthWrite),e.colorWrite!==void 0&&(this.colorWrite=e.colorWrite),e.clippingPlanes!==void 0&&(this.clippingPlanes=e.clippingPlanes.map(n=>new Ai().fromJSON(n))),e.clipIntersection!==void 0&&(this.clipIntersection=e.clipIntersection),e.clipShadows!==void 0&&(this.clipShadows=e.clipShadows),e.depthPacking!==void 0&&(this.depthPacking=e.depthPacking),e.blendSrc!==void 0&&(this.blendSrc=e.blendSrc),e.blendDst!==void 0&&(this.blendDst=e.blendDst),e.blendEquation!==void 0&&(this.blendEquation=e.blendEquation),e.blendSrcAlpha!==void 0&&(this.blendSrcAlpha=e.blendSrcAlpha),e.blendDstAlpha!==void 0&&(this.blendDstAlpha=e.blendDstAlpha),e.blendEquationAlpha!==void 0&&(this.blendEquationAlpha=e.blendEquationAlpha),e.blendColor!==void 0&&this.blendColor!==void 0&&this.blendColor.setHex(e.blendColor),e.blendAlpha!==void 0&&(this.blendAlpha=e.blendAlpha),e.stencilWriteMask!==void 0&&(this.stencilWriteMask=e.stencilWriteMask),e.stencilFunc!==void 0&&(this.stencilFunc=e.stencilFunc),e.stencilRef!==void 0&&(this.stencilRef=e.stencilRef),e.stencilFuncMask!==void 0&&(this.stencilFuncMask=e.stencilFuncMask),e.stencilFail!==void 0&&(this.stencilFail=e.stencilFail),e.stencilZFail!==void 0&&(this.stencilZFail=e.stencilZFail),e.stencilZPass!==void 0&&(this.stencilZPass=e.stencilZPass),e.stencilWrite!==void 0&&(this.stencilWrite=e.stencilWrite),e.wireframe!==void 0&&(this.wireframe=e.wireframe),e.wireframeLinewidth!==void 0&&(this.wireframeLinewidth=e.wireframeLinewidth),e.wireframeLinecap!==void 0&&(this.wireframeLinecap=e.wireframeLinecap),e.wireframeLinejoin!==void 0&&(this.wireframeLinejoin=e.wireframeLinejoin),e.rotation!==void 0&&(this.rotation=e.rotation),e.linewidth!==void 0&&(this.linewidth=e.linewidth),e.linecap!==void 0&&(this.linecap=e.linecap),e.linejoin!==void 0&&(this.linejoin=e.linejoin),e.dashSize!==void 0&&(this.dashSize=e.dashSize),e.gapSize!==void 0&&(this.gapSize=e.gapSize),e.scale!==void 0&&(this.scale=e.scale),e.polygonOffset!==void 0&&(this.polygonOffset=e.polygonOffset),e.polygonOffsetFactor!==void 0&&(this.polygonOffsetFactor=e.polygonOffsetFactor),e.polygonOffsetUnits!==void 0&&(this.polygonOffsetUnits=e.polygonOffsetUnits),e.dithering!==void 0&&(this.dithering=e.dithering),e.alphaToCoverage!==void 0&&(this.alphaToCoverage=e.alphaToCoverage),e.premultipliedAlpha!==void 0&&(this.premultipliedAlpha=e.premultipliedAlpha),e.forceSinglePass!==void 0&&(this.forceSinglePass=e.forceSinglePass),e.allowOverride!==void 0&&(this.allowOverride=e.allowOverride),e.visible!==void 0&&(this.visible=e.visible),e.toneMapped!==void 0&&(this.toneMapped=e.toneMapped),e.userData!==void 0&&(this.userData=e.userData),e.vertexColors!==void 0&&(typeof e.vertexColors=="number"?this.vertexColors=e.vertexColors>0:this.vertexColors=e.vertexColors),e.size!==void 0&&(this.size=e.size),e.sizeAttenuation!==void 0&&(this.sizeAttenuation=e.sizeAttenuation),e.map!==void 0&&(this.map=t[e.map]||null),e.matcap!==void 0&&(this.matcap=t[e.matcap]||null),e.alphaMap!==void 0&&(this.alphaMap=t[e.alphaMap]||null),e.bumpMap!==void 0&&(this.bumpMap=t[e.bumpMap]||null),e.bumpScale!==void 0&&(this.bumpScale=e.bumpScale),e.normalMap!==void 0&&(this.normalMap=t[e.normalMap]||null),e.normalMapType!==void 0&&(this.normalMapType=e.normalMapType),e.normalScale!==void 0){let n=e.normalScale;Array.isArray(n)===!1&&(n=[n,n]),this.normalScale=new Ie().fromArray(n)}return e.displacementMap!==void 0&&(this.displacementMap=t[e.displacementMap]||null),e.displacementScale!==void 0&&(this.displacementScale=e.displacementScale),e.displacementBias!==void 0&&(this.displacementBias=e.displacementBias),e.roughnessMap!==void 0&&(this.roughnessMap=t[e.roughnessMap]||null),e.metalnessMap!==void 0&&(this.metalnessMap=t[e.metalnessMap]||null),e.emissiveMap!==void 0&&(this.emissiveMap=t[e.emissiveMap]||null),e.emissiveIntensity!==void 0&&(this.emissiveIntensity=e.emissiveIntensity),e.specularMap!==void 0&&(this.specularMap=t[e.specularMap]||null),e.specularIntensityMap!==void 0&&(this.specularIntensityMap=t[e.specularIntensityMap]||null),e.specularColorMap!==void 0&&(this.specularColorMap=t[e.specularColorMap]||null),e.envMap!==void 0&&(this.envMap=t[e.envMap]||null),e.envMapRotation!==void 0&&this.envMapRotation.fromArray(e.envMapRotation),e.envMapIntensity!==void 0&&(this.envMapIntensity=e.envMapIntensity),e.reflectivity!==void 0&&(this.reflectivity=e.reflectivity),e.refractionRatio!==void 0&&(this.refractionRatio=e.refractionRatio),e.lightMap!==void 0&&(this.lightMap=t[e.lightMap]||null),e.lightMapIntensity!==void 0&&(this.lightMapIntensity=e.lightMapIntensity),e.aoMap!==void 0&&(this.aoMap=t[e.aoMap]||null),e.aoMapIntensity!==void 0&&(this.aoMapIntensity=e.aoMapIntensity),e.gradientMap!==void 0&&(this.gradientMap=t[e.gradientMap]||null),e.clearcoatMap!==void 0&&(this.clearcoatMap=t[e.clearcoatMap]||null),e.clearcoatRoughnessMap!==void 0&&(this.clearcoatRoughnessMap=t[e.clearcoatRoughnessMap]||null),e.clearcoatNormalMap!==void 0&&(this.clearcoatNormalMap=t[e.clearcoatNormalMap]||null),e.clearcoatNormalScale!==void 0&&(this.clearcoatNormalScale=new Ie().fromArray(e.clearcoatNormalScale)),e.diffuseRoughnessMap!==void 0&&(this.diffuseRoughnessMap=t[e.diffuseRoughnessMap]||null),e.iridescenceMap!==void 0&&(this.iridescenceMap=t[e.iridescenceMap]||null),e.iridescenceThicknessMap!==void 0&&(this.iridescenceThicknessMap=t[e.iridescenceThicknessMap]||null),e.transmissionMap!==void 0&&(this.transmissionMap=t[e.transmissionMap]||null),e.thicknessMap!==void 0&&(this.thicknessMap=t[e.thicknessMap]||null),e.anisotropyMap!==void 0&&(this.anisotropyMap=t[e.anisotropyMap]||null),e.sheenColorMap!==void 0&&(this.sheenColorMap=t[e.sheenColorMap]||null),e.sheenRoughnessMap!==void 0&&(this.sheenRoughnessMap=t[e.sheenRoughnessMap]||null),this}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;const t=e.clippingPlanes;let n=null;if(t!==null){const s=t.length;n=new Array(s);for(let a=0;a!==s;++a)n[a]=t[a].clone()}return this.clippingPlanes=n,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.allowOverride=e.allowOverride,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){e===!0&&this.version++}}class _o extends Oi{constructor(e){super(),this.isSpriteMaterial=!0,this.type="SpriteMaterial",this.color=new Ce(16777215),this.map=null,this.alphaMap=null,this.rotation=0,this.sizeAttenuation=!0,this.transparent=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.rotation=e.rotation,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}}let ks;const va=new D,Bs=new D,zs=new D,$s=new Ie,ya=new Ie,Uf=new tt,mr=new D,xa=new D,gr=new D,yh=new Ie,Il=new Ie,xh=new Ie;class zc extends Ut{constructor(e=new _o){if(super(),this.isSprite=!0,this.type="Sprite",ks===void 0){ks=new bt;const t=new Float32Array([-.5,-.5,0,0,0,.5,-.5,0,1,0,.5,.5,0,1,1,-.5,.5,0,0,1]),n=new E0(t,5);ks.setIndex([0,1,2,0,2,3]),ks.setAttribute("position",new bo(n,3,0,!1)),ks.setAttribute("uv",new bo(n,2,3,!1))}this.geometry=ks,this.material=e,this.center=new Ie(.5,.5),this.count=1}intersectsFrustum(e){return e.intersectsSprite(this)}raycast(e,t){e.camera===null&&it('Sprite: "Raycaster.camera" needs to be set in order to raycast against sprites.'),Bs.setFromMatrixScale(this.matrixWorld),Uf.copy(e.camera.matrixWorld),this.modelViewMatrix.multiplyMatrices(e.camera.matrixWorldInverse,this.matrixWorld),zs.setFromMatrixPosition(this.modelViewMatrix),e.camera.isPerspectiveCamera&&this.material.sizeAttenuation===!1&&Bs.multiplyScalar(-zs.z);const n=this.material.rotation;let s,a;n!==0&&(a=Math.cos(n),s=Math.sin(n));const r=this.center;vr(mr.set(-.5,-.5,0),zs,r,Bs,s,a),vr(xa.set(.5,-.5,0),zs,r,Bs,s,a),vr(gr.set(.5,.5,0),zs,r,Bs,s,a),yh.set(0,0),Il.set(1,0),xh.set(1,1);let o=e.ray.intersectTriangle(mr,xa,gr,!1,va);if(o===null&&(vr(xa.set(-.5,.5,0),zs,r,Bs,s,a),Il.set(0,1),o=e.ray.intersectTriangle(mr,gr,xa,!1,va),o===null))return;const l=e.ray.origin.distanceTo(va);l<e.near||l>e.far||t.push({distance:l,point:va.clone(),uv:Cn.getInterpolation(va,mr,xa,gr,yh,Il,xh,new Ie),face:null,object:this})}copy(e,t){return super.copy(e,t),e.center!==void 0&&this.center.copy(e.center),this.material=e.material,this}toJSON(e){const t=super.toJSON(e);return t.object.center=this.center.toArray(),t}}function vr(i,e,t,n,s,a){$s.subVectors(i,t).addScalar(.5).multiply(n),s!==void 0?(ya.x=a*$s.x-s*$s.y,ya.y=s*$s.x+a*$s.y):ya.copy($s),i.copy(e),i.x+=ya.x,i.y+=ya.y,i.applyMatrix4(Uf)}const Mi=new D,Nl=new D,yr=new D,xr=new D;class Xo{constructor(e=new D,t=new D(0,0,-1)){this.origin=e,this.direction=t}set(e,t){return this.origin.copy(e),this.direction.copy(t),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,t){return t.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,Mi)),this}closestPointToPoint(e,t){t.subVectors(e,this.origin);const n=t.dot(this.direction);return n<0?t.copy(this.origin):t.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){const t=Mi.subVectors(e,this.origin).dot(this.direction);return t<0?this.origin.distanceToSquared(e):(Mi.copy(this.origin).addScaledVector(this.direction,t),Mi.distanceToSquared(e))}distanceSqToSegment(e,t,n,s){Nl.copy(e).add(t).multiplyScalar(.5),yr.copy(t).sub(e).normalize(),xr.copy(this.origin).sub(Nl);const a=e.distanceTo(t)*.5,r=-this.direction.dot(yr),o=xr.dot(this.direction),l=-xr.dot(yr),c=xr.lengthSq(),d=Math.abs(1-r*r);let h,u,f,g;if(d>0)if(h=r*l-o,u=r*o-l,g=a*d,h>=0)if(u>=-g)if(u<=g){const y=1/d;h*=y,u*=y,f=h*(h+r*u+2*o)+u*(r*h+u+2*l)+c}else u=a,h=Math.max(0,-(r*u+o)),f=-h*h+u*(u+2*l)+c;else u=-a,h=Math.max(0,-(r*u+o)),f=-h*h+u*(u+2*l)+c;else u<=-g?(h=Math.max(0,-(-r*a+o)),u=h>0?-a:Math.min(Math.max(-a,-l),a),f=-h*h+u*(u+2*l)+c):u<=g?(h=0,u=Math.min(Math.max(-a,-l),a),f=u*(u+2*l)+c):(h=Math.max(0,-(r*a+o)),u=h>0?a:Math.min(Math.max(-a,-l),a),f=-h*h+u*(u+2*l)+c);else u=r>0?-a:a,h=Math.max(0,-(r*u+o)),f=-h*h+u*(u+2*l)+c;return n&&n.copy(this.origin).addScaledVector(this.direction,h),s&&s.copy(Nl).addScaledVector(yr,u),f}intersectSphere(e,t){if(e.radius<0)return null;Mi.subVectors(e.center,this.origin);const n=Mi.dot(this.direction),s=Mi.dot(Mi)-n*n,a=e.radius*e.radius;if(s>a)return null;const r=Math.sqrt(a-s),o=n-r,l=n+r;return l<0?null:o<0?this.at(l,t):this.at(o,t)}intersectsSphere(e){return e.radius<0?!1:this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){const t=e.normal.dot(this.direction);if(t===0)return e.distanceToPoint(this.origin)===0?0:null;const n=-(this.origin.dot(e.normal)+e.constant)/t;return n>=0?n:null}intersectPlane(e,t){const n=this.distanceToPlane(e);return n===null?null:this.at(n,t)}intersectsPlane(e){const t=e.distanceToPoint(this.origin);return t===0||e.normal.dot(this.direction)*t<0}intersectBox(e,t){let n,s,a,r,o,l;const c=1/this.direction.x,d=1/this.direction.y,h=1/this.direction.z,u=this.origin;return c>=0?(n=(e.min.x-u.x)*c,s=(e.max.x-u.x)*c):(n=(e.max.x-u.x)*c,s=(e.min.x-u.x)*c),d>=0?(a=(e.min.y-u.y)*d,r=(e.max.y-u.y)*d):(a=(e.max.y-u.y)*d,r=(e.min.y-u.y)*d),n>r||a>s||((a>n||isNaN(n))&&(n=a),(r<s||isNaN(s))&&(s=r),h>=0?(o=(e.min.z-u.z)*h,l=(e.max.z-u.z)*h):(o=(e.max.z-u.z)*h,l=(e.min.z-u.z)*h),n>l||o>s)||((o>n||n!==n)&&(n=o),(l<s||s!==s)&&(s=l),s<0)?null:this.at(n>=0?n:s,t)}intersectsBox(e){return this.intersectBox(e,Mi)!==null}intersectTriangle(e,t,n,s,a){const r=this.origin,o=this.direction,l=o.x,c=o.y,d=o.z,h=e.x-r.x,u=e.y-r.y,f=e.z-r.z,g=t.x-r.x,y=t.y-r.y,m=t.z-r.z,p=n.x-r.x,x=n.y-r.y,A=n.z-r.z,b=Math.abs(l),E=Math.abs(c),S=Math.abs(d);let v,w,P,R,N,F,G,L,z,X,$,te;if(b>=E&&b>=S?(P=l,F=h,z=g,te=p,l>=0?(v=c,w=d,R=u,N=f,G=y,L=m,X=x,$=A):(v=d,w=c,R=f,N=u,G=m,L=y,X=A,$=x)):E>=S?(P=c,F=u,z=y,te=x,c>=0?(v=d,w=l,R=f,N=h,G=m,L=g,X=A,$=p):(v=l,w=d,R=h,N=f,G=g,L=m,X=p,$=A)):(P=d,F=f,z=m,te=A,d>=0?(v=l,w=c,R=h,N=u,G=g,L=y,X=p,$=x):(v=c,w=l,R=u,N=h,G=y,L=g,X=x,$=p)),P===0)return null;const V=v/P,ee=w/P,ne=1/P,Ee=R-V*F,$e=N-ee*F,K=G-V*z,ye=L-ee*z,Me=X-V*te,Le=$-ee*te,xe=Me*ye-Le*K,Ge=Ee*Le-$e*Me,Lt=K*$e-ye*Ee;if(s){if(xe<0||Ge<0||Lt<0)return null}else if((xe<0||Ge<0||Lt<0)&&(xe>0||Ge>0||Lt>0))return null;const Ne=xe+Ge+Lt;if(Ne===0)return null;const rt=ne*(xe*F+Ge*z+Lt*te);return(Ne>0?rt<0:rt>0)?null:this.at(rt/Ne,a)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class ct extends Oi{constructor(e){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new Ce(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Wn,this.combine=hd,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}}const bh=new tt,hs=new Xo,br=new As,_h=new D,_r=new D,Mr=new D,wr=new D,Ul=new D,Sr=new D,Mh=new D,Er=new D;class Te extends Ut{constructor(e=new bt,t=new ct){super(),this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0?this.morphTargetInfluences=e.morphTargetInfluences.slice():this.morphTargetInfluences=void 0,e.morphTargetDictionary!==void 0?this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary):this.morphTargetDictionary=void 0,this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){const t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){const s=t[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let a=0,r=s.length;a<r;a++){const o=s[a].name||String(a);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=a}}}}getVertexPosition(e,t){const n=this.geometry,s=n.attributes.position,a=n.morphAttributes.position,r=n.morphTargetsRelative;t.fromBufferAttribute(s,e);const o=this.morphTargetInfluences;if(a&&o){Sr.set(0,0,0);for(let l=0,c=a.length;l<c;l++){const d=o[l],h=a[l];d!==0&&(Ul.fromBufferAttribute(h,e),r?Sr.addScaledVector(Ul,d):Sr.addScaledVector(Ul.sub(t),d))}t.add(Sr)}return t}intersectsFrustum(e){return e.intersectsObject(this)}raycast(e,t){const n=this.geometry,s=this.material,a=this.matrixWorld;s!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),br.copy(n.boundingSphere),br.applyMatrix4(a),hs.copy(e.ray).recast(e.near),!(br.containsPoint(hs.origin)===!1&&(hs.intersectSphere(br,_h)===null||hs.origin.distanceToSquared(_h)>(e.far-e.near)**2))&&(bh.copy(a).invert(),hs.copy(e.ray).applyMatrix4(bh),!(n.boundingBox!==null&&hs.intersectsBox(n.boundingBox)===!1)&&this._computeIntersections(e,t,hs)))}_computeIntersections(e,t,n){let s;const a=this.geometry,r=this.material,o=a.index,l=a.attributes.position,c=a.attributes.uv,d=a.attributes.uv1,h=a.attributes.normal,u=a.groups,f=a.drawRange;if(o!==null)if(Array.isArray(r))for(let g=0,y=u.length;g<y;g++){const m=u[g],p=r[m.materialIndex],x=Math.max(m.start,f.start),A=Math.min(o.count,Math.min(m.start+m.count,f.start+f.count));for(let b=x,E=A;b<E;b+=3){const S=o.getX(b),v=o.getX(b+1),w=o.getX(b+2);s=Ar(this,p,e,n,c,d,h,S,v,w),s&&(s.faceIndex=Math.floor(b/3),s.face.materialIndex=m.materialIndex,t.push(s))}}else{const g=Math.max(0,f.start),y=Math.min(o.count,f.start+f.count);for(let m=g,p=y;m<p;m+=3){const x=o.getX(m),A=o.getX(m+1),b=o.getX(m+2);s=Ar(this,r,e,n,c,d,h,x,A,b),s&&(s.faceIndex=Math.floor(m/3),t.push(s))}}else if(l!==void 0)if(Array.isArray(r))for(let g=0,y=u.length;g<y;g++){const m=u[g],p=r[m.materialIndex],x=Math.max(m.start,f.start),A=Math.min(l.count,Math.min(m.start+m.count,f.start+f.count));for(let b=x,E=A;b<E;b+=3){const S=b,v=b+1,w=b+2;s=Ar(this,p,e,n,c,d,h,S,v,w),s&&(s.faceIndex=Math.floor(b/3),s.face.materialIndex=m.materialIndex,t.push(s))}}else{const g=Math.max(0,f.start),y=Math.min(l.count,f.start+f.count);for(let m=g,p=y;m<p;m+=3){const x=m,A=m+1,b=m+2;s=Ar(this,r,e,n,c,d,h,x,A,b),s&&(s.faceIndex=Math.floor(m/3),t.push(s))}}}}function C0(i,e,t,n,s,a,r,o){let l;if(e.side===rn?l=n.intersectTriangle(r,a,s,!0,o):l=n.intersectTriangle(s,a,r,e.side===vs,o),l===null)return null;Er.copy(o),Er.applyMatrix4(i.matrixWorld);const c=t.ray.origin.distanceTo(Er);return c<t.near||c>t.far?null:{distance:c,point:Er.clone(),object:i}}function Ar(i,e,t,n,s,a,r,o,l,c){i.getVertexPosition(o,_r),i.getVertexPosition(l,Mr),i.getVertexPosition(c,wr);const d=C0(i,e,t,n,_r,Mr,wr,Mh);if(d){const h=new D;Cn.getBarycoord(Mh,_r,Mr,wr,h),s&&(d.uv=Cn.getInterpolatedAttribute(s,o,l,c,h,new Ie)),a&&(d.uv1=Cn.getInterpolatedAttribute(a,o,l,c,h,new Ie)),r&&(d.normal=Cn.getInterpolatedAttribute(r,o,l,c,h,new D),d.normal.dot(n.direction)>0&&d.normal.multiplyScalar(-1));const u={a:o,b:l,c,normal:new D,materialIndex:0};Cn.getNormal(_r,Mr,wr,u.normal),d.face=u,d.barycoord=h}return d}class Ff extends un{constructor(e=null,t=1,n=1,s,a,r,o,l,c=sn,d=sn,h,u){super(null,r,o,l,c,d,s,a,h,u),this.isDataTexture=!0,this.image={data:e,width:t,height:n},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class wh extends Ft{constructor(e,t,n,s=1){super(e,t,n),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=s}copy(e){return super.copy(e),this.meshPerAttribute=e.meshPerAttribute,this}toJSON(){const e=super.toJSON();return e.meshPerAttribute=this.meshPerAttribute,e.isInstancedBufferAttribute=!0,e}}const Hs=new tt,Sh=new tt,Tr=[],Eh=new Es,P0=new tt,ba=new Te,_a=new As;class Rr extends Te{constructor(e,t,n){super(e,t),this.isInstancedMesh=!0,this.instanceMatrix=new wh(new Float32Array(n*16),16),this.instanceColor=null,this.morphTexture=null,this.count=n,this.boundingBox=null,this.boundingSphere=null;for(let s=0;s<n;s++)this.setMatrixAt(s,P0)}computeBoundingBox(){const e=this.geometry,t=this.count;this.boundingBox===null&&(this.boundingBox=new Es),e.boundingBox===null&&e.computeBoundingBox(),this.boundingBox.makeEmpty();for(let n=0;n<t;n++)this.getMatrixAt(n,Hs),Eh.copy(e.boundingBox).applyMatrix4(Hs),this.boundingBox.union(Eh)}computeBoundingSphere(){const e=this.geometry,t=this.count;this.boundingSphere===null&&(this.boundingSphere=new As),e.boundingSphere===null&&e.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let n=0;n<t;n++)this.getMatrixAt(n,Hs),_a.copy(e.boundingSphere).applyMatrix4(Hs),this.boundingSphere.union(_a)}copy(e,t){return super.copy(e,t),this.instanceMatrix.copy(e.instanceMatrix),this.morphTexture=e.morphTexture!==null?e.morphTexture.clone():null,this.instanceColor=e.instanceColor!==null?e.instanceColor.clone():null,this.count=e.count,this.boundingBox=e.boundingBox!==null?e.boundingBox.clone():null,this.boundingSphere=e.boundingSphere!==null?e.boundingSphere.clone():null,this}getColorAt(e,t){return this.instanceColor===null?t.setRGB(1,1,1):t.fromArray(this.instanceColor.array,e*3)}getMatrixAt(e,t){return t.fromArray(this.instanceMatrix.array,e*16)}getMorphAt(e,t){const n=t.morphTargetInfluences,s=this.morphTexture.source.data.data,a=n.length+1,r=e*a+1;for(let o=0;o<n.length;o++)n[o]=s[r+o]}raycast(e,t){const n=this.matrixWorld,s=this.count;if(ba.geometry=this.geometry,ba.material=this.material,ba.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),_a.copy(this.boundingSphere),_a.applyMatrix4(n),e.ray.intersectsSphere(_a)!==!1))for(let a=0;a<s;a++){this.getMatrixAt(a,Hs),Sh.multiplyMatrices(n,Hs),ba.matrixWorld=Sh,ba.raycast(e,Tr);for(let r=0,o=Tr.length;r<o;r++){const l=Tr[r];l.instanceId=a,l.object=this,t.push(l)}Tr.length=0}}setColorAt(e,t){return this.instanceColor===null&&(this.instanceColor=new wh(new Float32Array(this.instanceMatrix.count*3).fill(1),3)),t.toArray(this.instanceColor.array,e*3),this}setMatrixAt(e,t){return t.toArray(this.instanceMatrix.array,e*16),this}setMorphAt(e,t){const n=t.morphTargetInfluences,s=n.length+1;this.morphTexture===null&&(this.morphTexture=new Ff(new Float32Array(s*this.count),s,this.count,gd,ii));const a=this.morphTexture.source.data.data;let r=0;for(let c=0;c<n.length;c++)r+=n[c];const o=this.geometry.morphTargetsRelative?1:1-r,l=s*e;return a[l]=o,a.set(n,l+1),this}updateMorphTargets(){}dispose(){super.dispose(),this.instanceMatrix.dispose(),this.instanceColor!==null&&this.instanceColor.dispose(),this.morphTexture!==null&&(this.morphTexture.dispose(),this.morphTexture=null)}}const us=new As,L0=new Ie(.5,.5),Cr=new D;class Xa{constructor(e=new Ai,t=new Ai,n=new Ai,s=new Ai,a=new Ai,r=new Ai){this.planes=[e,t,n,s,a,r]}set(e,t,n,s,a,r){const o=this.planes;return o[0].copy(e),o[1].copy(t),o[2].copy(n),o[3].copy(s),o[4].copy(a),o[5].copy(r),this}copy(e){const t=this.planes;for(let n=0;n<6;n++)t[n].copy(e.planes[n]);return this}setFromProjectionMatrix(e,t=si,n=!1){const s=this.planes,a=e.elements,r=a[0],o=a[1],l=a[2],c=a[3],d=a[4],h=a[5],u=a[6],f=a[7],g=a[8],y=a[9],m=a[10],p=a[11],x=a[12],A=a[13],b=a[14],E=a[15];if(s[0].setComponents(c-r,f-d,p-g,E-x).normalize(),s[1].setComponents(c+r,f+d,p+g,E+x).normalize(),s[2].setComponents(c+o,f+h,p+y,E+A).normalize(),s[3].setComponents(c-o,f-h,p-y,E-A).normalize(),n)s[4].setComponents(l,u,m,b).normalize(),s[5].setComponents(c-l,f-u,p-m,E-b).normalize();else if(s[4].setComponents(c-l,f-u,p-m,E-b).normalize(),t===si)s[5].setComponents(c+l,f+u,p+m,E+b).normalize();else if(t===Va)s[5].setComponents(l,u,m,b).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+t);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),us.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{const t=e.geometry;t.boundingSphere===null&&t.computeBoundingSphere(),us.copy(t.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(us)}intersectsSprite(e){us.center.set(0,0,0);const t=L0.distanceTo(e.center);return us.radius=.7071067811865476+t,us.applyMatrix4(e.matrixWorld),this.intersectsSphere(us)}intersectsSphere(e){const t=this.planes,n=e.center,s=-e.radius;for(let a=0;a<6;a++)if(t[a].distanceToPoint(n)<s)return!1;return!0}intersectsBox(e){const t=this.planes;for(let n=0;n<6;n++){const s=t[n];if(Cr.x=s.normal.x>0?e.max.x:e.min.x,Cr.y=s.normal.y>0?e.max.y:e.min.y,Cr.z=s.normal.z>0?e.max.z:e.min.z,s.distanceToPoint(Cr)<0)return!1}return!0}containsPoint(e){const t=this.planes;for(let n=0;n<6;n++)if(t[n].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}const Ah=new tt;class Ed{constructor(){this.coordinateSystem=si,this._frustums=[],this._count=0}setFromArrayCamera(e){const t=e.cameras,n=this._frustums;for(let s=0;s<t.length;s++){const a=t[s];Ah.multiplyMatrices(a.projectionMatrix,a.matrixWorldInverse),n[s]===void 0&&(n[s]=new Xa),n[s].setFromProjectionMatrix(Ah,a.coordinateSystem,a.reversedDepth)}return this._count=t.length,this}getFrustum(e){return this._frustums[e]}intersectsObject(e){const t=this._frustums;for(let n=0;n<this._count;n++)if(t[n].intersectsObject(e))return!0;return!1}intersectsSprite(e){const t=this._frustums;for(let n=0;n<this._count;n++)if(t[n].intersectsSprite(e))return!0;return!1}intersectsSphere(e){const t=this._frustums;for(let n=0;n<this._count;n++)if(t[n].intersectsSphere(e))return!0;return!1}intersectsBox(e){const t=this._frustums;for(let n=0;n<this._count;n++)if(t[n].intersectsBox(e))return!0;return!1}containsPoint(e){const t=this._frustums;for(let n=0;n<this._count;n++)if(t[n].containsPoint(e))return!0;return!1}copy(e){this.coordinateSystem=e.coordinateSystem;const t=this._frustums,n=e._frustums;for(let s=0;s<e._count;s++)t[s]===void 0&&(t[s]=new Xa),t[s].copy(n[s]);return this._count=e._count,this}clone(){return new Ed().copy(this)}}class Mo extends Oi{constructor(e){super(),this.isLineBasicMaterial=!0,this.type="LineBasicMaterial",this.color=new Ce(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.linewidth=e.linewidth,this.linecap=e.linecap,this.linejoin=e.linejoin,this.fog=e.fog,this}}const wo=new D,So=new D,Th=new tt,Ma=new Xo,Pr=new As,Fl=new D,Rh=new D;class Of extends Ut{constructor(e=new bt,t=new Mo){super(),this.isLine=!0,this.type="Line",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0?this.morphTargetInfluences=e.morphTargetInfluences.slice():this.morphTargetInfluences=void 0,e.morphTargetDictionary!==void 0?this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary):this.morphTargetDictionary=void 0,this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}computeLineDistances(){const e=this.geometry;if(e.index===null){const t=e.attributes.position,n=[0];for(let s=1,a=t.count;s<a;s++)wo.fromBufferAttribute(t,s-1),So.fromBufferAttribute(t,s),n[s]=n[s-1],n[s]+=wo.distanceTo(So);e.setAttribute("lineDistance",new st(n,1))}else Ue("Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}intersectsFrustum(e){return e.intersectsObject(this)}raycast(e,t){const n=this.geometry,s=this.matrixWorld,a=e.params.Line.threshold,r=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),Pr.copy(n.boundingSphere),Pr.applyMatrix4(s),Pr.radius+=a,e.ray.intersectsSphere(Pr)===!1)return;Th.copy(s).invert(),Ma.copy(e.ray).applyMatrix4(Th);const o=a/((this.scale.x+this.scale.y+this.scale.z)/3),l=o*o,c=this.isLineSegments?2:1,d=n.index,u=n.attributes.position;if(d!==null){const f=Math.max(0,r.start),g=Math.min(d.count,r.start+r.count);for(let y=f,m=g-1;y<m;y+=c){const p=d.getX(y),x=d.getX(y+1),A=Lr(this,e,Ma,l,p,x,y);A&&t.push(A)}if(this.isLineLoop){const y=d.getX(g-1),m=d.getX(f),p=Lr(this,e,Ma,l,y,m,g-1);p&&t.push(p)}}else{const f=Math.max(0,r.start),g=Math.min(u.count,r.start+r.count);for(let y=f,m=g-1;y<m;y+=c){const p=Lr(this,e,Ma,l,y,y+1,y);p&&t.push(p)}if(this.isLineLoop){const y=Lr(this,e,Ma,l,g-1,f,g-1);y&&t.push(y)}}}updateMorphTargets(){const t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){const s=t[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let a=0,r=s.length;a<r;a++){const o=s[a].name||String(a);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=a}}}}}function Lr(i,e,t,n,s,a,r){const o=i.geometry.attributes.position;if(wo.fromBufferAttribute(o,s),So.fromBufferAttribute(o,a),t.distanceSqToSegment(wo,So,Fl,Rh)>n)return;Fl.applyMatrix4(i.matrixWorld);const c=e.ray.origin.distanceTo(Fl);if(!(c<e.near||c>e.far))return{distance:c,point:Rh.clone().applyMatrix4(i.matrixWorld),index:r,face:null,faceIndex:null,barycoord:null,object:i}}const Ch=new D,Ph=new D;class Lh extends Of{constructor(e,t){super(e,t),this.isLineSegments=!0,this.type="LineSegments"}computeLineDistances(){const e=this.geometry;if(e.index===null){const t=e.attributes.position,n=[];for(let s=0,a=t.count;s<a;s+=2)Ch.fromBufferAttribute(t,s),Ph.fromBufferAttribute(t,s+1),n[s]=s===0?0:n[s-1],n[s+1]=n[s]+Ch.distanceTo(Ph);e.setAttribute("lineDistance",new st(n,1))}else Ue("LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}}class ra extends Oi{constructor(e){super(),this.isPointsMaterial=!0,this.type="PointsMaterial",this.color=new Ce(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.size=e.size,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}}const Dh=new tt,$c=new Xo,Dr=new As,Ir=new D;class qa extends Ut{constructor(e=new bt,t=new ra){super(),this.isPoints=!0,this.type="Points",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0?this.morphTargetInfluences=e.morphTargetInfluences.slice():this.morphTargetInfluences=void 0,e.morphTargetDictionary!==void 0?this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary):this.morphTargetDictionary=void 0,this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}intersectsFrustum(e){return e.intersectsObject(this)}raycast(e,t){const n=this.geometry,s=this.matrixWorld,a=e.params.Points.threshold,r=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),Dr.copy(n.boundingSphere),Dr.applyMatrix4(s),Dr.radius+=a,e.ray.intersectsSphere(Dr)===!1)return;Dh.copy(s).invert(),$c.copy(e.ray).applyMatrix4(Dh);const o=a/((this.scale.x+this.scale.y+this.scale.z)/3),l=o*o,c=n.index,h=n.attributes.position;if(c!==null){const u=Math.max(0,r.start),f=Math.min(c.count,r.start+r.count);for(let g=u,y=f;g<y;g++){const m=c.getX(g);Ir.fromBufferAttribute(h,m),Ih(Ir,m,l,s,e,t,this)}}else{const u=Math.max(0,r.start),f=Math.min(h.count,r.start+r.count);for(let g=u,y=f;g<y;g++)Ir.fromBufferAttribute(h,g),Ih(Ir,g,l,s,e,t,this)}}updateMorphTargets(){const t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){const s=t[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let a=0,r=s.length;a<r;a++){const o=s[a].name||String(a);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=a}}}}}function Ih(i,e,t,n,s,a,r){const o=$c.distanceSqToPoint(i);if(o<t){const l=new D;$c.closestPointToPoint(i,l),l.applyMatrix4(n);const c=s.ray.origin.distanceTo(l);if(c<s.near||c>s.far)return;a.push({distance:c,distanceToRay:Math.sqrt(o),point:l,index:e,face:null,faceIndex:null,barycoord:null,object:r})}}class kf extends un{constructor(e=[],t=sa,n,s,a,r,o,l,c,d){super(e,t,n,s,a,r,o,l,c,d),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}}class nr extends un{constructor(e,t,n,s,a,r,o,l,c){super(e,t,n,s,a,r,o,l,c),this.isCanvasTexture=!0,this.needsUpdate=!0}}class oa extends un{constructor(e,t,n=mi,s,a,r,o=sn,l=sn,c,d=ns,h=1){if(d!==ns&&d!==Ji)throw new Error("THREE.DepthTexture: format must be either THREE.DepthFormat or THREE.DepthStencilFormat");const u={width:e,height:t,depth:h};super(u,s,a,r,o,l,d,n,c),this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.source=new wd(Object.assign({},e.image)),this.compareFunction=e.compareFunction,this}toJSON(e){const t=super.toJSON(e);return t.compareFunction=this.compareFunction,t}}class Bf extends oa{constructor(e,t=mi,n=sa,s,a,r=sn,o=sn,l,c=ns){const d={width:e,height:e,depth:1},h=[d,d,d,d,d,d];super(e,e,t,n,s,a,r,o,l,c),this.image=h,this.isCubeDepthTexture=!0,this.isCubeTexture=!0}get images(){return this.image}set images(e){this.image=e}}class zf extends un{constructor(e=null){super(),this.sourceTexture=e,this.isExternalTexture=!0}copy(e){return super.copy(e),this.sourceTexture=e.sourceTexture,this}}class Xn extends bt{constructor(e=1,t=1,n=1,s=1,a=1,r=1){super(),this.type="BoxGeometry",this.parameters={width:e,height:t,depth:n,widthSegments:s,heightSegments:a,depthSegments:r};const o=this;s=Math.floor(s),a=Math.floor(a),r=Math.floor(r);const l=[],c=[],d=[],h=[];let u=0,f=0;g("z","y","x",-1,-1,n,t,e,r,a,0),g("z","y","x",1,-1,n,t,-e,r,a,1),g("x","z","y",1,1,e,n,t,s,r,2),g("x","z","y",1,-1,e,n,-t,s,r,3),g("x","y","z",1,-1,e,t,n,s,a,4),g("x","y","z",-1,-1,e,t,-n,s,a,5),this.setIndex(l),this.setAttribute("position",new st(c,3)),this.setAttribute("normal",new st(d,3)),this.setAttribute("uv",new st(h,2));function g(y,m,p,x,A,b,E,S,v,w,P){const R=b/v,N=E/w,F=b/2,G=E/2,L=S/2,z=v+1,X=w+1;let $=0,te=0;const V=new D;for(let ee=0;ee<X;ee++){const ne=ee*N-G;for(let Ee=0;Ee<z;Ee++){const $e=Ee*R-F;V[y]=$e*x,V[m]=ne*A,V[p]=L,c.push(V.x,V.y,V.z),V[y]=0,V[m]=0,V[p]=S>0?1:-1,d.push(V.x,V.y,V.z),h.push(Ee/v),h.push(1-ee/w),$+=1}}for(let ee=0;ee<w;ee++)for(let ne=0;ne<v;ne++){const Ee=u+ne+z*ee,$e=u+ne+z*(ee+1),K=u+(ne+1)+z*(ee+1),ye=u+(ne+1)+z*ee;l.push(Ee,$e,ye),l.push($e,K,ye),te+=6}o.addGroup(f,te,P),f+=te,u+=$}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Xn(e.width,e.height,e.depth,e.widthSegments,e.heightSegments,e.depthSegments)}}class qo extends bt{constructor(e=1,t=32,n=0,s=Math.PI*2){super(),this.type="CircleGeometry",this.parameters={radius:e,segments:t,thetaStart:n,thetaLength:s},t=Math.max(3,t);const a=[],r=[],o=[],l=[],c=new D,d=new Ie;r.push(0,0,0),o.push(0,0,1),l.push(.5,.5);for(let h=0,u=3;h<=t;h++,u+=3){const f=n+h/t*s;c.x=e*Math.cos(f),c.y=e*Math.sin(f),r.push(c.x,c.y,c.z),o.push(0,0,1),d.x=(r[u]/e+1)/2,d.y=(r[u+1]/e+1)/2,l.push(d.x,d.y)}for(let h=1;h<=t;h++)a.push(h,h+1,0);this.setIndex(a),this.setAttribute("position",new st(r,3)),this.setAttribute("normal",new st(o,3)),this.setAttribute("uv",new st(l,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new qo(e.radius,e.segments,e.thetaStart,e.thetaLength)}}class yn extends bt{constructor(e=1,t=1,n=1,s=32,a=1,r=!1,o=0,l=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:e,radiusBottom:t,height:n,radialSegments:s,heightSegments:a,openEnded:r,thetaStart:o,thetaLength:l};const c=this;s=Math.floor(s),a=Math.floor(a);const d=[],h=[],u=[],f=[];let g=0;const y=[],m=n/2;let p=0;x(),r===!1&&(e>0&&A(!0),t>0&&A(!1)),this.setIndex(d),this.setAttribute("position",new st(h,3)),this.setAttribute("normal",new st(u,3)),this.setAttribute("uv",new st(f,2));function x(){const b=new D,E=new D;let S=0;const v=(t-e)/n;for(let w=0;w<=a;w++){const P=[],R=w/a,N=R*(t-e)+e;for(let F=0;F<=s;F++){const G=F/s,L=G*l+o,z=Math.sin(L),X=Math.cos(L);E.x=N*z,E.y=-R*n+m,E.z=N*X,h.push(E.x,E.y,E.z),b.set(z,v,X).normalize(),u.push(b.x,b.y,b.z),f.push(G,1-R),P.push(g++)}y.push(P)}for(let w=0;w<s;w++)for(let P=0;P<a;P++){const R=y[P][w],N=y[P+1][w],F=y[P+1][w+1],G=y[P][w+1];(e>0||P!==0)&&(d.push(R,N,G),S+=3),(t>0||P!==a-1)&&(d.push(N,F,G),S+=3)}c.addGroup(p,S,0),p+=S}function A(b){const E=g,S=new Ie,v=new D;let w=0;const P=b===!0?e:t,R=b===!0?1:-1;for(let F=1;F<=s;F++)h.push(0,m*R,0),u.push(0,R,0),f.push(.5,.5),g++;const N=g;for(let F=0;F<=s;F++){const L=F/s*l+o,z=Math.cos(L),X=Math.sin(L);v.x=P*X,v.y=m*R,v.z=P*z,h.push(v.x,v.y,v.z),u.push(0,R,0),S.x=z*.5+.5,S.y=X*.5*R+.5,f.push(S.x,S.y),g++}for(let F=0;F<s;F++){const G=E+F,L=N+F;b===!0?d.push(L,L+1,G):d.push(L+1,L,G),w+=3}c.addGroup(p,w,b===!0?1:2),p+=w}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new yn(e.radiusTop,e.radiusBottom,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}}class Nn extends yn{constructor(e=1,t=1,n=32,s=1,a=!1,r=0,o=Math.PI*2){super(0,e,t,n,s,a,r,o),this.type="ConeGeometry",this.parameters={radius:e,height:t,radialSegments:n,heightSegments:s,openEnded:a,thetaStart:r,thetaLength:o}}static fromJSON(e){return new Nn(e.radius,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}}class ir extends bt{constructor(e=[],t=[],n=1,s=0){super(),this.type="PolyhedronGeometry",this.parameters={vertices:e,indices:t,radius:n,detail:s};const a=[],r=[];o(s),c(n),d(),this.setAttribute("position",new st(a,3)),this.setAttribute("normal",new st(a.slice(),3)),this.setAttribute("uv",new st(r,2)),s===0?this.computeVertexNormals():this.normalizeNormals();function o(x){const A=new D,b=new D,E=new D;for(let S=0;S<t.length;S+=3)f(t[S+0],A),f(t[S+1],b),f(t[S+2],E),l(A,b,E,x)}function l(x,A,b,E){const S=E+1,v=[];for(let w=0;w<=S;w++){v[w]=[];const P=x.clone().lerp(b,w/S),R=A.clone().lerp(b,w/S),N=S-w;for(let F=0;F<=N;F++)F===0&&w===S?v[w][F]=P:v[w][F]=P.clone().lerp(R,F/N)}for(let w=0;w<S;w++)for(let P=0;P<2*(S-w)-1;P++){const R=Math.floor(P/2);P%2===0?(u(v[w][R+1]),u(v[w+1][R]),u(v[w][R])):(u(v[w][R+1]),u(v[w+1][R+1]),u(v[w+1][R]))}}function c(x){const A=new D;for(let b=0;b<a.length;b+=3)A.x=a[b+0],A.y=a[b+1],A.z=a[b+2],A.normalize().multiplyScalar(x),a[b+0]=A.x,a[b+1]=A.y,a[b+2]=A.z}function d(){const x=new D;for(let A=0;A<a.length;A+=3){x.x=a[A+0],x.y=a[A+1],x.z=a[A+2];const b=m(x)/2/Math.PI+.5,E=p(x)/Math.PI+.5;r.push(b,1-E)}g(),h()}function h(){for(let x=0;x<r.length;x+=6){const A=r[x+0],b=r[x+2],E=r[x+4],S=Math.max(A,b,E),v=Math.min(A,b,E);S>.9&&v<.1&&(A<.2&&(r[x+0]+=1),b<.2&&(r[x+2]+=1),E<.2&&(r[x+4]+=1))}}function u(x){a.push(x.x,x.y,x.z)}function f(x,A){const b=x*3;A.x=e[b+0],A.y=e[b+1],A.z=e[b+2]}function g(){const x=new D,A=new D,b=new D,E=new D,S=new Ie,v=new Ie,w=new Ie;for(let P=0,R=0;P<a.length;P+=9,R+=6){x.set(a[P+0],a[P+1],a[P+2]),A.set(a[P+3],a[P+4],a[P+5]),b.set(a[P+6],a[P+7],a[P+8]),S.set(r[R+0],r[R+1]),v.set(r[R+2],r[R+3]),w.set(r[R+4],r[R+5]),E.copy(x).add(A).add(b).divideScalar(3);const N=m(E);y(S,R+0,x,N),y(v,R+2,A,N),y(w,R+4,b,N)}}function y(x,A,b,E){E<0&&x.x===1&&(r[A]=x.x-1),b.x===0&&b.z===0&&(r[A]=E/2/Math.PI+.5)}function m(x){return Math.atan2(x.z,-x.x)}function p(x){return Math.atan2(-x.y,Math.sqrt(x.x*x.x+x.z*x.z))}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new ir(e.vertices,e.indices,e.radius,e.detail)}}class ji extends ir{constructor(e=1,t=0){const n=(1+Math.sqrt(5))/2,s=1/n,a=[-1,-1,-1,-1,-1,1,-1,1,-1,-1,1,1,1,-1,-1,1,-1,1,1,1,-1,1,1,1,0,-s,-n,0,-s,n,0,s,-n,0,s,n,-s,-n,0,-s,n,0,s,-n,0,s,n,0,-n,0,-s,n,0,-s,-n,0,s,n,0,s],r=[3,11,7,3,7,15,3,15,13,7,19,17,7,17,6,7,6,15,17,4,8,17,8,10,17,10,6,8,0,16,8,16,2,8,2,10,0,12,1,0,1,18,0,18,16,6,10,2,6,2,13,6,13,15,2,16,18,2,18,3,2,3,13,18,1,9,18,9,11,18,11,3,4,14,12,4,12,0,4,0,8,11,9,5,11,5,19,11,19,7,19,5,14,19,14,4,19,4,17,1,12,14,1,14,5,1,5,9];super(a,r,e,t),this.type="DodecahedronGeometry",this.parameters={radius:e,detail:t}}static fromJSON(e){return new ji(e.radius,e.detail)}}const Nr=new D,Ur=new D,Ol=new D,Fr=new Cn;class D0 extends bt{constructor(e=null,t=1){if(super(),this.type="EdgesGeometry",this.parameters={geometry:e,thresholdAngle:t},e!==null){const s=Math.pow(10,4),a=Math.cos(Zs*t),r=e.getIndex(),o=e.getAttribute("position"),l=r?r.count:o.count,c=[0,0,0],d=["a","b","c"],h=new Array(3),u=new Map,f=[];for(let g=0;g<l;g+=3){r?(c[0]=r.getX(g),c[1]=r.getX(g+1),c[2]=r.getX(g+2)):(c[0]=g,c[1]=g+1,c[2]=g+2);const{a:y,b:m,c:p}=Fr;if(y.fromBufferAttribute(o,c[0]),m.fromBufferAttribute(o,c[1]),p.fromBufferAttribute(o,c[2]),Fr.getNormal(Ol),h[0]=`${Math.round(y.x*s)},${Math.round(y.y*s)},${Math.round(y.z*s)}`,h[1]=`${Math.round(m.x*s)},${Math.round(m.y*s)},${Math.round(m.z*s)}`,h[2]=`${Math.round(p.x*s)},${Math.round(p.y*s)},${Math.round(p.z*s)}`,!(h[0]===h[1]||h[1]===h[2]||h[2]===h[0]))for(let x=0;x<3;x++){const A=(x+1)%3,b=h[x],E=h[A],S=Fr[d[x]],v=Fr[d[A]],w=`${b}_${E}`,P=`${E}_${b}`,R=u.get(P);R?(Ol.dot(R.normal)<=a&&(f.push(S.x,S.y,S.z),f.push(v.x,v.y,v.z)),u.set(P,null)):u.has(w)||u.set(w,{index0:c[x],index1:c[A],normal:Ol.clone()})}}for(const g of u.values())if(g){const{index0:y,index1:m}=g;Nr.fromBufferAttribute(o,y),Ur.fromBufferAttribute(o,m),f.push(Nr.x,Nr.y,Nr.z),f.push(Ur.x,Ur.y,Ur.z)}this.setAttribute("position",new st(f,3))}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}}class qn extends ir{constructor(e=1,t=0){const n=(1+Math.sqrt(5))/2,s=[-1,n,0,1,n,0,-1,-n,0,1,-n,0,0,-1,n,0,1,n,0,-1,-n,0,1,-n,n,0,-1,n,0,1,-n,0,-1,-n,0,1],a=[0,11,5,0,5,1,0,1,7,0,7,10,0,10,11,1,5,9,5,11,4,11,10,2,10,7,6,7,1,8,3,9,4,3,4,2,3,2,6,3,6,8,3,8,9,4,9,5,2,4,11,6,2,10,8,6,7,9,8,1];super(s,a,e,t),this.type="IcosahedronGeometry",this.parameters={radius:e,detail:t}}static fromJSON(e){return new qn(e.radius,e.detail)}}class pi extends ir{constructor(e=1,t=0){const n=[1,0,0,-1,0,0,0,1,0,0,-1,0,0,0,1,0,0,-1],s=[0,2,4,0,4,3,0,3,5,0,5,2,1,2,5,1,5,3,1,3,4,1,4,2];super(n,s,e,t),this.type="OctahedronGeometry",this.parameters={radius:e,detail:t}}static fromJSON(e){return new pi(e.radius,e.detail)}}class Fi extends bt{constructor(e=1,t=1,n=1,s=1){super(),this.type="PlaneGeometry",this.parameters={width:e,height:t,widthSegments:n,heightSegments:s};const a=e/2,r=t/2,o=Math.floor(n),l=Math.floor(s),c=o+1,d=l+1,h=e/o,u=t/l,f=[],g=[],y=[],m=[];for(let p=0;p<d;p++){const x=p*u-r;for(let A=0;A<c;A++){const b=A*h-a;g.push(b,-x,0),y.push(0,0,1),m.push(A/o),m.push(1-p/l)}}for(let p=0;p<l;p++)for(let x=0;x<o;x++){const A=x+c*p,b=x+c*(p+1),E=x+1+c*(p+1),S=x+1+c*p;f.push(A,b,S),f.push(b,E,S)}this.setIndex(f),this.setAttribute("position",new st(g,3)),this.setAttribute("normal",new st(y,3)),this.setAttribute("uv",new st(m,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Fi(e.width,e.height,e.widthSegments,e.heightSegments)}}class Yo extends bt{constructor(e=.5,t=1,n=32,s=1,a=0,r=Math.PI*2){super(),this.type="RingGeometry",this.parameters={innerRadius:e,outerRadius:t,thetaSegments:n,phiSegments:s,thetaStart:a,thetaLength:r},n=Math.max(3,n),s=Math.max(1,s);const o=[],l=[],c=[],d=[];let h=e;const u=(t-e)/s,f=new D,g=new Ie;for(let y=0;y<=s;y++){for(let m=0;m<=n;m++){const p=a+m/n*r;f.x=h*Math.cos(p),f.y=h*Math.sin(p),l.push(f.x,f.y,f.z),c.push(0,0,1),g.x=(f.x/t+1)/2,g.y=(f.y/t+1)/2,d.push(g.x,g.y)}h+=u}for(let y=0;y<s;y++){const m=y*(n+1);for(let p=0;p<n;p++){const x=p+m,A=x,b=x+n+1,E=x+n+2,S=x+1;o.push(A,b,S),o.push(b,E,S)}}this.setIndex(o),this.setAttribute("position",new st(l,3)),this.setAttribute("normal",new st(c,3)),this.setAttribute("uv",new st(d,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Yo(e.innerRadius,e.outerRadius,e.thetaSegments,e.phiSegments,e.thetaStart,e.thetaLength)}}class Nt extends bt{constructor(e=1,t=32,n=16,s=0,a=Math.PI*2,r=0,o=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:e,widthSegments:t,heightSegments:n,phiStart:s,phiLength:a,thetaStart:r,thetaLength:o},t=Math.max(3,Math.floor(t)),n=Math.max(2,Math.floor(n));const l=Math.min(r+o,Math.PI);let c=0;const d=[],h=new D,u=new D,f=[],g=[],y=[],m=[];for(let p=0;p<=n;p++){const x=[],A=p/n,b=r+A*o,E=e*Math.cos(b),S=Math.sqrt(e*e-E*E);let v=0;p===0&&r===0?v=.5/t:p===n&&l===Math.PI&&(v=-.5/t);for(let w=0;w<=t;w++){const P=w/t,R=s+P*a;h.x=-S*Math.cos(R),h.y=E,h.z=S*Math.sin(R),g.push(h.x,h.y,h.z),u.copy(h).normalize(),y.push(u.x,u.y,u.z),m.push(P+v,1-A),x.push(c++)}d.push(x)}for(let p=0;p<n;p++)for(let x=0;x<t;x++){const A=d[p][x+1],b=d[p][x],E=d[p+1][x],S=d[p+1][x+1];(p!==0||r>0)&&f.push(A,b,S),(p!==n-1||l<Math.PI)&&f.push(b,E,S)}this.setIndex(f),this.setAttribute("position",new st(g,3)),this.setAttribute("normal",new st(y,3)),this.setAttribute("uv",new st(m,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Nt(e.radius,e.widthSegments,e.heightSegments,e.phiStart,e.phiLength,e.thetaStart,e.thetaLength)}}class an extends bt{constructor(e=1,t=.4,n=12,s=48,a=Math.PI*2,r=0,o=Math.PI*2){super(),this.type="TorusGeometry",this.parameters={radius:e,tube:t,radialSegments:n,tubularSegments:s,arc:a,thetaStart:r,thetaLength:o},n=Math.floor(n),s=Math.floor(s);const l=[],c=[],d=[],h=[],u=new D,f=new D,g=new D;for(let y=0;y<=n;y++){const m=r+y/n*o;for(let p=0;p<=s;p++){const x=p/s*a;f.x=(e+t*Math.cos(m))*Math.cos(x),f.y=(e+t*Math.cos(m))*Math.sin(x),f.z=t*Math.sin(m),c.push(f.x,f.y,f.z),u.x=e*Math.cos(x),u.y=e*Math.sin(x),g.subVectors(f,u).normalize(),d.push(g.x,g.y,g.z),h.push(p/s),h.push(y/n)}}for(let y=1;y<=n;y++)for(let m=1;m<=s;m++){const p=(s+1)*y+m-1,x=(s+1)*(y-1)+m-1,A=(s+1)*(y-1)+m,b=(s+1)*y+m;l.push(p,x,b),l.push(x,A,b)}this.setIndex(l),this.setAttribute("position",new st(c,3)),this.setAttribute("normal",new st(d,3)),this.setAttribute("uv",new st(h,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new an(e.radius,e.tube,e.radialSegments,e.tubularSegments,e.arc,e.thetaStart,e.thetaLength)}}function la(i){const e={};for(const t in i){e[t]={};for(const n in i[t]){const s=i[t][n];if(Nh(s))s.isRenderTargetTexture?(Ue("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),e[t][n]=null):e[t][n]=s.clone();else if(Array.isArray(s))if(Nh(s[0])){const a=[];for(let r=0,o=s.length;r<o;r++)a[r]=s[r].clone();e[t][n]=a}else e[t][n]=s.slice();else e[t][n]=s}}return e}function mn(i){const e={};for(let t=0;t<i.length;t++){const n=la(i[t]);for(const s in n)e[s]=n[s]}return e}function Nh(i){return i&&(i.isColor||i.isMatrix3||i.isMatrix4||i.isVector2||i.isVector3||i.isVector4||i.isTexture||i.isQuaternion)}function I0(i){const e=[];for(let t=0;t<i.length;t++)e.push(i[t].clone());return e}function $f(i){const e=i.getRenderTarget();return e===null?i.outputColorSpace:e.isXRRenderTarget===!0?e.texture.colorSpace:et.workingColorSpace}const N0={clone:la,merge:mn};var U0=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,F0=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class Pn extends Oi{constructor(e){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=U0,this.fragmentShader=F0,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=la(e.uniforms),this.uniformsGroups=I0(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this.defaultAttributeValues=Object.assign({},e.defaultAttributeValues),this.index0AttributeName=e.index0AttributeName,this.uniformsNeedUpdate=e.uniformsNeedUpdate,this}toJSON(e){const t=super.toJSON(e);t.glslVersion=this.glslVersion,t.uniforms={};for(const s in this.uniforms){const r=this.uniforms[s].value;r&&r.isTexture?t.uniforms[s]={type:"t",value:r.toJSON(e).uuid}:r&&r.isColor?t.uniforms[s]={type:"c",value:r.getHex()}:r&&r.isVector2?t.uniforms[s]={type:"v2",value:r.toArray()}:r&&r.isVector3?t.uniforms[s]={type:"v3",value:r.toArray()}:r&&r.isVector4?t.uniforms[s]={type:"v4",value:r.toArray()}:r&&r.isMatrix3?t.uniforms[s]={type:"m3",value:r.toArray()}:r&&r.isMatrix4?t.uniforms[s]={type:"m4",value:r.toArray()}:t.uniforms[s]={value:r}}Object.keys(this.defines).length>0&&(t.defines=this.defines),t.vertexShader=this.vertexShader,t.fragmentShader=this.fragmentShader,t.lights=this.lights,t.clipping=this.clipping;const n={};for(const s in this.extensions)this.extensions[s]===!0&&(n[s]=!0);return Object.keys(n).length>0&&(t.extensions=n),t}fromJSON(e,t){if(super.fromJSON(e,t),e.uniforms!==void 0)for(const n in e.uniforms){const s=e.uniforms[n];switch(this.uniforms[n]={},s.type){case"t":this.uniforms[n].value=t[s.value]||null;break;case"c":this.uniforms[n].value=new Ce().setHex(s.value);break;case"v2":this.uniforms[n].value=new Ie().fromArray(s.value);break;case"v3":this.uniforms[n].value=new D().fromArray(s.value);break;case"v4":this.uniforms[n].value=new Tt().fromArray(s.value);break;case"m3":this.uniforms[n].value=new ke().fromArray(s.value);break;case"m4":this.uniforms[n].value=new tt().fromArray(s.value);break;default:this.uniforms[n].value=s.value}}if(e.defines!==void 0&&(this.defines=e.defines),e.vertexShader!==void 0&&(this.vertexShader=e.vertexShader),e.fragmentShader!==void 0&&(this.fragmentShader=e.fragmentShader),e.glslVersion!==void 0&&(this.glslVersion=e.glslVersion),e.extensions!==void 0)for(const n in e.extensions)this.extensions[n]=e.extensions[n];return e.lights!==void 0&&(this.lights=e.lights),e.clipping!==void 0&&(this.clipping=e.clipping),this}}class O0 extends Pn{constructor(e){super(e),this.isRawShaderMaterial=!0,this.type="RawShaderMaterial"}}class $t extends Oi{constructor(e){super(),this.isMeshStandardMaterial=!0,this.type="MeshStandardMaterial",this.defines={STANDARD:""},this.color=new Ce(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new Ce(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=po,this.normalScale=new Ie(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Wn,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.defines={STANDARD:""},this.color.copy(e.color),this.roughness=e.roughness,this.metalness=e.metalness,this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.roughnessMap=e.roughnessMap,this.metalnessMap=e.metalnessMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.envMapIntensity=e.envMapIntensity,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}}class k0 extends Oi{constructor(e){super(),this.isMeshLambertMaterial=!0,this.type="MeshLambertMaterial",this.color=new Ce(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new Ce(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=po,this.normalScale=new Ie(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Wn,this.combine=hd,this.reflectivity=1,this.envMapIntensity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.envMapIntensity=e.envMapIntensity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}}class B0 extends Oi{constructor(e){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=Fm,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}}class z0 extends Oi{constructor(e){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}}class Ko extends Ut{static registerNode(e){this.prototype._lightNode=e}constructor(e,t=1){super(),this.isLight=!0,this.type="Light",this.color=new Ce(e),this.intensity=t}copy(e,t){return super.copy(e,t),this.color.copy(e.color),this.intensity=e.intensity,this}toJSON(e){const t=super.toJSON(e);return t.object.color=this.color.getHex(),t.object.intensity=this.intensity,t}}class Hf extends Ko{constructor(e,t,n){super(e,n),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(Ut.DEFAULT_UP),this.updateMatrix(),this.groundColor=new Ce(t)}copy(e,t){return super.copy(e,t),this.groundColor.copy(e.groundColor),this}toJSON(e){const t=super.toJSON(e);return t.object.groundColor=this.groundColor.getHex(),t}}const kl=new tt,Uh=new D,Fh=new D;class Gf{constructor(e){this.camera=e,this.intensity=1,this.bias=0,this.biasNode=null,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new Ie(512,512),this.mapType=wn,this.map=null,this.mapPass=null,this.matrix=new tt,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new Xa,this._frameExtents=new Ie(1,1),this._viewportCount=1,this._viewports=[new Tt(0,0,1,1)]}getViewportCount(){return this._viewportCount}getCamera(){return this.camera}getFrustum(){return this._frustum}updateMatrices(e){const t=this.camera;Uh.setFromMatrixPosition(e.matrixWorld),t.position.copy(Uh),Fh.setFromMatrixPosition(e.target.matrixWorld),t.lookAt(Fh),t.updateMatrixWorld(),this._updateMatrix(t,this.matrix,this._frustum)}_updateMatrix(e,t,n,s){kl.multiplyMatrices(e.projectionMatrix,e.matrixWorldInverse),n.setFromProjectionMatrix(kl,e.coordinateSystem,e.reversedDepth);const a=this._frameExtents,r=s?s.z/a.x:1,o=s?s.w/a.y:1,l=s?s.x/a.x:0,c=s?s.y/a.y:0;e.coordinateSystem===Va||e.reversedDepth?t.set(.5*r,0,0,.5*r+l,0,.5*o,0,.5*o+c,0,0,1,0,0,0,0,1):t.set(.5*r,0,0,.5*r+l,0,.5*o,0,.5*o+c,0,0,.5,.5,0,0,0,1),t.multiply(kl)}getViewport(e){return this._viewports[e]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(e){return this.camera=e.camera.clone(),this.intensity=e.intensity,this.bias=e.bias,this.radius=e.radius,this.autoUpdate=e.autoUpdate,this.needsUpdate=e.needsUpdate,this.normalBias=e.normalBias,this.blurSamples=e.blurSamples,this.mapSize.copy(e.mapSize),this.mapType=e.mapType,this.biasNode=e.biasNode,this}clone(){return new this.constructor().copy(this)}toJSON(){const e={};return e.intensity=this.intensity,e.bias=this.bias,e.normalBias=this.normalBias,e.radius=this.radius,e.blurSamples=this.blurSamples,e.mapSize=this.mapSize.toArray(),e.mapType=this.mapType,e.camera=this.camera.toJSON(!1).object,delete e.camera.matrix,e}}const Or=new D,kr=new Ui,oi=new D;class Vf extends Ut{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new tt,this.projectionMatrix=new tt,this.projectionMatrixInverse=new tt,this.coordinateSystem=si,this._reversedDepth=!1}get reversedDepth(){return this._reversedDepth}copy(e,t){return super.copy(e,t),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorld.decompose(Or,kr,oi),oi.x===1&&oi.y===1&&oi.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(Or,kr,oi.set(1,1,1)).invert()}updateWorldMatrix(e,t,n=!1){super.updateWorldMatrix(e,t,n),this.matrixWorld.decompose(Or,kr,oi),oi.x===1&&oi.y===1&&oi.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(Or,kr,oi.set(1,1,1)).invert()}clone(){return new this.constructor().copy(this)}}const Vi=new D,Oh=new Ie,kh=new Ie;class bn extends Vf{constructor(e=50,t=1,n=.1,s=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=n,this.far=s,this.focus=10,this.aspect=t,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){const t=.5*this.getFilmHeight()/e;this.fov=Wa*2*Math.atan(t),this.updateProjectionMatrix()}getFocalLength(){const e=Math.tan(Zs*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return Wa*2*Math.atan(Math.tan(Zs*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(e,t,n){Vi.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),t.set(Vi.x,Vi.y).multiplyScalar(-e/Vi.z),Vi.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),n.set(Vi.x,Vi.y).multiplyScalar(-e/Vi.z)}getViewSize(e,t){return this.getViewBounds(e,Oh,kh),t.subVectors(kh,Oh)}setViewOffset(e,t,n,s,a,r){this.aspect=e/t,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=s,this.view.width=a,this.view.height=r,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=this.near;let t=e*Math.tan(Zs*.5*this.fov)/this.zoom,n=2*t,s=this.aspect*n,a=-.5*s;const r=this.view;if(this.view!==null&&this.view.enabled){const l=r.fullWidth,c=r.fullHeight;a+=r.offsetX*s/l,t-=r.offsetY*n/c,s*=r.width/l,n*=r.height/c}const o=this.filmOffset;o!==0&&(a+=e*o/this.getFilmWidth()),this.projectionMatrix.makePerspective(a,a+s,t,t-n,e,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.fov=this.fov,t.object.zoom=this.zoom,t.object.near=this.near,t.object.far=this.far,t.object.focus=this.focus,t.object.aspect=this.aspect,this.view!==null&&(t.object.view=Object.assign({},this.view)),t.object.filmGauge=this.filmGauge,t.object.filmOffset=this.filmOffset,t}}class $0 extends Gf{constructor(){super(new bn(90,1,.5,500)),this.isPointLightShadow=!0}}class Wf extends Ko{constructor(e,t,n=0,s=2){super(e,t),this.isPointLight=!0,this.type="PointLight",this.distance=n,this.decay=s,this.shadow=new $0}get power(){return this.intensity*4*Math.PI}set power(e){this.intensity=e/(4*Math.PI)}dispose(){super.dispose(),this.shadow.dispose()}copy(e,t){return super.copy(e,t),this.distance=e.distance,this.decay=e.decay,this.shadow=e.shadow.clone(),this}toJSON(e){const t=super.toJSON(e);return t.object.distance=this.distance,t.object.decay=this.decay,t.object.shadow=this.shadow.toJSON(),t}}class Ad extends Vf{constructor(e=-1,t=1,n=1,s=-1,a=.1,r=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=t,this.top=n,this.bottom=s,this.near=a,this.far=r,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,t,n,s,a,r){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=s,this.view.width=a,this.view.height=r,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=(this.right-this.left)/(2*this.zoom),t=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,s=(this.top+this.bottom)/2;let a=n-e,r=n+e,o=s+t,l=s-t;if(this.view!==null&&this.view.enabled){const c=(this.right-this.left)/this.view.fullWidth/this.zoom,d=(this.top-this.bottom)/this.view.fullHeight/this.zoom;a+=c*this.view.offsetX,r=a+c*this.view.width,o-=d*this.view.offsetY,l=o-d*this.view.height}this.projectionMatrix.makeOrthographic(a,r,o,l,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.zoom=this.zoom,t.object.left=this.left,t.object.right=this.right,t.object.top=this.top,t.object.bottom=this.bottom,t.object.near=this.near,t.object.far=this.far,this.view!==null&&(t.object.view=Object.assign({},this.view)),t}}class H0 extends Gf{constructor(){super(new Ad(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}}class Eo extends Ko{constructor(e,t){super(e,t),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(Ut.DEFAULT_UP),this.updateMatrix(),this.target=new Ut,this.shadow=new H0}dispose(){super.dispose(),this.shadow.dispose()}copy(e){return super.copy(e),this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}toJSON(e){const t=super.toJSON(e);return t.object.shadow=this.shadow.toJSON(),t.object.target=this.target.uuid,t}}class Xf extends Ko{constructor(e,t){super(e,t),this.isAmbientLight=!0,this.type="AmbientLight"}}const Gs=-90,Vs=1;class Hc extends Ut{constructor(e,t,n){super(),this.type="CubeCamera",this.renderTarget=n,this.coordinateSystem=null,this.activeMipmapLevel=0;const s=new bn(Gs,Vs,e,t);s.layers=this.layers,this.add(s);const a=new bn(Gs,Vs,e,t);a.layers=this.layers,this.add(a);const r=new bn(Gs,Vs,e,t);r.layers=this.layers,this.add(r);const o=new bn(Gs,Vs,e,t);o.layers=this.layers,this.add(o);const l=new bn(Gs,Vs,e,t);l.layers=this.layers,this.add(l);const c=new bn(Gs,Vs,e,t);c.layers=this.layers,this.add(c)}updateCoordinateSystem(){const e=this.coordinateSystem,t=this.children.concat(),[n,s,a,r,o,l]=t;for(const c of t)this.remove(c);if(e===si)n.up.set(0,1,0),n.lookAt(1,0,0),s.up.set(0,1,0),s.lookAt(-1,0,0),a.up.set(0,0,-1),a.lookAt(0,1,0),r.up.set(0,0,1),r.lookAt(0,-1,0),o.up.set(0,1,0),o.lookAt(0,0,1),l.up.set(0,1,0),l.lookAt(0,0,-1);else if(e===Va)n.up.set(0,-1,0),n.lookAt(-1,0,0),s.up.set(0,-1,0),s.lookAt(1,0,0),a.up.set(0,0,1),a.lookAt(0,1,0),r.up.set(0,0,-1),r.lookAt(0,-1,0),o.up.set(0,-1,0),o.lookAt(0,0,1),l.up.set(0,-1,0),l.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+e);for(const c of t)this.add(c),c.updateMatrixWorld()}update(e,t){this.parent===null&&this.updateMatrixWorld();const{renderTarget:n,activeMipmapLevel:s}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());const[a,r,o,l,c,d]=this.children,h=e.getRenderTarget(),u=e.getActiveCubeFace(),f=e.getActiveMipmapLevel(),g=e.xr.enabled;e.xr.enabled=!1;const y=n.texture.mipmapsAutoUpdate;n.texture.mipmapsAutoUpdate=!1;let m=!1;e.isWebGLRenderer===!0?m=e.state.buffers.depth.getReversed():m=e.reversedDepthBuffer,e.setRenderTarget(n,0,s),m&&e.autoClear===!1&&e.clearDepth(),e.render(t,a),e.setRenderTarget(n,1,s),m&&e.autoClear===!1&&e.clearDepth(),e.render(t,r),e.setRenderTarget(n,2,s),m&&e.autoClear===!1&&e.clearDepth(),e.render(t,o),e.setRenderTarget(n,3,s),m&&e.autoClear===!1&&e.clearDepth(),e.render(t,l),e.setRenderTarget(n,4,s),m&&e.autoClear===!1&&e.clearDepth(),e.render(t,c),n.texture.mipmapsAutoUpdate=y,e.setRenderTarget(n,5,s),m&&e.autoClear===!1&&e.clearDepth(),e.render(t,d),e.setRenderTarget(h,u,f),e.xr.enabled=g,n.texture.needsPMREMUpdate=!0}}class G0 extends bn{constructor(e=[]){super(),this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=e,this.perCameraFrustumCulled=!1}}const Bh=new tt;class qf{constructor(e,t,n=0,s=1/0){this.ray=new Xo(e,t),this.near=n,this.far=s,this.camera=null,this.layers=new Sd,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(e,t){this.ray.set(e,t)}setFromCamera(e,t){t.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(t.matrixWorld),this.ray.direction.set(e.x,e.y,.5).unproject(t).sub(this.ray.origin).normalize(),this.camera=t):t.isOrthographicCamera?(this.ray.origin.set(e.x,e.y,t.projectionMatrix.elements[14]).unproject(t),this.ray.direction.set(0,0,-1).transformDirection(t.matrixWorld),this.camera=t):it("Raycaster: Unsupported camera type: "+t.type)}setFromXRController(e){return Bh.identity().extractRotation(e.matrixWorld),this.ray.origin.setFromMatrixPosition(e.matrixWorld),this.ray.direction.set(0,0,-1).applyMatrix4(Bh),this}intersectObject(e,t=!0,n=[]){return Gc(e,this,n,t),n.sort(zh),n}intersectObjects(e,t=!0,n=[]){for(let s=0,a=e.length;s<a;s++)Gc(e[s],this,n,t);return n.sort(zh),n}}function zh(i,e){return i.distance-e.distance}function Gc(i,e,t,n){let s=!0;if(i.layers.test(e.layers)&&i.raycast(e,t)===!1&&(s=!1),s===!0&&n===!0){const a=i.children;for(let r=0,o=a.length;r<o;r++)Gc(a[r],e,t,!0)}}function $h(i,e,t,n){const s=V0(n);switch(t){case wf:return i*e;case gd:return i*e/s.components*s.byteLength;case vd:return i*e/s.components*s.byteLength;case ys:return i*e*2/s.components*s.byteLength;case yd:return i*e*2/s.components*s.byteLength;case Sf:return i*e*3/s.components*s.byteLength;case hi:return i*e*4/s.components*s.byteLength;case xd:return i*e*4/s.components*s.byteLength;case jr:case Qr:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*8;case eo:case to:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case hc:case fc:return Math.max(i,16)*Math.max(e,8)/4;case dc:case uc:return Math.max(i,8)*Math.max(e,8)/2;case pc:case mc:case vc:case yc:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*8;case gc:case uo:case xc:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case bc:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case _c:return Math.floor((i+4)/5)*Math.floor((e+3)/4)*16;case Mc:return Math.floor((i+4)/5)*Math.floor((e+4)/5)*16;case wc:return Math.floor((i+5)/6)*Math.floor((e+4)/5)*16;case Sc:return Math.floor((i+5)/6)*Math.floor((e+5)/6)*16;case Ec:return Math.floor((i+7)/8)*Math.floor((e+4)/5)*16;case Ac:return Math.floor((i+7)/8)*Math.floor((e+5)/6)*16;case Tc:return Math.floor((i+7)/8)*Math.floor((e+7)/8)*16;case Rc:return Math.floor((i+9)/10)*Math.floor((e+4)/5)*16;case Cc:return Math.floor((i+9)/10)*Math.floor((e+5)/6)*16;case Pc:return Math.floor((i+9)/10)*Math.floor((e+7)/8)*16;case Lc:return Math.floor((i+9)/10)*Math.floor((e+9)/10)*16;case Dc:return Math.floor((i+11)/12)*Math.floor((e+9)/10)*16;case Ic:return Math.floor((i+11)/12)*Math.floor((e+11)/12)*16;case Nc:case Uc:case Fc:return Math.ceil(i/4)*Math.ceil(e/4)*16;case Oc:case kc:return Math.ceil(i/4)*Math.ceil(e/4)*8;case fo:case Bc:return Math.ceil(i/4)*Math.ceil(e/4)*16}throw new Error(`Unable to determine texture byte length for ${t} format.`)}function V0(i){switch(i){case wn:case xf:return{byteLength:1,components:1};case Ga:case bf:case gi:return{byteLength:2,components:1};case pd:case md:return{byteLength:2,components:4};case mi:case fd:case ii:return{byteLength:4,components:1};case _f:case Mf:return{byteLength:4,components:3}}throw new Error(`THREE.TextureUtils: Unknown texture type ${i}.`)}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:dd}}));typeof window<"u"&&(window.__THREE__?Ue("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=dd);function Yf(){let i=null,e=!1,t=null,n=null;function s(a,r){n=i.requestAnimationFrame(s),t(a,r)}return{start:function(){e!==!0&&t!==null&&i!==null&&(n=i.requestAnimationFrame(s),e=!0)},stop:function(){i!==null&&i.cancelAnimationFrame(n),e=!1},setAnimationLoop:function(a){t=a},setContext:function(a){i=a}}}function W0(i){const e=new WeakMap;function t(o,l){const c=o.array,d=o.usage,h=c.byteLength,u=i.createBuffer();i.bindBuffer(l,u),i.bufferData(l,c,d),o.onUploadCallback();let f;if(c instanceof Float32Array)f=i.FLOAT;else if(typeof Float16Array<"u"&&c instanceof Float16Array)f=i.HALF_FLOAT;else if(c instanceof Uint16Array)o.isFloat16BufferAttribute?f=i.HALF_FLOAT:f=i.UNSIGNED_SHORT;else if(c instanceof Int16Array)f=i.SHORT;else if(c instanceof Uint32Array)f=i.UNSIGNED_INT;else if(c instanceof Int32Array)f=i.INT;else if(c instanceof Int8Array)f=i.BYTE;else if(c instanceof Uint8Array)f=i.UNSIGNED_BYTE;else if(c instanceof Uint8ClampedArray)f=i.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+c);return{buffer:u,type:f,bytesPerElement:c.BYTES_PER_ELEMENT,version:o.version,size:h}}function n(o,l,c){const d=l.array,h=l.updateRanges;if(i.bindBuffer(c,o),h.length===0)i.bufferSubData(c,0,d);else{h.sort((f,g)=>f.start-g.start);let u=0;for(let f=1;f<h.length;f++){const g=h[u],y=h[f];y.start<=g.start+g.count+1?g.count=Math.max(g.count,y.start+y.count-g.start):(++u,h[u]=y)}h.length=u+1;for(let f=0,g=h.length;f<g;f++){const y=h[f];i.bufferSubData(c,y.start*d.BYTES_PER_ELEMENT,d,y.start,y.count)}l.clearUpdateRanges()}l.onUploadCallback()}function s(o){return o.isInterleavedBufferAttribute&&(o=o.data),e.get(o)}function a(o){o.isInterleavedBufferAttribute&&(o=o.data);const l=e.get(o);l&&(i.deleteBuffer(l.buffer),e.delete(o))}function r(o,l){if(o.isInterleavedBufferAttribute&&(o=o.data),o.isGLBufferAttribute){const d=e.get(o);(!d||d.version<o.version)&&e.set(o,{buffer:o.buffer,type:o.type,bytesPerElement:o.elementSize,version:o.version});return}const c=e.get(o);if(c===void 0)e.set(o,t(o,l));else if(c.version<o.version){if(c.size!==o.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");n(c.buffer,o,l),c.version=o.version}}return{get:s,remove:a,update:r}}var X0=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,q0=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,Y0=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,K0=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Z0=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,J0=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,j0=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,Q0=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,eg=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec4 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 );
	}
#endif`,tg=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,ng=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,ig=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,sg=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,ag=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,rg=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,og=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,lg=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,cg=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,dg=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,hg=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#endif`,ug=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#endif`,fg=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec4 vColor;
#endif`,pg=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec4( 1.0 );
#endif
#ifdef USE_COLOR_ALPHA
	vColor *= color;
#elif defined( USE_COLOR )
	vColor.rgb *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.rgb *= instanceColor.rgb;
#endif
#ifdef USE_BATCHING_COLOR
	vColor *= getBatchingColor( getIndirectIndex( gl_DrawID ) );
#endif`,mg=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
#define inverseTransformDirection transformDirectionByInverseViewMatrix
vec3 transformNormalByInverseViewMatrix( in vec3 normal, in mat4 viewMatrix ) {
	return normalize( ( vec4( normal, 0.0 ) * viewMatrix ).xyz );
}
vec3 transformDirectionByInverseViewMatrix( in vec3 dir, in mat4 viewMatrix ) {
	return normalize( ( vec4( dir, 0.0 ) * viewMatrix ).xyz );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,gg=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
#endif`,vg=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,yg=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,xg=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,bg=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,_g="gl_FragColor = linearToOutputTexel( gl_FragColor );",Mg=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,wg=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * reflectVec );
		#ifdef ENVMAP_BLENDING_MULTIPLY
			outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_MIX )
			outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_ADD )
			outgoingLight += envColor.xyz * specularStrength * reflectivity;
		#endif
	#endif
#endif`,Sg=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform mat3 envMapRotation;
	uniform samplerCube envMap;
	#ifdef ENVMAP_TYPE_PMREM
		float roughnessToMip( const in float roughness ) {
			float r = clamp( roughness, 0.0, 1.0 );
			return ENVMAP_MAX_LOD * r * ( 2.0 - r );
		}
	#endif
#endif`,Eg=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,Ag=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,Tg=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,Rg=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,Cg=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,Pg=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,Lg=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,Dg=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,Ig=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,Ng=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,Ug=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,Fg=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_SUN_LIGHTS > 0
	struct SunLight {
		vec3 direction;
		vec3 color;
	};
	uniform SunLight sunLights[ NUM_SUN_LIGHTS ];
	void getSunLightInfo( const in SunLight sunLight, out IncidentLight light ) {
		light.color = sunLight.color;
		light.direction = sunLight.direction;
		light.visible = true;
	}
#endif
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif
#include <lightprobes_pars_fragment>`,Og=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_PMREM
			vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
			vec4 envMapColor = textureLod( envMap, envMapRotation * worldNormal, ENVMAP_MAX_LOD );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_PMREM
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, pow4( roughness ) ) );
			reflectVec = transformDirectionByInverseViewMatrix( reflectVec, viewMatrix );
			vec4 envMapColor = textureLod( envMap, envMapRotation * reflectVec, roughnessToMip( roughness ) );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_RETROREFLECTION
		vec3 getIBLRetroRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
			#ifdef ENVMAP_TYPE_PMREM
				vec3 retroVec = normalize( mix( viewDir, normal, pow4( roughness ) ) );
				retroVec = transformDirectionByInverseViewMatrix( retroVec, viewMatrix );
				vec4 envMapColor = textureLod( envMap, envMapRotation * retroVec, roughnessToMip( roughness ) );
				return envMapColor.rgb * envMapIntensity;
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_PMREM
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
		#ifdef USE_RETROREFLECTION
			vec3 getIBLAnisotropyRetroRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
				#ifdef ENVMAP_TYPE_PMREM
					vec3 bentNormal = cross( bitangent, viewDir );
					bentNormal = normalize( cross( bentNormal, bitangent ) );
					bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
					return getIBLRetroRadiance( viewDir, bentNormal, roughness );
				#else
					return vec3( 0.0 );
				#endif
			}
		#endif
	#endif
#endif`,kg=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,Bg=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,zg=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,$g=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,Hg=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.diffuseContribution = diffuseColor.rgb * ( 1.0 - metalnessFactor );
material.metalness = metalnessFactor;
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.045 );
material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef USE_DIFFUSE_ROUGHNESS
	float diffuseRoughnessFactor = diffuseRoughness;
	#ifdef USE_DIFFUSE_ROUGHNESSMAP
		diffuseRoughnessFactor *= texture2D( diffuseRoughnessMap, vDiffuseRoughnessMapUv ).r;
	#endif
	material.diffuseRoughness = saturate( diffuseRoughnessFactor );
#endif
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor;
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = vec3( 0.04 );
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.045 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_RETROREFLECTION
	material.retroreflectivity = retroreflectivity;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.0001, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,Gg=`uniform sampler2D dfgLUT;
struct PhysicalMaterial {
	vec3 diffuseColor;
	vec3 diffuseContribution;
	vec3 specularColor;
	vec3 specularColorBlended;
	float roughness;
	float metalness;
	float specularF90;
	float dispersion;
	vec2 dfg;
	vec3 multiScatteringCompensation;
	#ifdef USE_DIFFUSE_ROUGHNESS
		float diffuseRoughness;
	#endif
	#ifdef USE_RETROREFLECTION
		float retroreflectivity;
	#endif
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0Dielectric;
		vec3 iridescenceF0Metallic;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
#ifdef USE_DIFFUSE_ROUGHNESS
	const float EON_EPSILON = 1e-7;
	float FON_DirectionalAlbedo( const in float mu, const in float roughness, const in float A ) {
		float muComp = 1.0 - mu;
		float gOverPi = muComp * ( 0.0571085289 + muComp * ( 0.491881867 + muComp * ( - 0.332181442 + muComp * 0.0714429953 ) ) );
		return A * ( 1.0 + roughness * gOverPi );
	}
	vec3 BRDF_EON( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 diffuseColor, const in float roughness ) {
		vec3 rho = saturate( diffuseColor );
		if ( roughness <= EON_EPSILON ) return BRDF_Lambert( rho );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float s = dot( lightDir, viewDir ) - dotNL * dotNV;
		float sOverT = ( s > 0.0 ) ? s / max( max( dotNL, dotNV ), EON_EPSILON ) : s;
		float A = 1.0 / ( 1.0 + ( 0.5 - 2.0 / ( 3.0 * PI ) ) * roughness );
		vec3 singleScatter = rho * RECIPROCAL_PI * A * ( 1.0 + roughness * sOverT );
		float averageAlbedo = A * ( 1.0 + ( 2.0 / 3.0 - 28.0 / ( 15.0 * PI ) ) * roughness );
		float albedoV = FON_DirectionalAlbedo( dotNV, roughness, A );
		float albedoL = FON_DirectionalAlbedo( dotNL, roughness, A );
		vec3 rhoMultiScatter = rho * rho * averageAlbedo / max( vec3( EON_EPSILON ), vec3( 1.0 ) - rho * ( 1.0 - averageAlbedo ) );
		vec3 multiScatter = rhoMultiScatter * RECIPROCAL_PI
			* max( EON_EPSILON, 1.0 - albedoV )
			* max( EON_EPSILON, 1.0 - albedoL )
			/ max( EON_EPSILON, 1.0 - averageAlbedo );
		return singleScatter + multiScatter;
	}
	vec3 EON_DirectionalAlbedo( const in vec3 diffuseColor, const in float roughness, const in float dotNV ) {
		vec3 rho = saturate( diffuseColor );
		if ( roughness <= EON_EPSILON ) return rho;
		float A = 1.0 / ( 1.0 + ( 0.5 - 2.0 / ( 3.0 * PI ) ) * roughness );
		float directionalAlbedo = FON_DirectionalAlbedo( dotNV, roughness, A );
		float averageAlbedo = A * ( 1.0 + ( 2.0 / 3.0 - 28.0 / ( 15.0 * PI ) ) * roughness );
		vec3 rhoMultiScatter = rho * rho * averageAlbedo / max( vec3( EON_EPSILON ), vec3( 1.0 ) - rho * ( 1.0 - averageAlbedo ) );
		return rho * directionalAlbedo + rhoMultiScatter * ( 1.0 - directionalAlbedo );
	}
#endif
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		return 0.5 / max( gv + gl, EPSILON );
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = max( material.clearcoatRoughness, 0.045 );
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColorBlended;
	float f90 = material.specularF90;
	float roughness = max( material.roughness, 0.045 );
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float alphaT = max( material.alphaT, alpha );
		float V = V_GGX_SmithCorrelated_Anisotropic( alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transpose( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float rInv = 1.0 / ( roughness + 0.1 );
	float a = -1.9362 + 1.0678 * roughness + 0.4573 * r2 - 0.8469 * rInv;
	float b = -0.6014 + 0.5538 * roughness - 0.4670 * r2 - 0.1255 * rInv;
	float DG = exp( a * dotNV + b );
	return saturate( DG );
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec2 fab, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec2 fab, const in vec3 specularColor, const in float specularF90, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColorBlended * t2.x + ( material.specularF90 - material.specularColorBlended ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseContribution * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
		#ifdef USE_CLEARCOAT
			vec3 Ncc = geometryClearcoatNormal;
			vec2 uvClearcoat = LTC_Uv( Ncc, viewDir, material.clearcoatRoughness );
			vec4 t1Clearcoat = texture2D( ltc_1, uvClearcoat );
			vec4 t2Clearcoat = texture2D( ltc_2, uvClearcoat );
			mat3 mInvClearcoat = mat3(
				vec3( t1Clearcoat.x, 0, t1Clearcoat.y ),
				vec3(             0, 1,             0 ),
				vec3( t1Clearcoat.z, 0, t1Clearcoat.w )
			);
			vec3 fresnelClearcoat = material.clearcoatF0 * t2Clearcoat.x + ( material.clearcoatF90 - material.clearcoatF0 ) * t2Clearcoat.y;
			clearcoatSpecularDirect += lightColor * fresnelClearcoat * LTC_Evaluate( Ncc, viewDir, position, mInvClearcoat, rectCoords );
		#endif
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
 
 		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
 
 		float sheenAlbedoV = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
 		float sheenAlbedoL = IBLSheenBRDF( geometryNormal, directLight.direction, material.sheenRoughness );
 
 		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * max( sheenAlbedoV, sheenAlbedoL );
 
 		irradiance *= sheenEnergyComp;
 
 	#endif
	vec3 specularBRDF = BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	#ifdef USE_RETROREFLECTION
		vec3 retroViewDir = reflect( - geometryViewDir, geometryNormal );
		vec3 retroSpecularBRDF = BRDF_GGX( directLight.direction, retroViewDir, geometryNormal, material );
		specularBRDF = mix( specularBRDF, retroSpecularBRDF, saturate( material.retroreflectivity ) );
	#endif
	reflectedLight.directSpecular += irradiance * specularBRDF * material.multiScatteringCompensation;
	vec3 halfDir = normalize( directLight.direction + geometryViewDir );
	float dotVH = saturate( dot( geometryViewDir, halfDir ) );
	vec3 F = F_Schlick( material.specularColor, material.specularF90, dotVH );
	#ifdef USE_RETROREFLECTION
		vec3 retroHalfDir = normalize( directLight.direction + retroViewDir );
		float dotRetroVH = saturate( dot( retroViewDir, retroHalfDir ) );
		vec3 retroF = F_Schlick( material.specularColor, material.specularF90, dotRetroVH );
		F = mix( F, retroF, saturate( material.retroreflectivity ) );
	#endif
	#ifdef USE_DIFFUSE_ROUGHNESS
		vec3 diffuseBRDF = BRDF_EON( directLight.direction, geometryViewDir, geometryNormal, material.diffuseColor, material.diffuseRoughness ) * ( 1.0 - material.metalness );
	#else
		vec3 diffuseBRDF = BRDF_Lambert( material.diffuseContribution );
	#endif
	reflectedLight.directDiffuse += irradiance * diffuseBRDF * ( 1.0 - F );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( material.dfg, material.specularColor, material.specularF90, material.iridescence, material.iridescenceF0Dielectric, singleScattering, multiScattering );
	#else
		computeMultiscattering( material.dfg, material.specularColor, material.specularF90, singleScattering, multiScattering );
	#endif
	#ifdef USE_DIFFUSE_ROUGHNESS
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		vec3 diffuseAlbedo = EON_DirectionalAlbedo( material.diffuseColor, material.diffuseRoughness, dotNV ) * ( 1.0 - material.metalness );
		vec3 diffuse = irradiance * RECIPROCAL_PI * diffuseAlbedo * ( 1.0 - singleScattering - multiScattering );
	#else
		vec3 diffuse = irradiance * BRDF_Lambert( material.diffuseContribution ) * ( 1.0 - singleScattering - multiScattering );
	#endif
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		sheenSpecularIndirect += irradiance * material.sheenColor * sheenAlbedo * RECIPROCAL_PI;
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		diffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectDiffuse += diffuse;
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness ) * RECIPROCAL_PI;
 	#endif
	vec3 singleScatteringDielectric = vec3( 0.0 );
	vec3 multiScatteringDielectric = vec3( 0.0 );
	vec3 singleScatteringMetallic = vec3( 0.0 );
	vec3 multiScatteringMetallic = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( material.dfg, material.specularColor, material.specularF90, material.iridescence, material.iridescenceF0Dielectric, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscatteringIridescence( material.dfg, material.diffuseColor, material.specularF90, material.iridescence, material.iridescenceF0Metallic, singleScatteringMetallic, multiScatteringMetallic );
	#else
		computeMultiscattering( material.dfg, material.specularColor, material.specularF90, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscattering( material.dfg, material.diffuseColor, material.specularF90, singleScatteringMetallic, multiScatteringMetallic );
	#endif
	vec3 singleScattering = mix( singleScatteringDielectric, singleScatteringMetallic, material.metalness );
	vec3 multiScattering = mix( multiScatteringDielectric, multiScatteringMetallic, material.metalness );
	vec3 totalScatteringDielectric = singleScatteringDielectric + multiScatteringDielectric;
	#ifdef USE_DIFFUSE_ROUGHNESS
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		vec3 diffuse = EON_DirectionalAlbedo( material.diffuseColor, material.diffuseRoughness, dotNV ) * ( 1.0 - material.metalness ) * ( 1.0 - totalScatteringDielectric );
	#else
		vec3 diffuse = material.diffuseContribution * ( 1.0 - totalScatteringDielectric );
	#endif
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	vec3 indirectSpecular = radiance * singleScattering;
	indirectSpecular += multiScattering * cosineWeightedIrradiance;
	vec3 indirectDiffuse = diffuse * cosineWeightedIrradiance;
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		indirectSpecular *= sheenEnergyComp;
		indirectDiffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectSpecular += indirectSpecular;
	reflectedLight.indirectDiffuse += indirectDiffuse;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,Vg=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		vec3 iridescenceFresnelDielectric = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		vec3 iridescenceFresnelMetallic = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.diffuseColor );
		material.iridescenceFresnel = mix( iridescenceFresnelDielectric, iridescenceFresnelMetallic, material.metalness );
		material.iridescenceF0Dielectric = Schlick_to_F0( iridescenceFresnelDielectric, 1.0, dotNVi );
		material.iridescenceF0Metallic = Schlick_to_F0( iridescenceFresnelMetallic, 1.0, dotNVi );
	}
#endif
#ifdef STANDARD
	float dotNVms = saturate( dot( geometryNormal, geometryViewDir ) );
	material.dfg = texture2D( dfgLUT, vec2( material.roughness, dotNVms ) ).rg;
	#if ( NUM_SUN_LIGHTS > 0 || NUM_DIR_LIGHTS > 0 || NUM_POINT_LIGHTS > 0 || NUM_SPOT_LIGHTS > 0 )
		float EssMs = material.dfg.x + material.dfg.y;
		material.multiScatteringCompensation = 1.0 + material.specularColorBlended * ( 1.0 / EssMs - 1.0 );
	#endif
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS ) && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SUN_LIGHTS > 0 ) && defined( RE_Direct )
	SunLight sunLight;
	#if defined( USE_SHADOWMAP ) && NUM_SUN_LIGHT_SHADOWS > 0
	SunLightShadow sunLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SUN_LIGHTS; i ++ ) {
		sunLight = sunLights[ i ];
		getSunLightInfo( sunLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SUN_LIGHT_SHADOWS )
		sunLightShadow = sunLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getSunShadow( sunShadowMap[ i ], sunLightShadow, UNROLLED_LOOP_INDEX ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_LIGHT_PROBE_GRIDS > 0
		vec3 probeWorldPos = ( ( vec4( geometryPosition, 1.0 ) - viewMatrix[ 3 ] ) * viewMatrix ).xyz;
		vec3 probeWorldNormal = transformNormalByInverseViewMatrix( geometryNormal, viewMatrix );
		int probeGrid = - 1;
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_LIGHT_PROBE_GRIDS; i ++ ) {
			if ( isInsideLightProbeGrid( probeWorldPos, probeWorldNormal, probesMin[ i ], probesMax[ i ], probesResolution[ i ] ) ) probeGrid = UNROLLED_LOOP_INDEX;
		}
		#pragma unroll_loop_end
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_LIGHT_PROBE_GRIDS; i ++ ) {
			if ( probeGrid == UNROLLED_LOOP_INDEX ) irradiance += getLightProbeGridIrradiance( probesSH[ i ], probesMin[ i ], probesMax[ i ], probesResolution[ i ], probeWorldPos, probeWorldNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,Wg=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( ENVMAP_TYPE_PMREM )
		#if defined( STANDARD ) || defined( LAMBERT ) || defined( PHONG )
			iblIrradiance += getIBLIrradiance( geometryNormal );
		#endif
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		vec3 iblRadiance = getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		vec3 iblRadiance = getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_RETROREFLECTION
		#ifdef USE_ANISOTROPY
			vec3 retroIBLRadiance = getIBLAnisotropyRetroRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
		#else
			vec3 retroIBLRadiance = getIBLRetroRadiance( geometryViewDir, geometryNormal, material.roughness );
		#endif
		iblRadiance = mix( iblRadiance, retroIBLRadiance, saturate( material.retroreflectivity ) );
	#endif
	radiance += iblRadiance;
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,Xg=`#if defined( RE_IndirectDiffuse )
	#if defined( LAMBERT ) || defined( PHONG )
		irradiance += iblIrradiance;
	#endif
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,qg=`#if NUM_LIGHT_PROBE_GRIDS > 0
uniform highp sampler3D probesSH[ NUM_LIGHT_PROBE_GRIDS ];
uniform vec3 probesMin[ NUM_LIGHT_PROBE_GRIDS ];
uniform vec3 probesMax[ NUM_LIGHT_PROBE_GRIDS ];
uniform vec3 probesResolution[ NUM_LIGHT_PROBE_GRIDS ];
bool isInsideLightProbeGrid( vec3 worldPos, vec3 worldNormal, vec3 probesMin, vec3 probesMax, vec3 probesResolution ) {
	vec3 spacing = ( probesMax - probesMin ) / probesResolution;
	vec3 samplePos = worldPos + worldNormal * spacing * 0.5;
	vec3 margin = spacing * 0.01;
	return all( greaterThanEqual( samplePos, probesMin - margin ) ) && all( lessThanEqual( samplePos, probesMax + margin ) );
}
vec3 getLightProbeGridIrradiance( highp sampler3D probesSH, vec3 probesMin, vec3 probesMax, vec3 probesResolution, vec3 worldPos, vec3 worldNormal ) {
	vec3 res = probesResolution;
	vec3 gridRange = probesMax - probesMin;
	vec3 probeSpacing = gridRange / res;
	vec3 samplePos = worldPos + worldNormal * probeSpacing * 0.5;
	vec3 uvw = clamp( ( samplePos - probesMin ) / gridRange, 0.5 / res, 1.0 - 0.5 / res );
	float nz          = res.z;
	float paddedSlices = nz + 2.0;
	float atlasDepth  = 7.0 * paddedSlices;
	float uvZBase     = uvw.z * nz + 1.0;
	vec4 s0 = texture( probesSH, vec3( uvw.xy, ( uvZBase                       ) / atlasDepth ) );
	vec4 s1 = texture( probesSH, vec3( uvw.xy, ( uvZBase +       paddedSlices   ) / atlasDepth ) );
	vec4 s2 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 2.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s3 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 3.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s4 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 4.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s5 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 5.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s6 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 6.0 * paddedSlices   ) / atlasDepth ) );
	vec3 c0 = s0.xyz;
	vec3 c1 = vec3( s0.w, s1.xy );
	vec3 c2 = vec3( s1.zw, s2.x );
	vec3 c3 = s2.yzw;
	vec3 c4 = s3.xyz;
	vec3 c5 = vec3( s3.w, s4.xy );
	vec3 c6 = vec3( s4.zw, s5.x );
	vec3 c7 = s5.yzw;
	vec3 c8 = s6.xyz;
	float x = worldNormal.x, y = worldNormal.y, z = worldNormal.z;
	vec3 result = c0 * 0.886227;
	result += c1 * 2.0 * 0.511664 * y;
	result += c2 * 2.0 * 0.511664 * z;
	result += c3 * 2.0 * 0.511664 * x;
	result += c4 * 2.0 * 0.429043 * x * y;
	result += c5 * 2.0 * 0.429043 * y * z;
	result += c6 * ( 0.743125 * z * z - 0.247708 );
	result += c7 * 2.0 * 0.429043 * x * z;
	result += c8 * 0.429043 * ( x * x - y * y );
	return max( result, vec3( 0.0 ) );
}
#endif`,Yg=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,Kg=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,Zg=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,Jg=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,jg=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,Qg=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,ev=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,tv=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,nv=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,iv=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,sv=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,av=`#if defined( USE_MORPHCOLORS )
	#if defined( USE_COLOR_ALPHA )
		vColor *= morphTargetBaseInfluence;
	#elif defined( USE_COLOR )
		vColor.rgb *= morphTargetBaseInfluence;
	#endif
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor.rgb += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,rv=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,ov=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,lv=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,cv=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#ifdef DOUBLE_SIDED
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#ifdef DOUBLE_SIDED
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,dv=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#if defined( USE_PACKED_NORMALMAP )
		mapN = vec3( mapN.xy, sqrt( saturate( 1.0 - dot( mapN.xy, mapN.xy ) ) ) );
	#endif
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,hv=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,uv=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,fv=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
		#ifdef FLIP_SIDED
			vBitangent = - vBitangent;
		#endif
	#endif
#endif`,pv=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,mv=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,gv=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,vv=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,yv=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,xv=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,bv=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	#ifdef USE_REVERSED_DEPTH_BUFFER
	
		return depth * ( far - near ) - far;
	#else
		return depth * ( near - far ) - near;
	#endif
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	
	#ifdef USE_REVERSED_DEPTH_BUFFER
		return ( near * far ) / ( ( near - far ) * depth - near );
	#else
		return ( near * far ) / ( ( far - near ) * depth - far );
	#endif
}`,_v=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,Mv=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,wv=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,Sv=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,Ev=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,Av=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,Tv=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
		#define SUN_LIGHT_CASCADES 2
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow sunShadowMap[ NUM_SUN_LIGHT_SHADOWS ];
		#else
			uniform sampler2D sunShadowMap[ NUM_SUN_LIGHT_SHADOWS ];
		#endif
		uniform mat4 sunShadowMatrix[ NUM_SUN_LIGHT_SHADOWS * SUN_LIGHT_CASCADES ];
		uniform vec4 sunShadowCascade[ NUM_SUN_LIGHT_SHADOWS * SUN_LIGHT_CASCADES ];
		varying vec4 vSunShadowWorldPosition;
		varying vec3 vSunShadowWorldNormal;
		struct SunLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SunLightShadow sunLightShadows[ NUM_SUN_LIGHT_SHADOWS ];
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#else
			uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#endif
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#else
			uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#endif
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform samplerCubeShadow pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#elif defined( SHADOWMAP_TYPE_BASIC )
			uniform samplerCube pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#endif
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float interleavedGradientNoise( vec2 position ) {
			return fract( 52.9829189 * fract( dot( position, vec2( 0.06711056, 0.00583715 ) ) ) );
		}
		vec2 vogelDiskSample( int sampleIndex, int samplesCount, float phi ) {
			const float goldenAngle = 2.399963229728653;
			float r = sqrt( ( float( sampleIndex ) + 0.5 ) / float( samplesCount ) );
			float theta = float( sampleIndex ) * goldenAngle + phi;
			return vec2( cos( theta ), sin( theta ) ) * r;
		}
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float getShadow( sampler2DShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
				vec2 radius = shadowRadius * texelSize;
				float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
				shadow = (
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 0, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 1, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 2, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 3, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 4, 5, phi ) * radius, shadowCoord.z ) )
				) * 0.2;
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#elif defined( SHADOWMAP_TYPE_VSM )
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 distribution = texture2D( shadowMap, shadowCoord.xy ).rg;
				float mean = distribution.x;
				float variance = distribution.y * distribution.y;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					float hard_shadow = step( mean, shadowCoord.z );
				#else
					float hard_shadow = step( shadowCoord.z, mean );
				#endif
				
				if ( hard_shadow == 1.0 ) {
					shadow = 1.0;
				} else {
					variance = max( variance, 0.0000001 );
					float d = shadowCoord.z - mean;
					float p_max = variance / ( variance + d * d );
					p_max = clamp( ( p_max - 0.3 ) / 0.65, 0.0, 1.0 );
					shadow = max( hard_shadow, p_max );
				}
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#else
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				float depth = texture2D( shadowMap, shadowCoord.xy ).r;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					shadow = step( depth, shadowCoord.z );
				#else
					shadow = step( shadowCoord.z, depth );
				#endif
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#endif
	#if NUM_SUN_LIGHT_SHADOWS > 0
		float getSunShadow(
			#if defined( SHADOWMAP_TYPE_PCF )
				sampler2DShadow shadowMap,
			#else
				sampler2D shadowMap,
			#endif
			SunLightShadow sunLightShadow,
			int shadowIndex
		) {
			vec4 shadowWorldPosition = vec4( vSunShadowWorldPosition.xyz + vSunShadowWorldNormal * sunLightShadow.shadowNormalBias, 1.0 );
			float viewDepth = vSunShadowWorldPosition.w;
			int cascadeOffset = shadowIndex * SUN_LIGHT_CASCADES;
			float shadow = 1.0;
			for ( int i = SUN_LIGHT_CASCADES - 1; i >= 0; i -- ) {
				vec4 cascade = sunShadowCascade[ cascadeOffset + i ];
				if ( viewDepth >= cascade.x && viewDepth < cascade.y ) {
					float cascadeShadow = getShadow(
						shadowMap,
						sunLightShadow.shadowMapSize,
						sunLightShadow.shadowIntensity,
						sunLightShadow.shadowBias,
						sunLightShadow.shadowRadius,
						sunShadowMatrix[ cascadeOffset + i ] * shadowWorldPosition
					);
					shadow = mix( cascadeShadow, shadow, smoothstep( cascade.z, cascade.y, viewDepth ) );
				}
			}
			return shadow;
		}
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	#if defined( SHADOWMAP_TYPE_PCF )
	float getPointShadow( samplerCubeShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 bd3D = normalize( lightToPosition );
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			float lightDistance = length( lightToPosition );
			float depthRange = shadowCameraFar - shadowCameraNear;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				float depthA = - shadowCameraNear / depthRange - shadowBias;
				float depthB = shadowCameraNear * shadowCameraFar / ( depthRange * lightDistance );
			#else
				float depthA = shadowCameraFar / depthRange + shadowBias;
				float depthB = - shadowCameraNear * shadowCameraFar / ( depthRange * lightDistance );
			#endif
			float texelSize = shadowRadius / shadowMapSize.x;
			vec3 absDir = abs( bd3D );
			vec3 tangent = absDir.x > absDir.z ? vec3( 0.0, 1.0, 0.0 ) : vec3( 1.0, 0.0, 0.0 );
			tangent = normalize( cross( bd3D, tangent ) );
			vec3 bitangent = cross( bd3D, tangent );
			float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
			shadow = 0.0;
			for ( int i = 0; i < 5; i ++ ) {
				vec2 offset = vogelDiskSample( i, 5, phi );
				vec3 direction = bd3D + ( tangent * offset.x + bitangent * offset.y ) * texelSize;
				vec3 absDirection = abs( direction );
				float dp = depthA + depthB / max( max( absDirection.x, absDirection.y ), absDirection.z );
				shadow += texture( shadowMap, vec4( direction, dp ) );
			}
			shadow *= 0.2;
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#elif defined( SHADOWMAP_TYPE_BASIC )
	float getPointShadow( samplerCube shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			float depth = textureCube( shadowMap, bd3D ).r;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				depth = 1.0 - depth;
			#endif
			shadow = step( dp, depth );
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#endif
	#endif
#endif`,Rv=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
		varying vec4 vSunShadowWorldPosition;
		varying vec3 vSunShadowWorldNormal;
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,Cv=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_SUN_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	#ifdef HAS_NORMAL
		vec3 shadowWorldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
	#else
		vec3 shadowWorldNormal = vec3( 0.0 );
	#endif
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_SUN_LIGHT_SHADOWS > 0
		vSunShadowWorldPosition = vec4( worldPosition.xyz, - mvPosition.z );
		vSunShadowWorldNormal = shadowWorldNormal;
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,Pv=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
	SunLightShadow sunLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SUN_LIGHT_SHADOWS; i ++ ) {
		sunLight = sunLightShadows[ i ];
		shadow *= receiveShadow ? getSunShadow( sunShadowMap[ i ], sunLight, UNROLLED_LOOP_INDEX ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0 && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,Lv=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,Dv=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,Iv=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,Nv=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,Uv=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,Fv=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,Ov=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,kv=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,Bv=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseContribution, material.specularColorBlended, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,zv=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,$v=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_DIFFUSE_ROUGHNESSMAP
	varying vec2 vDiffuseRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Hv=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_DIFFUSE_ROUGHNESSMAP
	uniform mat3 diffuseRoughnessMapTransform;
	varying vec2 vDiffuseRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Gv=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DIFFUSE_ROUGHNESSMAP
	vDiffuseRoughnessMapUv = ( diffuseRoughnessMapTransform * vec3( DIFFUSE_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,Vv=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const Wv=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,Xv=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,qv=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Yv=`uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <envmap_common_pars_fragment>
void main() {
	#ifdef ENVMAP_TYPE_PMREM
		vec4 texColor = textureLod( envMap, backgroundRotation * vWorldDirection, roughnessToMip( backgroundBlurriness ) );
	#else
		vec4 texColor = textureCube( envMap, backgroundRotation * vWorldDirection );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Kv=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Zv=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Jv=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,jv=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,Qv=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,ey=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = vec4( dist, 0.0, 0.0, 1.0 );
}`,ty=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,ny=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,iy=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,sy=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,ay=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,ry=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,oy=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,ly=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,cy=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,dy=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,hy=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,uy=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( normalize( normal ) * 0.5 + 0.5, diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,fy=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,py=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,my=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,gy=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DIFFUSE_ROUGHNESS
	uniform float diffuseRoughness;
	#ifdef USE_DIFFUSE_ROUGHNESSMAP
		uniform sampler2D diffuseRoughnessMap;
	#endif
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_RETROREFLECTION
	uniform float retroreflectivity;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
 
		outgoingLight = outgoingLight + sheenSpecularDirect + sheenSpecularIndirect;
 
 	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,vy=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,yy=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,xy=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,by=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,_y=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,My=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,wy=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Sy=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,qe={alphahash_fragment:X0,alphahash_pars_fragment:q0,alphamap_fragment:Y0,alphamap_pars_fragment:K0,alphatest_fragment:Z0,alphatest_pars_fragment:J0,aomap_fragment:j0,aomap_pars_fragment:Q0,batching_pars_vertex:eg,batching_vertex:tg,begin_vertex:ng,beginnormal_vertex:ig,bsdfs:sg,iridescence_fragment:ag,bumpmap_pars_fragment:rg,clipping_planes_fragment:og,clipping_planes_pars_fragment:lg,clipping_planes_pars_vertex:cg,clipping_planes_vertex:dg,color_fragment:hg,color_pars_fragment:ug,color_pars_vertex:fg,color_vertex:pg,common:mg,defaultnormal_vertex:gg,displacementmap_pars_vertex:vg,displacementmap_vertex:yg,emissivemap_fragment:xg,emissivemap_pars_fragment:bg,colorspace_fragment:_g,colorspace_pars_fragment:Mg,envmap_fragment:wg,envmap_common_pars_fragment:Sg,envmap_pars_fragment:Eg,envmap_pars_vertex:Ag,envmap_physical_pars_fragment:Og,envmap_vertex:Tg,fog_vertex:Rg,fog_pars_vertex:Cg,fog_fragment:Pg,fog_pars_fragment:Lg,gradientmap_pars_fragment:Dg,lightmap_pars_fragment:Ig,lights_lambert_fragment:Ng,lights_lambert_pars_fragment:Ug,lights_pars_begin:Fg,lights_toon_fragment:kg,lights_toon_pars_fragment:Bg,lights_phong_fragment:zg,lights_phong_pars_fragment:$g,lights_physical_fragment:Hg,lights_physical_pars_fragment:Gg,lights_fragment_begin:Vg,lights_fragment_maps:Wg,lights_fragment_end:Xg,lightprobes_pars_fragment:qg,logdepthbuf_fragment:Yg,logdepthbuf_pars_fragment:Kg,logdepthbuf_pars_vertex:Zg,logdepthbuf_vertex:Jg,map_fragment:jg,map_pars_fragment:Qg,map_particle_fragment:ev,map_particle_pars_fragment:tv,metalnessmap_fragment:nv,metalnessmap_pars_fragment:iv,morphinstance_vertex:sv,morphcolor_vertex:av,morphnormal_vertex:rv,morphtarget_pars_vertex:ov,morphtarget_vertex:lv,normal_fragment_begin:cv,normal_fragment_maps:dv,normal_pars_fragment:hv,normal_pars_vertex:uv,normal_vertex:fv,normalmap_pars_fragment:pv,clearcoat_normal_fragment_begin:mv,clearcoat_normal_fragment_maps:gv,clearcoat_pars_fragment:vv,iridescence_pars_fragment:yv,opaque_fragment:xv,packing:bv,premultiplied_alpha_fragment:_v,project_vertex:Mv,dithering_fragment:wv,dithering_pars_fragment:Sv,roughnessmap_fragment:Ev,roughnessmap_pars_fragment:Av,shadowmap_pars_fragment:Tv,shadowmap_pars_vertex:Rv,shadowmap_vertex:Cv,shadowmask_pars_fragment:Pv,skinbase_vertex:Lv,skinning_pars_vertex:Dv,skinning_vertex:Iv,skinnormal_vertex:Nv,specularmap_fragment:Uv,specularmap_pars_fragment:Fv,tonemapping_fragment:Ov,tonemapping_pars_fragment:kv,transmission_fragment:Bv,transmission_pars_fragment:zv,uv_pars_fragment:$v,uv_pars_vertex:Hv,uv_vertex:Gv,worldpos_vertex:Vv,background_vert:Wv,background_frag:Xv,backgroundCube_vert:qv,backgroundCube_frag:Yv,cube_vert:Kv,cube_frag:Zv,depth_vert:Jv,depth_frag:jv,distance_vert:Qv,distance_frag:ey,equirect_vert:ty,equirect_frag:ny,linedashed_vert:iy,linedashed_frag:sy,meshbasic_vert:ay,meshbasic_frag:ry,meshlambert_vert:oy,meshlambert_frag:ly,meshmatcap_vert:cy,meshmatcap_frag:dy,meshnormal_vert:hy,meshnormal_frag:uy,meshphong_vert:fy,meshphong_frag:py,meshphysical_vert:my,meshphysical_frag:gy,meshtoon_vert:vy,meshtoon_frag:yy,points_vert:xy,points_frag:by,shadow_vert:_y,shadow_frag:My,sprite_vert:wy,sprite_frag:Sy},ve={common:{diffuse:{value:new Ce(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new ke},alphaMap:{value:null},alphaMapTransform:{value:new ke},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new ke}},envmap:{envMap:{value:null},envMapRotation:{value:new ke},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98},dfgLUT:{value:null}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new ke}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new ke}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new ke},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new ke},normalScale:{value:new Ie(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new ke},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new ke}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new ke}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new ke}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new Ce(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},sunLights:{value:[],properties:{direction:{},color:{}}},sunLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},sunShadowMatrix:{value:[]},sunShadowCascade:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null},probesSH:{value:[]},probesMin:{value:[]},probesMax:{value:[]},probesResolution:{value:[]}},points:{diffuse:{value:new Ce(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new ke},alphaTest:{value:0},uvTransform:{value:new ke}},sprite:{diffuse:{value:new Ce(16777215)},opacity:{value:1},center:{value:new Ie(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new ke},alphaMap:{value:null},alphaMapTransform:{value:new ke},alphaTest:{value:0}}},ci={basic:{uniforms:mn([ve.common,ve.specularmap,ve.envmap,ve.aomap,ve.lightmap,ve.fog]),vertexShader:qe.meshbasic_vert,fragmentShader:qe.meshbasic_frag},lambert:{uniforms:mn([ve.common,ve.specularmap,ve.envmap,ve.aomap,ve.lightmap,ve.emissivemap,ve.bumpmap,ve.normalmap,ve.displacementmap,ve.fog,ve.lights,{emissive:{value:new Ce(0)},envMapIntensity:{value:1}}]),vertexShader:qe.meshlambert_vert,fragmentShader:qe.meshlambert_frag},phong:{uniforms:mn([ve.common,ve.specularmap,ve.envmap,ve.aomap,ve.lightmap,ve.emissivemap,ve.bumpmap,ve.normalmap,ve.displacementmap,ve.fog,ve.lights,{emissive:{value:new Ce(0)},specular:{value:new Ce(1118481)},shininess:{value:30},envMapIntensity:{value:1}}]),vertexShader:qe.meshphong_vert,fragmentShader:qe.meshphong_frag},standard:{uniforms:mn([ve.common,ve.envmap,ve.aomap,ve.lightmap,ve.emissivemap,ve.bumpmap,ve.normalmap,ve.displacementmap,ve.roughnessmap,ve.metalnessmap,ve.fog,ve.lights,{emissive:{value:new Ce(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:qe.meshphysical_vert,fragmentShader:qe.meshphysical_frag},toon:{uniforms:mn([ve.common,ve.aomap,ve.lightmap,ve.emissivemap,ve.bumpmap,ve.normalmap,ve.displacementmap,ve.gradientmap,ve.fog,ve.lights,{emissive:{value:new Ce(0)}}]),vertexShader:qe.meshtoon_vert,fragmentShader:qe.meshtoon_frag},matcap:{uniforms:mn([ve.common,ve.bumpmap,ve.normalmap,ve.displacementmap,ve.fog,{matcap:{value:null}}]),vertexShader:qe.meshmatcap_vert,fragmentShader:qe.meshmatcap_frag},points:{uniforms:mn([ve.points,ve.fog]),vertexShader:qe.points_vert,fragmentShader:qe.points_frag},dashed:{uniforms:mn([ve.common,ve.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:qe.linedashed_vert,fragmentShader:qe.linedashed_frag},depth:{uniforms:mn([ve.common,ve.displacementmap]),vertexShader:qe.depth_vert,fragmentShader:qe.depth_frag},normal:{uniforms:mn([ve.common,ve.bumpmap,ve.normalmap,ve.displacementmap,{opacity:{value:1}}]),vertexShader:qe.meshnormal_vert,fragmentShader:qe.meshnormal_frag},sprite:{uniforms:mn([ve.sprite,ve.fog]),vertexShader:qe.sprite_vert,fragmentShader:qe.sprite_frag},background:{uniforms:{uvTransform:{value:new ke},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:qe.background_vert,fragmentShader:qe.background_frag},backgroundCube:{uniforms:{envMap:{value:null},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new ke}},vertexShader:qe.backgroundCube_vert,fragmentShader:qe.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:qe.cube_vert,fragmentShader:qe.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:qe.equirect_vert,fragmentShader:qe.equirect_frag},distance:{uniforms:mn([ve.common,ve.displacementmap,{referencePosition:{value:new D},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:qe.distance_vert,fragmentShader:qe.distance_frag},shadow:{uniforms:mn([ve.lights,ve.fog,{color:{value:new Ce(0)},opacity:{value:1}}]),vertexShader:qe.shadow_vert,fragmentShader:qe.shadow_frag}};ci.physical={uniforms:mn([ci.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new ke},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new ke},clearcoatNormalScale:{value:new Ie(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new ke},diffuseRoughness:{value:0},diffuseRoughnessMap:{value:null},diffuseRoughnessMapTransform:{value:new ke},dispersion:{value:0},retroreflectivity:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new ke},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new ke},sheen:{value:0},sheenColor:{value:new Ce(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new ke},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new ke},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new ke},transmissionSamplerSize:{value:new Ie},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new ke},attenuationDistance:{value:0},attenuationColor:{value:new Ce(0)},specularColor:{value:new Ce(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new ke},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new ke},anisotropyVector:{value:new Ie},anisotropyMap:{value:null},anisotropyMapTransform:{value:new ke}}]),vertexShader:qe.meshphysical_vert,fragmentShader:qe.meshphysical_frag};const Br={r:0,b:0,g:0},Ey=new tt,Kf=new ke;Kf.set(-1,0,0,0,1,0,0,0,1);function Ay(i,e,t,n,s,a){const r=new Ce(0);let o=s===!0?0:1,l,c,d=null,h=0,u=null;function f(x){let A=x.isScene===!0?x.background:null;if(A&&A.isTexture){const b=x.backgroundBlurriness>0;A=e.get(A,b)}return A}function g(x){let A=!1;const b=f(x);b===null?m(r,o):b&&b.isColor&&(m(b,1),A=!0);const E=i.xr.getEnvironmentBlendMode();E==="additive"?t.buffers.color.setClear(0,0,0,1,a):E==="alpha-blend"&&t.buffers.color.setClear(0,0,0,0,a),(i.autoClear||A)&&(t.buffers.depth.setTest(!0),t.buffers.depth.setMask(!0),t.buffers.color.setMask(!0),i.clear(i.autoClearColor,i.autoClearDepth,i.autoClearStencil))}function y(x,A){const b=f(A);b&&b.isCubeTexture?(c===void 0&&(c=new Te(new Xn(1,1,1),new Pn({name:"BackgroundCubeMaterial",uniforms:la(ci.backgroundCube.uniforms),vertexShader:ci.backgroundCube.vertexShader,fragmentShader:ci.backgroundCube.fragmentShader,side:rn,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),c.geometry.deleteAttribute("normal"),c.geometry.deleteAttribute("uv"),c.onBeforeRender=function(E,S,v){this.matrixWorld.copyPosition(v.matrixWorld)},Object.defineProperty(c.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),n.update(c)),c.material.uniforms.envMap.value=b,c.material.uniforms.backgroundBlurriness.value=A.backgroundBlurriness,c.material.uniforms.backgroundIntensity.value=A.backgroundIntensity,c.material.uniforms.backgroundRotation.value.setFromMatrix4(Ey.makeRotationFromEuler(A.backgroundRotation)).transpose(),b.isRenderTargetTexture===!1&&c.material.uniforms.backgroundRotation.value.premultiply(Kf),c.material.toneMapped=et.getTransfer(b.colorSpace)!==lt,(d!==b||h!==b.version||u!==i.toneMapping)&&(c.material.needsUpdate=!0,d=b,h=b.version,u=i.toneMapping),c.layers.enableAll(),x.unshift(c,c.geometry,c.material,0,0,null)):b&&b.isTexture&&(l===void 0&&(l=new Te(new Fi(2,2),new Pn({name:"BackgroundMaterial",uniforms:la(ci.background.uniforms),vertexShader:ci.background.vertexShader,fragmentShader:ci.background.fragmentShader,side:vs,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),l.geometry.deleteAttribute("normal"),Object.defineProperty(l.material,"map",{get:function(){return this.uniforms.t2D.value}}),n.update(l)),l.material.uniforms.t2D.value=b,l.material.uniforms.backgroundIntensity.value=A.backgroundIntensity,l.material.toneMapped=et.getTransfer(b.colorSpace)!==lt,b.matrixAutoUpdate===!0&&b.updateMatrix(),l.material.uniforms.uvTransform.value.copy(b.matrix),(d!==b||h!==b.version||u!==i.toneMapping)&&(l.material.needsUpdate=!0,d=b,h=b.version,u=i.toneMapping),l.layers.enableAll(),x.unshift(l,l.geometry,l.material,0,0,null))}function m(x,A){x.getRGB(Br,$f(i)),t.buffers.color.setClear(Br.r,Br.g,Br.b,A,a)}function p(){c!==void 0&&(c.geometry.dispose(),c.material.dispose(),c=void 0),l!==void 0&&(l.geometry.dispose(),l.material.dispose(),l=void 0)}return{getClearColor:function(){return r},setClearColor:function(x,A=1){r.set(x),o=A,m(r,o)},getClearAlpha:function(){return o},setClearAlpha:function(x){o=x,m(r,o)},render:g,addToRenderList:y,dispose:p}}function Ty(i,e){const t=i.getParameter(i.MAX_VERTEX_ATTRIBS),n={},s=u(null);let a=s,r=!1;function o(N,F,G,L,z){let X=!1;const $=h(N,L,G,F);a!==$&&(a=$,c(a.object)),X=f(N,L,G,z),X&&g(N,L,G,z),z!==null&&e.update(z,i.ELEMENT_ARRAY_BUFFER),(X||r)&&(r=!1,b(N,F,G,L),z!==null&&i.bindBuffer(i.ELEMENT_ARRAY_BUFFER,e.get(z).buffer))}function l(){return i.createVertexArray()}function c(N){return i.bindVertexArray(N)}function d(N){return i.deleteVertexArray(N)}function h(N,F,G,L){const z=L.wireframe===!0;let X=n[F.id];X===void 0&&(X={},n[F.id]=X);const $=N.isInstancedMesh===!0?N.id:0;let te=X[$];te===void 0&&(te={},X[$]=te);let V=te[G.id];V===void 0&&(V={},te[G.id]=V);let ee=V[z];return ee===void 0&&(ee=u(l()),V[z]=ee),ee}function u(N){const F=[],G=[],L=[];for(let z=0;z<t;z++)F[z]=0,G[z]=0,L[z]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:F,enabledAttributes:G,attributeDivisors:L,object:N,attributes:{},index:null}}function f(N,F,G,L){const z=a.attributes,X=F.attributes;let $=0;const te=G.getAttributes();for(const V in te)if(te[V].location>=0){const ne=z[V];let Ee=X[V];if(Ee===void 0&&(V==="instanceMatrix"&&N.instanceMatrix&&(Ee=N.instanceMatrix),V==="instanceColor"&&N.instanceColor&&(Ee=N.instanceColor)),ne===void 0||ne.attribute!==Ee||Ee&&ne.data!==Ee.data)return!0;$++}return a.attributesNum!==$||a.index!==L}function g(N,F,G,L){const z={},X=F.attributes;let $=0;const te=G.getAttributes();for(const V in te)if(te[V].location>=0){let ne=X[V];ne===void 0&&(V==="instanceMatrix"&&N.instanceMatrix&&(ne=N.instanceMatrix),V==="instanceColor"&&N.instanceColor&&(ne=N.instanceColor));const Ee={};Ee.attribute=ne,ne&&ne.data&&(Ee.data=ne.data),z[V]=Ee,$++}a.attributes=z,a.attributesNum=$,a.index=L}function y(){const N=a.newAttributes;for(let F=0,G=N.length;F<G;F++)N[F]=0}function m(N){p(N,0)}function p(N,F){const G=a.newAttributes,L=a.enabledAttributes,z=a.attributeDivisors;G[N]=1,L[N]===0&&(i.enableVertexAttribArray(N),L[N]=1),z[N]!==F&&(i.vertexAttribDivisor(N,F),z[N]=F)}function x(){const N=a.newAttributes,F=a.enabledAttributes;for(let G=0,L=F.length;G<L;G++)F[G]!==N[G]&&(i.disableVertexAttribArray(G),F[G]=0)}function A(N,F,G,L,z,X,$){$===!0?i.vertexAttribIPointer(N,F,G,z,X):i.vertexAttribPointer(N,F,G,L,z,X)}function b(N,F,G,L){y();const z=L.attributes,X=G.getAttributes(),$=F.defaultAttributeValues;for(const te in X){const V=X[te];if(V.location>=0){let ee=z[te];if(ee===void 0&&(te==="instanceMatrix"&&N.instanceMatrix&&(ee=N.instanceMatrix),te==="instanceColor"&&N.instanceColor&&(ee=N.instanceColor)),ee!==void 0){const ne=ee.normalized,Ee=ee.itemSize,$e=e.get(ee);if($e===void 0)continue;const K=$e.buffer,ye=$e.type,Me=$e.bytesPerElement,Le=ye===i.INT||ye===i.UNSIGNED_INT||ee.gpuType===fd;if(ee.isInterleavedBufferAttribute){const xe=ee.data,Ge=xe.isInterleavedBuffer===!0?xe.stride:xe.itemSize,Lt=ee.offset;if(xe.isInstancedInterleavedBuffer||xe.isInstancedBufferAttribute){for(let Ne=0;Ne<V.locationSize;Ne++)p(V.location+Ne,xe.meshPerAttribute);N.isInstancedMesh!==!0&&L._maxInstanceCount===void 0&&(L._maxInstanceCount=xe.meshPerAttribute*xe.count)}else for(let Ne=0;Ne<V.locationSize;Ne++)m(V.location+Ne);i.bindBuffer(i.ARRAY_BUFFER,K);for(let Ne=0;Ne<V.locationSize;Ne++)A(V.location+Ne,Ee/V.locationSize,ye,ne,Ge*Me,(Lt+Ee/V.locationSize*Ne)*Me,Le)}else{if(ee.isInstancedBufferAttribute){for(let xe=0;xe<V.locationSize;xe++)p(V.location+xe,ee.meshPerAttribute);N.isInstancedMesh!==!0&&L._maxInstanceCount===void 0&&(L._maxInstanceCount=ee.meshPerAttribute*ee.count)}else for(let xe=0;xe<V.locationSize;xe++)m(V.location+xe);i.bindBuffer(i.ARRAY_BUFFER,K);for(let xe=0;xe<V.locationSize;xe++)A(V.location+xe,Ee/V.locationSize,ye,ne,Ee*Me,Ee/V.locationSize*xe*Me,Le)}}else if($!==void 0){const ne=$[te];if(ne!==void 0)switch(ne.length){case 2:i.vertexAttrib2fv(V.location,ne);break;case 3:i.vertexAttrib3fv(V.location,ne);break;case 4:i.vertexAttrib4fv(V.location,ne);break;default:i.vertexAttrib1fv(V.location,ne)}}}}x()}function E(){P();for(const N in n){const F=n[N];for(const G in F){const L=F[G];for(const z in L){const X=L[z];for(const $ in X)d(X[$].object),delete X[$];delete L[z]}}delete n[N]}}function S(N){if(n[N.id]===void 0)return;const F=n[N.id];for(const G in F){const L=F[G];for(const z in L){const X=L[z];for(const $ in X)d(X[$].object),delete X[$];delete L[z]}}delete n[N.id]}function v(N){for(const F in n){const G=n[F];for(const L in G){const z=G[L];if(z[N.id]===void 0)continue;const X=z[N.id];for(const $ in X)d(X[$].object),delete X[$];delete z[N.id]}}}function w(N){for(const F in n){const G=n[F],L=N.isInstancedMesh===!0?N.id:0,z=G[L];if(z!==void 0){for(const X in z){const $=z[X];for(const te in $)d($[te].object),delete $[te];delete z[X]}delete G[L],Object.keys(G).length===0&&delete n[F]}}}function P(){R(),r=!0,a!==s&&(a=s,c(a.object))}function R(){s.geometry=null,s.program=null,s.wireframe=!1}return{setup:o,reset:P,resetDefaultState:R,dispose:E,releaseStatesOfGeometry:S,releaseStatesOfObject:w,releaseStatesOfProgram:v,initAttributes:y,enableAttribute:m,disableUnusedAttributes:x}}function Ry(i,e,t){let n;function s(l){n=l}function a(l,c){i.drawArrays(n,l,c),t.update(c,n,1)}function r(l,c,d){d!==0&&(i.drawArraysInstanced(n,l,c,d),t.update(c,n,d))}function o(l,c,d){if(d===0)return;e.get("WEBGL_multi_draw").multiDrawArraysWEBGL(n,l,0,c,0,d);let u=0;for(let f=0;f<d;f++)u+=c[f];t.update(u,n,1)}this.setMode=s,this.render=a,this.renderInstances=r,this.renderMultiDraw=o}function Cy(i,e,t,n){let s;function a(){if(s!==void 0)return s;if(e.has("EXT_texture_filter_anisotropic")===!0){const v=e.get("EXT_texture_filter_anisotropic");s=i.getParameter(v.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else s=0;return s}function r(v){return!(v!==hi&&n.convert(v)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_FORMAT))}function o(v){const w=v===gi&&(e.has("EXT_color_buffer_half_float")||e.has("EXT_color_buffer_float"));return!(v!==wn&&v!==ii&&!w&&n.convert(v)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_TYPE))}function l(v){if(v==="highp"){if(i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.HIGH_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.HIGH_FLOAT).precision>0)return"highp";v="mediump"}return v==="mediump"&&i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.MEDIUM_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let c=t.precision!==void 0?t.precision:"highp";const d=l(c);d!==c&&(Ue("WebGLRenderer:",c,"not supported, using",d,"instead."),c=d);const h=t.reversedDepthBuffer===!0&&e.has("EXT_clip_control"),u=t.logarithmicDepthBuffer===!0&&h===!1;t.reversedDepthBuffer===!0&&h===!1&&Ue("WebGLRenderer: Unable to use reversed depth buffer due to missing EXT_clip_control extension. Fallback to default depth buffer."),t.logarithmicDepthBuffer===!0&&h===!0&&Ue("WebGLRenderer: Logarithmic depth buffer is ignored when reversed depth buffer is enabled.");const f=i.getParameter(i.MAX_TEXTURE_IMAGE_UNITS),g=i.getParameter(i.MAX_VERTEX_TEXTURE_IMAGE_UNITS),y=i.getParameter(i.MAX_TEXTURE_SIZE),m=i.getParameter(i.MAX_CUBE_MAP_TEXTURE_SIZE),p=i.getParameter(i.MAX_VERTEX_ATTRIBS),x=i.getParameter(i.MAX_VERTEX_UNIFORM_VECTORS),A=i.getParameter(i.MAX_VARYING_VECTORS),b=i.getParameter(i.MAX_FRAGMENT_UNIFORM_VECTORS),E=i.getParameter(i.MAX_SAMPLES),S=i.getParameter(i.SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:a,getMaxPrecision:l,textureFormatReadable:r,textureTypeReadable:o,precision:c,logarithmicDepthBuffer:u,reversedDepthBuffer:h,maxTextures:f,maxVertexTextures:g,maxTextureSize:y,maxCubemapSize:m,maxAttributes:p,maxVertexUniforms:x,maxVaryings:A,maxFragmentUniforms:b,maxSamples:E,samples:S}}function Py(i){const e=this;let t=null,n=0,s=!1,a=!1;const r=new Ai,o=new ke,l={value:null,needsUpdate:!1};this.uniform=l,this.numPlanes=0,this.numIntersection=0,this.init=function(h,u){const f=h.length!==0||u||n!==0||s;return s=u,n=h.length,f},this.beginShadows=function(){a=!0,d(null)},this.endShadows=function(){a=!1},this.setGlobalState=function(h,u){t=d(h,u,0)},this.setState=function(h,u,f){const g=h.clippingPlanes,y=h.clipIntersection,m=h.clipShadows,p=i.get(h);if(!s||g===null||g.length===0||a&&!m)a?d(null):c();else{const x=a?0:n,A=x*4;let b=p.clippingState||null;l.value=b,b=d(g,u,A,f);for(let E=0;E!==A;++E)b[E]=t[E];p.clippingState=b,this.numIntersection=y?this.numPlanes:0,this.numPlanes+=x}};function c(){l.value!==t&&(l.value=t,l.needsUpdate=n>0),e.numPlanes=n,e.numIntersection=0}function d(h,u,f,g){const y=h!==null?h.length:0;let m=null;if(y!==0){if(m=l.value,g!==!0||m===null){const p=f+y*4,x=u.matrixWorldInverse;o.getNormalMatrix(x),(m===null||m.length<p)&&(m=new Float32Array(p));for(let A=0,b=f;A!==y;++A,b+=4)r.copy(h[A]).applyMatrix4(x,o),r.normal.toArray(m,b),m[b+3]=r.constant}l.value=m,l.needsUpdate=!0}return e.numPlanes=y,e.numIntersection=0,m}}class Td extends Vn{constructor(e=1,t={}){super(e,e,t),this.isWebGLCubeRenderTarget=!0;const n={width:e,height:e,depth:1},s=[n,n,n,n,n,n];this.texture=new kf(s),this._setTextureOptions(t),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(e,t){this.texture.type=t.type,this.texture.colorSpace=t.colorSpace,this.texture.generateMipmaps=t.generateMipmaps,this.texture.minFilter=t.minFilter,this.texture.magFilter=t.magFilter;const n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},s=new Xn(5,5,5),a=new Pn({name:"CubemapFromEquirect",uniforms:la(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:rn,blending:Ks});a.uniforms.tEquirect.value=t;const r=new Te(s,a),o=t.minFilter;return t.minFilter===Li&&(t.minFilter=vn),new Hc(1,10,this).update(e,r),t.minFilter=o,r.geometry.dispose(),r.material.dispose(),this}clear(e,t=!0,n=!0,s=!0){const a=e.getRenderTarget();for(let r=0;r<6;r++)e.setRenderTarget(this,r),e.clear(t,n,s);e.setRenderTarget(a)}}const Hh=256,Ly=3,Dy=20,Zf=256,Jf=16,Iy=3,Ny=new D,Uy=new Ce;class Ao{constructor(e){this._renderer=e,this._cubeSize=0,this._sourceTarget=null,this._cubeCamera=new Hc(1,10,null),this._boxMesh=new Te(new Xn(5,5,5),null),this._cubemapMaterial=null,this._equirectMaterial=null,this._blurMaterial=null,this._ggxMaterial=null,this._integrationMaterial=null}fromScene(e,t=0,n=.1,s=100,a={}){const{size:r=256,position:o=Ny}=a,l=this._renderer;this._setSize(r);const c=this._allocateTarget(),d=this._getSourceTarget(!0);t>0&&(d.texture.mipmapsAutoUpdate=!1);const h=l.autoClear,u=l.autoClearColor,f=l.autoClearDepth,g=l.autoClearStencil,y=e.background;l.autoClear=!0,l.autoClearColor=!0,l.autoClearDepth=!0,l.autoClearStencil=!0,y===null&&(e.background=l.getClearColor(Uy));const m=new Hc(n,s,d);return m.position.copy(o),m.update(l,e),l.autoClear=h,l.autoClearColor=u,l.autoClearDepth=f,l.autoClearStencil=g,e.background=y,t>0&&(d.texture.mipmapsAutoUpdate=!0,this._blur(c,t)),this._applyPMREM(c),c}fromEquirectangular(e,t=null){return this._fromTexture(e,t)}fromCubemap(e,t=null){return this._fromTexture(e,t)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=Wh(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=Vh(),this._compileMaterial(this._equirectMaterial))}dispose(){this._sourceTarget!==null&&this._sourceTarget.dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose(),this._blurMaterial!==null&&this._blurMaterial.dispose(),this._ggxMaterial!==null&&this._ggxMaterial.dispose(),this._integrationMaterial!==null&&this._integrationMaterial.dispose(),this._boxMesh.geometry.dispose()}static lodToRoughness(e,t){return t>0?1-Math.sqrt(1-e/t):0}_setSize(e){this._cubeSize=Math.max(Hh,Pf(e))}_fromTexture(e,t){e.mapping===sa||e.mapping===Ha?this._setSize(e.image.length===0?Hh:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4);const n=t||this._allocateTarget();return this._textureToCubemap(e),this._applyPMREM(n),n}_allocateTarget(){const e=this._cubeSize,t=Gh(e,!1,!1),n=Math.log2(e)-Ly;for(let s=0;s<=n;s++)t.texture.mipmaps.push({width:e>>s,height:e>>s});return t.texture.name="PMREM",t.texture.isPMREMTexture=!0,t}_getSourceTarget(e=!1){const t=this._cubeSize,n=this._sourceTarget;return(n===null||n.width!==t||e&&n.depthBuffer===!1)&&(n!==null&&n.dispose(),this._sourceTarget=Gh(t,!0,e)),this._sourceTarget}_compileMaterial(e){this._boxMesh.material=e,this._renderer.compile(this._boxMesh,this._cubeCamera.children[0])}_renderCube(e,t,n){const s=this._boxMesh,a=this._cubeCamera;s.material=n,a.renderTarget=e,a.activeMipmapLevel=t;const r=e.width>>t;e.viewport.set(0,0,r,r),a.update(this._renderer,s),e.viewport.set(0,0,e.width,e.height)}_textureToCubemap(e){let t;e.mapping===sa||e.mapping===Ha?(this._cubemapMaterial===null&&(this._cubemapMaterial=Wh()),t=this._cubemapMaterial,t.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):(this._equirectMaterial===null&&(this._equirectMaterial=Vh()),t=this._equirectMaterial),t.uniforms.envMap.value=e,this._renderCube(this._getSourceTarget(),0,t)}_applyPMREM(e){this._ggxMaterial===null&&(this._ggxMaterial=Fy(),this._integrationMaterial=Oy());const t=this._cubeSize,n=e.texture.mipmaps.length-1,s=this._ggxMaterial.uniforms;s.envMap.value=this._sourceTarget.texture;const a=this._integrationMaterial.uniforms;a.envMap.value=this._sourceTarget.texture,a.sourceLod.value=Math.log2(t/Jf);for(let r=0;r<=n;r++){const o=Ao.lodToRoughness(r,n);if(r>n-Iy)a.roughness.value=o,this._renderCube(e,r,this._integrationMaterial);else{const l=o>0?Math.log2(t)+.5*Math.log2(6/(Zf*Math.pow(o,4)))+.5:0;s.roughness.value=o,s.lodBias.value=l,this._renderCube(e,r,this._ggxMaterial)}}}_blur(e,t){this._blurMaterial===null&&(this._blurMaterial=ky());const n=this._blurMaterial,s=n.uniforms,a=this._sourceTarget;s.sigma.value=Math.min(t,Math.PI)/Math.SQRT2,s.envMap.value=a.texture,this._renderCube(e,0,n),s.envMap.value=e.texture,this._renderCube(a,0,n)}}function Gh(i,e,t){return new Td(i,{minFilter:Li,generateMipmaps:e,type:gi,colorSpace:mo,depthBuffer:t})}function sr(i,e,t){return new Pn({name:i,uniforms:e,vertexShader:qe.cube_vert,fragmentShader:t,side:rn,blending:Ks,depthTest:!1,depthWrite:!1})}function Fy(){return sr("PMREMGGXConvolution",{envMap:{value:null},roughness:{value:0},lodBias:{value:0}},`

		#define GGX_SAMPLES ${Zf}u

		varying vec3 vWorldDirection;

		uniform samplerCube envMap;
		uniform float roughness;
		uniform float lodBias;

		#include <common>

		// Van der Corput radical inverse
		float radicalInverse_VdC( uint bits ) {

			bits = ( bits << 16u ) | ( bits >> 16u );
			bits = ( ( bits & 0x55555555u ) << 1u ) | ( ( bits & 0xAAAAAAAAu ) >> 1u );
			bits = ( ( bits & 0x33333333u ) << 2u ) | ( ( bits & 0xCCCCCCCCu ) >> 2u );
			bits = ( ( bits & 0x0F0F0F0Fu ) << 4u ) | ( ( bits & 0xF0F0F0F0u ) >> 4u );
			bits = ( ( bits & 0x00FF00FFu ) << 8u ) | ( ( bits & 0xFF00FF00u ) >> 8u );
			return float( bits ) * 2.3283064365386963e-10; // / 0x100000000

		}

		// Hammersley sequence
		vec2 hammersley( uint i, uint N ) {

			return vec2( float( i ) / float( N ), radicalInverse_VdC( i ) );

		}

		void main() {

			vec3 N = normalize( vWorldDirection );

			// For very low roughness, just sample the environment directly
			if ( roughness < 0.001 ) {

				gl_FragColor = vec4( textureLod( envMap, N, 0.0 ).rgb, 1.0 );
				return;

			}

			float alpha = roughness * roughness;
			float alpha2 = alpha * alpha;

			// Tangent space basis for VNDF sampling
			vec3 up = abs( N.z ) < 0.999 ? vec3( 0.0, 0.0, 1.0 ) : vec3( 1.0, 0.0, 0.0 );
			vec3 tangent = normalize( cross( up, N ) );
			vec3 bitangent = cross( N, tangent );

			vec3 prefilteredColor = vec3( 0.0 );
			float totalWeight = 0.0;

			for ( uint i = 0u; i < GGX_SAMPLES; i ++ ) {

				vec2 Xi = hammersley( i, GGX_SAMPLES );

				// With V = N, sample the reflected direction directly.
				float invQ = 1.0 / ( 1.0 - Xi.x + alpha2 * Xi.x );
				float NdotL = ( 1.0 - Xi.x - alpha2 * Xi.x ) * invQ;

				if ( NdotL > 0.0 ) {

					float phi = 2.0 * PI * Xi.y;
					float sinTheta = 2.0 * alpha * sqrt( Xi.x * ( 1.0 - Xi.x ) ) * invQ;
					vec3 L = N * NdotL + ( tangent * cos( phi ) + bitangent * sin( phi ) ) * sinTheta;

					// Match the source mip to the sample's solid angle. The terms
					// independent of the sample are precomputed in lodBias.
					float d = alpha2 * invQ;
					float lod = max( log2( d ) + lodBias, 0.0 );

					// Weight by NdotL for the split-sum approximation
					prefilteredColor += textureLod( envMap, L, lod ).rgb * NdotL;
					totalWeight += NdotL;

				}

			}

			gl_FragColor = vec4( prefilteredColor / totalWeight, 1.0 );

		}
	`)}function Oy(){return sr("PMREMGGXIntegration",{envMap:{value:null},roughness:{value:0},sourceLod:{value:0},sourceSize:{value:Jf}},`

		varying vec3 vWorldDirection;

		uniform samplerCube envMap;
		uniform float roughness;
		uniform float sourceLod;
		uniform int sourceSize;

		void main() {

			vec3 N = normalize( vWorldDirection );

			float alpha = roughness * roughness;
			float alpha2 = alpha * alpha;

			float texelSize = 2.0 / float( sourceSize );

			vec3 prefilteredColor = vec3( 0.0 );
			float totalWeight = 0.0;

			// Pair opposite texels: only the one in N's hemisphere contributes.
			for ( int face = 0; face < 3; face ++ ) {

				for ( int y = 0; y < sourceSize; y ++ ) {

					for ( int x = 0; x < sourceSize; x ++ ) {

						vec2 uv = ( vec2( x, y ) + 0.5 ) * texelSize - 1.0;
						vec3 texelDirection = face == 0 ? vec3( 1.0, uv ) : ( face == 1 ? vec3( uv.x, 1.0, uv.y ) : vec3( uv, 1.0 ) );

						float invDistance = inversesqrt( 1.0 + dot( uv, uv ) );
						float NdotL = dot( N, texelDirection );
						texelDirection *= NdotL < 0.0 ? - 1.0 : 1.0;
						NdotL = abs( NdotL ) * invDistance;

						// With V = N, NdotH squared is ( 1 + NdotL ) / 2. Common factors
						// in the GGX distribution and texel solid angle cancel when normalized.
						float d = 1.0 + alpha2 + ( alpha2 - 1.0 ) * NdotL;
						float weight = NdotL * invDistance * invDistance * invDistance / ( d * d );

						prefilteredColor += textureLod( envMap, texelDirection, sourceLod ).rgb * weight;
						totalWeight += weight;

					}

				}

			}

			gl_FragColor = vec4( prefilteredColor / totalWeight, 1.0 );

		}
	`)}function ky(){return sr("PMREMSphericalGaussianBlur",{envMap:{value:null},sigma:{value:0}},`

		#define SAMPLES ${Dy}
		#define GOLDEN_ANGLE 2.39996322973

		varying vec3 vWorldDirection;

		uniform samplerCube envMap;
		uniform float sigma;

		#include <common>

		void main() {

			vec3 outputDirection = normalize( vWorldDirection );

			vec3 up = abs( outputDirection.z ) < 0.999 ? vec3( 0.0, 0.0, 1.0 ) : vec3( 1.0, 0.0, 0.0 );
			vec3 tangent = normalize( cross( up, outputDirection ) );
			vec3 bitangent = cross( outputDirection, tangent );

			// Truncate the kernel at three standard deviations or at the antipode.
			float thetaMax = min( 3.0 * sigma, PI );
			float truncation = 1.0 - exp( - 0.5 * thetaMax * thetaMax / ( sigma * sigma ) );

			vec3 accumColor = vec3( 0.0 );
			float accumWeight = 0.0;

			for ( int i = 0; i < SAMPLES; i ++ ) {

				// Stratified inverse-CDF sampling of the Gaussian, placed on a golden-angle spiral.
				float stratum = ( float( i ) + 0.5 ) / float( SAMPLES );
				float theta = sigma * sqrt( - 2.0 * log( 1.0 - stratum * truncation ) );
				float phi = float( i ) * GOLDEN_ANGLE;

				vec3 offset = cos( phi ) * tangent + sin( phi ) * bitangent;
				vec3 sampleDirection = cos( theta ) * outputDirection + sin( theta ) * offset;

				// Correct the planar sample density to solid angle.
				float weight = sin( theta ) / theta;

				accumColor += weight * textureLod( envMap, sampleDirection, 0.0 ).rgb;
				accumWeight += weight;

			}

			gl_FragColor = vec4( accumColor / accumWeight, 1.0 );

		}
	`)}function Vh(){return sr("PMREMEquirectangularToCubemap",{envMap:{value:null}},`

		varying vec3 vWorldDirection;

		uniform sampler2D envMap;

		#include <common>

		void main() {

			// Average four subpixel samples to preserve small, bright features.
			vec3 direction = normalize( vWorldDirection );
			vec3 dx = dFdx( direction ) * 0.25;
			vec3 dy = dFdy( direction ) * 0.25;

			vec3 color = textureLod( envMap, equirectUv( normalize( direction - dx - dy ) ), 0.0 ).rgb;
			color += textureLod( envMap, equirectUv( normalize( direction + dx - dy ) ), 0.0 ).rgb;
			color += textureLod( envMap, equirectUv( normalize( direction - dx + dy ) ), 0.0 ).rgb;
			color += textureLod( envMap, equirectUv( normalize( direction + dx + dy ) ), 0.0 ).rgb;
			gl_FragColor = vec4( color * 0.25, 1.0 );

		}
	`)}function Wh(){return sr("PMREMCubemapToCubemap",{envMap:{value:null},flipEnvMap:{value:-1}},`

		varying vec3 vWorldDirection;

		uniform samplerCube envMap;
		uniform float flipEnvMap;

		void main() {

			gl_FragColor = vec4( textureCube( envMap, vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) ).rgb, 1.0 );

		}
	`)}function By(i){let e=new WeakMap,t=new WeakMap,n=null;function s(u,f=!1){return u==null?null:f?r(u):a(u)}function a(u){if(u&&u.isTexture){const f=u.mapping;if(f===hl||f===ul)if(e.has(u)){const g=e.get(u).texture;return o(g,u.mapping)}else{const g=u.image;if(g&&g.height>0){const y=new Td(g.height);return y.fromEquirectangularTexture(i,u),e.set(u,y),u.addEventListener("dispose",c),o(y.texture,u.mapping)}else return null}}return u}function r(u){if(u&&u.isTexture&&u.isPMREMTexture!==!0){const f=u.mapping,g=f===hl||f===ul,y=f===sa||f===Ha;if(g||y){let m=t.get(u);const p=m!==void 0?m.texture.pmremVersion:0;if(u.isRenderTargetTexture&&u.pmremVersion!==p)return n===null&&(n=new Ao(i)),m=g?n.fromEquirectangular(u,m):n.fromCubemap(u,m),m.texture.pmremVersion=u.pmremVersion,t.set(u,m),m.texture;if(m!==void 0)return m.texture;{const x=u.image;return g&&x&&x.height>0||y&&x&&l(x)?(n===null&&(n=new Ao(i)),m=g?n.fromEquirectangular(u):n.fromCubemap(u),m.texture.pmremVersion=u.pmremVersion,t.set(u,m),u.addEventListener("dispose",d),m.texture):null}}}return u}function o(u,f){return f===hl?u.mapping=sa:f===ul&&(u.mapping=Ha),u}function l(u){let f=0;const g=6;for(let y=0;y<g;y++)u[y]!==void 0&&f++;return f===g}function c(u){const f=u.target;f.removeEventListener("dispose",c);const g=e.get(f);g!==void 0&&(e.delete(f),g.dispose())}function d(u){const f=u.target;f.removeEventListener("dispose",d);const g=t.get(f);g!==void 0&&(t.delete(f),g.dispose())}function h(){e=new WeakMap,t=new WeakMap,n!==null&&(n.dispose(),n=null)}return{get:s,dispose:h}}function zy(i){const e={};function t(n){if(e[n]!==void 0)return e[n];const s=i.getExtension(n);return e[n]=s,s}return{has:function(n){return t(n)!==null},init:function(){t("EXT_color_buffer_float"),t("WEBGL_clip_cull_distance"),t("OES_texture_float_linear"),t("EXT_color_buffer_half_float"),t("WEBGL_multisampled_render_to_texture"),t("WEBGL_render_shared_exponent")},get:function(n){const s=t(n);return s===null&&no("WebGLRenderer: "+n+" extension not supported."),s}}}function $y(i,e,t,n){const s={},a=new WeakMap,r=new FinalizationRegistry(g=>delete s[g]);function o(g){l(g.target)}function l(g){g.index!==null&&e.remove(g.index);for(const m in g.attributes)e.remove(g.attributes[m]);g.removeEventListener("dispose",o),delete s[g.id],r.unregister(g);const y=a.get(g);y&&(e.remove(y),a.delete(g)),n.releaseStatesOfGeometry(g),g.isInstancedBufferGeometry===!0&&delete g._maxInstanceCount,t.memory.geometries--}function c(g,y){return s[y.id]!==void 0||(y.addEventListener("dispose",o),s[y.id]=new WeakRef(y),r.register(y,y.id,y),t.memory.geometries++),y}function d(g){const y=g.attributes;for(const m in y)e.update(y[m],i.ARRAY_BUFFER)}function h(g){const y=g.index,m=g.attributes.position;let p=0;if(m===void 0)return;const x=y!==null?y.array.length:m.array.length/3-1,A=m.count>=65535?Nf:If,b=new A(Math.ceil(x/3)*6,1),E=b.array;if(y!==null){const v=y.array;p=y.version;for(let w=0,P=0;w<x;w+=3){const R=v[w+0],N=v[w+1],F=v[w+2];E[P++]=R,E[P++]=N,E[P++]=N,E[P++]=F,E[P++]=F,E[P++]=R}}else{p=m.version;for(let v=0,w=0;v<x;v+=3){const P=v+0,R=v+1,N=v+2;E[w++]=P,E[w++]=R,E[w++]=R,E[w++]=N,E[w++]=N,E[w++]=P}}b.version=p;const S=a.get(g);S&&e.remove(S),a.set(g,b)}function u(g){const y=a.get(g);if(y){const m=g.index;m!==null&&y.version<m.version&&h(g)}else h(g);return a.get(g)}function f(){for(const g in s){const y=s[g].deref();y!==void 0&&l(y)}}return{get:c,update:d,getWireframeAttribute:u,dispose:f}}function Hy(i,e,t){let n;function s(h){n=h}let a,r;function o(h){a=h.type,r=h.bytesPerElement}function l(h,u){i.drawElements(n,u,a,h*r),t.update(u,n,1)}function c(h,u,f){f!==0&&(i.drawElementsInstanced(n,u,a,h*r,f),t.update(u,n,f))}function d(h,u,f){if(f===0)return;e.get("WEBGL_multi_draw").multiDrawElementsWEBGL(n,u,0,a,h,0,f);let y=0;for(let m=0;m<f;m++)y+=u[m];t.update(y,n,1)}this.setMode=s,this.setIndex=o,this.render=l,this.renderInstances=c,this.renderMultiDraw=d}function Gy(i){const e={geometries:0,textures:0},t={frame:0,calls:0,triangles:0,points:0,lines:0};function n(a,r,o){switch(t.calls++,r){case i.TRIANGLES:t.triangles+=o*(a/3);break;case i.LINES:t.lines+=o*(a/2);break;case i.LINE_STRIP:t.lines+=o*(a-1);break;case i.LINE_LOOP:t.lines+=o*a;break;case i.POINTS:t.points+=o*a;break;default:it("WebGLInfo: Unknown draw mode:",r);break}}function s(){t.calls=0,t.triangles=0,t.points=0,t.lines=0}return{memory:e,render:t,programs:null,autoReset:!0,reset:s,update:n}}function Vy(i,e,t){const n=new WeakMap,s=new Tt;function a(r,o,l){const c=r.morphTargetInfluences,d=o.morphAttributes.position||o.morphAttributes.normal||o.morphAttributes.color,h=d!==void 0?d.length:0;let u=n.get(o);if(u===void 0||u.count!==h){let R=function(){w.dispose(),n.delete(o),o.removeEventListener("dispose",R)};var f=R;u!==void 0&&u.texture.dispose();const g=o.morphAttributes.position!==void 0,y=o.morphAttributes.normal!==void 0,m=o.morphAttributes.color!==void 0,p=o.morphAttributes.position||[],x=o.morphAttributes.normal||[],A=o.morphAttributes.color||[];let b=0;g===!0&&(b=1),y===!0&&(b=2),m===!0&&(b=3);let E=o.attributes.position.count*b,S=1;E>e.maxTextureSize&&(S=Math.ceil(E/e.maxTextureSize),E=e.maxTextureSize);const v=new Float32Array(E*S*4*h),w=new Lf(v,E,S,h);w.type=ii,w.needsUpdate=!0;const P=b*4;for(let N=0;N<h;N++){const F=p[N],G=x[N],L=A[N],z=E*S*4*N;for(let X=0;X<F.count;X++){const $=X*P;g===!0&&(s.fromBufferAttribute(F,X),v[z+$+0]=s.x,v[z+$+1]=s.y,v[z+$+2]=s.z,v[z+$+3]=0),y===!0&&(s.fromBufferAttribute(G,X),v[z+$+4]=s.x,v[z+$+5]=s.y,v[z+$+6]=s.z,v[z+$+7]=0),m===!0&&(s.fromBufferAttribute(L,X),v[z+$+8]=s.x,v[z+$+9]=s.y,v[z+$+10]=s.z,v[z+$+11]=L.itemSize===4?s.w:1)}}u={count:h,texture:w,size:new Ie(E,S)},n.set(o,u),o.addEventListener("dispose",R)}if(r.isInstancedMesh===!0&&r.morphTexture!==null)l.getUniforms().setValue(i,"morphTexture",r.morphTexture,t);else{let g=0;for(let m=0;m<c.length;m++)g+=c[m];const y=o.morphTargetsRelative?1:1-g;l.getUniforms().setValue(i,"morphTargetBaseInfluence",y),l.getUniforms().setValue(i,"morphTargetInfluences",c)}l.getUniforms().setValue(i,"morphTargetsTexture",u.texture,t),l.getUniforms().setValue(i,"morphTargetsTextureSize",u.size)}return{update:a}}function Wy(i,e,t,n,s){let a=new WeakMap;function r(c){const d=s.render.frame,h=c.geometry,u=e.get(c,h);if(a.get(u)!==d&&(e.update(u),a.set(u,d)),c.isInstancedMesh&&(c.hasEventListener("dispose",l)===!1&&c.addEventListener("dispose",l),a.get(c)!==d&&(t.update(c.instanceMatrix,i.ARRAY_BUFFER),c.instanceColor!==null&&t.update(c.instanceColor,i.ARRAY_BUFFER),a.set(c,d))),c.isSkinnedMesh){const f=c.skeleton;a.get(f)!==d&&(f.update(),a.set(f,d))}return u}function o(){a=new WeakMap}function l(c){const d=c.target;d.removeEventListener("dispose",l),n.releaseStatesOfObject(d),t.remove(d.instanceMatrix),d.instanceColor!==null&&t.remove(d.instanceColor)}return{update:r,dispose:o}}const Xy={[uf]:"LINEAR_TONE_MAPPING",[ff]:"REINHARD_TONE_MAPPING",[pf]:"CINEON_TONE_MAPPING",[ud]:"ACES_FILMIC_TONE_MAPPING",[gf]:"AGX_TONE_MAPPING",[vf]:"NEUTRAL_TONE_MAPPING",[mf]:"CUSTOM_TONE_MAPPING"};function qy(i,e,t,n,s,a){const r=new Vn(e,t,{type:i,depthBuffer:s,stencilBuffer:a,samples:n?4:0,storeMultisampledDepthBuffer:!1,storeMultisampledStencilBuffer:!1,resolveDepthBuffer:!1,resolveStencilBuffer:!1});let o=null,l=null,c=null;const d=new bt;d.setAttribute("position",new st([-1,3,0,-1,-1,0,3,-1,0],3)),d.setAttribute("uv",new st([0,2,0,0,2,0],2));const h=new O0({uniforms:{tDiffuse:{value:null}},vertexShader:`
			precision highp float;

			uniform mat4 modelViewMatrix;
			uniform mat4 projectionMatrix;

			attribute vec3 position;
			attribute vec2 uv;

			varying vec2 vUv;

			void main() {
				vUv = uv;
				gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
			}`,fragmentShader:`
			precision highp float;

			uniform sampler2D tDiffuse;

			varying vec2 vUv;

			#include <tonemapping_pars_fragment>
			#include <colorspace_pars_fragment>

			void main() {
				gl_FragColor = texture2D( tDiffuse, vUv );

				#ifdef LINEAR_TONE_MAPPING
					gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );
				#elif defined( REINHARD_TONE_MAPPING )
					gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );
				#elif defined( CINEON_TONE_MAPPING )
					gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );
				#elif defined( ACES_FILMIC_TONE_MAPPING )
					gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );
				#elif defined( AGX_TONE_MAPPING )
					gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );
				#elif defined( NEUTRAL_TONE_MAPPING )
					gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );
				#elif defined( CUSTOM_TONE_MAPPING )
					gl_FragColor.rgb = CustomToneMapping( gl_FragColor.rgb );
				#endif

				#ifdef SRGB_TRANSFER
					gl_FragColor = sRGBTransferOETF( gl_FragColor );
				#endif
			}`,depthTest:!1,depthWrite:!1}),u=new Te(d,h),f=new Ad(-1,1,1,-1,0,1);let g=null,y=null,m=!1,p,x=null,A=[],b=!1;this.setSize=function(E,S){r.setSize(E,S),o!==null&&o.setSize(E,S),l!==null&&l.setSize(E,S);for(let v=0;v<A.length;v++){const w=A[v];w.setSize&&w.setSize(E,S)}},this.setEffects=function(E){A=E,b=A.length>0&&A[0].isRenderPass===!0;const S=r.width,v=r.height;A.length>0&&o===null&&(o=new Vn(S,v,{type:gi,depthBuffer:!1,stencilBuffer:!1}),l=new Vn(S,v,{type:gi,depthBuffer:!1,stencilBuffer:!1}));const w=s===!0&&A.some(P=>P.needsDepthTexture===!0);w!==(r.depthTexture!==null)&&(w===!0&&c===null&&(c=new oa(S,v),a===!0&&(c.format=Ji,c.type=aa)),r.dispose(),r.depthTexture=w?c:null,r.resolveDepthBuffer=w,r.storeMultisampledDepthBuffer=w);for(let P=0;P<A.length;P++){const R=A[P];R.setSize&&R.setSize(S,v),w&&R.needsDepthTexture===!0&&R.setDepthTexture&&R.setDepthTexture(c)}},this.begin=function(E,S){if(m||E.toneMapping===Ii&&A.length===0)return!1;if(x=S,S!==null){const v=S.width,w=S.height;(r.width!==v||r.height!==w)&&this.setSize(v,w)}return b===!1&&E.setRenderTarget(r),p=E.toneMapping,E.toneMapping=Ii,!0},this.hasRenderPass=function(){return b},this.end=function(E,S){E.toneMapping=p,m=!0;let v=r,w=o;for(let P=0;P<A.length;P++){const R=A[P];R.enabled!==!1&&(R.render(E,w,v,S),R.needsSwap!==!1&&(v=w,w=w===o?l:o))}if(g!==E.outputColorSpace||y!==E.toneMapping){g=E.outputColorSpace,y=E.toneMapping,h.defines={},et.getTransfer(g)===lt&&(h.defines.SRGB_TRANSFER="");const P=Xy[y];P&&(h.defines[P]=""),h.needsUpdate=!0}h.uniforms.tDiffuse.value=v.texture,E.setRenderTarget(x),E.render(u,f),x=null,m=!1},this.isCompositing=function(){return m},this.dispose=function(){r.dispose(),o!==null&&o.dispose(),l!==null&&l.dispose(),d.dispose(),h.dispose()}}const jf=new un,Qf=new oa(1,1),ep=new Bf(1),tp=new Lf,np=new p0,ip=new kf,Xh=[],qh=[],Yh=new Float32Array(16),Kh=new Float32Array(9),Zh=new Float32Array(4);function ha(i,e,t){const n=i[0];if(n<=0||n>0)return i;const s=e*t;let a=Xh[s];if(a===void 0&&(a=new Float32Array(s),Xh[s]=a),e!==0){n.toArray(a,0);for(let r=1,o=0;r!==e;++r)o+=t,i[r].toArray(a,o)}return a}function Gt(i,e){if(i.length!==e.length)return!1;for(let t=0,n=i.length;t<n;t++)if(i[t]!==e[t])return!1;return!0}function Vt(i,e){for(let t=0,n=e.length;t<n;t++)i[t]=e[t]}function Zo(i,e){let t=qh[e];t===void 0&&(t=new Int32Array(e),qh[e]=t);for(let n=0;n!==e;++n)t[n]=i.allocateTextureUnit();return t}function Yy(i,e){const t=this.cache;t[0]!==e&&(i.uniform1f(this.addr,e),t[0]=e)}function Ky(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2f(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Gt(t,e))return;i.uniform2fv(this.addr,e),Vt(t,e)}}function Zy(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3f(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else if(e.r!==void 0)(t[0]!==e.r||t[1]!==e.g||t[2]!==e.b)&&(i.uniform3f(this.addr,e.r,e.g,e.b),t[0]=e.r,t[1]=e.g,t[2]=e.b);else{if(Gt(t,e))return;i.uniform3fv(this.addr,e),Vt(t,e)}}function Jy(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4f(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Gt(t,e))return;i.uniform4fv(this.addr,e),Vt(t,e)}}function jy(i,e){const t=this.cache,n=e.elements;if(n===void 0){if(Gt(t,e))return;i.uniformMatrix2fv(this.addr,!1,e),Vt(t,e)}else{if(Gt(t,n))return;Zh.set(n),i.uniformMatrix2fv(this.addr,!1,Zh),Vt(t,n)}}function Qy(i,e){const t=this.cache,n=e.elements;if(n===void 0){if(Gt(t,e))return;i.uniformMatrix3fv(this.addr,!1,e),Vt(t,e)}else{if(Gt(t,n))return;Kh.set(n),i.uniformMatrix3fv(this.addr,!1,Kh),Vt(t,n)}}function ex(i,e){const t=this.cache,n=e.elements;if(n===void 0){if(Gt(t,e))return;i.uniformMatrix4fv(this.addr,!1,e),Vt(t,e)}else{if(Gt(t,n))return;Yh.set(n),i.uniformMatrix4fv(this.addr,!1,Yh),Vt(t,n)}}function tx(i,e){const t=this.cache;t[0]!==e&&(i.uniform1i(this.addr,e),t[0]=e)}function nx(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2i(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Gt(t,e))return;i.uniform2iv(this.addr,e),Vt(t,e)}}function ix(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3i(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(Gt(t,e))return;i.uniform3iv(this.addr,e),Vt(t,e)}}function sx(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4i(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Gt(t,e))return;i.uniform4iv(this.addr,e),Vt(t,e)}}function ax(i,e){const t=this.cache;t[0]!==e&&(i.uniform1ui(this.addr,e),t[0]=e)}function rx(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2ui(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Gt(t,e))return;i.uniform2uiv(this.addr,e),Vt(t,e)}}function ox(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3ui(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(Gt(t,e))return;i.uniform3uiv(this.addr,e),Vt(t,e)}}function lx(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4ui(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Gt(t,e))return;i.uniform4uiv(this.addr,e),Vt(t,e)}}function Jo(i){return i.version===0&&(i.compareFunction=Tf,i.needsUpdate=!0),i}function cx(i,e,t){const n=this.cache,s=t.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s);let a;this.type===i.SAMPLER_2D_SHADOW?a=Jo(Qf):a=jf,t.setTexture2D(e||a,s)}function dx(i,e,t){const n=this.cache,s=t.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),t.setTexture3D(e||np,s)}function hx(i,e,t){const n=this.cache,s=t.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s);let a;this.type===i.SAMPLER_CUBE_SHADOW?a=Jo(ep):a=ip,t.setTextureCube(e||a,s)}function ux(i,e,t){const n=this.cache,s=t.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),t.setTexture2DArray(e||tp,s)}function fx(i){switch(i){case 5126:return Yy;case 35664:return Ky;case 35665:return Zy;case 35666:return Jy;case 35674:return jy;case 35675:return Qy;case 35676:return ex;case 5124:case 35670:return tx;case 35667:case 35671:return nx;case 35668:case 35672:return ix;case 35669:case 35673:return sx;case 5125:return ax;case 36294:return rx;case 36295:return ox;case 36296:return lx;case 35678:case 36198:case 36298:case 36306:case 35682:return cx;case 35679:case 36299:case 36307:return dx;case 35680:case 36300:case 36308:case 36293:return hx;case 36289:case 36303:case 36311:case 36292:return ux}}function px(i,e){i.uniform1fv(this.addr,e)}function mx(i,e){const t=ha(e,this.size,2);i.uniform2fv(this.addr,t)}function gx(i,e){const t=ha(e,this.size,3);i.uniform3fv(this.addr,t)}function vx(i,e){const t=ha(e,this.size,4);i.uniform4fv(this.addr,t)}function yx(i,e){const t=ha(e,this.size,4);i.uniformMatrix2fv(this.addr,!1,t)}function xx(i,e){const t=ha(e,this.size,9);i.uniformMatrix3fv(this.addr,!1,t)}function bx(i,e){const t=ha(e,this.size,16);i.uniformMatrix4fv(this.addr,!1,t)}function _x(i,e){i.uniform1iv(this.addr,e)}function Mx(i,e){i.uniform2iv(this.addr,e)}function wx(i,e){i.uniform3iv(this.addr,e)}function Sx(i,e){i.uniform4iv(this.addr,e)}function Ex(i,e){i.uniform1uiv(this.addr,e)}function Ax(i,e){i.uniform2uiv(this.addr,e)}function Tx(i,e){i.uniform3uiv(this.addr,e)}function Rx(i,e){i.uniform4uiv(this.addr,e)}function Cx(i,e,t){const n=this.cache,s=e.length,a=Zo(t,s);Gt(n,a)||(i.uniform1iv(this.addr,a),Vt(n,a));let r;this.type===i.SAMPLER_2D_SHADOW?r=Jo(Qf):r=jf;for(let o=0;o!==s;++o)t.setTexture2D(e[o]||r,a[o])}function Px(i,e,t){const n=this.cache,s=e.length,a=Zo(t,s);Gt(n,a)||(i.uniform1iv(this.addr,a),Vt(n,a));for(let r=0;r!==s;++r)t.setTexture3D(e[r]||np,a[r])}function Lx(i,e,t){const n=this.cache,s=e.length,a=Zo(t,s);Gt(n,a)||(i.uniform1iv(this.addr,a),Vt(n,a));let r;this.type===i.SAMPLER_CUBE_SHADOW?r=Jo(ep):r=ip;for(let o=0;o!==s;++o)t.setTextureCube(e[o]||r,a[o])}function Dx(i,e,t){const n=this.cache,s=e.length,a=Zo(t,s);Gt(n,a)||(i.uniform1iv(this.addr,a),Vt(n,a));for(let r=0;r!==s;++r)t.setTexture2DArray(e[r]||tp,a[r])}function Ix(i){switch(i){case 5126:return px;case 35664:return mx;case 35665:return gx;case 35666:return vx;case 35674:return yx;case 35675:return xx;case 35676:return bx;case 5124:case 35670:return _x;case 35667:case 35671:return Mx;case 35668:case 35672:return wx;case 35669:case 35673:return Sx;case 5125:return Ex;case 36294:return Ax;case 36295:return Tx;case 36296:return Rx;case 35678:case 36198:case 36298:case 36306:case 35682:return Cx;case 35679:case 36299:case 36307:return Px;case 35680:case 36300:case 36308:case 36293:return Lx;case 36289:case 36303:case 36311:case 36292:return Dx}}class Nx{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.setValue=fx(t.type)}}class Ux{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.size=t.size,this.setValue=Ix(t.type)}}class Fx{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,t,n){const s=this.seq;for(let a=0,r=s.length;a!==r;++a){const o=s[a];o.setValue(e,t[o.id],n)}}}const Bl=/(\w+)(\])?(\[|\.)?/g;function Jh(i,e){i.seq.push(e),i.map[e.id]=e}function Ox(i,e,t){const n=i.name,s=n.length;for(Bl.lastIndex=0;;){const a=Bl.exec(n),r=Bl.lastIndex;let o=a[1];const l=a[2]==="]",c=a[3];if(l&&(o=o|0),c===void 0||c==="["&&r+2===s){Jh(t,c===void 0?new Nx(o,i,e):new Ux(o,i,e));break}else{let h=t.map[o];h===void 0&&(h=new Fx(o),Jh(t,h)),t=h}}}class io{constructor(e,t){this.seq=[],this.map={};const n=e.getProgramParameter(t,e.ACTIVE_UNIFORMS);for(let r=0;r<n;++r){const o=e.getActiveUniform(t,r),l=e.getUniformLocation(t,o.name);Ox(o,l,this)}const s=[],a=[];for(const r of this.seq)r.type===e.SAMPLER_2D_SHADOW||r.type===e.SAMPLER_CUBE_SHADOW||r.type===e.SAMPLER_2D_ARRAY_SHADOW?s.push(r):a.push(r);s.length>0&&(this.seq=s.concat(a))}setValue(e,t,n,s){const a=this.map[t];a!==void 0&&a.setValue(e,n,s)}setOptional(e,t,n){const s=t[n];s!==void 0&&this.setValue(e,n,s)}static upload(e,t,n,s){for(let a=0,r=t.length;a!==r;++a){const o=t[a],l=n[o.id];l.needsUpdate!==!1&&o.setValue(e,l.value,s)}}static seqWithValue(e,t){const n=[];for(let s=0,a=e.length;s!==a;++s){const r=e[s];r.id in t&&n.push(r)}return n}}function jh(i,e,t){const n=i.createShader(e);return i.shaderSource(n,t),i.compileShader(n),n}const kx=37297;let Bx=0;function zx(i,e){const t=i.split(`
`),n=[],s=Math.max(e-6,0),a=Math.min(e+6,t.length);for(let r=s;r<a;r++){const o=r+1;n.push(`${o===e?">":" "} ${o}: ${t[r]}`)}return n.join(`
`)}const Qh=new ke;function $x(i){et._getMatrix(Qh,et.workingColorSpace,i);const e=`mat3( ${Qh.elements.map(t=>t.toFixed(4))} )`;switch(et.getTransfer(i)){case go:return[e,"LinearTransferOETF"];case lt:return[e,"sRGBTransferOETF"];default:return Ue("WebGLProgram: Unsupported color space: ",i),[e,"LinearTransferOETF"]}}function eu(i,e,t){const n=i.getShaderParameter(e,i.COMPILE_STATUS),a=(i.getShaderInfoLog(e)||"").trim();if(n&&a==="")return"";const r=/ERROR: 0:(\d+)/.exec(a);if(r){const o=parseInt(r[1]);return t.toUpperCase()+`

`+a+`

`+zx(i.getShaderSource(e),o)}else return a}function Hx(i,e){const t=$x(e);return[`vec4 ${i}( vec4 value ) {`,`	return ${t[1]}( vec4( ${t[0]} * value.rgb, value.a ) );`,"}"].join(`
`)}const Gx={[uf]:"Linear",[ff]:"Reinhard",[pf]:"Cineon",[ud]:"ACESFilmic",[gf]:"AgX",[vf]:"Neutral",[mf]:"Custom"};function Vx(i,e){const t=Gx[e];return t===void 0?(Ue("WebGLProgram: Unsupported toneMapping:",e),"vec3 "+i+"( vec3 color ) { return LinearToneMapping( color ); }"):"vec3 "+i+"( vec3 color ) { return "+t+"ToneMapping( color ); }"}const zr=new D;function Wx(){et.getLuminanceCoefficients(zr);const i=zr.x.toFixed(4),e=zr.y.toFixed(4),t=zr.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${i}, ${e}, ${t} );`,"	return dot( weights, rgb );","}"].join(`
`)}function Xx(i){return[i.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",i.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(Ta).join(`
`)}function qx(i){const e=[];for(const t in i){const n=i[t];n!==!1&&e.push("#define "+t+" "+n)}return e.join(`
`)}function Yx(i,e){const t={},n=i.getProgramParameter(e,i.ACTIVE_ATTRIBUTES);for(let s=0;s<n;s++){const a=i.getActiveAttrib(e,s),r=a.name;let o=1;a.type===i.FLOAT_MAT2&&(o=2),a.type===i.FLOAT_MAT3&&(o=3),a.type===i.FLOAT_MAT4&&(o=4),t[r]={type:a.type,location:i.getAttribLocation(e,r),locationSize:o}}return t}function Ta(i){return i!==""}function tu(i,e){const t=e.numSpotLightShadows+e.numSpotLightMaps-e.numSpotLightShadowsWithMaps;return i.replace(/NUM_SUN_LIGHTS/g,e.numSunLights).replace(/NUM_DIR_LIGHTS/g,e.numDirLights).replace(/NUM_SPOT_LIGHTS/g,e.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,e.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,t).replace(/NUM_RECT_AREA_LIGHTS/g,e.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,e.numPointLights).replace(/NUM_HEMI_LIGHTS/g,e.numHemiLights).replace(/NUM_SUN_LIGHT_SHADOWS/g,e.numSunLightShadows).replace(/NUM_DIR_LIGHT_SHADOWS/g,e.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,e.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,e.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,e.numPointLightShadows).replace(/NUM_LIGHT_PROBE_GRIDS/g,e.numLightProbeGrids)}function nu(i,e){return i.replace(/NUM_CLIPPING_PLANES/g,e.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,e.numClippingPlanes-e.numClipIntersection)}const Kx=/^[ \t]*#include +<([\w\d./]+)>/gm;function Vc(i){return i.replace(Kx,Zx)}function Zx(i,e){const t=qe[e];if(t===void 0)throw new Error("THREE.WebGLProgram: Can not resolve #include <"+e+">");return Vc(t)}const Jx=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function iu(i){return i.replace(Jx,jx)}function jx(i,e,t,n){let s="";for(let a=parseInt(e);a<parseInt(t);a++)s+=n.replace(/\[\s*i\s*\]/g,"[ "+a+" ]").replace(/UNROLLED_LOOP_INDEX/g,a);return s}function su(i){let e=`precision ${i.precision} float;
	precision ${i.precision} int;
	precision ${i.precision} sampler2D;
	precision ${i.precision} samplerCube;
	precision ${i.precision} sampler3D;
	precision ${i.precision} sampler2DArray;
	precision ${i.precision} sampler2DShadow;
	precision ${i.precision} samplerCubeShadow;
	precision ${i.precision} sampler2DArrayShadow;
	precision ${i.precision} isampler2D;
	precision ${i.precision} isampler3D;
	precision ${i.precision} isamplerCube;
	precision ${i.precision} isampler2DArray;
	precision ${i.precision} usampler2D;
	precision ${i.precision} usampler3D;
	precision ${i.precision} usamplerCube;
	precision ${i.precision} usampler2DArray;
	`;return i.precision==="highp"?e+=`
#define HIGH_PRECISION`:i.precision==="mediump"?e+=`
#define MEDIUM_PRECISION`:i.precision==="lowp"&&(e+=`
#define LOW_PRECISION`),e}const Qx={[Jr]:"SHADOWMAP_TYPE_PCF",[Aa]:"SHADOWMAP_TYPE_VSM"};function eb(i){return Qx[i.shadowMapType]||"SHADOWMAP_TYPE_BASIC"}const tb={[Ha]:"ENVMAP_MODE_REFRACTION"};function nb(i){return i.envMap===!1?"ENVMAP_MODE_REFLECTION":tb[i.envMapMode]||"ENVMAP_MODE_REFLECTION"}const ib={[hd]:"ENVMAP_BLENDING_MULTIPLY",[Im]:"ENVMAP_BLENDING_MIX",[Nm]:"ENVMAP_BLENDING_ADD"};function sb(i){return i.envMap===!1?"ENVMAP_BLENDING_NONE":ib[i.combine]||"ENVMAP_BLENDING_NONE"}function ab(i,e,t,n){const s=i.getContext(),a=t.defines;let r=t.vertexShader,o=t.fragmentShader;const l=eb(t),c=t.envMapPMREM===!0?"ENVMAP_TYPE_PMREM":"ENVMAP_TYPE_CUBE",d=nb(t),h=sb(t),u=Xx(t),f=qx(a),g=s.createProgram();let y,m,p=t.glslVersion?"#version "+t.glslVersion+`
`:"";t.isRawShaderMaterial?(y=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,f].filter(Ta).join(`
`),y.length>0&&(y+=`
`),m=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,f].filter(Ta).join(`
`),m.length>0&&(m+=`
`)):(y=[su(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,f,t.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",t.batching?"#define USE_BATCHING":"",t.batchingColor?"#define USE_BATCHING_COLOR":"",t.instancing?"#define USE_INSTANCING":"",t.instancingColor?"#define USE_INSTANCING_COLOR":"",t.instancingMorph?"#define USE_INSTANCING_MORPH":"",t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+d:"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.displacementMap?"#define USE_DISPLACEMENTMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.diffuseRoughnessMap?"#define USE_DIFFUSE_ROUGHNESSMAP":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.mapUv?"#define MAP_UV "+t.mapUv:"",t.alphaMapUv?"#define ALPHAMAP_UV "+t.alphaMapUv:"",t.lightMapUv?"#define LIGHTMAP_UV "+t.lightMapUv:"",t.aoMapUv?"#define AOMAP_UV "+t.aoMapUv:"",t.emissiveMapUv?"#define EMISSIVEMAP_UV "+t.emissiveMapUv:"",t.bumpMapUv?"#define BUMPMAP_UV "+t.bumpMapUv:"",t.normalMapUv?"#define NORMALMAP_UV "+t.normalMapUv:"",t.displacementMapUv?"#define DISPLACEMENTMAP_UV "+t.displacementMapUv:"",t.metalnessMapUv?"#define METALNESSMAP_UV "+t.metalnessMapUv:"",t.roughnessMapUv?"#define ROUGHNESSMAP_UV "+t.roughnessMapUv:"",t.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+t.anisotropyMapUv:"",t.clearcoatMapUv?"#define CLEARCOATMAP_UV "+t.clearcoatMapUv:"",t.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+t.clearcoatNormalMapUv:"",t.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+t.clearcoatRoughnessMapUv:"",t.diffuseRoughnessMapUv?"#define DIFFUSE_ROUGHNESSMAP_UV "+t.diffuseRoughnessMapUv:"",t.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+t.iridescenceMapUv:"",t.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+t.iridescenceThicknessMapUv:"",t.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+t.sheenColorMapUv:"",t.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+t.sheenRoughnessMapUv:"",t.specularMapUv?"#define SPECULARMAP_UV "+t.specularMapUv:"",t.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+t.specularColorMapUv:"",t.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+t.specularIntensityMapUv:"",t.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+t.transmissionMapUv:"",t.thicknessMapUv?"#define THICKNESSMAP_UV "+t.thicknessMapUv:"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexNormals?"#define HAS_NORMAL":"",t.vertexColors?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.flatShading?"#define FLAT_SHADED":"",t.skinning?"#define USE_SKINNING":"",t.morphTargets?"#define USE_MORPHTARGETS":"",t.morphNormals&&t.flatShading===!1?"#define USE_MORPHNORMALS":"",t.morphColors?"#define USE_MORPHCOLORS":"",t.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+t.morphTextureStride:"",t.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+t.morphTargetsCount:"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+l:"",t.sizeAttenuation?"#define USE_SIZEATTENUATION":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",t.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(Ta).join(`
`),m=[su(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,f,t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",t.map?"#define USE_MAP":"",t.matcap?"#define USE_MATCAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+c:"",t.envMap?"#define "+d:"",t.envMap?"#define "+h:"",t.envMapPMREM?"#define ENVMAP_MAX_LOD "+t.envMapMaxLod+".0":"",t.envMapPMREM?"#define ENVMAP_SIZE "+t.envMapSize+".0":"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.packedNormalMap?"#define USE_PACKED_NORMALMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoat?"#define USE_CLEARCOAT":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.diffuseRoughness?"#define USE_DIFFUSE_ROUGHNESS":"",t.diffuseRoughnessMap?"#define USE_DIFFUSE_ROUGHNESSMAP":"",t.dispersion?"#define USE_DISPERSION":"",t.retroreflection?"#define USE_RETROREFLECTION":"",t.iridescence?"#define USE_IRIDESCENCE":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaTest?"#define USE_ALPHATEST":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.sheen?"#define USE_SHEEN":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors||t.instancingColor?"#define USE_COLOR":"",t.vertexAlphas||t.batchingColor?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.gradientMap?"#define USE_GRADIENTMAP":"",t.flatShading?"#define FLAT_SHADED":"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+l:"",t.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",t.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",t.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",t.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",t.toneMapping!==Ii?"#define TONE_MAPPING":"",t.toneMapping!==Ii?qe.tonemapping_pars_fragment:"",t.toneMapping!==Ii?Vx("toneMapping",t.toneMapping):"",t.dithering?"#define DITHERING":"",t.opaque?"#define OPAQUE":"",qe.colorspace_pars_fragment,Hx("linearToOutputTexel",t.outputColorSpace),Wx(),t.useDepthPacking?"#define DEPTH_PACKING "+t.depthPacking:"",`
`].filter(Ta).join(`
`)),r=Vc(r),r=tu(r,t),r=nu(r,t),o=Vc(o),o=tu(o,t),o=nu(o,t),r=iu(r),o=iu(o),t.isRawShaderMaterial!==!0&&(p=`#version 300 es
`,y=[u,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+y,m=["#define varying in",t.glslVersion===ih?"":"layout(location = 0) out highp vec4 pc_fragColor;",t.glslVersion===ih?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+m);const x=p+y+r,A=p+m+o,b=jh(s,s.VERTEX_SHADER,x),E=jh(s,s.FRAGMENT_SHADER,A);s.attachShader(g,b),s.attachShader(g,E),t.index0AttributeName!==void 0?s.bindAttribLocation(g,0,t.index0AttributeName):t.hasPositionAttribute===!0&&s.bindAttribLocation(g,0,"position"),s.linkProgram(g);function S(R){if(i.debug.checkShaderErrors){const N=s.getProgramInfoLog(g)||"",F=s.getShaderInfoLog(b)||"",G=s.getShaderInfoLog(E)||"",L=N.trim(),z=F.trim(),X=G.trim();let $=!0,te=!0;if(s.getProgramParameter(g,s.LINK_STATUS)===!1)if($=!1,typeof i.debug.onShaderError=="function")i.debug.onShaderError(s,g,b,E);else{const V=eu(s,b,"vertex"),ee=eu(s,E,"fragment");it("WebGLProgram: Shader Error "+s.getError()+" - VALIDATE_STATUS "+s.getProgramParameter(g,s.VALIDATE_STATUS)+`

Material Name: `+R.name+`
Material Type: `+R.type+`

Program Info Log: `+L+`
`+V+`
`+ee)}else L!==""?Ue("WebGLProgram: Program Info Log:",L):(z===""||X==="")&&(te=!1);te&&(R.diagnostics={runnable:$,programLog:L,vertexShader:{log:z,prefix:y},fragmentShader:{log:X,prefix:m}})}s.deleteShader(b),s.deleteShader(E),v=new io(s,g),w=Yx(s,g)}let v;this.getUniforms=function(){return v===void 0&&S(this),v};let w;this.getAttributes=function(){return w===void 0&&S(this),w};let P=t.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return P===!1&&(P=s.getProgramParameter(g,kx)),P},this.destroy=function(){n.releaseStatesOfProgram(this),s.deleteProgram(g),this.program=void 0},this.type=t.shaderType,this.name=t.shaderName,this.id=Bx++,this.cacheKey=e,this.usedTimes=1,this.program=g,this.vertexShader=b,this.fragmentShader=E,this}let rb=0;class ob{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e,t,n){const s=this._getShaderCacheForMaterial(e);return s.has(t)===!1&&(s.add(t),t.usedTimes++),s.has(n)===!1&&(s.add(n),n.usedTimes++),this}remove(e){const t=this.materialCache.get(e);for(const n of t)n.usedTimes--,n.usedTimes===0&&this.shaderCache.delete(n.code);return this.materialCache.delete(e),this}getVertexShaderStage(e){return this._getShaderStage(e.vertexShader)}getFragmentShaderStage(e){return this._getShaderStage(e.fragmentShader)}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){const t=this.materialCache;let n=t.get(e);return n===void 0&&(n=new Set,t.set(e,n)),n}_getShaderStage(e){const t=this.shaderCache;let n=t.get(e);return n===void 0&&(n=new lb(e),t.set(e,n)),n}}class lb{constructor(e){this.id=rb++,this.code=e,this.usedTimes=0}}function cb(i){return i===ys||i===uo||i===fo}function db(i,e,t,n,s,a){const r=new Sd,o=new ob,l=new Set,c=[],d=new Map,h=n.logarithmicDepthBuffer,u={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distance",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function f(v){return l.add(v),v===0?"uv":`uv${v}`}function g(v,w,P,R,N,F){const G=R.fog,L=N.geometry,z=v.isMeshStandardMaterial||v.isMeshLambertMaterial||v.isMeshPhongMaterial?R.environment:null,X=v.isMeshStandardMaterial||v.isMeshLambertMaterial&&!v.envMap||v.isMeshPhongMaterial&&!v.envMap,$=e.get(v.envMap||z,X),te=u[v.type];let V=n.precision;v.precision!==null&&(V=n.getMaxPrecision(v.precision),V!==v.precision&&Ue("WebGLProgram.getParameters:",v.precision,"not supported, using",V,"instead."));const ee=L.morphAttributes.position||L.morphAttributes.normal||L.morphAttributes.color,ne=ee!==void 0?ee.length:0;let Ee=0;L.morphAttributes.position!==void 0&&(Ee=1),L.morphAttributes.normal!==void 0&&(Ee=2),L.morphAttributes.color!==void 0&&(Ee=3);let $e,K,ye,Me;if(te){const ge=ci[te];$e=ge.vertexShader,K=ge.fragmentShader}else{$e=v.vertexShader,K=v.fragmentShader;const ge=o.getVertexShaderStage(v),ot=o.getFragmentShaderStage(v);o.update(v,ge,ot),ye=ge.id,Me=ot.id}const Le=i.getRenderTarget(),xe=i.state.buffers.depth.getReversed(),Ge=N.isInstancedMesh===!0,Lt=N.isBatchedMesh===!0,Ne=!!v.map,rt=!!v.matcap,ht=!!$,Ke=ht&&$.isPMREMTexture===!0,jt=!!v.aoMap,Ot=!!v.lightMap,xn=!!v.bumpMap&&v.wireframe===!1,St=!!v.normalMap,ri=!!v.displacementMap,Wt=!!v.emissiveMap,Fn=!!v.metalnessMap,On=!!v.roughnessMap,kn=v.anisotropy>0,U=v.clearcoat>0,Bn=v.diffuseRoughness>0,Mt=v.dispersion>0,wt=v.retroreflectivity>0,me=v.iridescence>0,kt=v.sheen>0,De=v.transmission>0,Oe=kn&&!!v.anisotropyMap,T=U&&!!v.clearcoatMap,_=U&&!!v.clearcoatNormalMap,k=U&&!!v.clearcoatRoughnessMap,ie=Bn&&!!v.diffuseRoughnessMap,J=me&&!!v.iridescenceMap,le=me&&!!v.iridescenceThicknessMap,fe=kt&&!!v.sheenColorMap,q=kt&&!!v.sheenRoughnessMap,Y=!!v.specularMap,de=!!v.specularColorMap,C=!!v.specularIntensityMap,Z=De&&!!v.transmissionMap,W=De&&!!v.thicknessMap,he=!!v.gradientMap,oe=!!v.alphaMap,ce=v.alphaTest>0,Re=!!v.alphaHash,Xe=!!v.extensions;let ae=Ii;v.toneMapped&&(Le===null||Le.isXRRenderTarget===!0)&&(ae=i.toneMapping);const Pe=Ke?$.isCompressedCubeTexture?$.image[0].mipmaps:$.mipmaps:null,Ve={shaderID:te,shaderType:v.type,shaderName:v.name,vertexShader:$e,fragmentShader:K,defines:v.defines,customVertexShaderID:ye,customFragmentShaderID:Me,isRawShaderMaterial:v.isRawShaderMaterial===!0,glslVersion:v.glslVersion,precision:V,batching:Lt,batchingColor:Lt&&N._colorsTexture!==null,instancing:Ge,instancingColor:Ge&&N.instanceColor!==null,instancingMorph:Ge&&N.morphTexture!==null,outputColorSpace:Le===null?i.outputColorSpace:Le.isXRRenderTarget===!0?Le.texture.colorSpace:et.workingColorSpace,alphaToCoverage:!!v.alphaToCoverage,map:Ne,matcap:rt,envMap:ht,envMapMode:ht&&$.mapping,envMapPMREM:Ke,envMapMaxLod:Ke?Pe.length-1:null,envMapSize:Ke?Pe[0].width:null,aoMap:jt,lightMap:Ot,bumpMap:xn,normalMap:St,displacementMap:ri,emissiveMap:Wt,normalMapObjectSpace:St&&v.normalMapType===Om,normalMapTangentSpace:St&&v.normalMapType===po,packedNormalMap:St&&v.normalMapType===po&&cb(v.normalMap.format),metalnessMap:Fn,roughnessMap:On,anisotropy:kn,anisotropyMap:Oe,clearcoat:U,clearcoatMap:T,clearcoatNormalMap:_,clearcoatRoughnessMap:k,diffuseRoughness:Bn,diffuseRoughnessMap:ie,dispersion:Mt,retroreflection:wt,iridescence:me,iridescenceMap:J,iridescenceThicknessMap:le,sheen:kt,sheenColorMap:fe,sheenRoughnessMap:q,specularMap:Y,specularColorMap:de,specularIntensityMap:C,transmission:De,transmissionMap:Z,thicknessMap:W,gradientMap:he,opaque:v.transparent===!1&&v.blending===Ua&&v.alphaToCoverage===!1,alphaMap:oe,alphaTest:ce,alphaHash:Re,combine:v.combine,mapUv:Ne&&f(v.map.channel),aoMapUv:jt&&f(v.aoMap.channel),lightMapUv:Ot&&f(v.lightMap.channel),bumpMapUv:xn&&f(v.bumpMap.channel),normalMapUv:St&&f(v.normalMap.channel),displacementMapUv:ri&&f(v.displacementMap.channel),emissiveMapUv:Wt&&f(v.emissiveMap.channel),metalnessMapUv:Fn&&f(v.metalnessMap.channel),roughnessMapUv:On&&f(v.roughnessMap.channel),anisotropyMapUv:Oe&&f(v.anisotropyMap.channel),clearcoatMapUv:T&&f(v.clearcoatMap.channel),clearcoatNormalMapUv:_&&f(v.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:k&&f(v.clearcoatRoughnessMap.channel),diffuseRoughnessMapUv:ie&&f(v.diffuseRoughnessMap.channel),iridescenceMapUv:J&&f(v.iridescenceMap.channel),iridescenceThicknessMapUv:le&&f(v.iridescenceThicknessMap.channel),sheenColorMapUv:fe&&f(v.sheenColorMap.channel),sheenRoughnessMapUv:q&&f(v.sheenRoughnessMap.channel),specularMapUv:Y&&f(v.specularMap.channel),specularColorMapUv:de&&f(v.specularColorMap.channel),specularIntensityMapUv:C&&f(v.specularIntensityMap.channel),transmissionMapUv:Z&&f(v.transmissionMap.channel),thicknessMapUv:W&&f(v.thicknessMap.channel),alphaMapUv:oe&&f(v.alphaMap.channel),vertexTangents:!!L.attributes.tangent&&(St||kn),vertexNormals:!!L.attributes.normal,vertexColors:v.vertexColors,vertexAlphas:v.vertexColors===!0&&!!L.attributes.color&&L.attributes.color.itemSize===4,pointsUvs:N.isPoints===!0&&!!L.attributes.uv&&(Ne||oe),fog:!!G,useFog:v.fog===!0,fogExp2:!!G&&G.isFogExp2,flatShading:v.wireframe===!1&&(v.flatShading===!0||L.attributes.normal===void 0&&St===!1&&(v.isMeshLambertMaterial||v.isMeshPhongMaterial||v.isMeshStandardMaterial||v.isMeshPhysicalMaterial)),sizeAttenuation:v.sizeAttenuation===!0,logarithmicDepthBuffer:h,reversedDepthBuffer:xe,skinning:N.isSkinnedMesh===!0,hasPositionAttribute:L.attributes.position!==void 0,morphTargets:L.morphAttributes.position!==void 0,morphNormals:L.morphAttributes.normal!==void 0,morphColors:L.morphAttributes.color!==void 0,morphTargetsCount:ne,morphTextureStride:Ee,numSunLights:w.sun.length,numDirLights:w.directional.length,numPointLights:w.point.length,numSpotLights:w.spot.length,numSpotLightMaps:w.spotLightMap.length,numRectAreaLights:w.rectArea.length,numHemiLights:w.hemi.length,numSunLightShadows:w.sunShadowMap.length,numDirLightShadows:w.directionalShadowMap.length,numPointLightShadows:w.pointShadowMap.length,numSpotLightShadows:w.spotShadowMap.length,numSpotLightShadowsWithMaps:w.numSpotLightShadowsWithMaps,numLightProbes:w.numLightProbes,numLightProbeGrids:F.filter(ge=>ge.texture!==null).length,numClippingPlanes:a.numPlanes,numClipIntersection:a.numIntersection,dithering:v.dithering,shadowMapEnabled:i.shadowMap.enabled&&P.length>0,shadowMapType:i.shadowMap.type,toneMapping:ae,decodeVideoTexture:Ne&&v.map.isVideoTexture===!0&&et.getTransfer(v.map.colorSpace)===lt,decodeVideoTextureEmissive:Wt&&v.emissiveMap.isVideoTexture===!0&&et.getTransfer(v.emissiveMap.colorSpace)===lt,premultipliedAlpha:v.premultipliedAlpha,doubleSided:v.side===Mn,flipSided:v.side===rn,useDepthPacking:v.depthPacking>=0,depthPacking:v.depthPacking||0,index0AttributeName:v.index0AttributeName,extensionClipCullDistance:Xe&&v.extensions.clipCullDistance===!0&&t.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(Xe&&v.extensions.multiDraw===!0||Lt)&&t.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:t.has("KHR_parallel_shader_compile"),customProgramCacheKey:v.customProgramCacheKey()};return Ve.vertexUv1s=l.has(1),Ve.vertexUv2s=l.has(2),Ve.vertexUv3s=l.has(3),l.clear(),Ve}function y(v){const w=[];if(v.shaderID?w.push(v.shaderID):(w.push(v.customVertexShaderID),w.push(v.customFragmentShaderID)),v.defines!==void 0)for(const P in v.defines)w.push(P),w.push(v.defines[P]);return v.isRawShaderMaterial===!1&&(m(w,v),p(w,v),w.push(i.outputColorSpace)),w.push(v.customProgramCacheKey),w.join()}function m(v,w){v.push(w.precision),v.push(w.outputColorSpace),v.push(w.envMapMode),v.push(w.envMapPMREM),v.push(w.envMapMaxLod),v.push(w.envMapSize),v.push(w.mapUv),v.push(w.alphaMapUv),v.push(w.lightMapUv),v.push(w.aoMapUv),v.push(w.bumpMapUv),v.push(w.normalMapUv),v.push(w.displacementMapUv),v.push(w.emissiveMapUv),v.push(w.metalnessMapUv),v.push(w.roughnessMapUv),v.push(w.anisotropyMapUv),v.push(w.clearcoatMapUv),v.push(w.clearcoatNormalMapUv),v.push(w.clearcoatRoughnessMapUv),v.push(w.diffuseRoughnessMapUv),v.push(w.iridescenceMapUv),v.push(w.iridescenceThicknessMapUv),v.push(w.sheenColorMapUv),v.push(w.sheenRoughnessMapUv),v.push(w.specularMapUv),v.push(w.specularColorMapUv),v.push(w.specularIntensityMapUv),v.push(w.transmissionMapUv),v.push(w.thicknessMapUv),v.push(w.combine),v.push(w.fogExp2),v.push(w.sizeAttenuation),v.push(w.morphTargetsCount),v.push(w.numSunLights),v.push(w.numDirLights),v.push(w.numPointLights),v.push(w.numSpotLights),v.push(w.numSpotLightMaps),v.push(w.numHemiLights),v.push(w.numRectAreaLights),v.push(w.numSunLightShadows),v.push(w.numDirLightShadows),v.push(w.numPointLightShadows),v.push(w.numSpotLightShadows),v.push(w.numSpotLightShadowsWithMaps),v.push(w.numLightProbes),v.push(w.numLightProbeGrids),v.push(w.shadowMapType),v.push(w.toneMapping),v.push(w.numClippingPlanes),v.push(w.numClipIntersection),v.push(w.depthPacking)}function p(v,w){r.disableAll(),w.instancing&&r.enable(0),w.instancingColor&&r.enable(1),w.instancingMorph&&r.enable(2),w.matcap&&r.enable(3),w.envMap&&r.enable(4),w.normalMapObjectSpace&&r.enable(5),w.normalMapTangentSpace&&r.enable(6),w.clearcoat&&r.enable(7),w.iridescence&&r.enable(8),w.alphaTest&&r.enable(9),w.vertexColors&&r.enable(10),w.vertexAlphas&&r.enable(11),w.vertexUv1s&&r.enable(12),w.vertexUv2s&&r.enable(13),w.vertexUv3s&&r.enable(14),w.vertexTangents&&r.enable(15),w.anisotropy&&r.enable(16),w.alphaHash&&r.enable(17),w.batching&&r.enable(18),w.dispersion&&r.enable(19),w.retroreflection&&r.enable(24),w.diffuseRoughness&&r.enable(25),w.batchingColor&&r.enable(20),w.gradientMap&&r.enable(21),w.packedNormalMap&&r.enable(22),w.vertexNormals&&r.enable(23),v.push(r.mask),r.disableAll(),w.fog&&r.enable(0),w.useFog&&r.enable(1),w.flatShading&&r.enable(2),w.logarithmicDepthBuffer&&r.enable(3),w.reversedDepthBuffer&&r.enable(4),w.skinning&&r.enable(5),w.morphTargets&&r.enable(6),w.morphNormals&&r.enable(7),w.morphColors&&r.enable(8),w.premultipliedAlpha&&r.enable(9),w.shadowMapEnabled&&r.enable(10),w.doubleSided&&r.enable(11),w.flipSided&&r.enable(12),w.useDepthPacking&&r.enable(13),w.dithering&&r.enable(14),w.transmission&&r.enable(15),w.sheen&&r.enable(16),w.opaque&&r.enable(17),w.pointsUvs&&r.enable(18),w.decodeVideoTexture&&r.enable(19),w.decodeVideoTextureEmissive&&r.enable(20),w.alphaToCoverage&&r.enable(21),w.numLightProbeGrids>0&&r.enable(22),w.hasPositionAttribute&&r.enable(23),v.push(r.mask)}function x(v){const w=u[v.type];let P;if(w){const R=ci[w];P=N0.clone(R.uniforms)}else P=v.uniforms;return P}function A(v,w){let P=d.get(w);return P!==void 0?++P.usedTimes:(P=new ab(i,w,v,s),c.push(P),d.set(w,P)),P}function b(v){if(--v.usedTimes===0){const w=c.indexOf(v);c[w]=c[c.length-1],c.pop(),d.delete(v.cacheKey),v.destroy()}}function E(v){o.remove(v)}function S(){o.dispose()}return{getParameters:g,getProgramCacheKey:y,getUniforms:x,acquireProgram:A,releaseProgram:b,releaseShaderCache:E,programs:c,dispose:S}}function hb(){let i=new WeakMap;function e(r){return i.has(r)}function t(r){let o=i.get(r);return o===void 0&&(o={},i.set(r,o)),o}function n(r){i.delete(r)}function s(r,o,l){i.get(r)[o]=l}function a(){i=new WeakMap}return{has:e,get:t,remove:n,update:s,dispose:a}}function ub(i,e){return i.groupOrder!==e.groupOrder?i.groupOrder-e.groupOrder:i.renderOrder!==e.renderOrder?i.renderOrder-e.renderOrder:i.material.id!==e.material.id?i.material.id-e.material.id:i.materialVariant!==e.materialVariant?i.materialVariant-e.materialVariant:i.z!==e.z?i.z-e.z:i.id-e.id}function au(i,e){return i.groupOrder!==e.groupOrder?i.groupOrder-e.groupOrder:i.renderOrder!==e.renderOrder?i.renderOrder-e.renderOrder:i.z!==e.z?e.z-i.z:i.id-e.id}function ru(){const i=[];let e=0;const t=[],n=[],s=[];function a(){e=0,t.length=0,n.length=0,s.length=0}function r(u){let f=0;return u.isInstancedMesh&&(f+=2),u.isSkinnedMesh&&(f+=1),f}function o(u,f,g,y,m,p){let x=i[e];return x===void 0?(x={id:u.id,object:u,geometry:f,material:g,materialVariant:r(u),groupOrder:y,renderOrder:u.renderOrder,z:m,group:p},i[e]=x):(x.id=u.id,x.object=u,x.geometry=f,x.material=g,x.materialVariant=r(u),x.groupOrder=y,x.renderOrder=u.renderOrder,x.z=m,x.group=p),e++,x}function l(u,f,g,y,m,p,x){x.reversedDepth===!0&&(m=-m);const A=o(u,f,g,y,m,p);g.transmission>0?n.push(A):g.transparent===!0?s.push(A):t.push(A)}function c(u,f,g,y,m,p){const x=o(u,f,g,y,m,p);g.transmission>0?n.unshift(x):g.transparent===!0?s.unshift(x):t.unshift(x)}function d(u,f){t.length>1&&t.sort(u||ub),n.length>1&&n.sort(f||au),s.length>1&&s.sort(f||au)}function h(){for(let u=e,f=i.length;u<f;u++){const g=i[u];if(g.id===null)break;g.id=null,g.object=null,g.geometry=null,g.material=null,g.group=null}}return{opaque:t,transmissive:n,transparent:s,init:a,push:l,unshift:c,finish:h,sort:d}}function fb(){let i=new WeakMap;function e(n,s){const a=i.get(n);let r;return a===void 0?(r=new ru,i.set(n,[r])):s>=a.length?(r=new ru,a.push(r)):r=a[s],r}function t(){i=new WeakMap}return{get:e,dispose:t}}function pb(){const i={};return{get:function(e){if(i[e.id]!==void 0)return i[e.id];let t;switch(e.type){case"SunLight":case"DirectionalLight":t={direction:new D,color:new Ce};break;case"SpotLight":t={position:new D,direction:new D,color:new Ce,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":t={position:new D,color:new Ce,distance:0,decay:0};break;case"HemisphereLight":t={direction:new D,skyColor:new Ce,groundColor:new Ce};break;case"RectAreaLight":t={color:new Ce,position:new D,halfWidth:new D,halfHeight:new D};break}return i[e.id]=t,t}}}function mb(){const i={};return{get:function(e){if(i[e.id]!==void 0)return i[e.id];let t;switch(e.type){case"SunLight":case"DirectionalLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Ie};break;case"SpotLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Ie};break;case"PointLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Ie,shadowCameraNear:1,shadowCameraFar:1e3};break}return i[e.id]=t,t}}}let gb=0;function vb(i,e){return(e.castShadow?2:0)-(i.castShadow?2:0)+(e.map?1:0)-(i.map?1:0)}function yb(i){const e=new pb,t=mb(),n={version:0,hash:{sunLength:-1,directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numSunShadows:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],sun:[],sunShadow:[],sunShadowMap:[],sunShadowMatrix:[],sunShadowCascade:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let c=0;c<9;c++)n.probe.push(new D);const s=new D,a=new tt,r=new tt;function o(c){let d=0,h=0,u=0;for(let F=0;F<9;F++)n.probe[F].set(0,0,0);let f=0,g=0,y=0,m=0,p=0,x=0,A=0,b=0,E=0,S=0,v=0,w=0,P=0,R=0;c.sort(vb);for(let F=0,G=c.length;F<G;F++){const L=c[F],z=L.color,X=L.intensity,$=L.distance;let te=null;if(L.shadow&&L.shadow.map&&(L.shadow.map.texture.format===ys?te=L.shadow.map.texture:te=L.shadow.map.depthTexture||L.shadow.map.texture),L.isAmbientLight)d+=z.r*X,h+=z.g*X,u+=z.b*X;else if(L.isLightProbe){for(let V=0;V<9;V++)n.probe[V].addScaledVector(L.sh.coefficients[V],X);R++}else if(L.isSunLight){const V=e.get(L);if(V.color.copy(L.color).multiplyScalar(L.intensity),L.castShadow){const ee=L.shadow,ne=t.get(L);ne.shadowIntensity=ee.intensity,ne.shadowBias=ee.bias,ne.shadowNormalBias=ee.normalBias,ne.shadowRadius=ee.radius,ne.shadowMapSize.copy(ee.mapSize).multiply(ee.getFrameExtents()),n.sunShadow[g]=ne,n.sunShadowMap[g]=te;const Ee=ee.getViewportCount();for(let $e=0;$e<Ee;$e++)n.sunShadowMatrix[y+$e]=ee.getMatrix($e),n.sunShadowCascade[y+$e]=ee._cascadeData[$e];y+=Ee,g++}n.sun[f]=V,f++}else if(L.isDirectionalLight){const V=e.get(L);if(V.color.copy(L.color).multiplyScalar(L.intensity),L.castShadow){const ee=L.shadow,ne=t.get(L);ne.shadowIntensity=ee.intensity,ne.shadowBias=ee.bias,ne.shadowNormalBias=ee.normalBias,ne.shadowRadius=ee.radius,ne.shadowMapSize=ee.mapSize,n.directionalShadow[m]=ne,n.directionalShadowMap[m]=te,n.directionalShadowMatrix[m]=L.shadow.matrix,E++}n.directional[m]=V,m++}else if(L.isSpotLight){const V=e.get(L);V.position.setFromMatrixPosition(L.matrixWorld),V.color.copy(z).multiplyScalar(X),V.distance=$,V.coneCos=Math.cos(L.angle),V.penumbraCos=Math.cos(L.angle*(1-L.penumbra)),V.decay=L.decay,n.spot[x]=V;const ee=L.shadow;if(L.map&&(n.spotLightMap[w]=L.map,w++,ee.updateMatrices(L),L.castShadow&&P++),n.spotLightMatrix[x]=ee.matrix,L.castShadow){const ne=t.get(L);ne.shadowIntensity=ee.intensity,ne.shadowBias=ee.bias,ne.shadowNormalBias=ee.normalBias,ne.shadowRadius=ee.radius,ne.shadowMapSize=ee.mapSize,n.spotShadow[x]=ne,n.spotShadowMap[x]=te,v++}x++}else if(L.isRectAreaLight){const V=e.get(L);V.color.copy(z).multiplyScalar(X),V.halfWidth.set(L.width*.5,0,0),V.halfHeight.set(0,L.height*.5,0),n.rectArea[A]=V,A++}else if(L.isPointLight){const V=e.get(L);if(V.color.copy(L.color).multiplyScalar(L.intensity),V.distance=L.distance,V.decay=L.decay,L.castShadow){const ee=L.shadow,ne=t.get(L);ne.shadowIntensity=ee.intensity,ne.shadowBias=ee.bias,ne.shadowNormalBias=ee.normalBias,ne.shadowRadius=ee.radius,ne.shadowMapSize=ee.mapSize,ne.shadowCameraNear=ee.camera.near,ne.shadowCameraFar=ee.camera.far,n.pointShadow[p]=ne,n.pointShadowMap[p]=te,n.pointShadowMatrix[p]=L.shadow.matrix,S++}n.point[p]=V,p++}else if(L.isHemisphereLight){const V=e.get(L);V.skyColor.copy(L.color).multiplyScalar(X),V.groundColor.copy(L.groundColor).multiplyScalar(X),n.hemi[b]=V,b++}}A>0&&(i.has("OES_texture_float_linear")===!0?(n.rectAreaLTC1=ve.LTC_FLOAT_1,n.rectAreaLTC2=ve.LTC_FLOAT_2):(n.rectAreaLTC1=ve.LTC_HALF_1,n.rectAreaLTC2=ve.LTC_HALF_2)),n.ambient[0]=d,n.ambient[1]=h,n.ambient[2]=u;const N=n.hash;(N.sunLength!==f||N.directionalLength!==m||N.pointLength!==p||N.spotLength!==x||N.rectAreaLength!==A||N.hemiLength!==b||N.numSunShadows!==g||N.numDirectionalShadows!==E||N.numPointShadows!==S||N.numSpotShadows!==v||N.numSpotMaps!==w||N.numLightProbes!==R)&&(n.sun.length=f,n.directional.length=m,n.spot.length=x,n.rectArea.length=A,n.point.length=p,n.hemi.length=b,n.sunShadow.length=g,n.sunShadowMap.length=g,n.sunShadowMatrix.length=y,n.sunShadowCascade.length=y,n.directionalShadow.length=E,n.directionalShadowMap.length=E,n.directionalShadowMatrix.length=E,n.pointShadow.length=S,n.pointShadowMap.length=S,n.pointShadowMatrix.length=S,n.spotShadow.length=v,n.spotShadowMap.length=v,n.spotLightMatrix.length=v+w-P,n.spotLightMap.length=w,n.numSpotLightShadowsWithMaps=P,n.numLightProbes=R,N.sunLength=f,N.directionalLength=m,N.pointLength=p,N.spotLength=x,N.rectAreaLength=A,N.hemiLength=b,N.numSunShadows=g,N.numDirectionalShadows=E,N.numPointShadows=S,N.numSpotShadows=v,N.numSpotMaps=w,N.numLightProbes=R,n.version=gb++)}function l(c,d){let h=0,u=0,f=0,g=0,y=0,m=0;const p=d.matrixWorldInverse;for(let x=0,A=c.length;x<A;x++){const b=c[x];if(b.isSunLight){const E=n.sun[h];E.direction.setFromMatrixPosition(b.matrixWorld),E.direction.transformDirection(p),h++}else if(b.isDirectionalLight){const E=n.directional[u];E.direction.setFromMatrixPosition(b.matrixWorld),s.setFromMatrixPosition(b.target.matrixWorld),E.direction.sub(s),E.direction.transformDirection(p),u++}else if(b.isSpotLight){const E=n.spot[g];E.position.setFromMatrixPosition(b.matrixWorld),E.position.applyMatrix4(p),E.direction.setFromMatrixPosition(b.matrixWorld),s.setFromMatrixPosition(b.target.matrixWorld),E.direction.sub(s),E.direction.transformDirection(p),g++}else if(b.isRectAreaLight){const E=n.rectArea[y];E.position.setFromMatrixPosition(b.matrixWorld),E.position.applyMatrix4(p),r.identity(),a.copy(b.matrixWorld),a.premultiply(p),r.extractRotation(a),E.halfWidth.set(b.width*.5,0,0),E.halfHeight.set(0,b.height*.5,0),E.halfWidth.applyMatrix4(r),E.halfHeight.applyMatrix4(r),y++}else if(b.isPointLight){const E=n.point[f];E.position.setFromMatrixPosition(b.matrixWorld),E.position.applyMatrix4(p),f++}else if(b.isHemisphereLight){const E=n.hemi[m];E.direction.setFromMatrixPosition(b.matrixWorld),E.direction.transformDirection(p),m++}}}return{setup:o,setupView:l,state:n}}function ou(i){const e=new yb(i),t=[],n=[],s=[];function a(h){d.camera=h,t.length=0,n.length=0,s.length=0}function r(h){h.isLightProbeGrid?s.push(h):t.push(h)}function o(h){n.push(h)}function l(){e.setup(t),s.sort((h,u)=>h.priority-u.priority||h.id-u.id)}function c(h){e.setupView(t,h)}const d={lightsArray:t,shadowsArray:n,lightProbeGridArray:s,camera:null,lights:e,transmissionRenderTarget:{},textureUnits:0};return{init:a,state:d,setupLights:l,setupLightsView:c,pushLight:r,pushShadow:o}}function xb(i){let e=new WeakMap;function t(s,a=0){const r=e.get(s);let o;return r===void 0?(o=new ou(i),e.set(s,[o])):a>=r.length?(o=new ou(i),r.push(o)):o=r[a],o}function n(){e=new WeakMap}return{get:t,dispose:n}}const bb=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,_b=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ).rg;
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ).r;
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( max( 0.0, squared_mean - mean * mean ) );
	gl_FragColor = vec4( mean, std_dev, 0.0, 1.0 );
}`,Mb=[new D(1,0,0),new D(-1,0,0),new D(0,1,0),new D(0,-1,0),new D(0,0,1),new D(0,0,-1)],wb=[new D(0,-1,0),new D(0,-1,0),new D(0,0,1),new D(0,0,-1),new D(0,-1,0),new D(0,-1,0)],lu=new tt,wa=new D,zl=new D;function Sb(i,e,t){let n=new Xa;const s=new Ie,a=new Ie,r=new Tt,o=new B0,l=new z0,c={},d=t.maxTextureSize,h={[vs]:rn,[rn]:vs,[Mn]:Mn},u=new Pn({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new Ie},radius:{value:4}},vertexShader:bb,fragmentShader:_b}),f=u.clone();f.defines.HORIZONTAL_PASS=1;const g=new bt;g.setAttribute("position",new Ft(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const y=new Te(g,u),m=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=Jr;let p=this.type;this.render=function(S,v,w){if(m.enabled===!1||m.autoUpdate===!1&&m.needsUpdate===!1||S.length===0)return;this.type===cf&&(Ue("WebGLShadowMap: PCFSoftShadowMap has been removed. Using PCFShadowMap instead."),this.type=Jr);const P=i.getRenderTarget(),R=i.getActiveCubeFace(),N=i.getActiveMipmapLevel(),F=i.state;F.setBlending(Ks),F.buffers.depth.getReversed()===!0?F.buffers.color.setClear(0,0,0,0):F.buffers.color.setClear(1,1,1,1),F.buffers.depth.setTest(!0),F.setScissorTest(!1);const G=p!==this.type;G&&v.traverse(function(L){L.material&&(Array.isArray(L.material)?L.material.forEach(z=>z.needsUpdate=!0):L.material.needsUpdate=!0)});for(let L=0,z=S.length;L<z;L++){const X=S[L],$=X.shadow;if($===void 0){Ue("WebGLShadowMap:",X,"has no shadow.");continue}if($.autoUpdate===!1&&$.needsUpdate===!1)continue;s.copy($.mapSize);const te=$.getFrameExtents();s.multiply(te),a.copy($.mapSize),(s.x>d||s.y>d)&&(s.x>d&&(a.x=Math.floor(d/te.x),s.x=a.x*te.x,$.mapSize.x=a.x),s.y>d&&(a.y=Math.floor(d/te.y),s.y=a.y*te.y,$.mapSize.y=a.y));const V=i.state.buffers.depth.getReversed();if($.camera._reversedDepth=V,$.map===null||G===!0){if($.map!==null&&($.map.depthTexture!==null&&($.map.depthTexture.dispose(),$.map.depthTexture=null),$.map.dispose()),this.type===Aa){if(X.isPointLight){Ue("WebGLShadowMap: VSM shadow maps are not supported for PointLights. Use PCF or BasicShadowMap instead.");continue}$.map=new Vn(s.x,s.y,{format:ys,type:gi,minFilter:vn,magFilter:vn,generateMipmaps:!1}),$.map.texture.name=X.name+".shadowMap",$.map.depthTexture=new oa(s.x,s.y,ii),$.map.depthTexture.name=X.name+".shadowMapDepth",$.map.depthTexture.format=ns,$.map.depthTexture.compareFunction=null,$.map.depthTexture.minFilter=sn,$.map.depthTexture.magFilter=sn}else X.isPointLight?($.map=new Td(s.x),$.map.depthTexture=new Bf(s.x,mi)):($.map=new Vn(s.x,s.y),$.map.depthTexture=new oa(s.x,s.y,mi)),$.map.depthTexture.name=X.name+".shadowMap",$.map.depthTexture.format=ns,this.type===Jr?($.map.depthTexture.compareFunction=V?Af:Ef,$.map.depthTexture.minFilter=vn,$.map.depthTexture.magFilter=vn):($.map.depthTexture.compareFunction=null,$.map.depthTexture.minFilter=sn,$.map.depthTexture.magFilter=sn);$.camera.updateProjectionMatrix()}$.map.isWebGLCubeRenderTarget!==!0&&($.map.width!==s.x||$.map.height!==s.y)&&$.map.setSize(s.x,s.y);const ee=$.map.isWebGLCubeRenderTarget?6:$.getViewportCount();X.isPointLight!==!0&&$.updateMatrices(X,w);const ne=($.camera.layers.mask&4294967294)!==0?$.camera.layers:w.layers;for(let Ee=0;Ee<ee;Ee++){const $e=$.getCamera(Ee);if(X.isPointLight){const K=$.camera,ye=$.matrix,Me=X.distance||K.far;Me!==K.far&&(K.far=Me,K.updateProjectionMatrix()),wa.setFromMatrixPosition(X.matrixWorld),K.position.copy(wa),zl.copy(K.position),zl.add(Mb[Ee]),K.up.copy(wb[Ee]),K.lookAt(zl),K.updateMatrixWorld(),ye.makeTranslation(-wa.x,-wa.y,-wa.z),lu.multiplyMatrices(K.projectionMatrix,K.matrixWorldInverse),$._frustum.setFromProjectionMatrix(lu,K.coordinateSystem,K.reversedDepth)}if($.map.isWebGLCubeRenderTarget)i.setRenderTarget($.map,Ee),i.clear();else{Ee===0&&(i.setRenderTarget($.map),i.clear());const K=$.getViewport(Ee);r.set(a.x*K.x,a.y*K.y,a.x*K.z,a.y*K.w),F.viewport(r)}n=$.getFrustum(Ee),b(v,w,$e,X,ne,this.type)}$.isPointLightShadow!==!0&&this.type===Aa&&x($,w),$.needsUpdate=!1}p=this.type,m.needsUpdate=!1,i.setRenderTarget(P,R,N)};function x(S,v){const w=e.update(y);u.defines.VSM_SAMPLES!==S.blurSamples&&(u.defines.VSM_SAMPLES=S.blurSamples,f.defines.VSM_SAMPLES=S.blurSamples,u.needsUpdate=!0,f.needsUpdate=!0),S.mapPass===null?S.mapPass=new Vn(s.x,s.y,{format:ys,type:gi}):(S.mapPass.width!==S.map.width||S.mapPass.height!==S.map.height)&&S.mapPass.setSize(S.map.width,S.map.height),u.uniforms.shadow_pass.value=S.map.depthTexture,u.uniforms.resolution.value.set(S.map.width,S.map.height),u.uniforms.radius.value=S.radius,i.setRenderTarget(S.mapPass),i.clear(),i.renderBufferDirect(v,null,w,u,y,null),f.uniforms.shadow_pass.value=S.mapPass.texture,f.uniforms.resolution.value.set(S.map.width,S.map.height),f.uniforms.radius.value=S.radius,i.setRenderTarget(S.map),i.clear(),i.renderBufferDirect(v,null,w,f,y,null)}function A(S,v,w,P){let R=null;const N=w.isPointLight===!0?S.customDistanceMaterial:S.customDepthMaterial;if(N!==void 0)R=N;else if(R=w.isPointLight===!0?l:o,i.localClippingEnabled&&v.clipShadows===!0&&Array.isArray(v.clippingPlanes)&&v.clippingPlanes.length!==0||v.displacementMap&&v.displacementScale!==0||v.alphaMap&&v.alphaTest>0||v.map&&v.alphaTest>0||v.alphaToCoverage===!0){const F=R.uuid,G=v.uuid;let L=c[F];L===void 0&&(L={},c[F]=L);let z=L[G];z===void 0&&(z=R.clone(),L[G]=z,v.addEventListener("dispose",E)),R=z}if(R.visible=v.visible,R.wireframe=v.wireframe,P===Aa?R.side=v.shadowSide!==null?v.shadowSide:v.side:R.side=v.shadowSide!==null?v.shadowSide:h[v.side],R.alphaMap=v.alphaMap,R.alphaTest=v.alphaToCoverage===!0?.5:v.alphaTest,R.map=v.map,R.clipShadows=v.clipShadows,R.clippingPlanes=v.clippingPlanes,R.clipIntersection=v.clipIntersection,R.displacementMap=v.displacementMap,R.displacementScale=v.displacementScale,R.displacementBias=v.displacementBias,R.wireframeLinewidth=v.wireframeLinewidth,R.linewidth=v.linewidth,w.isPointLight===!0&&R.isMeshDistanceMaterial===!0){const F=i.properties.get(R);F.light=w}return R}function b(S,v,w,P,R,N){if(S.visible===!1)return;if(S.layers.test(R)&&(S.isMesh||S.isLine||S.isPoints)&&(S.castShadow||S.receiveShadow&&N===Aa)&&(!S.frustumCulled||S.intersectsFrustum(n))){S.modelViewMatrix.multiplyMatrices(w.matrixWorldInverse,S.matrixWorld);const L=e.update(S),z=S.material;if(Array.isArray(z)){const X=L.groups;for(let $=0,te=X.length;$<te;$++){const V=X[$],ee=z[V.materialIndex];if(ee&&ee.visible){const ne=A(S,ee,P,N);S.onBeforeShadow(i,S,v,w,L,ne,V),i.renderBufferDirect(w,null,L,ne,S,V),S.onAfterShadow(i,S,v,w,L,ne,V)}}}else if(z.visible){const X=A(S,z,P,N);S.onBeforeShadow(i,S,v,w,L,X,null),i.renderBufferDirect(w,null,L,X,S,null),S.onAfterShadow(i,S,v,w,L,X,null)}}const G=S.children;for(let L=0,z=G.length;L<z;L++)b(G[L],v,w,P,R,N)}function E(S){S.target.removeEventListener("dispose",E);for(const w in c){const P=c[w],R=S.target.uuid;R in P&&(P[R].dispose(),delete P[R])}}}function Eb(i,e){function t(){let C=!1;const Z=new Tt;let W=null;const he=new Tt(0,0,0,0);return{setMask:function(oe){W!==oe&&!C&&(i.colorMask(oe,oe,oe,oe),W=oe)},setLocked:function(oe){C=oe},setClear:function(oe,ce,Re,Xe,ae){ae===!0&&(oe*=Xe,ce*=Xe,Re*=Xe),Z.set(oe,ce,Re,Xe),he.equals(Z)===!1&&(i.clearColor(oe,ce,Re,Xe),he.copy(Z))},reset:function(){C=!1,W=null,he.set(-1,0,0,0)}}}function n(){let C=!1,Z=!1,W=null,he=null,oe=null;return{setReversed:function(ce){if(Z!==ce){const Re=e.get("EXT_clip_control");ce?Re.clipControlEXT(Re.LOWER_LEFT_EXT,Re.ZERO_TO_ONE_EXT):Re.clipControlEXT(Re.LOWER_LEFT_EXT,Re.NEGATIVE_ONE_TO_ONE_EXT),Z=ce;const Xe=oe;oe=null,this.setClear(Xe)}},getReversed:function(){return Z},setTest:function(ce){ce?xe(i.DEPTH_TEST):Ge(i.DEPTH_TEST)},setMask:function(ce){W!==ce&&!C&&(i.depthMask(ce),W=ce)},setFunc:function(ce){if(Z&&(ce=qm[ce]),he!==ce){switch(ce){case nc:i.depthFunc(i.NEVER);break;case ic:i.depthFunc(i.ALWAYS);break;case sc:i.depthFunc(i.LESS);break;case $a:i.depthFunc(i.LEQUAL);break;case ac:i.depthFunc(i.EQUAL);break;case rc:i.depthFunc(i.GEQUAL);break;case oc:i.depthFunc(i.GREATER);break;case lc:i.depthFunc(i.NOTEQUAL);break;default:i.depthFunc(i.LEQUAL)}he=ce}},setLocked:function(ce){C=ce},setClear:function(ce){oe!==ce&&(oe=ce,Z&&(ce=1-ce),i.clearDepth(ce))},reset:function(){C=!1,W=null,he=null,oe=null,Z=!1}}}function s(){let C=!1,Z=null,W=null,he=null,oe=null,ce=null,Re=null,Xe=null,ae=null;return{setTest:function(Pe){C||(Pe?xe(i.STENCIL_TEST):Ge(i.STENCIL_TEST))},setMask:function(Pe){Z!==Pe&&!C&&(i.stencilMask(Pe),Z=Pe)},setFunc:function(Pe,Ve,ge){(W!==Pe||he!==Ve||oe!==ge)&&(i.stencilFunc(Pe,Ve,ge),W=Pe,he=Ve,oe=ge)},setOp:function(Pe,Ve,ge){(ce!==Pe||Re!==Ve||Xe!==ge)&&(i.stencilOp(Pe,Ve,ge),ce=Pe,Re=Ve,Xe=ge)},setLocked:function(Pe){C=Pe},setClear:function(Pe){ae!==Pe&&(i.clearStencil(Pe),ae=Pe)},reset:function(){C=!1,Z=null,W=null,he=null,oe=null,ce=null,Re=null,Xe=null,ae=null}}}const a=new t,r=new n,o=new s;let l={};const c=new WeakMap;let d={},h={},u={},f=new WeakMap,g=[],y=null,m=!1,p=null,x=null,A=null,b=null,E=null,S=null,v=null,w=new Ce(0,0,0),P=0,R=!1,N=null,F=null,G=null,L=null,z=null;const X=i.getParameter(i.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let $=!1,te=0;const V=i.getParameter(i.VERSION);V.indexOf("WebGL")!==-1?(te=parseFloat(/^WebGL (\d)/.exec(V)[1]),$=te>=1):V.indexOf("OpenGL ES")!==-1&&(te=parseFloat(/^OpenGL ES (\d)/.exec(V)[1]),$=te>=2);let ee=null,ne={};const Ee=i.getParameter(i.SCISSOR_BOX),$e=i.getParameter(i.VIEWPORT),K=new Tt().fromArray(Ee),ye=new Tt().fromArray($e);function Me(C,Z,W,he){const oe=new Uint8Array(4),ce=i.createTexture();i.bindTexture(C,ce),i.texParameteri(C,i.TEXTURE_MIN_FILTER,i.NEAREST),i.texParameteri(C,i.TEXTURE_MAG_FILTER,i.NEAREST);for(let Re=0;Re<W;Re++)C===i.TEXTURE_3D||C===i.TEXTURE_2D_ARRAY?i.texImage3D(Z,0,i.RGBA,1,1,he,0,i.RGBA,i.UNSIGNED_BYTE,oe):i.texImage2D(Z+Re,0,i.RGBA,1,1,0,i.RGBA,i.UNSIGNED_BYTE,oe);return ce}const Le={};Le[i.TEXTURE_2D]=Me(i.TEXTURE_2D,i.TEXTURE_2D,1),Le[i.TEXTURE_CUBE_MAP]=Me(i.TEXTURE_CUBE_MAP,i.TEXTURE_CUBE_MAP_POSITIVE_X,6),Le[i.TEXTURE_2D_ARRAY]=Me(i.TEXTURE_2D_ARRAY,i.TEXTURE_2D_ARRAY,1,1),Le[i.TEXTURE_3D]=Me(i.TEXTURE_3D,i.TEXTURE_3D,1,1),a.setClear(0,0,0,1),r.setClear(1),o.setClear(0),xe(i.DEPTH_TEST),r.setFunc($a),xn(!1),St(eh),xe(i.CULL_FACE),jt(Ks);function xe(C){d[C]!==!0&&(i.enable(C),d[C]=!0)}function Ge(C){d[C]!==!1&&(i.disable(C),d[C]=!1)}function Lt(C,Z){return u[C]!==Z?(i.bindFramebuffer(C,Z),u[C]=Z,C===i.DRAW_FRAMEBUFFER&&(u[i.FRAMEBUFFER]=Z),C===i.FRAMEBUFFER&&(u[i.DRAW_FRAMEBUFFER]=Z),!0):!1}function Ne(C,Z){let W=g,he=!1;if(C){W=f.get(Z),W===void 0&&(W=[],f.set(Z,W));const oe=C.textures;if(W.length!==oe.length||W[0]!==i.COLOR_ATTACHMENT0){for(let ce=0,Re=oe.length;ce<Re;ce++)W[ce]=i.COLOR_ATTACHMENT0+ce;W.length=oe.length,he=!0}}else W[0]!==i.BACK&&(W[0]=i.BACK,he=!0);he&&i.drawBuffers(W)}function rt(C){return y!==C?(i.useProgram(C),y=C,!0):!1}const ht={[Xs]:i.FUNC_ADD,[gm]:i.FUNC_SUBTRACT,[vm]:i.FUNC_REVERSE_SUBTRACT};ht[ym]=i.MIN,ht[xm]=i.MAX;const Ke={[bm]:i.ZERO,[_m]:i.ONE,[Mm]:i.SRC_COLOR,[df]:i.SRC_ALPHA,[Rm]:i.SRC_ALPHA_SATURATE,[Am]:i.DST_COLOR,[Sm]:i.DST_ALPHA,[wm]:i.ONE_MINUS_SRC_COLOR,[hf]:i.ONE_MINUS_SRC_ALPHA,[Tm]:i.ONE_MINUS_DST_COLOR,[Em]:i.ONE_MINUS_DST_ALPHA,[Cm]:i.CONSTANT_COLOR,[Pm]:i.ONE_MINUS_CONSTANT_COLOR,[Lm]:i.CONSTANT_ALPHA,[Dm]:i.ONE_MINUS_CONSTANT_ALPHA};function jt(C,Z,W,he,oe,ce,Re,Xe,ae,Pe){if(C===Ks){m===!0&&(Ge(i.BLEND),m=!1);return}if(m===!1&&(xe(i.BLEND),m=!0),C!==mm){if(C!==p||Pe!==R){if((x!==Xs||E!==Xs)&&(i.blendEquation(i.FUNC_ADD),x=Xs,E=Xs),Pe)switch(C){case Ua:i.blendFuncSeparate(i.ONE,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case fi:i.blendFunc(i.ONE,i.ONE);break;case th:i.blendFuncSeparate(i.ZERO,i.ONE_MINUS_SRC_COLOR,i.ZERO,i.ONE);break;case nh:i.blendFuncSeparate(i.DST_COLOR,i.ONE_MINUS_SRC_ALPHA,i.ZERO,i.ONE);break;default:it("WebGLState: Invalid blending: ",C);break}else switch(C){case Ua:i.blendFuncSeparate(i.SRC_ALPHA,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case fi:i.blendFuncSeparate(i.SRC_ALPHA,i.ONE,i.ONE,i.ONE);break;case th:it("WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true");break;case nh:it("WebGLState: MultiplyBlending requires material.premultipliedAlpha = true");break;default:it("WebGLState: Invalid blending: ",C);break}A=null,b=null,S=null,v=null,w.set(0,0,0),P=0,p=C,R=Pe}return}oe=oe||Z,ce=ce||W,Re=Re||he,(Z!==x||oe!==E)&&(i.blendEquationSeparate(ht[Z],ht[oe]),x=Z,E=oe),(W!==A||he!==b||ce!==S||Re!==v)&&(i.blendFuncSeparate(Ke[W],Ke[he],Ke[ce],Ke[Re]),A=W,b=he,S=ce,v=Re),(Xe.equals(w)===!1||ae!==P)&&(i.blendColor(Xe.r,Xe.g,Xe.b,ae),w.copy(Xe),P=ae),p=C,R=!1}function Ot(C,Z){C.side===Mn?Ge(i.CULL_FACE):xe(i.CULL_FACE);let W=C.side===rn;Z&&(W=!W),xn(W),C.blending===Ua&&C.transparent===!1?jt(Ks):jt(C.blending,C.blendEquation,C.blendSrc,C.blendDst,C.blendEquationAlpha,C.blendSrcAlpha,C.blendDstAlpha,C.blendColor,C.blendAlpha,C.premultipliedAlpha),r.setFunc(C.depthFunc),r.setTest(C.depthTest),r.setMask(C.depthWrite),a.setMask(C.colorWrite);const he=C.stencilWrite;o.setTest(he),he&&(o.setMask(C.stencilWriteMask),o.setFunc(C.stencilFunc,C.stencilRef,C.stencilFuncMask),o.setOp(C.stencilFail,C.stencilZFail,C.stencilZPass)),Wt(C.polygonOffset,C.polygonOffsetFactor,C.polygonOffsetUnits),C.alphaToCoverage===!0?xe(i.SAMPLE_ALPHA_TO_COVERAGE):Ge(i.SAMPLE_ALPHA_TO_COVERAGE)}function xn(C){N!==C&&(C?i.frontFace(i.CW):i.frontFace(i.CCW),N=C)}function St(C){C!==fm?(xe(i.CULL_FACE),C!==F&&(C===eh?i.cullFace(i.BACK):C===pm?i.cullFace(i.FRONT):i.cullFace(i.FRONT_AND_BACK))):Ge(i.CULL_FACE),F=C}function ri(C){C!==G&&($&&i.lineWidth(C),G=C)}function Wt(C,Z,W){C?(xe(i.POLYGON_OFFSET_FILL),(L!==Z||z!==W)&&(L=Z,z=W,r.getReversed()&&(Z=-Z,W=-W),i.polygonOffset(Z,W))):Ge(i.POLYGON_OFFSET_FILL)}function Fn(C){C?xe(i.SCISSOR_TEST):Ge(i.SCISSOR_TEST)}function On(C){C===void 0&&(C=i.TEXTURE0+X-1),ee!==C&&(i.activeTexture(C),ee=C)}function kn(C,Z,W){W===void 0&&(ee===null?W=i.TEXTURE0+X-1:W=ee);let he=ne[W];he===void 0&&(he={type:void 0,texture:void 0},ne[W]=he),(he.type!==C||he.texture!==Z)&&(ee!==W&&(i.activeTexture(W),ee=W),i.bindTexture(C,Z||Le[C]),he.type=C,he.texture=Z)}function U(){const C=ne[ee];C!==void 0&&C.type!==void 0&&(i.bindTexture(C.type,null),C.type=void 0,C.texture=void 0)}function Bn(){try{i.compressedTexImage2D(...arguments)}catch(C){it("WebGLState:",C)}}function Mt(){try{i.compressedTexImage3D(...arguments)}catch(C){it("WebGLState:",C)}}function wt(){try{i.texSubImage2D(...arguments)}catch(C){it("WebGLState:",C)}}function me(){try{i.texSubImage3D(...arguments)}catch(C){it("WebGLState:",C)}}function kt(){try{i.compressedTexSubImage2D(...arguments)}catch(C){it("WebGLState:",C)}}function De(){try{i.compressedTexSubImage3D(...arguments)}catch(C){it("WebGLState:",C)}}function Oe(){try{i.texStorage2D(...arguments)}catch(C){it("WebGLState:",C)}}function T(){try{i.texStorage3D(...arguments)}catch(C){it("WebGLState:",C)}}function _(){try{i.texImage2D(...arguments)}catch(C){it("WebGLState:",C)}}function k(){try{i.texImage3D(...arguments)}catch(C){it("WebGLState:",C)}}function ie(C){return h[C]!==void 0?h[C]:i.getParameter(C)}function J(C,Z){h[C]!==Z&&(i.pixelStorei(C,Z),h[C]=Z)}function le(C){K.equals(C)===!1&&(i.scissor(C.x,C.y,C.z,C.w),K.copy(C))}function fe(C){ye.equals(C)===!1&&(i.viewport(C.x,C.y,C.z,C.w),ye.copy(C))}function q(C,Z){let W=c.get(Z);W===void 0&&(W=new WeakMap,c.set(Z,W));let he=W.get(C);he===void 0&&(he=i.getUniformBlockIndex(Z,C.name),i.uniformBlockBinding(Z,he,he),W.set(C,he))}function Y(C,Z,W){const oe=c.get(Z).get(C);l[oe]!==W&&(i.bindBufferBase(i.UNIFORM_BUFFER,oe,W),l[oe]=W)}function de(){i.disable(i.BLEND),i.disable(i.CULL_FACE),i.disable(i.DEPTH_TEST),i.disable(i.POLYGON_OFFSET_FILL),i.disable(i.SCISSOR_TEST),i.disable(i.STENCIL_TEST),i.disable(i.SAMPLE_ALPHA_TO_COVERAGE),i.blendEquation(i.FUNC_ADD),i.blendFunc(i.ONE,i.ZERO),i.blendFuncSeparate(i.ONE,i.ZERO,i.ONE,i.ZERO),i.blendColor(0,0,0,0),i.colorMask(!0,!0,!0,!0),i.clearColor(0,0,0,0),i.depthMask(!0),i.depthFunc(i.LESS),r.setReversed(!1),i.clearDepth(1),i.stencilMask(4294967295),i.stencilFunc(i.ALWAYS,0,4294967295),i.stencilOp(i.KEEP,i.KEEP,i.KEEP),i.clearStencil(0),i.cullFace(i.BACK),i.frontFace(i.CCW),i.polygonOffset(0,0),i.activeTexture(i.TEXTURE0),i.bindFramebuffer(i.FRAMEBUFFER,null),i.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),i.bindFramebuffer(i.READ_FRAMEBUFFER,null),i.useProgram(null),i.lineWidth(1),i.scissor(0,0,i.canvas.width,i.canvas.height),i.viewport(0,0,i.canvas.width,i.canvas.height),i.pixelStorei(i.PACK_ALIGNMENT,4),i.pixelStorei(i.UNPACK_ALIGNMENT,4),i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,!1),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,!1),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,i.BROWSER_DEFAULT_WEBGL),i.pixelStorei(i.PACK_ROW_LENGTH,0),i.pixelStorei(i.PACK_SKIP_PIXELS,0),i.pixelStorei(i.PACK_SKIP_ROWS,0),i.pixelStorei(i.UNPACK_ROW_LENGTH,0),i.pixelStorei(i.UNPACK_IMAGE_HEIGHT,0),i.pixelStorei(i.UNPACK_SKIP_PIXELS,0),i.pixelStorei(i.UNPACK_SKIP_ROWS,0),i.pixelStorei(i.UNPACK_SKIP_IMAGES,0),d={},h={},ee=null,ne={},u={},l={},f=new WeakMap,g=[],y=null,m=!1,p=null,x=null,A=null,b=null,E=null,S=null,v=null,w=new Ce(0,0,0),P=0,R=!1,N=null,F=null,G=null,L=null,z=null,K.set(0,0,i.canvas.width,i.canvas.height),ye.set(0,0,i.canvas.width,i.canvas.height),a.reset(),r.reset(),o.reset()}return{buffers:{color:a,depth:r,stencil:o},enable:xe,disable:Ge,bindFramebuffer:Lt,drawBuffers:Ne,useProgram:rt,setBlending:jt,setMaterial:Ot,setFlipSided:xn,setCullFace:St,setLineWidth:ri,setPolygonOffset:Wt,setScissorTest:Fn,activeTexture:On,bindTexture:kn,unbindTexture:U,compressedTexImage2D:Bn,compressedTexImage3D:Mt,texImage2D:_,texImage3D:k,pixelStorei:J,getParameter:ie,updateUBOMapping:q,uniformBlockBinding:Y,texStorage2D:Oe,texStorage3D:T,texSubImage2D:wt,texSubImage3D:me,compressedTexSubImage2D:kt,compressedTexSubImage3D:De,scissor:le,viewport:fe,reset:de}}function Ab(i,e,t,n,s,a,r){const o=e.has("WEBGL_multisampled_render_to_texture")?e.get("WEBGL_multisampled_render_to_texture"):null,l=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),c=new Ie,d=new WeakMap,h=new Set;let u;const f=new WeakMap,g=new Set,y=new FinalizationRegistry(T=>g.delete(T));let m=!1;try{m=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function p(T,_){return m?new OffscreenCanvas(T,_):vo("canvas")}function x(T,_,k){let ie=1;const J=Oe(T);if((J.width>k||J.height>k)&&(ie=k/Math.max(J.width,J.height)),ie<1)if(typeof HTMLImageElement<"u"&&T instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&T instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&T instanceof ImageBitmap||typeof VideoFrame<"u"&&T instanceof VideoFrame){const le=Math.floor(ie*J.width),fe=Math.floor(ie*J.height);u===void 0&&(u=p(le,fe));const q=_?p(le,fe):u;return q.width=le,q.height=fe,q.getContext("2d").drawImage(T,0,0,le,fe),Ue("WebGLRenderer: Texture has been resized from ("+J.width+"x"+J.height+") to ("+le+"x"+fe+")."),q}else return"data"in T&&Ue("WebGLRenderer: Image in DataTexture is too big ("+J.width+"x"+J.height+")."),T;return T}function A(T){return T.generateMipmaps}function b(T){i.generateMipmap(T)}function E(T){return T.isWebGLCubeRenderTarget?i.TEXTURE_CUBE_MAP:T.isWebGL3DRenderTarget?i.TEXTURE_3D:T.isWebGLArrayRenderTarget||T.isCompressedArrayTexture?i.TEXTURE_2D_ARRAY:i.TEXTURE_2D}function S(T,_,k,ie,J,le=!1){if(T!==null){if(i[T]!==void 0)return i[T];Ue("WebGLRenderer: Attempt to use non-existing WebGL internal format '"+T+"'")}let fe;ie&&(fe=e.get("EXT_texture_norm16"),fe||Ue("WebGLRenderer: Unable to use normalized textures without EXT_texture_norm16 extension"));let q=_;if(_===i.RED&&(k===i.FLOAT&&(q=i.R32F),k===i.HALF_FLOAT&&(q=i.R16F),k===i.UNSIGNED_BYTE&&(q=i.R8),k===i.UNSIGNED_SHORT&&fe&&(q=fe.R16_EXT),k===i.SHORT&&fe&&(q=fe.R16_SNORM_EXT)),_===i.RED_INTEGER&&(k===i.UNSIGNED_BYTE&&(q=i.R8UI),k===i.UNSIGNED_SHORT&&(q=i.R16UI),k===i.UNSIGNED_INT&&(q=i.R32UI),k===i.BYTE&&(q=i.R8I),k===i.SHORT&&(q=i.R16I),k===i.INT&&(q=i.R32I)),_===i.RG&&(k===i.FLOAT&&(q=i.RG32F),k===i.HALF_FLOAT&&(q=i.RG16F),k===i.UNSIGNED_BYTE&&(q=i.RG8),k===i.UNSIGNED_SHORT&&fe&&(q=fe.RG16_EXT),k===i.SHORT&&fe&&(q=fe.RG16_SNORM_EXT)),_===i.RG_INTEGER&&(k===i.UNSIGNED_BYTE&&(q=i.RG8UI),k===i.UNSIGNED_SHORT&&(q=i.RG16UI),k===i.UNSIGNED_INT&&(q=i.RG32UI),k===i.BYTE&&(q=i.RG8I),k===i.SHORT&&(q=i.RG16I),k===i.INT&&(q=i.RG32I)),_===i.RGB_INTEGER&&(k===i.UNSIGNED_BYTE&&(q=i.RGB8UI),k===i.UNSIGNED_SHORT&&(q=i.RGB16UI),k===i.UNSIGNED_INT&&(q=i.RGB32UI),k===i.BYTE&&(q=i.RGB8I),k===i.SHORT&&(q=i.RGB16I),k===i.INT&&(q=i.RGB32I)),_===i.RGBA_INTEGER&&(k===i.UNSIGNED_BYTE&&(q=i.RGBA8UI),k===i.UNSIGNED_SHORT&&(q=i.RGBA16UI),k===i.UNSIGNED_INT&&(q=i.RGBA32UI),k===i.BYTE&&(q=i.RGBA8I),k===i.SHORT&&(q=i.RGBA16I),k===i.INT&&(q=i.RGBA32I)),_===i.RGB&&(k===i.UNSIGNED_SHORT&&fe&&(q=fe.RGB16_EXT),k===i.SHORT&&fe&&(q=fe.RGB16_SNORM_EXT),k===i.UNSIGNED_INT_5_9_9_9_REV&&(q=i.RGB9_E5),k===i.UNSIGNED_INT_10F_11F_11F_REV&&(q=i.R11F_G11F_B10F)),_===i.RGBA){const Y=le?go:et.getTransfer(J);k===i.FLOAT&&(q=i.RGBA32F),k===i.HALF_FLOAT&&(q=i.RGBA16F),k===i.UNSIGNED_BYTE&&(q=Y===lt?i.SRGB8_ALPHA8:i.RGBA8),k===i.UNSIGNED_SHORT&&fe&&(q=fe.RGBA16_EXT),k===i.SHORT&&fe&&(q=fe.RGBA16_SNORM_EXT),k===i.UNSIGNED_SHORT_4_4_4_4&&(q=i.RGBA4),k===i.UNSIGNED_SHORT_5_5_5_1&&(q=i.RGB5_A1)}return(q===i.R16F||q===i.R32F||q===i.RG16F||q===i.RG32F||q===i.RGBA16F||q===i.RGBA32F)&&e.get("EXT_color_buffer_float"),q}function v(T,_){let k;return T?_===null||_===mi||_===aa?k=i.DEPTH24_STENCIL8:_===ii?k=i.DEPTH32F_STENCIL8:_===Ga&&(k=i.DEPTH24_STENCIL8,Ue("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):_===null||_===mi||_===aa?k=i.DEPTH_COMPONENT24:_===ii?k=i.DEPTH_COMPONENT32F:_===Ga&&(k=i.DEPTH_COMPONENT16),k}function w(T,_){return A(T)===!0||T.isFramebufferTexture&&T.minFilter!==sn&&T.minFilter!==vn?Math.log2(Math.max(_.width,_.height))+1:T.mipmaps.length>0?T.mipmaps.length:T.isCompressedTexture&&Array.isArray(T.image)?_.mipmaps.length:1}function P(T){const _=new WeakRef(T);n.get(T).__ref=_,g.add(_),y.register(T,_,_)}function R(T){const _=n.get(T).__ref;_!==void 0&&(g.delete(_),y.unregister(_))}function N(T){G(T.target)}function F(T){L(T.target)}function G(T){T.removeEventListener("dispose",N),R(T),X(T),T.isVideoTexture&&d.delete(T),T.isHTMLTexture&&h.delete(T)}function L(T){T.removeEventListener("dispose",F),R(T),te(T)}function z(){for(const T of g){const _=T.deref();_!==void 0&&(_.isRenderTarget===!0?L(_):G(_))}g.clear(),h.clear()}function X(T){const _=n.get(T);if(_.__webglInit===void 0)return;const k=T.source,ie=f.get(k);if(ie){const J=ie[_.__cacheKey];J.usedTimes--,J.usedTimes===0&&$(T),Object.keys(ie).length===0&&f.delete(k)}n.remove(T)}function $(T){const _=n.get(T);i.deleteTexture(_.__webglTexture);const k=T.source,ie=f.get(k);delete ie[_.__cacheKey],r.memory.textures--}function te(T){const _=n.get(T);_.__depthDisposeCallback&&_.__depthDisposeCallback();const k=T.depthTexture;if(k&&k.renderTarget===T&&G(k),T.isWebGLCubeRenderTarget)for(let J=0;J<6;J++){if(Array.isArray(_.__webglFramebuffer[J]))for(let le=0;le<_.__webglFramebuffer[J].length;le++)i.deleteFramebuffer(_.__webglFramebuffer[J][le]);else i.deleteFramebuffer(_.__webglFramebuffer[J]);_.__webglDepthbuffer&&i.deleteRenderbuffer(_.__webglDepthbuffer[J])}else{if(Array.isArray(_.__webglFramebuffer))for(let J=0;J<_.__webglFramebuffer.length;J++)i.deleteFramebuffer(_.__webglFramebuffer[J]);else i.deleteFramebuffer(_.__webglFramebuffer);if(_.__webglDepthbuffer&&i.deleteRenderbuffer(_.__webglDepthbuffer),_.__webglMultisampledFramebuffer&&i.deleteFramebuffer(_.__webglMultisampledFramebuffer),_.__webglColorRenderbuffer)for(let J=0;J<_.__webglColorRenderbuffer.length;J++)_.__webglColorRenderbuffer[J]&&i.deleteRenderbuffer(_.__webglColorRenderbuffer[J]);_.__webglDepthRenderbuffer&&i.deleteRenderbuffer(_.__webglDepthRenderbuffer)}const ie=T.textures;for(let J=0,le=ie.length;J<le;J++){const fe=n.get(ie[J]);fe.__webglTexture&&(i.deleteTexture(fe.__webglTexture),r.memory.textures--),n.remove(ie[J])}n.remove(T)}let V=0;function ee(){V=0}function ne(){return V}function Ee(T){V=T}function $e(){const T=V;return T>=s.maxTextures&&Ue("WebGLTextures: Trying to use "+(T+1)+" texture units while this GPU supports only "+s.maxTextures),V+=1,T}function K(T){const _=[];return _.push(T.wrapS),_.push(T.wrapT),_.push(T.wrapR||0),_.push(T.magFilter),_.push(T.minFilter),_.push(T.anisotropy),_.push(T.internalFormat),_.push(T.format),_.push(T.type),_.push(T.generateMipmaps),_.push(T.mipmapsAutoUpdate),_.push(T.premultiplyAlpha),_.push(T.flipY),_.push(T.unpackAlignment),_.push(T.colorSpace),_.join()}function ye(T,_){const k=n.get(T);if(T.isVideoTexture&&kt(T),T.isRenderTargetTexture===!1&&T.isExternalTexture!==!0&&T.version>0&&k.__version!==T.version){const ie=T.image;if(ie===null)Ue("WebGLRenderer: Texture marked for update but no image data found.");else if(ie.complete===!1)Ue("WebGLRenderer: Texture marked for update but image is incomplete");else{Ot(k,T,_);return}}else T.isExternalTexture&&(k.__webglTexture=T.sourceTexture?T.sourceTexture:null);t.bindTexture(i.TEXTURE_2D,k.__webglTexture,i.TEXTURE0+_)}function Me(T,_){const k=n.get(T);if(T.isRenderTargetTexture===!1&&T.version>0&&k.__version!==T.version){Ot(k,T,_);return}else T.isExternalTexture&&(k.__webglTexture=T.sourceTexture?T.sourceTexture:null);t.bindTexture(i.TEXTURE_2D_ARRAY,k.__webglTexture,i.TEXTURE0+_)}function Le(T,_){const k=n.get(T);if(T.isRenderTargetTexture===!1&&T.version>0&&k.__version!==T.version){Ot(k,T,_);return}t.bindTexture(i.TEXTURE_3D,k.__webglTexture,i.TEXTURE0+_)}function xe(T,_){const k=n.get(T);if(T.version>0&&k.__version!==T.version){xn(k,T,_);return}t.bindTexture(i.TEXTURE_CUBE_MAP,k.__webglTexture,i.TEXTURE0+_)}const Ge={[ho]:i.REPEAT,[Pi]:i.CLAMP_TO_EDGE,[cc]:i.MIRRORED_REPEAT},Lt={[sn]:i.NEAREST,[Um]:i.NEAREST_MIPMAP_NEAREST,[or]:i.NEAREST_MIPMAP_LINEAR,[vn]:i.LINEAR,[fl]:i.LINEAR_MIPMAP_NEAREST,[Li]:i.LINEAR_MIPMAP_LINEAR},Ne={[Bm]:i.NEVER,[Tf]:i.ALWAYS,[zm]:i.LESS,[Ef]:i.LEQUAL,[$m]:i.EQUAL,[Af]:i.GEQUAL,[Hm]:i.GREATER,[Gm]:i.NOTEQUAL};function rt(T,_){if(_.type===ii&&e.has("OES_texture_float_linear")===!1&&(_.magFilter===vn||_.magFilter===fl||_.magFilter===or||_.magFilter===Li||_.minFilter===vn||_.minFilter===fl||_.minFilter===or||_.minFilter===Li)&&Ue("WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),i.texParameteri(T,i.TEXTURE_WRAP_S,Ge[_.wrapS]),i.texParameteri(T,i.TEXTURE_WRAP_T,Ge[_.wrapT]),(T===i.TEXTURE_3D||T===i.TEXTURE_2D_ARRAY)&&i.texParameteri(T,i.TEXTURE_WRAP_R,Ge[_.wrapR]),i.texParameteri(T,i.TEXTURE_MAG_FILTER,Lt[_.magFilter]),i.texParameteri(T,i.TEXTURE_MIN_FILTER,Lt[_.minFilter]),_.compareFunction&&(i.texParameteri(T,i.TEXTURE_COMPARE_MODE,i.COMPARE_REF_TO_TEXTURE),i.texParameteri(T,i.TEXTURE_COMPARE_FUNC,Ne[_.compareFunction])),e.has("EXT_texture_filter_anisotropic")===!0){if(_.magFilter===sn||_.minFilter!==or&&_.minFilter!==Li||_.type===ii&&e.has("OES_texture_float_linear")===!1)return;if(_.anisotropy>1||n.get(_).__currentAnisotropy){const k=e.get("EXT_texture_filter_anisotropic");i.texParameterf(T,k.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(_.anisotropy,s.getMaxAnisotropy())),n.get(_).__currentAnisotropy=_.anisotropy}}}function ht(T,_){let k=!1;T.__webglInit===void 0&&(T.__webglInit=!0,_.addEventListener("dispose",N),P(_));const ie=_.source;let J=f.get(ie);J===void 0&&(J={},f.set(ie,J));const le=K(_);if(le!==T.__cacheKey){J[le]===void 0&&(J[le]={texture:i.createTexture(),usedTimes:0},r.memory.textures++,k=!0),J[le].usedTimes++;const fe=J[T.__cacheKey];fe!==void 0&&(J[T.__cacheKey].usedTimes--,fe.usedTimes===0&&$(_)),T.__cacheKey=le,T.__webglTexture=J[le].texture}return k}function Ke(T,_,k){return Math.floor(Math.floor(T/k)/_)}function jt(T,_,k,ie){const le=T.updateRanges;if(le.length===0)t.texSubImage2D(i.TEXTURE_2D,0,0,0,_.width,_.height,k,ie,_.data);else{le.sort((C,Z)=>C.start-Z.start);let fe=0;for(let C=1;C<le.length;C++){const Z=le[fe],W=le[C],he=Z.start+Z.count,oe=Ke(W.start,_.width,4),ce=Ke(Z.start,_.width,4);W.start<=he+1&&oe===ce&&Ke(W.start+W.count-1,_.width,4)===oe?Z.count=Math.max(Z.count,W.start+W.count-Z.start):(++fe,le[fe]=W)}le.length=fe+1;const q=t.getParameter(i.UNPACK_ROW_LENGTH),Y=t.getParameter(i.UNPACK_SKIP_PIXELS),de=t.getParameter(i.UNPACK_SKIP_ROWS);t.pixelStorei(i.UNPACK_ROW_LENGTH,_.width);for(let C=0,Z=le.length;C<Z;C++){const W=le[C],he=Math.floor(W.start/4),oe=Math.ceil(W.count/4),ce=he%_.width,Re=Math.floor(he/_.width),Xe=oe,ae=1;t.pixelStorei(i.UNPACK_SKIP_PIXELS,ce),t.pixelStorei(i.UNPACK_SKIP_ROWS,Re),t.texSubImage2D(i.TEXTURE_2D,0,ce,Re,Xe,ae,k,ie,_.data)}T.clearUpdateRanges(),t.pixelStorei(i.UNPACK_ROW_LENGTH,q),t.pixelStorei(i.UNPACK_SKIP_PIXELS,Y),t.pixelStorei(i.UNPACK_SKIP_ROWS,de)}}function Ot(T,_,k){let ie=i.TEXTURE_2D;(_.isDataArrayTexture||_.isCompressedArrayTexture)&&(ie=i.TEXTURE_2D_ARRAY),_.isData3DTexture&&(ie=i.TEXTURE_3D);const J=ht(T,_),le=_.source;t.bindTexture(ie,T.__webglTexture,i.TEXTURE0+k);const fe=n.get(le);if(le.version!==fe.__version||J===!0){if(t.activeTexture(i.TEXTURE0+k),(typeof ImageBitmap<"u"&&_.image instanceof ImageBitmap)===!1){const ae=et.getPrimaries(et.workingColorSpace),Pe=_.colorSpace===Ti?null:et.getPrimaries(_.colorSpace),Ve=_.colorSpace===Ti||ae===Pe?i.NONE:i.BROWSER_DEFAULT_WEBGL;t.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,_.flipY),t.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,_.premultiplyAlpha),t.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,Ve)}t.pixelStorei(i.UNPACK_ALIGNMENT,_.unpackAlignment);let Y=x(_.image,!1,s.maxTextureSize);Y=De(_,Y);const de=a.convert(_.format,_.colorSpace),C=a.convert(_.type);let Z=S(_.internalFormat,de,C,_.normalized,_.colorSpace,_.isVideoTexture);rt(ie,_);let W;const he=_.mipmaps,oe=_.isVideoTexture!==!0,ce=fe.__version===void 0||J===!0,Re=le.dataReady,Xe=w(_,Y);if(_.isDepthTexture)Z=v(_.format===Ji,_.type),ce&&(oe?t.texStorage2D(i.TEXTURE_2D,1,Z,Y.width,Y.height):t.texImage2D(i.TEXTURE_2D,0,Z,Y.width,Y.height,0,de,C,null));else if(_.isDataTexture)if(he.length>0){oe&&ce&&t.texStorage2D(i.TEXTURE_2D,Xe,Z,he[0].width,he[0].height);for(let ae=0,Pe=he.length;ae<Pe;ae++)W=he[ae],oe?Re&&t.texSubImage2D(i.TEXTURE_2D,ae,0,0,W.width,W.height,de,C,W.data):t.texImage2D(i.TEXTURE_2D,ae,Z,W.width,W.height,0,de,C,W.data);_.generateMipmaps=!1}else oe?(ce&&t.texStorage2D(i.TEXTURE_2D,Xe,Z,Y.width,Y.height),Re&&jt(_,Y,de,C)):t.texImage2D(i.TEXTURE_2D,0,Z,Y.width,Y.height,0,de,C,Y.data);else if(_.isCompressedTexture)if(_.isCompressedArrayTexture){oe&&ce&&t.texStorage3D(i.TEXTURE_2D_ARRAY,Xe,Z,he[0].width,he[0].height,Y.depth);for(let ae=0,Pe=he.length;ae<Pe;ae++)if(W=he[ae],_.format!==hi)if(de!==null)if(oe){if(Re)if(_.layerUpdates.size>0){const Ve=$h(W.width,W.height,_.format,_.type);for(const ge of _.layerUpdates){const ot=W.data.subarray(ge*Ve/W.data.BYTES_PER_ELEMENT,(ge+1)*Ve/W.data.BYTES_PER_ELEMENT);t.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,ae,0,0,ge,W.width,W.height,1,de,ot)}}else t.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,ae,0,0,0,W.width,W.height,Y.depth,de,W.data)}else t.compressedTexImage3D(i.TEXTURE_2D_ARRAY,ae,Z,W.width,W.height,Y.depth,0,W.data,0,0);else Ue("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else oe?Re&&t.texSubImage3D(i.TEXTURE_2D_ARRAY,ae,0,0,0,W.width,W.height,Y.depth,de,C,W.data):t.texImage3D(i.TEXTURE_2D_ARRAY,ae,Z,W.width,W.height,Y.depth,0,de,C,W.data);_.layerUpdates.size>0&&_.clearLayerUpdates()}else{oe&&ce&&t.texStorage2D(i.TEXTURE_2D,Xe,Z,he[0].width,he[0].height);for(let ae=0,Pe=he.length;ae<Pe;ae++)W=he[ae],_.format!==hi?de!==null?oe?Re&&t.compressedTexSubImage2D(i.TEXTURE_2D,ae,0,0,W.width,W.height,de,W.data):t.compressedTexImage2D(i.TEXTURE_2D,ae,Z,W.width,W.height,0,W.data):Ue("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):oe?Re&&t.texSubImage2D(i.TEXTURE_2D,ae,0,0,W.width,W.height,de,C,W.data):t.texImage2D(i.TEXTURE_2D,ae,Z,W.width,W.height,0,de,C,W.data)}else if(_.isDataArrayTexture)if(oe){if(ce&&t.texStorage3D(i.TEXTURE_2D_ARRAY,Xe,Z,Y.width,Y.height,Y.depth),Re)if(_.layerUpdates.size>0){const ae=$h(Y.width,Y.height,_.format,_.type);for(const Pe of _.layerUpdates){const Ve=Y.data.subarray(Pe*ae/Y.data.BYTES_PER_ELEMENT,(Pe+1)*ae/Y.data.BYTES_PER_ELEMENT);t.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,Pe,Y.width,Y.height,1,de,C,Ve)}_.clearLayerUpdates()}else t.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,0,Y.width,Y.height,Y.depth,de,C,Y.data)}else t.texImage3D(i.TEXTURE_2D_ARRAY,0,Z,Y.width,Y.height,Y.depth,0,de,C,Y.data);else if(_.isData3DTexture)oe?(ce&&t.texStorage3D(i.TEXTURE_3D,Xe,Z,Y.width,Y.height,Y.depth),Re&&t.texSubImage3D(i.TEXTURE_3D,0,0,0,0,Y.width,Y.height,Y.depth,de,C,Y.data)):t.texImage3D(i.TEXTURE_3D,0,Z,Y.width,Y.height,Y.depth,0,de,C,Y.data);else if(_.isFramebufferTexture){if(ce)if(oe)t.texStorage2D(i.TEXTURE_2D,Xe,Z,Y.width,Y.height);else{let ae=Y.width,Pe=Y.height;for(let Ve=0;Ve<Xe;Ve++)t.texImage2D(i.TEXTURE_2D,Ve,Z,ae,Pe,0,de,C,null),ae>>=1,Pe>>=1}}else if(_.isHTMLTexture){if("texElementImage2D"in i){const ae=i.canvas;if(ae.hasAttribute("layoutsubtree")||ae.setAttribute("layoutsubtree","true"),Y.parentNode!==ae){ae.appendChild(Y),h.add(_),ae.onpaint=Pe=>{const Ve=Pe.changedElements;for(const ge of h)Ve.includes(ge.image)&&(ge.needsUpdate=!0)},ae.requestPaint();return}if(i.texElementImage2D.length===3)i.texElementImage2D(i.TEXTURE_2D,i.RGBA8,Y);else{const Ve=i.RGBA,ge=i.RGBA,ot=i.UNSIGNED_BYTE;i.texElementImage2D(i.TEXTURE_2D,0,Ve,ge,ot,Y)}i.texParameteri(i.TEXTURE_2D,i.TEXTURE_MIN_FILTER,i.LINEAR),i.texParameteri(i.TEXTURE_2D,i.TEXTURE_WRAP_S,i.CLAMP_TO_EDGE),i.texParameteri(i.TEXTURE_2D,i.TEXTURE_WRAP_T,i.CLAMP_TO_EDGE)}}else if(he.length>0){if(oe&&ce){const ae=Oe(he[0]);t.texStorage2D(i.TEXTURE_2D,Xe,Z,ae.width,ae.height)}for(let ae=0,Pe=he.length;ae<Pe;ae++)W=he[ae],oe?Re&&t.texSubImage2D(i.TEXTURE_2D,ae,0,0,de,C,W):t.texImage2D(i.TEXTURE_2D,ae,Z,de,C,W);_.generateMipmaps=!1}else if(oe){if(ce){const ae=Oe(Y);t.texStorage2D(i.TEXTURE_2D,Xe,Z,ae.width,ae.height)}Re&&t.texSubImage2D(i.TEXTURE_2D,0,0,0,de,C,Y)}else t.texImage2D(i.TEXTURE_2D,0,Z,de,C,Y);A(_)&&_.mipmapsAutoUpdate===!0&&b(ie),fe.__version=le.version,_.onUpdate&&_.onUpdate(_)}T.__version=_.version}function xn(T,_,k){if(_.image.length!==6)return;const ie=ht(T,_),J=_.source;t.bindTexture(i.TEXTURE_CUBE_MAP,T.__webglTexture,i.TEXTURE0+k);const le=n.get(J);if(J.version!==le.__version||ie===!0){t.activeTexture(i.TEXTURE0+k);const fe=et.getPrimaries(et.workingColorSpace),q=_.colorSpace===Ti?null:et.getPrimaries(_.colorSpace),Y=_.colorSpace===Ti||fe===q?i.NONE:i.BROWSER_DEFAULT_WEBGL;t.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,_.flipY),t.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,_.premultiplyAlpha),t.pixelStorei(i.UNPACK_ALIGNMENT,_.unpackAlignment),t.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,Y);const de=_.isCompressedTexture||_.image[0].isCompressedTexture,C=_.image[0]&&_.image[0].isDataTexture,Z=[];for(let ge=0;ge<6;ge++)!de&&!C?Z[ge]=x(_.image[ge],!0,s.maxCubemapSize):Z[ge]=C?_.image[ge].image:_.image[ge],Z[ge]=De(_,Z[ge]);const W=Z[0],he=a.convert(_.format,_.colorSpace),oe=a.convert(_.type);let ce=S(_.internalFormat,he,oe,_.normalized,_.colorSpace);const Re=_.isVideoTexture!==!0,Xe=le.__version===void 0||ie===!0,ae=J.dataReady;let Pe=w(_,W);rt(i.TEXTURE_CUBE_MAP,_);let Ve;if(_.isDepthTexture){if(ce=v(_.format===Ji,_.type),Xe)if(Re)t.texStorage2D(i.TEXTURE_CUBE_MAP,1,ce,W.width,W.height);else for(let ge=0;ge<6;ge++)t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ge,0,ce,W.width,W.height,0,he,oe,null)}else if(de){Re&&Xe&&t.texStorage2D(i.TEXTURE_CUBE_MAP,Pe,ce,W.width,W.height);for(let ge=0;ge<6;ge++){Ve=Z[ge].mipmaps;for(let ot=0;ot<Ve.length;ot++){const Xt=Ve[ot];_.format!==hi?he!==null?Re?ae&&t.compressedTexSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ge,ot,0,0,Xt.width,Xt.height,he,Xt.data):t.compressedTexImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ge,ot,ce,Xt.width,Xt.height,0,Xt.data):Ue("WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):Re?ae&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ge,ot,0,0,Xt.width,Xt.height,he,oe,Xt.data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ge,ot,ce,Xt.width,Xt.height,0,he,oe,Xt.data)}}}else{if(Ve=_.mipmaps,Re&&Xe){Ve.length>0&&Pe++;const ge=Oe(Z[0]);t.texStorage2D(i.TEXTURE_CUBE_MAP,Pe,ce,ge.width,ge.height)}for(let ge=0;ge<6;ge++)if(C){Re?ae&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ge,0,0,0,Z[ge].width,Z[ge].height,he,oe,Z[ge].data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ge,0,ce,Z[ge].width,Z[ge].height,0,he,oe,Z[ge].data);for(let ot=0;ot<Ve.length;ot++){const ki=Ve[ot].image[ge].image;Re?ae&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ge,ot+1,0,0,ki.width,ki.height,he,oe,ki.data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ge,ot+1,ce,ki.width,ki.height,0,he,oe,ki.data)}}else{Re?ae&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ge,0,0,0,he,oe,Z[ge]):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ge,0,ce,he,oe,Z[ge]);for(let ot=0;ot<Ve.length;ot++){const Xt=Ve[ot];Re?ae&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ge,ot+1,0,0,he,oe,Xt.image[ge]):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ge,ot+1,ce,he,oe,Xt.image[ge])}}}A(_)&&_.mipmapsAutoUpdate===!0&&b(i.TEXTURE_CUBE_MAP),le.__version=J.version,_.onUpdate&&_.onUpdate(_)}T.__version=_.version}function St(T,_,k,ie,J,le){const fe=a.convert(k.format,k.colorSpace),q=a.convert(k.type),Y=S(k.internalFormat,fe,q,k.normalized,k.colorSpace),de=n.get(_),C=n.get(k);if(C.__renderTarget=_,!de.__hasExternalTextures){const Z=Math.max(1,_.width>>le),W=Math.max(1,_.height>>le);J===i.TEXTURE_3D||J===i.TEXTURE_2D_ARRAY?t.texImage3D(J,le,Y,Z,W,_.depth,0,fe,q,null):t.texImage2D(J,le,Y,Z,W,0,fe,q,null)}t.bindFramebuffer(i.FRAMEBUFFER,T),me(_)?o.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,ie,J,C.__webglTexture,0,wt(_)):(J===i.TEXTURE_2D||J>=i.TEXTURE_CUBE_MAP_POSITIVE_X&&J<=i.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&i.framebufferTexture2D(i.FRAMEBUFFER,ie,J,C.__webglTexture,le),t.bindFramebuffer(i.FRAMEBUFFER,null)}function ri(T,_,k){if(i.bindRenderbuffer(i.RENDERBUFFER,T),_.depthBuffer){const ie=_.depthTexture,J=ie&&ie.isDepthTexture?ie.type:null,le=v(_.stencilBuffer,J),fe=_.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT;me(_)?o.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,wt(_),le,_.width,_.height):k?i.renderbufferStorageMultisample(i.RENDERBUFFER,wt(_),le,_.width,_.height):i.renderbufferStorage(i.RENDERBUFFER,le,_.width,_.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,fe,i.RENDERBUFFER,T)}else{const ie=_.textures;for(let J=0;J<ie.length;J++){const le=ie[J],fe=a.convert(le.format,le.colorSpace),q=a.convert(le.type),Y=S(le.internalFormat,fe,q,le.normalized,le.colorSpace);me(_)?o.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,wt(_),Y,_.width,_.height):k?i.renderbufferStorageMultisample(i.RENDERBUFFER,wt(_),Y,_.width,_.height):i.renderbufferStorage(i.RENDERBUFFER,Y,_.width,_.height)}}i.bindRenderbuffer(i.RENDERBUFFER,null)}function Wt(T,_,k){const ie=_.isWebGLCubeRenderTarget===!0;if(t.bindFramebuffer(i.FRAMEBUFFER,T),!(_.depthTexture&&_.depthTexture.isDepthTexture))throw new Error("THREE.WebGLTextures: renderTarget.depthTexture must be an instance of THREE.DepthTexture.");const J=n.get(_.depthTexture);J.__renderTarget=_;const le=ie?_.depthTexture.image[0]:_.depthTexture.image;(!J.__webglTexture||le.width!==_.width||le.height!==_.height)&&(le.width=_.width,le.height=_.height,_.depthTexture.needsUpdate=!0),ie?xe(_.depthTexture,0):ye(_.depthTexture,0);const fe=J.__webglTexture,q=wt(_),Y=ie?i.TEXTURE_CUBE_MAP_POSITIVE_X+k:i.TEXTURE_2D,de=_.depthTexture.format===Ji?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT;if(_.depthTexture.format===ns)me(_)?o.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,de,Y,fe,0,q):i.framebufferTexture2D(i.FRAMEBUFFER,de,Y,fe,0);else if(_.depthTexture.format===Ji)me(_)?o.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,de,Y,fe,0,q):i.framebufferTexture2D(i.FRAMEBUFFER,de,Y,fe,0);else throw new Error("THREE.WebGLTextures: Unknown depthTexture format.")}function Fn(T){const _=n.get(T),k=T.isWebGLCubeRenderTarget===!0;if(_.__boundDepthTexture!==T.depthTexture){const ie=T.depthTexture;if(_.__depthDisposeCallback&&_.__depthDisposeCallback(),ie){const J=()=>{delete _.__boundDepthTexture,delete _.__depthDisposeCallback,ie.removeEventListener("dispose",J)};ie.addEventListener("dispose",J),_.__depthDisposeCallback=J}_.__boundDepthTexture=ie}if(T.depthTexture&&!_.__autoAllocateDepthBuffer)if(k)for(let ie=0;ie<6;ie++)Wt(_.__webglFramebuffer[ie],T,ie);else T.texture.mipmaps.length>0?Wt(_.__webglFramebuffer[0],T,0):Wt(_.__webglFramebuffer,T,0);else if(k){_.__webglDepthbuffer=[];for(let ie=0;ie<6;ie++)if(t.bindFramebuffer(i.FRAMEBUFFER,_.__webglFramebuffer[ie]),_.__webglDepthbuffer[ie]===void 0)_.__webglDepthbuffer[ie]=i.createRenderbuffer(),ri(_.__webglDepthbuffer[ie],T,!1);else{const J=T.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,le=_.__webglDepthbuffer[ie];i.bindRenderbuffer(i.RENDERBUFFER,le),i.framebufferRenderbuffer(i.FRAMEBUFFER,J,i.RENDERBUFFER,le)}}else if(T.texture.mipmaps.length>0?t.bindFramebuffer(i.FRAMEBUFFER,_.__webglFramebuffer[0]):t.bindFramebuffer(i.FRAMEBUFFER,_.__webglFramebuffer),_.__webglDepthbuffer===void 0)_.__webglDepthbuffer=i.createRenderbuffer(),ri(_.__webglDepthbuffer,T,!1);else{const J=T.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,le=_.__webglDepthbuffer;i.bindRenderbuffer(i.RENDERBUFFER,le),i.framebufferRenderbuffer(i.FRAMEBUFFER,J,i.RENDERBUFFER,le)}t.bindFramebuffer(i.FRAMEBUFFER,null)}function On(T,_,k){const ie=n.get(T);_!==void 0&&St(ie.__webglFramebuffer,T,T.texture,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,0),k!==void 0&&Fn(T)}function kn(T){const _=T.texture,k=n.get(T),ie=n.get(_);T.addEventListener("dispose",F),P(T);const J=T.textures,le=T.isWebGLCubeRenderTarget===!0,fe=J.length>1;if(fe||(ie.__webglTexture===void 0&&(ie.__webglTexture=i.createTexture()),ie.__version=_.version,r.memory.textures++),le){k.__webglFramebuffer=[];for(let q=0;q<6;q++)if(_.mipmaps.length>0){k.__webglFramebuffer[q]=[];for(let Y=0;Y<_.mipmaps.length;Y++)k.__webglFramebuffer[q][Y]=i.createFramebuffer()}else k.__webglFramebuffer[q]=i.createFramebuffer()}else{if(_.mipmaps.length>0){k.__webglFramebuffer=[];for(let q=0;q<_.mipmaps.length;q++)k.__webglFramebuffer[q]=i.createFramebuffer()}else k.__webglFramebuffer=i.createFramebuffer();if(fe)for(let q=0,Y=J.length;q<Y;q++){const de=n.get(J[q]);de.__webglTexture===void 0&&(de.__webglTexture=i.createTexture(),r.memory.textures++)}if(T.samples>0&&me(T)===!1){k.__webglMultisampledFramebuffer=i.createFramebuffer(),k.__webglColorRenderbuffer=[],t.bindFramebuffer(i.FRAMEBUFFER,k.__webglMultisampledFramebuffer);for(let q=0;q<J.length;q++){const Y=J[q];k.__webglColorRenderbuffer[q]=i.createRenderbuffer(),i.bindRenderbuffer(i.RENDERBUFFER,k.__webglColorRenderbuffer[q]);const de=a.convert(Y.format,Y.colorSpace),C=a.convert(Y.type),Z=S(Y.internalFormat,de,C,Y.normalized,Y.colorSpace,T.isXRRenderTarget===!0),W=wt(T);i.renderbufferStorageMultisample(i.RENDERBUFFER,W,Z,T.width,T.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+q,i.RENDERBUFFER,k.__webglColorRenderbuffer[q])}i.bindRenderbuffer(i.RENDERBUFFER,null),T.depthBuffer&&(k.__webglDepthRenderbuffer=i.createRenderbuffer(),ri(k.__webglDepthRenderbuffer,T,!0)),t.bindFramebuffer(i.FRAMEBUFFER,null)}}if(le){t.bindTexture(i.TEXTURE_CUBE_MAP,ie.__webglTexture),rt(i.TEXTURE_CUBE_MAP,_);for(let q=0;q<6;q++)if(_.mipmaps.length>0)for(let Y=0;Y<_.mipmaps.length;Y++)St(k.__webglFramebuffer[q][Y],T,_,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+q,Y);else St(k.__webglFramebuffer[q],T,_,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+q,0);A(_)?b(i.TEXTURE_CUBE_MAP):_.mipmaps.length>0&&i.texParameteri(i.TEXTURE_CUBE_MAP,i.TEXTURE_MAX_LEVEL,_.mipmaps.length-1),t.unbindTexture()}else if(fe){for(let q=0,Y=J.length;q<Y;q++){const de=J[q],C=n.get(de);let Z=i.TEXTURE_2D;(T.isWebGL3DRenderTarget||T.isWebGLArrayRenderTarget)&&(Z=T.isWebGL3DRenderTarget?i.TEXTURE_3D:i.TEXTURE_2D_ARRAY),t.bindTexture(Z,C.__webglTexture),rt(Z,de),St(k.__webglFramebuffer,T,de,i.COLOR_ATTACHMENT0+q,Z,0),A(de)&&b(Z)}t.unbindTexture()}else{let q=i.TEXTURE_2D;if((T.isWebGL3DRenderTarget||T.isWebGLArrayRenderTarget)&&(q=T.isWebGL3DRenderTarget?i.TEXTURE_3D:i.TEXTURE_2D_ARRAY),t.bindTexture(q,ie.__webglTexture),rt(q,_),_.mipmaps.length>0)for(let Y=0;Y<_.mipmaps.length;Y++)St(k.__webglFramebuffer[Y],T,_,i.COLOR_ATTACHMENT0,q,Y);else St(k.__webglFramebuffer,T,_,i.COLOR_ATTACHMENT0,q,0);A(_)?b(q):_.mipmaps.length>0&&i.texParameteri(q,i.TEXTURE_MAX_LEVEL,_.mipmaps.length-1),t.unbindTexture()}T.depthBuffer&&Fn(T)}function U(T){const _=T.textures;for(let k=0,ie=_.length;k<ie;k++){const J=_[k];if(A(J)&&J.mipmapsAutoUpdate===!0){const le=E(T),fe=n.get(J).__webglTexture;t.bindTexture(le,fe),b(le),t.unbindTexture()}}}const Bn=[];function Mt(T){if(T.samples>0){if(me(T)===!1){const _=T.textures,k=T.width,ie=T.height;let J=i.COLOR_BUFFER_BIT;const le=T.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,fe=n.get(T),q=_.length>1;if(q)for(let de=0;de<_.length;de++)t.bindFramebuffer(i.FRAMEBUFFER,fe.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+de,i.RENDERBUFFER,null),t.bindFramebuffer(i.FRAMEBUFFER,fe.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+de,i.TEXTURE_2D,null,0);t.bindFramebuffer(i.READ_FRAMEBUFFER,fe.__webglMultisampledFramebuffer),T.texture.mipmaps.length>0?t.bindFramebuffer(i.DRAW_FRAMEBUFFER,fe.__webglFramebuffer[0]):t.bindFramebuffer(i.DRAW_FRAMEBUFFER,fe.__webglFramebuffer);for(let de=0;de<_.length;de++){if(T.resolveDepthBuffer&&(T.depthBuffer&&(J|=i.DEPTH_BUFFER_BIT),T.stencilBuffer&&T.resolveStencilBuffer&&(J|=i.STENCIL_BUFFER_BIT)),q){i.framebufferRenderbuffer(i.READ_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.RENDERBUFFER,fe.__webglColorRenderbuffer[de]);const C=n.get(_[de]).__webglTexture;i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,C,0)}i.blitFramebuffer(0,0,k,ie,0,0,k,ie,J,i.NEAREST),l===!0&&(Bn.length=0,Bn.push(i.COLOR_ATTACHMENT0+de),T.depthBuffer&&T.storeMultisampledDepthBuffer===!1&&Bn.push(le),i.invalidateFramebuffer(i.READ_FRAMEBUFFER,Bn))}if(t.bindFramebuffer(i.READ_FRAMEBUFFER,null),t.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),q)for(let de=0;de<_.length;de++){t.bindFramebuffer(i.FRAMEBUFFER,fe.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+de,i.RENDERBUFFER,fe.__webglColorRenderbuffer[de]);const C=n.get(_[de]).__webglTexture;t.bindFramebuffer(i.FRAMEBUFFER,fe.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+de,i.TEXTURE_2D,C,0)}t.bindFramebuffer(i.DRAW_FRAMEBUFFER,fe.__webglMultisampledFramebuffer)}else if(T.depthBuffer&&T.storeMultisampledDepthBuffer===!1&&l){const _=T.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT;i.invalidateFramebuffer(i.DRAW_FRAMEBUFFER,[_])}}}function wt(T){return Math.min(s.maxSamples,T.samples)}function me(T){const _=n.get(T);return T.samples>0&&e.has("WEBGL_multisampled_render_to_texture")===!0&&_.__useRenderToTexture!==!1}function kt(T){const _=r.render.frame;d.get(T)!==_&&(d.set(T,_),T.update())}function De(T,_){const k=T.colorSpace,ie=T.format,J=T.type;return T.isCompressedTexture===!0||T.isVideoTexture===!0||k!==mo&&k!==Ti&&(et.getTransfer(k)===lt?(ie!==hi||J!==wn)&&Ue("WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):it("WebGLTextures: Unsupported texture color space:",k)),_}function Oe(T){return typeof HTMLImageElement<"u"&&T instanceof HTMLImageElement?(c.width=T.naturalWidth||T.width,c.height=T.naturalHeight||T.height):typeof VideoFrame<"u"&&T instanceof VideoFrame?(c.width=T.displayWidth,c.height=T.displayHeight):(c.width=T.width,c.height=T.height),c}this.allocateTextureUnit=$e,this.resetTextureUnits=ee,this.getTextureUnits=ne,this.setTextureUnits=Ee,this.setTexture2D=ye,this.setTexture2DArray=Me,this.setTexture3D=Le,this.setTextureCube=xe,this.rebindTextures=On,this.setupRenderTarget=kn,this.updateRenderTargetMipmap=U,this.updateMultisampleRenderTarget=Mt,this.setupDepthRenderbuffer=Fn,this.setupFrameBufferTexture=St,this.useMultisampledRTT=me,this.dispose=z}function Tb(i,e){function t(n,s=Ti){let a;const r=et.getTransfer(s);if(n===wn)return i.UNSIGNED_BYTE;if(n===pd)return i.UNSIGNED_SHORT_4_4_4_4;if(n===md)return i.UNSIGNED_SHORT_5_5_5_1;if(n===_f)return i.UNSIGNED_INT_5_9_9_9_REV;if(n===Mf)return i.UNSIGNED_INT_10F_11F_11F_REV;if(n===xf)return i.BYTE;if(n===bf)return i.SHORT;if(n===Ga)return i.UNSIGNED_SHORT;if(n===fd)return i.INT;if(n===mi)return i.UNSIGNED_INT;if(n===ii)return i.FLOAT;if(n===gi)return i.HALF_FLOAT;if(n===wf)return i.ALPHA;if(n===Sf)return i.RGB;if(n===hi)return i.RGBA;if(n===ns)return i.DEPTH_COMPONENT;if(n===Ji)return i.DEPTH_STENCIL;if(n===gd)return i.RED;if(n===vd)return i.RED_INTEGER;if(n===ys)return i.RG;if(n===yd)return i.RG_INTEGER;if(n===xd)return i.RGBA_INTEGER;if(n===jr||n===Qr||n===eo||n===to)if(r===lt)if(a=e.get("WEBGL_compressed_texture_s3tc_srgb"),a!==null){if(n===jr)return a.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(n===Qr)return a.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(n===eo)return a.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(n===to)return a.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(a=e.get("WEBGL_compressed_texture_s3tc"),a!==null){if(n===jr)return a.COMPRESSED_RGB_S3TC_DXT1_EXT;if(n===Qr)return a.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(n===eo)return a.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(n===to)return a.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(n===dc||n===hc||n===uc||n===fc)if(a=e.get("WEBGL_compressed_texture_pvrtc"),a!==null){if(n===dc)return a.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(n===hc)return a.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(n===uc)return a.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(n===fc)return a.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(n===pc||n===mc||n===gc||n===vc||n===yc||n===uo||n===xc)if(a=e.get("WEBGL_compressed_texture_etc"),a!==null){if(n===pc||n===mc)return r===lt?a.COMPRESSED_SRGB8_ETC2:a.COMPRESSED_RGB8_ETC2;if(n===gc)return r===lt?a.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:a.COMPRESSED_RGBA8_ETC2_EAC;if(n===vc)return a.COMPRESSED_R11_EAC;if(n===yc)return a.COMPRESSED_SIGNED_R11_EAC;if(n===uo)return a.COMPRESSED_RG11_EAC;if(n===xc)return a.COMPRESSED_SIGNED_RG11_EAC}else return null;if(n===bc||n===_c||n===Mc||n===wc||n===Sc||n===Ec||n===Ac||n===Tc||n===Rc||n===Cc||n===Pc||n===Lc||n===Dc||n===Ic)if(a=e.get("WEBGL_compressed_texture_astc"),a!==null){if(n===bc)return r===lt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:a.COMPRESSED_RGBA_ASTC_4x4_KHR;if(n===_c)return r===lt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:a.COMPRESSED_RGBA_ASTC_5x4_KHR;if(n===Mc)return r===lt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:a.COMPRESSED_RGBA_ASTC_5x5_KHR;if(n===wc)return r===lt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:a.COMPRESSED_RGBA_ASTC_6x5_KHR;if(n===Sc)return r===lt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:a.COMPRESSED_RGBA_ASTC_6x6_KHR;if(n===Ec)return r===lt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:a.COMPRESSED_RGBA_ASTC_8x5_KHR;if(n===Ac)return r===lt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:a.COMPRESSED_RGBA_ASTC_8x6_KHR;if(n===Tc)return r===lt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:a.COMPRESSED_RGBA_ASTC_8x8_KHR;if(n===Rc)return r===lt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:a.COMPRESSED_RGBA_ASTC_10x5_KHR;if(n===Cc)return r===lt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:a.COMPRESSED_RGBA_ASTC_10x6_KHR;if(n===Pc)return r===lt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:a.COMPRESSED_RGBA_ASTC_10x8_KHR;if(n===Lc)return r===lt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:a.COMPRESSED_RGBA_ASTC_10x10_KHR;if(n===Dc)return r===lt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:a.COMPRESSED_RGBA_ASTC_12x10_KHR;if(n===Ic)return r===lt?a.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:a.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(n===Nc||n===Uc||n===Fc)if(a=e.get("EXT_texture_compression_bptc"),a!==null){if(n===Nc)return r===lt?a.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:a.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(n===Uc)return a.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(n===Fc)return a.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(n===Oc||n===kc||n===fo||n===Bc)if(a=e.get("EXT_texture_compression_rgtc"),a!==null){if(n===Oc)return a.COMPRESSED_RED_RGTC1_EXT;if(n===kc)return a.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(n===fo)return a.COMPRESSED_RED_GREEN_RGTC2_EXT;if(n===Bc)return a.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return n===aa?i.UNSIGNED_INT_24_8:i[n]!==void 0?i[n]:null}return{convert:t}}const Rb=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,Cb=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class Pb{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(e,t){if(this.texture===null){const n=new zf(e.texture);(e.depthNear!==t.depthNear||e.depthFar!==t.depthFar)&&(this.depthNear=e.depthNear,this.depthFar=e.depthFar),this.texture=n}}getMesh(e){if(this.texture!==null&&this.mesh===null){const t=e.cameras[0].viewport,n=new Pn({vertexShader:Rb,fragmentShader:Cb,uniforms:{depthColor:{value:this.texture},depthWidth:{value:t.z},depthHeight:{value:t.w}}});this.mesh=new Te(new Fi(20,20),n)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class Lb extends Ss{constructor(e,t){super();const n=this;let s=null,a=1,r=null,o="local-floor",l=1,c=null,d=null,h=null,u=null,f=null,g=null;const y=typeof XRWebGLBinding<"u",m=new Pb,p={},x=t.getContextAttributes();let A=null,b=null;const E=[],S=[],v=new Ie;let w=null,P=null;const R=new bn;R.viewport=new Tt;const N=new bn;N.viewport=new Tt;const F=[R,N],G=new G0;let L=null,z=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(K){let ye=E[K];return ye===void 0&&(ye=new bl,E[K]=ye),ye.getTargetRaySpace()},this.getControllerGrip=function(K){let ye=E[K];return ye===void 0&&(ye=new bl,E[K]=ye),ye.getGripSpace()},this.getHand=function(K){let ye=E[K];return ye===void 0&&(ye=new bl,E[K]=ye),ye.getHandSpace()};function X(K){const ye=S.indexOf(K.inputSource);if(ye===-1)return;const Me=E[ye];Me!==void 0&&(Me.update(K.inputSource,K.frame,c||r),Me.dispatchEvent({type:K.type,data:K.inputSource}))}function $(){s.removeEventListener("select",X),s.removeEventListener("selectstart",X),s.removeEventListener("selectend",X),s.removeEventListener("squeeze",X),s.removeEventListener("squeezestart",X),s.removeEventListener("squeezeend",X),s.removeEventListener("end",$),s.removeEventListener("inputsourceschange",te);for(let K=0;K<E.length;K++){const ye=S[K];ye!==null&&(S[K]=null,E[K].disconnect(ye))}L=null,z=null,m.reset();for(const K in p)delete p[K];if(e.setRenderTarget(A),f=null,u=null,h=null,s=null,b=null,$e.stop(),n.isPresenting=!1,e.setPixelRatio(w),e.setSize(v.width,v.height,!1),P!==null){const K=P.camera;K.fov=P.fov,K.zoom=P.zoom,K.updateProjectionMatrix(),P=null}n.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(K){a=K,n.isPresenting===!0&&Ue("WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(K){o=K,n.isPresenting===!0&&Ue("WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return c||r},this.setReferenceSpace=function(K){c=K},this.getBaseLayer=function(){return u!==null?u:f},this.getBinding=function(){return h===null&&y&&(h=new XRWebGLBinding(s,t)),h},this.getFrame=function(){return g},this.getSession=function(){return s},this.setSession=async function(K){if(s=K,s!==null){if(A=e.getRenderTarget(),s.addEventListener("select",X),s.addEventListener("selectstart",X),s.addEventListener("selectend",X),s.addEventListener("squeeze",X),s.addEventListener("squeezestart",X),s.addEventListener("squeezeend",X),s.addEventListener("end",$),s.addEventListener("inputsourceschange",te),x.xrCompatible!==!0&&await t.makeXRCompatible(),w=e.getPixelRatio(),e.getSize(v),y&&"createProjectionLayer"in XRWebGLBinding.prototype){let Me=null,Le=null,xe=null;x.depth&&(xe=x.stencil?t.DEPTH24_STENCIL8:t.DEPTH_COMPONENT24,Me=x.stencil?Ji:ns,Le=x.stencil?aa:mi);const Ge={colorFormat:t.RGBA8,depthFormat:xe,scaleFactor:a};h=this.getBinding(),u=h.createProjectionLayer(Ge),s.updateRenderState({layers:[u]}),e.setPixelRatio(1),e.setSize(u.textureWidth,u.textureHeight,!1),b=new Vn(u.textureWidth,u.textureHeight,{format:hi,type:wn,depthTexture:new oa(u.textureWidth,u.textureHeight,Le,void 0,void 0,void 0,void 0,void 0,void 0,Me),stencilBuffer:x.stencil,colorSpace:e.outputColorSpace,samples:x.antialias?4:0,resolveDepthBuffer:u.ignoreDepthValues===!1,resolveStencilBuffer:u.ignoreDepthValues===!1,storeMultisampledDepthBuffer:u.ignoreDepthValues===!1,storeMultisampledStencilBuffer:u.ignoreDepthValues===!1})}else{const Me={antialias:x.antialias,alpha:!0,depth:x.depth,stencil:x.stencil,framebufferScaleFactor:a};f=new XRWebGLLayer(s,t,Me),s.updateRenderState({baseLayer:f}),e.setPixelRatio(1),e.setSize(f.framebufferWidth,f.framebufferHeight,!1),b=new Vn(f.framebufferWidth,f.framebufferHeight,{format:hi,type:wn,colorSpace:e.outputColorSpace,stencilBuffer:x.stencil,resolveDepthBuffer:f.ignoreDepthValues===!1,resolveStencilBuffer:f.ignoreDepthValues===!1,storeMultisampledDepthBuffer:f.ignoreDepthValues===!1,storeMultisampledStencilBuffer:f.ignoreDepthValues===!1})}b.isXRRenderTarget=!0,this.setFoveation(l),c=null,r=await s.requestReferenceSpace(o),$e.setContext(s),$e.start(),n.isPresenting=!0,n.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(s!==null)return s.environmentBlendMode},this.getDepthTexture=function(){return m.getDepthTexture()};function te(K){for(let ye=0;ye<K.removed.length;ye++){const Me=K.removed[ye],Le=S.indexOf(Me);Le>=0&&(S[Le]=null,E[Le].disconnect(Me))}for(let ye=0;ye<K.added.length;ye++){const Me=K.added[ye];let Le=S.indexOf(Me);if(Le===-1){for(let Ge=0;Ge<E.length;Ge++)if(Ge>=S.length){S.push(Me),Le=Ge;break}else if(S[Ge]===null){S[Ge]=Me,Le=Ge;break}if(Le===-1)break}const xe=E[Le];xe&&xe.connect(Me)}}function V(K,ye){ye===null?K.matrixWorld.copy(K.matrix):K.matrixWorld.multiplyMatrices(ye.matrixWorld,K.matrix),K.matrixWorldInverse.copy(K.matrixWorld).invert()}this.updateCamera=function(K){if(s===null)return;let ye=K.near,Me=K.far;m.texture!==null&&(m.depthNear>0&&(ye=m.depthNear),m.depthFar>0&&(Me=m.depthFar)),G.near=N.near=R.near=ye,G.far=N.far=R.far=Me,(L!==G.near||z!==G.far)&&(s.updateRenderState({depthNear:G.near,depthFar:G.far}),L=G.near,z=G.far),G.layers.mask=K.layers.mask|6,R.layers.mask=G.layers.mask&-5,N.layers.mask=G.layers.mask&-3;const Le=K.parent,xe=G.cameras;V(G,Le);for(let Ge=0;Ge<xe.length;Ge++)V(xe[Ge],Le);G.projectionMatrix.copy(R.projectionMatrix),G.projectionMatrixInverse.copy(R.projectionMatrixInverse),P===null&&K.isPerspectiveCamera&&(P={camera:K,fov:K.fov,zoom:K.zoom}),ee(K,G,Le)};function ee(K,ye,Me){Me===null?K.matrix.copy(ye.matrixWorld):(K.matrix.copy(Me.matrixWorld),K.matrix.invert(),K.matrix.multiply(ye.matrixWorld)),K.matrix.decompose(K.position,K.quaternion,K.scale),K.updateMatrixWorld(!0),K.projectionMatrix.copy(ye.projectionMatrix),K.projectionMatrixInverse.copy(ye.projectionMatrixInverse),K.isPerspectiveCamera&&(K.fov=Wa*2*Math.atan(1/K.projectionMatrix.elements[5]),K.zoom=1)}this.getCamera=function(){return G},this.getFoveation=function(){if(!(u===null&&f===null))return l},this.setFoveation=function(K){l=K,u!==null&&(u.fixedFoveation=K),f!==null&&f.fixedFoveation!==void 0&&(f.fixedFoveation=K)},this.hasDepthSensing=function(){return m.texture!==null},this.getDepthSensingMesh=function(){return m.getMesh(G)},this.getCameraTexture=function(K){return p[K]};let ne=null;function Ee(K,ye){if(d=ye.getViewerPose(c||r),g=ye,d!==null){const Me=d.views;f!==null&&(e.setRenderTargetFramebuffer(b,f.framebuffer),e.setRenderTarget(b));let Le=!1;Me.length!==G.cameras.length&&(G.cameras.length=0,Le=!0);for(let Ne=0;Ne<Me.length;Ne++){const rt=Me[Ne];let ht=null;if(f!==null)ht=f.getViewport(rt);else{const jt=h.getViewSubImage(u,rt);ht=jt.viewport,Ne===0&&(e.setRenderTargetTextures(b,jt.colorTexture,jt.depthStencilTexture),e.setRenderTarget(b))}let Ke=F[Ne];Ke===void 0&&(Ke=new bn,Ke.layers.enable(Ne),Ke.viewport=new Tt,F[Ne]=Ke),Ke.matrix.fromArray(rt.transform.matrix),Ke.matrix.decompose(Ke.position,Ke.quaternion,Ke.scale),Ke.projectionMatrix.fromArray(rt.projectionMatrix),Ke.projectionMatrixInverse.copy(Ke.projectionMatrix).invert(),Ke.viewport.set(ht.x,ht.y,ht.width,ht.height),Ne===0&&(G.matrix.copy(Ke.matrix),G.matrix.decompose(G.position,G.quaternion,G.scale)),Le===!0&&G.cameras.push(Ke)}const xe=s.enabledFeatures;if(xe&&xe.includes("depth-sensing")&&s.depthUsage=="gpu-optimized"&&y){h=n.getBinding();const Ne=h.getDepthInformation(Me[0]);Ne&&Ne.isValid&&Ne.texture&&m.init(Ne,s.renderState)}if(xe&&xe.includes("camera-access")&&y){e.state.unbindTexture(),h=n.getBinding();for(let Ne=0;Ne<Me.length;Ne++){const rt=Me[Ne].camera;if(rt){let ht=p[rt];ht||(ht=new zf,p[rt]=ht);const Ke=h.getCameraImage(rt);ht.sourceTexture=Ke}}}}for(let Me=0;Me<E.length;Me++){const Le=S[Me],xe=E[Me];Le!==null&&xe!==void 0&&xe.update(Le,ye,c||r)}ne&&ne(K,ye),ye.detectedPlanes&&n.dispatchEvent({type:"planesdetected",data:ye}),g=null}const $e=new Yf;$e.setAnimationLoop(Ee),this.setAnimationLoop=function(K){ne=K},this.dispose=function(){}}}const Db=new tt,sp=new ke;sp.set(-1,0,0,0,1,0,0,0,1);function Ib(i,e){function t(m,p){m.matrixAutoUpdate===!0&&m.updateMatrix(),p.value.copy(m.matrix)}function n(m,p){p.color.getRGB(m.fogColor.value,$f(i)),p.isFog?(m.fogNear.value=p.near,m.fogFar.value=p.far):p.isFogExp2&&(m.fogDensity.value=p.density)}function s(m,p,x,A,b){p.isNodeMaterial?p.uniformsNeedUpdate=!1:p.isMeshBasicMaterial?a(m,p):p.isMeshLambertMaterial?(a(m,p),p.envMap&&(m.envMapIntensity.value=p.envMapIntensity)):p.isMeshToonMaterial?(a(m,p),h(m,p)):p.isMeshPhongMaterial?(a(m,p),d(m,p),p.envMap&&(m.envMapIntensity.value=p.envMapIntensity)):p.isMeshStandardMaterial?(a(m,p),u(m,p),p.isMeshPhysicalMaterial&&f(m,p,b)):p.isMeshMatcapMaterial?(a(m,p),g(m,p)):p.isMeshDepthMaterial?a(m,p):p.isMeshDistanceMaterial?(a(m,p),y(m,p)):p.isMeshNormalMaterial?a(m,p):p.isLineBasicMaterial?(r(m,p),p.isLineDashedMaterial&&o(m,p)):p.isPointsMaterial?l(m,p,x,A):p.isSpriteMaterial?c(m,p):p.isShadowMaterial?(m.color.value.copy(p.color),m.opacity.value=p.opacity):p.isShaderMaterial&&(p.uniformsNeedUpdate=!1)}function a(m,p){m.opacity.value=p.opacity,p.color&&m.diffuse.value.copy(p.color),p.emissive&&m.emissive.value.copy(p.emissive).multiplyScalar(p.emissiveIntensity),p.map&&(m.map.value=p.map,t(p.map,m.mapTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,t(p.alphaMap,m.alphaMapTransform)),p.bumpMap&&(m.bumpMap.value=p.bumpMap,t(p.bumpMap,m.bumpMapTransform),m.bumpScale.value=p.bumpScale,p.side===rn&&(m.bumpScale.value*=-1)),p.normalMap&&(m.normalMap.value=p.normalMap,t(p.normalMap,m.normalMapTransform),m.normalScale.value.copy(p.normalScale),p.side===rn&&m.normalScale.value.negate()),p.displacementMap&&(m.displacementMap.value=p.displacementMap,t(p.displacementMap,m.displacementMapTransform),m.displacementScale.value=p.displacementScale,m.displacementBias.value=p.displacementBias),p.emissiveMap&&(m.emissiveMap.value=p.emissiveMap,t(p.emissiveMap,m.emissiveMapTransform)),p.specularMap&&(m.specularMap.value=p.specularMap,t(p.specularMap,m.specularMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest);const x=e.get(p),A=x.envMap,b=x.envMapRotation;A&&(m.envMap.value=A,m.envMapRotation.value.setFromMatrix4(Db.makeRotationFromEuler(b)).transpose(),A.isCubeTexture&&A.isRenderTargetTexture===!1&&m.envMapRotation.value.premultiply(sp),m.reflectivity.value=p.reflectivity,m.ior.value=p.ior,m.refractionRatio.value=p.refractionRatio),p.lightMap&&(m.lightMap.value=p.lightMap,m.lightMapIntensity.value=p.lightMapIntensity,t(p.lightMap,m.lightMapTransform)),p.aoMap&&(m.aoMap.value=p.aoMap,m.aoMapIntensity.value=p.aoMapIntensity,t(p.aoMap,m.aoMapTransform))}function r(m,p){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,p.map&&(m.map.value=p.map,t(p.map,m.mapTransform))}function o(m,p){m.dashSize.value=p.dashSize,m.totalSize.value=p.dashSize+p.gapSize,m.scale.value=p.scale}function l(m,p,x,A){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,m.size.value=p.size*x,m.scale.value=A*.5,p.map&&(m.map.value=p.map,t(p.map,m.uvTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,t(p.alphaMap,m.alphaMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest)}function c(m,p){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,m.rotation.value=p.rotation,p.map&&(m.map.value=p.map,t(p.map,m.mapTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,t(p.alphaMap,m.alphaMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest)}function d(m,p){m.specular.value.copy(p.specular),m.shininess.value=Math.max(p.shininess,1e-4)}function h(m,p){p.gradientMap&&(m.gradientMap.value=p.gradientMap)}function u(m,p){m.metalness.value=p.metalness,p.metalnessMap&&(m.metalnessMap.value=p.metalnessMap,t(p.metalnessMap,m.metalnessMapTransform)),m.roughness.value=p.roughness,p.roughnessMap&&(m.roughnessMap.value=p.roughnessMap,t(p.roughnessMap,m.roughnessMapTransform)),p.envMap&&(m.envMapIntensity.value=p.envMapIntensity)}function f(m,p,x){m.ior.value=p.ior,p.diffuseRoughness>0&&(m.diffuseRoughness.value=p.diffuseRoughness,p.diffuseRoughnessMap&&(m.diffuseRoughnessMap.value=p.diffuseRoughnessMap,t(p.diffuseRoughnessMap,m.diffuseRoughnessMapTransform))),p.sheen>0&&(m.sheenColor.value.copy(p.sheenColor).multiplyScalar(p.sheen),m.sheenRoughness.value=p.sheenRoughness,p.sheenColorMap&&(m.sheenColorMap.value=p.sheenColorMap,t(p.sheenColorMap,m.sheenColorMapTransform)),p.sheenRoughnessMap&&(m.sheenRoughnessMap.value=p.sheenRoughnessMap,t(p.sheenRoughnessMap,m.sheenRoughnessMapTransform))),p.clearcoat>0&&(m.clearcoat.value=p.clearcoat,m.clearcoatRoughness.value=p.clearcoatRoughness,p.clearcoatMap&&(m.clearcoatMap.value=p.clearcoatMap,t(p.clearcoatMap,m.clearcoatMapTransform)),p.clearcoatRoughnessMap&&(m.clearcoatRoughnessMap.value=p.clearcoatRoughnessMap,t(p.clearcoatRoughnessMap,m.clearcoatRoughnessMapTransform)),p.clearcoatNormalMap&&(m.clearcoatNormalMap.value=p.clearcoatNormalMap,t(p.clearcoatNormalMap,m.clearcoatNormalMapTransform),m.clearcoatNormalScale.value.copy(p.clearcoatNormalScale),p.side===rn&&m.clearcoatNormalScale.value.negate())),p.dispersion>0&&(m.dispersion.value=p.dispersion),p.retroreflectivity>0&&(m.retroreflectivity.value=p.retroreflectivity),p.iridescence>0&&(m.iridescence.value=p.iridescence,m.iridescenceIOR.value=p.iridescenceIOR,m.iridescenceThicknessMinimum.value=p.iridescenceThicknessMinimum,m.iridescenceThicknessMaximum.value=p.iridescenceThicknessMaximum,p.iridescenceMap&&(m.iridescenceMap.value=p.iridescenceMap,t(p.iridescenceMap,m.iridescenceMapTransform)),p.iridescenceThicknessMap&&(m.iridescenceThicknessMap.value=p.iridescenceThicknessMap,t(p.iridescenceThicknessMap,m.iridescenceThicknessMapTransform))),p.transmission>0&&(m.transmission.value=p.transmission,m.transmissionSamplerMap.value=x.texture,m.transmissionSamplerSize.value.set(x.width,x.height),p.transmissionMap&&(m.transmissionMap.value=p.transmissionMap,t(p.transmissionMap,m.transmissionMapTransform)),m.thickness.value=p.thickness,p.thicknessMap&&(m.thicknessMap.value=p.thicknessMap,t(p.thicknessMap,m.thicknessMapTransform)),m.attenuationDistance.value=p.attenuationDistance,m.attenuationColor.value.copy(p.attenuationColor)),p.anisotropy>0&&(m.anisotropyVector.value.set(p.anisotropy*Math.cos(p.anisotropyRotation),p.anisotropy*Math.sin(p.anisotropyRotation)),p.anisotropyMap&&(m.anisotropyMap.value=p.anisotropyMap,t(p.anisotropyMap,m.anisotropyMapTransform))),m.specularIntensity.value=p.specularIntensity,m.specularColor.value.copy(p.specularColor),p.specularColorMap&&(m.specularColorMap.value=p.specularColorMap,t(p.specularColorMap,m.specularColorMapTransform)),p.specularIntensityMap&&(m.specularIntensityMap.value=p.specularIntensityMap,t(p.specularIntensityMap,m.specularIntensityMapTransform))}function g(m,p){p.matcap&&(m.matcap.value=p.matcap)}function y(m,p){const x=e.get(p).light;m.referencePosition.value.setFromMatrixPosition(x.matrixWorld),m.nearDistance.value=x.shadow.camera.near,m.farDistance.value=x.shadow.camera.far}return{refreshFogUniforms:n,refreshMaterialUniforms:s}}function Nb(i,e,t,n){let s={},a={};function r(x,A){const b=A.program;n.uniformBlockBinding(x,b,s[x.id])}function o(x,A){let b=s[x.id];b===void 0&&(g(x),b=l(x),s[x.id]=b,x.addEventListener("dispose",m));const E=A.program;n.updateUBOMapping(x,E);const S=e.render.frame;a[x.id]!==S&&(c(x),a[x.id]=S)}function l(x){const A=i.createBuffer(),b=x.__size,E=x.usage;return i.bindBuffer(i.UNIFORM_BUFFER,A),i.bufferData(i.UNIFORM_BUFFER,b,E),i.bindBuffer(i.UNIFORM_BUFFER,null),A}function c(x){const A=s[x.id],b=x.uniforms,E=x.__cache;i.bindBuffer(i.UNIFORM_BUFFER,A);for(let S=0,v=b.length;S<v;S++){const w=b[S];if(Array.isArray(w))for(let P=0,R=w.length;P<R;P++)d(w[P],S,P,E);else d(w,S,0,E)}i.bindBuffer(i.UNIFORM_BUFFER,null)}function d(x,A,b,E){if(u(x,A,b,E)===!0){const S=x.__offset,v=x.value;if(Array.isArray(v)){let w=0;for(let P=0;P<v.length;P++){const R=v[P],N=y(R,!0);h(R,x.__data,w),w+=N.storage/Float32Array.BYTES_PER_ELEMENT}}else h(v,x.__data,0);i.bufferSubData(i.UNIFORM_BUFFER,S,x.__data)}}function h(x,A,b){typeof x=="number"||typeof x=="boolean"?A[b]=x:x.isMatrix3?(A[b]=x.elements[0],A[b+1]=x.elements[1],A[b+2]=x.elements[2],A[b+3]=0,A[b+4]=x.elements[3],A[b+5]=x.elements[4],A[b+6]=x.elements[5],A[b+7]=0,A[b+8]=x.elements[6],A[b+9]=x.elements[7],A[b+10]=x.elements[8],A[b+11]=0):ArrayBuffer.isView(x)?A.set(x.subarray(0,A.length-b),b):x.toArray(A,b)}function u(x,A,b,E){const S=x.value,v=A+"_"+b;if(Array.isArray(S)){E[v]===void 0&&(E[v]=[]);const w=E[v];let P=!1;for(let R=0;R<S.length;R++)f(S[R],w,R)===!0&&(P=!0);return P}return f(S,E,v)}function f(x,A,b){if(A[b]===void 0)return typeof x=="number"||typeof x=="boolean"?A[b]=x:ArrayBuffer.isView(x)?A[b]=x.slice():A[b]=x.clone(),!0;{const E=A[b];if(typeof x=="number"||typeof x=="boolean"){if(E!==x)return A[b]=x,!0}else{if(ArrayBuffer.isView(x))return!0;if(E.equals(x)===!1)return E.copy(x),!0}}return!1}function g(x){const A=x.uniforms;let b=0;const E=16;for(let v=0,w=A.length;v<w;v++){const P=Array.isArray(A[v])?A[v]:[A[v]];for(let R=0,N=P.length;R<N;R++){const F=P[R],G=Array.isArray(F.value)?F.value:[F.value],L=Array.isArray(A[v])||Array.isArray(F.value);let z=b;for(let $=0,te=G.length;$<te;$++){const V=G[$],ee=y(V,L),ne=b%E,Ee=ne%ee.boundary,$e=ne+Ee;b+=Ee,$e!==0&&E-$e<ee.storage&&(b+=E-$e),$===0&&(z=b),b+=ee.storage}const X=F.type==="int"?Int32Array:F.type==="uint"?Uint32Array:Float32Array;F.__data=new X((b-z)/Float32Array.BYTES_PER_ELEMENT),F.__offset=z}}const S=b%E;return S>0&&(b+=E-S),x.__size=b,x.__cache={},this}function y(x,A){const b={boundary:0,storage:0};return typeof x=="number"||typeof x=="boolean"?(b.boundary=4,b.storage=4):x.isVector2?(b.boundary=8,b.storage=8):x.isVector3||x.isColor?(b.boundary=16,b.storage=12):x.isVector4?(b.boundary=16,b.storage=16):x.isMatrix3?(b.boundary=16,b.storage=48):x.isMatrix4?(b.boundary=16,b.storage=64):x.isTexture?Ue("WebGLRenderer: Texture samplers can not be part of an uniforms group."):ArrayBuffer.isView(x)?(b.boundary=16,b.storage=x.byteLength):Ue("WebGLRenderer: Unsupported uniform value type.",x),A===!0&&(b.boundary=16,b.storage=Math.ceil(b.storage/16)*16),b}function m(x){const A=x.target;A.removeEventListener("dispose",m),i.deleteBuffer(s[A.id]),delete s[A.id],delete a[A.id]}function p(){for(const x in s)i.deleteBuffer(s[x]);s={},a={}}return{bind:r,update:o,dispose:p}}const Ub=new Uint16Array([12469,15057,12620,14925,13266,14620,13807,14376,14323,13990,14545,13625,14713,13328,14840,12882,14931,12528,14996,12233,15039,11829,15066,11525,15080,11295,15085,10976,15082,10705,15073,10495,13880,14564,13898,14542,13977,14430,14158,14124,14393,13732,14556,13410,14702,12996,14814,12596,14891,12291,14937,11834,14957,11489,14958,11194,14943,10803,14921,10506,14893,10278,14858,9960,14484,14039,14487,14025,14499,13941,14524,13740,14574,13468,14654,13106,14743,12678,14818,12344,14867,11893,14889,11509,14893,11180,14881,10751,14852,10428,14812,10128,14765,9754,14712,9466,14764,13480,14764,13475,14766,13440,14766,13347,14769,13070,14786,12713,14816,12387,14844,11957,14860,11549,14868,11215,14855,10751,14825,10403,14782,10044,14729,9651,14666,9352,14599,9029,14967,12835,14966,12831,14963,12804,14954,12723,14936,12564,14917,12347,14900,11958,14886,11569,14878,11247,14859,10765,14828,10401,14784,10011,14727,9600,14660,9289,14586,8893,14508,8533,15111,12234,15110,12234,15104,12216,15092,12156,15067,12010,15028,11776,14981,11500,14942,11205,14902,10752,14861,10393,14812,9991,14752,9570,14682,9252,14603,8808,14519,8445,14431,8145,15209,11449,15208,11451,15202,11451,15190,11438,15163,11384,15117,11274,15055,10979,14994,10648,14932,10343,14871,9936,14803,9532,14729,9218,14645,8742,14556,8381,14461,8020,14365,7603,15273,10603,15272,10607,15267,10619,15256,10631,15231,10614,15182,10535,15118,10389,15042,10167,14963,9787,14883,9447,14800,9115,14710,8665,14615,8318,14514,7911,14411,7507,14279,7198,15314,9675,15313,9683,15309,9712,15298,9759,15277,9797,15229,9773,15166,9668,15084,9487,14995,9274,14898,8910,14800,8539,14697,8234,14590,7790,14479,7409,14367,7067,14178,6621,15337,8619,15337,8631,15333,8677,15325,8769,15305,8871,15264,8940,15202,8909,15119,8775,15022,8565,14916,8328,14804,8009,14688,7614,14569,7287,14448,6888,14321,6483,14088,6171,15350,7402,15350,7419,15347,7480,15340,7613,15322,7804,15287,7973,15229,8057,15148,8012,15046,7846,14933,7611,14810,7357,14682,7069,14552,6656,14421,6316,14251,5948,14007,5528,15356,5942,15356,5977,15353,6119,15348,6294,15332,6551,15302,6824,15249,7044,15171,7122,15070,7050,14949,6861,14818,6611,14679,6349,14538,6067,14398,5651,14189,5311,13935,4958,15359,4123,15359,4153,15356,4296,15353,4646,15338,5160,15311,5508,15263,5829,15188,6042,15088,6094,14966,6001,14826,5796,14678,5543,14527,5287,14377,4985,14133,4586,13869,4257,15360,1563,15360,1642,15358,2076,15354,2636,15341,3350,15317,4019,15273,4429,15203,4732,15105,4911,14981,4932,14836,4818,14679,4621,14517,4386,14359,4156,14083,3795,13808,3437,15360,122,15360,137,15358,285,15355,636,15344,1274,15322,2177,15281,2765,15215,3223,15120,3451,14995,3569,14846,3567,14681,3466,14511,3305,14344,3121,14037,2800,13753,2467,15360,0,15360,1,15359,21,15355,89,15346,253,15325,479,15287,796,15225,1148,15133,1492,15008,1749,14856,1882,14685,1886,14506,1783,14324,1608,13996,1398,13702,1183]);let li=null;function Fb(){return li===null&&(li=new Ff(Ub,16,16,ys,gi),li.name="DFG_LUT",li.minFilter=vn,li.magFilter=vn,li.wrapS=Pi,li.wrapT=Pi,li.generateMipmaps=!1,li.needsUpdate=!0),li}class Ob{constructor(e={}){const{canvas:t=Wm(),context:n=null,depth:s=!0,stencil:a=!1,alpha:r=!1,antialias:o=!1,premultipliedAlpha:l=!0,preserveDrawingBuffer:c=!1,powerPreference:d="default",failIfMajorPerformanceCaveat:h=!1,reversedDepthBuffer:u=!1,outputBufferType:f=wn}=e;this.isWebGLRenderer=!0;let g;if(n!==null){if(typeof WebGLRenderingContext<"u"&&n instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");g=n.getContextAttributes().alpha}else g=r;const y=f,m=new Set([xd,yd,vd]),p=new Set([wn,mi,Ga,aa,pd,md]),x=new Uint32Array(4),A=new Int32Array(4),b={textures:[],min:[],max:[],resolution:[]};let E=null,S=null;const v=[],w=[];let P=null;this.domElement=t,this.debug={checkShaderErrors:!0,diagnostics:{keywords:!1},onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=Ii,this.toneMappingExposure=1,this.transmissionResolutionScale=1;const R=this;let N=!1,F=null,G=null,L=null,z=null;this._outputColorSpace=zt;let X=0,$=0,te=null,V=-1,ee=null;const ne=new Tt,Ee=new Tt;let $e=null;const K=new Ce(0);let ye=0,Me=t.width,Le=t.height,xe=1,Ge=null,Lt=null;const Ne=new Tt(0,0,Me,Le),rt=new Tt(0,0,Me,Le);let ht=!1;const Ke=new Xa,jt=new Ed;let Ot=!1,xn=!1;const St=new tt,ri=new D,Wt=new Tt,Fn={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let On=!1;function kn(){return te===null?xe:1}let U=n;function Bn(M,I){return t.getContext(M,I)}let Mt,wt,me,kt,De,Oe,T,_,k,ie,J,le,fe,q,Y,de,C,Z,W,he,oe,ce,Re;try{const M={alpha:!0,depth:s,stencil:a,antialias:o,premultipliedAlpha:l,preserveDrawingBuffer:c,powerPreference:d,failIfMajorPerformanceCaveat:h};if("setAttribute"in t&&t.setAttribute("data-engine",`three.js r${dd}`),t.addEventListener("webglcontextlost",Pe,!1),t.addEventListener("webglcontextrestored",Ve,!1),t.addEventListener("webglcontextcreationerror",ge,!1),U===null){const I="webgl2";if(U=Bn(I,M),U===null)throw Bn(I)?new Error("THREE.WebGLRenderer: Error creating WebGL context with your selected attributes."):new Error("THREE.WebGLRenderer: Error creating WebGL context.")}Xe()}catch(M){throw t.removeEventListener("webglcontextlost",Pe,!1),t.removeEventListener("webglcontextrestored",Ve,!1),t.removeEventListener("webglcontextcreationerror",ge,!1),it("WebGLRenderer: "+M.message),M}function Xe(){Mt=new zy(U),Mt.init(),oe=new Tb(U,Mt),wt=new Cy(U,Mt,e,oe),me=new Eb(U,Mt),wt.reversedDepthBuffer&&u&&me.buffers.depth.setReversed(!0),G=U.createFramebuffer(),L=U.createFramebuffer(),z=U.createFramebuffer(),kt=new Gy(U),De=new hb,Oe=new Ab(U,Mt,me,De,wt,oe,kt),T=new By(R),_=new W0(U),ce=new Ty(U,_),k=new $y(U,_,kt,ce),ie=new Wy(U,k,_,ce,kt),Z=new Vy(U,wt,Oe),Y=new Py(De),J=new db(R,T,Mt,wt,ce,Y),le=new Ib(R,De),fe=new fb,q=new xb(Mt),C=new Ay(R,T,me,ie,g,l),de=new Sb(R,ie,wt),Re=new Nb(U,kt,wt,me),W=new Ry(U,Mt,kt),he=new Hy(U,Mt,kt),kt.programs=J.programs,R.capabilities=wt,R.extensions=Mt,R.properties=De,R.renderLists=fe,R.shadowMap=de,R.state=me,R.info=kt}y!==wn&&(P=new qy(y,t.width,t.height,o,s,a));const ae=new Lb(R,U);this.xr=ae,this.getContext=function(){return U},this.getContextAttributes=function(){return U.getContextAttributes()},this.forceContextLoss=function(){const M=Mt.get("WEBGL_lose_context");M&&M.loseContext()},this.forceContextRestore=function(){const M=Mt.get("WEBGL_lose_context");M&&M.restoreContext()},this.getPixelRatio=function(){return xe},this.setPixelRatio=function(M){M!==void 0&&(xe=M,this.setSize(Me,Le,!1))},this.getSize=function(M){return M.set(Me,Le)},this.setSize=function(M,I,H=!0){if(ae.isPresenting){Ue("WebGLRenderer: Can't change size while VR device is presenting.");return}Me=M,Le=I,t.width=Math.floor(M*xe),t.height=Math.floor(I*xe),H===!0&&(t.style.width=M+"px",t.style.height=I+"px"),P!==null&&P.setSize(t.width,t.height),this.setViewport(0,0,M,I)},this.getDrawingBufferSize=function(M){return M.set(Me*xe,Le*xe).floor()},this.setDrawingBufferSize=function(M,I,H){Me=M,Le=I,xe=H,t.width=Math.floor(M*H),t.height=Math.floor(I*H),this.setViewport(0,0,M,I)},this.setEffects=function(M){if(y===wn){it("WebGLRenderer: setEffects() requires outputBufferType set to HalfFloatType or FloatType.");return}if(M){for(let I=0;I<M.length;I++)if(M[I].isOutputPass===!0){Ue("WebGLRenderer: OutputPass is not needed in setEffects(). Tone mapping and color space conversion are applied automatically.");break}}P.setEffects(M||[])},this.getCurrentViewport=function(M){return M.copy(ne)},this.getViewport=function(M){return M.copy(Ne)},this.setViewport=function(M,I,H,O){M.isVector4?Ne.set(M.x,M.y,M.z,M.w):Ne.set(M,I,H,O),me.viewport(ne.copy(Ne).multiplyScalar(kn()).round())},this.getScissor=function(M){return M.copy(rt)},this.setScissor=function(M,I,H,O){M.isVector4?rt.set(M.x,M.y,M.z,M.w):rt.set(M,I,H,O),me.scissor(Ee.copy(rt).multiplyScalar(kn()).round())},this.getScissorTest=function(){return ht},this.setScissorTest=function(M){me.setScissorTest(ht=M)},this.setOpaqueSort=function(M){Ge=M},this.setTransparentSort=function(M){Lt=M},this.getClearColor=function(M){return M.copy(C.getClearColor())},this.setClearColor=function(){C.setClearColor(...arguments)},this.getClearAlpha=function(){return C.getClearAlpha()},this.setClearAlpha=function(){C.setClearAlpha(...arguments)},this.clear=function(M=!0,I=!0,H=!0){let O=0;if(M){let B=!1;if(te!==null){const pe=te.texture.format;B=m.has(pe)}if(B){const pe=te.texture.type,_e=p.has(pe),ue=C.getClearColor(),be=C.getClearAlpha(),Ae=ue.r,He=ue.g,Ze=ue.b;_e?(x[0]=Ae,x[1]=He,x[2]=Ze,x[3]=be,U.clearBufferuiv(U.COLOR,0,x)):(A[0]=Ae,A[1]=He,A[2]=Ze,A[3]=be,U.clearBufferiv(U.COLOR,0,A))}else O|=U.COLOR_BUFFER_BIT}I&&(O|=U.DEPTH_BUFFER_BIT,this.state.buffers.depth.setMask(!0)),H&&(O|=U.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),O!==0&&U.clear(O)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.setNodesHandler=function(M){M.setRenderer(this),F=M},this.dispose=function(){t.removeEventListener("webglcontextlost",Pe,!1),t.removeEventListener("webglcontextrestored",Ve,!1),t.removeEventListener("webglcontextcreationerror",ge,!1),C.dispose(),fe.dispose(),q.dispose(),Oe.dispose(),De.dispose(),T.dispose(),ie.dispose(),k.dispose(),ce.dispose(),Re.dispose(),J.dispose(),ae.dispose(),ae.removeEventListener("sessionstart",zd),ae.removeEventListener("sessionend",$d),rs.stop()};function Pe(M){M.preventDefault(),yo("WebGLRenderer: Context Lost."),N=!0}function Ve(){yo("WebGLRenderer: Context Restored."),N=!1;const M=kt.autoReset,I=de.enabled,H=de.autoUpdate,O=de.needsUpdate,B=de.type;Xe(),kt.autoReset=M,de.enabled=I,de.autoUpdate=H,de.needsUpdate=O,de.type=B}function ge(M){it("WebGLRenderer: A WebGL context could not be created. Reason: ",M.statusMessage)}function ot(M){const I=M.target;I.removeEventListener("dispose",ot),Xt(I)}function Xt(M){ki(M),De.remove(M)}function ki(M){const I=De.get(M).programs;I!==void 0&&(I.forEach(function(H){J.releaseProgram(H)}),M.isShaderMaterial&&J.releaseShaderCache(M))}this.renderBufferDirect=function(M,I,H,O,B,pe){I===null&&(I=Fn);const _e=B.isMesh&&B.matrixWorld.determinantAffine()<0,ue=Ip(M,I,H,O,B);me.setMaterial(O,_e);let be=H.index,Ae=1;if(O.wireframe===!0){if(be=k.getWireframeAttribute(H),be===void 0)return;Ae=2}const He=H.drawRange,Ze=H.attributes.position;let we=He.start*Ae,Je=(He.start+He.count)*Ae;pe!==null&&(we=Math.max(we,pe.start*Ae),Je=Math.min(Je,(pe.start+pe.count)*Ae)),be!==null?(we=Math.max(we,0),Je=Math.min(Je,be.count)):Ze!=null&&(we=Math.max(we,0),Je=Math.min(Je,Ze.count));const Dt=Je-we;if(Dt<0||Dt===1/0)return;ce.setup(B,O,ue,H,be);let mt,ut=W;if(be!==null&&(mt=_.get(be),ut=he,ut.setIndex(mt)),B.isMesh)O.wireframe===!0?(me.setLineWidth(O.wireframeLinewidth*kn()),ut.setMode(U.LINES)):ut.setMode(U.TRIANGLES);else if(B.isLine){let on=O.linewidth;on===void 0&&(on=1),me.setLineWidth(on*kn()),B.isLineSegments?ut.setMode(U.LINES):B.isLineLoop?ut.setMode(U.LINE_LOOP):ut.setMode(U.LINE_STRIP)}else B.isPoints?ut.setMode(U.POINTS):B.isSprite&&ut.setMode(U.TRIANGLES);if(B.isBatchedMesh)if(Mt.get("WEBGL_multi_draw"))ut.renderMultiDraw(B._multiDrawStarts,B._multiDrawCounts,B._multiDrawCount);else{const on=B._multiDrawStarts,Se=B._multiDrawCounts,fn=B._multiDrawCount,at=be?_.get(be).bytesPerElement:1,os=De.get(O).currentProgram.getUniforms();for(let ln=0;ln<fn;ln++)os.setValue(U,"_gl_DrawID",ln),ut.render(on[ln]/at,Se[ln])}else if(B.isInstancedMesh)ut.renderInstances(we,Dt,B.count);else if(H.isInstancedBufferGeometry){const on=H._maxInstanceCount!==void 0?H._maxInstanceCount:1/0,Se=Math.min(H.instanceCount,on);ut.renderInstances(we,Dt,Se)}else ut.render(we,Dt)};function Bd(M,I,H,O){F!==null&&M.isNodeMaterial&&F.setObject(O,M),Ot===!0&&Y.setState(M,H,!1),M.transparent===!0&&M.side===Mn&&M.forceSinglePass===!1?(M.side=rn,M.needsUpdate=!0,ua(M,I,O),M.side=vs,M.needsUpdate=!0,ua(M,I,O),M.side=Mn):ua(M,I,O)}this.compile=function(M,I,H=null){H===null&&(H=M),F!==null&&F.renderStart(M,I,H),S=q.get(H),S.init(I),w.push(S),H.traverseVisible(function(B){B.isLight&&B.layers.test(I.layers)&&(S.pushLight(B),B.castShadow&&S.pushShadow(B))}),M!==H&&M.traverseVisible(function(B){B.isLight&&B.layers.test(I.layers)&&(S.pushLight(B),B.castShadow&&S.pushShadow(B))}),S.setupLights(),F!==null&&F.updateLights(S.state.lightsArray),xn=this.localClippingEnabled,Ot=Y.init(this.clippingPlanes,xn),Ot===!0&&Y.setGlobalState(this.clippingPlanes,I),F!==null&&de.render(S.state.shadowsArray,H,I);const O=new Set;return M.traverse(function(B){if(!(B.isMesh||B.isPoints||B.isLine||B.isSprite))return;const pe=B.material;if(pe)if(Array.isArray(pe))for(let _e=0;_e<pe.length;_e++){const ue=pe[_e];Bd(ue,H,I,B),O.add(ue)}else Bd(pe,H,I,B),O.add(pe)}),S=w.pop(),F!==null&&F.renderEnd(),O},this.compileAsync=function(M,I,H=null){const O=this.compile(M,I,H);return new Promise(B=>{function pe(){if(O.forEach(function(_e){const be=De.get(_e).currentProgram;(be===void 0||be.isReady())&&O.delete(_e)}),O.size===0){B(M);return}setTimeout(pe,10)}Mt.get("KHR_parallel_shader_compile")!==null?pe():setTimeout(pe,10)})};let ll=null;function Lp(M){ll&&ll(M)}function zd(){rs.stop()}function $d(){rs.start()}const rs=new Yf;rs.setAnimationLoop(Lp),typeof self<"u"&&rs.setContext(self),this.setAnimationLoop=function(M){ll=M,ae.setAnimationLoop(M),M===null?rs.stop():rs.start()},ae.addEventListener("sessionstart",zd),ae.addEventListener("sessionend",$d),this.render=function(M,I){if(I!==void 0&&I.isCamera!==!0){it("WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(N===!0)return;F!==null&&F.renderStart(M,I);const H=ae.enabled===!0&&ae.isPresenting===!0,O=P!==null&&(te===null||H)&&P.begin(R,te);if(M.matrixWorldAutoUpdate===!0&&M.updateMatrixWorld(),I.parent===null&&I.matrixWorldAutoUpdate===!0&&I.updateMatrixWorld(),ae.enabled===!0&&ae.isPresenting===!0&&(P===null||P.isCompositing()===!1)&&(ae.cameraAutoUpdate===!0&&ae.updateCamera(I),I=ae.getCamera()),M.isScene===!0&&M.onBeforeRender(R,M,I,te),S=q.get(M,w.length),S.init(I),S.state.textureUnits=Oe.getTextureUnits(),w.push(S),St.multiplyMatrices(I.projectionMatrix,I.matrixWorldInverse),I.isArrayCamera?jt.setFromArrayCamera(I):Ke.setFromProjectionMatrix(St,si,I.reversedDepth),xn=this.localClippingEnabled,Ot=Y.init(this.clippingPlanes,xn),E=fe.get(M,v.length),E.init(),v.push(E),this.info.render.frame++,ae.enabled===!0&&ae.isPresenting===!0){const _e=R.xr.getDepthSensingMesh();_e!==null&&cl(_e,I,-1/0,R.sortObjects)}cl(M,I,0,R.sortObjects),E.finish(),F!==null&&F.updateLights(S.state.lightsArray),R.sortObjects===!0&&E.sort(Ge,Lt),On=ae.enabled===!1||ae.isPresenting===!1||ae.hasDepthSensing()===!1,On&&C.addToRenderList(E,M),this.info.autoReset===!0&&this.info.reset(),Ot===!0&&Y.beginShadows();const B=S.state.shadowsArray;if(de.render(B,M,I),Ot===!0&&Y.endShadows(),(O&&P.hasRenderPass())===!1){const _e=E.opaque,ue=E.transmissive;if(S.setupLights(),I.isArrayCamera){const be=I.cameras;if(ue.length>0)for(let Ae=0,He=be.length;Ae<He;Ae++){const Ze=be[Ae];Gd(_e,ue,M,Ze)}On&&C.render(M);for(let Ae=0,He=be.length;Ae<He;Ae++){const Ze=be[Ae];Hd(E,M,Ze,Ze.viewport)}}else ue.length>0&&Gd(_e,ue,M,I),On&&C.render(M),Hd(E,M,I)}te!==null&&$===0&&(Oe.updateMultisampleRenderTarget(te),Oe.updateRenderTargetMipmap(te)),O&&P.end(R),M.isScene===!0&&M.onAfterRender(R,M,I),ce.resetDefaultState(),V=-1,ee=null,w.pop(),w.length>0?(S=w[w.length-1],Oe.setTextureUnits(S.state.textureUnits),Ot===!0&&Y.setGlobalState(R.clippingPlanes,S.state.camera)):S=null,v.pop(),v.length>0?E=v[v.length-1]:E=null,F!==null&&F.renderEnd()};function cl(M,I,H,O){if(M.visible===!1)return;if(M.layers.test(I.layers)){if(M.isGroup)H=M.renderOrder;else if(M.isLOD)M.autoUpdate===!0&&M.update(I);else if(M.isLight)S.pushLight(M),M.castShadow&&S.pushShadow(M);else if(M.isSprite){const _e=I.isArrayCamera?jt:Ke;if(!M.frustumCulled||M.intersectsFrustum(_e)){O&&Wt.setFromMatrixPosition(M.matrixWorld).applyMatrix4(St);const ue=ie.update(M),be=M.material;be.visible&&E.push(M,ue,be,H,Wt.z,null,I)}}else if(M.isMesh||M.isLine||M.isPoints){const _e=I.isArrayCamera?jt:Ke;if(!M.frustumCulled||M.intersectsFrustum(_e)){const ue=ie.update(M),be=M.material;if(O&&(M.boundingSphere!==void 0?(M.boundingSphere===null&&M.computeBoundingSphere(),Wt.copy(M.boundingSphere.center)):(ue.boundingSphere===null&&ue.computeBoundingSphere(),Wt.copy(ue.boundingSphere.center)),Wt.applyMatrix4(M.matrixWorld).applyMatrix4(St)),Array.isArray(be)){const Ae=ue.groups;for(let He=0,Ze=Ae.length;He<Ze;He++){const we=Ae[He],Je=be[we.materialIndex];Je&&Je.visible&&E.push(M,ue,Je,H,Wt.z,we,I)}}else be.visible&&E.push(M,ue,be,H,Wt.z,null,I)}}}const pe=M.children;for(let _e=0,ue=pe.length;_e<ue;_e++)cl(pe[_e],I,H,O)}function Hd(M,I,H,O){const{opaque:B,transmissive:pe,transparent:_e}=M;S.setupLightsView(H),Ot===!0&&Y.setGlobalState(R.clippingPlanes,H),O&&me.viewport(ne.copy(O)),B.length>0&&ar(B,I,H),pe.length>0&&ar(pe,I,H),_e.length>0&&ar(_e,I,H),me.buffers.depth.setTest(!0),me.buffers.depth.setMask(!0),me.buffers.color.setMask(!0),me.setPolygonOffset(!1)}function Gd(M,I,H,O){if((H.isScene===!0?H.overrideMaterial:null)!==null)return;if(S.state.transmissionRenderTarget[O.id]===void 0){const we=Mt.has("EXT_color_buffer_half_float")||Mt.has("EXT_color_buffer_float");S.state.transmissionRenderTarget[O.id]=new Vn(1,1,{generateMipmaps:!0,type:we?gi:wn,minFilter:Li,samples:Math.max(4,wt.samples),stencilBuffer:a,resolveDepthBuffer:!1,resolveStencilBuffer:!1,storeMultisampledDepthBuffer:!1,storeMultisampledStencilBuffer:!1,colorSpace:et.workingColorSpace})}const pe=S.state.transmissionRenderTarget[O.id],_e=O.viewport||ne;pe.setSize(_e.z*R.transmissionResolutionScale,_e.w*R.transmissionResolutionScale);const ue=R.getRenderTarget(),be=R.getActiveCubeFace(),Ae=R.getActiveMipmapLevel();R.setRenderTarget(pe),R.getClearColor(K),ye=R.getClearAlpha(),ye<1&&R.setClearColor(16777215,.5),R.clear(),On&&C.render(H);const He=R.toneMapping;R.toneMapping=Ii;const Ze=O.viewport;if(O.viewport!==void 0&&(O.viewport=void 0),S.setupLightsView(O),Ot===!0&&Y.setGlobalState(R.clippingPlanes,O),ar(M,H,O),Oe.updateMultisampleRenderTarget(pe),Oe.updateRenderTargetMipmap(pe),Mt.has("WEBGL_multisampled_render_to_texture")===!1){let we=!1;for(let Je=0,Dt=I.length;Je<Dt;Je++){const mt=I[Je],{object:ut,geometry:on,material:Se,group:fn}=mt;if(Se.side===Mn&&ut.layers.test(O.layers)){const at=Se.side;Se.side=rn,Se.needsUpdate=!0,Vd(ut,H,O,on,Se,fn),Se.side=at,Se.needsUpdate=!0,we=!0}}we===!0&&(Oe.updateMultisampleRenderTarget(pe),Oe.updateRenderTargetMipmap(pe))}R.setRenderTarget(ue,be,Ae),R.setClearColor(K,ye),Ze!==void 0&&(O.viewport=Ze),R.toneMapping=He}function ar(M,I,H){const O=I.isScene===!0?I.overrideMaterial:null;for(let B=0,pe=M.length;B<pe;B++){const _e=M[B],{object:ue,geometry:be,group:Ae}=_e;let He=_e.material;He.allowOverride===!0&&O!==null&&(He=O),ue.layers.test(H.layers)&&Vd(ue,I,H,be,He,Ae)}}function Vd(M,I,H,O,B,pe){F!==null&&B.isNodeMaterial&&F.setObject(M,B),M.onBeforeRender(R,I,H,O,B,pe),M.modelViewMatrix.multiplyMatrices(H.matrixWorldInverse,M.matrixWorld),M.normalMatrix.getNormalMatrix(M.modelViewMatrix),B.onBeforeRender(R,I,H,O,M,pe),B.transparent===!0&&B.side===Mn&&B.forceSinglePass===!1?(B.side=rn,B.needsUpdate=!0,R.renderBufferDirect(H,I,O,B,M,pe),B.side=vs,B.needsUpdate=!0,R.renderBufferDirect(H,I,O,B,M,pe),B.side=Mn):R.renderBufferDirect(H,I,O,B,M,pe),M.onAfterRender(R,I,H,O,B,pe)}function Wd(M){let I=0;for(const H of M)H.texture!==null&&I++;return I}function ua(M,I,H){I.isScene!==!0&&(I=Fn);const O=De.get(M),B=S.state.lights,pe=S.state.shadowsArray,_e=B.state.version,ue=J.getParameters(M,B.state,pe,I,H,S.state.lightProbeGridArray),be=J.getProgramCacheKey(ue);let Ae=O.programs;O.environment=M.isMeshStandardMaterial||M.isMeshLambertMaterial||M.isMeshPhongMaterial?I.environment:null,O.fog=I.fog;const He=M.isMeshStandardMaterial||M.isMeshLambertMaterial&&!M.envMap||M.isMeshPhongMaterial&&!M.envMap;O.envMap=T.get(M.envMap||O.environment,He),O.envMapRotation=O.environment!==null&&M.envMap===null?I.environmentRotation:M.envMapRotation,Ae===void 0&&(M.addEventListener("dispose",ot),Ae=new Map,O.programs=Ae,O.programVariants=new Map);let Ze=Ae.get(be);if(Ze!==void 0){if(O.currentProgram===Ze&&O.lightsStateVersion===_e)return qd(M,ue),Ze}else ue.uniforms=J.getUniforms(M),F!==null&&M.isNodeMaterial&&F.build(M,H,ue),M.onBeforeCompile(ue,R),Ze=J.acquireProgram(ue,be),Ae.set(be,Ze),O.uniforms=ue.uniforms;const we=O.uniforms;return(!M.isShaderMaterial&&!M.isRawShaderMaterial||M.clipping===!0)&&(we.clippingPlanes=Y.uniform),qd(M,ue),O.needsLights=Up(M),O.lightsStateVersion=_e,O.needsLights&&(we.ambientLightColor.value=B.state.ambient,we.lightProbe.value=B.state.probe,we.sunLights.value=B.state.sun,we.sunLightShadows.value=B.state.sunShadow,we.directionalLights.value=B.state.directional,we.directionalLightShadows.value=B.state.directionalShadow,we.spotLights.value=B.state.spot,we.spotLightShadows.value=B.state.spotShadow,we.rectAreaLights.value=B.state.rectArea,we.ltc_1.value=B.state.rectAreaLTC1,we.ltc_2.value=B.state.rectAreaLTC2,we.pointLights.value=B.state.point,we.pointLightShadows.value=B.state.pointShadow,we.hemisphereLights.value=B.state.hemi,we.sunShadowMatrix.value=B.state.sunShadowMatrix,we.sunShadowCascade.value=B.state.sunShadowCascade,we.directionalShadowMatrix.value=B.state.directionalShadowMatrix,we.spotLightMatrix.value=B.state.spotLightMatrix,we.spotLightMap.value=B.state.spotLightMap,we.pointShadowMatrix.value=B.state.pointShadowMatrix),O.numLightProbeGrids=Wd(S.state.lightProbeGridArray),O.currentProgram=Ze,O.uniformsList=null,Ze}function Dp(M,I,H,O,B){const pe=De.get(M),_e=pe.currentProgram.id+","+O+","+B;let ue=pe.programVariants.get(_e);return ue===void 0?(ue=ua(M,I,H),pe.programVariants.set(_e,ue)):(pe.currentProgram=ue,pe.uniformsList=null,pe.outputColorSpace=O,pe.toneMapping=B),ue}function Xd(M){if(M.uniformsList===null){const I=M.currentProgram.getUniforms();M.uniformsList=io.seqWithValue(I.seq,M.uniforms)}return M.uniformsList}function qd(M,I){const H=De.get(M);H.outputColorSpace=I.outputColorSpace,H.batching=I.batching,H.batchingColor=I.batchingColor,H.instancing=I.instancing,H.instancingColor=I.instancingColor,H.instancingMorph=I.instancingMorph,H.skinning=I.skinning,H.morphTargets=I.morphTargets,H.morphNormals=I.morphNormals,H.morphColors=I.morphColors,H.morphTargetsCount=I.morphTargetsCount,H.numClippingPlanes=I.numClippingPlanes,H.numIntersection=I.numClipIntersection,H.vertexAlphas=I.vertexAlphas,H.vertexTangents=I.vertexTangents,H.toneMapping=I.toneMapping}function Ip(M,I,H,O,B){I.isScene!==!0&&(I=Fn),Oe.resetTextureUnits();const pe=I.fog,_e=O.isMeshStandardMaterial||O.isMeshLambertMaterial||O.isMeshPhongMaterial?I.environment:null,ue=te===null?R.outputColorSpace:te.isXRRenderTarget===!0?te.texture.colorSpace:et.workingColorSpace,be=O.isMeshStandardMaterial||O.isMeshLambertMaterial&&!O.envMap||O.isMeshPhongMaterial&&!O.envMap,Ae=T.get(O.envMap||_e,be),He=O.vertexColors===!0&&!!H.attributes.color&&H.attributes.color.itemSize===4,Ze=!!H.attributes.tangent&&(!!O.normalMap||O.anisotropy>0),we=!!H.morphAttributes.position,Je=!!H.morphAttributes.normal,Dt=!!H.morphAttributes.color;let mt=Ii;O.toneMapped&&(te===null||te.isXRRenderTarget===!0)&&(mt=R.toneMapping);const ut=H.morphAttributes.position||H.morphAttributes.normal||H.morphAttributes.color,on=ut!==void 0?ut.length:0,Se=De.get(O),fn=S.state.lights;if(Ot===!0&&(xn===!0||M!==ee)){const Et=M===ee&&O.id===V;Y.setState(O,M,Et)}let at=!1,os=!1;O.version===Se.__version?Se.needsLights&&Se.lightsStateVersion!==fn.state.version||B.isBatchedMesh&&Se.batching===!1||!B.isBatchedMesh&&Se.batching===!0||B.isBatchedMesh&&Se.batchingColor===!0&&B._colorsTexture===null||B.isBatchedMesh&&Se.batchingColor===!1&&B._colorsTexture!==null||B.isInstancedMesh&&Se.instancing===!1||!B.isInstancedMesh&&Se.instancing===!0||B.isSkinnedMesh&&Se.skinning===!1||!B.isSkinnedMesh&&Se.skinning===!0||B.isInstancedMesh&&Se.instancingColor===!0&&B.instanceColor===null||B.isInstancedMesh&&Se.instancingColor===!1&&B.instanceColor!==null||B.isInstancedMesh&&Se.instancingMorph===!0&&B.morphTexture===null||B.isInstancedMesh&&Se.instancingMorph===!1&&B.morphTexture!==null||Se.envMap!==Ae||O.fog===!0&&Se.fog!==pe||Se.numClippingPlanes!==void 0&&(Se.numClippingPlanes!==Y.numPlanes||Se.numIntersection!==Y.numIntersection)||Se.vertexAlphas!==He||Se.vertexTangents!==Ze||Se.morphTargets!==we||Se.morphNormals!==Je||Se.morphColors!==Dt||Se.morphTargetsCount!==on||Se.numLightProbeGrids!==Wd(S.state.lightProbeGridArray)?at=!0:(Se.outputColorSpace!==ue||Se.toneMapping!==mt)&&(os=!0):(at=!0,Se.__version=O.version);let ln=Se.currentProgram;(at===!0||os===!0)&&(ln=os===!0?Dp(O,I,B,ue,mt):ua(O,I,B),F&&O.isNodeMaterial&&F.onUpdateProgram(O,ln,Se));let rr=!1,Bi=!1,ls=!1;const nt=ln.getUniforms(),Qt=Se.uniforms;if(me.useProgram(ln.program)&&(rr=!0,Bi=!0,ls=!0),O.id!==V&&(V=O.id,Bi=!0),rr||ee!==M){me.buffers.depth.getReversed()&&M.reversedDepth!==!0&&(M._reversedDepth=!0,M.updateProjectionMatrix()),nt.setValue(U,"projectionMatrix",M.projectionMatrix),nt.setValue(U,"viewMatrix",M.matrixWorldInverse);const qt=nt.map.cameraPosition;qt!==void 0&&qt.setValue(U,ri.setFromMatrixPosition(M.matrixWorld)),wt.logarithmicDepthBuffer&&nt.setValue(U,"logDepthBufFC",2/(Math.log(M.far+1)/Math.LN2)),(O.isMeshPhongMaterial||O.isMeshToonMaterial||O.isMeshLambertMaterial||O.isMeshBasicMaterial||O.isMeshStandardMaterial||O.isShaderMaterial)&&nt.setValue(U,"isOrthographic",M.isOrthographicCamera===!0),ee!==M&&(ee=M,Bi=!0,ls=!0)}if(Se.needsLights&&(fn.state.sunShadowMap.length>0&&nt.setValue(U,"sunShadowMap",fn.state.sunShadowMap,Oe),fn.state.directionalShadowMap.length>0&&nt.setValue(U,"directionalShadowMap",fn.state.directionalShadowMap,Oe),fn.state.spotShadowMap.length>0&&nt.setValue(U,"spotShadowMap",fn.state.spotShadowMap,Oe),fn.state.pointShadowMap.length>0&&nt.setValue(U,"pointShadowMap",fn.state.pointShadowMap,Oe)),B.isSkinnedMesh){nt.setOptional(U,B,"bindMatrix"),nt.setOptional(U,B,"bindMatrixInverse");const Et=B.skeleton;Et&&(Et.boneTexture===null&&Et.computeBoneTexture(),nt.setValue(U,"boneTexture",Et.boneTexture,Oe))}B.isBatchedMesh&&(nt.setOptional(U,B,"batchingTexture"),nt.setValue(U,"batchingTexture",B._matricesTexture,Oe),nt.setOptional(U,B,"batchingIdTexture"),nt.setValue(U,"batchingIdTexture",B._indirectTexture,Oe),nt.setOptional(U,B,"batchingColorTexture"),B._colorsTexture!==null&&nt.setValue(U,"batchingColorTexture",B._colorsTexture,Oe));const Yn=H.morphAttributes;if((Yn.position!==void 0||Yn.normal!==void 0||Yn.color!==void 0)&&Z.update(B,H,ln),(Bi||Se.receiveShadow!==B.receiveShadow)&&(Se.receiveShadow=B.receiveShadow,nt.setValue(U,"receiveShadow",B.receiveShadow)),(O.isMeshStandardMaterial||O.isMeshLambertMaterial||O.isMeshPhongMaterial)&&O.envMap===null&&I.environment!==null&&(Qt.envMapIntensity.value=I.environmentIntensity),Qt.dfgLUT!==void 0&&(Qt.dfgLUT.value=Fb()),Bi){if(nt.setValue(U,"toneMappingExposure",R.toneMappingExposure),Se.needsLights&&Np(Qt,ls),pe&&O.fog===!0&&le.refreshFogUniforms(Qt,pe),le.refreshMaterialUniforms(Qt,O,xe,Le,S.state.transmissionRenderTarget[M.id]),Se.needsLights&&Se.numLightProbeGrids>0){const Et=b;let qt=0;for(const vi of S.state.lightProbeGridArray)vi.texture!==null&&(Et.textures[qt]=vi.texture,Et.min[qt]=vi.boundingBox.min,Et.max[qt]=vi.boundingBox.max,Et.resolution[qt]=vi.resolution,qt++);for(const vi in Et)Et[vi].length=qt;Qt.probesSH.value=Et.textures,Qt.probesMin.value=Et.min,Qt.probesMax.value=Et.max,Qt.probesResolution.value=Et.resolution}io.upload(U,Xd(Se),Qt,Oe)}if(O.isShaderMaterial&&O.uniformsNeedUpdate===!0&&(io.upload(U,Xd(Se),Qt,Oe),O.uniformsNeedUpdate=!1),O.isSpriteMaterial&&nt.setValue(U,"center",B.center),nt.setValue(U,"modelViewMatrix",B.modelViewMatrix),nt.setValue(U,"normalMatrix",B.normalMatrix),nt.setValue(U,"modelMatrix",B.matrixWorld),O.uniformsGroups!==void 0){const Et=O.uniformsGroups;for(let qt=0,vi=Et.length;qt<vi;qt++){const Kd=Et[qt];Re.update(Kd,ln),Re.bind(Kd,ln)}}return ln}function Np(M,I){M.ambientLightColor.needsUpdate=I,M.lightProbe.needsUpdate=I,M.sunLights.needsUpdate=I,M.sunLightShadows.needsUpdate=I,M.directionalLights.needsUpdate=I,M.directionalLightShadows.needsUpdate=I,M.pointLights.needsUpdate=I,M.pointLightShadows.needsUpdate=I,M.spotLights.needsUpdate=I,M.spotLightShadows.needsUpdate=I,M.rectAreaLights.needsUpdate=I,M.hemisphereLights.needsUpdate=I}function Up(M){return M.isMeshLambertMaterial||M.isMeshToonMaterial||M.isMeshPhongMaterial||M.isMeshStandardMaterial||M.isShadowMaterial||M.isShaderMaterial&&M.lights===!0}this.getActiveCubeFace=function(){return X},this.getActiveMipmapLevel=function(){return $},this.getRenderTarget=function(){return te},this.setRenderTargetTextures=function(M,I,H){const O=De.get(M);O.__autoAllocateDepthBuffer=M.resolveDepthBuffer===!1,O.__autoAllocateDepthBuffer===!1&&(O.__useRenderToTexture=!1),De.get(M.texture).__webglTexture=I,De.get(M.depthTexture).__webglTexture=O.__autoAllocateDepthBuffer?void 0:H,O.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(M,I){const H=De.get(M);H.__webglFramebuffer=I,H.__useDefaultFramebuffer=I===void 0},this.setRenderTarget=function(M,I=0,H=0){te=M,X=I,$=H;let O=null,B=!1,pe=!1;if(M){const ue=De.get(M);if(ue.__useDefaultFramebuffer!==void 0){me.bindFramebuffer(U.FRAMEBUFFER,ue.__webglFramebuffer),ne.copy(M.viewport),Ee.copy(M.scissor),$e=M.scissorTest,me.viewport(ne),me.scissor(Ee),me.setScissorTest($e),V=-1;return}else if(ue.__webglFramebuffer===void 0)Oe.setupRenderTarget(M);else if(ue.__hasExternalTextures)Oe.rebindTextures(M,De.get(M.texture).__webglTexture,De.get(M.depthTexture).__webglTexture);else if(M.depthBuffer){const He=M.depthTexture;if(ue.__boundDepthTexture!==He){if(He!==null&&De.has(He)&&(M.width!==He.image.width||M.height!==He.image.height))throw new Error("THREE.WebGLRenderer: Attached DepthTexture is initialized to the incorrect size.");Oe.setupDepthRenderbuffer(M)}}const be=M.texture;(be.isData3DTexture||be.isDataArrayTexture||be.isCompressedArrayTexture)&&(pe=!0);const Ae=De.get(M).__webglFramebuffer;M.isWebGLCubeRenderTarget?(Array.isArray(Ae[I])?O=Ae[I][H]:O=Ae[I],B=!0):M.samples>0&&Oe.useMultisampledRTT(M)===!1?O=De.get(M).__webglMultisampledFramebuffer:Array.isArray(Ae)?O=Ae[H]:O=Ae,ne.copy(M.viewport),Ee.copy(M.scissor),$e=M.scissorTest}else ne.copy(Ne).multiplyScalar(xe).floor(),Ee.copy(rt).multiplyScalar(xe).floor(),$e=ht;if(H!==0&&(O=G),me.bindFramebuffer(U.FRAMEBUFFER,O)&&me.drawBuffers(M,O),me.viewport(ne),me.scissor(Ee),me.setScissorTest($e),B){const ue=De.get(M.texture);U.framebufferTexture2D(U.FRAMEBUFFER,U.COLOR_ATTACHMENT0,U.TEXTURE_CUBE_MAP_POSITIVE_X+I,ue.__webglTexture,H)}else if(pe){const ue=I;for(let be=0;be<M.textures.length;be++){const Ae=De.get(M.textures[be]);U.framebufferTextureLayer(U.FRAMEBUFFER,U.COLOR_ATTACHMENT0+be,Ae.__webglTexture,H,ue)}}else if(M!==null&&H!==0){const ue=De.get(M.texture);U.framebufferTexture2D(U.FRAMEBUFFER,U.COLOR_ATTACHMENT0,U.TEXTURE_2D,ue.__webglTexture,H)}V=-1};function Yd(M){const I=De.get(M);return(I.__readFormat!==M.format||I.__readType!==M.type)&&(I.__readFormat=M.format,I.__readType=M.type,I.__formatReadable=wt.textureFormatReadable(M.format),I.__typeReadable=wt.textureTypeReadable(M.type)),I}this.readRenderTargetPixels=function(M,I,H,O,B,pe,_e,ue=0){if(!(M&&M.isWebGLRenderTarget)){it("WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let be=De.get(M).__webglFramebuffer;if(M.isWebGLCubeRenderTarget&&_e!==void 0&&(be=be[_e],Array.isArray(be)&&(be=be[0])),be){me.bindFramebuffer(U.FRAMEBUFFER,be);try{const Ae=M.textures[ue],He=Ae.format,Ze=Ae.type;M.textures.length>1&&U.readBuffer(U.COLOR_ATTACHMENT0+ue);const we=Yd(Ae);if(we.__formatReadable===!1){it("WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(we.__typeReadable===!1){it("WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}I>=0&&I<=M.width-O&&H>=0&&H<=M.height-B&&U.readPixels(I,H,O,B,oe.convert(He),oe.convert(Ze),pe)}finally{const Ae=te!==null?De.get(te).__webglFramebuffer:null;me.bindFramebuffer(U.FRAMEBUFFER,Ae)}}},this.readRenderTargetPixelsAsync=async function(M,I,H,O,B,pe,_e,ue=0){if(!(M&&M.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let be=De.get(M).__webglFramebuffer;if(M.isWebGLCubeRenderTarget&&_e!==void 0&&(be=be[_e],Array.isArray(be)&&(be=be[0])),be)if(I>=0&&I<=M.width-O&&H>=0&&H<=M.height-B){me.bindFramebuffer(U.FRAMEBUFFER,be);const Ae=M.textures[ue],He=Ae.format,Ze=Ae.type;M.textures.length>1&&U.readBuffer(U.COLOR_ATTACHMENT0+ue);const we=Yd(Ae);if(we.__formatReadable===!1)throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(we.__typeReadable===!1)throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");const Je=U.createBuffer();U.bindBuffer(U.PIXEL_PACK_BUFFER,Je),U.bufferData(U.PIXEL_PACK_BUFFER,pe.byteLength,U.STREAM_READ),U.readPixels(I,H,O,B,oe.convert(He),oe.convert(Ze),0),U.bindBuffer(U.PIXEL_PACK_BUFFER,null);const Dt=te!==null?De.get(te).__webglFramebuffer:null;me.bindFramebuffer(U.FRAMEBUFFER,Dt);const mt=U.fenceSync(U.SYNC_GPU_COMMANDS_COMPLETE,0);return U.flush(),await Xm(U,mt,4),U.bindBuffer(U.PIXEL_PACK_BUFFER,Je),U.getBufferSubData(U.PIXEL_PACK_BUFFER,0,pe),U.bindBuffer(U.PIXEL_PACK_BUFFER,null),U.deleteBuffer(Je),U.deleteSync(mt),pe}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")},this.copyFramebufferToTexture=function(M,I=null,H=0){const O=Math.pow(2,-H),B=Math.floor(M.image.width*O),pe=Math.floor(M.image.height*O),_e=I!==null?I.x:0,ue=I!==null?I.y:0;Oe.setTexture2D(M,0),U.copyTexSubImage2D(U.TEXTURE_2D,H,0,0,_e,ue,B,pe),me.unbindTexture()},this.copyTextureToTexture=function(M,I,H=null,O=null,B=0,pe=0){let _e,ue,be,Ae,He,Ze,we,Je,Dt;const mt=M.isCompressedTexture?M.mipmaps[pe]:M.image;if(H!==null)_e=H.max.x-H.min.x,ue=H.max.y-H.min.y,be=H.isBox3?H.max.z-H.min.z:1,Ae=H.min.x,He=H.min.y,Ze=H.isBox3?H.min.z:0;else{const nt=Math.pow(2,-B);_e=Math.floor(mt.width*nt),ue=Math.floor(mt.height*nt),M.isDataArrayTexture?be=mt.depth:M.isData3DTexture?be=Math.floor(mt.depth*nt):be=1,Ae=0,He=0,Ze=0}O!==null?(we=O.x,Je=O.y,Dt=O.z):(we=0,Je=0,Dt=0);const ut=oe.convert(I.format),on=oe.convert(I.type);let Se;I.isData3DTexture?(Oe.setTexture3D(I,0),Se=U.TEXTURE_3D):I.isDataArrayTexture||I.isCompressedArrayTexture?(Oe.setTexture2DArray(I,0),Se=U.TEXTURE_2D_ARRAY):(Oe.setTexture2D(I,0),Se=U.TEXTURE_2D),me.activeTexture(U.TEXTURE0),me.pixelStorei(U.UNPACK_FLIP_Y_WEBGL,I.flipY),me.pixelStorei(U.UNPACK_PREMULTIPLY_ALPHA_WEBGL,I.premultiplyAlpha),me.pixelStorei(U.UNPACK_ALIGNMENT,I.unpackAlignment);const fn=me.getParameter(U.UNPACK_ROW_LENGTH),at=me.getParameter(U.UNPACK_IMAGE_HEIGHT),os=me.getParameter(U.UNPACK_SKIP_PIXELS),ln=me.getParameter(U.UNPACK_SKIP_ROWS),rr=me.getParameter(U.UNPACK_SKIP_IMAGES);me.pixelStorei(U.UNPACK_ROW_LENGTH,mt.width),me.pixelStorei(U.UNPACK_IMAGE_HEIGHT,mt.height),me.pixelStorei(U.UNPACK_SKIP_PIXELS,Ae),me.pixelStorei(U.UNPACK_SKIP_ROWS,He),me.pixelStorei(U.UNPACK_SKIP_IMAGES,Ze);const Bi=M.isDataArrayTexture||M.isData3DTexture,ls=I.isDataArrayTexture||I.isData3DTexture;if(M.isDepthTexture){const nt=De.get(M),Qt=De.get(I),Yn=De.get(nt.__renderTarget),Et=De.get(Qt.__renderTarget);me.bindFramebuffer(U.READ_FRAMEBUFFER,Yn.__webglFramebuffer),me.bindFramebuffer(U.DRAW_FRAMEBUFFER,Et.__webglFramebuffer);for(let qt=0;qt<be;qt++)Bi&&(U.framebufferTextureLayer(U.READ_FRAMEBUFFER,U.COLOR_ATTACHMENT0,De.get(M).__webglTexture,B,Ze+qt),U.framebufferTextureLayer(U.DRAW_FRAMEBUFFER,U.COLOR_ATTACHMENT0,De.get(I).__webglTexture,pe,Dt+qt)),U.blitFramebuffer(Ae,He,Ae+_e,He+ue,we,Je,we+_e,Je+ue,U.DEPTH_BUFFER_BIT,U.NEAREST);me.bindFramebuffer(U.READ_FRAMEBUFFER,null),me.bindFramebuffer(U.DRAW_FRAMEBUFFER,null)}else if(B!==0||M.isRenderTargetTexture||De.has(M)){const nt=De.get(M),Qt=De.get(I);me.bindFramebuffer(U.READ_FRAMEBUFFER,L),me.bindFramebuffer(U.DRAW_FRAMEBUFFER,z);for(let Yn=0;Yn<be;Yn++)Bi?U.framebufferTextureLayer(U.READ_FRAMEBUFFER,U.COLOR_ATTACHMENT0,nt.__webglTexture,B,Ze+Yn):U.framebufferTexture2D(U.READ_FRAMEBUFFER,U.COLOR_ATTACHMENT0,U.TEXTURE_2D,nt.__webglTexture,B),ls?U.framebufferTextureLayer(U.DRAW_FRAMEBUFFER,U.COLOR_ATTACHMENT0,Qt.__webglTexture,pe,Dt+Yn):U.framebufferTexture2D(U.DRAW_FRAMEBUFFER,U.COLOR_ATTACHMENT0,U.TEXTURE_2D,Qt.__webglTexture,pe),B!==0?U.blitFramebuffer(Ae,He,Ae+_e,He+ue,we,Je,we+_e,Je+ue,U.COLOR_BUFFER_BIT,U.NEAREST):ls?U.copyTexSubImage3D(Se,pe,we,Je,Dt+Yn,Ae,He,_e,ue):U.copyTexSubImage2D(Se,pe,we,Je,Ae,He,_e,ue);me.bindFramebuffer(U.READ_FRAMEBUFFER,null),me.bindFramebuffer(U.DRAW_FRAMEBUFFER,null)}else ls?M.isDataTexture||M.isData3DTexture?U.texSubImage3D(Se,pe,we,Je,Dt,_e,ue,be,ut,on,mt.data):I.isCompressedArrayTexture?U.compressedTexSubImage3D(Se,pe,we,Je,Dt,_e,ue,be,ut,mt.data):U.texSubImage3D(Se,pe,we,Je,Dt,_e,ue,be,ut,on,mt):M.isDataTexture?U.texSubImage2D(U.TEXTURE_2D,pe,we,Je,_e,ue,ut,on,mt.data):M.isCompressedTexture?U.compressedTexSubImage2D(U.TEXTURE_2D,pe,we,Je,mt.width,mt.height,ut,mt.data):U.texSubImage2D(U.TEXTURE_2D,pe,we,Je,_e,ue,ut,on,mt);me.pixelStorei(U.UNPACK_ROW_LENGTH,fn),me.pixelStorei(U.UNPACK_IMAGE_HEIGHT,at),me.pixelStorei(U.UNPACK_SKIP_PIXELS,os),me.pixelStorei(U.UNPACK_SKIP_ROWS,ln),me.pixelStorei(U.UNPACK_SKIP_IMAGES,rr),pe===0&&I.generateMipmaps===!0&&I.mipmapsAutoUpdate===!0&&U.generateMipmap(Se),me.unbindTexture()},this.initRenderTarget=function(M){De.get(M).__webglFramebuffer===void 0&&Oe.setupRenderTarget(M)},this.initTexture=function(M){M.isCubeTexture?Oe.setTextureCube(M,0):M.isData3DTexture?Oe.setTexture3D(M,0):M.isDataArrayTexture||M.isCompressedArrayTexture?Oe.setTexture2DArray(M,0):Oe.setTexture2D(M,0),me.unbindTexture()},this.resetState=function(){X=0,$=0,te=null,me.reset(),ce.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return si}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;const t=this.getContext();t.drawingBufferColorSpace=et._getDrawingBufferColorSpace(e),t.unpackColorSpace=et._getUnpackColorSpace()}}const kb=`
vec3 mod289(vec3 x){return x-floor(x*(1.0/289.0))*289.0;} vec4 mod289(vec4 x){return x-floor(x*(1.0/289.0))*289.0;}
vec4 permute(vec4 x){return mod289(((x*34.0)+1.0)*x);} vec4 taylorInvSqrt(vec4 r){return 1.79284291400159-0.85373472095314*r;}
float snoise(vec3 v){ const vec2 C=vec2(1.0/6.0,1.0/3.0); const vec4 D=vec4(0.0,0.5,1.0,2.0);
  vec3 i=floor(v+dot(v,C.yyy)); vec3 x0=v-i+dot(i,C.xxx); vec3 g=step(x0.yzx,x0.xyz); vec3 l=1.0-g; vec3 i1=min(g.xyz,l.zxy); vec3 i2=max(g.xyz,l.zxy);
  vec3 x1=x0-i1+C.xxx; vec3 x2=x0-i2+C.yyy; vec3 x3=x0-D.yyy; i=mod289(i);
  vec4 p=permute(permute(permute(i.z+vec4(0.0,i1.z,i2.z,1.0))+i.y+vec4(0.0,i1.y,i2.y,1.0))+i.x+vec4(0.0,i1.x,i2.x,1.0));
  float n_=0.142857142857; vec3 ns=n_*D.wyz-D.xzx; vec4 j=p-49.0*floor(p*ns.z*ns.z); vec4 x_=floor(j*ns.z); vec4 y_=floor(j-7.0*x_);
  vec4 x=x_*ns.x+ns.yyyy; vec4 y=y_*ns.x+ns.yyyy; vec4 h=1.0-abs(x)-abs(y); vec4 b0=vec4(x.xy,y.xy); vec4 b1=vec4(x.zw,y.zw);
  vec4 s0=floor(b0)*2.0+1.0; vec4 s1=floor(b1)*2.0+1.0; vec4 sh=-step(h,vec4(0.0)); vec4 a0=b0.xzyw+s0.xzyw*sh.xxyy; vec4 a1=b1.xzyw+s1.xzyw*sh.zzww;
  vec3 p0=vec3(a0.xy,h.x); vec3 p1=vec3(a0.zw,h.y); vec3 p2=vec3(a1.xy,h.z); vec3 p3=vec3(a1.zw,h.w);
  vec4 norm=taylorInvSqrt(vec4(dot(p0,p0),dot(p1,p1),dot(p2,p2),dot(p3,p3))); p0*=norm.x; p1*=norm.y; p2*=norm.z; p3*=norm.w;
  vec4 m=max(0.6-vec4(dot(x0,x0),dot(x1,x1),dot(x2,x2),dot(x3,x3)),0.0); m=m*m;
  return 42.0*dot(m*m,vec4(dot(p0,x0),dot(p1,x1),dot(p2,x2),dot(p3,x3))); }
float fbm(vec3 p, int oct){ float s=0.0, a=0.5; for(int i=0;i<8;i++){ if(i>=oct) break; s+=a*snoise(p); p=p*2.03+vec3(1.7,9.2,3.1); a*=0.5; } return s; }
vec3 hash3(vec3 p){ p=fract(p*vec3(0.1031,0.1030,0.0973)); p+=dot(p,p.yxz+33.33); return fract((p.xxy+p.yxx)*p.zyx); }
float craters(vec3 p){ vec3 i=floor(p), f=fract(p); float c=0.0; for(int x=-1;x<=1;x++) for(int y=-1;y<=1;y++) for(int z=-1;z<=1;z++){ vec3 o=vec3(float(x),float(y),float(z)); vec3 h=hash3(i+o); vec3 d=o+h-f; float r=0.15+0.3*h.x; float dd=length(d)/r; if(dd<1.0){ c+= (dd<0.8? -0.6*(1.0-dd*dd*1.4) : 0.0) + (dd>=0.75 ? 0.5*(1.0-abs(dd-0.88)/0.13) : 0.0); } } return c; }`,Bb="varying vec2 vUv; void main(){ vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }",zb=`precision highp float; varying vec2 vUv; uniform int uMode; uniform float uSeed;
${kb}
vec3 dirOf(vec2 uv){ float lon = (uv.x - 0.5) * 6.2831853; float lat = (uv.y - 0.5) * 3.1415926; return vec3(cos(lat)*cos(lon), sin(lat), cos(lat)*sin(lon)); }
void main(){ vec3 n = dirOf(vUv); vec3 p = n*1.2 + vec3(uSeed*7.31, uSeed*3.17, uSeed*1.91);
  if (uMode == 0) { // Earth albedo (rgb) + water mask (a)
    float h = fbm(p*1.6, 7) + 0.35*fbm(p*5.0, 4); float wl = 0.02; vec3 col; float water = 0.0;
    if (h < wl) { float dpt = clamp((wl-h)*3.0, 0.0, 1.0); col = mix(vec3(0.12,0.42,0.65), vec3(0.04,0.16,0.36), dpt); water = 1.0; }
    else { float e = clamp((h-wl)/0.73, 0.0, 1.0); float dry = smoothstep(0.1, 0.5, snoise(p*1.3+4.0)*0.5+0.5) * (1.0-abs(n.y));
      vec3 green = mix(vec3(0.20,0.45,0.18), vec3(0.62,0.55,0.34), dry); col = e < 0.45 ? mix(green, vec3(0.55,0.5,0.36), e/0.45) : mix(vec3(0.55,0.5,0.36), vec3(0.92,0.9,0.86), (e-0.45)/0.55); }
    float lat = abs(n.y) + 0.06*snoise(p*2.0); float ice = smoothstep(0.84, 0.89, lat); col = mix(col, vec3(0.94,0.96,1.0), ice); water *= 1.0-ice;
    gl_FragColor = vec4(col, water); }
  else if (uMode == 1) { // clouds (r), city lights (g)
    float cl = smoothstep(0.36, 0.78, fbm(n*2.2 + vec3(uSeed), 6)*0.5+0.5); cl = max(cl, smoothstep(0.55, 0.9, fbm(n*vec3(1.0,3.5,1.0)*2.0+3.0, 4)*0.5+0.5)*0.8*(1.0-abs(n.y)));
    float h = fbm(p*1.6, 7) + 0.35*fbm(p*5.0, 4); float land = smoothstep(0.03, 0.12, h-0.02);
    float region = smoothstep(0.55, 0.8, snoise(p*5.0)*0.5+0.5); float dots = smoothstep(0.6, 0.9, snoise(p*70.0)*0.5+0.5) + 0.35*smoothstep(0.7, 0.95, snoise(p*26.0)*0.5+0.5);
    gl_FragColor = vec4(cl, region*dots*land*(1.0-smoothstep(0.75, 0.9, abs(n.y))), 0.0, 1.0); }
  else if (uMode == 2) { // Moon albedo
    float h = fbm(p*1.6, 6)*0.6 + craters(n*6.0+uSeed)*0.5 + craters(n*15.0+uSeed*2.0)*0.25; float mare = smoothstep(0.1, -0.2, fbm(p*0.9+2.0, 4));
    vec3 col = mix(vec3(0.62,0.61,0.59), vec3(0.36,0.36,0.37), mare) * (0.8 + h*0.35); gl_FragColor = vec4(col, 1.0); }
  else if (uMode == 4) { // Mars albedo: rust plains, dark regions, polar caps
    float h = fbm(p*1.4, 6); float dark = smoothstep(0.05, 0.35, fbm(p*0.8+5.0, 4)); vec3 col = mix(vec3(0.78,0.42,0.24), vec3(0.42,0.2,0.13), dark) * (0.85 + h*0.25);
    float ice = smoothstep(0.86, 0.9, abs(n.y) + 0.04*snoise(p*3.0)); col = mix(col, vec3(0.95,0.93,0.9), ice); gl_FragColor = vec4(col, 1.0); }
  else { // nebula sky
    float n1 = fbm(n*1.8 + 1.3, 5)*0.5+0.5; float n2 = fbm(n*4.0 + 3.0, 4)*0.5+0.5; vec3 col = vec3(0.004,0.006,0.016) + vec3(0.12,0.22,0.5)*pow(n1, 3.4)*0.6 + vec3(0.25,0.08,0.3)*pow(n2, 4.0)*0.5;
    float band = exp(-pow(n.y*3.2 + 0.4*snoise(n*3.0), 2.0)); col += vec3(0.16,0.15,0.2)*band*(0.5+0.5*n1);
    gl_FragColor = vec4(col, 1.0); } }`;function Sa(i,e,t,n,s=1){const a=new Vn(t,n,{type:wn,generateMipmaps:!0,minFilter:Li,magFilter:vn,wrapS:ho}),r=new Wo,o=new Ad(-1,1,1,-1,0,1),l=new Pn({vertexShader:Bb,fragmentShader:zb,uniforms:{uMode:{value:e},uSeed:{value:s}}}),c=new Te(new Fi(2,2),l);r.add(c);const d=i.getRenderTarget();return i.setRenderTarget(a),i.render(r,o),i.setRenderTarget(d),l.dispose(),c.geometry.dispose(),a.texture.colorSpace=e===1?Ti:zt,a}const cu="varying vec3 vN; varying vec3 vW; varying vec2 vUv; void main(){ vUv = uv; vN = normalize(mat3(modelMatrix)*normal); vec4 w = modelMatrix*vec4(position,1.0); vW = w.xyz; gl_Position = projectionMatrix*viewMatrix*w; }",du=`uniform sampler2D uDay; uniform sampler2D uAux; uniform vec3 uSun; uniform float uTime; varying vec3 vN; varying vec3 vW; varying vec2 vUv;
void main(){ vec3 n = normalize(vN); vec3 v = normalize(cameraPosition - vW); float ndl = dot(n, uSun);
  vec4 day = texture2D(uDay, vUv); vec4 aux = texture2D(uAux, vUv); float cl = texture2D(uAux, vUv + vec2(uTime*0.0016, 0.0)).r;
  float diff = max(ndl, 0.0); vec3 col = day.rgb*(0.025 + diff*1.1);
  vec3 h = normalize(uSun + v); col += vec3(1.0,0.93,0.8)*pow(max(dot(n,h),0.0), 70.0)*day.a*diff*0.9;
  col = mix(col, vec3(1.0)*(0.04 + diff*1.15), cl*0.9);
  col += vec3(1.0,0.72,0.38)*aux.g*(1.0-cl*0.85)*smoothstep(0.05,-0.25,ndl)*1.6;
  float limb = pow(1.0 - max(dot(n, v), 0.0), 3.0); col += vec3(0.32,0.58,1.0)*limb*(0.15 + diff*0.95);
  col = mix(col, col*vec3(1.15,0.85,0.7), smoothstep(0.2,0.0,ndl)*smoothstep(-0.1,0.05,ndl)*0.6);
  gl_FragColor = vec4(col, 1.0); }`,hu=`uniform vec3 uSun; varying vec3 vN; varying vec3 vW; void main(){ vec3 n = normalize(vN); vec3 v = normalize(cameraPosition - vW); float rim = pow(1.0 - abs(dot(n, v)), 2.6);
  float lit = clamp(dot(n, uSun)*0.9 + 0.35, 0.0, 1.0); gl_FragColor = vec4(vec3(0.35,0.62,1.0)*rim*lit*1.6, rim*lit); }`,$l="varying vec3 vN; varying vec3 vW; varying vec2 vUv; void main(){ vUv = uv; vN = normalize(mat3(modelMatrix)*normal); vec4 w = modelMatrix*vec4(position,1.0); vW = w.xyz; gl_Position = projectionMatrix*viewMatrix*w; }",$b="uniform sampler2D uMap; uniform vec3 uSun; varying vec3 vN; varying vec2 vUv; void main(){ float d = max(dot(normalize(vN), uSun), 0.0); gl_FragColor = vec4(texture2D(uMap, vUv).rgb*(0.02 + d*1.2), 1.0); }";class Hb{constructor(e,t,n){this.group=new _t,this.targets=[],this.worlds={},this.world="earth",this.renderer=null,this.R=0,this.sunDir=t.clone().normalize();const s=n==="high",a=s?2048:1024,r=Sa(e,0,a,a/2,1),o=Sa(e,1,a,a/2,1),l=Sa(e,2,512,256,4),c=Sa(e,3,s?1024:512,s?512:256,2);this.targets.push(r,o,l,c);const d=3e3,h=d*Math.sin(xo.degToRad(50));this.uniforms={uDay:{value:r.texture},uAux:{value:o.texture},uSun:{value:this.sunDir},uTime:{value:0}},this.earth=new Te(new Nt(h,s?128:72,s?64:40),new Pn({vertexShader:cu,fragmentShader:du,uniforms:this.uniforms})),this.earth.position.set(0,-d,0),this.earth.rotation.z=.35,this.group.add(this.earth);const u=new Te(new Nt(h*1.03,64,32),new Pn({vertexShader:$l,fragmentShader:hu,uniforms:{uSun:{value:this.sunDir}},side:rn,transparent:!0,blending:fi,depthWrite:!1}));u.position.copy(this.earth.position),this.group.add(u),this.atm=u,this.renderer=e,this.R=h,this.worlds.earth=[],this.moon=new Te(new Nt(160,40,24),new Pn({vertexShader:$l,fragmentShader:$b,uniforms:{uMap:{value:l.texture},uSun:{value:this.sunDir}}})),this.moon.position.set(-3400,900,-4200),this.group.add(this.moon);const f=new Te(new Nt(9e3,48,24),new ct({map:c.texture,side:rn,depthWrite:!1}));this.group.add(f);const g=s?3500:1800,y=new Float32Array(g*3),m=new Float32Array(g*3),p=new Ce;for(let E=0;E<g;E++){const S=Math.random()*2-1,v=Math.random()*Math.PI*2,w=Math.sqrt(1-S*S);y.set([w*Math.cos(v)*8500,S*8500,w*Math.sin(v)*8500],E*3),p.setHSL(.55+Math.random()*.15-(Math.random()<.2?.45:0),.5,.75+Math.random()*.25),m.set([p.r,p.g,p.b],E*3)}const x=new bt;x.setAttribute("position",new Ft(y,3)),x.setAttribute("color",new Ft(m,3)),this.group.add(new qa(x,new ra({size:s?2.2:1.8,sizeAttenuation:!1,vertexColors:!0,depthWrite:!1,transparent:!0,opacity:.95})));const A=(()=>{const E=document.createElement("canvas");E.width=E.height=128;const S=E.getContext("2d"),v=S.createRadialGradient(64,64,0,64,64,64);v.addColorStop(0,"rgba(255,255,240,1)"),v.addColorStop(.12,"rgba(255,248,220,0.95)"),v.addColorStop(.35,"rgba(255,220,160,0.25)"),v.addColorStop(1,"rgba(255,200,120,0)"),S.fillStyle=v,S.fillRect(0,0,128,128);const w=new nr(E);return w.colorSpace=zt,w})(),b=new zc(new _o({map:A,depthWrite:!1,blending:fi,transparent:!0}));b.position.copy(this.sunDir).multiplyScalar(7e3),b.scale.setScalar(1300),this.group.add(b)}setWorld(e){if(e===this.world)return;this.world=e;const t=this.renderer;if(!this.worlds[e]&&e!=="earth"){const n=Sa(t,e==="mars"?4:2,1024,512,e==="moon"?4:e==="vault"?9:5);this.targets.push(n);const s=new Te(new Nt(this.R,96,48),new k0({map:n.texture,color:e==="vault"?new Ce(.55,.38,.85):new Ce(.62,.62,.62),emissive:e==="vault"?new Ce(.05,.02,.1):new Ce(0,0,0)}));s.position.copy(this.earth.position),s.rotation.z=.2,this.group.add(s);const a=[s];if(e==="mars"||e==="vault"){const o=new Te(new Nt(this.R*1.02,64,32),new Pn({vertexShader:$l,fragmentShader:hu.replace("vec3(0.35,0.62,1.0)",e==="vault"?"vec3(0.7,0.45,1.0)":"vec3(0.95,0.6,0.42)"),uniforms:{uSun:{value:this.sunDir}},side:rn,transparent:!0,blending:fi,depthWrite:!1}));o.position.copy(s.position),this.group.add(o),a.push(o)}const r=e==="moon"?new Te(new Nt(260,48,32),new Pn({vertexShader:cu,fragmentShader:du,uniforms:this.uniforms})):new Te(new qn(90,2),new $t({color:"#6e6660",flatShading:!0,roughness:1}));r.position.set(-3e3,1400,-4600),this.group.add(r),a.push(r),this.worlds[e]=a}for(const[n,s]of Object.entries(this.worlds))s.forEach(a=>a.visible=n===e);this.earth.visible=e==="earth",this.atm.visible=e==="earth",this.moon.visible=e==="earth"}update(e,t){this.uniforms.uTime.value=e,this.earth.rotation.y=e*.004,this.group.position.set(t.position.x*.98,0,t.position.z*.98)}}const Fe=yt*Zl,qi={haven:{top:[.3,.55,.43],rim:[.24,.42,.5],soil:[.08,.42,.33],deep:[.07,.25,.22],rock:[.07,.28,.27],flora:"grass",peb:"#8a8f99"},moon:{top:[.6,.03,.46],rim:[.6,.03,.55],soil:[.6,.03,.4],deep:[.6,.03,.28],rock:[.6,.03,.3],flora:"pebbles",peb:"#9a9a9e"},vault:{top:[.74,.32,.24],rim:[.76,.42,.34],soil:[.74,.3,.16],deep:[.74,.25,.1],rock:[.72,.2,.14],flora:"pebbles",peb:"#b06dff"},dune:{top:[.095,.62,.5],rim:[.11,.58,.64],soil:[.075,.5,.46],deep:[.065,.45,.3],rock:[.07,.32,.34],flora:"grass",peb:"#a08060",grass:"#f0cf7a",fl:["#ff9a4a","#ffd84a","#e05a3a"],flp:.06},sakura:{top:[.27,.45,.42],rim:[.93,.65,.74],soil:[.05,.3,.36],deep:[.04,.28,.22],rock:[.07,.18,.3],flora:"grass",peb:"#8a8f99",grass:"#a8e08e",fl:["#ffb7d5","#ff8fc0","#ffffff","#ffd1e6"],flp:.42},frost:{top:[.58,.34,.8],rim:[.54,.65,.66],soil:[.58,.35,.62],deep:[.6,.42,.42],rock:[.6,.22,.45],flora:"grass",peb:"#cfe8ff",grass:"#e6f6ff",fl:["#9fd0ff","#ffffff"],flp:.05},ember:{top:[.05,.72,.36],rim:[.085,.7,.5],soil:[.04,.45,.3],deep:[.03,.4,.2],rock:[.05,.25,.25],flora:"grass",peb:"#7a5040",grass:"#ff9a40",fl:["#ffd84a","#ff5a3a","#b33a1a"],flp:.2},neon:{top:[.66,.45,.13],rim:[.52,.9,.5],soil:[.7,.4,.12],deep:[.75,.5,.07],rock:[.7,.3,.11],flora:"grass",peb:"#3cf2ff",grass:"#2ee6ff",fl:["#ff3df0","#3cf2ff","#ffe03c"],flp:.08,glow:!0,check:.035},mars:{top:[.03,.62,.36],rim:[.05,.55,.46],soil:[.03,.45,.32],deep:[.02,.35,.22],rock:[.02,.32,.24],flora:"pebbles",peb:"#6b3422"}};function Gb(i){const e=qi[i]||qi.haven,t=new Ce,n=s=>"#"+t.setHSL(s[0],s[1],s[2]).getHexString();return[n(e.top),n(e.rim),e.flora==="pebbles"?n(e.soil):e.grass||"#5fb04a"]}class Vb{constructor(){this.group=new _t,this.grid=null,this.theme="haven",this.holo=new _t,this.debris=null,this.dInfo=[],this.key="",this.flora=[],this.floraKey="",this.group.add(this.holo)}build(e,t,n="haven"){const s=e.join("|")+"#"+t.join("|")+n;if(s===this.key)return;this.key=s,this.floraKey="",this.theme=n;const a=qi[n]||qi.haven;for(const b of[...this.group.children])b!==this.holo&&(this.group.remove(b),Wb(b));this.holo.clear(),this.flora=[];const r=new Set(e),o=(b,E)=>b>=0&&E>=0&&b<Fe&&E<Fe&&r.has(`${Math.floor(b/yt)},${Math.floor(E/yt)}`),l=Ln(7),c=[],d=[],h=new Ce,u=(b,E,S,v,w)=>{c.push(...b,...E,...S,...b,...S,...v);for(let P=0;P<6;P++)d.push(w.r,w.g,w.b)};for(let b=0;b<Fe;b++)for(let E=0;E<Fe;E++){if(!o(b,E))continue;const S=b-Fe/2,v=E-Fe/2,w=!o(b-1,E)||!o(b+1,E)||!o(b,E-1)||!o(b,E+1),P=a.check||.012,R=(l()-.5)*.05+((b+E)%2?P:-P),N=w?a.rim:a.top;h.setHSL(N[0]+(w?0:(l()-.5)*.02),N[1],N[2]+R),u([S,0,v],[S,0,v+1],[S+1,0,v+1],[S+1,0,v],h);const F=[[!o(b,E-1),[S+1,0,v],[S,0,v]],[!o(b,E+1),[S,0,v+1],[S+1,0,v+1]],[!o(b-1,E),[S,0,v],[S,0,v+1]],[!o(b+1,E),[S+1,0,v+1],[S+1,0,v]]];for(const[G,L,z]of F)G&&(h.setHSL(a.soil[0],a.soil[1],a.soil[2]+(l()-.5)*.04),u(L,[L[0],-.45,L[2]],[z[0],-.45,z[2]],z,h),h.setHSL(a.deep[0],a.deep[1],a.deep[2]),u([L[0],-.45,L[2]],[L[0],-.9,L[2]],[z[0],-.9,z[2]],[z[0],-.45,z[2]],h))}const f=new bt;f.setAttribute("position",new st(c,3)),f.setAttribute("color",new st(d,3)),f.computeVertexNormals();const g=new Te(f,new $t({vertexColors:!0,roughness:.92,metalness:0,flatShading:!0}));g.receiveShadow=!0,g.name="ground",this.group.add(g);const y=new $t({vertexColors:!0,flatShading:!0,roughness:.95});for(const b of e){const[E,S]=b.split(",").map(Number),v=E*yt+yt/2-Fe/2,w=S*yt+yt/2-Fe/2,P=Ln(E*31+S*7+3),R=4+P()*3.5,N=new Nn(yt*.62,R,9,4,!0);N.rotateX(Math.PI),N.translate(0,-.85-R/2,0);const F=N.attributes.position,G=new Float32Array(F.count*3);for(let X=0;X<F.count;X++){const $=F.getY(X),te=(-$-.85)/R,V=1-te*.15;F.setX(X,F.getX(X)*V+(P()-.5)*.5*(1-te)),F.setZ(X,F.getZ(X)*V+(P()-.5)*.5*(1-te)),F.setY(X,$+(P()-.5)*.35*(te>.02?1:0)),h.setHSL(a.rock[0]-te*.02,Math.max(0,a.rock[1]-te*.12),a.rock[2]-te*.12+(P()-.5)*.04),G.set([h.r,h.g,h.b],X*3)}N.setAttribute("color",new Ft(G,3)),N.computeVertexNormals();const L=new Te(N,y);L.position.set(v,0,w),L.castShadow=!0,this.group.add(L);const z=new Te(new pi(.22,0),new ct({color:"#7af7ff",toneMapped:!1}));z.position.set(v+(P()-.5)*3,-1.6-P()*1.4,w+(P()-.5)*3),z.scale.y=2,this.group.add(z)}const m=[];for(let b=0;b<Fe;b++)for(let E=0;E<Fe;E++){if(!o(b,E)||(b+E)%2)continue;const S=b-Fe/2+.5,v=E-Fe/2+.5;o(b,E-1)||m.push(new D(S,-.2,v-.5)),o(b,E+1)||m.push(new D(S,-.2,v+.5)),o(b-1,E)||m.push(new D(S-.5,-.2,v)),o(b+1,E)||m.push(new D(S+.5,-.2,v))}if(m.length){const b=new Rr(new Nt(.06,6,4),new ct({color:"#7af7ff",toneMapped:!1}),m.length),E=new tt;m.forEach((S,v)=>{E.makeTranslation(S.x,S.y,S.z),b.setMatrixAt(v,E)}),this.group.add(b)}const p=26;this.debris=new Rr(new ji(.5,0),y.clone(),p),this.debris.material.vertexColors=!1,this.debris.material.color.set("#6b5a4a"),this.debris.castShadow=!0,this.dInfo=[];for(let b=0;b<p;b++){const E=l()*Math.PI*2,S=14+l()*12;this.dInfo.push({p:new D(Math.cos(E)*S,-3-l()*6,Math.sin(E)*S),s:.3+l()*1.1,r:l()*6,ph:l()*6})}this.group.add(this.debris);for(const b of t){const[E,S]=b.split(",").map(Number),v=E*yt+yt/2-Fe/2,w=S*yt+yt/2-Fe/2,P=new Te(new Xn(yt-.3,.08,yt-.3),new ct({color:"#4fd8ff",transparent:!0,opacity:.12,depthWrite:!1}));P.position.set(v,-.1,w),P.userData.plot=b,this.holo.add(P);const R=new Lh(new D0(new Xn(yt-.3,.08,yt-.3)),new Mo({color:"#7af7ff",transparent:!0,opacity:.35}));R.position.copy(P.position),this.holo.add(R)}const x=[];for(let b=0;b<=Fe;b++)for(let E=0;E<Fe;E++)(o(b,E)||o(b-1,E))&&x.push(b-Fe/2,.02,E-Fe/2,b-Fe/2,.02,E+1-Fe/2);for(let b=0;b<=Fe;b++)for(let E=0;E<Fe;E++)(o(E,b)||o(E,b-1))&&x.push(E-Fe/2,.02,b-Fe/2,E+1-Fe/2,.02,b-Fe/2);const A=new bt;A.setAttribute("position",new st(x,3)),this.grid=new Lh(A,new Mo({color:"#ffffff",transparent:!0,opacity:.18})),this.grid.visible=!1,this.group.add(this.grid)}holoMeshes(){return this.holo.children.filter(e=>e.userData.plot)}scatter(e,t){const n=e.join("|")+"#"+[...t].sort().join(",");if(n===this.floraKey)return;this.floraKey=n,this.flora.forEach(y=>{this.group.remove(y),y.geometry.dispose()}),this.flora=[];const s=new Set(e),a=Ln(99),r=[],o=[],l=new Ui,c=new Wn,d=qi[this.theme]||qi.haven,h=d.fl||["#ffd84a","#ff7ab8","#ffffff","#9fd0ff","#ff9a4a"],u=d.flp??.12;for(let y=0;y<Fe;y++)for(let m=0;m<Fe;m++){if(!s.has(`${Math.floor(y/yt)},${Math.floor(m/yt)}`)||t.has(y+","+m))continue;const p=a()<.55?1+Math.floor(a()*3):0;for(let x=0;x<p;x++){c.set(0,a()*6,(a()-.5)*.3),l.setFromEuler(c);const A=.6+a()*.7;r.push(new tt().compose(new D(y-Fe/2+.15+a()*.7,0,m-Fe/2+.15+a()*.7),l,new D(A,A*(.8+a()*.6),A)))}if(a()<u){const x=new Ce(h[Math.floor(a()*h.length)]);o.push({m:new tt().makeTranslation(y-Fe/2+.2+a()*.6,.09,m-Fe/2+.2+a()*.6),c:x})}}const f=qi[this.theme]||qi.haven,g=f.flora==="pebbles";if(g&&(o.length=0),r.length){const y=g?new ji(.06,0):new Nn(.045,.2,3);y.translate(0,g?.03:.1,0);const m=new Rr(y,new $t({color:g?f.peb:f.grass||"#5fb04a",flatShading:!0,roughness:.9,emissive:f.glow&&f.grass||"#000000",emissiveIntensity:f.glow?.9:0}),r.length);r.forEach((p,x)=>m.setMatrixAt(x,p)),m.receiveShadow=!0,this.group.add(m),this.flora.push(m)}if(o.length){const y=new qn(.045,0),m=new Rr(y,new $t({color:"#ffffff",roughness:.6,emissive:f.glow?"#888888":"#222222"}),o.length);o.forEach((p,x)=>{m.setMatrixAt(x,p.m),m.setColorAt(x,p.c)}),this.group.add(m),this.flora.push(m)}}update(e){if(this.debris){const t=new tt,n=new Ui,s=new Wn,a=new D;this.dInfo.forEach((r,o)=>{s.set(r.r+e*.1,r.r*2+e*.07,0),n.setFromEuler(s),a.setScalar(r.s),t.compose(new D(r.p.x,r.p.y+Math.sin(e*.4+r.ph)*.4,r.p.z),n,a),this.debris.setMatrixAt(o,t)}),this.debris.instanceMatrix.needsUpdate=!0}this.holo.children.forEach(t=>{const n=t.material;n&&"opacity"in n&&t.userData.plot&&(n.opacity=.05+Math.sin(e*2)*.025)})}}function Wb(i){i.traverse(e=>{const t=e;t.geometry&&t.geometry.dispose()})}function Xb(i,e=!1){const t=i[0].index!==null,n=new Set(Object.keys(i[0].attributes)),s=new Set(Object.keys(i[0].morphAttributes)),a={},r={},o=i[0].morphTargetsRelative,l=new bt;l.morphTargetsRelative=o;let c=0;for(let d=0;d<i.length;++d){const h=i[d];let u=0,f=0;if(t!==(h.index!==null))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+d+". All geometries must have compatible attributes; make sure index attribute exists among all geometries, or in none of them."),null;for(const g in h.attributes){if(!n.has(g))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+d+'. All geometries must have compatible attributes; make sure "'+g+'" attribute exists among all geometries, or in none of them.'),null;a[g]===void 0&&(a[g]=[]),a[g].push(h.attributes[g]),u++}if(u!==n.size)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+d+". Make sure all geometries have the same number of attributes."),null;if(o!==h.morphTargetsRelative)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+d+". .morphTargetsRelative must be consistent throughout all geometries."),null;for(const g in h.morphAttributes){if(!s.has(g))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+d+".  .morphAttributes must be consistent throughout all geometries."),null;if(h.morphAttributes[g].length!==i[0].morphAttributes[g].length)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+d+'. All geometries must have the same number of morph targets for the "'+g+'" morph attribute.'),null;r[g]===void 0&&(r[g]=[]),r[g].push(h.morphAttributes[g]),f++}if(f!==s.size)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+d+". Make sure all geometries have the same number of morph attributes."),null;if(e){let g;if(t)g=h.index.count;else if(h.attributes.position!==void 0)g=h.attributes.position.count;else return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+d+". The geometry must have either an index or a position attribute"),null;l.addGroup(c,g,d),c+=g}}if(t){let d=0;const h=[];for(let u=0;u<i.length;++u){const f=i[u].index;for(let g=0;g<f.count;++g)h.push(f.getX(g)+d);d+=i[u].attributes.position.count}l.setIndex(h)}for(const d in a){const h=uu(a[d]);if(!h)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+d+" attribute."),null;l.setAttribute(d,h)}for(const d in r){const h=r[d][0].length;if(h!==0){l.morphAttributes=l.morphAttributes||{},l.morphAttributes[d]=[];for(let u=0;u<h;++u){const f=[];for(let y=0;y<r[d].length;++y)f.push(r[d][y][u]);const g=uu(f);if(!g)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+d+" morphAttribute."),null;l.morphAttributes[d].push(g)}}}return l}function uu(i){let e,t,n,s=-1,a=0;for(let c=0;c<i.length;++c){const d=i[c];if(e===void 0&&(e=d.array.constructor),e!==d.array.constructor)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.array must be of consistent array types across matching attributes."),null;if(t===void 0&&(t=d.itemSize),t!==d.itemSize)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.itemSize must be consistent across matching attributes."),null;if(n===void 0&&(n=d.normalized),n!==d.normalized)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.normalized must be consistent across matching attributes."),null;if(s===-1&&(s=d.gpuType),s!==d.gpuType)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.gpuType must be consistent across matching attributes."),null;a+=d.count*t}const r=new e(a),o=new Ft(r,t,n);let l=0;for(let c=0;c<i.length;++c){const d=i[c];if(d.isInterleavedBufferAttribute){const h=l/t;for(let u=0,f=d.count;u<f;u++)for(let g=0;g<t;g++){const y=d.getComponent(u,g);o.setComponent(u+h,g,y)}}else r.set(d.array,l);l+=d.count*t}return s!==void 0&&(o.gpuType=s),o}const $r=new Ce,Oa={body:new $t({vertexColors:!0,flatShading:!0,roughness:.62,metalness:.12}),glow:new ct({vertexColors:!0,toneMapped:!1}),glass:new $t({vertexColors:!0,transparent:!0,opacity:.38,roughness:.08,metalness:.2,depthWrite:!1}),ghostOk:new ct({color:6160282,transparent:!0,opacity:.45,depthWrite:!1}),ghostBad:new ct({color:16734826,transparent:!0,opacity:.45,depthWrite:!1})};class Pt{constructor(){this.parts={body:[],glow:[],glass:[]}}add(e,t,n=0,s=0,a=0,r={}){let o=e.index?e.toNonIndexed():e.clone();o.attributes.uv&&o.deleteAttribute("uv"),o.attributes.uv1&&o.deleteAttribute("uv1");const l=new tt().compose(new D(n,s,a),new Ui().setFromEuler(new Wn(r.rx||0,r.ry||0,r.rz||0)),new D(r.sx??1,r.sy??1,r.sz??1));o.applyMatrix4(l),$r.set(t);const c=o.attributes.position.count,d=new Float32Array(c*3);for(let h=0;h<c;h++)d[h*3]=$r.r,d[h*3+1]=$r.g,d[h*3+2]=$r.b;return o.setAttribute("color",new Ft(d,3)),this.parts[r.glow?"glow":r.glass?"glass":"body"].push(o),e.dispose(),this}box(e,t,n,s,a=0,r=0,o=0,l={}){return this.add(new Xn(e,t,n),s,a,r+t/2,o,l)}cyl(e,t,n,s,a,r=0,o=0,l=0,c={}){return this.add(new yn(e,t,n,s),a,r,o+n/2,l,c)}sphere(e,t,n=0,s=0,a=0,r={}){return this.add(new Nt(e,r.w||10,r.h||7,0,Math.PI*2,0,r.theta||Math.PI),t,n,s,a,r)}build(e=""){const t=new _t;t.name=e;for(const n of["body","glow","glass"]){const s=this.parts[n];if(!s.length)continue;const a=Xb(s,!1);if(s.forEach(o=>o.dispose()),!a)continue;const r=new Te(a,Oa[n]);r.castShadow=n==="body",r.receiveShadow=n==="body",r.userData.bucket=n,t.add(r)}return t}}const An=(i,e)=>{const t=new Ce(i);return e<0?t.lerp(new Ce(0),-e):t.lerp(new Ce(16777215),e),"#"+t.getHexString()},Wc=(i,e,t)=>"#"+new Ce(i).lerp(new Ce(e),t).getHexString(),Be={solar:{name:"Solar",color:"#ffb23e",glow:"#ffe08a",glyph:"☀",strong:["bio","cryo"],blurb:"Runs on starlight. Hums when the Sun is up."},plasma:{name:"Plasma",color:"#ff5a3c",glow:"#ffb08a",glyph:"♨",strong:["alloy","bio"],blurb:"Contained fire at ten thousand degrees."},hydro:{name:"Hydro",color:"#2f8cff",glow:"#9fd0ff",glyph:"≈",strong:["plasma","geo"],blurb:"Pumps, cleans and cools. Every colony needs water."},cryo:{name:"Cryo",color:"#7fe4ff",glow:"#dff8ff",glyph:"❄",strong:["aero","bio"],blurb:"Supercooled circuits, near absolute zero."},geo:{name:"Geo",color:"#b07a4a",glow:"#e2b48c",glyph:"▲",strong:["volt","plasma"],blurb:"Drills, diggers and regolith movers."},bio:{name:"Bio",color:"#4fcf5a",glow:"#b6ffb0",glyph:"❦",strong:["hydro","geo"],blurb:"Gardeners of greenhouses and living hulls."},volt:{name:"Volt",color:"#ffe23a",glow:"#fff6a8",glyph:"ϟ",strong:["hydro","aero"],blurb:"Lightning in a capacitor."},alloy:{name:"Alloy",color:"#9aa7b8",glow:"#e6edf5",glyph:"⚙",strong:["cryo","kinetic"],blurb:"Armour, welders and heavy lifting."},void:{name:"Void",color:"#6b3fd6",glow:"#c2a6ff",glyph:"◐",strong:["photon","neural"],blurb:"Built for the dark between stars."},photon:{name:"Photon",color:"#fff4c2",glow:"#ffffff",glyph:"✦",strong:["void","chrono"],blurb:"Lasers, lenses and light."},kinetic:{name:"Kinetic",color:"#ff7a1a",glow:"#ffc28a",glyph:"✊",strong:["alloy","gravity"],blurb:"Impact, momentum, mass drivers."},aero:{name:"Aero",color:"#b9f0e6",glow:"#ecfffb",glyph:"༄",strong:["geo","kinetic"],blurb:"Flyers and atmosphere shapers."},gravity:{name:"Gravity",color:"#3c4aa8",glow:"#9aa6ff",glyph:"◉",strong:["aero","photon"],blurb:"Bends space a little, on purpose."},chrono:{name:"Chrono",color:"#c9a2ff",glow:"#eedcff",glyph:"⧗",strong:["neural","volt"],blurb:"Clocks running a little sideways."},neural:{name:"Neural",color:"#ff6fd8",glow:"#ffc4f0",glyph:"✺",strong:["kinetic","gravity"],blurb:"Artificial minds. They learn from everything."},relic:{name:"Relic",color:"#d8b46a",glow:"#fff0c4",glyph:"⌬",relic:!0,strong:[],blurb:"Precursor make, older than our species."},aurora:{name:"Aurora",color:"#6fffc8",glow:"#d6fff0",glyph:"❈",relic:!0,strong:[],blurb:"Beauty as a power source."},arcana:{name:"Arcana",color:"#8a5cff",glow:"#d7c6ff",glyph:"✧",relic:!0,strong:[],blurb:"Technology indistinguishable from magic."},entropy:{name:"Entropy",color:"#ff3d6e",glow:"#ffb3c6",glyph:"✹",relic:!0,strong:[],blurb:"Chaos, harnessed."},joy:{name:"Joy",color:"#ffd24a",glow:"#fff2b8",glyph:"☺",relic:!0,strong:[],blurb:"Precursor machines made to be happy."},reverie:{name:"Reverie",color:"#7aa8ff",glow:"#d2e2ff",glyph:"☾",relic:!0,strong:[],blurb:"They dream in mathematics."},soul:{name:"Soul",color:"#f2f2ff",glow:"#ffffff",glyph:"❂",relic:!0,strong:[],blurb:"Something in them is alive."}},qb=Object.keys(Be).filter(i=>!Be[i].relic),Qn="#2c3340",Hr="#cdd5df";function jo(i,e=1){const t=Q[i],n=Be[t.el[0]].color,s=t.el[1]?Be[t.el[1]].color:An(n,-.35),a=We[t.rarity].color,r=new _t,o=new Pt;let l=0;const c=y=>(r.add(y),y),d=y=>{const m=new Pt;return y(m),m.build()};let h=()=>{};switch(t.chassis){case"orb":{l=.55,o.sphere(.26,n,0,0,0,{w:14,h:10}),o.sphere(.27,s,0,0,0,{w:14,h:4,theta:Math.PI*.18}),o.sphere(.09,a,0,.02,.22,{glow:!0,w:8,h:6}),o.sphere(.05,"#ffffff",.02,.05,.27,{glow:!0,w:6,h:4});const y=c(d(m=>m.add(new an(.38,.025,5,28),s)));y.rotation.x=Math.PI/2.4,h=m=>{y.rotation.z=m*1.8};break}case"drone":{l=.6,o.box(.34,.14,.34,n,0,-.07,0),o.sphere(.16,s,0,.05,0,{theta:Math.PI/2,w:10,h:5}),o.box(.12,.05,.02,a,0,-.01,.18,{glow:!0});const y=[];for(const[m,p]of[[.28,.28],[-.28,.28],[.28,-.28],[-.28,-.28]]){o.box(.24,.03,.04,Qn,m/2,0,p/2,{ry:Math.atan2(m,p)});const x=c(d(A=>{A.cyl(.13,.13,.012,10,Hr,0,0,0,{glass:!0}),A.box(.24,.01,.03,Qn)}));x.position.set(m,.02,p),y.push(x)}h=m=>y.forEach((p,x)=>{p.rotation.y=m*30*(x%2?1:-1)});break}case"rover":{o.box(.5,.18,.36,n,0,.12,0),o.box(.3,.1,.3,s,-.05,.3,0),o.cyl(.02,.02,.22,5,Hr,.12,.3,0),o.box(.14,.08,.08,Qn,.12,.52,0),o.box(.02,.04,.06,a,.19,.53,0,{glow:!0});const y=[];for(const[m,p]of[[.17,.2],[-.17,.2],[.17,-.2],[-.17,-.2]]){const x=c(d(A=>A.cyl(.09,.09,.07,10,Qn,0,-.035,0,{rx:Math.PI/2})));x.position.set(m,.09,p),y.push(x)}i==="digger"&&o.add(new Nn(.08,.22,7),Hr,.32,.18,0,{rz:-Math.PI/2}),i==="ember"&&o.cyl(.035,.035,.2,5,Qn,.25,.28,0,{rz:-.9}),h=(m,p)=>y.forEach(x=>{x.rotation.z=p?-m*8:0});break}case"walker":{const y=c(d(p=>{p.box(.36,.22,.3,n,0,0,0),p.box(.3,.06,.26,s,0,.22,0),p.box(.14,.05,.02,a,.06,.12,.16,{glow:!0}),p.box(.06,.05,.02,a,-.08,.12,.16,{glow:!0})}));y.position.y=.34;const m=[];for(const p of[.11,-.11]){const x=c(d(A=>{A.box(.07,.32,.07,Qn,0,-.32,0),A.box(.13,.04,.16,s,0,-.34,.02)}));x.position.set(p,.36,0),m.push(x)}h=(p,x)=>{m.forEach((A,b)=>{A.rotation.x=x?Math.sin(p*9+b*Math.PI)*.5:0}),y.position.y=.34+(x?Math.abs(Math.sin(p*9))*.03:0)};break}case"android":{const y=c(d(p=>{p.box(.24,.3,.16,n,0,0,0),p.box(.26,.06,.18,s,0,.24,0),p.sphere(.12,Hr,0,.42,0,{w:10,h:8}),p.box(.18,.05,.05,a,0,.43,.09,{glow:!0}),p.sphere(.035,a,0,.12,.085,{glow:!0,w:6,h:4})}));y.position.y=.3;const m=[];for(const[p,x,A,b]of[[.16,.56,.26,s],[-.16,.56,.26,s],[.07,.3,.3,Qn],[-.07,.3,.3,Qn]]){const E=c(d(S=>S.box(.07,A,.07,b,0,-A,0)));E.position.set(p,x,0),m.push(E)}i==="sprout"&&o.add(new qn(.08,0),"#5fdc5a",0,.86,0),h=(p,x)=>{m.forEach((A,b)=>{A.rotation.x=x?Math.sin(p*8+b%2*Math.PI+(b>1?Math.PI:0))*.55:Math.sin(p*1.5+b)*.05})};break}case"mech":{const y=c(d(p=>{p.box(.46,.34,.34,n,0,0,0),p.box(.2,.12,.2,s,0,.34,0),p.box(.16,.05,.02,a,0,.4,.105,{glow:!0});for(const x of[.29,-.29])p.box(.14,.14,.2,s,x,.16,0),p.box(.11,.3,.11,Qn,x,-.14,.02)}));y.position.y=.36;const m=[];for(const p of[.13,-.13]){const x=c(d(A=>{A.box(.12,.34,.12,Qn,0,-.34,0),A.box(.18,.05,.22,s,0,-.36,.02)}));x.position.set(p,.38,0),m.push(x)}h=(p,x)=>{m.forEach((A,b)=>{A.rotation.x=x?Math.sin(p*5+b*Math.PI)*.35:0}),y.rotation.y=x?Math.sin(p*5)*.06:0};break}case"crawler":{const y=c(d(p=>{p.sphere(.16,n,.18,0,0,{w:10,h:7}),p.sphere(.13,s,0,0,0,{w:10,h:7}),p.sphere(.11,n,-.16,0,0,{w:10,h:7}),p.sphere(.035,a,.31,.04,.06,{glow:!0,w:6,h:4}),p.sphere(.035,a,.31,.04,-.06,{glow:!0,w:6,h:4})}));y.position.y=.2;const m=[];for(let p=0;p<6;p++){const x=.16-(p>>1)*.16,A=p%2?1:-1,b=c(d(E=>E.box(.03,.03,.24,Qn,0,0,.1*A)));b.position.set(x,.18,.08*A),b.rotation.x=.5*A,m.push(b)}h=(p,x)=>m.forEach((A,b)=>{A.rotation.y=x?Math.sin(p*14+b)*.35:0});break}}const u=o.build("bot");r.add(u),(t.chassis==="orb"||t.chassis==="drone")&&(u.position.y=0);const f=new _t;for(;r.children.length;)f.add(r.children[0]);if(f.position.y=l,r.add(f),l){const y=new Te(new qo(.22,12),new ct({color:Be[t.el[0]].glow,transparent:!0,opacity:.35,depthWrite:!1}));y.rotation.x=-Math.PI/2,y.position.y=.02,y.name="hoverGlow",r.add(y)}const g=.95+Ct.indexOf(t.rarity)*.08+Math.min(.25,(e-1)*.008);return r.scale.setScalar(g),r.traverse(y=>{y.isMesh&&(y.castShadow=!0)}),{group:r,hover:l,anim:(y,m)=>{h(y,m),l&&(f.position.y=l+Math.sin(y*2.2+e)*.05)}}}const Sn="#c8d0da",tn="#3a4250",ca="#bfe9ff",gs="#ffe9a8";function nn(i,e){return new Te(i,new ct({color:e,toneMapped:!1}))}function Qo(i,e=.7,t=.45){const n=Yb(i.banner),s=new Fi(e,t,8,1);s.translate(e/2,0,0);const a=new Te(s,new $t({map:n,side:Mn,roughness:.8}));a.castShadow=!0;const r=s.attributes.position.array.slice();return a.userData.wave=o=>{const l=s.attributes.position.array;for(let c=0;c<l.length;c+=3){const d=r[c];l[c+2]=Math.sin(d*7-o*4)*.06*(d/e)}s.attributes.position.needsUpdate=!0},a}const da=new Map;function Yb(i){const e=i.bg+i.fg+i.emblem,t=da.get(e);if(t)return t;const n=document.createElement("canvas");n.width=128,n.height=80;const s=n.getContext("2d");s.fillStyle=i.bg,s.fillRect(0,0,128,80),s.fillStyle=An(i.bg,-.25),s.fillRect(0,64,128,16),s.fillStyle=i.fg,s.translate(64,36),Ya(s,i.emblem,22),s.fill(Ka(i.emblem));const a=new nr(n);return a.colorSpace=zt,da.set(e,a),a}function Ya(i,e,t){if(i.beginPath(),e==="star")for(let n=0;n<10;n++){const s=-Math.PI/2+n*Math.PI/5,a=n%2?t*.45:t;i.lineTo(Math.cos(s)*a,Math.sin(s)*a)}else if(e==="planet")i.arc(0,0,t*.6,0,7),i.moveTo(t,0),i.ellipse(0,0,t,t*.28,-.3,0,7);else if(e==="bolt")i.moveTo(t*.2,-t),i.lineTo(-t*.5,t*.1),i.lineTo(0,t*.1),i.lineTo(-t*.2,t),i.lineTo(t*.5,-t*.1),i.lineTo(0,-t*.1);else if(e==="gear")for(let n=0;n<16;n++){const s=n*Math.PI/8,a=n%2?t*.7:t;i.lineTo(Math.cos(s)*a,Math.sin(s)*a)}else if(e==="rocket")i.moveTo(0,-t),i.quadraticCurveTo(t*.45,-t*.3,t*.3,t*.5),i.lineTo(t*.6,t),i.lineTo(-t*.6,t),i.lineTo(-t*.3,t*.5),i.quadraticCurveTo(-t*.45,-t*.3,0,-t);else if(e==="crown")i.moveTo(-t*.9,t*.7),i.lineTo(-t*.95,-t*.55),i.lineTo(-t*.45,-t*.05),i.lineTo(0,-t*.8),i.lineTo(t*.45,-t*.05),i.lineTo(t*.95,-t*.55),i.lineTo(t*.9,t*.7);else if(e==="atom"){for(let n=0;n<3;n++){const s=n*Math.PI/3;i.moveTo(Math.cos(s)*t,Math.sin(s)*t),i.ellipse(0,0,t,t*.3,s,0,Math.PI*2),i.moveTo(Math.cos(s)*t*.84,Math.sin(s)*t*.84),i.ellipse(0,0,t*.84,t*.17,s,0,Math.PI*2,!0)}i.moveTo(t*.22,0),i.arc(0,0,t*.22,0,Math.PI*2)}else if(e==="leaf")i.moveTo(-t*.75,t*.75),i.quadraticCurveTo(-t*.9,-t*.6,t*.8,-t*.85),i.quadraticCurveTo(t*.7,t*.75,-t*.6,t*.6),i.lineTo(-t*.9,t*.95),i.lineTo(-t*.95,t*.88);else if(e==="eye")i.moveTo(-t,0),i.quadraticCurveTo(0,-t*.95,t,0),i.quadraticCurveTo(0,t*.95,-t,0),i.moveTo(t*.42,0),i.arc(0,0,t*.42,0,Math.PI*2,!0),i.moveTo(t*.2,0),i.arc(0,0,t*.2,0,Math.PI*2);else if(e==="chip"){const n=t*.62;i.rect(-n,-n,n*2,n*2),i.moveTo(-n*.5,-n*.5),i.lineTo(-n*.5,n*.5),i.lineTo(n*.5,n*.5),i.lineTo(n*.5,-n*.5),i.closePath();for(let s=-1;s<=1;s++){const a=s*n*.6-t*.07;i.rect(a,-t,t*.14,t-n),i.rect(a,n,t*.14,t-n),i.rect(-t,a,t-n,t*.14),i.rect(n,a,t-n,t*.14)}}else e==="gem"?(i.moveTo(-t*.85,-t*.3),i.lineTo(-t*.45,-t*.78),i.lineTo(t*.45,-t*.78),i.lineTo(t*.85,-t*.3),i.lineTo(0,t*.92)):i.arc(0,0,t*.8,0,7);i.closePath()}const Ka=i=>i==="atom"||i==="eye"||i==="chip"?"evenodd":"nonzero";function Kb(i,e){const t=new Pt,n=e.primary,s=e.accent,a=Math.min(5,1+Math.floor((i-1)/3));t.cyl(1.95,1.95,.28,8,An(n,-.18),0,0,0,{ry:Math.PI/8}),t.cyl(1.88,1.88,.05,8,s,0,.28,0,{ry:Math.PI/8,glow:!0});const r=1.25;for(const[y,m]of[[r,r],[-r,r],[r,-r],[-r,-r]]){const p=.55+Math.min(.5,i*.04);t.box(.85,p,.85,n,y,.33,m),t.box(.87,.07,.87,s,y,.33+p,m),t.box(.6,.09,.02,gs,y,.33+p*.55,m+.43,{glow:!0}),t.box(.02,.09,.6,gs,y+.43*Math.sign(y),.33+p*.55,m,{glow:!0})}let o=.33,l=1.15;for(let y=0;y<a;y++){const m=.62-y*.04;t.cyl(l,l*1.04,m,12,y%2?An(n,-.08):n,0,o,0),t.cyl(l*1.03,l*1.03,.06,12,s,0,o+m-.12,0,{glow:y===a-1});for(let p=0;p<8;p++){const x=p/8*Math.PI*2;t.box(.18,.12,.02,gs,Math.cos(x)*l*1.02,o+m*.45,Math.sin(x)*l*1.02,{ry:-x+Math.PI/2,glow:!0})}o+=m,l*=.84}t.sphere(l*1.05,ca,0,o,0,{theta:Math.PI/2,w:14,h:6,glass:!0}),t.sphere(l*.45,s,0,o+.05,0,{glow:!0,w:8,h:5}),i>=5&&(t.cyl(.62,.62,.05,10,tn,1.35,.3,-1.35),t.cyl(.5,.5,.06,10,"#ffcc33",1.35,.3,-1.35),t.cyl(.42,.42,.07,10,tn,1.35,.3,-1.35)),i>=8&&(t.cyl(.05,.08,.6,6,Sn,-1.25,.95+Math.min(.5,i*.04),1.25),t.sphere(.32,Sn,-1.25,1.62+Math.min(.5,i*.04),1.25,{theta:Math.PI/2,rx:Math.PI*.75}));const c=t.build("command"),d=o+l*1.05,h=new Te(new yn(.02,.035,.9,5),Oa.body);h.position.set(0,d+.45,0),h.geometry.setAttribute("color",new Ft(new Float32Array(h.geometry.attributes.position.count*3).fill(.8),3)),c.add(h);const u=nn(new Nt(.07,8,6),"#ff4a4a");u.position.set(0,d+.92,0),c.add(u);const f=new Te(new yn(.025,.025,1.5,5),new $t({color:Sn}));f.position.set(-1.7,1.03,-1.7),f.castShadow=!0,c.add(f);const g=Qo(e);return g.position.set(-1.68,1.55,-1.7),c.add(g),{group:c,height:d+1,anim:y=>{u.material.color.set(Math.sin(y*3)>0?"#ff4a4a":"#3a0a0a"),g.userData.wave(y)}}}function Zb(i,e){const t=new Pt,n=e.primary,s=e.accent,a=Math.min(4,1+Math.floor((i-1)/3));t.cyl(1.9,1.95,.3,6,An(n,-.2),0,0,0,{ry:Math.PI/6}),t.cyl(1.82,1.82,.05,6,s,0,.3,0,{ry:Math.PI/6,glow:!0});for(let d=0;d<6;d++){const h=d/6*Math.PI*2;t.cyl(.42,.42,.55+Math.min(.4,i*.03),10,n,Math.cos(h)*1.25,.3,Math.sin(h)*1.25),t.sphere(.42,ca,Math.cos(h)*1.25,.85+Math.min(.4,i*.03),Math.sin(h)*1.25,{theta:Math.PI/2,w:10,h:5,glass:!0})}let r=.3;for(let d=0;d<a;d++)t.cyl(.95-d*.12,1-d*.12,.5,14,d%2?An(n,-.1):n,0,r,0),t.cyl(.98-d*.12,.98-d*.12,.06,14,s,0,r+.42,0,{glow:d===a-1}),r+=.5;t.sphere(.62,ca,0,r,0,{theta:Math.PI/2,w:14,h:6,glass:!0}),t.sphere(.25,s,0,r+.05,0,{glow:!0,w:8,h:5});const o=t.build("hub"),l=new Te(new yn(.025,.025,1.4,5),new $t({color:Sn}));l.position.set(-1.6,1,-1.2),o.add(l);const c=Qo(e);return c.position.set(-1.58,1.5,-1.2),o.add(c),{group:o,height:r+.9,anim:d=>c.userData.wave(d)}}function Jb(i,e,t){const n=new Pt,s=t.primary,a=(Be[e]||Be.solar).color,r=(Be[e]||Be.solar).glow;n.cyl(1.42,1.48,.22,6,An(s,-.12),0,0,0,{ry:Math.PI/6}),n.cyl(1.36,1.36,.04,6,Wc(s,a,.35),0,.22,0,{ry:Math.PI/6}),n.cyl(.62,.62,.03,16,a,0,.26,0,{glow:!0}),n.cyl(.5,.5,.035,16,An(a,-.5),0,.26,0);const o=i>=4?6:3,l=.7+Math.min(.8,i*.07);for(let u=0;u<o;u++){const f=u/o*Math.PI*2+Math.PI/6,g=Math.cos(f)*1.18,y=Math.sin(f)*1.18;n.box(.16,l,.16,s,g,.26,y,{ry:-f}),n.box(.2,.08,.2,fu(t),g,.26+l,y,{ry:-f}),n.box(.06,l*.6,.02,a,g*.99,.26+l*.25,y*.99,{ry:-f+Math.PI/2,glow:!0})}i>=4&&n.add(new an(1.18,.05,6,24),fu(t),0,.26+l+.06,0,{rx:Math.PI/2}),i>=7&&n.sphere(1.25,Wc(r,"#ffffff",.4),0,.26,0,{theta:Math.PI/2,w:18,h:8,glass:!0});const c=2+Math.floor((i-1)/3);for(let u=0;u<c;u++){const f=u/c*Math.PI*2+.4;n.cyl(.17,.17,.03,8,An(a,.2),Math.cos(f)*.86,.26,Math.sin(f)*.86,{glow:!0})}const d=n.build("bay"),h=nn(new pi(.18,0),r);return h.position.y=.26+l+.45,h.material.transparent=!0,h.material.opacity=.85,d.add(h),{group:d,height:.26+l+.7,anim:u=>{h.rotation.y=u*1.4,h.position.y=.26+l+.45+Math.sin(u*2)*.06}}}const fu=i=>i.accent;function jb(i,e){const t=new Pt,n=e.primary,s=e.accent,a="#9dff5a";t.box(2.7,.18,2.7,An(n,-.2),0,0,0),t.box(1.7,1+Math.min(.4,i*.04),1.5,n,-.35,.18,-.4),t.box(1.74,.1,1.54,s,-.35,1.18+Math.min(.4,i*.04),-.4),t.box(1,.12,.02,gs,-.35,.75,.36,{glow:!0}),t.box(.4,.55,.03,tn,.25,.18,.36);const r=1+Math.min(3,Math.floor(i/3));for(let f=0;f<r;f++)t.cyl(.13,.16,.7+f*.1,8,Sn,-.9+f*.38,1.28,-.85),t.cyl(.15,.15,.06,8,s,-.9+f*.38,1.9+f*.1,-.85);t.box(2.2,.12,.4,tn,0,.18,.95);for(let f=0;f<5;f++)t.box(.18,.18,.22,a,-.8+f*.4,.3,.95,{glow:!0});const o=t.build("fab"),l=new Pt;l.cyl(.42,.42,1.25,14,ca,0,0,0,{glass:!0}),l.cyl(.46,.46,.08,14,s,0,1.25,0),l.cyl(.46,.46,.1,14,Sn,0,-.02,0);const c=l.build("tank");c.position.set(.85,.18,-.55),o.add(c);const d=nn(new yn(.36,.36,1,14),a);d.geometry.translate(0,.5,0),d.position.set(.85,.22,-.55),o.add(d);const h=new _t,u=new Pt;return u.box(.1,.6,.1,"#ffb23e",0,0,0),u.box(.5,.08,.08,"#ffb23e",.22,.56,0),u.box(.08,.18,.08,tn,.45,.4,0),h.add(u.build()),h.position.set(.95,.3,.6),o.add(h),{group:o,height:2.1,anim:(f,g)=>{const y=g.ready?1:g.working?.15+.7*(f*.08%1):.08;d.scale.y=xo.lerp(d.scale.y||.1,y*1.2,.08),h.rotation.y=g.working?Math.sin(f*2.4)*.9:0,d.material.color.set(g.ready&&Math.sin(f*5)>0?"#c8ff7a":a)}}}function Qb(i,e){const t=new Pt,n=e.primary,s=e.accent,a=Math.min(3,1+Math.floor((i-1)/3));t.box(2.8,.2,2.8,An(n,-.2),0,0,0),t.box(2.6,.05,.4,"#ffcc33",0,.2,1.05),t.box(2,.6,.7,n,0,.2,-.95),t.box(2.04,.06,.74,s,0,.8,-.95),t.box(1.4,.1,.02,gs,0,.55,-.59,{glow:!0});const r=[-.85,0,.85];for(let h=0;h<3;h++){const u=h<a;t.cyl(.36,.4,.14,12,u?Sn:tn,r[h],.2,.15),u&&(t.cyl(.32,.32,.9,12,ca,r[h],.34,.15,{glass:!0}),t.cyl(.36,.36,.08,12,s,r[h],1.24,.15))}const o=t.build("assembly"),l=new _t,c=new Pt;c.box(.08,1.5,.08,"#ffb23e",-1.3,0,-.3),c.box(2.7,.08,.08,"#ffb23e",0,1.5,-.3),c.box(.12,.3,.12,tn,0,1.22,-.3),l.add(c.build()),l.position.y=.2,o.add(l);const d=[];for(let h=0;h<3;h++){const u=nn(new qn(.17,1),"#ffffff");u.position.set(r[h],.8,.15),u.visible=!1,o.add(u),d.push(u)}return{group:o,height:1.8,anim:(h,u)=>{const f=u.cores||[];d.forEach((g,y)=>{const m=f[y];if(g.visible=!!m&&y<a,!m)return;g.material.color.set(m.color),g.rotation.y=h*(m.ready?3:1.2),g.rotation.x=h*.7;const p=m.ready?1+Math.sin(h*6)*.15:.85+Math.sin(h*2+y)*.08;g.scale.setScalar(p),g.position.y=.8+Math.sin(h*1.5+y)*.05}),l.position.x=f.some(g=>!g.ready)?Math.sin(h*.9)*.8:l.position.x*.95}}}function e_(i,e){const t=new Pt,n=e.primary,s=e.accent;t.box(3.8,.22,2.8,An(n,-.2),0,0,0),t.box(3.6,.04,.3,s,0,.22,1.15,{glow:!0});for(const h of[-1.25,1.25])t.cyl(.62,.7,.35,12,n,h,.22,0),t.cyl(.66,.66,.06,12,s,h,.57,0),t.sphere(.58,ca,h,.62,0,{theta:Math.PI/2,w:16,h:7,glass:!0}),t.cyl(.4,.4,.03,14,"#b06dff",h,.6,0,{glow:!0});t.cyl(.22,.3,1+Math.min(.4,i*.04),10,Sn,0,.22,0),t.box(2,.12,.18,tn,0,.62,0),t.box(.7,.5,.6,n,0,.22,-.95),t.box(.5,.08,.02,gs,0,.5,-.64,{glow:!0});const a=t.build("fusion"),r=1.25+Math.min(.4,i*.04),o=new _t,l=new Pt;l.add(new an(.55,.07,8,32),s),l.add(new an(.42,.03,6,28),"#b06dff",0,0,0,{glow:!0}),o.add(l.build()),o.position.y=r,a.add(o);const c=nn(new qn(.16,1),"#e2c8ff");c.position.y=r,a.add(c);const d=nn(new yn(.035,.035,2.5,6),"#d6b8ff");return d.rotation.z=Math.PI/2,d.position.y=.95,d.visible=!1,a.add(d),{group:a,height:r+.6,anim:(h,u)=>{o.rotation.x=Math.PI/2+Math.sin(h*.5)*.2,o.rotation.z=h*(u.working?4:.4),c.scale.setScalar(u.working?1+Math.sin(h*9)*.25:.7),d.visible=!!u.working,d.scale.x=1+Math.sin(h*20)*.3,c.material.color.set(u.ready?"#fff2a8":"#e2c8ff")}}}function t_(i,e){const t=new Pt,n=e.primary,s=e.accent;t.cyl(1.9,2,.25,24,An(n,-.2),0,0,0),t.cyl(1.7,1.7,.04,32,"#2a3446",0,.25,0),t.add(new an(1.7,.05,6,48),s,0,.29,0,{rx:Math.PI/2,glow:!0});for(const[d,h]of[[-.8,"#4aa8ff"],[.8,"#ff5a6a"]])t.cyl(.42,.42,.03,18,h,d,.29,0,{glow:!0});const a=6+Math.min(6,i);for(let d=0;d<a;d++){const h=d/a*Math.PI*2;t.box(.14,.9+d%2*.3,.14,n,Math.cos(h)*1.75,.25,Math.sin(h)*1.75),t.box(.17,.08,.17,s,Math.cos(h)*1.75,1.15+d%2*.3,Math.sin(h)*1.75,{glow:!0})}const r=t.build("arena"),o=new Te(new an(1.25,.04,6,48),new ct({color:"#7af7ff",toneMapped:!1,transparent:!0,opacity:.85}));o.position.y=1.5,o.rotation.x=Math.PI/2,r.add(o);const l=Qo(e,.55,.34);l.position.set(.02,2,0);const c=new Te(new yn(.02,.02,1,5),new $t({color:Sn}));return c.position.set(0,1.7,0),r.add(c,l),{group:r,height:2.3,anim:d=>{o.rotation.z=d*.8,o.position.y=1.4+Math.sin(d*1.5)*.1,l.userData.wave(d)}}}function ap(i){const e=new Pt,t=1.3+i*.35,n=.2+i*.03;if(e.cyl(n,n,t,12,"#f2f4f7",0,.2),e.add(new Nn(n,.5+i*.08,12),"#ff7a3c",0,.2+t+.25+i*.04,0),e.cyl(n*1.02,n*1.02,.08,12,"#2c3340",0,.2+t*.6),i>=3)for(const s of[-1,1])e.cyl(n*.45,n*.45,t*.6,10,"#e6e9ee",s*n*1.5,.2),e.add(new Nn(n*.45,.25,10),"#ff7a3c",s*n*1.5,.2+t*.6+.12,0);for(let s=0;s<4;s++){const a=s/4*Math.PI*2;e.box(.04,.35,.22,"#ff7a3c",Math.cos(a)*n,.2,Math.sin(a)*n,{ry:-a})}return e.cyl(n*.7,n*.9,.2,10,"#3a4250",0,0),{group:e.build("rocket"),height:.2+t+.7}}function n_(i,e,t){const n=new Pt,s=e.primary,a=e.accent,r=i>=9?4:i>=6?3:i>=3?2:1;n.box(2.8,.25,2.8,An(s,-.25),0,0,0),n.cyl(.95,.95,.06,20,"#2c3340",0,.25,0),n.cyl(.8,.8,.065,20,"#ffcc33",0,.25,0),n.cyl(.66,.66,.07,20,"#2c3340",0,.25,0);const o=2.2+r*.4;n.box(.3,o,.3,s,-1.05,.25,-1);for(let d=.6;d<o;d+=.5)n.box(.62,.05,.05,a,-.78,.25+d,-1);n.box(.36,.1,.36,a,-1.05,.25+o,-1,{glow:!0}),n.box(.7,.4,.5,s,1,.25,1),n.box(.5,.08,.02,gs,1,.45,1.26,{glow:!0});const l=n.build("pad");let c=null;return t&&(c=ap(r).group,c.position.y=.3,l.add(c)),{group:l,height:.3+(t?2.2+r*.5:1.5)}}function i_(i,e){const t=new Pt;t.cyl(.95,1,.18,10,"#3a2f4a"),t.cyl(.7,.7,.05,12,"#120a1c",0,.18);for(let r=0;r<6;r++){const o=r/6*Math.PI*2;t.add(new pi(.12,0),"#c48bff",Math.cos(o)*.45,.25,Math.sin(o)*.45,{sy:2,glass:!0})}for(const[r,o]of[[-.7,-.7],[.7,-.7],[0,.75]])t.box(.08,1.3,.08,"#c8d0da",r,.18,o);t.box(1.5,.08,.08,e.accent,0,1.45,-.7),t.box(.3,.3,.3,e.primary,0,1.2,0);const n=t.build("mine"),s=new Te(new Nn(.12,.6,8),new $t({color:"#e6b84a",metalness:.6,roughness:.3}));s.rotation.x=Math.PI,s.position.y=.75,n.add(s);const a=nn(new qo(.55,20),"#b06dff");return a.rotation.x=-Math.PI/2,a.position.y=.24,a.material.transparent=!0,a.material.opacity=.6,n.add(a),{group:n,height:1.7,anim:(r,o)=>{s.rotation.y=o.working?r*12:0,s.position.y=o.working?.55+Math.sin(r*3)*.15:.75,a.material.opacity=o.ready?.6+Math.sin(r*5)*.3:.35}}}function s_(i){const e=new Pt;e.cyl(1.3,1.45,.3,8,"#2a2236",0,0,0,{ry:Math.PI/8}),e.cyl(.9,1,.5,8,"#3a2f4a",0,.3,0,{ry:Math.PI/8}),e.cyl(.6,.6,.05,16,"#b06dff",0,.8,0,{glow:!0});for(let a=0;a<4;a++){const r=a/4*Math.PI*2+Math.PI/4;e.box(.22,1.4,.22,"#4a3d5e",Math.cos(r)*1.15,.3,Math.sin(r)*1.15),e.add(new pi(.1,0),"#e6c8ff",Math.cos(r)*1.15,1.85,Math.sin(r)*1.15,{glow:!0})}const t=e.build("forge"),n=nn(new pi(.28,0),"#d6b8ff");n.position.y=1.5,t.add(n);const s=new _t;for(let a=0;a<3;a++){const r=nn(new an(.45+a*.12,.012,4,32),"#b06dff");r.rotation.x=a*1.1,s.add(r)}return s.position.y=1.5,t.add(s),{group:t,height:2.2,anim:a=>{n.rotation.y=a*1.5,n.position.y=1.5+Math.sin(a*1.4)*.08,s.children.forEach((r,o)=>{r.rotation.y=a*(.6+o*.4),r.rotation.z=a*.3*(o+1)})}}}function a_(i,e){const t=Be[e]||Be.aurora,n=new Pt;n.cyl(1.45,1.5,.22,12,"#2a2236"),n.cyl(1.2,1.2,.04,24,"#3a2f4a",0,.22,0);const s=6+Math.min(4,Math.floor(i/3));for(let o=0;o<s;o++){const l=o/s*Math.PI*2,c=.9+o%2*.35;n.box(.22,c,.22,"#4a3d5e",Math.cos(l)*1.2,.22,Math.sin(l)*1.2,{ry:-l}),n.box(.05,c*.6,.02,t.color,Math.cos(l)*1.08,.22+c*.2,Math.sin(l)*1.08,{ry:-l+Math.PI/2,glow:!0})}n.cyl(.7,.7,.04,24,t.color,0,.26,0,{glow:!0});const a=n.build("relicbay"),r=nn(new an(.4,.03,4,6),t.glow);return r.position.y=1.4,a.add(r),{group:a,height:1.9,anim:o=>{r.rotation.y=o,r.rotation.x=Math.sin(o*.7)*.6}}}function r_(i,e){const t="n"+i+e,n=da.get(t);if(n)return n;const s=document.createElement("canvas");s.width=512,s.height=144;const a=s.getContext("2d");let r=76;a.textAlign="center",a.textBaseline="middle";do a.font=`700 ${r}px Oxanium, Barlow, sans-serif`,r-=4;while(a.measureText(i.toUpperCase()).width>470&&r>20);a.shadowColor=e,a.shadowBlur=22,a.fillStyle=e,a.fillText(i.toUpperCase(),256,76),a.shadowBlur=8,a.fillStyle=Wc(e,"#ffffff",.65),a.fillText(i.toUpperCase(),256,76);const o=new nr(s);return o.colorSpace=zt,da.set(t,o),o}function o_(i,e){const t="e"+i+e,n=da.get(t);if(n)return n;const s=document.createElement("canvas");s.width=128,s.height=128;const a=s.getContext("2d");a.translate(64,64),a.shadowColor=e,a.shadowBlur=14,a.fillStyle=e,Ya(a,i,46),a.fill(Ka(i));const r=new nr(s);return r.colorSpace=zt,da.set(t,r),r}const l_=new $t({color:"#e8b64c",metalness:.55,roughness:.3,emissive:"#3a2a08"}),c_=new ct({color:"#fff1b8",toneMapped:!1});function d_(i){i.traverse(e=>{const t=e;if(!t.isMesh)return;const n=t.material;t.material=n.isMeshBasicMaterial?c_:l_,t.castShadow=!0})}function h_(i,e,t){const n=new Pt;switch(i){case"tree":{n.cyl(.05,.08,.45,6,"#7a5232"),n.add(new qn(.32,0),"#47c95a",0,.68,0),n.add(new qn(.22,0),"#6ee36f",.12,.88,.05);for(const[s,a,r]of[[.2,.62,.15],[-.18,.75,.12],[.05,.6,-.25]])n.sphere(.045,"#aaffee",s,a,r,{glow:!0,w:6,h:4});return{group:n.build("tree"),height:1.1}}case"rock":{const s=new ji(.32,0),a=s.attributes.position;for(let r=0;r<a.count;r++)a.setY(r,a.getY(r)*.7);return n.add(s,"#8a8f99",0,.18,0,{ry:.7}),n.add(new ji(.14,0),"#6c717b",.28,.08,.12),{group:n.build("rock"),height:.5}}case"path":return n.box(.98,.04,.98,"#cfd6df"),n.box(.86,.045,.86,"#e7ecf2"),{group:n.build("path"),height:.1};case"lamp":{n.cyl(.08,.1,.1,6,tn),n.cyl(.03,.03,.95,6,Sn,0,.1),n.box(.24,.04,.06,Sn,.1,1.02,0);const s=n.build("lamp"),a=nn(new Nt(.07,8,6),"#ffe7a0");a.position.set(.2,.98,0),s.add(a);const r=new Wf("#ffd890",1.2,3.2,2);return r.position.set(.2,.92,0),s.add(r),{group:s,height:1.2}}case"flag":{n.cyl(.07,.09,.08,6,tn);const s=n.build("flag"),a=new Te(new yn(.02,.02,1.4,5),new $t({color:Sn}));a.position.y=.75,s.add(a);const r=Qo(e,.6,.38);return r.position.set(.02,1.25,0),s.add(r),{group:s,height:1.5,anim:o=>r.userData.wave(o)}}case"crystal":{for(const[r,o,l,c]of[[0,0,.7,.13],[.16,.08,.45,.09],[-.14,.1,.5,.1],[.05,-.16,.38,.08]])n.add(new pi(c,0),"#c48bff",r,l/2,o,{sy:l/c/2,glass:!0});n.cyl(.25,.3,.06,7,"#5d5468");const s=n.build("crystal"),a=nn(new pi(.06,0),"#f0d8ff");return a.position.y=.3,s.add(a),{group:s,height:.8}}case"fountain":{n.cyl(.85,.9,.22,16,"#d9dee5"),n.cyl(.72,.72,.03,16,"#2f8cff",0,.2,0,{glass:!0}),n.cyl(.12,.16,.55,8,"#c8d0da",0,.2),n.cyl(.3,.3,.05,12,"#c8d0da",0,.75);const s=n.build("fountain"),a=new _t;for(let r=0;r<6;r++){const o=nn(new an(.28,.02,4,12,Math.PI),"#9fd8ff");o.rotation.y=r/6*Math.PI*2,o.position.y=.78,o.rotation.z=0,a.add(o)}return a.children.forEach(r=>{r.geometry.translate(.28,0,0)}),s.add(a),{group:s,height:1.2,anim:r=>{a.rotation.y=r*.6,a.scale.y=1+Math.sin(r*3)*.08}}}case"sign":{n.box(.08,.95,.08,tn,-.86,0,0),n.box(.08,.95,.08,tn,.86,0,0),n.box(1.92,.62,.1,"#121a28",0,.62,0),n.box(1.96,.04,.12,e.accent,0,1.24,0,{glow:!0}),n.box(1.96,.04,.12,e.accent,0,.6,0,{glow:!0});const s=n.build("sign"),a=new ct({map:r_(e.name||"New Haven",e.accent),transparent:!0,toneMapped:!1,depthWrite:!1}),r=new Te(new Fi(1.84,.52),a);r.position.set(0,.93,.056),s.add(r);const o=r.clone();return o.rotation.y=Math.PI,o.position.z=-.056,s.add(o),{group:s,height:1.4,anim:l=>{a.opacity=Math.sin(l*31)>.985?.55:.92+Math.sin(l*4)*.06}}}case"beacon":{n.cyl(.3,.36,.14,8,tn),n.cyl(.14,.2,.42,8,Sn,0,.14),n.cyl(.22,.22,.04,12,e.accent,0,.56,0,{glow:!0});const s=n.build("beacon"),a=new Te(new Fi(.75,.75),new ct({map:o_(e.banner.emblem,e.banner.fg==="#14202e"?e.accent:e.banner.fg),transparent:!0,side:Mn,depthWrite:!1,blending:fi,toneMapped:!1}));a.position.y=1.08,s.add(a);const r=new Te(new yn(.34,.2,.5,14,1,!0),new ct({color:e.accent,transparent:!0,opacity:.16,side:Mn,depthWrite:!1,blending:fi}));return r.position.y=.83,s.add(r),{group:s,height:1.6,anim:o=>{a.rotation.y=o*1.1,a.position.y=1.08+Math.sin(o*2)*.05}}}case"turbine":{n.cyl(.05,.1,1.5,8,"#e9eef5"),n.box(.13,.13,.28,"#e9eef5",0,1.44,0),n.box(.14,.03,.22,e.accent,0,1.55,0),n.cyl(.16,.2,.08,8,tn);const s=n.build("turbine"),a=new _t;a.position.set(0,1.5,.16);const r=new $t({color:"#f4f7fb",flatShading:!0});for(let o=0;o<3;o++){const l=new Xn(.07,.66,.015);l.translate(0,.33,0);const c=new Te(l,r);c.rotation.z=o*Math.PI*2/3,c.castShadow=!0,a.add(c)}return a.add(new Te(new Nt(.055,8,6),r)),s.add(a),{group:s,height:2.2,anim:o=>{a.rotation.z=-o*2.2}}}case"pond":{n.cyl(.92,.96,.12,16,"#9aa4b1"),n.cyl(.8,.8,.02,16,"#1d78c8",0,.1,0,{glass:!0}),n.add(new ji(.15,0),"#8a8f99",.74,.1,.42),n.add(new ji(.11,0),"#6c717b",-.62,.08,-.55);for(const[o,l]of[[.32,-.22],[-.3,.3],[.05,.5]])n.cyl(.11,.11,.012,8,"#4fcf5a",o,.115,l);n.sphere(.035,"#ff9ac8",.32,.14,-.22,{w:6,h:4});const s=n.build("pond"),a=[],r=["#ff7a3c","#ffffff","#ffb23e"];for(let o=0;o<3;o++){const l=new _t;l.position.y=.075;const c=new Te(new Nn(.035,.15,5),new $t({color:r[o],roughness:.4}));c.position.x=.3+o*.13,c.rotation.x=-Math.PI/2,l.add(c),s.add(l),a.push(l)}return{group:s,height:.5,anim:o=>a.forEach((l,c)=>{l.rotation.y=o*(.55+c*.18)+c*2.1})}}case"topiary":return n.box(.44,.12,.44,"#7a5232"),n.box(.36,.4,.3,"#3fae4a",0,.12),n.box(.3,.24,.26,"#4fc45a",0,.54),n.box(.1,.28,.1,"#3fae4a",-.25,.2),n.box(.1,.28,.1,"#3fae4a",.25,.2),n.cyl(.015,.015,.14,4,"#3fae4a",0,.78),n.sphere(.045,"#ff7ab8",0,.94,0,{w:6,h:4}),n.sphere(.035,"#fff4c2",-.07,.67,.135,{glow:!0,w:6,h:4}),n.sphere(.035,"#fff4c2",.07,.67,.135,{glow:!0,w:6,h:4}),{group:n.build("topiary"),height:1.1};case"bench":return n.box(.82,.05,.3,"#b07a4a",0,.3,.02),n.box(.82,.2,.05,"#b07a4a",0,.4,-.13),n.box(.06,.3,.28,tn,-.34,0,0),n.box(.06,.3,.28,tn,.34,0,0),n.box(.84,.03,.06,e.accent,0,.6,-.13),{group:n.build("bench"),height:.7};case"dish":{n.box(.9,.2,.9,"#9aa4b1"),n.cyl(.1,.14,.6,8,Sn,0,.2),n.sphere(.65,"#e9eef5",0,1.05,0,{theta:Math.PI/2.6,rx:Math.PI*.8,w:16,h:6}),n.cyl(.02,.02,.5,4,tn,.12,.95,.1,{rx:-.6});const s=n.build("dish"),a=nn(new Nt(.05,6,4),"#7af7ff");return a.position.set(.22,1.32,.3),s.add(a),{group:s,height:1.6}}case"monolith":{n.box(.5,1.8,.2,"#0c0a12");for(let s=0;s<5;s++)n.box(.36,.03,.01,"#b06dff",0,.3+s*.3,.105,{glow:!0});return{group:n.build("monolith"),height:2}}case"arch":{for(const r of[-.75,.75])n.cyl(.12,.16,.12,8,"#c8d0da",r,0),n.cyl(.07,.07,.6,8,"#e9eef5",r,.12);n.add(new an(.75,.07,8,28,Math.PI),"#e6b84a",0,.72,0),n.add(new an(.62,.025,6,28,Math.PI),"#fff4c2",0,.72,0,{glow:!0});const s=n.build("arch"),a=new _t;for(let r=0;r<7;r++){const o=nn(new pi(.04,0),"#fff4c2"),l=r/6*Math.PI;o.position.set(Math.cos(l)*.75,.72+Math.sin(l)*.75,0),a.add(o)}return s.add(a),{group:s,height:1.6,anim:r=>a.children.forEach((o,l)=>{o.scale.setScalar(.6+.6*Math.abs(Math.sin(r*2+l))),o.rotation.y=r*3})}}case"statue":if(t&&Q[t]){n.box(1.3,.25,1.3,"#d9dee5"),n.box(1.04,.45,1.04,"#c3cad4",0,.25),n.box(1.12,.06,1.12,"#e6b84a",0,.7),n.box(.5,.14,.02,"#e6b84a",0,.38,.52);const s=n.build("statue"),a=jo(t,20);return d_(a.group),a.group.scale.setScalar(1.45),a.group.position.y=.76+a.hover*.3,a.group.rotation.y=.35,s.add(a.group),{group:s,height:2.3}}case"statueGeneric":return n.box(1.2,.3,1.2,"#d9dee5"),n.box(1,.5,1,"#c3cad4",0,.3),n.sphere(.38,"#e6b84a",0,1.22,0,{w:14,h:10}),n.add(new an(.52,.05,6,24),"#e6b84a",0,1.22,0,{rx:1.2}),n.sphere(.1,"#fff4c2",0,1.26,.33,{glow:!0}),{group:n.build("statue"),height:1.8}}return n.box(.8,.4,.8,"#ff00ff"),{group:n.build("?"),height:.5}}function Xc(i,e,t,n){const s=Math.max(1,e);return i==="command"?Kb(s,n):i==="hub"?Zb(s,n):i==="bay"?Jb(s,t||"solar",n):i==="fab"?jb(s,n):i==="assembly"?Qb(s,n):i==="fusion"?e_(s,n):i==="arena"?t_(s,n):i==="mine"?i_(s,n):i==="forge"?s_():i==="relicbay"?a_(s,t||"aurora"):i==="pad"?n_(s,n,!n.noRocket):h_(i,n,t)}function u_(){const i=new Pt;i.cyl(.32,.42,.7,8,"#e9eef5",0,.1),i.cyl(.43,.43,.08,8,"#ff7a3c",0,.3),i.add(new Nn(.32,.4,8),"#e9eef5",0,1,0),i.box(.3,.2,.02,"#2c3340",0,.42,.37);for(let s=0;s<4;s++){const a=s/4*Math.PI*2+Math.PI/4;i.box(.05,.35,.22,"#ff7a3c",Math.cos(a)*.38,0,Math.sin(a)*.38,{ry:-a})}const e=i.build("pod"),t=nn(new Nn(.2,.7,8),"#ffd27a");t.rotation.x=Math.PI,t.position.y=-.3,e.add(t);const n=nn(new Nt(.06,8,6),"#7cf29a");return n.position.y=1.22,e.add(n),e.userData.flame=t,e.userData.beacon=n,e}function f_(i,e,t){const n=new _t,s=new $t({color:"#f2b233",roughness:.6,metalness:.3}),a=new yn(.035,.035,t,5),r=new yn(.025,.025,1,4),o=[-i/2+.1,i/2-.1],l=[-e/2+.1,e/2-.1];for(const d of o)for(const h of l){const u=new Te(a,s);u.position.set(d,t/2,h),u.castShadow=!0,n.add(u)}for(let d=.4;d<t;d+=.6){for(const h of l){const u=new Te(r,s);u.scale.y=i-.2,u.rotation.z=Math.PI/2,u.position.set(0,d,h),n.add(u)}for(const h of o){const u=new Te(r,s);u.scale.y=e-.2,u.rotation.x=Math.PI/2,u.position.set(h,d,0),n.add(u)}}const c=new Te(new Xn(.08,.08,Math.max(i,e)*.9),s);return c.position.set(0,t+.1,0),c.name="crane",n.add(c),n}const Hn=(i=Date.now())=>{const e=new Date(i);return`${e.getFullYear()}-${String(e.getMonth()+1).padStart(2,"0")}-${String(e.getDate()).padStart(2,"0")}`},p_=(i=Date.now())=>Hn(i-864e5);function pt(i){const e=i;return e.daily||(e.daily={day:0,cycle:0,last:"",streak:0,best:0,total:0,mDate:"",missions:[],mBase:{},mClaimed:[],bonus:!1,drop:Date.now()+8*6e4,drops:0,dropAt:null,spin:"",adSpin:"",ach:{}}),e.daily}const xs=i=>1+i.lvl*.6,Rd={2:{dm:10,label:"Dark Matter"},6:{core:"advanced",label:"Advanced core"},9:{dm:20,label:"Dark Matter"},13:{core:"elite",label:"Elite core"},16:{dm:30,label:"Dark Matter"},20:{decor:"arch",label:"Starlight Arch"},23:{dm:40,label:"Dark Matter"},27:{core:"epic",label:"Epic core"}};function Cd(i,e,t=pt(i).cycle){const n=xs(i)*(1+e*.07)*(1+t*.5),s=Rd[e],a=e%2?{cells:Ye(60*n)}:{credits:Ye(250*n)};s&&s.dm&&(a.dm=s.dm+t*10);const r=s&&s.core?Ct[Math.min(Ct.length-1,Ct.indexOf(s.core)+t)]:void 0;return{res:a,core:r,decor:s&&s.decor,label:s?s.label:""}}const el=(i,e=Date.now())=>pt(i).last!==Hn(e);function rp(i,e,t){let n=$n.filter(r=>Q[r].rarity===e);if(e==="standard"&&!ze(i,"assembly").some(r=>r.lvl>0)){const r=n.filter(o=>ws(i,o));r.length&&(n=r)}const s=n.filter(r=>!i.dex[r]),a=s.length&&Ln(t)()<.75?s:n;return a[Math.floor(Ln(t+7)()*a.length)]}function as(i,e,t,n=Date.now()){const s=rp(i,e,t),a=ze(i,"assembly")[0];if(a&&a.lvl>0)return Do(i,s,"gift",n),{sp:s,core:!0};const r=e==="standard"?ws(i,s):null;return r?(i.bots.push({id:Jt("b"),sp:s,lvl:1,fed:0,bay:r.id,born:n}),jc(i,s,n),hn.push({kind:"newBot",bot:i.bots[i.bots.length-1].id}),{sp:s,core:!1}):(i.cores.push({id:Jt("c"),sp:s,from:"gift",state:"waiting",at:n}),{sp:s,core:!0})}function Pd(i,e,t=Date.now()){const n=ze(i,"assembly")[0];return n&&n.lvl>0?Do(i,e,"gift",t):i.cores.push({id:Jt("c"),sp:e,from:"gift",state:"waiting",at:t}),{sp:e,core:!0}}function op(i,e=Date.now()){const t=pt(i);if(!el(i,e))return null;const n=Cd(i,t.day);Un(i,n.res);let s=null;n.core&&(s=as(i,n.core,ea(Hn(e))+t.total,e)),n.decor&&(i.stats["decor_"+n.decor]=(i.stats["decor_"+n.decor]||0)+1),t.streak=t.last===p_(e)?t.streak+1:1,t.best=Math.max(t.best,t.streak),t.total++,t.last=Hn(e);const a=t.day;return t.day++,t.day>=28&&(t.day=0,t.cycle++),dt(i,20+a*2),{...n,day:a,gift:s}}const m_=[{id:"collect",kind:"collects",n:()=>8,text:i=>`Collect credits from your bays ${i} times`},{id:"credits",kind:"collected",n:i=>Ye(1500*xs(i)),text:i=>`Collect ${i.toLocaleString()} credits`},{id:"harvest",kind:"harvests",n:()=>3,text:i=>`Harvest ${i} Fabricator recipes`},{id:"feed",kind:"feeds",n:()=>12,text:i=>`Feed your bots ${i} times`},{id:"craft",kind:"crafts",n:()=>4,text:i=>`Start ${i} Fabricator recipes`},{id:"upgrade",kind:"upgrades",n:()=>2,text:i=>`Start ${i} upgrades`},{id:"recruit",kind:"recruits",n:()=>1,text:()=>"Recruit a bot from the shop"},{id:"decor",kind:"decor",n:()=>2,text:i=>`Place ${i} decorations`},{id:"fuse",kind:"fusions",n:()=>1,text:()=>"Fuse two bots",need:i=>ze(i,"fusion").some(e=>e.lvl>0)},{id:"boot",kind:"boots",n:()=>1,text:()=>"Activate a core in the Assembly Bay",need:i=>ze(i,"assembly").some(e=>e.lvl>0)},{id:"drop",kind:"drops",n:()=>1,text:()=>"Open a supply drop"},{id:"launch",kind:"launches",n:()=>1,text:()=>"Launch an expedition",need:i=>ze(i,"pad").some(e=>e.lvl>0)},{id:"arena",kind:"arenaWins",n:()=>2,text:i=>`Win ${i} Arena battles`,need:i=>ze(i,"arena").some(e=>e.lvl>0)}],g_=(i,e)=>e===0?{credits:Ye(500*xs(i))}:e===1?{cells:Ye(150*xs(i))}:{dm:5};function Za(i,e=Date.now()){const t=pt(i),n=Hn(e);if(t.mDate===n)return!1;const s=Ln(ea(n)^i.created>>>0),a=m_.filter(o=>!o.need||o.need(i)),r=[];for(;r.length<3&&a.length;)r.push(a.splice(Math.floor(s()*a.length),1)[0]);return t.missions=r.map((o,l)=>{const c=o.n(i);return{id:o.id,kind:o.kind,n:c,text:o.text(c),reward:g_(i,l)}}),t.mBase={...i.stats},t.mClaimed=[!1,!1,!1],t.bonus=!1,t.mDate=n,!0}const tl=(i,e)=>Math.max(0,(i.stats[e.kind]||0)-(pt(i).mBase[e.kind]||0));function lp(i,e){const t=pt(i),n=t.missions[e];return!n||t.mClaimed[e]||tl(i,n)<n.n?null:(t.mClaimed[e]=!0,Un(i,n.reward),dt(i,15),n)}const js=i=>{const e=pt(i);return e.missions.length===3&&e.mClaimed.every(Boolean)&&!e.bonus};function cp(i,e=Date.now()){const t=pt(i);if(!js(i))return null;t.bonus=!0;const n={dm:10,cells:Ye(250*xs(i))};Un(i,n);const s=Ln(ea(t.mDate)+3)(),a=s<.35?as(i,s<.06?"elite":"advanced",ea(t.mDate)+11,e):null;return dt(i,30),{res:n,gift:a}}const Ja=4*36e5,To=2;function qc(i,e=Date.now()){const t=pt(i);for(;t.drops<To&&e>=t.drop;)t.drops++,t.drop+=Ja;t.drops>=To&&t.drop<e&&(t.drop=e+Ja)}function dp(i,e=Date.now()){const t=pt(i);if(t.drops<=0)return null;t.drops--,t.drops===To-1&&t.drop-e>Ja&&(t.drop=e+Ja);const n=Ln(e/1e3>>>0),s={credits:Ye(350*xs(i)*(.7+n()*.8)),cells:Ye(90*xs(i)*(.7+n()*.8))};n()<.35&&(s.dm=2+Math.floor(n()*5)),Un(i,s);const a=n(),r=a<.12?as(i,a<.025?"elite":a<.12&&ts(i)>=3?"advanced":"standard",e/1e3>>>0,e):null;return i.stats.drops=(i.stats.drops||0)+1,dt(i,10),{res:s,gift:r}}const nl=(i,e=Date.now())=>pt(i).spin!==Hn(e);function Yc(i,e=!1,t=Date.now()){const n=pt(i);if(!e&&!nl(i,t)||e&&n.adSpin===Hn(t))return null;const s=Ln(ea(Hn(t)+(e?"ad":""))^i.created>>>0),a=s(),r=a<.04?"elite":a<.3?"advanced":"standard";e?n.adSpin=Hn(t):n.spin=Hn(t);const o=as(i,r,s()*1e9>>>0,t);return dt(i,10),{rarity:r,...o}}const il=[{id:"collector",name:"Credit Collector",tiers:[1e4,2e5,5e6,1e8],stat:i=>i.stats.collected||0,unit:"credits collected"},{id:"crew",name:"Crew Chief",tiers:[5,12,25,50],stat:i=>i.bots.length,unit:"bots"},{id:"dex",name:"Botanist of Bots",tiers:[10,25,50,82],stat:i=>Qc(i),unit:"species discovered"},{id:"fuser",name:"Fusion Pioneer",tiers:[1,10,50,250],stat:i=>i.stats.fusions||0,unit:"fusions"},{id:"feeder",name:"Snack Time",tiers:[50,500,5e3,5e4],stat:i=>i.stats.feeds||0,unit:"feedings"},{id:"farmer",name:"Power Farmer",tiers:[10,100,1e3,5e3],stat:i=>i.stats.harvests||0,unit:"harvests"},{id:"builder",name:"Master Builder",tiers:[3,6,10,15],stat:i=>ts(i),unit:"Command Center level"},{id:"loyal",name:"Loyal Commander",tiers:[3,7,28,100],stat:i=>pt(i).total,unit:"days logged in"},{id:"streak",name:"On a Roll",tiers:[3,7,14,30],stat:i=>pt(i).best,unit:"day streak"},{id:"land",name:"Land Baron",tiers:[1,4,8,16],stat:i=>i.landBought,unit:"plots bought"},{id:"decorator",name:"Interior Designer",tiers:[5,25,75,200],stat:i=>i.stats.decor||0,unit:"decorations"},{id:"veteran",name:"Veteran",tiers:[5,15,30,60],stat:i=>i.lvl,unit:"Commander level"},{id:"champion",name:"Arena Champion",tiers:[5,50,250,1e3],stat:i=>i.stats.arenaWins||0,unit:"Arena wins"},{id:"defender",name:"Defender of the Colony",tiers:[1,10,50,200],stat:i=>i.stats.raidsWon||0,unit:"raids repelled"},{id:"explorer",name:"Explorer",tiers:[3,25,150,600],stat:i=>i.stats.expeditions||0,unit:"expeditions"},{id:"hoarder",name:"Supply Hoarder",tiers:[5,30,150,600],stat:i=>i.stats.drops||0,unit:"supply drops"}],Ro=[5,15,40,100],sl=(i,e)=>pt(i).ach[e.id]||0,ja=(i,e)=>{const t=sl(i,e);return t<e.tiers.length&&e.stat(i)>=e.tiers[t]};function hp(i,e){const t=il.find(s=>s.id===e);if(!t||!ja(i,t))return null;const n=sl(i,t);return pt(i).ach[e]=n+1,i.res.dm+=Ro[n],dt(i,25*(n+1)),{a:t,tier:n,dm:Ro[n]}}function so(i,e=Date.now()){const t=pt(i);return{day:el(i,e),missions:t.missions.some((n,s)=>!t.mClaimed[s]&&tl(i,n)>=n.n)||js(i),ach:il.some(n=>ja(i,n)),spin:nl(i,e),drop:t.drops>0}}const v_=Object.freeze(Object.defineProperty({__proto__:null,ACHS:il,ACH_DM:Ro,DROP_EVERY:Ja,DROP_MAX:To,SPECIAL:Rd,achReady:ja,achTier:sl,attention:so,bonusReady:js,canClaimDay:el,canSpin:nl,claimAch:hp,claimBonus:cp,claimDay:op,claimMission:lp,daily:pt,dateKey:Hn,dayReward:Cd,giftSpecies:rp,giveCore:as,giveSpecies:Pd,mProgress:tl,openDrop:dp,refreshMissions:Za,spin:Yc,tickDrops:qc},Symbol.toStringTag,{value:"Module"})),is={strike:{name:"Strike",el:"none",power:.8,desc:"A plain, honest hit."},solar:{name:"Sunburst",el:"solar",power:1,fx:"drain",desc:"Heals for a third of the damage dealt."},plasma:{name:"Plasma Torch",el:"plasma",power:1.2,fx:"burn",chance:.4,desc:"May set the target burning."},hydro:{name:"Tidal Jet",el:"hydro",power:1.15,desc:"A crushing jet of water."},cryo:{name:"Cryo Lance",el:"cryo",power:1,fx:"freeze",chance:.3,desc:"May freeze the target for a turn."},geo:{name:"Rockslide",el:"geo",power:1.25,desc:"Heavy and hard to argue with."},bio:{name:"Overgrowth",el:"bio",power:.75,fx:"heal",desc:"Strikes, then restores 18% of its hull."},volt:{name:"Arc Discharge",el:"volt",power:1.1,fx:"stun",chance:.2,desc:"May short-circuit the target."},alloy:{name:"Plate Up",el:"alloy",power:.6,fx:"shield",desc:"Hits, then halves the next blow it takes."},void:{name:"Null Pulse",el:"void",power:1.25,desc:"A wave of absolute nothing."},photon:{name:"Prism Laser",el:"photon",power:1.1,fx:"pierce",desc:"Cuts straight through shields."},kinetic:{name:"Mass Driver",el:"kinetic",power:1.45,fx:"reckless",chance:.2,desc:"Devastating, but misses one shot in five."},aero:{name:"Cyclone",el:"aero",power:1,fx:"first",desc:"Always strikes first."},gravity:{name:"Crush",el:"gravity",power:1,fx:"crush",desc:"Hits harder the healthier the target is."},chrono:{name:"Rewind",el:"chrono",power:.7,fx:"heal",desc:"Strikes, then winds back 18% of its damage."},neural:{name:"Overload",el:"neural",power:1,fx:"weaken",desc:"Lowers the target's attack by 20%."}},up=i=>[...Q[i].el.filter(e=>is[e]).map(e=>e),"strike"];function Ld(i,e){if(i==="none")return 1;const t=e.some(s=>Be[i].strong.includes(s)),n=e.some(s=>(Be[s].strong||[]).includes(i));return t&&!n?1.35:n&&!t?.8:1}const y_={drone:14,orb:12,android:11,rover:10,crawler:9,walker:8,mech:6};function Co(i,e,t,n){const s=ia({sp:i,lvl:e});return{sp:i,lvl:e,name:t||Q[i].name,hp:s.hp,max:s.hp,atk:Math.round(s.atk*1.6),spd:y_[Q[i].chassis]+e*.25+Ct.indexOf(Q[i].rarity),shield:!1,burn:0,frozen:!1,weak:0,bot:n}}const _n=i=>Math.round(i.reduce((e,t)=>{const n=ia({sp:t.sp,lvl:t.lvl});return e+Math.sqrt(n.hp*n.atk)},0));function fp(i,e,t){return{A:i,B:e,a:0,b:0,turn:0,seed:t,over:""}}function x_(i,e,t,n){const s=e==="A"?i.A[i.a]:i.B[i.b],a=e==="A"?i.B[i.b]:i.A[i.a],r=is[t],o={side:e,who:e==="A"?i.a:i.b,target:e==="A"?i.b:i.a,move:t,dmg:0,eff:1,crit:!1,miss:!1,heal:0,status:"",ko:!1};if(s.frozen)return s.frozen=!1,o.status="frozen",o.miss=!0,o;if(r.fx==="reckless"&&n()<(r.chance||0))return o.miss=!0,o;o.eff=Ld(r.el,Q[a.sp].el),o.crit=n()<.1;let l=s.atk*(1-s.weak)*r.power*o.eff*(.9+n()*.2)*(o.crit?1.5:1);return r.fx==="crush"&&(l*=.7+.6*(a.hp/a.max)),a.shield&&r.fx!=="pierce"&&(l*=.5,a.shield=!1,o.status="shielded"),o.dmg=Math.max(1,Math.round(l)),a.hp=Math.max(0,a.hp-o.dmg),r.fx==="drain"&&(o.heal=Math.round(o.dmg/3),s.hp=Math.min(s.max,s.hp+o.heal)),r.fx==="heal"&&(o.heal=Math.round(s.max*.18),s.hp=Math.min(s.max,s.hp+o.heal)),r.fx==="shield"&&(s.shield=!0),r.fx==="weaken"&&(a.weak=Math.min(.5,a.weak+.2),o.status="weakened"),(r.fx==="burn"||r.fx==="freeze"||r.fx==="stun")&&a.hp>0&&n()<(r.chance||0)&&(r.fx==="burn"?(a.burn=3,o.status="burning"):(a.frozen=!0,o.status=r.fx==="freeze"?"frozen solid":"stunned")),o.ko=a.hp<=0,o}function Hl(i,e){const t=e==="A"?i.A[i.a]:i.B[i.b],n=e==="A"?i.B[i.b]:i.A[i.a];let s="strike",a=-1;for(const r of up(t.sp)){const o=is[r];let l=o.power*Ld(o.el,Q[n.sp].el)*(o.fx==="reckless"?.8:1);(o.fx==="heal"||o.fx==="drain")&&t.hp<t.max*.45&&(l*=1.6),o.fx==="shield"&&!t.shield&&t.hp<t.max*.6&&(l+=.5),o.fx==="weaken"&&n.weak<.2&&(l+=.2),l>a&&(a=l,s=r)}return s}function b_(i,e,t){if(i.over)return[];const n=Ln(i.seed+ ++i.turn*104729),s=[],a=i.A[i.a],r=i.B[i.b],o=(is[e].fx==="first"?100:0)+a.spd,l=(is[t].fx==="first"?100:0)+r.spd,c=o>l||o===l&&n()<.5?[["A",e],["B",t]]:[["B",t],["A",e]];for(const[d,h]of c)(d==="A"?i.A[i.a]:i.B[i.b]).hp<=0||(d==="A"?i.B[i.b]:i.A[i.a]).hp<=0||s.push(x_(i,d,h,n));for(const[d,h]of[["A",i.A[i.a]],["B",i.B[i.b]]])if(h.hp>0&&h.burn>0){const u=Math.max(1,Math.round(h.max*.06));h.hp=Math.max(0,h.hp-u),h.burn--,s.push({side:d==="A"?"B":"A",who:-1,target:d==="A"?i.a:i.b,move:"burn",dmg:u,eff:1,crit:!1,miss:!1,heal:0,status:"burn",ko:h.hp<=0})}if(i.A[i.a].hp<=0){const d=i.A.findIndex(h=>h.hp>0);d<0?i.over="B":i.a=d}if(i.B[i.b].hp<=0){const d=i.B.findIndex(h=>h.hp>0);d<0?i.over=i.over?i.over:"A":i.b=d}return i.turn>=60&&!i.over&&(i.over=i.A.reduce((d,h)=>d+h.hp/h.max,0)>=i.B.reduce((d,h)=>d+h.hp/h.max,0)?"A":"B"),s}const Qi=[["Bronze III",0],["Bronze II",100],["Bronze I",200],["Silver III",350],["Silver II",500],["Silver I",650],["Gold III",850],["Gold II",1050],["Gold I",1250],["Platinum",1500],["Diamond",1800],["Singularity",2200]],Ra=["#cd7f32","#cd7f32","#cd7f32","#c0c8d4","#c0c8d4","#c0c8d4","#ffd36a","#ffd36a","#ffd36a","#7af7ff","#9fd0ff","#c49bff"],bs=i=>{let e=0;for(let t=0;t<Qi.length;t++)i>=Qi[t][1]&&(e=t);return e},_s=5,Kc=90*6e4;function In(i){const e=i;return e.arena||(e.arena={trophies:0,best:0,seasonBest:0,season:pp(),tickets:_s,tAt:Date.now(),wins:0,losses:0,rivals:[],rAt:0,team:[],dayWins:0,day:""}),e.arena}const pp=(i=Date.now())=>{const e=new Date(i),t=(e.getDay()+6)%7;return e.setHours(0,0,0,0),e.setDate(e.getDate()-t),`${e.getFullYear()}-${e.getMonth()+1}-${e.getDate()}`},__=(i=Date.now())=>{const e=new Date(i),t=(e.getDay()+6)%7;return e.setHours(0,0,0,0),e.setDate(e.getDate()-t+7),e.getTime()};function mp(i,e=Date.now()){const t=In(i);for(;t.tickets<_s&&e>=t.tAt+Kc;)t.tickets++,t.tAt+=Kc;t.tickets>=_s&&(t.tAt=e)}function gp(i,e){const t=1+i.lvl*.5;return{dm:10+e*8,cells:Ye(300*t*(1+e*.4)),credits:Ye(800*t*(1+e*.5))}}function vp(i,e=Date.now()){const t=In(i),n=pp(e);if(t.season===n)return null;const s=bs(t.seasonBest),a=t.seasonBest>0?gp(i,s):null;return a&&Un(i,a),t.season=n,t.trophies=Math.floor(t.trophies*.75),t.seasonBest=t.trophies,a?{league:s,reward:a}:null}const pu=["Nova","Astra","Kepler","Lumen","Vega","Orion","Tycho","Halley","Sagan","Ceres","Juno","Selene","Rhea","Titan","Helix","Zenith","Polaris","Draco","Lyra","Corvus"],mu=["Station","Colony","Outpost","Haven","Reach","Spire","Hold","Landing","Array","Ring"],gu=["#1b6fd8","#d83a3a","#1f9c5a","#7a3fd6","#e08a1a","#14202e","#0fb3c9","#c9324f"],vu=["star","planet","bolt","gear","rocket","circle"];function Di(i){const e=In(i),t=s=>Q[s.sp].alien==="relic"||!!(i.space&&i.space.exps.some(a=>a.crew.includes(s.id)));let n=e.team.map(s=>i.bots.find(a=>a.id===s)).filter(s=>!!s&&!s.stored&&!t(s));if(n.length<Math.min(3,i.bots.filter(s=>!s.stored).length)){const s=[...i.bots].filter(a=>!a.stored&&!t(a)&&!n.includes(a)).sort((a,r)=>_n([r])-_n([a]));n=[...n,...s].slice(0,3),e.team=n.map(a=>a.id)}return n.slice(0,3)}function yu(i,e=Date.now()){const t=In(i),n=_n(Di(i).map(r=>({sp:r.sp,lvl:r.lvl}))),s=Ln(ea(String(e>>>0))^i.created>>>0),a=bs(t.trophies);return t.rivals=[0,1,2].map(r=>{const o=Math.max(40,n*[.78,.98,1.2][r]*(1+a*.02)),l=Math.min(6,Math.floor(a/2)+(r===2?2:1)),c=$n.filter(h=>Ct.indexOf(Q[h].rarity)<=l),d=[];for(let h=0;h<3;h++){const u=c[Math.floor(s()*c.length)];let f=1;for(;f<40&&_n([...d,{sp:u,lvl:f+1}])<=o*((h+1)/3);)f++;d.push({sp:u,lvl:f})}return{name:`${pu[Math.floor(s()*pu.length)]} ${mu[Math.floor(s()*mu.length)]}`,banner:{bg:gu[Math.floor(s()*gu.length)],fg:s()<.5?"#ffd23a":"#ffffff",emblem:vu[Math.floor(s()*vu.length)]},team:d,diff:r,power:_n(d)}}),t.rAt=e,t.rivals}const yp=[18,26,36];function Ca(i){const e=In(i);return ze(i,"arena").some(t=>t.lvl>0)?e.tickets<=0?{ok:!1,why:"No battle tickets: one recharges every 90 minutes"}:Di(i).length<1?{ok:!1,why:"You need bots to fight"}:{ok:!0}:{ok:!1,why:"Build the Arena first"}}function M_(i,e,t=Date.now()){const n=In(i);if(!Ca(i).ok)return null;const a=n.rivals[e];if(!a)return null;n.tickets===_s&&(n.tAt=t),n.tickets--;const r=Di(i).map(o=>Co(o.sp,o.lvl,o.nick,o.id));return{bt:fp(r,a.team.map(o=>Co(o.sp,o.lvl)),t/1e3>>>0),rival:a}}function w_(i,e,t,n=Date.now()){const s=In(i),a=new Date(n).toDateString();s.day!==a&&(s.day=a,s.dayWins=0);const r=1+i.lvl*.5;let o,l;e?(l=yp[t],s.wins++,s.dayWins++,o={credits:Ye(300*r*(1+t*.5)),cells:Ye(80*r*(1+t*.5))},s.dayWins===1&&(o.dm=5),i.stats.arenaWins=(i.stats.arenaWins||0)+1):(l=-14,s.losses++,o={credits:Ye(60*r)});const c=bs(s.trophies);s.trophies=Math.max(0,s.trophies+l),s.best=Math.max(s.best,s.trophies),s.seasonBest=Math.max(s.seasonBest,s.trophies);const d=bs(s.trophies),h=(ze(i,"arena")[0]||{lvl:1}).lvl;for(const u of Object.keys(o))u!=="dm"&&(o[u]=Ye(o[u]*(1+.1*(h-1))));return Un(i,o),dt(i,e?20+t*10:5),s.rivals=[],{reward:o,dt:l,promoted:d>c?d:-1,league:d}}const S_=16,xp=10*36e5,E_=2*36e5;function al(i){const e=i;return e.raid||(e.raid={next:Date.now()+36e5,eta:0,team:[],won:0,lost:0}),e.raid}const A_={bg:"#14080c",fg:"#ff3d5a",emblem:"circle"};function T_(i,e=Date.now()){if(i.lvl<S_)return null;const t=al(i);if(!t.eta&&e>=t.next){const n=_n(Di(i).map(o=>({sp:o.sp,lvl:o.lvl}))),s=Math.max(60,n*1.08),a=["krdrone","krwarrior","krdrone","krbrood"],r=[];for(let o=0;o<3;o++){const l=a[(o+Math.floor(e/36e5))%(o===2&&i.lvl>24?4:3)];let c=1;for(;c<40&&_n([...r,{sp:l,lvl:c+1}])<=s*((o+1)/3);)c++;r.push({sp:l,lvl:c})}return t.team=r,t.eta=e+E_,{kind:"warn"}}if(t.eta&&e>=t.eta){let n=0;for(const s of ze(i,"bay")){const a=Math.floor((i.bay[s.id]||0)*.5);i.bay[s.id]-=a,n+=a}return t.eta=0,t.next=e+xp,t.lost++,{kind:"hit",stolen:n}}return null}function R_(i,e=Date.now()){const t=al(i);if(!t.eta||!t.team.length)return null;const n=Di(i).map(a=>Co(a.sp,a.lvl,a.nick,a.id));if(!n.length)return null;const s={name:"Kr'thul Swarm",banner:A_,team:t.team,diff:2,power:_n(t.team)};return{bt:fp(n,t.team.map(a=>Co(a.sp,a.lvl)),e/1e3>>>0),rival:s}}function C_(i,e,t=Date.now()){const n=al(i),s=1+i.lvl*.5;if(n.eta=0,n.next=t+xp,e){n.won++,i.stats.raidsWon=(i.stats.raidsWon||0)+1;const r={dm:12,cells:Ye(400*s),credits:Ye(1200*s)};Un(i,r),dt(i,60);const o=Ln(t/1e3>>>0)(),l=o<.35?o<.03?"krbrood":o<.12?"krwarrior":"krdrone":null;return{win:e,reward:r,capture:l}}n.lost++;let a=0;for(const r of ze(i,"bay")){const o=Math.floor((i.bay[r.id]||0)*.5);i.bay[r.id]-=o,a+=o}return{win:e,reward:{},capture:null,stolen:a}}const Zc=new D(0,0,-260),xu=new Set(["photon","volt","solar","neural","void"]);class P_{constructor(e){this.group=new _t,this.A=[],this.B=[],this.t=0,this.anims=[],this.onImpact=()=>{};const t=new Pt;t.cyl(7.2,7.6,.6,32,"#2a3446",0,-.6),t.cyl(7,7,.06,48,"#3a4a64",0,0),t.add(new an(6.9,.08,6,64),"#6ee7ff",0,.05,0,{rx:Math.PI/2,glow:!0}),t.add(new an(3.2,.05,6,48),"#6ee7ff",0,.06,0,{rx:Math.PI/2,glow:!0});for(const[s,a]of[[-3.2,"#4aa8ff"],[3.2,"#ff5a6a"]])t.cyl(1.4,1.4,.05,24,a,s,.05,0,{glow:!0}),t.cyl(1.25,1.25,.06,24,"#1a2232",s,.06,0);for(let s=0;s<10;s++){const a=s/10*Math.PI*2;t.box(.3,2.2,.3,"#c8d0da",Math.cos(a)*6.6,0,Math.sin(a)*6.6),t.box(.34,.12,.34,"#6ee7ff",Math.cos(a)*6.6,2.2,Math.sin(a)*6.6,{glow:!0})}t.cyl(.1,1.2,4,10,"#3a4250",0,-4.6,0);const n=t.build("arena");n.traverse(s=>{s.isMesh&&(s.receiveShadow=!0)}),this.group.add(n),this.ring=new Te(new an(7.6,.03,4,96),new ct({color:"#7af7ff",transparent:!0,opacity:.18})),this.ring.rotation.x=Math.PI/2,this.ring.position.y=6,this.group.add(this.ring),this.group.position.copy(Zc),e.add(this.group)}clear(){for(const e of[...this.A,...this.B])this.group.remove(e.m.group);this.A=[],this.B=[],this.anims=[]}setup(e){this.clear();const t=(s,a,r)=>{const o=s==="A"?-1:1;return r?new D(o*2.4,.1,0):new D(o*4.8,.1,a%2?1.8:-1.8)},n=(s,a,r,o)=>{const l=jo(s.sp,s.lvl);l.group.scale.multiplyScalar(2.7);const c=t(a,r,o);return l.group.position.copy(c),l.group.rotation.y=a==="A"?Math.PI/2:-Math.PI/2,this.group.add(l.group),{m:l,home:c,ko:s.hp<=0,flash:0}};this.A=e.A.map((s,a)=>n(s,"A",a,a===e.a)),this.B=e.B.map((s,a)=>n(s,"B",a,a===e.b))}worldPos(e,t){const n=(e==="A"?this.A:this.B)[t];return n?n.m.group.position.clone().add(this.group.position).add(new D(0,1.4,0)):this.group.position.clone()}tween(e,t,n){this.anims.push({t:0,dur:e,fn:t,done:n})}play(e,t,n=1){return new Promise(s=>{let a=0;const r=()=>{if(a>=e.length){this.reposition(t,n,s);return}const o=e[a++];this.playHit(o,n,r)};r()})}playHit(e,t,n){const s=e.side==="A"?this.A:this.B,r=(e.side==="A"?this.B:this.A)[e.target];if(!r){n();return}if(e.move==="burn"){r.flash=1,this.onImpact(e,r.m.group.position.clone().add(this.group.position).add(new D(0,1.6,0))),this.tween(.35/t,()=>{},n);return}const o=s[e.who];if(!o){n();return}const l=is[e.move].el,c=l==="none"?"#ffffff":Be[l].glow,d=o.m.group.position.clone(),h=d.clone().lerp(r.m.group.position,.18);this.tween(.18/t,u=>o.m.group.position.lerpVectors(d,h,Math.sin(u*Math.PI/2)),()=>{const u=o.m.group.position.clone().add(new D(0,1.2,0)),f=r.m.group.position.clone().add(new D(0,1.1,0));let g;if(xu.has(l)){const m=u.distanceTo(f),p=new Te(new yn(.09,.09,m,8),new ct({color:c,toneMapped:!1,transparent:!0}));p.position.copy(u).lerp(f,.5),p.lookAt(f),p.rotateX(Math.PI/2),g=p}else g=new Te(new qn(.28,1),new ct({color:c,toneMapped:!1})),g.position.copy(u);this.group.add(g);const y=xu.has(l);this.tween((y?.22:.32)/t,m=>{y?(g.material.opacity=1-m*.6,g.scale.x=g.scale.z=1+Math.sin(m*30)*.3):(g.position.lerpVectors(u,f,m),g.position.y+=Math.sin(m*Math.PI)*.8,g.rotation.y+=.3)},()=>{this.group.remove(g),e.miss||(r.flash=1),this.onImpact(e,f.clone().add(this.group.position)),this.tween(.22/t,m=>o.m.group.position.lerpVectors(h,d,m),()=>{e.ko?this.knockOut(r,t,n):n()})})})}knockOut(e,t,n){e.ko=!0;const s=e.m.group,a=s.rotation.z,r=s.position.y;this.tween(.5/t,o=>{s.rotation.z=a+o*1.4*(s.position.x<0?-1:1),s.position.y=r-o*.3,s.scale.setScalar(2.7*(1-o*.35))},()=>{s.visible=!1,n()})}reposition(e,t,n){const s=[];for(const[a,r,o]of[["A",this.A,e.a],["B",this.B,e.b]]){const l=r[o];if(!l||l.ko)continue;const c=new D((a==="A"?-1:1)*2.4,.1,0);if(l.m.group.position.distanceTo(c)>.1){const d=l.m.group.position.clone();s.push(()=>this.tween(.4/t,h=>l.m.group.position.lerpVectors(d,c,h))),l.home=c}}s.forEach(a=>a()),this.tween(s.length?.45/t:.05,()=>{},n)}update(e){this.t+=e;const t=this.t;this.ring.rotation.z=t*.2;for(const n of[...this.anims]){n.t+=e;const s=Math.min(1,n.t/n.dur);n.fn(s),s>=1&&(this.anims.splice(this.anims.indexOf(n),1),n.done&&n.done())}for(const n of[...this.A,...this.B])if(!n.ko&&(n.m.anim(t,!1),n.flash>0)){n.flash=Math.max(0,n.flash-e*4);const s=2.7*(1+n.flash*.12);n.m.group.scale.setScalar(s)}}}const ft={moon:{name:"The Moon",tier:1,hours:.5,crew:1,els:["geo","solar"],dist:1.4,color:"#bdbab4",size:.32,moonOf:"earth",fact:"384,400 km away; three days by chemical rocket.",first:"Your crew plants the colony banner beside the Apollo 11 site. Helium-3 glitters in the regolith.",outpost:{res:"cells",rate:120}},neo:{name:"Near-Earth Asteroids",tier:1,hours:1,crew:2,els:["geo","alloy","gravity"],needs:"moon",dist:4.2,color:"#8a7a68",size:.18,fact:"Thousands of mountains of metal drift past Earth every year.",first:"A nickel-iron asteroid the size of a stadium. Your bots start a claim.",outpost:{res:"credits",rate:400}},mars:{name:"Mars",tier:2,hours:2,crew:2,els:["geo","plasma","cryo"],needs:"moon",dist:5.4,color:"#c2643a",size:.42,fact:"Olympus Mons is 22 km high; a day lasts 24 h 37 min.",first:"Dust devils dance across Jezero Crater as your rover crew rolls out. Ice lies a metre down.",outpost:{res:"credits",rate:700}},phobos:{name:"Phobos",tier:2,hours:2.5,crew:2,els:["gravity","alloy"],needs:"mars",dist:5.9,color:"#6e6660",size:.14,moonOf:"mars",fact:"Orbits Mars three times a day, slowly spiralling inwards.",first:"A perfect depot site: one shove and cargo falls to Mars.",outpost:{res:"cells",rate:260}},ceres:{name:"Ceres",tier:2,hours:4,crew:2,els:["cryo","hydro","geo"],needs:"neo",dist:7.4,color:"#7a7570",size:.24,fact:"The largest object in the asteroid belt, with salt-bright craters.",first:"Occator Crater's bright salts are brine frozen in place. Water for the whole belt.",outpost:{res:"credits",rate:1300}},europa:{name:"Europa",tier:3,hours:6,crew:3,els:["cryo","hydro","bio"],needs:"ceres",dist:10.5,color:"#d8ccb4",size:.2,moonOf:"jupiter",fact:"An ocean of salt water under 20 km of ice.",first:"The deep probe melts through the ice. Something down there glows.",outpost:{res:"cells",rate:900}},ganymede:{name:"Ganymede",tier:3,hours:6,crew:3,els:["gravity","volt","cryo"],needs:"ceres",dist:10.9,color:"#a39889",size:.26,moonOf:"jupiter",fact:"The largest moon in the Solar System, with its own magnetic field.",first:"Aurorae ripple over the ice plains. Jupiter fills half the sky.",outpost:{res:"credits",rate:2400}},titan:{name:"Titan",tier:4,hours:8,crew:3,els:["hydro","bio","aero"],needs:"europa",dist:13.6,color:"#d08a3a",size:.3,moonOf:"saturn",fact:"Thick orange skies and lakes of liquid methane.",first:"Your drone crew glides down through orange haze onto the shore of Kraken Mare.",outpost:{res:"credits",rate:4200}},enceladus:{name:"Enceladus",tier:4,hours:10,crew:3,els:["cryo","neural","hydro"],needs:"titan",dist:14.1,color:"#f2f8fd",size:.16,moonOf:"saturn",fact:"Geysers at its south pole spray an ocean into space.",first:"Your bots fly straight through a geyser plume and sample an alien ocean.",outpost:{res:"dm",rate:2}},proxima:{star:!0,alien:"veyari",ly:4.2,angle:.6,name:"Proxima Centauri b",tier:5,hours:16,crew:3,els:["void","photon","gravity"],needs:"pluto",dist:28,color:"#ff9a6a",size:.35,fact:"The nearest star to the Sun: a red dwarf with a rocky world in its habitable zone.",first:"On a tidally locked world, crystal gardens grow along the twilight line. Their gardeners, the Veyari, have been waiting for you.",outpost:{res:"dm",rate:6}},barnard:{star:!0,alien:"synod",ly:6,angle:1.7,name:"Barnard's Star",tier:5,hours:18,crew:3,els:["cryo","chrono","gravity"],needs:"proxima",dist:30,color:"#ff7a5a",size:.32,fact:"An ancient red dwarf racing across our sky faster than any other star.",first:'A frozen planet humming with machinery. The Synod, a parliament of machines, opens a channel: "We have been expecting your bots."',outpost:{res:"dm",rate:7}},tauceti:{star:!0,alien:"mycelar",ly:12,angle:2.9,name:"Tau Ceti e",tier:5,hours:20,crew:3,els:["bio","hydro","neural"],needs:"barnard",dist:32,color:"#ffe08a",size:.34,fact:"A Sun-like star with a debris disc and several super-Earths.",first:"A whole continent is one fungal mind, the Mycelar. It sings to your crew through their sensors.",outpost:{res:"dm",rate:8}},trappist:{star:!0,alien:"oshoru",ly:40,angle:4.1,name:"TRAPPIST-1e",tier:5,hours:24,crew:3,els:["hydro","aero","kinetic"],needs:"tauceti",dist:34,color:"#ff6a5a",size:.3,fact:"Seven Earth-sized worlds orbit one tiny star; three could hold oceans.",first:"An ocean world. The Oshoru, a young sea-faring people, swim up to greet your landing craft.",outpost:{res:"dm",rate:9}},epseri:{star:!0,alien:"lumenchoir",ly:10.5,angle:5.2,name:"Epsilon Eridani",tier:5,hours:24,crew:3,els:["photon","solar","neural"],needs:"trappist",dist:36,color:"#ffd27a",size:.36,fact:"A young, restless star wrapped in asteroid belts.",first:"Something old is broadcasting here. The Lumen, beings of pure light, have been listening to Earth for a century.",outpost:{res:"dm",rate:12}},pluto:{name:"Pluto",tier:4,hours:12,crew:3,els:["cryo","void","chrono"],needs:"enceladus",dist:18.5,color:"#d9c4a8",size:.2,fact:"A heart-shaped glacier of nitrogen ice, 6 billion km from the Sun.",first:"At the edge of the Solar System your crew looks back. The Sun is just a bright star. Beyond: the real stars.",outpost:{res:"dm",rate:4}}},ai=[...Object.keys(ft).filter(i=>!ft[i].star),...Object.keys(ft).filter(i=>ft[i].star)],L_=[{id:"mercury",dist:2.2,color:"#9a948d",size:.16},{id:"venus",dist:3.1,color:"#d9b77a",size:.3},{id:"earth",dist:4,color:"#3f7fd8",size:.32},{id:"jupiter",dist:10.7,color:"#d6b48a",size:.95},{id:"saturn",dist:13.8,color:"#e6d3a3",size:.8,ring:!0},{id:"uranus",dist:16.4,color:"#a6dce4",size:.5},{id:"neptune",dist:17.6,color:"#3a6ed8",size:.48}],Ms=[{name:"Kestrel",pad:1},{name:"Meridian",pad:3},{name:"Colossus",pad:6},{name:"Leviathan",pad:9},{name:"Starship",pad:10}],Ki=i=>Ms.filter(e=>i>=e.pad).length,Qs=i=>1+Math.floor(i/4);function Ht(i){const e=i;return e.space||(e.space={visits:{},exps:[],outposts:{}}),e.space}const Dd=i=>ze(i,"pad")[0],bu=(i,e)=>Ht(i).exps.some(t=>t.crew.includes(e)),Jc=(i,e)=>{const t=ft[e];return!t.needs||(Ht(i).visits[t.needs]||0)>0},bp=i=>Math.round(120*Math.pow(2.1,ai.indexOf(i)*.6+ft[i].tier-1));function Id(i,e,t){const n=ft[e],s=Math.round(t.reduce((r,o)=>{const l=ia(o);return r+Math.sqrt(l.hp*l.atk)},0)),a=t.reduce((r,o)=>r+Q[o.sp].el.filter(l=>n.els.includes(l)).length,0);return{power:s,match:a,mult:Math.min(2.5,(.55+.45*Math.min(1.6,s/bp(e)))*(1+.15*a))}}function _p(i,e,t){const n=Dd(i),s=ft[e];if(!n||n.lvl<1)return{ok:!1,why:"Build the Launch Pad first"};if(At(i,n.id,"build"))return{ok:!1,why:"The Launch Pad is being upgraded"};if(!Jc(i,e))return{ok:!1,why:`Visit ${ft[s.needs].name} first`};if(Ki(n.lvl)<s.tier)return{ok:!1,why:`Needs a ${Ms[s.tier-1].name} rocket (Launch Pad level ${Ms[s.tier-1].pad})`};if(Ht(i).exps.length>=Qs(n.lvl))return{ok:!1,why:"Every rocket is out: wait for one to return"};if(Ht(i).exps.some(r=>r.dest===e))return{ok:!1,why:"A crew is already on its way there"};if(!t.length)return{ok:!1,why:"Pick a crew"};if(t.some(r=>{const o=i.bots.find(l=>l.id===r);return!o||Q[o.sp].alien==="relic"}))return{ok:!1,why:"Relic AIs never leave the Vault"};if(t.length>s.crew)return{ok:!1,why:`At most ${s.crew} bots`};const a=Ye(150*Math.pow(2.3,ai.indexOf(e)*.55));return i.res.credits<a?{ok:!1,why:"Not enough credits for fuel",cost:a}:{ok:!0,cost:a}}function D_(i,e,t,n=Date.now()){const s=_p(i,e,t);if(!s.ok)return s;i.res.credits-=s.cost||0;const a=t.map(l=>i.bots.find(c=>c.id===l)).filter(Boolean);for(const l of a)delete l.post;const r=Id(i,e,a),o={id:Jt("e"),dest:e,crew:t,start:n,end:n+ft[e].hours*36e5,power:r.power,match:r.match};return Ht(i).exps.push(o),i.stats.launches=(i.stats.launches||0)+1,dt(i,20+ai.indexOf(e)*6),hn.push({kind:"launch",dest:e}),{...s,exp:o}}const I_=i=>ft[i].hours*3600;function Mp(i,e){const t=ft[e.dest],n=ai.indexOf(e.dest),s=e.crew.map(u=>i.bots.find(f=>f.id===u)).filter(u=>!!u),a=Id(i,e.dest,s),r=Ln(e.start/1e3>>>0),o=a.mult*(1+i.lvl*.25)*Math.pow(1.3,n),l={credits:Ye(400*o*t.hours),cells:Ye(110*o*t.hours)};r()<.35+.05*t.tier&&(l.dm=2+Math.round(r()*4*t.tier));const c=!(Ht(i).visits[e.dest]>0);c&&(l.dm=(l.dm||0)+10+n*5);const d=r(),h=d<.02*t.tier?"epic":d<.08*t.tier?"elite":d<.3?"advanced":null;return{res:l,rarity:h,first:c,alien:c&&t.alien?t.alien:null}}const N_=i=>Object.keys(ft).filter(e=>ft[e].alien&&(Ht(i).visits[e]||0)>0).length;function U_(i,e=Date.now()){const t=Ht(i),n=[];for(const s of[...t.exps]){if(s.end>e)continue;const a=Mp(i,s);Un(i,a.res);const r=a.alien?Pd(i,a.alien,s.end):a.rarity?as(i,a.rarity,s.start/1e3>>>0,s.end):null;t.visits[s.dest]=(t.visits[s.dest]||0)+1,t.exps=t.exps.filter(o=>o!==s),i.stats.expeditions=(i.stats.expeditions||0)+1,dt(i,25+ai.indexOf(s.dest)*8),n.push({exp:s,res:a.res,gift:r,first:a.first}),hn.push({kind:"expBack",dest:s.dest})}for(const[s,a]of Object.entries(t.outposts)){const r=(e-a.t)/1e3;if(a.t=e,r<=0)continue;const o=wp(s,a.lvl);a.buf=Math.min(o,a.buf+Po(s,a.lvl)*r/3600)}return n}const Po=(i,e)=>ft[i].outpost.rate*(1+.5*(e-1)),wp=(i,e)=>Po(i,e)*8,F_=(i,e)=>Ye(2e3*Math.pow(2.2,ai.indexOf(i)*.6)*Math.pow(2,e));function Sp(i,e){const t=Ht(i).outposts[e],n=t?t.lvl:0;if(!(Ht(i).visits[e]>0))return{ok:!1,why:"Send an expedition there first"};if(n>=10)return{ok:!1,why:"Maximum level"};const s=F_(e,n);return i.res.credits<s?{ok:!1,why:"Not enough credits",cost:s}:{ok:!0,cost:s}}function O_(i,e,t=Date.now()){const n=Sp(i,e);if(!n.ok)return n;i.res.credits-=n.cost||0;const s=Ht(i),a=s.outposts[e];return a?a.lvl++:s.outposts[e]={lvl:1,buf:0,t},i.stats.outposts=Object.keys(s.outposts).length,dt(i,40),n}function k_(i,e){const t=Ht(i).outposts[e];if(!t)return 0;const n=Math.floor(t.buf);return n<=0?0:(t.buf-=n,i.res[ft[e].outpost.res]+=n,n)}const B_={mercury:.4,venus:2.2,earth:4.1,neo:3.5,mars:5.3,ceres:1.2,jupiter:2.6,saturn:.9,uranus:3.9,neptune:5.6,pluto:4.6};class z_{constructor(e){this.canvas=e,this.scene=new Wo,this.camera=new bn(40,1,.1,2e3),this.bodies=new Map,this.picks=[],this.ships=new Map,this.yaw=.6,this.dist=34,this.t=0,this.active=!1,this.ray=new qf,this.onPick=()=>{},this.scene.add(new Xf("#556070",.6));const t=new Wf("#fff2d8",3.2,0,0);this.scene.add(t);const n=new Te(new Nt(1.1,32,20),new ct({color:"#ffd27a",toneMapped:!1}));this.scene.add(n);const s=new zc(new _o({map:_u(),color:"#ffcf7a",blending:fi,depthWrite:!1,transparent:!0}));s.scale.setScalar(7),this.scene.add(s);const a=1500,r=new Float32Array(a*3);for(let f=0;f<a;f++){const g=Math.random()*2-1,y=Math.random()*6.283,m=Math.sqrt(1-g*g);r.set([m*Math.cos(y)*600,g*600,m*Math.sin(y)*600],f*3)}const o=new bt;o.setAttribute("position",new Ft(r,3)),this.scene.add(new qa(o,new ra({size:1.6,sizeAttenuation:!1,color:"#cfe0ff"})));const l=(f,g=.18)=>{const y=[];for(let m=0;m<=128;m++){const p=m/128*Math.PI*2;y.push(new D(Math.cos(p)*f,0,Math.sin(p)*f))}return new Of(new bt().setFromPoints(y),new Mo({color:"#6ee7ff",transparent:!0,opacity:g}))},c=(f,g,y,m,p=!1)=>{const x=new _t,A=new qn(m,3),b=new Float32Array(A.attributes.position.count*3),E=new Ce(y),S=new Ce;for(let P=0;P<A.attributes.position.count;P++){const R=A.attributes.position.getY(P)/m,N=Math.sin(R*9+P*.37)*.06;S.copy(E).offsetHSL(0,0,N+(Math.random()-.5)*.05),b.set([S.r,S.g,S.b],P*3)}A.setAttribute("color",new Ft(b,3));const v=new Te(A,new $t({vertexColors:!0,roughness:.85,flatShading:!0}));if(x.add(v),p){const P=new Te(new Yo(m*1.4,m*2.3,48),new ct({color:"#d9c79a",side:Mn,transparent:!0,opacity:.6}));P.rotation.x=-Math.PI/2.3,x.add(P)}const w=B_[f]??Math.random()*6;return x.position.set(Math.cos(w)*g,0,Math.sin(w)*g),x.userData={r:g,a:w,speed:.08/Math.pow(g,1.5),size:m},this.scene.add(x),this.bodies.set(f,x),x};for(const f of L_)this.scene.add(l(f.dist)),c(f.id,f.dist,f.color,f.size,!!f.ring);const d=700,h=new Float32Array(d*3);for(let f=0;f<d;f++){const g=Math.random()*6.283,y=6.6+Math.random()*1.5;h.set([Math.cos(g)*y,(Math.random()-.5)*.25,Math.sin(g)*y],f*3)}const u=new bt;u.setAttribute("position",new Ft(h,3)),this.scene.add(new qa(u,new ra({size:.05,color:"#a89880"})));for(const f of ai){const g=ft[f];let y;if(g.star){const p=new _t,x=new Te(new Nt(g.size,16,10),new ct({color:g.color,toneMapped:!1}));p.add(x);const A=new zc(new _o({map:_u(),color:g.color,blending:fi,depthWrite:!1,transparent:!0}));A.scale.setScalar(g.size*9),p.add(A),p.position.set(Math.cos(g.angle||0)*g.dist,1.5,Math.sin(g.angle||0)*g.dist),this.scene.add(p),y=p}else if(g.moonOf){const p=this.bodies.get(g.moonOf),x=new _t,A=new Te(new qn(g.size,2),new $t({color:g.color,roughness:.9,flatShading:!0})),b=(p.children[0].geometry.boundingSphere,0);x.add(A);const E=p.userData.size||.4;A.position.x=E+.45+ai.indexOf(f)%3*.25+b,x.userData={spin:.6+ai.indexOf(f)%4*.25,mesh:A},p.add(x),y=A}else this.scene.add(l(g.dist,.1)),y=c(f,g.dist,g.color,g.size);const m=new Te(new Nt(Math.max(.5,g.size*2),8,6),new ct({visible:!1}));m.userData.id=f,y.add(m),this.picks.push(m),this.bodies.set(f,y)}this.input()}input(){let e=null,t=!1,n=0;const s=new Map;this.canvas.addEventListener("pointerdown",a=>{if(this.active&&(s.set(a.pointerId,{x:a.clientX,y:a.clientY}),e={x:a.clientX,y:a.clientY,id:a.pointerId},t=!1,s.size===2)){const[r,o]=[...s.values()];n=Math.hypot(r.x-o.x,r.y-o.y)}}),this.canvas.addEventListener("pointermove",a=>{if(!this.active||!e)return;const r=s.get(a.pointerId);if(!r)return;const o=a.clientX-r.x;if(r.x=a.clientX,r.y=a.clientY,Math.hypot(a.clientX-e.x,a.clientY-e.y)>7&&(t=!0),s.size===2){const[l,c]=[...s.values()],d=Math.hypot(l.x-c.x,l.y-c.y);n&&(this.dist=Math.min(60,Math.max(10,this.dist*n/d))),n=d}else t&&(this.yaw-=o*.006)}),this.canvas.addEventListener("pointerup",a=>{this.active&&(s.delete(a.pointerId),e&&!t&&s.size===0&&this.tap(a.clientX,a.clientY),s.size||(e=null))}),this.canvas.addEventListener("wheel",a=>{this.active&&(this.dist=Math.min(60,Math.max(10,this.dist*Math.pow(1.0015,a.deltaY))))},{passive:!0})}tap(e,t){const n=this.canvas.getBoundingClientRect();this.ray.setFromCamera(new Ie((e-n.left)/n.width*2-1,-((t-n.top)/n.height)*2+1),this.camera);const s=this.ray.intersectObjects(this.picks,!1)[0];s&&this.onPick(s.object.userData.id)}worldPos(e){const t=this.bodies.get(e),n=new D;return t&&t.getWorldPosition(n),n}project(e){const t=e.clone().project(this.camera),n=this.canvas.getBoundingClientRect();return{x:n.left+(t.x*.5+.5)*n.width,y:n.top+(-t.y*.5+.5)*n.height,vis:t.z<1}}focus(e){const t=this.worldPos(e);this.yaw=Math.atan2(t.x,t.z)}syncShips(e,t){const n=new Set;for(const s of e){n.add(s.id);let a=this.ships.get(s.id);a||(a=new Te(new Nn(.12,.4,6),new ct({color:"#7cf29a",toneMapped:!1})),this.scene.add(a),this.ships.set(s.id,a));const r=Math.min(1,Math.max(0,(t-s.start)/(s.end-s.start))),o=this.worldPos("earth"),l=this.worldPos(s.dest),c=o.clone().lerp(l,.5);c.y+=o.distanceTo(l)*.3;const d=new D().copy(o).multiplyScalar((1-r)*(1-r)).addScaledVector(c,2*r*(1-r)).addScaledVector(l,r*r),h=new D().copy(o).multiplyScalar((1-r-.01)**2).addScaledVector(c,2*(r+.01)*(1-r-.01)).addScaledVector(l,(r+.01)**2);a.position.copy(d),a.lookAt(h),a.rotateX(Math.PI/2)}for(const[s,a]of this.ships)n.has(s)||(this.scene.remove(a),this.ships.delete(s))}frame(e,t){this.t+=e;const n=this.canvas.clientWidth||innerWidth,s=this.canvas.clientHeight||innerHeight;this.camera.aspect!==n/s&&(this.camera.aspect=n/s,this.camera.updateProjectionMatrix());for(const[,o]of this.bodies){const l=o.userData;l&&l.r&&(l.a+=l.speed*e,o.position.set(Math.cos(l.a)*l.r,0,Math.sin(l.a)*l.r),o.rotation.y+=e*.3),o.children.forEach(c=>{c.userData&&c.userData.spin&&(c.rotation.y+=e*c.userData.spin)})}const a=.95,r=this.dist*(n/s<.8?1.5:1);this.camera.position.set(Math.sin(this.yaw)*Math.cos(a)*r,Math.sin(a)*r,Math.cos(this.yaw)*Math.cos(a)*r),this.camera.lookAt(0,0,0),t.render(this.scene,this.camera)}}let Gr=null;function _u(){if(Gr)return Gr;const i=document.createElement("canvas");i.width=i.height=128;const e=i.getContext("2d"),t=e.createRadialGradient(64,64,0,64,64,64);return t.addColorStop(0,"rgba(255,240,200,1)"),t.addColorStop(.2,"rgba(255,210,120,0.6)"),t.addColorStop(1,"rgba(255,180,80,0)"),e.fillStyle=t,e.fillRect(0,0,128,128),Gr=new nr(i),Gr}class $_{constructor(e,t){this.canvas=e,this.scene=new Wo,this.island=new Vb,this.views=new Map,this.bots=new Map,this.cam={x:0,z:1,dist:30,yaw:Math.PI/4,tx:0,tz:1,tdist:30,tyaw:Math.PI/4},this.ghost=null,this.ghostObj=null,this.ghostFoot=null,this.selected=null,this.t=0,this.ray=new qf,this.ptr=new Ie,this.fx=[],this.onTap=()=>{},this.pod=null,this.podPick=null,this.podY=0,this.mode="island",this.system=null,this.rockets=[],this.arena=null,this.saved=null,this.onGhostMove=()=>{},this.look={primary:"#e9eef5",accent:"#22c7e8",banner:{bg:"#1b6fd8",fg:"#ffd23a",emblem:"star"}};const n=/Android|iPhone|iPad|iPod/i.test(navigator.userAgent)||navigator.maxTouchPoints>1&&Math.min(screen.width,screen.height)<820;this.quality=t==="auto"?n?"low":"high":t,this.renderer=new Ob({canvas:e,antialias:this.quality==="high",powerPreference:"high-performance"}),this.renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,this.quality==="high"?2:1.5)),this.renderer.outputColorSpace=zt,this.renderer.toneMapping=ud,this.renderer.toneMappingExposure=1.05,this.renderer.shadowMap.enabled=!0,this.renderer.shadowMap.type=cf,this.camera=new bn(30,1,1,16e3);const s=new D(-.55,.62,.42).normalize();this.sun=new Eo("#fff3df",2.7),this.sun.position.copy(s).multiplyScalar(40),this.sun.castShadow=!0;const a=this.quality==="high"?2048:1024;this.sun.shadow.mapSize.set(a,a);const r=this.sun.shadow.camera;r.left=-22,r.right=22,r.top=22,r.bottom=-22,r.near=1,r.far=110,this.sun.shadow.bias=-5e-4,this.sun.shadow.normalBias=.02,this.scene.add(this.sun,this.sun.target),this.scene.add(new Hf("#bcd8ff","#3a2a22",.85)),this.scene.add(new Xf("#405070",.35));const o=new Eo("#7ab6ff",.6);o.position.set(30,10,-30),this.scene.add(o),this.backdrop=new Hb(this.renderer,s,this.quality),this.scene.add(this.backdrop.group),this.scene.add(this.island.group),this.selRing=new Te(new Yo(.9,1,48),new ct({color:"#6ee7ff",transparent:!0,opacity:.9,depthWrite:!1,side:Mn})),this.selRing.rotation.x=-Math.PI/2,this.selRing.visible=!1,this.scene.add(this.selRing),this.resize(),window.addEventListener("resize",()=>this.resize()),this.input()}openMap(){this.system||(this.system=new z_(this.canvas)),this.system.active=!0,this.mode="map",this.select(null)}closeMap(){this.system&&(this.system.active=!1),this.mode="island"}launchFx(e,t){const n=this.views.get(e);if(!n)return;const s=ap(t);s.group.position.copy(n.root.position),s.group.position.y=.3;const a=new Te(new Nn(.25,1.4,10),new ct({color:"#ffd27a",toneMapped:!1}));a.rotation.x=Math.PI,a.position.y=-.6,s.group.add(a);const r=160,o=new Float32Array(r*3).fill(0),l=new Float32Array(r*3),c=new bt;c.setAttribute("position",new Ft(o,3));const d=new qa(c,new ra({color:"#d8dde4",size:.6,transparent:!0,opacity:.75,depthWrite:!1}));this.scene.add(s.group,d),this.rockets.push({g:s.group,t:0,smoke:d,v:l})}enterArena(){this.arena||(this.arena=new P_(this.scene)),this.mode="arena",this.saved={x:this.cam.tx,z:this.cam.tz,dist:this.cam.tdist,yaw:this.cam.tyaw},this.cam.tx=Zc.x,this.cam.tz=Zc.z+.8,this.cam.tdist=19,this.cam.tyaw=0,this.select(null)}exitArena(){this.mode="island",this.saved&&(this.cam.tx=this.saved.x,this.cam.tz=this.saved.z,this.cam.tdist=this.saved.dist,this.cam.tyaw=this.saved.yaw)}resize(){const e=this.canvas.clientWidth||window.innerWidth,t=this.canvas.clientHeight||window.innerHeight;this.renderer.setSize(e,t,!1),this.camera.aspect=e/t,this.camera.updateProjectionMatrix()}placeCamera(){const e=this.cam,t=.18;e.x+=(e.tx-e.x)*t,e.z+=(e.tz-e.z)*t,e.dist+=(e.tdist-e.dist)*t,e.yaw+=(e.tyaw-e.yaw)*t;const n=xo.degToRad(this.mode==="arena"?32:xo.lerp(56,34,ni((e.dist-14)/52))),s=this.camera.aspect<.8?this.mode==="arena"?1.6:1.35:1,a=e.dist*s;this.camera.position.set(e.x+Math.sin(e.yaw)*Math.cos(n)*a,Math.sin(n)*a,e.z+Math.cos(e.yaw)*Math.cos(n)*a),this.camera.lookAt(e.x,0,e.z),this.sun.target.position.set(e.x,0,e.z),this.sun.position.set(e.x-.55*40,.62*40,e.z+.42*40)}focus(e,t,n){this.cam.tx=e,this.cam.tz=t,n&&(this.cam.tdist=n)}clampCam(){const e=this.cam,t=Fe/2+2;e.tx=ni(e.tx,-t,t),e.tz=ni(e.tz,-t,t),e.tdist=ni(e.tdist,12,66)}groundAt(e,t){const n=this.canvas.getBoundingClientRect();this.ptr.set((e-n.left)/n.width*2-1,-((t-n.top)/n.height)*2+1),this.ray.setFromCamera(this.ptr,this.camera);const s=new D;return this.ray.ray.intersectPlane(new Ai(new D(0,1,0),0),s)?s:null}input(){const e=this.canvas,t=new Map;let n=!1,s=0,a=null,r=!1;const o=()=>{const[c,d]=[...t.values()];return{d:Math.hypot(c.x-d.x,c.y-d.y),a:Math.atan2(d.y-c.y,d.x-c.x),cx:(c.x+d.x)/2,cy:(c.y+d.y)/2}};e.addEventListener("pointerdown",c=>{if(this.mode!=="arena"&&(e.setPointerCapture(c.pointerId),t.set(c.pointerId,{x:c.clientX,y:c.clientY,sx:c.clientX,sy:c.clientY}),n=!1,s=performance.now(),t.size===2&&(a=o()),r=!1,this.ghost&&t.size===1)){const d=this.groundAt(c.clientX,c.clientY);if(d){const[h,u]=gn({t:this.ghost.t,r:this.ghost.r}),f=this.ghost.x-Fe/2,g=this.ghost.z-Fe/2;d.x>=f-.5&&d.x<=f+h+.5&&d.z>=g-.5&&d.z<=g+u+.5&&(r=!0)}}}),e.addEventListener("pointermove",c=>{const d=t.get(c.pointerId);if(!d)return;const h=c.clientX-d.x,u=c.clientY-d.y;if(d.x=c.clientX,d.y=c.clientY,Math.hypot(d.x-d.sx,d.y-d.sy)>7&&(n=!0),!!n){if(t.size===1){if(r&&this.ghost){this.ghostTo(c.clientX,c.clientY);return}if(c.buttons===2){this.cam.tyaw-=h*.008;return}const f=this.cam.dist*.0021*(this.camera.aspect<.8?1.35:1),g=Math.cos(this.cam.yaw),y=Math.sin(this.cam.yaw);this.cam.tx-=(h*g+u*y*1.25)*f,this.cam.tz-=(-h*y+u*g*1.25)*f,this.clampCam()}else if(t.size===2&&a){const f=o();this.cam.tdist*=a.d/Math.max(1,f.d),this.cam.tyaw-=f.a-a.a,a=f,this.clampCam()}}});const l=c=>{const d=t.get(c.pointerId);t.delete(c.pointerId),t.size<2&&(a=null),!(!d||n||c.button===2)&&(performance.now()-s>600||this.tap(c.clientX,c.clientY))};e.addEventListener("pointerup",l),e.addEventListener("pointercancel",c=>t.delete(c.pointerId)),e.addEventListener("contextmenu",c=>c.preventDefault()),e.addEventListener("wheel",c=>{c.preventDefault(),this.mode!=="arena"&&(this.cam.tdist*=Math.pow(1.0015,c.deltaY),this.clampCam())},{passive:!1}),window.addEventListener("keydown",c=>{c.target.tagName!=="INPUT"&&((c.key==="q"||c.key==="Q")&&(this.cam.tyaw+=Math.PI/4),(c.key==="e"||c.key==="E")&&(this.cam.tyaw-=Math.PI/4))})}tap(e,t){if(this.ghost){this.ghostTo(e,t);return}const n=this.canvas.getBoundingClientRect();if(this.ptr.set((e-n.left)/n.width*2-1,-((t-n.top)/n.height)*2+1),this.ray.setFromCamera(this.ptr,this.camera),this.podPick&&this.pod&&this.pod.visible&&this.ray.intersectObject(this.podPick,!1)[0]){this.onTap({drop:!0});return}const s=this.ray.intersectObjects([...this.bots.values()].map(c=>c.pick),!1)[0];if(s){this.onTap({bot:s.object.userData.bot});return}const a=[...this.views.values()].map(c=>c.pick),r=this.ray.intersectObjects(a,!1)[0];if(r){this.onTap({item:r.object.userData.item});return}const o=this.ray.intersectObjects(this.island.holoMeshes(),!1)[0];if(o){this.onTap({plot:o.object.userData.plot});return}const l=this.groundAt(e,t);this.onTap(l?{tile:[Math.floor(l.x+Fe/2),Math.floor(l.z+Fe/2)]}:{})}startGhost(e){this.ghost=e,this.island.grid.visible=!0,this.rebuildGhost()}endGhost(){this.ghost=null,this.ghostObj&&this.scene.remove(this.ghostObj),this.ghostObj=null,this.island.grid.visible=!1}ghostTo(e,t){const n=this.groundAt(e,t);if(!n||!this.ghost)return;const[s,a]=gn({t:this.ghost.t,r:this.ghost.r}),r=Math.round(n.x+Fe/2-s/2),o=Math.round(n.z+Fe/2-a/2);(r!==this.ghost.x||o!==this.ghost.z)&&(this.ghost.x=r,this.ghost.z=o,this.onGhostMove())}rotateGhost(){this.ghost&&(this.ghost.r=(this.ghost.r+1)%4,this.rebuildGhost(),this.onGhostMove())}rebuildGhost(){this.ghostObj&&this.scene.remove(this.ghostObj);const e=this.ghost,[t,n]=gn({t:e.t,r:e.r}),s=new _t,a=Xc(e.t,1,e.el,this.look);a.group.rotation.y=-e.r*Math.PI/2,a.group.traverse(r=>{const o=r;o.isMesh&&(o.castShadow=!1)}),s.add(a.group),this.ghostFoot=new Te(new Fi(t,n),Oa.ghostOk),this.ghostFoot.rotation.x=-Math.PI/2,this.ghostFoot.position.y=.04,s.add(this.ghostFoot),this.ghostObj=s,this.scene.add(s)}setGhostOk(e){this.ghost&&(this.ghost.ok=e),this.ghostFoot&&(this.ghostFoot.material=e?Oa.ghostOk:Oa.ghostBad)}sync(e){this.look={primary:e.paint.primary,accent:e.paint.accent,banner:e.banner,name:e.name};const t=JSON.stringify(this.look),n=[];for(let c=0;c<5;c++)for(let d=0;d<5;d++){const h=`${c},${d}`;$o(e,h)==="buyable"&&n.push(h)}const s=En(e);this.island.build(s.plots,n,s.turf||(Bt[e.at]?Bt[e.at].theme:"haven")),this.backdrop.setWorld(Bt[e.at]?Bt[e.at].world:"earth");const a=new Set;for(const c of s.items){const[d,h]=gn(c);for(let u=c.x;u<c.x+d;u++)for(let f=c.z;f<c.z+h;f++)a.add(u+","+f)}this.island.scatter(s.plots,a);const r=new Set;for(const c of s.items){r.add(c.id);const d=At(e,c.id,"build"),h=c.t==="pad"&&Ht(e).exps.length<Qs(c.lvl)?1:0,u=`${c.t}|${c.lvl}|${c.el}|${c.r}|${t}|${d?1:0}|${h}`;let f=this.views.get(c.id);(!f||f.key!==u)&&(f&&this.scene.remove(f.root),f=this.makeView(c,u,!!d,c.t==="pad"&&!h),this.views.set(c.id,f)),this.ghost&&this.ghost.move===c.id?f.root.visible=!1:f.root.visible=!0}for(const[c,d]of this.views)r.has(c)||(this.scene.remove(d.root),this.views.delete(c));const o=new Set;for(const c of e.bots){const d=c.post||c.bay;if(!d||za(e,c))continue;const h=Rt(e,d);if(!h||es(e,d)!==e.at)continue;o.add(c.id);const u=`${c.sp}|${Math.floor(c.lvl/5)}`;let f=this.bots.get(c.id);if(!f||f.key!==u){f&&this.scene.remove(f.model.group);const g=jo(c.sp,c.lvl),y=this.centerOf(h),m=new D(y.x+(Math.random()-.5)*1.6,.26,y.z+(Math.random()-.5)*1.6),p=new Te(new Nt(.45,8,6),new ct({visible:!1}));p.position.y=.45,p.userData.bot=c.id,g.group.add(p),g.group.position.copy(m),this.scene.add(g.group),f={key:u,model:g,pos:m,target:m.clone(),wait:Math.random()*2,bay:d,pick:p},this.bots.set(c.id,f)}f.bay!==d&&(f.bay=d,f.wait=0)}for(const[c,d]of this.bots)o.has(c)||(this.scene.remove(d.model.group),this.bots.delete(c));const l=pt(e);l.drops>0&&l.dropAt?(this.pod||(this.pod=u_(),this.podPick=new Te(new Xn(1,1.6,1),new ct({visible:!1})),this.podPick.position.y=.6,this.pod.add(this.podPick),this.pod.traverse(c=>{c.isMesh&&(c.castShadow=!0)}),this.scene.add(this.pod),this.podY=30),this.pod.position.set(l.dropAt[0]+.5-Fe/2,this.pod.position.y,l.dropAt[1]+.5-Fe/2),this.pod.visible=!0):this.pod&&(this.pod.visible=!1,this.scene.remove(this.pod),this.pod=null)}podTop(){return this.pod&&this.pod.visible?new D(this.pod.position.x,this.pod.position.y+1.6,this.pod.position.z):null}centerOf(e){const[t,n]=gn(e);return new D(e.x+t/2-Fe/2,0,e.z+n/2-Fe/2)}topOf(e){const t=this.views.get(e);if(!t)return null;const n=t.root.position.clone();return n.y=t.model.height+.3,n}makeView(e,t,n,s=!1){const a=new _t,r=Xc(e.t,e.lvl,e.el,s?{...this.look,noRocket:!0}:this.look);r.group.rotation.y=-e.r*Math.PI/2,a.add(r.group);const[o,l]=gn(e);a.position.copy(this.centerOf(e));const c=new Te(new Xn(o*.95,Math.max(.6,r.height),l*.95),new ct({visible:!1}));c.position.y=Math.max(.6,r.height)/2,c.userData.item=e.id,a.add(c);let d;return n&&(d=f_(o,l,Math.max(.8,r.height*.8)),a.add(d),e.lvl===0&&(r.group.scale.y=.25)),this.scene.add(a),{key:t,root:a,model:r,pick:c,scaf:d}}select(e,t){if(this.selected=e,this.selRing.visible=!!e,e&&t){const n=Rt(t,e);if(!n)return;const[s,a]=gn(n),r=this.centerOf(n);this.selRing.position.set(r.x,.05,r.z),this.selRing.scale.setScalar(Math.max(s,a)*.72)}}burst(e,t,n=26){const s=new Float32Array(n*3),a=new Float32Array(n*3);for(let l=0;l<n;l++){s.set([e.x,e.y,e.z],l*3);const c=Math.random()*Math.PI*2,d=Math.random();a.set([Math.cos(c)*d*2.2,2+Math.random()*3,Math.sin(c)*d*2.2],l*3)}const r=new bt;r.setAttribute("position",new Ft(s,3));const o=new qa(r,new ra({color:t,size:.22,transparent:!0,depthWrite:!1,blending:fi}));this.scene.add(o),this.fx.push({pts:o,v:a,life:1})}project(e){const t=new D(e.x,e.y,e.z).project(this.camera),n=this.canvas.getBoundingClientRect();return{x:n.left+(t.x*.5+.5)*n.width,y:n.top+(-t.y*.5+.5)*n.height,vis:t.z<1&&t.z>-1}}frame(e,t){this.t+=e;const n=this.t;if(this.mode==="map"&&this.system){this.system.syncShips(Ht(t).exps,Date.now()),this.system.frame(e,this.renderer);return}for(const s of[...this.rockets]){s.t+=e;const a=Math.min(60,s.t*s.t*2.2);s.g.position.y=.3+a,s.g.rotation.y+=e*.4;const r=s.smoke.geometry.attributes.position;for(let o=0;o<r.count;o++)r.getY(o)===0&&Math.random()<.3&&s.t<3?(r.setXYZ(o,s.g.position.x,s.g.position.y-.4,s.g.position.z),s.v.set([(Math.random()-.5)*1.2,-.5-Math.random(),(Math.random()-.5)*1.2],o*3)):r.getY(o)!==0&&(r.setXYZ(o,r.getX(o)+s.v[o*3]*e,Math.max(.05,r.getY(o)+s.v[o*3+1]*e),r.getZ(o)+s.v[o*3+2]*e),s.v[o*3]*=.98,s.v[o*3+2]*=.98);r.needsUpdate=!0,s.smoke.material.opacity=Math.max(0,.75-Math.max(0,s.t-3)*.25),s.t>6&&(this.scene.remove(s.g,s.smoke),s.smoke.geometry.dispose(),this.rockets.splice(this.rockets.indexOf(s),1))}this.mode==="arena"&&(this.cam.tyaw=Math.sin(n*.15)*.35,this.arena?.update(e)),this.placeCamera(),this.backdrop.update(n,this.camera),this.island.update(n);for(const[s,a]of this.views){const r=!!(At(t,s,"craft")||At(t,s,"fuse")),o=Rt(t,s),l=o&&o.t==="assembly"?t.cores.filter(c=>c.state!=="waiting").map(c=>({color:We[Q[c.sp].rarity].color,ready:c.state==="ready"})):void 0;if(a.model.anim?.(n,{working:r,ready:t.ready[s]?1:0,cores:l}),a.scaf){const c=a.scaf.getObjectByName("crane");c&&(c.rotation.y=n*.8)}}for(const[,s]of this.bots){const a=Rt(t,s.bay);if(!a)continue;const r=this.centerOf(a),o=s.target.clone().sub(s.pos);o.y=0;const l=o.length();let c=!1;if(l>.05){c=!0,o.normalize(),s.pos.addScaledVector(o,Math.min(l,e*(l>2?2.2:.7))),s.pos.y+=(s.target.y-s.pos.y)*Math.min(1,e*4);const d=Math.atan2(o.x,o.z),h=s.model.group;let u=d-h.rotation.y;u=Math.atan2(Math.sin(u),Math.cos(u)),h.rotation.y+=u*Math.min(1,e*6)}else if(s.wait-=e,s.wait<=0){const d=Math.random()*Math.PI*2,h=a.t==="bay"||a.t==="relicbay",[u,f]=gn(a),g=h?.35+Math.random()*.75:Math.max(u,f)/2+.25+Math.random()*.3;s.target.set(r.x+Math.cos(d)*g,h?.26:0,r.z+Math.sin(d)*g),s.wait=(h?1.5:3)+Math.random()*4}s.model.group.position.copy(s.pos),s.model.anim(n,c)}if(this.selRing.visible&&(this.selRing.material.opacity=.55+Math.sin(n*4)*.3),this.pod&&this.pod.visible){this.podY=Math.max(0,this.podY-e*Math.max(4,this.podY*1.6)),this.pod.position.y=this.podY;const s=this.pod.userData.flame;s.visible=this.podY>.05,s.scale.y=.8+Math.random()*.5,this.pod.userData.beacon.material.color.set(Math.sin(n*5)>0?"#7cf29a":"#1a4a2a"),this.pod.rotation.y+=e*(this.podY>0?2:0)}if(this.ghost&&this.ghostObj){const[s,a]=gn({t:this.ghost.t,r:this.ghost.r});this.ghostObj.position.set(this.ghost.x+s/2-Fe/2,.02+Math.sin(n*5)*.03,this.ghost.z+a/2-Fe/2)}for(const s of[...this.fx]){s.life-=e*1.1;const a=s.pts.geometry.attributes.position;for(let r=0;r<a.count;r++)s.v[r*3+1]-=e*6,a.setXYZ(r,a.getX(r)+s.v[r*3]*e,a.getY(r)+s.v[r*3+1]*e,a.getZ(r)+s.v[r*3+2]*e);a.needsUpdate=!0,s.pts.material.opacity=Math.max(0,s.life),s.life<=0&&(this.scene.remove(s.pts),s.pts.geometry.dispose(),this.fx.splice(this.fx.indexOf(s),1))}this.renderer.render(this.scene,this.camera)}}class H_{constructor(e){this.renderer=e,this.scene=new Wo,this.cam=new bn(30,1,.1,100),this.cache=new Map,this.size=192,this.rt=new Vn(this.size,this.size,{samples:4}),this.rt.texture.colorSpace=zt;const t=new Eo("#fff3df",2.6);t.position.set(-3,5,4),this.scene.add(t,new Hf("#cfe4ff","#3a2a22",1.1));const n=new Eo("#7ab6ff",.9);n.position.set(4,2,-4),this.scene.add(n)}shoot(e,t,n,s){const a=this.cache.get(t);if(a)return a;this.scene.add(e),this.cam.position.set(n*.7,s+n*.55,n*.85),this.cam.lookAt(0,s*.45,0);const r=this.renderer.getRenderTarget(),o=this.renderer.getClearColor(new Ce),l=this.renderer.getClearAlpha(),c=this.renderer.shadowMap.enabled;this.renderer.setClearColor(0,0),this.renderer.setRenderTarget(this.rt),this.renderer.clear(),this.renderer.render(this.scene,this.cam);const d=new Uint8Array(this.size*this.size*4);this.renderer.readRenderTargetPixels(this.rt,0,0,this.size,this.size,d),this.renderer.setRenderTarget(r),this.renderer.setClearColor(o,l),this.renderer.shadowMap.enabled=c,this.scene.remove(e);const h=document.createElement("canvas");h.width=h.height=this.size;const u=h.getContext("2d"),f=u.createImageData(this.size,this.size);for(let y=0;y<this.size;y++)f.data.set(d.subarray((this.size-1-y)*this.size*4,(this.size-y)*this.size*4),y*this.size*4);u.putImageData(f,0,0);const g=h.toDataURL("image/png");return this.cache.set(t,g),g}building(e,t,n,s){const a=Xc(e,t,n,s),[r,o]=Qe[e].size,l=Math.max(r,o);return this.shoot(a.group,`b|${e}|${t}|${n}|${s.primary}${s.accent}${s.banner.bg}${s.banner.fg}${s.banner.emblem}`,l*1.55+.8,Math.max(.6,a.height*.6))}bot(e){const t=jo(e,1);t.group.rotation.y=.5;const n=t.group.getObjectByName("hoverGlow");return n&&(n.visible=!1),this.shoot(t.group,`bot|${e}`,1.75,.55)}}const fs={credits:'<span class="ic cr">C</span>',cells:'<span class="ic ce">⚡</span>',dm:'<span class="ic dm">◆</span>'},Vr=i=>`<span class="els">${i.map(e=>`<span class="el" style="background:${Be[e].color}" title="${Be[e].name}">${Be[e].glyph}</span>`).join("")}</span>`,Wr=i=>{const e=We[Q[i].rarity];return`<span class="rar" style="color:${e.color}">${e.name}</span>`},Ws=i=>i.t==="bay"?`${Be[i.el].name} Bay`:Qe[i.t].name;class G_{constructor(e){this.ui=e,this.fuseA=null,this.fuseB=null,this.dexR="all",this.picking=null}get s(){return this.ui.app.s}get app(){return this.ui.app}img(e,t=!0,n=0){return`<img src="${this.app.studio.bot(e)}" alt="" style="${n?`width:${n}px;height:${n}px;`:""}${t?"":"filter:brightness(0) opacity(0.55)"}">`}botPanel(e){const t=this.s,n=Q[e.sp],s=ia(e),a=Bo(e.lvl);let r=0;for(let l=e.fed;l<4;l++)r+=a;const o=e.post?`Helping at the ${Ws(Rt(t,e.post))}`:e.stored?"In storage (not earning)":e.bay?`Lives in the ${Ws(Rt(t,e.bay))}`:"";return`<button class="ibtn x" data-a="deselect">✕</button><div class="row" style="align-items:flex-start;gap:12px"><div class="pic" style="width:96px;height:96px;border-radius:16px;background:radial-gradient(circle at 50% 40%, ${Be[n.el[0]].color}66, transparent 70%);flex:none;display:grid;place-items:center;overflow:hidden">${this.img(e.sp,!0,96)}</div>
      <div class="grow"><h2>${re(e.nick||n.name)} <button class="btn small" data-a="rename" data-bot="${e.id}" style="min-height:26px;padding:2px 8px">✎</button></h2><div class="sub">${e.nick?re(n.name)+" · ":""}${Wr(e.sp)} · ${Vr(n.el)}</div>
      <div class="sub">Level ${e.lvl}<span class="pips">${[0,1,2,3].map(l=>`<i class="${l<e.fed?"on":""}"></i>`).join("")}</span></div><div class="sub">${re(o)}</div></div></div>
      <p class="desc">${re(n.desc)}</p><table class="stats"><tr><td>Earns</td><td>${e.post||e.stored?"<s>":""}${fs.credits} ${se(Ei(e))}/min${e.post||e.stored?"</s>":""}</td></tr><tr><td>Hull · attack</td><td>${se(s.hp)} · ${se(s.atk)}</td></tr><tr><td>Moves from</td><td>${n.el.map(l=>Be[l].name).join(", ")}</td></tr></table>
      ${e.lvl<ko?`<div class="row"><button class="btn green small grow" data-a="feed" data-bot="${e.id}"><span class="cost" data-cost="cells:${a}">${fs.cells}${se(a)}</span> Feed</button><button class="btn green small grow" data-a="feedLvl" data-bot="${e.id}"><span class="cost" data-cost="cells:${r}">${fs.cells}${se(r)}</span> To level ${e.lvl+1}</button></div>`:'<p class="sub">Maximum level.</p>'}
      <div class="row" style="margin-top:8px">${e.stored?`<button class="btn small" data-a="unstore" data-bot="${e.id}">⬆ Activate</button>`:`<button class="btn small" data-a="pickBay" data-bot="${e.id}">⇄ Move</button>${e.post?`<button class="btn small" data-a="unpost" data-bot="${e.id}">↩ Back to bay</button>`:`<button class="btn small" data-a="pickPost" data-bot="${e.id}">🛠 Help a building</button>`}<button class="btn small" data-a="store" data-bot="${e.id}">❄ Store</button>`}
      <button class="btn small" data-a="release" data-bot="${e.id}">Release (${fs.credits}${se(Du(e))})</button></div>`}helpersHTML(e){if(!Si[e.t]||e.lvl<1)return"";const t=this.s,n=oo(t,e.id),s=ta(e.lvl),a=tr(t,e);return`<div class="sub" style="margin-top:10px">Helpers · +${Math.round(a*100)}% ${Qd[e.t]} · best: ${Si[e.t].map(r=>Be[r].glyph).join(" ")} bots</div><div class="row">${n.map(r=>`<button class="btn small" data-a="selBot" data-bot="${r.id}" style="padding:2px 8px 2px 2px"><img src="${this.app.studio.bot(r.sp)}" style="width:30px;height:30px">L${r.lvl}</button>`).join("")}${n.length<s?`<button class="btn small" data-a="pickHelper" data-id="${e.id}">＋ Add helper (${n.length}/${s})</button>`:""}</div>`}fusionHTML(e){const t=this.s,n=At(t,e.id,"fuse");let s="";if(n){const a=ui((n.end-Date.now())/1e3);s+=`<div class="row" style="justify-content:center;gap:16px;margin:6px 0">${(n.parents||[]).map(r=>{const o=t.bots.find(l=>l.id===r);return o?`<div style="width:70px;text-align:center">${this.img(o.sp,!0,64)}<div class="sub" style="margin:0">L${o.lvl}</div></div>`:""}).join('<b style="font-size:24px">+</b>')}</div>
      <p class="desc" style="text-align:center">Fusing… the new core's rarity is revealed when it is done.</p><div class="bar"><i data-bar="${n.id}"></i></div><div class="row" style="margin-top:8px"><b class="grow" data-left="${n.id}"></b><button class="btn gold small" data-a="finish" data-job="${n.id}" data-dm="${n.id}">${a?`${fs.dm}${a} Finish now`:"Finish (free)"}</button></div>`}else{const a=t.bots.find(l=>l.id===this.fuseA),r=t.bots.find(l=>l.id===this.fuseB),o=(l,c)=>`<button class="card" data-a="pickFuse" data-slot="${c}" style="width:46%;align-items:center;min-height:120px">${l?`${this.img(l.sp,!0,72)}<b>${re(l.nick||Q[l.sp].name)}</b><span class="sub" style="margin:0">L${l.lvl} ${Vr(Q[l.sp].el)}</span>`:`<span style="font-size:34px;opacity:.6">＋</span><span class="sub" style="margin:0">Pick a bot<br>(level ${Zi}+)</span>`}</button>`;if(s+=`<p class="desc">Fuse two bots of level ${Zi} or more. Both parents stay with you; the child's elements come from both.</p><div class="row" style="justify-content:space-between">${o(a,"A")}${o(r,"B")}</div>`,a&&r&&a!==r){const l=Cu(a,r),c=Pu(t,e,a.id,r.id);s+=`<div class="sub" style="margin-top:10px">Possible results</div><div class="bots" style="grid-template-columns:repeat(auto-fill,minmax(92px,1fr))">${l.map(d=>{const h=!!t.dex[d.sp];return`<div class="rec"><div style="width:56px;height:56px">${this.img(d.sp,h,56)}</div><b>${h?re(Q[d.sp].name):"???"}</b>${Wr(d.sp)}<span class="out" style="font-size:13px">${(d.p*100).toFixed(d.p<.1?1:0)}%</span></div>`}).join("")}</div>
          <div class="row" style="margin-top:8px"><span class="grow"><span class="cost ${t.res.credits<(c.cost||0)?"short":""}" data-cost="credits:${c.cost||Jl(a,r)}">${fs.credits}${se(c.cost||Jl(a,r))}</span> · ${xt(jl(t,e,l[l.length-1].sp))}–${xt(jl(t,e,l[0].sp))}</span><button class="btn gold" data-a="fuse" data-id="${e.id}" ${c.ok?"":"disabled"}>🧬 Fuse</button></div>${c.ok?"":`<p class="why">${re(c.why||"")}</p>`}`}}return s+this.helpersHTML(e)}assemblyHTML(e){const t=this.s,n=t.cores.map(s=>{const a=t.jobs.find(l=>l.kind==="boot"&&l.core===s.id),r=We[Q[s.sp].rarity],o=`<div class="pic" style="width:48px;height:48px;border-radius:50%;background:radial-gradient(circle at 40% 35%, #fff, ${r.color} 45%, ${r.color}55 70%, transparent 72%)"></div>`;if(s.state==="ready")return`<div class="botc">${o}<div><b style="color:${r.color}">${r.name} core</b><div class="meta">Booted: ready to activate</div></div><button class="btn gold small" data-a="activate" data-core="${s.id}">Activate</button></div>`;if(a){const l=ui((a.end-Date.now())/1e3);return`<div class="botc">${o}<div><b style="color:${r.color}">${r.name} core</b><div class="meta">Booting · <span data-left="${a.id}">${xt((a.end-Date.now())/1e3)}</span></div><div class="bar" style="margin-top:4px"><i data-bar="${a.id}"></i></div></div><button class="btn gold small" data-a="finish" data-job="${a.id}" data-dm="${a.id}">${l?`${fs.dm}${l}`:"Free"}</button></div>`}return`<div class="botc">${o}<div><b style="color:${r.color}">${r.name} core</b><div class="meta">Queued: waiting for a free pod</div></div><span></span></div>`}).join("");return`<p class="desc">${ka(e.lvl)} pod${ka(e.lvl)>1?"s":""} boot cores side by side. Cores arrive from the shop (Advanced bots), the Fusion Lab and events.</p><div class="bots">${n||'<p class="desc">No cores right now.</p>'}</div>`+this.helpersHTML(e)}picker(e,t){this.ui.modal(`<h1 style="font-size:20px">${e}</h1><div class="bots" style="max-height:56vh;overflow:auto;text-align:left">${t||'<p class="desc">Nobody fits yet.</p>'}</div><button class="btn" data-a="closeModal" style="margin-top:10px">Cancel</button>`)}pickRow(e,t,n="",s="Pick"){const a=Q[e.sp];return`<div class="botc"><div class="pic">${this.img(e.sp)}</div><div><b>${re(e.nick||a.name)}</b> ${Vr(a.el)}<div class="meta">${Wr(e.sp)} · L${e.lvl}${e.post?" · helping":""}${e.stored?" · stored":""}</div></div><button class="btn small gold" data-a="${t}" data-bot="${e.id}" ${n}>${s}</button></div>`}dexHTML(){const e=this.s,t=Qc(e),n=Ct.map(a=>[a,$n.filter(r=>Q[r].rarity===a).length,$n.filter(r=>Q[r].rarity===a&&e.dex[r]).length]),s=$n.filter(a=>this.dexR==="all"||Q[a].rarity===this.dexR);return`<div class="head"><h1>Botdex</h1><span class="sub">${t} / ${$n.length} discovered</span><button class="ibtn" data-a="close">✕</button></div>
      <div class="tabs"><button class="tab ${this.dexR==="all"?"on":""}" data-a="dexR" data-r="all">All</button>${n.map(([a,r,o])=>`<button class="tab ${this.dexR===a?"on":""}" data-a="dexR" data-r="${a}" style="color:${We[a].color}">${We[a].name} ${o}/${r}</button>`).join("")}</div>
      <div class="body"><p class="sub" style="text-align:center">Every new species pays Dark Matter (${Ru.map((a,r)=>`<span style="color:${We[Ct[r]].color}">${a}</span>`).join(" · ")} by rarity). Elements are shown so you can plan fusions.</p>
      <div class="grid" style="grid-template-columns:repeat(auto-fill,minmax(132px,1fr))">${s.map(a=>{const r=Q[a],o=!!e.dex[a],l=o?`${e.bots.filter(c=>c.sp===a).length} owned`:r.alien==="contact"?"First contact":r.alien==="swarm"?"Defeat the Swarm":r.price?`Shop · level ${r.unlock}`:r.el.length>1?"Fusion":"";return`<div class="card" style="align-items:center;text-align:center;gap:3px;${o?"":"opacity:.8"}"><div class="thumb" style="height:96px;width:100%">${this.img(a,o)}</div><b>${o?re(r.name):"???"}</b>${Wr(a)}${Vr(r.el)}<span class="sub" style="margin:0">${l}</span></div>`}).join("")}</div></div>`}act(e,t){const n=this.s,s=this.app,a=this.ui,r=t.dataset.bot?n.bots.find(o=>o.id===t.dataset.bot):void 0;switch(e){case"selBot":return r&&(a.closeModal(),a.selectBot(r.id),s.audio.play("tap")),!0;case"feedLvl":if(r){let o=!1,l=0;for(;r.fed>0||!o;){const c=sd(n,r);if(!c.ok){l||a.deny(c.why);break}if(l++,c.lvlUp){o=!0;break}}if(l){s.audio.play(o?"done":"feed");const c=t.getBoundingClientRect();a.popText(c.left+c.width/2,c.top,o?`Level ${r.lvl}!`:`+${l} feeds`,o?"#ffd36a":"#9dff5a"),s.changed(),a.renderPanel()}}return!0;case"rename":if(r){const o=prompt("Name this bot",r.nick||Q[r.sp].name);if(o!==null){const l=o.trim().slice(0,18);l&&l!==Q[r.sp].name?r.nick=l:delete r.nick,s.changed(),a.renderPanel()}}return!0;case"pickBay":if(r){const o=ze(n,"bay").filter(l=>l.lvl>0&&l.el&&Q[r.sp].el.includes(l.el)&&l.id!==r.bay);this.ui.modal(`<h1 style="font-size:20px">Move ${re(r.nick||Q[r.sp].name)}</h1><div class="bots" style="text-align:left">${o.map(l=>{const c=Dn(n,l.id).length,d=ti(l.lvl);return`<div class="botc"><div class="pic" style="background:${Be[l.el].color}44">${Be[l.el].glyph}</div><div><b>${Ws(l)}</b><div class="meta">Level ${l.lvl} · ${c}/${d} bots</div></div><button class="btn small gold" data-a="moveTo" data-bot="${r.id}" data-id="${l.id}" ${c<d?"":"disabled"}>Move</button></div>`}).join("")||`<p class="desc">No other ${Q[r.sp].el.map(l=>Be[l].name).join("/")} Bay yet.</p>`}</div><button class="btn" data-a="closeModal" style="margin-top:10px">Cancel</button>`)}return!0;case"moveTo":return r&&t.dataset.id&&(Qu(n,r,t.dataset.id)?(delete r.post,s.audio.play("place"),a.closeModal(),s.changed(),a.renderPanel()):a.deny("That bay is full")),!0;case"pickPost":if(r){const o=Uo(n).filter(l=>Si[l.t]&&l.lvl>0);this.ui.modal(`<h1 style="font-size:20px">Where should ${re(r.nick||Q[r.sp].name)} help?</h1><p class="sub">A helper stops earning credits while it works. Bots with a matching element help 50% more.</p><div class="bots" style="text-align:left">${o.map(l=>{const c=Lu(n,r,l),d=Q[r.sp].el.some(h=>Si[l.t].includes(h));return`<div class="botc"><div class="pic" style="background:rgba(110,231,255,.12)">${{command:"🏛",fab:"⚡",fusion:"🧬",assembly:"🤖"}[l.t]||"🏗"}</div><div><b>${Ws(l)}</b><div class="meta">${Qd[l.t]}${d?' · <b style="color:#7cf29a">element match</b>':""} · ${oo(n,l.id).length}/${ta(l.lvl)}</div></div><button class="btn small gold" data-a="postTo" data-bot="${r.id}" data-id="${l.id}" ${c.ok?"":"disabled"}>Assign</button></div>`}).join("")}</div><button class="btn" data-a="closeModal" style="margin-top:10px">Cancel</button>`)}return!0;case"postTo":if(r&&t.dataset.id){const o=Rt(n,t.dataset.id),l=Xp(n,r,o);l.ok?(s.audio.play("place"),a.closeModal(),s.changed(),a.renderPanel(),a.toast(`${r.nick||Q[r.sp].name} is now helping at the ${Ws(o)}`,"good")):a.deny(l.why)}return!0;case"pickHelper":{const o=Rt(n,t.dataset.id||"");if(!o)return!0;const l=n.bots.filter(c=>!c.stored&&c.post!==o.id).sort((c,d)=>Number(Q[d.sp].el.some(h=>Si[o.t].includes(h)))-Number(Q[c.sp].el.some(h=>Si[o.t].includes(h)))||d.lvl-c.lvl);return this.picker(`Helper for the ${Ws(o)}`,l.map(c=>this.pickRow(c,"postTo",`data-id="${o.id}"`,Q[c.sp].el.some(d=>Si[o.t].includes(d))?"Assign ★":"Assign")).join("")),!0}case"unpost":return r&&(qp(r),s.changed(),a.renderPanel(),s.audio.play("tap")),!0;case"store":return r&&(Yp(n,r),s.changed(),a.renderPanel(),s.audio.play("tap"),a.toast("Stored: it stops earning until you activate it","")),!0;case"unstore":if(r){const o=Kp(n,r);o.ok?(s.audio.play("place"),s.changed(),a.renderPanel()):a.deny(o.why)}return!0;case"release":if(r){if(!t.dataset.sure)return t.dataset.sure="1",t.innerHTML="Tap again to release",!0;const o=Zp(n,r);o.ok?(s.audio.play("buy"),a.select(null),s.changed(),a.toast(`Released for ${se(o.cost||0)} credits`,"gold")):a.deny(o.why)}return!0;case"pickFuse":{const o=t.dataset.slot,l=o==="A"?this.fuseB:this.fuseA,c=n.bots.filter(d=>d.lvl>=Zi&&d.id!==l).sort((d,h)=>Ct.indexOf(Q[h.sp].rarity)-Ct.indexOf(Q[d.sp].rarity)||h.lvl-d.lvl);return this.picking={kind:"fuse",ctx:o},this.picker(`Parent ${o}`,c.map(d=>this.pickRow(d,"fusePick",`data-slot="${o}"`)).join("")||`<p class="desc">No bots at level ${Zi} yet: feed your crew Power Cells.</p>`),!0}case"fusePick":return r&&(t.dataset.slot==="A"?this.fuseA=r.id:this.fuseB=r.id,a.closeModal(),a.renderPanel(),s.audio.play("tap")),!0;case"fuse":{const o=Rt(n,t.dataset.id||"");if(!o||!this.fuseA||!this.fuseB)return!0;const l=Gp(n,o,this.fuseA,this.fuseB);return l.ok?(s.audio.play("build"),this.fuseA=this.fuseB=null,s.changed(),a.renderPanel(),a.toast("Fusion started","good")):a.deny(l.why),!0}case"activate":{const o=Wp(n,t.dataset.core||"");return o.ok&&o.bot?(s.audio.play("levelup"),s.changed(),a.renderPanel(),a.newBot(o.bot),o.bot.stored&&a.toast("No room in a matching bay: it waits in storage","gold")):a.deny(o.why),!0}case"dexR":return this.dexR=t.dataset.r||"all",a.renderOver(),s.audio.play("tap"),!0}return!1}}const Pa={credits:'<span class="ic cr">C</span>',cells:'<span class="ic ce">⚡</span>',dm:'<span class="ic dm">◆</span>'},Xr=i=>Object.entries(i).filter(([,e])=>e>0).map(([e,t])=>`<span class="cost">${Pa[e]||""}${se(t)}</span>`).join(" "),Mu=(i,e=34)=>`<span style="display:inline-block;width:${e}px;height:${e}px;border-radius:50%;background:radial-gradient(circle at 40% 35%, #fff, ${We[i].color} 45%, ${We[i].color}55 70%, transparent 72%);vertical-align:middle"></span>`;class V_{constructor(e){this.ui=e,this.tab="calendar"}get s(){return this.ui.app.s}get app(){return this.ui.app}hudHTML(){const e=this.s,t=so(e),n=pt(e),s=o=>o?'<i class="rdot"></i>':"",a=e.raid;return`${a&&a.eta?`<button class="chip raid" data-a="raid">⚠ Swarm ${xt((a.eta-Date.now())/1e3)}</button>`:""}<button class="ibtn" data-a="daily" title="Daily rewards">📅${s(t.day||t.missions||t.ach)}</button><button class="ibtn" data-a="spin" title="Free daily core">🎁${s(t.spin)}</button><button class="chip ${n.drops?"hot":""}" data-a="drop" title="Supply drop">📦 <span id="dropT">${n.drops?`Open${n.drops>1?" ×"+n.drops:""}!`:xt((n.drop-Date.now())/1e3)}</span></button>`}overHTML(){const e=this.s,t=pt(e),n=so(e),s=[["calendar","Calendar",n.day],["missions","Missions",n.missions],["ach","Achievements",n.ach]];let a="";if(this.tab==="calendar"){const r=el(e);a=`<div class="row" style="justify-content:center;gap:18px;margin-bottom:10px"><div class="ox" style="font-size:18px">🔥 ${t.streak} day streak</div><div class="sub" style="margin:0">Best ${t.best} · ${t.total} days in all${t.cycle?` · cycle ${t.cycle+1}`:""}</div></div>
        <p class="sub" style="text-align:center">Rewards grow every day. Miss a day and the calendar simply waits for you: it never resets.</p><div class="cal">${Array.from({length:28},(o,l)=>{const c=Cd(e,l),d=l<t.day,h=l===t.day&&r,u=c.core?Mu(c.core,30):c.decor?'<span style="font-size:26px">🌟</span>':c.res.dm&&!c.res.credits&&!c.res.cells?'<span style="font-size:22px">◆</span>':"";return`<div class="day ${d?"done":""} ${h?"today":""} ${Rd[l]?"special":""}" ${h?'data-a="claimDay"':""}><b>Day ${l+1}</b>${u}<span class="dr">${Xr(c.res)}</span>${c.label?`<span class="lbl">${re(c.label)}</span>`:""}${d?'<span class="tick">✓</span>':""}</div>`}).join("")}</div>
        ${r?`<div class="row" style="justify-content:center;margin-top:12px"><button class="btn gold" data-a="claimDay">Claim day ${t.day+1}</button>${this.app.platform.adsAvailable?'<button class="btn" data-a="claimDayAd">▶ Watch an ad: double it</button>':""}</div>`:`<p class="sub" style="text-align:center;margin-top:12px">Come back tomorrow for day ${t.day+1}.</p>`}`}else this.tab==="missions"?(Za(e),a=`<p class="sub" style="text-align:center">New missions every day. Finish all three for the bonus chest.</p><div class="bots" style="max-width:520px;margin:0 auto">${t.missions.map((r,o)=>{const l=Math.min(r.n,tl(e,r)),c=l>=r.n,d=t.mClaimed[o];return`<div class="botc" style="grid-template-columns:1fr auto"><div><b>${re(r.text)}</b><div class="bar" style="margin:6px 0 4px"><i style="width:${l/r.n*100}%"></i></div><div class="meta">${se(l)} / ${se(r.n)} · reward ${Xr(r.reward)}</div></div>${d?'<span class="sub">✓ Done</span>':`<button class="btn ${c?"gold":""} small" data-a="claimMission" data-i="${o}" ${c?"":"disabled"}>Claim</button>`}</div>`}).join("")}
        <div class="botc chest ${js(e)?"ready":""}" style="grid-template-columns:54px 1fr auto"><div style="font-size:36px;text-align:center">🧰</div><div><b>Bonus chest</b><div class="meta">Dark Matter, Power Cells and a chance of an Advanced or Elite core</div></div>${t.bonus?'<span class="sub">✓ Opened</span>':`<button class="btn ${js(e)?"gold":""} small" data-a="claimBonus" ${js(e)?"":"disabled"}>Open</button>`}</div></div>`):a=`<div class="bots" style="max-width:620px;margin:0 auto">${il.map(r=>{const o=sl(e,r),l=r.stat(e),c=o>=r.tiers.length,d=r.tiers[Math.min(o,r.tiers.length-1)];return`<div class="botc" style="grid-template-columns:44px 1fr auto"><div style="font:700 16px Oxanium;text-align:center;color:${["#9aa7b8","#cd7f32","#c0c8d4","#ffd36a","#7af7ff"][o]}">${["☆","★","★★","★★★","✦"][o]}</div><div><b>${re(r.name)}</b> <span class="sub">tier ${Math.min(o+1,r.tiers.length)}/${r.tiers.length}</span><div class="bar" style="margin:5px 0 3px"><i style="width:${c?100:Math.min(100,l/d*100)}%"></i></div><div class="meta">${se(l)} / ${se(d)} ${re(r.unit)}</div></div>
          ${c?'<span class="sub">Complete</span>':`<button class="btn ${ja(e,r)?"gold":""} small" data-a="claimAch" data-id="${r.id}" ${ja(e,r)?"":"disabled"}>${Pa.dm}${Ro[o]}</button>`}</div>`}).join("")}</div>`;return`<div class="head"><h1>Daily</h1><button class="ibtn" data-a="close">✕</button></div><div class="tabs">${s.map(([r,o,l])=>`<button class="tab ${this.tab===r?"on":""}" data-a="dtab" data-t="${r}">${o}${l?' <i class="rdot" style="position:static;display:inline-block"></i>':""}</button>`).join("")}</div><div class="body">${a}</div>`}giftLine(e){if(!e)return"";const t=Q[e.sp].rarity;return`<div class="gift" style="--rc:${We[t].color}">${Mu(t,40)}<span><b style="color:${We[t].color}">${We[t].name} core!</b><br><span class="sub" style="margin:0">${e.core?ze(this.s,"assembly").some(n=>n.lvl>0)?"Booting in the Assembly Bay":"Waits for your Assembly Bay":"Joined your crew"}</span></span></div>`}dropReveal(e){const t=Object.entries(e.res).map(([n,s],a)=>`<div class="loot" style="animation-delay:${.25+a*.22}s">${Pa[n].replace('class="ic','style="width:38px;height:38px;font-size:18px" class="ic')}<b>+${se(s)}</b></div>`).join("");this.ui.modal(`<div class="ox sub" style="letter-spacing:.2em">SUPPLY DROP</div><div style="font-size:64px;line-height:1;margin:6px 0;animation:zoom .5s">📦</div><div class="lootrow">${t}</div>${e.gift?`<div style="animation:zoom .4s ${.3+Object.keys(e.res).length*.22}s both">${this.giftLine(e.gift)}</div>`:""}<button class="btn gold" data-a="closeModal" style="min-width:160px;margin-top:12px">Nice!</button>`,!0)}spinReveal(e){const t=$n.filter(h=>["standard","advanced","elite"].includes(Q[h].rarity)),n=34,s=29,a=[];for(let h=0;h<n;h++){const u=h===s?e.sp:t[Math.floor(Math.random()*t.length)],f=Q[u].rarity;a.push(`<div class="rc" style="--rc:${We[f].color}"><img src="${this.app.studio.bot(u)}"></div>`)}this.ui.modal(`<div class="ox sub" style="letter-spacing:.2em">DAILY CORE</div><div class="reel"><div class="strip" id="strip">${a.join("")}</div><div class="needle"></div></div><div id="spinRes" style="min-height:96px"></div><button class="btn gold hidden" id="spinOk" data-a="closeModal" style="min-width:160px">Collect</button>`);const r=document.getElementById("strip"),o=96;requestAnimationFrame(()=>{r.style.transition="transform 4.2s cubic-bezier(.12,.62,.16,1)";const h=r.parentElement.clientWidth;r.style.transform=`translateX(${-2784+h/2-o/2}px)`});let l=0;const c=()=>{const h=new DOMMatrix(getComputedStyle(r).transform),u=Math.floor(-h.m41/o);u!==l&&(l=u,this.app.audio.play("tap"))},d=window.setInterval(c,30);window.setTimeout(()=>{clearInterval(d);const h=Q[e.sp],u=We[h.rarity];this.app.audio.play(Ct.indexOf(h.rarity)>=1?"levelup":"claim"),document.getElementById("spinRes").innerHTML=`<h1 style="color:${u.color};margin:10px 0 2px">${re(h.name)}</h1><div class="rar" style="color:${u.color}">${u.name}${this.s.dex[e.sp]&&Date.now()-this.s.dex[e.sp]<6e3?" · NEW SPECIES":""}</div><p class="sub">${e.core?ze(this.s,"assembly").some(f=>f.lvl>0)?"Its core is booting in the Assembly Bay.":"Its core waits for your Assembly Bay (Commander level 4).":"It joined your crew."}</p>`,document.getElementById("spinOk").classList.remove("hidden")},4300)}offlineReport(e,t){const n=so(this.s),s=[];return t.credits>=1&&s.push(`${Pa.credits} <b>${se(t.credits)}</b> credits waiting in ${t.bays} bay${t.bays>1?"s":""}`),t.ready&&s.push(`${Pa.cells} <b>${t.ready}</b> fabricator recipe${t.ready>1?"s":""} ready to harvest`),t.built&&s.push(`🏗 <b>${t.built}</b> construction${t.built>1?"s":""} finished`),t.cores&&s.push(`🤖 <b>${t.cores}</b> core${t.cores>1?"s":""} booted and ready`),n.drop&&s.push("📦 A supply drop has landed"),n.day&&s.push("📅 Today's calendar reward is waiting"),n.spin&&s.push("🎁 Your free daily core is ready"),s.length?(this.ui.modal(`<div class="ox sub" style="letter-spacing:.2em">WELCOME BACK</div><h1>While you were away</h1><p class="sub">${xt(e/1e3)} in orbit. Your crew kept working.</p><div class="report">${s.map(a=>`<div>${a}</div>`).join("")}</div>${t.credits>=1||t.ready?'<button class="btn gold" data-a="collectAll" style="min-width:180px">Collect everything</button>':`<button class="btn gold" data-a="closeModal">Let's go</button>`}`,!0),!0):!1}act(e,t){const n=this.s,s=this.app,a=this.ui;switch(e){case"daily":return Za(n),a.openOver("daily"),s.audio.play("tap"),!0;case"dtab":return this.tab=t.dataset.t,a.renderOver(),s.audio.play("tap"),!0;case"claimDay":case"claimDayAd":{const r=o=>{const l={...n.res},c=op(n);if(!c)return;o&&Un(n,c.res),s.audio.play("claim"),s.changed(),a.renderOver(),a.renderHud();const d={};for(const h of["credits","cells","dm"]){const u=n.res[h]-l[h];u>0&&(d[h]=u)}a.modal(`<div class="ox sub" style="letter-spacing:.2em">DAY ${c.day+1}</div><h1>Daily reward</h1><div class="rewards">${Xr(d)}</div>${this.giftLine(c.gift)}${c.decor?'<div class="gift"><span style="font-size:36px">🌟</span><span><b>Starlight Arch</b><br><span class="sub" style="margin:0">An exclusive decoration: place it from Shop → Decor</span></span></div>':""}<p class="sub">🔥 ${pt(n).streak} day streak</p><button class="btn gold" data-a="closeModal" style="min-width:160px">Thanks!</button>`,!0)};return e==="claimDayAd"?s.platform.rewarded(()=>s.audio.setMuted(!0)).then(o=>{s.audio.setMuted(s.platform.muted()),r(o)}):r(!1),!0}case"claimMission":{const r=lp(n,+(t.dataset.i||0));if(r){s.audio.play("claim");const o=t.getBoundingClientRect();for(const l of Object.keys(r.reward))a.flyTo(l,o.left+o.width/2,o.top);s.changed(),a.renderOver()}return!0}case"claimBonus":{const r=cp(n);return r&&(s.audio.play("levelup"),s.changed(),a.renderOver(),a.modal(`<div class="ox sub" style="letter-spacing:.2em">ALL MISSIONS DONE</div><div style="font-size:60px;line-height:1">🧰</div><h1>Bonus chest</h1><div class="rewards">${Xr(r.res)}</div>${this.giftLine(r.gift)}<button class="btn gold" data-a="closeModal" style="min-width:160px">Awesome!</button>`,!0)),!0}case"claimAch":{const r=hp(n,t.dataset.id||"");return r&&(s.audio.play("claim"),a.toast(`${r.a.name} tier ${r.tier+1}: +${r.dm} Dark Matter`,"gold"),s.changed(),a.renderOver()),!0}case"spin":{if(!nl(n))return s.platform.adsAvailable&&pt(n).adSpin!==Hn()?a.modal(`<h1>Daily core</h1><p class="desc">You have used today's free spin. Watch a short ad for one more?</p><div class="row" style="justify-content:center"><button class="btn" data-a="closeModal">No thanks</button><button class="btn gold" data-a="spinAd">▶ Watch ad</button></div>`):a.toast("Your next free core is ready tomorrow",""),!0;const r=Yc(n);return r&&(s.changed(),this.spinReveal(r)),!0}case"spinAd":return a.closeModal(),s.platform.rewarded(()=>s.audio.setMuted(!0)).then(r=>{if(s.audio.setMuted(s.platform.muted()),!r)return;const o=Yc(n,!0);o&&(s.changed(),this.spinReveal(o))}),!0;case"drop":{const r=dp(n);return r?(s.audio.play("harvest"),s.changed(),this.dropReveal(r),!0):(a.toast(`The next supply drop lands in ${xt((pt(n).drop-Date.now())/1e3)}`,""),!0)}case"collectAll":{let r=0,o=0;for(const l of ze(n,"bay"))r+=rd(n,l);for(const l of ze(n,"fab"))o+=od(n,l);return a.closeModal(),s.audio.play("collect",r),r&&a.toast(`Collected ${se(r)} credits${o?` and ${se(o)} Power Cells`:""}`,"gold"),s.changed(),!0}}return!1}}const W_={credits:'<span class="ic cr">C</span>',cells:'<span class="ic ce">⚡</span>',dm:'<span class="ic dm">◆</span>'},Gl=i=>Object.entries(i).filter(([,e])=>e>0).map(([e,t])=>`<span class="cost">${W_[e]||""}${se(t)}</span>`).join(" "),Vl=i=>`<span class="els">${i.map(e=>`<span class="el" style="background:${Be[e].color}">${Be[e].glyph}</span>`).join("")}</span>`;class X_{constructor(e){this.ui=e,this.fight=null}startRaid(){const e=R_(this.s);if(!e){this.ui.deny("No raid to defend against");return}this.ui.closeModal(),this.fight={...e,busy:!1,auto:!1,speed:1,raid:!0},this.ui.closeOver(),this.ui.select(null);const t=this.app.world;t.enterArena(),t.arena.setup(e.bt),t.arena.onImpact=(n,s)=>this.impact(n,s),this.app.audio.play("whoosh"),this.app.changed(),this.renderHUD(),document.body.classList.add("fighting")}get s(){return this.ui.app.s}get app(){return this.ui.app}banner(e,t=48){const n=document.createElement("canvas");n.width=96,n.height=60;const s=n.getContext("2d");return s.fillStyle=e.bg,s.fillRect(0,0,96,60),s.fillStyle=e.fg,s.translate(48,30),Ya(s,e.emblem,20),s.fill(Ka(e.emblem)),`<img src="${n.toDataURL()}" style="width:${t}px;height:${t*60/96}px;border-radius:5px">`}overHTML(){const e=this.s,t=In(e);mp(e);const n=bs(t.trophies),s=Qi[n+1];t.rivals.length||yu(e);const a=Di(e),r=_n(a.map(d=>({sp:d.sp,lvl:d.lvl}))),o=Qi[n][1],l=s?s[1]:o+1,c=s?(t.trophies-o)/(l-o)*100:100;return`<div class="head"><h1>Arena</h1><span class="chip">🎟 ${t.tickets}/${_s}${t.tickets<_s?` · +1 in ${xt((t.tAt+Kc-Date.now())/1e3)}`:""}</span><button class="ibtn" data-a="close">✕</button></div><div class="body" style="max-width:820px;margin:0 auto;width:100%">
      <div class="card" style="flex-direction:row;align-items:center;gap:14px"><div style="font:700 40px Oxanium;color:${Ra[n]};text-shadow:0 0 18px ${Ra[n]}88">🏆</div><div class="grow"><b style="font-size:18px;color:${Ra[n]}">${Qi[n][0]}</b> <span class="sub">${se(t.trophies)} trophies · best ${se(t.best)} · ${t.wins}W ${t.losses}L</span>
        <div class="bar gold" style="margin:6px 0"><i style="width:${c}%"></i></div><div class="sub" style="margin:0">${s?`${s[1]-t.trophies} to ${s[0]}`:"Top league!"} · season ends in ${xt((__()-Date.now())/1e3)} · reward: ${Gl(gp(e,bs(t.seasonBest)))}</div></div></div>
      <h3 class="ox" style="margin:14px 0 6px">Your team <span class="sub">power ${se(r)}</span></h3><div class="row">${[0,1,2].map(d=>{const h=a[d];return`<button class="card" data-a="pickTeam" data-i="${d}" style="width:32%;align-items:center;min-height:120px">${h?`<img src="${this.app.studio.bot(h.sp)}" style="width:70px;height:70px"><b>${re(h.nick||Q[h.sp].name)}</b><span class="sub" style="margin:0">L${h.lvl} ${Vl(Q[h.sp].el)}</span>`:'<span style="font-size:30px;opacity:.5">＋</span>'}</button>`}).join("")}</div>
      <h3 class="ox" style="margin:14px 0 6px">Rival colonies <button class="btn small" data-a="rerollRivals" style="margin-left:8px">↻ New rivals</button></h3><div class="bots">${t.rivals.map((d,h)=>`<div class="botc" style="grid-template-columns:56px 1fr auto">${this.banner(d.banner,56)}<div><b>${re(d.name)}</b> <span class="rar" style="color:${["#7cf29a","#ffd36a","#ff6b7a"][d.diff]}">${["Easy","Even","Hard"][d.diff]}</span><div class="row" style="gap:2px;margin:3px 0">${d.team.map(u=>`<img src="${this.app.studio.bot(u.sp)}" title="${Q[u.sp].name} L${u.lvl}" style="width:34px;height:34px">`).join("")}<span class="sub" style="margin:0 0 0 6px">power ${se(d.power)}</span></div><div class="meta">Win: +${yp[d.diff]} 🏆 and rewards</div></div><button class="btn gold small" data-a="fight" data-i="${h}" ${Ca(e).ok?"":"disabled"}>⚔ Fight</button></div>`).join("")}</div>
      ${Ca(e).ok?"":`<p class="why" style="text-align:center">${re(Ca(e).why||"")}</p>`}<p class="sub" style="text-align:center">Rivals are rival colonies matched to your team's power. Element matchups matter: a super-effective move hits 35% harder.</p></div>`}start(e){const t=M_(this.s,e);if(!t){this.ui.deny(Ca(this.s).why);return}this.fight={...t,busy:!1,auto:!1,speed:1},this.ui.closeOver(),this.ui.select(null);const n=this.app.world;n.enterArena(),n.arena.setup(t.bt),n.arena.onImpact=(s,a)=>this.impact(s,a),this.app.audio.play("whoosh"),this.app.changed(),this.renderHUD(),document.body.classList.add("fighting")}impact(e,t){const n=this.app.world.project(t),s=this.app.world;if(e.move==="burn"){this.ui.popText(n.x,n.y,`-${se(e.dmg)} 🔥`,"#ff9a4a");return}if(e.miss){this.ui.popText(n.x,n.y,e.status==="frozen"?"Frozen!":"Miss!","#9fd0ff"),this.app.audio.play("deny");return}this.ui.popText(n.x,n.y-10,`-${se(e.dmg)}${e.crit?"!":""}`,e.eff>1?"#ffd36a":e.eff<1?"#9aa7b8":"#ffffff"),e.eff!==1&&setTimeout(()=>this.ui.popText(n.x,n.y-34,e.eff>1?"Super effective!":"Resisted",e.eff>1?"#ffd36a":"#9aa7b8"),120),e.status&&e.status!=="shielded"&&setTimeout(()=>this.ui.popText(n.x+30,n.y+10,e.status,"#c49bff"),220),e.heal&&this.ui.popText(n.x-40,n.y-40,`+${se(e.heal)}`,"#7cf29a"),s.burst(new D(t.x,t.y,t.z),q_(e.move),e.crit?34:20),this.app.audio.play(e.crit?"crit":"hit"),this.renderHUD()}renderHUD(){const e=document.getElementById("battle"),t=this.fight;if(!t){e.classList.add("hidden");return}e.classList.remove("hidden");const n=t.bt,s=n.A[n.a],a=n.B[n.b],r=(l,c,d,h)=>{const u=l[c];return`<div class="bside ${d?"r":""}"><div class="bname"><b>${re(u.name)}</b> <span class="sub" style="margin:0">L${u.lvl}</span> ${Vl(Q[u.sp].el)}${u.shield?" 🛡":""}${u.burn?" 🔥":""}${u.frozen?" ❄":""}</div><div class="hp"><i style="width:${u.hp/u.max*100}%;background:${u.hp/u.max>.5?"#5fdc7a":u.hp/u.max>.25?"#ffd36a":"#ff6b7a"}"></i><span>${se(u.hp)} / ${se(u.max)}</span></div><div class="bench">${l.map((f,g)=>`<i class="${f.hp<=0?"ko":g===c?"on":""}"></i>`).join("")}<span class="sub" style="margin:0 6px">${re(h)}</span></div></div>`},o=up(s.sp).map(l=>{const c=is[l],d=Ld(c.el,Q[a.sp].el),h=c.el==="none"?"#9aa7b8":Be[c.el].color;return`<button class="mv" data-a="move" data-m="${l}" ${t.busy||n.over?"disabled":""} style="--mc:${h}" title="${re(c.desc)}"><b>${re(c.name)}</b><span>${c.el==="none"?"Neutral":Be[c.el].name}${d>1?' · <em class="se">super effective</em>':d<1?' · <em class="re">resisted</em>':""}</span></button>`}).join("");e.innerHTML=`<div class="btop">${r(n.A,n.a,!1,this.s.name)}<div class="vs">VS</div>${r(n.B,n.b,!0,t.rival.name)}</div><div class="bbot"><div class="moves">${o}</div><div class="bopts"><button class="btn small ${t.auto?"gold":""}" data-a="autoBattle">⚡ Auto</button><button class="btn small" data-a="battleSpeed">${t.speed}×</button><button class="btn small" data-a="forfeit">Forfeit</button></div></div>`}async turn(e){const t=this.fight;if(!t||t.busy||t.bt.over)return;t.busy=!0,this.renderHUD();const n=t.bt,s=b_(n,e,Hl(n,"B"));if(await this.app.world.arena.play(s,n,t.speed),t.busy=!1,n.over){this.end(n.over==="A");return}this.renderHUD(),t.auto&&setTimeout(()=>this.turn(Hl(n,"A")),250/t.speed)}end(e){const t=this.fight;if(t.raid){this.endRaid(e);return}const n=w_(this.s,e,t.rival.diff);this.app.audio.play(e?"levelup":"deny"),this.app.changed(),setTimeout(()=>{this.ui.modal(`<div class="ox sub" style="letter-spacing:.2em">${e?"VICTORY":"DEFEAT"}</div><div class="big" style="color:${e?"#ffd36a":"#ff6b7a"}">${e?"🏆":"💥"}</div><h1>${e?`You beat ${re(t.rival.name)}!`:`${re(t.rival.name)} won this time`}</h1>
      <div class="rewards"><span class="cost" style="color:${n.dt>0?"#7cf29a":"#ff6b7a"}">${n.dt>0?"+":""}${n.dt} 🏆</span>${Gl(n.reward)}</div>${n.promoted>=0?`<p class="desc" style="color:${Ra[n.promoted]};font:700 18px Oxanium">Promoted to ${Qi[n.promoted][0]}!</p>`:""}${e?"":'<p class="sub">Tip: feed your team, fuse rarer bots, and pick moves that are super effective against your rival.</p>'}
      <div class="row" style="justify-content:center"><button class="btn" data-a="leaveArena">Back to the colony</button><button class="btn gold" data-a="arenaAgain">Arena</button></div>`,e)},500/t.speed)}endRaid(e){const t=C_(this.s,e),n=t.capture?this.giveCapture(t.capture):null;this.app.audio.play(e?"levelup":"deny"),this.app.changed(),setTimeout(()=>this.ui.modal(`<div class="ox sub" style="letter-spacing:.2em">${e?"RAID REPELLED":"THE SWARM BROKE THROUGH"}</div><div class="big" style="color:${e?"#7cf29a":"#ff6b7a"}">${e?"🛡":"🔥"}</div><h1>${e?"The colony is safe!":"They raided your bays"}</h1>
      ${e?`<div class="rewards">${Gl(t.reward)}</div>${n?`<p class="desc" style="color:#c49bff">You captured and reprogrammed a ${re(Q[t.capture].name)}! Its core is booting.</p>`:""}`:`<p class="desc">The Swarm carried off ${se(t.stolen||0)} credits from your bays. Level up your crew and fuse stronger bots before the next raid.</p>`}
      <button class="btn gold" data-a="leaveArena">Back to the colony</button>`,e),500/(this.fight?this.fight.speed:1))}giveCapture(e){const t=window.__daily;return t?t.giveSpecies(this.s,e):null}leave(){this.fight=null,this.renderHUD(),document.body.classList.remove("fighting"),this.app.world.exitArena(),this.ui.closeModal(),this.app.changed()}act(e,t){const n=this.s,s=this.app,a=this.ui;switch(e){case"arena":return ze(n,"arena").some(r=>r.lvl>0)?(vp(n),a.openOver("arena"),s.audio.play("tap"),!0):(a.openOver("shop","buildings"),a.toast("Build the Arena first (Commander level 6)","gold"),!0);case"fight":return this.start(+(t.dataset.i||0)),!0;case"rerollRivals":return yu(n),a.renderOver(),s.audio.play("tap"),!0;case"pickTeam":{const r=+(t.dataset.i||0);In(n);const o=Di(n).map(c=>c.id),l=n.bots.filter(c=>!c.stored).sort((c,d)=>_n([{sp:d.sp,lvl:d.lvl}])-_n([{sp:c.sp,lvl:c.lvl}]));return a.modal(`<h1 style="font-size:20px">Team slot ${r+1}</h1><div class="bots" style="max-height:56vh;overflow:auto;text-align:left">${l.map(c=>`<div class="botc"><div class="pic"><img src="${s.studio.bot(c.sp)}"></div><div><b>${re(c.nick||Q[c.sp].name)}</b> ${Vl(Q[c.sp].el)}<div class="meta"><span class="rar" style="color:${We[Q[c.sp].rarity].color}">${We[Q[c.sp].rarity].name}</span> · L${c.lvl} · power ${se(_n([{sp:c.sp,lvl:c.lvl}]))}</div></div><button class="btn small gold" data-a="setTeam" data-i="${r}" data-bot="${c.id}" ${o[r]===c.id?"disabled":""}>${o.includes(c.id)?"Swap":"Pick"}</button></div>`).join("")}</div><button class="btn" data-a="closeModal" style="margin-top:10px">Cancel</button>`),!0}case"setTeam":{const r=In(n),o=Di(n).map(h=>h.id),l=t.dataset.bot,c=+(t.dataset.i||0),d=o.indexOf(l);return d>=0&&(o[d]=o[c]),o[c]=l,r.team=o.filter(Boolean),r.rivals=[],a.closeModal(),a.renderOver(),s.audio.play("tap"),!0}case"move":return this.turn(t.dataset.m||"strike"),!0;case"raid":{const r=al(n);return r.eta&&a.modal(`<div class="ox sub" style="letter-spacing:.2em;color:#ff6b7a">⚠ SWARM RAID INCOMING</div><h1>The Kr'thul are coming</h1><p class="desc">A Swarm raiding party arrives in <b>${xt((r.eta-Date.now())/1e3)}</b>. Defend the colony with your Arena team, or they will carry off half the credits waiting in your bays.</p><div class="row" style="justify-content:center;gap:4px;margin:8px 0">${r.team.map(o=>`<div style="text-align:center"><img src="${s.studio.bot(o.sp)}" style="width:64px;height:64px"><div class="sub" style="margin:0">L${o.lvl}</div></div>`).join("")}</div><p class="sub">Swarm power ${se(_n(r.team))} · your team ${se(_n(Di(n).map(o=>({sp:o.sp,lvl:o.lvl}))))}</p><div class="row" style="justify-content:center"><button class="btn" data-a="closeModal">Later</button><button class="btn gold" data-a="defendRaid">🛡 Defend now</button></div>`),!0}case"defendRaid":return this.startRaid(),!0;case"autoBattle":return this.fight&&(this.fight.auto=!this.fight.auto,this.renderHUD(),this.fight.auto&&!this.fight.busy&&this.turn(Hl(this.fight.bt,"A"))),!0;case"battleSpeed":return this.fight&&(this.fight.speed=this.fight.speed===1?2:this.fight.speed===2?3:1,this.renderHUD()),!0;case"forfeit":return this.fight&&!this.fight.busy&&(this.fight.bt.over="B",this.end(!1)),!0;case"leaveArena":return this.leave(),!0;case"arenaAgain":return this.leave(),setTimeout(()=>this.act("arena",t),200),!0}return!1}}const q_=i=>{const e=is[i];return!e||e.el==="none"?"#ffffff":Be[e.el].glow},Xi={credits:'<span class="ic cr">C</span>',cells:'<span class="ic ce">⚡</span>',dm:'<span class="ic dm">◆</span>'},wu=i=>Object.entries(i).filter(([,e])=>e>0).map(([e,t])=>`<span class="cost">${Xi[e]||""}${se(t)}</span>`).join(" "),Wl=i=>`<span class="els">${i.map(e=>`<span class="el" style="background:${Be[e].color}" title="${Be[e].name}">${Be[e].glyph}</span>`).join("")}</span>`;class Y_{constructor(e){this.ui=e,this.dest=null,this.crew={},this.labels=new Map}get s(){return this.ui.app.s}get app(){return this.ui.app}open(){this.app.world.openMap(),document.body.classList.add("mapview"),this.ui.select(null),this.render(),this.app.audio.play("whoosh");const e=this.app.world.system;e.onPick=t=>{this.dest=t,this.app.audio.play("tap"),this.render()}}close(){this.app.world.closeMap(),document.body.classList.remove("mapview"),this.dest=null,document.getElementById("mapui").classList.add("hidden"),this.labels.forEach(e=>e.remove()),this.labels.clear(),document.getElementById("panel").classList.add("hidden"),this.app.changed()}render(){const e=document.getElementById("mapui");e.classList.remove("hidden");const t=Ht(this.s),n=Dd(this.s);e.innerHTML=`<div class="maptop"><button class="btn small" data-a="closeMap">← Colony</button><h2 class="ox" style="margin:0 8px;flex:1">The Solar System</h2><span class="chip">🚀 ${n&&n.lvl?`${t.exps.length}/${Qs(n.lvl)} · ${Ms[Ki(n.lvl)-1].name}`:"No Launch Pad"}</span></div>
      <div class="exps">${t.exps.map(s=>`<button class="expc" data-a="mapDest" data-d="${s.dest}"><b>${re(ft[s.dest].name)}</b><span data-exp="${s.id}">${xt((s.end-Date.now())/1e3)}</span><div class="bar"><i data-expbar="${s.id}" style="width:${ni((Date.now()-s.start)/(s.end-s.start))*100}%"></i></div></button>`).join("")}</div>`,this.panel()}frame(){if(this.app.world.mode!=="map")return;const e=this.app.world.system;if(!e)return;const t=Ht(this.s),n=Date.now();for(const s of ai){let a=this.labels.get(s);a||(a=document.createElement("div"),a.className="plabel",a.dataset.a="mapDest",a.dataset.d=s,document.body.appendChild(a),this.labels.set(s,a));const r=Jc(this.s,s),o=t.visits[s]||0,l=t.outposts[s],c=t.exps.find(u=>u.dest===s),d=`<b>${re(ft[s].name)}</b>${c?`<i>🚀 ${xt((c.end-n)/1e3)}</i>`:l&&l.buf>=1?`<i class="ready">${Xi[ft[s].outpost.res]}${se(l.buf)}</i>`:r?o?`<i>✓ ${o}</i>`:'<i class="new">new</i>':"<i>🔒</i>"}`;a.dataset.h!==d&&(a.innerHTML=d,a.dataset.h=d),a.classList.toggle("sel",this.dest===s),a.classList.toggle("locked",!r);const h=e.project(e.worldPos(s));a.style.left=h.x+"px",a.style.top=h.y+"px",a.style.display=h.vis?"":"none"}document.querySelectorAll("[data-exp]").forEach(s=>{const a=t.exps.find(r=>r.id===s.dataset.exp);a&&(s.textContent=xt((a.end-n)/1e3))}),document.querySelectorAll("[data-expbar]").forEach(s=>{const a=t.exps.find(r=>r.id===s.dataset.expbar);a&&(s.style.width=ni((n-a.start)/(a.end-a.start))*100+"%")})}crewOf(e){const t=(this.crew[e]||[]).filter(n=>{const s=this.s.bots.find(a=>a.id===n);return s&&!s.stored&&!bu(this.s,n)});return this.crew[e]=t,t}panel(){const e=document.getElementById("panel");if(!this.dest){e.classList.add("hidden");return}e.classList.remove("hidden");const t=this.s,n=this.dest,s=ft[n],a=Ht(t),r=a.exps.find(l=>l.dest===n);let o=`<button class="ibtn x" data-a="mapDest" data-d="">✕</button><h2>${re(s.name)}</h2><div class="sub">${Ms[s.tier-1].name} rocket · ${xt(I_(n))} · crew of up to ${s.crew} · ${a.visits[n]?`visited ${a.visits[n]}×`:"never visited"}</div><p class="desc">${re(s.fact)}</p>`;if(!Jc(t,n))o+=`<p class="why">🔒 Visit ${re(ft[s.needs].name)} first.</p>`;else if(r){const l=ui((r.end-Date.now())/1e3);o+=`<p class="desc">A crew is on the way: ${r.crew.map(c=>{const d=t.bots.find(h=>h.id===c);return d?re(d.nick||Q[d.sp].name):""}).join(", ")}.</p><div class="bar"><i data-expbar="${r.id}"></i></div><div class="row" style="margin-top:8px"><b class="grow" data-exp="${r.id}">${xt((r.end-Date.now())/1e3)}</b><button class="btn gold small" data-a="finishExp" data-e="${r.id}">${l?`${Xi.dm}${l} Bring them home`:"Return now (free)"}</button></div>`}else{const l=this.crewOf(n),c=l.map(u=>t.bots.find(f=>f.id===u)),d=Id(t,n,c),h=_p(t,n,l);if(o+=`<div class="sub">Favoured elements ${Wl(s.els)} (each match +15% haul)</div><div class="row" style="margin:8px 0">${Array.from({length:s.crew},(u,f)=>{const g=c[f];return`<button class="card" data-a="pickCrew" data-i="${f}" style="width:31%;min-height:96px;align-items:center;padding:6px">${g?`<img src="${this.app.studio.bot(g.sp)}" style="width:52px;height:52px"><b style="font-size:12px">${re(g.nick||Q[g.sp].name)}</b><span class="sub" style="margin:0">L${g.lvl} ${Wl(Q[g.sp].el)}</span>`:'<span style="font-size:24px;opacity:.5">＋</span><span class="sub" style="margin:0">Crew</span>'}</button>`}).join("")}</div>`,c.length){const u=Mp(t,{dest:n,crew:l,start:0});o+=`<div class="sub">Crew power ${se(d.power)} vs ${se(bp(n))} · ${d.match} element match${d.match===1?"":"es"} · haul ×${d.mult.toFixed(2)}</div><div class="sub">Expected: ${wu({credits:u.res.credits,cells:u.res.cells})} + Dark Matter and core chances${a.visits[n]>0?"":' · <b style="color:#ffd36a">first-visit bonus</b>'}</div>`}o+=`<div class="row" style="margin-top:8px"><span class="grow">${h.cost!==void 0?`<span class="cost ${t.res.credits<(h.cost||0)?"short":""}">${Xi.credits}${se(h.cost||0)}</span> fuel`:""}</span><button class="btn gold" data-a="launchExp" ${h.ok?"":"disabled"}>🚀 Launch</button></div>${h.ok?"":`<p class="why">${re(h.why||"")}</p>`}<p class="sub">The crew is away for the whole trip: they don't earn, help or fight until they're back.</p>`}if(a.visits[n]>0){const l=a.outposts[n],c=Sp(t,n),d=s.outpost.res;o+=`<div class="sub" style="margin-top:10px;border-top:1px solid var(--line);padding-top:8px">Outpost ${l?`level ${l.lvl} · ${Xi[d]} ${se(Po(n,l.lvl))}/h · store ${se(l.buf)} / ${se(wp(n,l.lvl))}`:`· earns ${Xi[d]} ${se(Po(n,1))} per hour, even while you're away`}</div>
      <div class="row">${l?`<button class="btn green small" data-a="collectOutpost" ${l.buf>=1?"":"disabled"}>Collect ${Xi[d]}${se(l.buf)}</button>`:""}<button class="btn small" data-a="buildOutpost" ${c.ok?"":"disabled"}>${l?"⬆ Upgrade":"🏗 Build outpost"} ${c.cost!==void 0?`<span class="cost">${Xi.credits}${se(c.cost)}</span>`:""}</button></div>`}e.innerHTML=o}reveal(e){const t=ft[e.exp.dest],n=e.exp.crew.map(a=>this.s.bots.find(r=>r.id===a)).filter(Boolean),s=e.gift?(()=>{const a=Q[e.gift.sp].rarity;return`<div class="gift" style="--rc:${We[a].color}"><span style="font-size:30px">🤖</span><span><b style="color:${We[a].color}">${We[a].name} core found!</b><br><span class="sub" style="margin:0">Salvaged on ${re(t.name)}</span></span></div>`})():"";this.ui.modal(`<div class="ox sub" style="letter-spacing:.2em">${e.first&&t.alien?"FIRST CONTACT":"EXPEDITION RETURNED"}</div><h1>${re(t.name)}</h1><div class="row" style="justify-content:center;gap:4px">${n.map(a=>`<img src="${this.app.studio.bot(a.sp)}" style="width:54px;height:54px">`).join("")}</div>${e.first?`<p class="desc" style="font-style:italic">“${re(t.first)}”</p>`:""}<div class="rewards">${wu(e.res)}</div>${s}${e.first&&t.alien?`<p class="desc" style="color:#c49bff">★ First contact! An alliance with this civilisation adds 5% to every bot's earnings.</p>`:""}${e.first?'<p class="sub">First visit! You can now build an outpost here.</p>':""}<button class="btn gold" data-a="closeModal" style="min-width:160px">Welcome home</button>`,!0)}act(e,t){const n=this.s,s=this.app,a=this.ui;switch(e){case"space":return this.open(),!0;case"closeMap":return this.close(),s.audio.play("tap"),!0;case"mapDest":return this.dest=t.dataset.d||null,this.dest&&s.world.system?.focus(this.dest),this.render(),s.audio.play("tap"),!0;case"pickCrew":{const r=this.dest,o=+(t.dataset.i||0),l=this.crewOf(r),c=ft[r],d=n.bots.filter(h=>!h.stored&&!bu(n,h.id)&&Q[h.sp].alien!=="relic").sort((h,u)=>Q[u.sp].el.filter(f=>c.els.includes(f)).length-Q[h.sp].el.filter(f=>c.els.includes(f)).length||ia(u).atk-ia(h).atk);return a.modal(`<h1 style="font-size:20px">Crew for ${re(c.name)}</h1><div class="bots" style="max-height:56vh;overflow:auto;text-align:left">${d.map(h=>{const u=Q[h.sp].el.filter(f=>c.els.includes(f)).length;return`<div class="botc"><div class="pic"><img src="${s.studio.bot(h.sp)}"></div><div><b>${re(h.nick||Q[h.sp].name)}</b> ${Wl(Q[h.sp].el)}<div class="meta">L${h.lvl}${u?` · <b style="color:#7cf29a">${u} match${u>1?"es":""}</b>`:""}${h.post?" · helping":""}</div></div><button class="btn small gold" data-a="setCrew" data-i="${o}" data-bot="${h.id}">${l.includes(h.id)?"Swap":"Pick"}</button></div>`}).join("")}</div><div class="row" style="justify-content:center;margin-top:10px">${l[o]?`<button class="btn" data-a="setCrew" data-i="${o}" data-bot="">Remove</button>`:""}<button class="btn" data-a="closeModal">Cancel</button></div>`),!0}case"setCrew":{const r=this.dest,o=+(t.dataset.i||0),l=t.dataset.bot||"",c=[...this.crewOf(r)],d=c.indexOf(l);return d>=0&&c.splice(d,1),l?c.splice(Math.min(o,c.length),0,l):c.splice(o,1),this.crew[r]=c.slice(0,ft[r].crew),a.closeModal(),this.panel(),s.audio.play("tap"),!0}case"launchExp":{const r=this.dest,o=D_(n,r,this.crewOf(r));return o.ok?(this.crew[r]=[],s.audio.play("build"),s.changed(),this.render(),a.toast(`The crew is on its way to ${ft[r].name}`,"good")):a.deny(o.why),!0}case"finishExp":{const r=Ht(n).exps.find(l=>l.id===t.dataset.e);if(!r)return!0;const o=ui((r.end-Date.now())/1e3);return n.res.dm<o?(a.deny("Not enough Dark Matter"),!0):(n.res.dm-=o,r.end=Date.now(),s.changed(),!0)}case"buildOutpost":{const r=O_(n,this.dest);return r.ok?(s.audio.play("build"),s.changed(),this.panel(),a.toast("Outpost ready: it earns while you are away","good")):a.deny(r.why),!0}case"collectOutpost":{const r=k_(n,this.dest);if(r){s.audio.play("collect",r);const o=t.getBoundingClientRect();a.flyTo(ft[this.dest].outpost.res,o.left+o.width/2,o.top,6),s.changed(),this.panel()}return!0}}return!1}}const Ep={collects:[2,"collect from a bay"],harvests:[6,"harvest a recipe"],feeds:[1,"feed a bot"],fusions:[30,"fuse two bots"],boots:[15,"activate a core"],arenaWins:[20,"win an Arena battle"],expeditions:[25,"complete an expedition"],decor:[3,"place a decoration"],drops:[10,"open a supply drop"],raidsWon:[40,"repel a Swarm raid"],upgrades:[8,"start an upgrade"]},qr=[{id:"solstice",name:"Solar Solstice",tagline:"The Sun is at its brightest: every solar panel sings.",color:"#ffb23e",icon:"☀",featured:["collects","harvests"],bot:"solstice"},{id:"cup",name:"Arena Cup",tagline:"Rival colonies gather in orbit for the season's grand tournament.",color:"#ff5a6a",icon:"🏆",featured:["arenaWins","raidsWon"],bot:"champion"},{id:"deep",name:"Deep Space Week",tagline:"Launch windows are wide open. Fill the sky with rockets.",color:"#4aa8ff",icon:"🚀",featured:["expeditions","drops"],bot:"voyager"},{id:"fusion",name:"Fusion Frenzy",tagline:"The Fusion Lab hums day and night. Strange new cores appear.",color:"#b06dff",icon:"🧬",featured:["fusions","boots"],bot:"chimera"},{id:"garden",name:"Garden Gala",tagline:"The colony blooms. Decorate, feed and grow.",color:"#4fcf5a",icon:"🌸",featured:["decor","feeds"],bot:"blossom"},{id:"forge",name:"Forge Fest",tagline:"Builder drones work double shifts. Raise the skyline.",color:"#ff7a1a",icon:"🔨",featured:["upgrades","harvests"],bot:"anvil"}],ms=[60,150,300,500,800,1200,1700,2400],Xl=7*864e5,ql=Date.UTC(2026,0,5);function Qa(i=Date.now()){const e=Math.floor((i-ql)/Xl);return{def:qr[(e%qr.length+qr.length)%qr.length],week:e,start:ql+e*Xl,end:ql+(e+1)*Xl}}function rl(i,e=Date.now()){const t=i,n=Qa(e);return(!t.event||t.event.week!==n.week)&&(t.event={week:n.week,base:{...i.stats},claimed:[]}),t.event}function Nd(i,e=Date.now()){const t=Qa(e),n=rl(i,e);let s=0;for(const[a,[r]]of Object.entries(Ep))s+=Math.max(0,(i.stats[a]||0)-(n.base[a]||0))*r*(t.def.featured.includes(a)?3:1);return s}function Ap(i,e,t){const n=1+i.lvl*.4;return e===ms.length-1?{label:"Exclusive bot",bot:t.bot}:e===3?{label:"Elite core",core:"elite"}:e===5?{label:"Epic core",core:"epic"}:{label:e%2?"Dark Matter":"Supplies",res:e%2?{dm:10+e*5}:{credits:Ye(1500*n*(1+e)),cells:Ye(400*n*(1+e))}}}function K_(i,e,t=Date.now()){const n=Qa(t),s=rl(i,t);if(s.claimed.includes(e)||Nd(i,t)<ms[e])return null;const a=Ap(i,e,n.def);s.claimed.push(e);let r=null;return a.res&&Un(i,a.res),a.core&&(r=as(i,a.core,n.week*31+e,t)),a.bot&&(r=Pd(i,a.bot,t)),dt(i,30+e*10),i.stats.eventSteps=(i.stats.eventSteps||0)+1,{r:a,gift:r}}const Z_=(i,e=Date.now())=>{const t=rl(i,e),n=Nd(i,e);return ms.some((s,a)=>n>=s&&!t.claimed.includes(a))},wi={credits:'<span class="ic cr">C</span>',dm:'<span class="ic dm">◆</span>',iridium:'<span class="ic ir">✦</span>'},Wi=(i,e,t=22)=>`<span class="gem t${e}" style="--gc:${Kt[i].color};width:${t}px;height:${t}px"></span>`;class J_{constructor(e){this.ui=e,this.digColor="aurora"}get s(){return this.ui.app.s}get app(){return this.ui.app}eventChip(){const e=Qa(),t=Z_(this.s);return`<button class="chip ev" data-a="event" style="--ec:${e.def.color}">${e.def.icon} ${re(e.def.name)} · ${xt((e.end-Date.now())/1e3)}${t?'<i class="rdot"></i>':""}</button>`}eventHTML(){const e=this.s,t=Qa(),n=rl(e),s=Nd(e),a=t.def,r=ms[ms.length-1],o=Q[a.bot];return`<div class="head"><h1>${a.icon} ${re(a.name)}</h1><span class="chip">ends in ${xt((t.end-Date.now())/1e3)}</span><button class="ibtn" data-a="close">✕</button></div><div class="body" style="max-width:760px;margin:0 auto;width:100%">
      <div class="card evhero" style="--ec:${a.color}"><div class="row" style="align-items:center;gap:14px"><img src="${this.app.studio.bot(a.bot)}" style="width:120px;height:120px"><div class="grow"><div class="ox sub" style="letter-spacing:.15em;color:${a.color}">THIS WEEK'S EXCLUSIVE</div><h2 style="margin:2px 0">${re(o.name)}</h2><span class="rar" style="color:${We[o.rarity].color}">${We[o.rarity].name}</span><p class="desc">${re(a.tagline)} Reach the top of the track to win it: it never comes back in the shop.</p></div></div></div>
      <div class="row" style="margin:12px 0 4px"><b class="ox grow" style="font-size:20px">🎟 ${se(s)} tokens</b><span class="sub">${n.claimed.length}/${ms.length} rewards</span></div><div class="bar gold"><i style="width:${Math.min(100,s/r*100)}%"></i></div>
      <div class="track">${ms.map((l,c)=>{const d=Ap(e,c,a),h=n.claimed.includes(c),u=s>=l;return`<div class="ms ${h?"got":u?"ok":""}"><b>${se(l)}</b><span>${d.bot?`<img src="${this.app.studio.bot(d.bot)}" style="width:40px;height:40px">`:d.core?"🤖":d.res?d.res.dm?"◆":"📦":""}</span><i>${re(d.label)}</i>${h?"<em>✓</em>":u?`<button class="btn gold small" data-a="claimMs" data-i="${c}">Claim</button>`:""}</div>`}).join("")}</div>
      <h3 class="ox" style="margin:14px 0 6px">How to earn tokens</h3><div class="earn">${Object.entries(Ep).map(([l,[c,d]])=>{const h=a.featured.includes(l);return`<div class="${h?"feat":""}"><span>${re(d)}</span><b>+${c*(h?3:1)}</b>${h?"<em>×3 this week</em>":""}</div>`}).join("")}</div>
      <p class="sub" style="text-align:center">A new event starts every Monday. Six themes rotate, each with its own exclusive bot.</p></div>`}crystalsHTML(){const e=Zt(this.s).crystals;return`<table class="gems"><tr><td></td>${dl.map(t=>`<th>${t}</th>`).join("")}</tr>${Da.map(t=>`<tr><td><b style="color:${Kt[t].color}">${Kt[t].name}</b></td>${e[t].map((n,s)=>`<td>${Wi(t,s,18)} ${se(n)}</td>`).join("")}</tr>`).join("")}</table>`}mineHTML(e){const t=this.s,n=Zt(t).ready[e.id],s=At(t,e.id,"dig");if(n)return`<div class="row"><span class="grow desc">${Wi(n.color,0)} ${se(n.n)} ${Kt[n.color].name} shards are ready.</span><button class="btn green" data-a="collectMine" data-id="${e.id}">Collect</button></div>`;if(s){const a=ui((s.end-Date.now())/1e3);return`<p class="desc">Digging for ${Kt[s.sp||"aurora"].name} shards…</p><div class="bar"><i data-bar="${s.id}"></i></div><div class="row" style="margin-top:8px"><b class="grow" data-left="${s.id}"></b><button class="btn gold small" data-a="finish" data-job="${s.id}" data-dm="${s.id}">${a?`${wi.dm}${a} Finish now`:"Finish (free)"}</button></div>`}return`<p class="desc">Pick a crystal colour, then a dig. Credits buy digging time; deeper digs pay more shards.</p><div class="row">${Da.map(a=>`<button class="btn small ${this.digColor===a?"gold":""}" data-a="digColor" data-c="${a}">${Wi(a,0,16)} ${Kt[a].name}</button>`).join("")}</div>
      <div class="recipes">${Io.map((a,r)=>`<div class="rec"><b>${re(a.name)}</b><span class="out" style="color:${Kt[this.digColor].color}">${Wi(this.digColor,0,16)} ${Iu(a.shards,e.lvl)}</span><span class="sub">${xt(a.sec)}</span><button class="btn small" data-a="dig" data-id="${e.id}" data-i="${r}"><span class="cost" data-cost="credits:${a.cost}">${wi.credits}${se(a.cost)}</span></button></div>`).join("")}</div>`}forgeHTML(){const e=this.s,t=Zt(e).crystals;return`<p class="desc">Four crystals of a tier and some Iridium make one of the next tier. You have ${wi.iridium} ${se(e.res.iridium||0)} Iridium.</p>
    <table class="gems"><tr><td></td>${dl.slice(0,3).map((n,s)=>`<th>${n} → ${dl[s+1]}<br><span class="sub" style="margin:0">${wi.iridium}${Nu(s)}</span></th>`).join("")}</tr>${Da.map(n=>`<tr><td><b style="color:${Kt[n].color}">${Kt[n].name}</b></td>${[0,1,2].map(s=>{const a=Fu(e,n,s).ok;return`<td><button class="btn small ${a?"gold":""}" data-a="forge" data-c="${n}" data-t="${s}" ${a?"":"disabled"}>${Wi(n,s,14)}${t[n][s]}/${lo} → ${Wi(n,s+1,14)}</button></td>`}).join("")}</tr>`).join("")}</table>`}relicHTML(e){const t=this.s,n=e.el||"aurora",s=Dn(t,e.id),a=ti(e.lvl),r=t.bay[e.id]||0,o=$n.filter(l=>Q[l].alien==="relic"&&Q[l].el[0]===n);return`<div class="row"><div class="grow"><div class="bar" id="relbar"><i style="width:${r/Ba(e)*100}%;background:linear-gradient(90deg,#c49bff,#8a5cff)"></i></div></div><b>${wi.iridium} <span id="relv">${se(r)} / ${se(Ba(e))}</span></b><button class="btn gold small" id="relc" data-a="collect" data-id="${e.id}" ${r>=1?"":"disabled"}>Collect</button></div>
      <div class="sub">${wi.iridium} ${(Math.round(zu(t,e.id)*600)/10).toLocaleString("en-US")} Iridium per minute · ${s.length}/${a} Relic AIs</div>
      <div class="bots">${s.map(l=>{const c=Bu(t,l),d=l.lvl<5?td[l.lvl-1]:null;return`<div class="botc"><div class="pic" style="background:radial-gradient(circle, ${Be[n].color}55, transparent 70%)"><img src="${this.app.studio.bot(l.sp)}"></div><div><b>${re(Q[l.sp].name)}</b> <span style="color:#ffd36a">${"★".repeat(l.lvl)}${"☆".repeat(5-l.lvl)}</span><div class="meta">${wi.iridium} ${ec(Ct.indexOf(Q[l.sp].rarity),l.lvl).toFixed(1)}/min</div></div>
          ${d?`<button class="btn small ${c.ok?"gold":""}" data-a="evolve" data-bot="${l.id}" ${c.ok?"":"disabled"}>⬆ ${Wi(n,d[0],14)}${d[1]}</button>`:'<span class="sub">MAX</span>'}</div>`}).join("")||'<p class="desc">No Relic AIs here yet.</p>'}</div>
      <div class="sub" style="margin-top:10px">Summon ${/^[AEIOU]/.test(Be[n].name)?"an":"a"} ${Be[n].name} Relic AI</div><div class="bots">${o.map((l,c)=>{const[d,h]=ed[c],u=ku(t,l);return`<div class="botc"><div class="pic"><img src="${this.app.studio.bot(l)}" style="${t.dex[l]?"":"filter:brightness(0) opacity(.55)"}"></div><div><b>${t.dex[l]?re(Q[l].name):"???"}</b> <span class="rar" style="color:${We[Q[l].rarity].color}">${["Minor","Major","Prime"][c]}</span><div class="meta">earns ${wi.iridium} ${ec(Ct.indexOf(Q[l].rarity),1).toFixed(1)}/min at one star</div></div><button class="btn small ${u.ok?"gold":""}" data-a="summon" data-sp="${l}" ${u.ok?"":"disabled"} title="${re(u.why||"")}">${Wi(n,d,14)}${h}</button></div>`}).join("")}</div>`}act(e,t){const n=this.s,s=this.app,a=this.ui,r=t.dataset.id?Rt(n,t.dataset.id):void 0;switch(e){case"event":return a.openOver("event"),s.audio.play("tap"),!0;case"claimMs":{const o=K_(n,+(t.dataset.i||0));return o&&(s.audio.play(o.r.bot?"levelup":"claim"),s.changed(),a.renderOver(),o.r.bot?a.toast(`${Q[o.r.bot].name} is yours! Its core is booting.`,"gold"):o.gift&&a.toast("A core is booting in the Assembly Bay","gold")),!0}case"crystals":return a.modal(`<h1 style="font-size:20px">Relic crystals</h1>${this.crystalsHTML()}<p class="sub">${wi.iridium} ${se(n.res.iridium||0)} Iridium</p><button class="btn" data-a="closeModal">Close</button>`),!0;case"digColor":return this.digColor=t.dataset.c||"aurora",a.renderPanel(),s.audio.play("tap"),!0;case"dig":if(r){const o=tm(n,r,+(t.dataset.i||0),this.digColor);o.ok?(s.audio.play("build"),s.changed(),a.renderPanel()):a.deny(o.why)}return!0;case"collectMine":if(r){const o=Uu(n,r);if(o){s.audio.play("crystal");const l=t.getBoundingClientRect();a.popText(l.left+l.width/2,l.top,`+${o.n} ${Kt[o.color].name}`,Kt[o.color].color),s.changed(),a.renderPanel()}}return!0;case"forge":{const o=im(n,t.dataset.c||"aurora",+(t.dataset.t||0));return o.ok?(s.audio.play("done"),s.changed(),a.renderPanel()):a.deny(o.why),!0}case"summon":{const o=sm(n,t.dataset.sp||"");return o.ok&&o.bot?(s.audio.play("levelup"),s.changed(),a.renderPanel(),a.newBot(o.bot)):a.deny(o.why),!0}case"evolve":{const o=n.bots.find(c=>c.id===t.dataset.bot);if(!o)return!0;const l=am(n,o);return l.ok?(s.audio.play("evolve"),s.changed(),a.renderPanel(),a.toast(`${Q[o.sp].name} evolved to ${o.lvl} stars!`,"gold")):a.deny(l.why),!0}}return!1}}const ao=[{id:"haven",name:"Haven",primary:"#e9eef5",accent:"#22c7e8"},{id:"sunrise",name:"Sunrise",primary:"#f4efe6",accent:"#ff7a3c"},{id:"meadow",name:"Meadow",primary:"#dfe7d8",accent:"#4fcf5a"},{id:"nightgold",name:"Night Gold",primary:"#2e3644",accent:"#ffd23a",need:{lvl:4}},{id:"orchid",name:"Orchid",primary:"#f2e8f7",accent:"#b06dff",need:{lvl:7}},{id:"cobalt",name:"Cobalt",primary:"#e6f1ff",accent:"#2f6bff",need:{lvl:10}},{id:"dusk",name:"Crimson Dusk",primary:"#3b2f2f",accent:"#ff4f6a",need:{lvl:13}},{id:"brass",name:"Brass",primary:"#fff6dc",accent:"#c9902a",need:{lvl:16}},{id:"lunar",name:"Lunar Silver",primary:"#c9ccd3",accent:"#7aa8ff",need:{island:"moon"}},{id:"rust",name:"Martian Rust",primary:"#e8d2c0",accent:"#c4502a",need:{island:"mars"}},{id:"jade",name:"Veyari Jade",primary:"#e4f2ea",accent:"#1fae7a",need:{allies:1}},{id:"precursor",name:"Precursor",primary:"#1d1a2b",accent:"#c49bff",need:{island:"vault"}},{id:"champion",name:"Champion",primary:"#fbf3e4",accent:"#e8202f",need:{stat:["arenaWins",25]}},{id:"carapace",name:"Carapace",primary:"#2a2f22",accent:"#9bdc3a",need:{stat:["raidsWon",5]}},{id:"solstice",name:"Solstice",primary:"#fff4d6",accent:"#ffb23e",need:{stat:["eventSteps",8]}},{id:"prism",name:"Prism",primary:"#f4f7ff",accent:"#ff5ad1",need:{dex:50}}],Tp=[{id:"blue",name:"Blue",color:"#1b6fd8"},{id:"red",name:"Red",color:"#d83a3a"},{id:"green",name:"Green",color:"#1f9c5a"},{id:"violet",name:"Violet",color:"#7a3fd6"},{id:"amber",name:"Amber",color:"#e08a1a"},{id:"night",name:"Night",color:"#14202e"},{id:"snow",name:"Snow",color:"#e6e6ea"},{id:"teal",name:"Teal",color:"#0fb3c9"},{id:"rose",name:"Rose",color:"#ff7ab8",need:{lvl:12}},{id:"gold",name:"Gold",color:"#d4a21c",need:{logins:14}},{id:"void",name:"Void",color:"#2b0f45",need:{island:"vault"}},{id:"onyx",name:"Onyx",color:"#050608",need:{stat:["raidsWon",3]}}],j_=["#ffd23a","#ffffff","#14202e","#ff4f6a","#6ee7ff","#7cf29a","#c49bff","#ff9a3c"],Rp=[{id:"star",name:"Star"},{id:"planet",name:"Planet"},{id:"circle",name:"Orb"},{id:"bolt",name:"Bolt",need:{lvl:3}},{id:"gear",name:"Gear",need:{lvl:5}},{id:"rocket",name:"Rocket",need:{stat:["expeditions",1]}},{id:"crown",name:"Crown",need:{stat:["arenaWins",10]}},{id:"atom",name:"Atom",need:{stat:["fusions",5]}},{id:"leaf",name:"Leaf",need:{stat:["decor",25]}},{id:"eye",name:"Watcher",need:{allies:1}},{id:"chip",name:"Chip",need:{dex:30}},{id:"gem",name:"Relic",need:{island:"vault"}}],Cp=[{id:"haven",name:"Haven Meadow",desc:"Soft green turf and wildflowers."},{id:"dune",name:"Dune Mesa",desc:"Warm sand, dry grass and desert blooms.",need:{lvl:9}},{id:"sakura",name:"Sakura Terrace",desc:"Pale grass under drifts of pink petals.",need:{lvl:12}},{id:"frost",name:"Frost Shelf",desc:"Packed snow, blue ice and frosted tufts.",need:{lvl:15}},{id:"ember",name:"Ember Grove",desc:"Autumn fire: copper grass and red leaves.",need:{stat:["eventSteps",4]}},{id:"neon",name:"Neon Grid",desc:"Midnight panels and glowing fibre-optic grass.",need:{stat:["arenaWins",15]}},{id:"moon",name:"Lunar Regolith",desc:"Grey dust and pebbles carried home from the Moon.",need:{island:"moon"}},{id:"mars",name:"Red Sands",desc:"Iron-red ground from Bradbury Landing.",need:{island:"mars"}},{id:"vault",name:"Precursor Stone",desc:"Violet ruin-stone, humming with relic dust.",need:{island:"vault"}}],Q_={arenaWins:"Arena wins",raidsWon:"Swarm raids repelled",eventSteps:"event rewards claimed",expeditions:"expeditions",fusions:"fusions",decor:"decorations placed"},eM={moon:"Found Tranquility Base on the Moon",mars:"Found Bradbury Landing on Mars",vault:"Found the Precursor Vault"};function er(i,e){return e?!(e.lvl&&i.lvl<e.lvl||e.stat&&(i.stats[e.stat[0]]||0)<e.stat[1]||e.island&&!i.islands[e.island]||e.allies&&N_(i)<e.allies||e.dex&&Object.keys(i.dex).length<e.dex||e.logins&&pt(i).total<e.logins||e.trophies&&In(i).best<e.trophies):!0}function Yr(i){return i?i.lvl?`Commander level ${i.lvl}`:i.stat?`${i.stat[1]} ${Q_[i.stat[0]]||i.stat[0]}`:i.island?eM[i.island]||i.island:i.allies?"Meet an alien civilisation":i.dex?`${i.dex} species in the Botdex`:i.logins?`${i.logins} days on the login calendar`:i.trophies?`${i.trophies} trophies`:"":"Free"}const ol=[...ao.map(i=>({key:"paint:"+i.id,kind:"paint",name:i.name,need:i.need})),...Tp.map(i=>({key:"bg:"+i.id,kind:"banner colour",name:i.name,need:i.need})),...Rp.map(i=>({key:"em:"+i.id,kind:"emblem",name:i.name,need:i.need})),...Cp.map(i=>({key:"turf:"+i.id,kind:"island turf",name:i.name,need:i.need}))],tM=i=>ol.filter(e=>er(i,e.need));function Pp(i){const e=i;return e.styleSeen||(e.styleSeen=ol.filter(t=>er(i,t.need)).map(t=>t.key)),e.styleSeen}function nM(i){const e=Pp(i),t=ol.filter(n=>er(i,n.need)&&!e.includes(n.key));for(const n of t)e.push(n.key);return t.length&&(i.styleNew=(i.styleNew||0)+t.length),t}const iM=i=>{Pp(i)},sM=i=>i.styleNew||0,aM=i=>{i.styleNew=0},gt={credits:'<span class="ic cr">C</span>',cells:'<span class="ic ce">⚡</span>',dm:'<span class="ic dm">◆</span>',iridium:'<span class="ic ir">✦</span>'},Su=(i,e)=>Object.entries(i).filter(([,t])=>t>0).map(([t,n])=>`<span class="cost ">${gt[t]||""}${se(n)}</span>`).join(" "),Kr=i=>`<span class="els">${i.map(e=>`<span class="el" style="background:${Be[e].color}" title="${Be[e].name}">${Be[e].glyph}</span>`).join("")}</span>`,rM=qb;class oM{constructor(e){this.app=e,this.sel=null,this.selBot=null,this.tab="bays",this.over="",this.bubbles=new Map,this.lastRes={credits:0,cells:0,dm:0},this.panelKey="",this.tick=0,this.dailyKey="",this.objKey="",this.cardUrl="",this.crew=new G_(this),this.daily=new V_(this),this.arena=new X_(this),this.space=new Y_(this),this.vault=new J_(this),document.addEventListener("click",t=>{const n=t.target.closest("[data-a]");n&&(t.stopPropagation(),this.act(n.dataset.a,n))}),document.addEventListener("input",t=>{const n=t.target;n.dataset.set&&this.app.setSetting(n.dataset.set,n.type==="range"?+n.value:n.value),n.id==="cname"&&(this.s.name=n.value.slice(0,24)||"New Haven",this.renderHud())}),this.renderHud(),this.renderNav(),this.renderObj()}get s(){return this.app.s}get world(){return this.app.world}renderHud(){const e=this.s,t=e.xp/Ea(e)*100;vt("#hud").innerHTML=`<div class="lvl" title="Commander level"><div class="badge" style="--p:${t}%"><b>${e.lvl}</b></div><div class="nm"><b>${re(e.name)}</b><i>${se(e.xp)} / ${se(Ea(e))} XP</i></div></div>
      <button class="chip" data-a="islands" title="Your islands">${{home:"🌍",moon:"🌕",mars:"🔴"}[e.at]||"🌍"} ${re(e.at==="home"?e.name:Bt[e.at].name)} ▾</button>
      <div class="res" id="r-credits">${gt.credits}<span class="v">${se(e.res.credits)}</span></div><div class="res" id="r-cells">${gt.cells}<span class="v">${se(e.res.cells)}</span></div><div class="res" id="r-dm">${gt.dm}<span class="v">${se(e.res.dm)}</span></div>${e.islands.vault?`<div class="res" id="r-iridium" data-a="crystals" title="Iridium and crystals"><span class="ic ir">✦</span><span class="v">${se(e.res.iridium||0)}</span></div>`:""}
      <div class="sp"></div><span id="dailyHud" class="row" style="gap:6px;flex-wrap:nowrap">${this.vault.eventChip()}${this.daily.hudHTML()}</span><button class="ibtn" data-a="zoomout" title="Overview">🛰</button><button class="ibtn" data-a="settings" title="Settings">⚙</button>`}updHud(){const e=this.s;for(const n of["credits","cells","dm","iridium"]){const s=Math.floor(e.res[n]||0);if(s!==Math.floor(this.lastRes[n]||0)){const a=vt(`#r-${n}`);a&&(a.querySelector(".v").textContent=se(s),s>(this.lastRes[n]||0)&&(a.classList.remove("bump"),a.offsetWidth,a.classList.add("bump"))),this.lastRes[n]=s}}const t=vt(".lvl .badge");if(t){t.style.setProperty("--p",e.xp/Ea(e)*100+"%"),t.querySelector("b").textContent=String(e.lvl);const n=vt(".lvl .nm i");n&&(n.textContent=`${se(e.xp)} / ${se(Ea(e))} XP`)}}renderNav(){vt("#nav").innerHTML='<button data-a="shop" id="n-shop"><span class="g">🛒</span>Shop</button><button data-a="bots"><span class="g">🤖</span>Crew</button><button data-a="dex"><span class="g">📖</span>Botdex</button><button data-a="arena"><span class="g">⚔</span>Arena</button><button data-a="space"><span class="g">🚀</span>Space</button><button data-a="custom" id="n-style"><span class="g">🎨</span>Style</button>',iM(this.s),this.updStyleDot()}updStyleDot(){const e=vt("#n-style");if(!e)return;const t=sM(this.s);let n=e.querySelector(".dot");t&&!n?(n=document.createElement("span"),n.className="dot",e.appendChild(n)):!t&&n&&n.remove()}checkStyles(){const e=nM(this.s);if(e.length){this.app.audio.play("sparkle");for(const t of e.slice(0,3))this.toast(`🎨 New ${t.kind} unlocked: ${t.name}. Try it in Style.`,"gold");e.length>3&&this.toast(`🎨 ${e.length-3} more styles unlocked`,"gold"),this.updStyleDot(),this.app.changed()}}renderObj(){const e=this.s,t=Na(e),n=vt("#obj");if(!t){n.classList.add("hidden");return}n.classList.remove("hidden");const s=co(e,t);n.classList.toggle("done",s),n.innerHTML=`<div class="t">Mission ${e.obj.i+1} of ${ro.length}</div><p>${re(t.text)}</p><div class="rw">Reward: ${Su(t.reward)}</div>${s?'<button class="btn gold claim" data-a="claim">✓ Claim reward</button>':""}`}frame(){if(this.tick++,this.updHud(),this.placeBubbles(),this.space.frame(),this.tick%20===0){this.tick%120===0&&this.checkStyles();const e=this.vault.eventChip()+this.daily.hudHTML();if(e!==this.dailyKey){this.dailyKey=e;const t=vt("#dailyHud");t&&(t.innerHTML=e)}}this.tick%15===0&&(this.refreshPanel(),this.renderObjIfChanged(),(this.over==="shop"||this.over==="bots")&&this.refreshOverCosts())}renderObjIfChanged(){const e=Na(this.s),t=(e?e.id:"-")+(e&&co(this.s,e)?1:0);t!==this.objKey&&(this.objKey=t,this.renderObj())}placeBubbles(){const e=this.s,t=this.world,n=new Set,s=vt("#bubbles"),a=(r,o,l,c,d,h)=>{if(!o)return;n.add(r);let u=this.bubbles.get(r);u||(u=document.createElement("div"),u.className="bub",d&&(u.dataset.a=d,h&&(u.dataset.id=h)),s.appendChild(u),this.bubbles.set(r,u)),u.dataset.h!==l+c&&(u.innerHTML=l,u.className="bub "+c,u.dataset.h=l+c);const f=t.project(o);u.style.left=f.x+"px",u.style.top=f.y+"px",u.style.display=f.vis&&!t.ghost&&t.mode==="island"?"":"none"};for(const r of En(e).items){const o=t.topOf(r.id),l=At(e,r.id,"build");if(l){const c=(l.end-Date.now())/1e3,d=ni(1-(l.end-Date.now())/(l.end-l.start));a("t"+r.id,o,`<span>${c>0?xt(c):"Done!"}</span><div class="bar"><i style="width:${d*100}%"></i></div>`,"timer","select",r.id);continue}if(r.t==="bay"){const c=Math.floor(e.bay[r.id]||0);c>=1&&a("c"+r.id,o,`${gt.credits}${se(c)}`,c>=Yi(r,e)*.98?"full":"","collect",r.id)}if(r.t==="fab"){const c=e.ready[r.id],d=At(e,r.id,"craft");if(c)a("r"+r.id,o,`${gt.cells}+${se(c.cells)}`,"ready","harvest",r.id);else if(d){const h=ni(1-(d.end-Date.now())/(d.end-d.start));a("t"+r.id,o,`<span>${xt((d.end-Date.now())/1e3)}</span><div class="bar cell"><i style="width:${h*100}%"></i></div>`,"timer","select",r.id)}else r.lvl>0&&a("i"+r.id,o,`${gt.cells}<span>Idle</span>`,"","select",r.id)}if(r.t==="relicbay"){const c=Math.floor(e.bay[r.id]||0);c>=1&&a("c"+r.id,o,`<span class="ic ir">✦</span>${se(c)}`,c>=Ba(r)*.98?"full":"","collect",r.id)}if(r.t==="mine"&&r.lvl>0){const c=Zt(e).ready[r.id],d=At(e,r.id,"dig");if(c)a("r"+r.id,o,`💎 <span>+${c.n}</span>`,"ready","collectMine",r.id);else if(d){const h=ni(1-(d.end-Date.now())/(d.end-d.start));a("t"+r.id,o,`<span>💎 ${xt((d.end-Date.now())/1e3)}</span><div class="bar"><i style="width:${h*100}%"></i></div>`,"timer","select",r.id)}else a("i"+r.id,o,"💎 <span>Idle</span>","","select",r.id)}if(r.t==="assembly"&&r.lvl>0){const c=e.cores.filter(d=>d.state==="ready").length;c&&a("a"+r.id,o,`🤖 <span>${c} ready!</span>`,"ready","select",r.id)}if(r.t==="fusion"&&r.lvl>0){const c=At(e,r.id,"fuse");if(c){const d=ni(1-(c.end-Date.now())/(c.end-c.start));a("t"+r.id,o,`<span>🧬 ${xt((c.end-Date.now())/1e3)}</span><div class="bar"><i style="width:${d*100}%"></i></div>`,"timer","select",r.id)}else e.bots.filter(d=>d.lvl>=Zi).length>=2&&a("i"+r.id,o,"🧬 <span>Fuse</span>","","select",r.id)}}for(let r=0;r<5;r++)for(let o=0;o<5;o++){const l=`${r},${o}`;if($o(e,l)!=="buyable")continue;const c={x:r*yt+yt/2-Fe/2,y:.4,z:o*yt+yt/2-Fe/2},d=Na(e);e.lvl>=Go(e)&&(t.cam.tdist>40||d&&d.kind==="land")&&a("p"+l,c,`＋ ${gt.credits}${se(Ho(e))}`,"plot","plot",l)}for(const[r,o]of this.bubbles)n.has(r)||(o.remove(),this.bubbles.delete(r))}select(e){this.sel=e,this.selBot=null,this.world.select(e,this.s),this.panelKey="",this.renderPanel()}selectBot(e){this.sel=null,this.selBot=e,this.world.select(null),this.panelKey="",this.renderPanel()}panelSig(){const e=this.s;if(this.selBot){const s=e.bots.find(a=>a.id===this.selBot);return s?["bot",s.id,s.lvl,s.fed,s.post,s.bay,s.stored,s.nick].join("|"):""}const t=this.sel?Rt(e,this.sel):null;if(!t)return"";const n=e.jobs.filter(s=>s.item===t.id).map(s=>s.id+s.kind).join();return[t.id,t.lvl,t.r,n,t.t==="bay"?Dn(e,t.id).map(s=>s.id+s.lvl+s.fed+(s.post||"")).join():"",e.ready[t.id]?1:0,e.lvl,ts(e),Oo(e),oo(e,t.id).map(s=>s.id).join(),t.t==="assembly"?e.cores.map(s=>s.id+s.state).join():"",this.crew.fuseA,this.crew.fuseB,t.t==="mine"?JSON.stringify(Zt(e).ready[t.id]||"")+this.vault.digColor:"",t.t==="forge"||t.t==="relicbay"?JSON.stringify(Zt(e).crystals)+Dn(e,t.id).map(s=>s.id+s.lvl).join()+Math.floor((e.res.iridium||0)/10):""].join("|")}refreshPanel(){if(!this.sel&&!this.selBot)return;if(this.panelSig()!==this.panelKey){this.renderPanel();return}const t=this.s;if(this.selBot){Ts("#panel [data-cost]").forEach(s=>{const[a,r]=s.dataset.cost.split(":");s.classList.toggle("short",t.res[a]<+r)});return}const n=Rt(t,this.sel);if(n){if(Ts("#panel [data-left]").forEach(s=>{const a=t.jobs.find(r=>r.id===s.dataset.left);a&&(s.textContent=xt((a.end-Date.now())/1e3))}),Ts("#panel [data-bar]").forEach(s=>{const a=t.jobs.find(r=>r.id===s.dataset.bar);a&&(s.style.width=ni(1-(a.end-Date.now())/(a.end-a.start))*100+"%")}),Ts("#panel [data-dm]").forEach(s=>{const a=t.jobs.find(r=>r.id===s.dataset.dm);if(a){const r=ui((a.end-Date.now())/1e3);s.innerHTML=r?`${gt.dm}${r} Finish now`:"Finish (free)"}}),n.t==="bay"){const s=vt("#panel .bar.gold i"),a=vt("#panel #bayv"),r=t.bay[n.id]||0;s&&(s.style.width=r/Yi(n,t)*100+"%"),a&&(a.textContent=`${se(r)} / ${se(Yi(n,t))}`)}if(n.t==="relicbay"){const s=vt("#panel #relbar i"),a=vt("#panel #relv"),r=vt("#panel #relc"),o=t.bay[n.id]||0,l=Ba(n);s&&(s.style.width=o/l*100+"%"),a&&(a.textContent=`${se(o)} / ${se(l)}`),r&&(r.disabled=o<1)}Ts("#panel [data-cost]").forEach(s=>{const[a,r]=s.dataset.cost.split(":");s.classList.toggle("short",t.res[a]<+r)})}}renderPanel(){const e=vt("#panel"),t=this.s,n=this.selBot?t.bots.find(l=>l.id===this.selBot):null;if(n){e.classList.remove("hidden"),this.panelKey=this.panelSig(),e.innerHTML=this.crew.botPanel(n);return}const s=this.sel?Rt(t,this.sel):null;if(!s){e.classList.add("hidden");return}e.classList.remove("hidden"),this.panelKey=this.panelSig();const a=Qe[s.t],r=At(t,s.id,"build");let o=`<button class="ibtn x" data-a="deselect">✕</button><h2>${re(s.t==="bay"?`${Be[s.el].name} Bay`:a.name)}</h2><div class="sub">${a.cat==="decor"?"Decoration":`Level ${s.lvl} / ${Vu(t,s)}`}</div>`;if(r){const l=ui((r.end-Date.now())/1e3);o+=`<p class="desc">${s.lvl===0?"Under construction":`Upgrading to level ${r.lvl}`}: builder drones at work.</p><div class="bar"><i data-bar="${r.id}"></i></div><div class="row" style="margin-top:8px"><b class="grow" data-left="${r.id}"></b><button class="btn gold small" data-a="finish" data-job="${r.id}" data-dm="${r.id}">${l?`${gt.dm}${l} Finish now`:"Finish (free)"}</button></div>`}else if(s.t==="hub")o+=`<p class="desc">${re(a.desc)}</p>${Bt[t.at]&&Bt[t.at].perk?`<p class="desc" style="color:#7cf29a">★ ${re(Bt[t.at].perk)}</p>`:""}<table class="stats"><tr><td>Bays allowed here</td><td>${La(s.lvl)}</td></tr><tr><td>Fabricators allowed here</td><td>${qs(s.lvl)}</td></tr><tr><td>Max building level here</td><td>${s.lvl}</td></tr></table>`+this.upgradeRow(s)+this.moveRow(s);else if(s.t==="command"){const l=s.lvl+1;o+=`<p class="desc">${re(a.desc)}</p><table class="stats"><tr><td>Bays allowed</td><td>${La(s.lvl)}</td></tr><tr><td>Fabricators allowed</td><td>${qs(s.lvl)}</td></tr><tr><td>Max building level</td><td>${s.lvl}</td></tr><tr><td>Builder drones</td><td>${t.builders}</td></tr></table>`,s.lvl<a.max&&(o+=`<div class="sub">Level ${l}: ${La(l)} bays · ${qs(l)} fabricators · buildings to level ${l}${Ys[l]>t.lvl?` · needs Commander level ${Ys[l]}`:""}</div>`),o+=this.upgradeRow(s)+this.crew.helpersHTML(s)+`<div class="row" style="margin-top:8px"><button class="btn small" data-a="custom">🎨 Colony style</button><button class="btn small" data-a="move" data-id="${s.id}">✥ Move</button></div>`}else if(s.t==="mine")o+=this.vault.mineHTML(s)+this.upgradeRow(s,s.lvl<a.max?`Level ${s.lvl+1}: +15% shards per dig`:"")+this.moveRow(s);else if(s.t==="forge")o+=this.vault.forgeHTML()+this.moveRow(s);else if(s.t==="relicbay")o+=this.vault.relicHTML(s)+this.upgradeRow(s,s.lvl<a.max?`Level ${s.lvl+1}: holds more Iridium${ti(s.lvl+1)>ti(s.lvl)?`, ${ti(s.lvl+1)} Relic AIs`:""}`:"")+this.moveRow(s);else if(s.t==="pad"){const l=Ht(t);o+=`<p class="desc">${re(a.desc)}</p><table class="stats"><tr><td>Rocket</td><td>${Ms[Ki(s.lvl)-1].name} (tier ${Ki(s.lvl)})</td></tr><tr><td>Launch slots</td><td>${l.exps.length} / ${Qs(s.lvl)} in use</td></tr><tr><td>Worlds visited</td><td>${Object.keys(l.visits).length} / ${ai.length}</td></tr></table><button class="btn gold" data-a="space" style="width:100%">🚀 Open the Solar System</button>`+this.upgradeRow(s,s.lvl<a.max?`Level ${s.lvl+1}${Ki(s.lvl+1)>Ki(s.lvl)?`: the ${Ms[Ki(s.lvl+1)-1].name} rocket`:""}${Qs(s.lvl+1)>Qs(s.lvl)?", +1 launch slot":""}`:"")+this.moveRow(s)}else if(s.t==="arena"){const l=In(t),c=bs(l.trophies);o+=`<p class="desc">${re(a.desc)}</p><div class="row"><b class="grow" style="color:${Ra[c]}">🏆 ${Qi[c][0]} · ${se(l.trophies)}</b><span class="chip">🎟 ${l.tickets}/${_s}</span></div><button class="btn gold" data-a="arena" style="width:100%;margin-top:8px">⚔ Enter the Arena</button>`+this.upgradeRow(s,s.lvl<a.max?`Level ${s.lvl+1}: battle rewards +${s.lvl*10}%`:"")+this.moveRow(s)}else if(s.t==="assembly"||s.t==="fusion")o+=(s.t==="assembly"?this.crew.assemblyHTML(s):this.crew.fusionHTML(s))+this.upgradeRow(s,s.lvl<a.max?s.t==="assembly"?`Level ${s.lvl+1}: boots 5% faster${ka(s.lvl+1)>ka(s.lvl)?", +1 pod":""}${ta(s.lvl+1)>ta(s.lvl)?", +1 helper slot":""}`:`Level ${s.lvl+1}: fuses 5% faster`:"")+this.moveRow(s);else if(s.t==="bay"){const l=Dn(t,s.id),c=ti(s.lvl),d=t.bay[s.id]||0,h=zo(t,s.id)*60;o+=`<div class="row"><div class="grow"><div class="bar gold"><i style="width:${d/Yi(s,t)*100}%"></i></div></div><b id="bayv">${se(d)} / ${se(Yi(s,t))}</b></div><div class="row" style="margin:6px 0"><span class="grow sub">${gt.credits} ${se(h)} per minute · ${l.length}/${c} bots</span><button class="btn gold small" data-a="collect" data-id="${s.id}" ${d>=1?"":"disabled"}>Collect</button></div>`,o+=`<div class="bots">${l.map(u=>this.botCard(u)).join("")||'<p class="desc">No bots yet. Recruit one in the Shop.</p>'}</div>`,l.length<c&&(o+=`<button class="btn small" style="margin-top:8px;width:100%" data-a="shop" data-tab="bots">＋ Recruit a ${Be[s.el].name} bot</button>`),o+=this.upgradeRow(s,s.lvl<a.max?`Level ${s.lvl+1}: holds ${se(lf(s.lvl+1))} credits${ti(s.lvl+1)>c?`, ${ti(s.lvl+1)} bots`:""}`:"")+this.moveRow(s)}else if(s.t==="fab"){const l=t.ready[s.id],c=At(t,s.id,"craft");if(l)o+=`<div class="row"><span class="grow desc">${se(l.cells)} Power Cells are ready.</span><button class="btn green" data-a="harvest" data-id="${s.id}">${gt.cells} Harvest</button></div>`;else if(c){const d=na[c.recipe||0],h=ui((c.end-Date.now())/1e3);o+=`<p class="desc">Printing <b>${re(d.name)}</b></p><div class="bar cell"><i data-bar="${c.id}"></i></div><div class="row" style="margin-top:8px"><b class="grow" data-left="${c.id}"></b><button class="btn gold small" data-a="finish" data-job="${c.id}" data-dm="${c.id}">${h?`${gt.dm}${h} Finish now`:"Finish (free)"}</button></div>`}else o+=`<p class="desc">Pick a recipe. Longer recipes make more cells per credit: choose one that finishes when you'll be back.</p><div class="recipes">${ef(s).map(d=>`<div class="rec ${d.open?"":"locked"}"><b>${re(d.name)}</b><span class="out">⚡${se(d.out)}</span><span class="sub">${xt(d.sec)}</span>${d.open?`<button class="btn small" data-a="craft" data-id="${s.id}" data-r="${d.i}"><span class="cost" data-cost="credits:${d.cost}">${gt.credits}${se(d.cost)}</span></button>`:`<span class="why">Level ${d.lvl}</span>`}</div>`).join("")}</div>`;o+=this.upgradeRow(s,s.lvl<a.max?`Level ${s.lvl+1}: +10% cells${na.some(d=>d.lvl===s.lvl+1)?", a new recipe":""}`:"")+this.crew.helpersHTML(s)+this.moveRow(s)}else if(s.t==="statue"){const l=[...new Set(t.bots.map(c=>c.sp))].sort((c,d)=>Ct.indexOf(Q[d].rarity)-Ct.indexOf(Q[c].rarity));o+=`<p class="desc">${s.el&&Q[s.el]?`${re(Q[s.el].name)} stands on the plinth, cast in gold.`:"Choose who stands on the plinth:"}</p><div class="pick">${l.map(c=>`<button class="pk ${s.el===c?"on":""}" data-a="statueSp" data-id="${s.id}" data-sp="${c}" title="${re(Q[c].name)}"><img src="${this.app.studio.bot(c)}" alt=""></button>`).join("")}</div>
        <div class="row" style="margin-top:8px"><button class="btn small" data-a="move" data-id="${s.id}">✥ Move</button><button class="btn small" data-a="sell" data-id="${s.id}">Sell (${gt.credits}${se(Math.floor(a.buildCost(0)*.5))})</button></div>`}else o+=`<p class="desc">${re(a.desc)}</p><div class="row"><button class="btn small" data-a="move" data-id="${s.id}">✥ Move</button><button class="btn small" data-a="sell" data-id="${s.id}">Sell (${gt.credits}${se(Math.floor(a.buildCost(0)*.5))})</button></div>`;e.innerHTML=o}moveRow(e){return`<div class="row" style="margin-top:8px"><button class="btn small" data-a="move" data-id="${e.id}">✥ Move</button></div>`}upgradeRow(e,t=""){const n=this.s,s=Qe[e.t];if(e.lvl>=s.max)return'<p class="sub">Maximum level.</p>';const a=id(n,e);return`${t?`<div class="sub">${t}</div>`:""}<div class="row" style="margin-top:8px"><span class="grow">${a.cost?`<span class="cost ${n.res.credits<a.cost?"short":""}" data-cost="credits:${a.cost}">${gt.credits}${se(a.cost)}</span> · ${xt(a.time||0)}`:""}</span><button class="btn gold" data-a="upgrade" data-id="${e.id}" ${a.ok?"":"disabled"}>⬆ Upgrade</button></div>${a.ok?"":`<p class="why">${re(a.why||"")}</p>`}`}botCard(e,t=!1){const n=this.s,s=Q[e.sp],a=Bo(e.lvl),r=t&&e.bay?Rt(n,e.bay):null;return`<div class="botc"><div class="pic" data-a="selBot" data-bot="${e.id}" style="cursor:pointer;background:radial-gradient(circle at 50% 40%, ${Be[s.el[0]].color}55, transparent 70%)"><img src="${this.app.studio.bot(e.sp)}" alt=""></div>
      <div><b data-a="selBot" data-bot="${e.id}" style="cursor:pointer">${re(e.nick||s.name)}</b> ${Kr(s.el)}<div class="meta"><span class="rar" style="color:${We[s.rarity].color}">${We[s.rarity].name}</span> · Level ${e.lvl}<span class="pips">${[0,1,2,3].map(o=>`<i class="${o<e.fed?"on":""}"></i>`).join("")}</span></div><div class="meta">${e.post?"🛠 helping":e.stored?"❄ stored":`${gt.credits} ${se(Ei(e))}/min`}${r?` · ${Be[r.el].name} Bay`:""}</div></div>
      ${e.lvl<ko?`<button class="btn small green" data-a="feed" data-bot="${e.id}"><span class="cost" data-cost="cells:${a}">${gt.cells}${se(a)}</span></button>`:'<span class="sub">MAX</span>'}</div>`}openOver(e,t){this.over=e,t&&(this.tab=t),this.select(null),this.renderOver(),this.app.platform.gameplayStop()}closeOver(){this.over="",vt("#over").classList.add("hidden"),this.app.platform.gameplayStart()}renderOver(){const e=vt("#over");e.classList.remove("hidden");const t=this.s;if(this.over==="shop"){const n=t.at==="vault"?[["vault","Vault"],["decor","Decor"]]:[["bays","Bays"],["bots","Bots"],["buildings","Buildings"],["decor","Decor"]];t.at==="vault"&&!["vault","decor"].includes(this.tab)&&(this.tab="vault"),t.at!=="vault"&&this.tab==="vault"&&(this.tab="bays");let s="";this.tab==="bays"?s=rM.map(a=>{const r=ei(t,"bay",a),o=ze(t,"bay").filter(l=>l.el===a).length;return this.shopCard(this.app.studio.building("bay",1,a,this.world.look),`${Be[a].name} Bay`,`${Be[a].blurb} ${o?`You have ${o}.`:""}`,r,`data-a="buyB" data-t="bay" data-el="${a}"`,Kr([a]))}).join(""):this.tab==="bots"?s=$n.filter(a=>Q[a].price).map(a=>{const r=Q[a],o=ad(t,a),l=t.bots.filter(c=>c.sp===a).length;return this.shopCard(this.app.studio.bot(a),r.name,r.desc+(r.rarity!=="standard"?` Boots in the Assembly Bay (${xt(We[r.rarity].assembly*.5)}).`:""),o,`data-a="recruit" data-sp="${a}"`,`${Kr(r.el)} <span class="rar" style="color:${We[r.rarity].color}">${We[r.rarity].name}</span> · ${se(Ei({sp:a,lvl:1}))}/min${l?` · owned ${l}`:""}${t.dex[a]?"":' · <b style="color:#ffd36a">new</b>'}`,(r.unlock||1)>t.lvl)}).join(""):this.tab==="vault"?s=[...["mine","forge"].map(a=>{const r=ei(t,a);return this.shopCard(this.app.studio.building(a,1,void 0,this.world.look),Qe[a].name,Qe[a].desc,r,`data-a="buyB" data-t="${a}"`)}),...Object.keys(Kt).map(a=>{const r=ei(t,"relicbay",a);return this.shopCard(this.app.studio.building("relicbay",1,a,this.world.look),`${Kt[a].name} Sanctum`,`Wakes ${Kt[a].name} Relic AIs. They earn Iridium here.`,r,`data-a="buyB" data-t="relicbay" data-el="${a}"`)}),(()=>{const a=ei(t,"monolith");return this.shopCard(this.app.studio.building("monolith",1,void 0,this.world.look),Qe.monolith.name,Qe.monolith.desc,a,'data-a="buyB" data-t="monolith"')})()].join(""):this.tab==="buildings"?s=["fab","assembly","fusion"].map(a=>{const r=ei(t,a);return this.shopCard(this.app.studio.building(a,1,void 0,this.world.look),Qe[a].name,Qe[a].desc,r,`data-a="buyB" data-t="${a}"`,a==="fab"?`${ze(t,a).length}/${qs(ts(t))} built`:ze(t,a).length?"Built":`Unlocks at Commander level ${Qe[a].unlock}`,Qe[a].unlock>t.lvl)}).join(""):s=[...t.stats.decor_arch?["arch"]:[],...jd.filter(a=>Qe[a].cat==="decor"&&!Qe[a].vault)].map(a=>{const r=ei(t,a);return this.shopCard(this.app.studio.building(a,1,void 0,this.world.look),Qe[a].name,Qe[a].desc,r,`data-a="buyB" data-t="${a}"`,"",Qe[a].unlock>t.lvl)}).join(""),e.innerHTML=`<div class="head"><h1>Shop</h1><div class="res">${gt.credits}<span>${se(t.res.credits)}</span></div><button class="ibtn" data-a="close">✕</button></div><div class="tabs">${n.map(([a,r])=>`<button class="tab ${this.tab===a?"on":""}" data-a="tab" data-tab="${a}">${r}</button>`).join("")}</div><div class="body"><div class="grid">${s}</div></div>`}else if(this.over==="bots"){const n=[...t.bots].sort((r,o)=>Ei(o)-Ei(r)),s=t.bots.reduce((r,o)=>r+Ei(o),0),a=t.cores.length?`<div class="botc" style="grid-template-columns:54px 1fr auto;border-color:var(--gold)"><div style="font-size:30px;text-align:center">🤖</div><div><b>${t.cores.length} core${t.cores.length>1?"s":""} waiting</b><div class="meta">${t.cores.map(r=>`<span style="color:${We[Q[r.sp].rarity].color}">●</span>`).join(" ")} ${ze(t,"assembly").some(r=>r.lvl>0)?"in the Assembly Bay":"Build the Assembly Bay (Commander level 4) to boot them"}</div></div><span></span></div>`:"";e.innerHTML=`<div class="head"><h1>Your crew</h1><span class="sub">${t.bots.length} bots · ${gt.credits} ${se(s)}/min</span><button class="ibtn" data-a="close">✕</button></div><div class="body"><div class="bots" style="max-width:640px;margin:0 auto">${a}${n.map(r=>this.botCard(r,!0)).join("")}</div></div>`}else if(this.over==="custom")e.innerHTML=this.customHTML();else if(this.over==="dex")e.innerHTML=this.crew.dexHTML();else if(this.over==="daily")e.innerHTML=this.daily.overHTML();else if(this.over==="arena")e.innerHTML=this.arena.overHTML();else if(this.over==="event")e.innerHTML=this.vault.eventHTML();else if(this.over==="settings"){const n=t.settings;e.innerHTML=`<div class="head"><h1>Settings</h1><button class="ibtn" data-a="close">✕</button></div><div class="body"><div class="card" style="max-width:420px;margin:0 auto;gap:12px">
      <label>Sound effects <input type="range" min="0" max="1" step="0.05" value="${n.sfx}" data-set="sfx" style="width:100%"></label><label>Music <input type="range" min="0" max="1" step="0.05" value="${n.music}" data-set="music" style="width:100%"></label>
      <label>Graphics <select data-set="quality" style="width:100%;padding:8px;border-radius:8px;background:#0d1a2e;color:#fff;border:1px solid var(--line)">${["auto","high","low"].map(s=>`<option ${n.quality===s?"selected":""}>${s}</option>`).join("")}</select></label>
      <p class="sub">Starward 3D · version ${this.app.version} · web build. Your colony runs in real time, even while you are away.</p><button class="btn" data-a="reset">Reset progress</button></div></div>`}}shopCard(e,t,n,s,a,r="",o=!1){return`<div class="card ${o?"locked":""}"><div class="thumb"><img src="${e}" alt=""></div><b>${re(t)}</b>${r?`<div class="sub" style="margin:0">${r}</div>`:""}<p class="desc">${re(n)}</p>
      <button class="btn ${s.ok?"gold":""} small" ${a} ${s.ok?"":"disabled"}>${o?"🔒 ":""}${s.cost!==void 0?`<span class="cost" data-cost="credits:${s.cost}">${gt.credits}${se(s.cost)}</span>`:"Free"}</button>${s.ok?"":`<span class="why">${re(s.why||"")}</span>`}</div>`}refreshOverCosts(){Ts("#over [data-cost]").forEach(e=>{const[t,n]=e.dataset.cost.split(":");e.classList.toggle("short",this.s.res[t]<+n)})}customHTML(){const e=this.s,t=this.bannerSVG(e.banner),n=En(e),s=Bt[e.at]?Bt[e.at].theme:"haven",a=n.turf||s,r=(l,c,d,h,u,f="")=>{const g=er(e,c);return`<button class="sw ${f} ${l?"on":""} ${g?"":"lk"}" ${g?h:`data-a="lockedStyle" data-why="${re(u+": "+Yr(c))}"`} title="${re(u+(g?"":" · "+Yr(c)))}">${d}${g?"":"<i>🔒</i>"}</button>`},o=ao.find(l=>l.primary===e.paint.primary&&l.accent===e.paint.accent);return`<div class="head"><h1>Colony style</h1><span class="chip">🎨 ${tM(e).length} / ${ol.length} styles</span><button class="ibtn" data-a="close">✕</button></div><div class="body"><div class="stylegrid">
      <div class="card"><label class="ox">Colony name<input id="cname" value="${re(e.name)}" maxlength="24" style="width:100%;margin-top:6px;padding:10px;border-radius:10px;border:1px solid var(--line);background:#0d1a2e;color:#fff;font:600 16px Barlow"></label>
        <p class="sub" style="margin:8px 0">Your name flies on every Neon Sign; your banner on the Command Center, every Colony Flag and Holo Beacon, and in the Arena.</p><button class="btn gold" data-a="shareCard">📸 Make a colony card</button></div>
      <div class="card"><div class="row"><b class="ox grow">Paint scheme</b><span class="sub">${re(o?o.name:"")}</span></div><div class="sws">${ao.map((l,c)=>r(o===l,l.need,`<span style="background:linear-gradient(135deg, ${l.primary} 55%, ${l.accent} 55%)"></span>`,`data-a="paint" data-i="${c}"`,l.name)).join("")}</div></div>
      <div class="card"><b class="ox">Banner</b><div class="row" style="margin-top:6px;align-items:flex-start;gap:12px"><div style="width:120px;flex:none">${t}</div><div class="grow">
        <div class="sws sm">${Tp.map(l=>r(e.banner.bg===l.color,l.need,`<span style="background:${l.color}"></span>`,`data-a="bannerBg" data-c="${l.color}"`,l.name)).join("")}</div>
        <div class="sws sm round">${j_.map(l=>r(e.banner.fg===l,void 0,`<span style="background:${l}"></span>`,`data-a="bannerFg" data-c="${l}"`,"Emblem colour")).join("")}</div></div></div>
        <div class="sws em">${Rp.map(l=>r(e.banner.emblem===l.id,l.need,this.bannerSVG({bg:"transparent",fg:"#ffffff",emblem:l.id},30),`data-a="emblem" data-e="${l.id}"`,l.name)).join("")}</div></div>
      <div class="card wide"><div class="row"><b class="ox grow">Island turf</b><span class="sub">${re(Bt[e.at]?Bt[e.at].name:"New Haven")}</span></div><div class="turfs">${Cp.map(l=>{const[c,d,h]=Gb(l.id),u=er(e,l.need);return`<button class="turf ${a===l.id?"on":""} ${u?"":"lk"}" ${u?`data-a="turf" data-k="${l.id}"`:`data-a="lockedStyle" data-why="${re(l.name+": "+Yr(l.need))}"`}><span class="tp" style="background:linear-gradient(160deg, ${c} 0 62%, ${d} 62% 74%, ${h} 74%)"></span><b>${re(l.name)}</b><small>${u?re(l.desc):"🔒 "+re(Yr(l.need))}</small></button>`}).join("")}</div></div>
      </div><p class="sub" style="text-align:center">Locked styles show how to earn them: level up, win in the Arena, found islands, meet aliens, repel the Swarm and finish events. Every island can wear its own turf.</p></div>`}async shareCard(){const e=this.s,t=this.world;t.renderer.render(t.scene,t.camera);const n=t.renderer.domElement,s=document.createElement("canvas");s.width=1200,s.height=630;const a=s.getContext("2d");a.fillStyle="#081221",a.fillRect(0,0,1200,630);const r=780,o=630,l=n.width/n.height,c=r/o;let d=n.width,h=n.height,u=0,f=0;l>c?(d=h*c,u=(n.width-d)/2):(h=d/c,f=(n.height-h)/2),a.drawImage(n,u,f,d,h,420,0,r,o);const g=a.createLinearGradient(380,0,700,0);g.addColorStop(0,"#081221"),g.addColorStop(1,"rgba(8,18,33,0)"),a.fillStyle=g,a.fillRect(380,0,320,630);const y=document.createElement("canvas");y.width=128,y.height=80;const m=y.getContext("2d");m.fillStyle=e.banner.bg,m.fillRect(0,0,128,80),m.fillStyle=e.banner.fg,m.translate(64,40),Ya(m,e.banner.emblem,26),m.fill(Ka(e.banner.emblem)),a.save(),a.shadowColor="rgba(0,0,0,0.5)",a.shadowBlur=16,a.drawImage(y,56,56,144,90),a.restore(),a.fillStyle=e.paint.accent,a.fillRect(56,150,144,6),a.fillStyle="#ffffff",a.font="700 54px Oxanium, sans-serif";let p=54;for(;a.measureText(e.name).width>420&&p>28;)p-=2,a.font=`700 ${p}px Oxanium, sans-serif`;a.fillText(e.name,56,222),a.fillStyle="#7fe3ff",a.font="600 24px Barlow, sans-serif",a.fillText(`Commander level ${e.lvl}`,58,258);const x=In(e);[["Bots",String(e.bots.length)],["Botdex",`${Object.keys(e.dex).length} / ${$n.length}`],["Trophies",String(x.trophies)],["Islands",String(Object.keys(e.islands).length)]].forEach(([S,v],w)=>{const P=58+w%2*190,R=310+Math.floor(w/2)*64;a.fillStyle="rgba(255,255,255,0.55)",a.font="600 18px Barlow, sans-serif",a.fillText(S.toUpperCase(),P,R),a.fillStyle="#ffd36a",a.font="700 30px Oxanium, sans-serif",a.fillText(v,P,R+32)});const b=[...new Set([...e.bots].sort((S,v)=>Ct.indexOf(Q[v.sp].rarity)-Ct.indexOf(Q[S.sp].rarity)||v.lvl-S.lvl).map(S=>S.sp))].slice(0,3);for(let S=0;S<b.length;S++){const v=new Image;v.src=this.app.studio.bot(b[S]);try{await v.decode()}catch{continue}const w=50+S*118;a.fillStyle="rgba(255,255,255,0.06)",a.beginPath(),a.roundRect(w,442,104,104,16),a.fill(),a.strokeStyle=We[Q[b[S]].rarity].color,a.lineWidth=3,a.stroke(),a.drawImage(v,w+4,446,96,96)}a.fillStyle="rgba(8,18,33,0.75)",a.fillRect(420,560,780,70),a.fillStyle="#ffffff",a.font="800 30px Oxanium, sans-serif",a.fillText("STARWARD 3D",446,606),a.fillStyle="rgba(255,255,255,0.7)",a.font="600 20px Barlow, sans-serif",a.fillText("Build your own colony in orbit",680,604),this.cardUrl=s.toDataURL("image/png");const E=typeof navigator.share=="function";this.modal(`<h1 style="font-size:22px">Your colony card</h1><img src="${this.cardUrl}" alt="Colony card" style="width:100%;border-radius:12px;display:block;margin:8px 0"><div class="row" style="justify-content:center;gap:8px"><a class="btn gold" download="${re(e.name.replace(/[^\w -]/g,"")||"colony")}.png" href="${this.cardUrl}">⬇ Save image</a>${E?'<button class="btn" data-a="shareNative">Share</button>':""}<button class="btn" data-a="closeModal">Close</button></div>`)}async shareNative(){try{const e=await(await fetch(this.cardUrl)).blob(),n={files:[new File([e],"starward-colony.png",{type:"image/png"})],title:this.s.name,text:`My colony ${this.s.name} in Starward 3D`};navigator.canShare&&!navigator.canShare(n)&&delete n.files,await navigator.share(n)}catch{}}bannerSVG(e,t=120){const n=document.createElement("canvas");n.width=128,n.height=80;const s=n.getContext("2d");return e.bg!=="transparent"&&(s.fillStyle=e.bg,s.fillRect(0,0,128,80)),s.fillStyle=e.fg,s.translate(64,40),Ya(s,e.emblem,26),s.fill(Ka(e.emblem)),`<img src="${n.toDataURL()}" style="width:${t}px;height:${t*80/128}px;border-radius:6px;display:block">`}renderPlace(){const e=vt("#place"),t=this.world.ghost;if(!t){e.classList.add("hidden");return}e.classList.remove("hidden");const n=Qe[t.t],s=t.move?null:ei(this.s,t.t,t.el);e.innerHTML=`<span class="lbl">${re(t.t==="bay"?`${Be[t.el].name} Bay`:n.name)}${s&&s.cost?` · ${gt.credits}${se(s.cost)}`:""}</span><button class="btn small" data-a="placeRot">⟳ Rotate</button><button class="btn small" data-a="placeCancel">✕</button><button class="btn green small" data-a="placeOk" ${t.ok?"":"disabled"}>✓ ${t.move?"Place":"Build"}</button>`}toast(e,t=""){const n=document.createElement("div");n.className="toast "+t,n.textContent=e,vt("#toasts").appendChild(n),setTimeout(()=>n.remove(),2600)}popText(e,t,n,s){const a=document.createElement("div");a.className="pop",a.style.left=e+"px",a.style.top=t+"px",a.style.color=s,a.textContent=n,document.body.appendChild(a),setTimeout(()=>a.remove(),1100)}flyTo(e,t,n,s=6){const a=vt(`#r-${e}`);if(!a)return;const r=a.getBoundingClientRect();for(let o=0;o<s;o++){const l=document.createElement("div");l.className="fly",l.innerHTML=gt[e].replace('class="ic','style="width:26px;height:26px" class="ic'),l.style.left=t-13+(Math.random()-.5)*40+"px",l.style.top=n-13+(Math.random()-.5)*30+"px",document.body.appendChild(l),setTimeout(()=>{l.style.transform=`translate(${r.left+13-parseFloat(l.style.left)}px, ${r.top+13-parseFloat(l.style.top)}px) scale(0.6)`,l.style.opacity="0.4"},30+o*45),setTimeout(()=>l.remove(),800+o*45)}}modal(e,t=!1){const n=vt("#modal");n.innerHTML=`${t?'<div class="rays"></div>':""}<div class="box">${e}</div>`,n.classList.remove("hidden"),this.app.platform.gameplayStop()}closeModal(){vt("#modal").classList.add("hidden"),vt("#modal").innerHTML="",this.over||this.app.platform.gameplayStart()}levelUp(e,t,n=null){const s=[...$n.filter(a=>Q[a].unlock===e).map(a=>Q[a].name),...jd.filter(a=>Qe[a].unlock===e).map(a=>Qe[a].name)];this.modal(`<div class="ox sub" style="letter-spacing:.2em">COMMANDER LEVEL</div><div class="big">${e}</div><h1>Level up!</h1><div class="rewards">${Su(t)}</div>${n?`<div class="sub" style="margin:0">Milestone bonus</div>${this.daily.giftLine(n)}`:""}${s.length?`<p class="desc">Unlocked: <b>${s.map(re).join(", ")}</b></p>`:""}${Ys.indexOf(e)>1?`<p class="desc">You can now upgrade the Command Center to level ${Ys.indexOf(e)}.</p>`:""}<button class="btn gold" data-a="closeModal" style="margin-top:8px;min-width:160px">Awesome!</button>`,!0)}newBot(e){const t=Q[e.sp],n=Date.now()-(this.s.dex[e.sp]||0)<4e3&&Object.keys(this.s.dex).length>1,s=We[t.rarity].color,a=Ct.indexOf(t.rarity);this.modal(`<div class="ox sub" style="letter-spacing:.2em;color:${s}">${n?"★ NEW SPECIES DISCOVERED ★":"NEW CREWMATE"}</div>${a>=2?`<div style="position:absolute;inset:0;border-radius:22px;box-shadow:inset 0 0 60px ${s}66;pointer-events:none"></div>`:""}<img src="${this.app.studio.bot(e.sp)}" style="width:180px;height:180px;margin:-6px auto -10px;display:block"><h1>${re(t.name)}</h1><div>${Kr(t.el)} <span class="rar" style="color:${We[t.rarity].color}">${We[t.rarity].name}</span></div><p class="desc">${re(t.desc)}</p><p class="sub">Earns ${gt.credits} ${se(Ei(e))} per minute. Feed it Power Cells to level it up.</p><button class="btn gold" data-a="closeModal" style="min-width:160px">Welcome aboard!</button>`,!0)}act(e,t){const n=this.app,s=this.s;if(n.audio.unlock(),this.crew.act(e,t)||this.daily.act(e,t)||this.arena.act(e,t)||this.space.act(e,t)||this.vault.act(e,t))return;const a=t.dataset.id||"",r=a?Rt(s,a):void 0;switch(e){case"shop":this.openOver("shop",t.dataset.tab||this.tab),n.audio.play("tap");break;case"bots":this.openOver("bots"),n.audio.play("tap");break;case"dex":this.openOver("dex"),n.audio.play("tap");break;case"custom":aM(s),this.updStyleDot(),this.openOver("custom"),n.audio.play("tap");break;case"lockedStyle":this.toast(`🔒 ${t.dataset.why}`,""),n.audio.play("deny");break;case"turf":{const o=En(s),l=t.dataset.k,c=Bt[s.at]?Bt[s.at].theme:"haven";l===c?delete o.turf:o.turf=l,n.changed(),this.renderOver(),n.audio.play("place");break}case"statueSp":if(r){r.el=t.dataset.sp,n.changed(),this.renderPanel(),n.audio.play("place");const o=this.world.topOf(r.id);o&&this.world.burst(o,"#ffd36a",26)}break;case"shareCard":this.shareCard(),n.audio.play("tap");break;case"shareNative":this.shareNative();break;case"settings":this.openOver("settings"),n.audio.play("tap");break;case"close":this.closeOver(),n.audio.play("tap");break;case"tab":this.tab=t.dataset.tab,this.renderOver(),n.audio.play("tap");break;case"islands":{const o=jp.map(l=>{const c=Bt[l],d=!!s.islands[l],h=d?null:cd(s,l);return`<div class="botc" style="grid-template-columns:54px 1fr auto"><div style="font-size:34px;text-align:center">${{home:"🌍",moon:"🌕",mars:"🔴"}[l]}</div><div><b>${re(l==="home"?s.name:c.name)}</b>${s.at===l?' <span class="tag" style="color:#7cf29a">you are here</span>':""}<div class="meta">${re(c.blurb)}</div>${c.perk?`<div class="meta" style="color:#7cf29a">★ ${re(c.perk)}</div>`:""}${!d&&h&&!h.ok?`<div class="why" style="margin:2px 0 0">${re(h.why||"")}</div>`:""}</div>
            ${d?s.at===l?"<span></span>":`<button class="btn gold small" data-a="travel" data-k="${l}">Travel</button>`:`<button class="btn ${h&&h.ok?"gold":""} small" data-a="foundIsland" data-k="${l}" ${h&&h.ok?"":"disabled"}>Found ${gt.credits}${se(c.cost||0)}</button>`}</div>`}).join("");this.modal(`<h1 style="font-size:22px">Your islands</h1><p class="sub">Every island keeps working while you are elsewhere: bays fill and recipes finish everywhere.</p><div class="bots" style="text-align:left">${o}</div><button class="btn" data-a="closeModal" style="margin-top:10px">Close</button>`),n.audio.play("tap");break}case"travel":this.closeModal(),n.travel(t.dataset.k);break;case"foundIsland":{const o=rf(s,t.dataset.k);this.closeModal(),o.ok?n.travel(t.dataset.k,!0):this.deny(o.why);break}case"zoomout":this.world.focus(0,1,this.world.cam.tdist>45?30:58),n.audio.play("whoosh");break;case"deselect":this.select(null),this.selBot=null,this.renderPanel();break;case"select":a&&(this.select(a),n.audio.play("tap"));break;case"collect":r&&n.collect(r);break;case"harvest":r&&n.harvest(r);break;case"craft":if(r){const o=nf(s,r,+t.dataset.r);o.ok?(n.audio.play("buy"),n.changed(),this.renderPanel()):this.deny(o.why)}break;case"upgrade":if(r){const o=Wu(s,r);o.ok?(n.audio.play("build"),n.changed(),this.renderPanel()):this.deny(o.why)}break;case"finish":{const o=s.jobs.find(l=>l.id===t.dataset.job);o&&Zu(s,o)?(n.audio.play("done"),n.changed(),this.renderPanel()):this.deny("Not enough Dark Matter");break}case"feed":{const o=s.bots.find(c=>c.id===t.dataset.bot);if(!o)break;const l=sd(s,o);if(l.ok){n.audio.play(l.lvlUp?"done":"feed");const c=t.getBoundingClientRect();this.popText(c.left+c.width/2,c.top,l.lvlUp?`Level ${o.lvl}!`:"+XP",l.lvlUp?"#ffd36a":"#9dff5a"),n.changed(),this.over==="bots"?this.renderOver():this.renderPanel()}else this.deny(l.why);break}case"recruit":{const o=ju(s,t.dataset.sp);if(o.ok&&o.core){n.audio.play("buy"),this.closeOver(),n.changed();const l=ze(s,"assembly")[0];if(l){const c=this.world.centerOf(l);this.world.focus(c.x,c.z),this.select(l.id)}this.toast("The core is booting in the Assembly Bay","good");break}if(o.ok&&o.bot){n.audio.play("buy"),this.closeOver(),n.changed(),this.newBot(o.bot);const l=Rt(s,o.bot.bay);if(l){const c=this.world.centerOf(l);this.world.focus(c.x,c.z)}}else this.deny(o.why);break}case"buyB":{const o=t.dataset.t,l=t.dataset.el,c=ei(s,o,l);if(!c.ok){this.deny(c.why);break}this.closeOver(),n.startPlacing({t:o,el:l,r:0,x:0,z:0,ok:!1});break}case"move":r&&(this.select(null),n.startPlacing({t:r.t,el:r.el,r:r.r,x:r.x,z:r.z,move:r.id,ok:!0}));break;case"sell":r&&Ku(s,r)&&(n.audio.play("buy"),this.select(null),n.changed());break;case"placeRot":this.world.rotateGhost(),n.audio.play("tap");break;case"placeCancel":n.endPlacing(),n.audio.play("tap");break;case"placeOk":n.confirmPlacing();break;case"plot":n.askPlot(a);break;case"buyPlot":{const o=sf(s,t.dataset.k);this.closeModal(),o.ok?(n.audio.play("levelup"),n.changed(),this.toast("The island grows!","gold")):this.deny(o.why);break}case"claim":{const o=af(s);if(o){n.audio.play("claim");const l=t.getBoundingClientRect();for(const c of Object.keys(o.reward))this.flyTo(c,l.left+l.width/2,l.top);n.changed(),this.renderObj()}break}case"closeModal":this.closeModal(),n.audio.play("tap");break;case"paint":{const o=ao[+t.dataset.i];s.paint={primary:o.primary,accent:o.accent},n.changed(),this.renderOver(),n.audio.play("tap");break}case"bannerBg":s.banner={...s.banner,bg:t.dataset.c},n.changed(),this.renderOver(),n.audio.play("tap");break;case"bannerFg":s.banner={...s.banner,fg:t.dataset.c},n.changed(),this.renderOver(),n.audio.play("tap");break;case"emblem":s.banner={...s.banner,emblem:t.dataset.e},n.changed(),this.renderOver(),n.audio.play("tap");break;case"reset":t.dataset.sure?n.reset():(t.dataset.sure="1",t.textContent="Tap again to erase your colony");break}}deny(e){this.toast(e||"Not possible","bad"),this.app.audio.play("deny")}}class lM{constructor(){this.ctx=null,this.out=null,this.vol=.8,this.mvol=.45,this.muted=!1,this.music=null,this.timer=0}unlock(){if(this.ctx){this.ctx.state==="suspended"&&this.ctx.resume();return}try{this.ctx=new(window.AudioContext||window.webkitAudioContext),this.out=this.ctx.createGain(),this.out.gain.value=this.muted?0:this.vol,this.out.connect(this.ctx.destination)}catch{this.ctx=null}}setVolume(e){this.vol=e,this.out&&(this.out.gain.value=this.muted?0:e)}setMuted(e){this.muted=e,this.out&&(this.out.gain.value=e?0:this.vol),this.music&&(this.music.bus.gain.value=e?0:this.mvol*.4)}tone(e,t,n,s="sine",a=.2,r=0){const o=this.ctx,l=o.createOscillator(),c=o.createGain();l.type=s,l.frequency.setValueAtTime(e,t),r&&l.frequency.exponentialRampToValueAtTime(Math.max(30,e*r),t+n),c.gain.setValueAtTime(0,t),c.gain.linearRampToValueAtTime(a,t+.008),c.gain.exponentialRampToValueAtTime(1e-4,t+n),l.connect(c),c.connect(this.out),l.start(t),l.stop(t+n+.05)}noise(e,t,n=.2,s=800){const a=this.ctx,r=a.createBuffer(1,Math.floor(a.sampleRate*t),a.sampleRate),o=r.getChannelData(0);for(let h=0;h<o.length;h++)o[h]=(Math.random()*2-1)*(1-h/o.length);const l=a.createBufferSource();l.buffer=r;const c=a.createBiquadFilter();c.type="lowpass",c.frequency.value=s;const d=a.createGain();d.gain.value=n,l.connect(c),c.connect(d),d.connect(this.out),l.start(e)}play(e,t=1){if(!this.ctx||!this.out||this.muted)return;const n=this.ctx.currentTime;switch(e){case"tap":this.tone(880,n,.06,"triangle",.08);break;case"collect":{const s=Math.min(6,2+Math.floor(Math.log10(Math.max(1,t))));[0,4,7,12,16,19].slice(0,s).forEach((a,r)=>this.tone(988*Math.pow(2,a/12),n+r*.055,.22,"triangle",.12));break}case"harvest":[0,5,9].forEach((s,a)=>this.tone(660*Math.pow(2,s/12),n+a*.06,.2,"square",.05)),this.tone(1320,n+.2,.3,"sine",.08);break;case"build":this.noise(n,.12,.25,500),this.tone(120,n,.18,"sine",.3,.5);break;case"place":this.tone(220,n,.12,"sine",.25,.6),this.noise(n,.08,.15,1200);break;case"done":[0,4,7,12].forEach((s,a)=>this.tone(523*Math.pow(2,s/12),n+a*.08,.3,"triangle",.12));break;case"feed":this.tone(300,n,.15,"sawtooth",.06,2.2),this.tone(600,n+.05,.12,"square",.04,1.6);break;case"levelup":[0,4,7,12,16,19,24].forEach((s,a)=>this.tone(392*Math.pow(2,s/12),n+a*.07,.5,"triangle",.13)),[0,4,7].forEach(s=>this.tone(784*Math.pow(2,s/12),n+.55,.9,"sine",.09));break;case"deny":this.tone(180,n,.16,"square",.07,.7);break;case"buy":this.tone(660,n,.1,"triangle",.1),this.tone(990,n+.08,.18,"triangle",.1);break;case"claim":[0,7,12].forEach((s,a)=>this.tone(659*Math.pow(2,s/12),n+a*.07,.35,"triangle",.12));break;case"whoosh":this.noise(n,.35,.18,2400);break;case"hit":this.noise(n,.09,.22,900),this.tone(170,n,.12,"square",.07,.5);break;case"crit":this.noise(n,.18,.32,1800),this.tone(95,n,.28,"sawtooth",.11,.4),this.tone(1250,n+.02,.16,"triangle",.06,.5);break;case"launch":this.noise(n,1.8,.32,320),this.tone(55,n,1.8,"sawtooth",.1,2.6),this.noise(n+.2,1.4,.12,2600);break;case"crystal":[0,7,12,19].forEach((s,a)=>this.tone(1046*Math.pow(2,s/12),n+a*.05,.45,"sine",.07)),this.tone(2093,n+.22,.6,"triangle",.03);break;case"evolve":[0,4,7,11,14,19,24].forEach((s,a)=>{this.tone(330*Math.pow(2,s/12),n+a*.06,.55,"triangle",.1),this.tone(660*Math.pow(2,s/12),n+a*.06+.02,.4,"sine",.04)}),this.noise(n+.42,.5,.08,5e3);break;case"sparkle":[12,19,24,31].forEach((s,a)=>this.tone(784*Math.pow(2,s/12)/2,n+a*.045,.3,"sine",.06));break}}setMusic(e){this.mvol=e,this.music?this.music.bus.gain.setTargetAtTime(this.muted?0:e*.4,this.ctx.currentTime,.4):e>0&&this.startMusic()}startMusic(){if(!this.ctx||this.music||this.mvol<=0)return;const e=this.ctx,t=e.createGain();t.gain.value=0,t.gain.setTargetAtTime(this.muted?0:this.mvol*.4,e.currentTime,2),t.connect(e.destination);const n=e.createBiquadFilter();n.type="lowpass",n.frequency.value=1200,n.connect(t),this.music={bus:t,next:e.currentTime+.5,chord:0,lp:n},this.timer=window.setInterval(()=>this.tick(),300)}tick(){const e=this.ctx,t=this.music;if(!e||!t||e.state!=="running")return;const n=e.currentTime;if(n<t.next)return;const s=[[261.63,329.63,392,493.88],[220,261.63,329.63,392],[174.61,220,261.63,329.63],[196,246.94,293.66,392],[233.08,293.66,349.23,440]],a=s[t.chord%s.length];t.chord+=1+(Math.random()<.25?1:0);const r=9;for(const o of a)for(const l of[-6,5]){const c=e.createOscillator();c.type="sawtooth",c.frequency.value=o/2,c.detune.value=l;const d=e.createGain();d.gain.setValueAtTime(0,n),d.gain.linearRampToValueAtTime(.011,n+3),d.gain.setValueAtTime(.011,n+r-2.5),d.gain.linearRampToValueAtTime(0,n+r+1),c.connect(d),d.connect(t.lp),c.start(n),c.stop(n+r+1.5)}for(let o=0;o<3;o++){const l=a[Math.floor(Math.random()*a.length)]*2,c=e.createOscillator();c.type="sine",c.frequency.value=l;const d=e.createGain(),h=n+1+o*2.4+Math.random();d.gain.setValueAtTime(0,h),d.gain.linearRampToValueAtTime(.03,h+.01),d.gain.exponentialRampToValueAtTime(1e-4,h+2.5),c.connect(d),d.connect(t.bus),c.start(h),c.stop(h+2.6)}t.lp.frequency.setTargetAtTime(800+Math.random()*900,n,3),t.next=n+r-1.5}}const Zr="starward3d_v1";class cM{constructor(){this.version="0.2",this.platform=Fp,this.audio=new lM,this.last=performance.now(),this.saveAt=0,this.queue=[],this.dayCheck=0,this.spaceCheck=0}async boot(){await this.platform.init(),this.platform.loadingStart();const e=this.platform.load(Zr);let t;try{t=e?zp(JSON.parse(e)):Kl()}catch(c){console.warn("save unreadable, starting fresh",c),t=Kl()}this.s=t;const n=Date.now()-(t.last||Date.now());Ia(t,Date.now());const s=hn.filter(c=>c.kind==="built").length;hn.length=0,qc(t),Za(t);const a=ze(t,"bay").map(c=>Math.floor(t.bay[c.id]||0)).filter(c=>c>=1),r={credits:a.reduce((c,d)=>c+d,0),bays:a.length,ready:Object.keys(t.ready).length,cores:t.cores.filter(c=>c.state==="ready").length,built:s};this.world=new $_(vt("#gl"),t.settings.quality),this.studio=new H_(this.world.renderer),this.ui=new oM(this),this.audio.setVolume(t.settings.sfx),this.audio.mvol=t.settings.music,this.platform.onMute=c=>this.audio.setMuted(c),this.platform.muted()&&this.audio.setMuted(!0),this.world.onTap=c=>this.tapped(c),this.world.onGhostMove=()=>this.validatePlacing(),this.world.sync(t);const o=ze(t,"command")[0];if(o){const c=this.world.centerOf(o);this.world.cam.x=this.world.cam.tx=c.x-1,this.world.cam.z=this.world.cam.tz=c.z+1}document.addEventListener("pointerdown",()=>{this.audio.unlock(),this.audio.setMusic(this.s.settings.music)},{once:!0}),document.addEventListener("visibilitychange",()=>{document.hidden?this.save():Ia(this.s,Date.now())}),window.addEventListener("pagehide",()=>this.save()),requestAnimationFrame(c=>this.loop(c)),this.platform.loadingStop();const l=vt("#load");l.style.opacity="0",setTimeout(()=>l.remove(),500),this.platform.gameplayStart(),e&&n>10*6e4&&setTimeout(()=>this.enqueue(()=>this.ui.daily.offlineReport(n,r)),600),e||setTimeout(()=>this.ui.modal(`<div class="ox sub" style="letter-spacing:.2em">WELCOME, COMMANDER</div><h1>${re(t.name)}</h1><p class="desc">An asteroid in low Earth orbit, a Command Center, a fabricator and one small, cheerful robot named Helio. Everything else is up to you.</p><p class="desc">Your bots earn credits in their bays. Tap a bay to collect, print Power Cells, feed your crew and grow the colony.</p><button class="btn gold" data-a="closeModal" style="min-width:180px">Let's go!</button>`,!0),400),window.__app=this,window.__G=um,window.__daily=v_}loop(e){const t=Math.min(.05,(e-this.last)/1e3);this.last=e;const n=Date.now();if(Ia(this.s,n),qc(this.s,n),n>this.spaceCheck){this.spaceCheck=n+1e3;for(const s of U_(this.s,n))this.changed(),this.enqueue(()=>this.ui.space.reveal(s))}if(n>this.dayCheck){this.dayCheck=n+5e3,Za(this.s,n),this.placeDrop(),mp(this.s,n);const s=T_(this.s,n);s&&s.kind==="warn"&&(this.audio.play("deny"),this.ui.toast("⚠ A Kr'thul raid is coming: defend your colony!","bad"),this.platform.notify("raid",Date.now()+6e4,"Swarm raid incoming!","The Kr'thul arrive in 2 hours. Defend your colony!")),s&&s.kind==="hit"&&this.enqueue(()=>this.ui.modal(`<div class="ox sub" style="letter-spacing:.2em;color:#ff6b7a">RAID</div><div class="big">🔥</div><h1>The Swarm raided the colony</h1><p class="desc">Nobody stood in their way. They carried off ${se(s.stolen)} credits from your bays.</p><p class="sub">Next time, tap the red Swarm warning at the top and defend with your Arena team.</p><button class="btn gold" data-a="closeModal">We'll be ready</button>`));const a=vp(this.s,n);a&&this.enqueue(()=>this.ui.modal(`<div class="ox sub" style="letter-spacing:.2em">ARENA SEASON ENDED</div><div class="big">🏆</div><h1>${Qi[a.league][0]}</h1><p class="desc">Your best league this season. Here are your rewards:</p><div class="rewards">${Object.entries(a.reward).map(([r,o])=>`<span class="cost">${r==="dm"?"◆":r==="cells"?"⚡":"C"} ${se(o)}</span>`).join(" ")}</div><button class="btn gold" data-a="closeModal">Collect</button>`,!0))}this.drain(),this.world.frame(t,this.s),this.ui.frame(),n>this.saveAt&&(this.saveAt=n+1e4,this.save()),requestAnimationFrame(s=>this.loop(s))}drain(){for(;hn.length;){const e=hn.shift();if(e.kind==="levelup"){this.audio.play("levelup"),this.platform.happytime();const t=e.lvl%5===0?as(this.s,e.lvl%10===0?"advanced":"standard",e.lvl*7919+(this.s.created>>>0)):null;this.enqueue(()=>this.ui.levelUp(e.lvl,e.reward,t)),this.ui.renderHud()}else if(e.kind==="built"){this.audio.play("done"),this.world.topOf(e.item),this.changed();const t=Rt(this.s,e.item);if(t){const n=this.world.topOf(t.id);n&&this.world.burst(n,"#ffd36a",30),this.ui.toast(`${t.t==="bay"?"Bay":Qe[t.t].name} ${e.first?"is ready":`reached level ${e.lvl}`}!`,"good")}}else if(e.kind==="crafted")this.changed();else if(e.kind==="discover")this.ui.toast(`New species in the Botdex: +${e.dm} Dark Matter`,"gold");else if(e.kind==="fused")this.audio.play("done"),this.changed(),this.ui.toast(`Fusion complete: a ${We[Q[e.sp].rarity].name} core is in the Assembly Bay`,"gold");else if(e.kind==="booted")this.audio.play("claim"),this.changed(),this.ui.toast(`A ${We[Q[e.sp].rarity].name} core has booted: activate it in the Assembly Bay`,"good");else if(e.kind==="core")this.changed();else if(e.kind==="launch"){const t=Dd(this.s);this.changed(),t&&(this.world.launchFx(t.id,Ki(t.lvl)),this.audio.play("launch"))}else if(e.kind==="expBack")this.audio.play("levelup"),this.changed();else if(e.kind==="land")this.changed();else if(e.kind==="dug"){this.audio.play("done"),this.changed();const t=this.world.topOf(e.item);t&&this.world.burst(t,"#c49bff",24),this.ui.toast("Crystals dug up: tap the mine to collect","good")}else e.kind==="evolved"&&(this.platform.happytime(),this.changed())}this.queue.length&&vt("#modal").classList.contains("hidden")&&this.queue.shift()()}enqueue(e){this.queue.push(e)}placeDrop(){const e=pt(this.s);if(e.drops<=0){e.dropAt&&(e.dropAt=null,this.world.sync(this.s));return}if(e.dropAt&&ps(this.s,e.dropAt[0],e.dropAt[1],1,1)){this.world.podTop()||this.world.sync(this.s);return}const t=ze(this.s,"command")[0],n=t?t.x+2:15,s=t?t.z+2:15;let a=null,r=1e9;for(let o=0;o<30;o++)for(let l=0;l<30;l++){if(!ps(this.s,o,l,1,1))continue;const c=Math.abs(Math.hypot(o-n,l-s)-4.5);c<r&&(r=c,a=[o,l])}e.dropAt=a,this.world.sync(this.s)}changed(){this.world.sync(this.s),this.ui.renderObjIfChanged(),this.saveAt=Math.min(this.saveAt,Date.now()+1500)}save(){try{this.platform.save(Zr,JSON.stringify(this.s))}catch{}this.notifications()}notifications(){if(this.platform.name!=="mobile")return;const e=this.s,t=Date.now();let n=1/0;for(const o of ze(e,"bay")){const l=zo(e,o.id);l>0&&(n=Math.min(n,t+(Yi(o,e)-(e.bay[o.id]||0))/l*1e3))}isFinite(n)&&this.platform.notify("bays",n,"Your bays are full","Your crew has filled their bays with credits. Come and collect!");const s=e.jobs.filter(o=>o.kind==="craft").map(o=>o.end).sort()[0];s&&this.platform.notify("fab",s,"Power Cells ready","Your Fabricator has finished printing.");const a=pt(e);this.platform.notify("drop",a.drops?t+36e5:a.drop,"A supply drop has landed","Open it before the next one arrives.");const r=new Date;r.setDate(r.getDate()+1),r.setHours(19,0,0,0),this.platform.notify("daily",r.getTime(),"Your daily reward is waiting",`Day ${a.day+1} of your calendar is ready. Keep the streak going!`)}tapped(e){this.audio.unlock();const t=this.s;if(e.drop){const n=this.world.podTop();this.ui.daily.act("drop",document.body),n&&this.world.burst(n,"#7cf29a",40),this.placeDrop();return}if(e.bot){this.ui.selectBot(e.bot),this.audio.play("tap");return}if(e.item){const n=Rt(t,e.item);if(!n)return;if(n.t==="bay"&&(t.bay[n.id]||0)>=1&&!At(t,n.id,"build")){this.collect(n),this.ui.sel!==n.id&&this.ui.select(n.id);return}if(n.t==="fab"&&t.ready[n.id]){this.harvest(n),this.ui.select(n.id);return}if(n.t==="mine"&&Zt(t).ready[n.id]){const s=Uu(t,n);if(s){this.audio.play("crystal");const a=this.world.topOf(n.id);if(a){this.world.burst(a,Kt[s.color].color,26);const r=this.world.project(a);this.ui.popText(r.x,r.y-10,`+${s.n} ${Kt[s.color].name}`,Kt[s.color].color)}this.changed()}this.ui.sel!==n.id?this.ui.select(n.id):this.ui.renderPanel();return}if(n.t==="relicbay"&&(t.bay[n.id]||0)>=1){this.collect(n),this.ui.sel!==n.id&&this.ui.select(n.id);return}this.ui.select(this.ui.sel===n.id?null:n.id),this.audio.play("tap");return}if(e.plot){this.askPlot(e.plot);return}this.ui.select(null)}collect(e){const t=rd(this.s,e);if(!t)return;this.audio.play("collect",t);const n=e.t==="relicbay",s=n?"#c49bff":"#ffd36a",a=this.world.topOf(e.id);if(a){this.world.burst(a,s,18+Math.min(30,Math.floor(Math.log10(t)*6)));const r=this.world.project(a);this.ui.popText(r.x,r.y-10,`+${se(t)}${n?" ✦":""}`,s),this.ui.flyTo(n?"iridium":"credits",r.x,r.y,Math.min(9,3+Math.floor(Math.log10(t)*2)))}this.changed(),this.ui.renderPanel()}harvest(e){const t=od(this.s,e);if(!t)return;this.audio.play("harvest");const n=this.world.topOf(e.id);if(n){this.world.burst(n,"#9dff5a",26);const s=this.world.project(n);this.ui.popText(s.x,s.y-10,`+${se(t)} ⚡`,"#9dff5a"),this.ui.flyTo("cells",s.x,s.y,6)}this.changed(),this.ui.renderPanel()}askPlot(e){const t=this.s,n=ld(t,e),s=Ho(t),a=Go(t);this.ui.modal(`<div class="ox sub" style="letter-spacing:.2em">EXPAND THE ISLAND</div><h1>New land</h1><p class="desc">Tow in another 6×6 slab of asteroid and bolt it to your island: room for more bays, fabricators and decorations.</p><div class="rewards"><span class="cost ${t.res.credits<s?"short":""}"><span class="ic cr">C</span>${se(s)}</span></div>${n.ok?"":`<p class="why">${re(n.why||"")}</p>`}<div class="row" style="justify-content:center"><button class="btn" data-a="closeModal">Not now</button><button class="btn gold" data-a="buyPlot" data-k="${e}" ${n.ok?"":"disabled"}>Expand</button></div>${t.lvl<a?`<p class="sub">Reach Commander level ${a} to expand.</p>`:""}`)}startPlacing(e){const t=this.s;if(!e.move){const[n,s]=gn({t:e.t,r:e.r}),a=Math.round(this.world.cam.tx+15-n/2),r=Math.round(this.world.cam.tz+15-s/2);let o=null,l=1e9;for(let c=0;c<30;c++)for(let d=0;d<30;d++)if(ps(t,c,d,n,s)){const h=(c-a)**2+(d-r)**2;h<l&&(l=h,o=[c,d])}if(!o){this.ui.deny("No free space: expand the island or move things around");return}[e.x,e.z]=o}this.world.startGhost(e),this.world.sync(t),this.validatePlacing(),this.ui.select(null),this.audio.play("tap")}validatePlacing(){const e=this.world.ghost;if(!e)return;const[t,n]=gn({t:e.t,r:e.r});this.world.setGhostOk(ps(this.s,e.x,e.z,t,n,e.move)),this.ui.renderPlace()}confirmPlacing(){const e=this.world.ghost;if(!e||!e.ok)return;const t=this.s;if(e.move){const a=Rt(t,e.move);a&&Yu(t,a,e.x,e.z,e.r)&&(this.audio.play("place"),this.endPlacing(),this.changed(),this.ui.select(a.id));return}const n=Gu(t,e.t,e.x,e.z,e.r,e.el);if(!n.ok){this.ui.deny(n.why);return}this.audio.play(Qe[e.t].cat==="decor"?"place":"build"),this.changed();const s=n.item?this.world.topOf(n.item.id):null;if(s&&this.world.burst(s,"#6ee7ff",16),Qe[e.t].cat==="decor"&&ei(t,e.t).ok){this.validatePlacing(),this.ui.renderPlace();return}this.endPlacing(),n.item&&Qe[e.t].cat!=="decor"&&this.ui.select(n.item.id)}endPlacing(){this.world.endGhost(),this.world.sync(this.s),this.ui.renderPlace()}travel(e,t=!1){const n=this.s;if(!t&&!of(n,e))return;this.ui.select(null),this.audio.play("whoosh");const s=document.createElement("div");s.className="warp",document.body.appendChild(s),setTimeout(()=>{this.world.sync(n);const a=nd(n,n.at==="home"?"command":"hub")[0];if(a){const r=this.world.centerOf(a);this.world.cam.x=this.world.cam.tx=r.x-1,this.world.cam.z=this.world.cam.tz=r.z+1}this.ui.renderHud(),this.placeDrop()},250),setTimeout(()=>s.remove(),900),t&&setTimeout(()=>this.ui.modal(`<div class="ox sub" style="letter-spacing:.2em">NEW ISLAND</div><h1>${re(Bt[e].name)}</h1><p class="desc">${re(Bt[e].blurb)}</p><p class="desc" style="color:#7cf29a">★ ${re(Bt[e].perk||"")}</p><p class="sub">Build bays and fabricators here: bots of any element can live on any island. Use the island button at the top to travel.</p><button class="btn gold" data-a="closeModal">Let's build</button>`,!0),700),this.changed()}setSetting(e,t){this.s.settings[e]=t,e==="sfx"&&this.audio.setVolume(t),e==="music"&&this.audio.setMusic(t),e==="quality"&&(this.save(),this.ui.toast("Graphics change applies after a reload","gold")),this.save()}reset(){this.platform.save(Zr,"");try{localStorage.removeItem(Zr)}catch{}location.reload()}}new cM().boot().catch(i=>{console.error(i);const e=document.getElementById("load");e&&(e.innerHTML='<div style="text-align:center;padding:20px"><div class="logo">STARWARD</div><p>Your device could not start WebGL. Try another browser.</p></div>')});
