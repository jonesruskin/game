(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const s of document.querySelectorAll('link[rel="modulepreload"]'))n(s);new MutationObserver(s=>{for(const r of s)if(r.type==="childList")for(const a of r.addedNodes)a.tagName==="LINK"&&a.rel==="modulepreload"&&n(a)}).observe(document,{childList:!0,subtree:!0});function e(s){const r={};return s.integrity&&(r.integrity=s.integrity),s.referrerPolicy&&(r.referrerPolicy=s.referrerPolicy),s.crossOrigin==="use-credentials"?r.credentials="include":s.crossOrigin==="anonymous"?r.credentials="omit":r.credentials="same-origin",r}function n(s){if(s.ep)return;s.ep=!0;const r=e(s);fetch(s.href,r)}})();const Gc={save(i,t){try{localStorage.setItem(i,t)}catch{}},load(i){try{return localStorage.getItem(i)}catch{return null}}};let bn=null,Rr=!1;const ai=()=>!!bn,ef={name:"crazygames",adsAvailable:!1,onMute:null,async init(){const i=window.CrazyGames&&window.CrazyGames.SDK;if(i)try{if(await i.init(),i.environment&&i.environment!=="disabled"){bn=i,this.adsAvailable=!0;try{i.game.addSettingsChangeListener(t=>this.onMute&&this.onMute(!!(t&&t.muteAudio)))}catch{}}}catch(t){console.warn("CrazyGames SDK init failed; running standalone",t),bn=null}},loadingStart(){try{ai()&&bn.game.loadingStart()}catch{}},loadingStop(){try{ai()&&bn.game.loadingStop()}catch{}},gameplayStart(){if(!Rr){Rr=!0;try{ai()&&bn.game.gameplayStart()}catch{}}},gameplayStop(){if(Rr){Rr=!1;try{ai()&&bn.game.gameplayStop()}catch{}}},happytime(){try{ai()&&bn.game.happytime()}catch{}},midgame(i){return Vc("midgame",i)},rewarded(i){return Vc("rewarded",i)},save(i,t){Gc.save(i,t);try{ai()&&bn.data.setItem(i,t)}catch{}},load(i){let t=null;try{ai()&&(t=bn.data.getItem(i))}catch{t=null}return t||Gc.load(i)},muted(){try{return ai()&&!!bn.game.settings.muteAudio}catch{return!1}},notify(){},cancelNotify(){}};function Vc(i,t){return new Promise(e=>{if(!ai())return e(!1);try{bn.ad.requestAd(i,{adStarted:()=>t&&t(),adFinished:()=>e(!0),adError:()=>e(!1)})}catch{e(!1)}})}const Ci=(i,t=0,e=1)=>i<t?t:i>e?e:i;function yt(i){if(!isFinite(i))return"∞";const t=Math.abs(i);if(t<1e3)return String(Math.floor(i));const e=["K","M","B","T","Qa","Qi"];let n=-1,s=t;for(;s>=1e3&&n<e.length-1;)s/=1e3,n++;return(i<0?"-":"")+(s>=100?Math.floor(s):s>=10?s.toFixed(1).replace(/\.0$/,""):s.toFixed(2).replace(/\.?0+$/,""))+e[n]}function tn(i){if(i=Math.max(0,Math.ceil(i)),i<60)return i+"s";const t=Math.floor(i/86400),e=Math.floor(i%86400/3600),n=Math.floor(i%3600/60),s=i%60;return t?`${t}d ${e}h`:e?`${e}h ${n}m`:s&&n<10?`${n}m ${s}s`:`${n}m`}const Ut=i=>String(i).replace(/[&<>"']/g,t=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[t]);function Nn(i){let t=i>>>0;return()=>{t=t+1831565813|0;let e=Math.imul(t^t>>>15,1|t);return e=e+Math.imul(e^e>>>7,61|e)^e,((e^e>>>14)>>>0)/4294967296}}function Ns(i){let t=2166136261;for(let e=0;e<i.length;e++)t^=i.charCodeAt(e),t=Math.imul(t,16777619);return t>>>0}let nf=0;const pn=(i="x")=>i+Date.now().toString(36)+(nf++).toString(36)+Math.floor(Math.random()*1296).toString(36),ye=(i,t=document)=>t.querySelector(i),as=(i,t=document)=>Array.from(t.querySelectorAll(i)),ge=i=>{if(i<100)return Math.round(i);const t=Math.pow(10,Math.floor(Math.log10(i))-1);return Math.round(i/t)*t},sf=100,Bo=i=>Math.round(40*Math.pow(i,1.85)),rf=i=>({dm:3+Math.floor(i/5),credits:100*i}),wa=[{id:"a1",text:"Tap the Solar Bay to collect the credits Helio earned",kind:"collect",n:1,reward:{credits:150},hint:"bay"},{id:"a2",text:"Start a recipe at the Fabricator",kind:"craft",n:1,reward:{cells:20},hint:"fab"},{id:"a3",text:"Harvest Power Cells from the Fabricator",kind:"harvest",n:1,reward:{credits:100},hint:"fab"},{id:"a4",text:"Feed Helio until it reaches level 2",kind:"botLevel",n:2,reward:{cells:40,dm:5},hint:"bay"},{id:"a5",text:"Recruit Ember from the Shop (Bots tab)",kind:"ownSpecies",t:"ember",reward:{credits:200},hint:"shop"},{id:"a6",text:"Build a Plasma Bay so Ember has a home",kind:"bayEl",t:"plasma",reward:{credits:250},hint:"shop"},{id:"a7",text:"Upgrade the Command Center to level 2",kind:"cc",n:2,reward:{dm:10,credits:300},hint:"command"},{id:"a8",text:"Place a decoration (Shop → Decor)",kind:"decor",n:1,reward:{credits:150}},{id:"a9",text:"Raise any bot to level 4",kind:"botLevel",n:4,reward:{cells:150,dm:10}},{id:"a10",text:"Upgrade a Bay to level 2 (more credit storage)",kind:"bayLevel",n:2,reward:{credits:500}},{id:"a11",text:"Expand the island: buy a new plot of land",kind:"land",n:1,reward:{dm:15}},{id:"a12",text:"Run 4 bots",kind:"bots",n:4,reward:{credits:800}},{id:"a13",text:"Reach Commander level 6",kind:"level",n:6,reward:{dm:20}},{id:"a14",text:"Upgrade the Command Center to level 4",kind:"cc",n:4,reward:{credits:2500,dm:15}},{id:"b1",text:"Build the Assembly Bay (Shop → Buildings)",kind:"build",t:"assembly",reward:{credits:1e3,dm:10}},{id:"b2",text:"Post a bot as a helper at the Fabricator (tap a bot)",kind:"helper",reward:{cells:300}},{id:"b3",text:"Build the Fusion Lab",kind:"build",t:"fusion",reward:{credits:1500,dm:15}},{id:"b4",text:"Fuse two level-4 bots in the Fusion Lab",kind:"fusions",n:1,reward:{cells:400,dm:10}},{id:"b5",text:"Boot the new core in the Assembly Bay and activate it",kind:"boots",n:1,reward:{credits:1500}},{id:"a15",text:"Recruit an Advanced hybrid bot",kind:"rarity",t:"advanced",reward:{dm:30}},{id:"b6",text:"Discover 12 species in the Botdex",kind:"dex",n:12,reward:{dm:25}},{id:"b7",text:"Upgrade the Command Center to level 6",kind:"cc",n:6,reward:{credits:8e3,dm:20}},{id:"b8",text:"Fuse an Elite bot (three elements)",kind:"rarity",t:"elite",reward:{dm:40}},{id:"b9",text:"Discover 25 species",kind:"dex",n:25,reward:{dm:40}},{id:"b10",text:"Fuse an Epic bot",kind:"rarity",t:"epic",reward:{dm:60}},{id:"c1",text:"Build the Arena (Shop → Buildings)",kind:"build",t:"arena",reward:{credits:3e3,dm:15}},{id:"c2",text:"Win your first Arena battle",kind:"arenaWins",n:1,reward:{cells:500,dm:15}},{id:"c3",text:"Reach the Silver league",kind:"trophies",n:350,reward:{dm:30}},{id:"b11",text:"Reach Commander level 20",kind:"level",n:20,reward:{dm:50}},{id:"c4",text:"Reach the Gold league",kind:"trophies",n:850,reward:{dm:60}}],yh=1;function ko(i=Date.now()){const t=(a,o,l,c=1,d)=>({id:pn("i"),t:a,x:o,z:l,r:0,lvl:c,...d?{el:d}:{}}),e=t("command",13,13),n=t("bay",8,9,1,"solar"),s=t("fab",19,9);return{v:yh,created:i,last:i,name:"New Haven",res:{credits:600,cells:30,dm:25},xp:0,lvl:1,isl:{plots:["1,1","2,1","3,1","1,2","2,2","3,2","1,3","2,3","3,3"],items:[e,n,s,t("tree",12,9),t("tree",17,18),t("rock",8,19),t("tree",9,18),t("path",14,17),t("path",15,17),t("path",14,18),t("path",15,18)]},bots:[{id:pn("b"),sp:"helio",lvl:1,fed:0,bay:n.id,born:i}],jobs:[],cores:[],dex:{helio:i},bay:{[n.id]:120},ready:{},obj:{i:0,claimed:{}},stats:{},settings:{sfx:.8,music:.45,quality:"auto"},paint:{primary:"#e9eef5",accent:"#22c7e8"},banner:{bg:"#1b6fd8",fg:"#ffd23a",emblem:"star"},builders:2,landBought:0,tut:0}}function af(i){const t=ko(i.created||Date.now()),e=i;for(const s in t)e[s]===void 0&&(e[s]=t[s]);for(const s in t.settings)e.settings[s]===void 0&&(e.settings[s]=t.settings[s]);for(const s of i.bots)i.dex[s.sp]||(i.dex[s.sp]=s.born||Date.now());const n=wa.findIndex(s=>!i.obj.claimed[s.id]);return i.obj.i=n<0?wa.length:n,i.v=yh,i}const $c=[3,20,60,180,600,1800,3600,2*3600,4*3600,8*3600,12*3600,16*3600,24*3600,36*3600,48*3600],os=(i,t=0)=>$c[Math.min($c.length-1,Math.max(0,i-1+t))],Gn=(i,t,e,n,s)=>({name:i,size:t,cat:"decor",max:1,unlock:n,desc:s,buildCost:()=>e,upCost:()=>0,time:()=>0}),oe={command:{name:"Command Center",size:[4,4],cat:"core",max:15,unique:!0,unlock:1,desc:"The heart of your colony. Its level sets how far every other building can grow, and how many Bays and Fabricators you can run.",buildCost:()=>0,upCost:i=>ge(400*Math.pow(2.05,i-1)),time:i=>os(i,0)},bay:{name:"Bot Bay",size:[3,3],cat:"bay",max:10,unlock:1,desc:"Home and charging dock for bots of its element. Bots earn credits here; the bay holds them until you collect.",buildCost:i=>ge(150*Math.pow(1.6,i)),upCost:i=>ge(250*Math.pow(1.9,i-1)),time:i=>os(i,-1)},fab:{name:"Fabricator",size:[3,3],cat:"production",max:10,unlock:1,desc:"Prints Power Cells for your bots. Pick a recipe that matches when you will be back.",buildCost:i=>ge(300*Math.pow(2.4,i)),upCost:i=>ge(400*Math.pow(1.95,i-1)),time:i=>os(i,-1)},assembly:{name:"Assembly Bay",size:[3,3],cat:"production",max:10,unique:!0,unlock:4,desc:"Boots new bot cores: from the shop, from the Fusion Lab and from events. More levels boot more cores at once, faster.",buildCost:()=>1500,upCost:i=>ge(1800*Math.pow(1.9,i-1)),time:i=>os(i,0)},fusion:{name:"Fusion Lab",size:[4,3],cat:"production",max:10,unique:!0,unlock:5,desc:"Fuses two bots of level 4 or more into a new core. The child may take after either parent, or be a hybrid of both: sometimes a rarer one.",buildCost:()=>3e3,upCost:i=>ge(3500*Math.pow(1.9,i-1)),time:i=>os(i,1)},arena:{name:"Arena",size:[4,4],cat:"production",max:10,unique:!0,unlock:6,desc:"Your gateway to the holo-arena in orbit: pick three bots and battle rival colonies for trophies, rewards and league glory.",buildCost:()=>5e3,upCost:i=>ge(5e3*Math.pow(1.9,i-1)),time:i=>os(i,1)},tree:Gn("Holo Tree",[1,1],40,1,"A glowing tree grown from engineered moss and fibre optics."),rock:Gn("Moon Rock",[1,1],30,1,"A souvenir boulder. Every colony keeps one."),path:Gn("Walkway",[1,1],10,1,"A paved tile for paths and plazas."),lamp:Gn("Lumen Post",[1,1],60,2,"A tall lamp with a soft, warm glow."),flag:Gn("Colony Flag",[1,1],100,3,"Flies your colony colours."),crystal:Gn("Crystal Cluster",[1,1],250,4,"Grown in microgravity, sold by the kilo."),fountain:Gn("Gravity Fountain",[2,2],600,5,"Water arcing in a gentle artificial gravity well."),dish:Gn("Dish Array",[2,2],900,7,"Listening to the stars, mostly for show."),statue:Gn("Bot Statue",[2,2],1500,9,"A monument to the bots who built the colony."),arch:{...Gn("Starlight Arch",[2,1],0,1,"A ring of light that only loyal commanders own. Earned on day 21 of the login calendar."),exclusive:"calendar"}},Wc=["bay","fab","assembly","fusion","arena","tree","rock","path","lamp","flag","crystal","fountain","dish","statue"],Ea=i=>2+i,ar=i=>1+Math.floor(i/3),Ts=[0,0,2,3,5,7,9,12,15,18,21,25,29,33,38,44],Rs=i=>2+Math.floor((i-1)/3),bh=i=>ge(400*Math.pow(2,i-1)),oi={command:["alloy","geo","kinetic"],fab:["solar","volt","plasma"],fusion:["neural","chrono","photon"],assembly:["alloy","neural","volt"]},Xc={command:"construction speed",fab:"Power Cells per recipe",fusion:"fusion speed",assembly:"boot speed"},Us=i=>1+(i>=5?1:0)+(i>=9?1:0),fr=i=>1+Math.floor((Math.max(1,i)-1)/3),Fs=[{name:"Quick Charge",sec:30,cells:12,cost:20,xp:1,lvl:1},{name:"Standard Cells",sec:300,cells:60,cost:80,xp:3,lvl:1},{name:"Battery Pack",sec:1800,cells:240,cost:300,xp:8,lvl:2},{name:"Power Core",sec:7200,cells:700,cost:900,xp:20,lvl:3},{name:"Fusion Rod",sec:8*3600,cells:2200,cost:2600,xp:50,lvl:5},{name:"Star Battery",sec:24*3600,cells:6e3,cost:6500,xp:120,lvl:7}],Mh=(i,t)=>Math.round(i.cells*(1+.1*(t-1))),he=6,zo=5,kl=i=>ge(800*Math.pow(2,i)),zl=i=>3+i*2,ct=(i,t,e,n,s,r,a)=>({name:i,el:t,rarity:e,chassis:n,desc:s,...r?{price:r,unlock:a}:{}}),gt={helio:ct("Helio",["solar"],"standard","orb","A floating solar collector with a sunny disposition. Your first crewmate.",300,1),ember:ct("Ember",["plasma"],"standard","rover","Welds hull plates with a plasma torch it is very proud of.",350,1),tidepool:ct("Tidepool",["hydro"],"standard","crawler","Recycles every drop of water on the island. Twice.",400,2),frostbyte:ct("Frostbyte",["cryo"],"standard","walker","Keeps the servers cold and the jokes colder.",450,3),digger:ct("Digger",["geo"],"standard","rover","Has never met a rock it could not move.",500,3),sprout:ct("Sprout",["bio"],"standard","android","Talks to the greenhouse plants. They grow faster.",550,4),sparky:ct("Sparky",["volt"],"standard","drone","A hyperactive power drone. Do not let it near the coffee.",600,4),bolt:ct("Bolt",["alloy"],"standard","mech","Lifts girders, opens jars, never complains.",700,5),zephyr:ct("Zephyr",["aero"],"standard","drone","Rides the ventilation currents for fun.",800,5),lumen:ct("Lumen",["photon"],"standard","drone","A flying floodlight that loves an audience.",900,6),brawler:ct("Brawler",["kinetic"],"standard","mech","Built for demolition, adores being useful.",1e3,6),anchor:ct("Anchor",["gravity"],"standard","walker","Heavier than it looks, calmer than it sounds.",1200,7),umbra:ct("Umbra",["void"],"standard","orb","Absorbs stray light. Prefers the night shift.",1400,7),tick:ct("Tick",["chrono"],"standard","android","Always exactly on time, sometimes slightly early.",1600,8),cortex:ct("Cortex",["neural"],"standard","orb","A small AI that asks a lot of questions.",1800,8),solarflare:ct("Solarflare",["solar","plasma"],"advanced","drone","Catches sunlight, throws it back as fire.",2600,9),thunderhead:ct("Thunderhead",["volt","hydro"],"advanced","orb","A storm in a sphere. Crackles when it is happy.",3200,10),magmaw:ct("Magmaw",["geo","plasma"],"advanced","crawler","Eats rock, breathes lava, purrs.",3800,11),greenhouse:ct("Greenhouse",["bio","solar"],"advanced","android","A walking garden that photosynthesises on the job.",4400,12),glacier:ct("Glacier",["cryo","alloy"],"advanced","mech","Ice-armoured and unhurried. Nothing gets past.",5e3,13),floe:ct("Floe",["hydro","cryo"],"advanced","crawler","Skates across frozen reservoirs, clearing them.",5600,14),quarry:ct("Quarry",["geo","alloy"],"advanced","mech","Turns asteroids into neatly stacked bricks.",6200,15),mangrove:ct("Mangrove",["bio","hydro"],"advanced","walker","Grows roots into the water pipes. On purpose.",6900,16),dynamo:ct("Dynamo",["volt","alloy"],"advanced","rover","A rolling generator with a lot of torque.",7600,17),eclipse:ct("Eclipse",["void","photon"],"advanced","orb","Half light, half dark, entirely mysterious.",8400,18),rampart:ct("Rampart",["kinetic","alloy"],"advanced","mech","A wall that walks. Very reassuring.",9200,19),stormkite:ct("Stormkite",["aero","volt"],"advanced","drone","Flies into lightning to recharge.",1e4,20),monolith:ct("Monolith",["gravity","geo"],"advanced","walker","Stands perfectly still for days. Then dances.",11e3,21),paradox:ct("Paradox",["chrono","neural"],"advanced","android","Remembers things that have not happened yet.",12e3,22),synapse:ct("Synapse",["neural","volt"],"advanced","orb","Thinks in lightning. Talks in puns.",13e3,23),blizzard:ct("Blizzard",["aero","cryo"],"advanced","drone","Brings its own weather everywhere it goes.",14e3,24),prism:ct("Prism",["photon","solar"],"advanced","orb","Splits starlight into every colour it knows.",15e3,25),undertow:ct("Undertow",["void","gravity"],"advanced","crawler","Pulls things in. Gently. Usually.",16e3,26),blastforge:ct("Blastforge",["plasma","kinetic"],"advanced","mech","Forges hull plates with controlled explosions.",17500,27),rootbound:ct("Rootbound",["bio","geo"],"advanced","walker","Plants a tree with every step.",19e3,28),rainmaker:ct("Rainmaker",["hydro","aero"],"advanced","drone","Seeds clouds over the greenhouses.",20500,29),sundial:ct("Sundial",["chrono","photon"],"advanced","android","Tells time by the shadows it casts.",22e3,30),mycelium:ct("Mycelium",["neural","bio"],"advanced","crawler","A network of thinking fungus in a shell.",24e3,31),orbiter:ct("Orbiter",["gravity","aero"],"advanced","orb","Has its own small moon. It is very attached.",26e3,32),permafrost:ct("Permafrost",["cryo","void"],"advanced","walker","Cold enough to freeze light.",28e3,33),arcjet:ct("Arcjet",["volt","plasma"],"advanced","rover","Rides a cushion of ionised air.",3e4,34),mirrorplate:ct("Mirrorplate",["alloy","photon"],"advanced","mech","Polished so well it reflects your mood.",32e3,35),striker:ct("Striker",["kinetic","aero"],"advanced","drone","Fast, precise, slightly showing off.",34e3,36),pendulum:ct("Pendulum",["chrono","gravity"],"advanced","walker","Swings between moments.",36e3,37),oracle:ct("Oracle",["neural","photon"],"advanced","orb","Answers questions before you ask them.",38e3,38),mudlark:ct("Mudlark",["geo","hydro"],"advanced","rover","Happiest up to its axles in wet regolith.",4e4,39),sunvolt:ct("Sunvolt",["solar","volt"],"advanced","rover","Charges in sunlight, discharges in enthusiasm.",42e3,40),phantom:ct("Phantom",["void","neural"],"advanced","android","Appears on cameras that are switched off.",45e3,41),thermocline:ct("Thermocline",["plasma","cryo"],"advanced","crawler","Hot on one side, frozen on the other.",48e3,42),corona:ct("Corona",["solar","plasma","photon"],"elite","orb","A miniature star on a leash."),tsunami:ct("Tsunami",["hydro","kinetic","aero"],"elite","crawler","Moves like a wave and hits like one too."),tectonic:ct("Tectonic",["geo","gravity","kinetic"],"elite","mech","Rearranges continents for practice."),verdant:ct("Verdant",["bio","solar","hydro"],"elite","android","Terraforms a garden wherever it stands."),tesla:ct("Tesla",["volt","alloy","neural"],"elite","android","An inventor bot with a coil for a heart."),borealis:ct("Borealis",["cryo","photon","aero"],"elite","drone","Paints the polar sky in green fire."),nightshade:ct("Nightshade",["void","bio","neural"],"elite","crawler","Beautiful, clever, best kept at arm's length."),chronoforge:ct("Chronoforge",["chrono","plasma","alloy"],"elite","mech","Forges parts it will need tomorrow."),gravwell:ct("Gravwell",["gravity","void","hydro"],"elite","orb","A floating whirlpool that hums."),overclock:ct("Overclock",["volt","chrono","kinetic"],"elite","rover","Runs every process twice as fast. Including naps."),dreadnought:ct("Dreadnought",["alloy","kinetic","gravity"],"elite","mech","Armour plate all the way down."),lumina:ct("Lumina",["photon","bio","neural"],"elite","android","A gardener that glows in the dark."),supernova:ct("Supernova",["solar","plasma","gravity","photon"],"epic","orb","Contains a star's last breath, politely."),leviathan:ct("Leviathan",["hydro","cryo","gravity","kinetic"],"epic","crawler","The deep-ocean bot of Europa legends."),titanforge:ct("Titanforge",["alloy","geo","plasma","kinetic"],"epic","mech","Builds space stations single-handed. It has four hands."),gaia:ct("Gaia",["bio","geo","hydro","solar"],"epic","android","Turns dead rock into living soil."),tempest:ct("Tempest",["aero","volt","hydro","cryo"],"epic","drone","A hurricane that follows instructions."),eventide:ct("Eventide",["void","chrono","photon"],"epic","orb","Lives in the moment between day and night."),hivemind:ct("Hivemind",["neural","bio","alloy","volt"],"epic","crawler","A thousand tiny minds in one shell."),starweaver:ct("Starweaver",["photon","gravity","aero"],"epic","drone","Spins light sails from starlight."),quasar:ct("Quasar",["volt","void","photon","gravity"],"epic","orb","Brighter than a galaxy, smaller than a fridge."),juggernaut:ct("Juggernaut",["kinetic","alloy","gravity","geo"],"epic","mech","Unstoppable. Literally: nobody has tried."),solaris:ct("Solaris Prime",["solar","photon","plasma","neural"],"legendary","android","The first AI to dream of the Sun, and then build one."),abyssal:ct("Abyssal",["void","hydro","gravity","cryo"],"legendary","crawler","From the dark oceans beneath Enceladus."),chronarch:ct("Chronarch",["chrono","neural","photon","void"],"legendary","android","Keeper of every second the colony has lived."),colossus:ct("Colossus",["alloy","kinetic","geo","gravity"],"legendary","mech","A walking fortress the size of a hab block."),seraph:ct("Seraph",["aero","photon","bio","solar"],"legendary","drone","Six wings of light, one gentle voice."),voltaic:ct("Voltaic Storm",["volt","aero","plasma","kinetic"],"legendary","orb","Lightning that learned to fly."),omega:ct("Omega Protocol",["neural","alloy","chrono","kinetic"],"prototype","mech","The last line of code anyone wrote by hand."),genesis:ct("Genesis Engine",["bio","solar","hydro","geo"],"prototype","android","Makes worlds. Small ones, for now."),horizon:ct("Event Horizon",["gravity","void","chrono","photon"],"prototype","orb","Nothing it looks at can look away."),architect:ct("The Architect",["neural","chrono","gravity","photon"],"singularity","orb","It designed itself. Then it designed the rest."),primemover:ct("Prime Mover",["kinetic","plasma","solar","gravity"],"singularity","mech","The engine at the start of everything.")},Xn=Object.keys(gt),Qt={standard:{name:"Standard",color:"#b9c3cf",earn:10,power:1,fuseChance:1,assembly:30},advanced:{name:"Advanced",color:"#5fdc7a",earn:15,power:1.2,fuseChance:.6,assembly:600},elite:{name:"Elite",color:"#4aa8ff",earn:22,power:1.45,fuseChance:.35,assembly:3600},epic:{name:"Epic",color:"#b06dff",earn:34,power:1.75,fuseChance:.18,assembly:4*3600},legendary:{name:"Legendary",color:"#ffa53a",earn:52,power:2.1,fuseChance:.08,assembly:12*3600},prototype:{name:"Prototype",color:"#ff4f6a",earn:80,power:2.6,fuseChance:.035,assembly:24*3600},singularity:{name:"Singularity",color:"#7af7ff",earn:125,power:3.2,fuseChance:.015,assembly:48*3600}},on=Object.keys(Qt),qn=i=>on.indexOf(gt[i].rarity),Sh=[2,4,8,15,30,60,120];function Hl(i,t,e=Date.now()){if(i.dex[t])return!1;i.dex[t]=e;const n=Sh[qn(t)];return i.res.dm+=n,Yn.push({kind:"discover",sp:t,dm:n}),!0}const Gl=i=>Object.keys(i.dex).filter(t=>gt[t]).length;function Vl(i){const t=gt[i.sp],e=Qt[t.rarity].power,n=1+.1*(t.el.length-1);return{hp:Math.round((120+32*(i.lvl-1))*e*n),atk:Math.round((20+5.5*(i.lvl-1))*e*n)}}const Pi=4;function wh(i,t){const e=gt[i.sp],n=gt[t.sp],s=new Set([...e.el,...n.el]),r=qn(i.sp),a=qn(t.sp),o=Math.min(r,a),l=Math.max(r,a),c=[];for(const h of Xn){const u=gt[h],f=on.indexOf(u.rarity),g=h===i.sp||h===t.sp;!g&&(!u.el.every(x=>s.has(x))||!u.el.some(x=>e.el.includes(x))||!u.el.some(x=>n.el.includes(x))||u.el.length<2||f<(o>=2?o:o-1)||f===3&&l<1||f===4&&o<2||f===5&&o<3||f===6&&o<4||f>l+2)||c.push({sp:h,w:Qt[u.rarity].fuseChance*(g?1.3:1)})}const d=c.reduce((h,u)=>h+u.w,0);return c.map(h=>({sp:h.sp,p:h.w/d})).sort((h,u)=>qn(u.sp)-qn(h.sp)||u.p-h.p)}const Ho=(i,t)=>{const e=qn(i.sp),n=qn(t.sp);return Math.round(120*(1+e)*(1+n)*Math.pow(1.7,Math.max(e,n)))};function Mr(i,t){const e=oi[t.t]||[];let n=0;for(const s of i.bots){if(s.post!==t.id)continue;const r=gt[s.sp],a=(.04+.006*s.lvl)*Math.sqrt(Qt[r.rarity].power)*(r.el.some(o=>e.includes(o))?1.5:1);n+=a}return Math.min(.6,n)}const Go=(i,t,e)=>Math.round(Qt[gt[e].rarity].assembly*(1-.05*(t.lvl-1))*(1-Mr(i,t)));function Eh(i,t,e,n){if(t.lvl<1||Fe(i,t.id,"build"))return{ok:!1,why:"The Fusion Lab is under construction"};if(Fe(i,t.id,"fuse"))return{ok:!1,why:"Already fusing"};const s=i.bots.find(o=>o.id===e),r=i.bots.find(o=>o.id===n);if(!s||!r)return{ok:!1,why:"Pick two bots"};if(s===r)return{ok:!1,why:"Pick two different bots"};if(s.lvl<Pi||r.lvl<Pi)return{ok:!1,why:`Both bots need level ${Pi}`};const a=Ho(s,r);return i.res.credits<a?{ok:!1,why:"Not enough credits",cost:a}:{ok:!0,cost:a}}function of(i,t,e,n,s=Date.now(),r=Math.random){const a=Eh(i,t,e,n);if(!a.ok)return a;const o=i.bots.find(f=>f.id===e),l=i.bots.find(f=>f.id===n);i.res.credits-=a.cost||0;const c=wh(o,l);let d=r(),h=c[0].sp;for(const f of c){if(d<f.p){h=f.sp;break}d-=f.p}const u=Go(i,t,h);return i.jobs.push({id:pn("j"),kind:"fuse",item:t.id,start:s,end:s+u*1e3,sp:h,parents:[e,n]}),i.stats.fusions=(i.stats.fusions||0)+1,Be(i,15+10*qn(h)),{...a,time:u,sp:h}}const lf=(i,t,e)=>Math.round(Qt[gt[e].rarity].assembly*.5*(1-.05*(t.lvl-1))*(1-Mr(i,t)));function $l(i,t,e,n=Date.now()){const s={id:pn("c"),sp:t,from:e,state:"waiting",at:n};return i.cores.push(s),Vo(i,n),Yn.push({kind:"core",core:s.id,sp:t}),s}function Vo(i,t=Date.now()){const e=Zt(i,"assembly")[0];if(!e||e.lvl<1||Fe(i,e.id,"build"))return;let n=i.jobs.filter(s=>s.kind==="boot").length;for(const s of i.cores){if(n>=fr(e.lvl))break;s.state==="waiting"&&(s.state="booting",i.jobs.push({id:pn("j"),kind:"boot",item:e.id,start:t,end:t+lf(i,e,s.sp)*1e3,core:s.id}),n++)}}function cf(i,t,e=Date.now()){const n=i.cores.find(a=>a.id===t);if(!n||n.state!=="ready")return{ok:!1,why:"Still booting"};const s=es(i,n.sp),r={id:pn("b"),sp:n.sp,lvl:1,fed:0,bay:s?s.id:null,born:e,...s?{}:{stored:!0}};return i.bots.push(r),i.cores=i.cores.filter(a=>a!==n),Hl(i,n.sp,e),i.stats.boots=(i.stats.boots||0)+1,Be(i,10+12*qn(n.sp)),Yn.push({kind:"newBot",bot:r.id}),{ok:!0,bot:r}}function es(i,t,e){const n=gt[t].el;return Zt(i,"bay").filter(s=>s.lvl>0&&s.el&&n.includes(s.el)&&s.id!==e&&pi(i,s.id).length<Rs(s.lvl)).sort((s,r)=>pi(i,s.id).length-pi(i,r.id).length)[0]}const Aa=(i,t)=>i.bots.filter(e=>e.post===t);function Ah(i,t,e){return oi[e.t]?e.lvl<1?{ok:!1,why:"Under construction"}:t.stored?{ok:!1,why:"Activate it from storage first"}:t.post===e.id?{ok:!1,why:"Already helping here"}:Aa(i,e.id).length>=Us(e.lvl)?{ok:!1,why:`All ${Us(e.lvl)} helper slots are taken`}:{ok:!0}:{ok:!1,why:"Bots cannot help here"}}function df(i,t,e){const n=Ah(i,t,e);return n.ok&&(t.post=e.id,i.stats.posts=(i.stats.posts||0)+1),n}function hf(i){delete i.post}function uf(i,t){t.bay=null,t.stored=!0,delete t.post}function ff(i,t){const e=es(i,t.sp);return e?(t.bay=e.id,delete t.stored,{ok:!0}):{ok:!1,why:`No room: build or upgrade a ${gt[t.sp].el.map(n=>n[0].toUpperCase()+n.slice(1)).join("/")} Bay`}}const Th=i=>Math.round((gt[i.sp].price||2e3*Math.pow(3,qn(i.sp)))*.25*(1+.1*(i.lvl-1)));function pf(i,t){if(i.bots.length<=1)return{ok:!1,why:"You need at least one bot"};i.bots=i.bots.filter(n=>n!==t);const e=Th(t);return i.res.credits+=e,{ok:!0,cost:e}}const mf=(i,t)=>i.cores.find(e=>e.id===t),Yn=[],Li=i=>{Yn.push(i)},gf=(i,t)=>Object.entries(t).every(([e,n])=>i.res[e]>=(n||0)),vf=(i,t)=>{for(const[e,n]of Object.entries(t))i.res[e]-=n||0},Qn=(i,t)=>{for(const[e,n]of Object.entries(t))e in i.res&&(i.res[e]+=n)},Zn=(i,t,e=1)=>{i.stats[t]=(i.stats[t]||0)+e};function Be(i,t){if(!(t<=0))for(i.xp+=t;i.lvl<sf&&i.xp>=Bo(i.lvl);){i.xp-=Bo(i.lvl),i.lvl++;const e=rf(i.lvl);Qn(i,e),Li({kind:"levelup",lvl:i.lvl,reward:e})}}const Zt=(i,t)=>i.isl.items.filter(e=>e.t===t),Me=(i,t)=>i.isl.items.find(e=>e.id===t),vi=i=>(Zt(i,"command")[0]||{lvl:1}).lvl,Qe=i=>{const[t,e]=oe[i.t].size;return i.r%2?[e,t]:[t,e]},Rh=(i,t)=>`${Math.floor(i/he)},${Math.floor(t/he)}`,Ch=(i,t,e)=>t>=0&&e>=0&&t<he*zo&&e<he*zo&&i.isl.plots.includes(Rh(t,e));function Xi(i,t,e,n,s,r){for(let a=t;a<t+n;a++)for(let o=e;o<e+s;o++)if(!Ch(i,a,o))return!1;for(const a of i.isl.items){if(a.id===r)continue;const[o,l]=Qe(a);if(t<a.x+o&&t+n>a.x&&e<a.z+l&&e+s>a.z)return!1}return!0}const Wa=i=>i.jobs.filter(t=>t.kind==="build").length,Fe=(i,t,e)=>i.jobs.find(n=>n.item===t&&(!e||n.kind===e));function Ti(i,t,e){const n=oe[t];if(!n)return{ok:!1,why:"Unknown"};if(n.exclusive){const l=i.stats["decor_"+t]||0;return Zt(i,t).length<l?{ok:!0,cost:0,time:0}:{ok:!1,why:l?"All placed":"Earned from the login calendar",cost:0}}if(i.lvl<n.unlock)return{ok:!1,why:`Commander level ${n.unlock}`,cost:n.buildCost(Zt(i,t).length)};const s=Zt(i,t).length,r=vi(i);if(n.unique&&s)return{ok:!1,why:"Already built"};if(t==="bay"&&s>=Ea(r))return{ok:!1,why:`Bay limit (${Ea(r)}): upgrade the Command Center`};if(t==="fab"&&s>=ar(r))return{ok:!1,why:`Fabricator limit (${ar(r)}): upgrade the Command Center`};const a=t==="bay"&&e&&!Zt(i,"bay").some(l=>l.el===e)?Math.round(n.buildCost(Math.max(0,s-1))*.7):n.buildCost(s),o=Math.round(n.time(1)*Nh(i));return o>0&&Wa(i)>=i.builders?{ok:!1,why:"All builder drones are busy",cost:a,time:o}:i.res.credits<a?{ok:!1,why:"Not enough credits",cost:a,time:o}:{ok:!0,cost:a,time:o}}function Ph(i,t,e,n,s,r,a=Date.now()){const o=Ti(i,t,r);if(!o.ok)return o;const l={id:pn("i"),t,x:e,z:n,r:s,lvl:o.time?0:1,...r?{el:r}:{}},[c,d]=Qe(l);return Xi(i,e,n,c,d)?(i.res.credits-=o.cost||0,i.isl.items.push(l),Zn(i,"built"),o.time?i.jobs.push({id:pn("j"),kind:"build",item:l.id,start:a,end:a+o.time*1e3,lvl:1}):(Be(i,Ih(o.cost||0)),oe[t].cat==="decor"&&Zn(i,"decor")),t==="bay"&&(i.bay[l.id]=0),{...o,item:l}):{ok:!1,why:"Something is in the way"}}const Lh=(i,t)=>t.t==="command"?oe.command.max:Math.min(oe[t.t].max,vi(i));function Wl(i,t){const e=oe[t.t];if(e.cat==="decor")return{ok:!1,why:"Decorations do not upgrade"};if(Fe(i,t.id,"build"))return{ok:!1,why:"Under construction"};if(t.lvl>=e.max)return{ok:!1,why:"Maximum level"};if(t.t!=="command"&&t.lvl>=vi(i))return{ok:!1,why:`Upgrade the Command Center to level ${t.lvl+1} first`};if(t.t==="command"&&i.lvl<Ts[t.lvl+1])return{ok:!1,why:`Commander level ${Ts[t.lvl+1]} needed`};if(t.t==="fab"&&Fe(i,t.id,"craft"))return{ok:!1,why:"Finish or harvest the recipe first"};const n=e.upCost(t.lvl),s=Math.round(e.time(t.lvl+1)*(t.t==="command"?1:Nh(i)));return Wa(i)>=i.builders?{ok:!1,why:"All builder drones are busy",cost:n,time:s}:i.res.credits<n?{ok:!1,why:"Not enough credits",cost:n,time:s}:{ok:!0,cost:n,time:s}}function Dh(i,t,e=Date.now()){const n=Wl(i,t);return n.ok&&(i.res.credits-=n.cost||0,Zn(i,"upgrades"),i.jobs.push({id:pn("j"),kind:"build",item:t.id,start:e,end:e+(n.time||0)*1e3,lvl:t.lvl+1})),n}const Ih=i=>Math.max(5,Math.round(i/15)),Nh=i=>{const t=Zt(i,"command")[0];return t?1-Mr(i,t):1};function Uh(i,t,e,n,s){const[r,a]=Qe({t:t.t,r:s});return Xi(i,e,n,r,a,t.id)?(t.x=e,t.z=n,t.r=s,!0):!1}function Fh(i,t){return oe[t.t].cat!=="decor"||oe[t.t].exclusive?!1:(i.isl.items=i.isl.items.filter(e=>e!==t),i.res.credits+=Math.floor(oe[t.t].buildCost(0)*.5),!0)}const qi=i=>i<=60?0:Math.ceil(1.1*Math.pow(i/60,.7));function Oh(i,t,e=Date.now()){const n=qi((t.end-e)/1e3);return i.res.dm<n?!1:(i.res.dm-=n,t.end=e,or(i,e),!0)}const li=i=>{const t=gt[i.sp];return Qt[t.rarity].earn*(1+.15*(t.el.length-1))*(1+.35*(i.lvl-1))},Xa=40,qa=i=>Math.round(4*Math.pow(1.33,i-1)),pi=(i,t)=>i.bots.filter(e=>e.bay===t),Ya=(i,t)=>pi(i,t).filter(e=>!e.post).reduce((e,n)=>e+li(n),0)/60,Ri=i=>bh(Math.max(1,i.lvl));function Xl(i,t){if(t.lvl>=Xa)return{ok:!1,why:"Maximum level"};const e=qa(t.lvl);if(i.res.cells<e)return{ok:!1,why:"Not enough Power Cells",cost:e};i.res.cells-=e,t.fed++,Zn(i,"feeds"),Be(i,1+Math.floor(t.lvl/4));let n=!1;return t.fed>=4&&(t.fed=0,t.lvl++,n=!0,Li({kind:"botLevel",bot:t.id,lvl:t.lvl})),{ok:!0,cost:e,lvlUp:n}}function ql(i,t){const e=gt[t];if(!e||!e.price)return{ok:!1,why:"Not for sale"};const n=i.bots.filter(r=>r.sp===t).length,s=Math.round(e.price*(1+.5*n));if(i.lvl<(e.unlock||1))return{ok:!1,why:`Commander level ${e.unlock}`,cost:s};if(e.rarity!=="standard"){const r=Zt(i,"assembly")[0];if(!r||r.lvl<1)return{ok:!1,why:"Build the Assembly Bay first: rarer bots boot there",cost:s}}else if(!es(i,t)){const r=e.el.map(o=>o[0].toUpperCase()+o.slice(1));return{ok:!1,why:Zt(i,"bay").some(o=>o.el&&e.el.includes(o.el))?`No room: upgrade or add a ${r.join("/")} Bay`:`Build a ${r.join(" or ")} Bay first`,cost:s}}return i.res.credits<s?{ok:!1,why:"Not enough credits",cost:s}:{ok:!0,cost:s}}function Bh(i,t,e=Date.now()){const n=ql(i,t);if(!n.ok)return n;if(i.res.credits-=n.cost||0,Zn(i,"recruits"),Be(i,10+Math.round((n.cost||0)/50)),gt[t].rarity!=="standard"){const a=$l(i,t,"shop",e);return{...n,core:a.id}}const s=es(i,t),r={id:pn("b"),sp:t,lvl:1,fed:0,bay:s.id,born:e};return i.bots.push(r),Hl(i,t,e),Li({kind:"newBot",bot:r.id}),{...n,bot:r}}function kh(i,t,e){const n=Me(i,e);return!n||!n.el||!gt[t.sp].el.includes(n.el)||t.bay===e||pi(i,e).length>=Rs(n.lvl)?!1:(t.bay=e,delete t.stored,!0)}function Yl(i,t){const e=Math.floor(i.bay[t.id]||0);if(e<=0)return 0;i.bay[t.id]-=e,i.res.credits+=e,Zn(i,"collects"),Zn(i,"collected",e);const n=(i.stats.xpFrac||0)+e/50,s=Math.floor(n);return i.stats.xpFrac=n-s,Be(i,s),e}const zh=i=>Fs.map((t,e)=>({...t,i:e,open:Math.max(1,i.lvl)>=t.lvl,out:Mh(t,Math.max(1,i.lvl))}));function Hh(i,t,e){const n=Fs[e];return n?t.lvl<1||Fe(i,t.id,"build")?{ok:!1,why:"Under construction"}:Fe(i,t.id,"craft")?{ok:!1,why:"Already printing"}:i.ready[t.id]?{ok:!1,why:"Harvest first"}:t.lvl<n.lvl?{ok:!1,why:`Fabricator level ${n.lvl}`}:i.res.credits<n.cost?{ok:!1,why:"Not enough credits",cost:n.cost}:{ok:!0,cost:n.cost,time:n.sec}:{ok:!1}}function Gh(i,t,e,n=Date.now()){const s=Hh(i,t,e);return s.ok&&(i.res.credits-=s.cost||0,Zn(i,"crafts"),i.jobs.push({id:pn("j"),kind:"craft",item:t.id,start:n,end:n+Fs[e].sec*1e3,recipe:e})),s}function Kl(i,t){const e=i.ready[t.id];return e?(delete i.ready[t.id],i.res.cells+=e.cells,Be(i,e.xp),Zn(i,"harvests"),e.cells):0}function Ka(i,t){if(i.isl.plots.includes(t))return"open";const[e,n]=t.split(",").map(Number);return[[1,0],[-1,0],[0,1],[0,-1]].some(([s,r])=>i.isl.plots.includes(`${e+s},${n+r}`))?"buyable":"far"}function Zl(i,t){if(Ka(i,t)!=="buyable")return{ok:!1,why:"Expand next to your island"};const e=kl(i.landBought),n=zl(i.landBought);return i.lvl<n?{ok:!1,why:`Commander level ${n}`,cost:e}:i.res.credits<e?{ok:!1,why:"Not enough credits",cost:e}:{ok:!0,cost:e}}function Vh(i,t){const e=Zl(i,t);return e.ok&&(i.res.credits-=e.cost||0,i.isl.plots.push(t),i.landBought++,Zn(i,"land"),Be(i,25+i.landBought*10),Li({kind:"land",key:t})),e}function xf(i,t){i.jobs=i.jobs.filter(n=>n!==t);const e=Me(i,t.item);if(e){if(t.kind==="build"){const n=e.lvl===0;e.lvl=t.lvl||e.lvl+1;const s=oe[e.t];Be(i,Ih(n?s.buildCost(0):s.upCost(e.lvl-1))),Li({kind:"built",item:e.id,lvl:e.lvl,first:n}),e.t==="assembly"&&Vo(i,t.end)}if(t.kind==="craft"){const n=Fs[t.recipe||0];i.ready[e.id]={cells:Math.round(Mh(n,Math.max(1,e.lvl))*(1+Mr(i,e))),xp:n.xp},Li({kind:"crafted",item:e.id})}if(t.kind==="fuse"&&t.sp){const n=$l(i,t.sp,"fusion",t.end);Li({kind:"fused",item:e.id,core:n.id,sp:t.sp})}if(t.kind==="boot"){const n=mf(i,t.core);n&&(n.state="ready",Li({kind:"booted",core:n.id,sp:n.sp})),Vo(i,t.end)}}}function or(i,t=Date.now()){let e=i.last||t;if(t<e){i.last=t;return}for(;;){const n=i.jobs.filter(r=>r.end<=t).sort((r,a)=>r.end-a.end)[0],s=n?Math.max(e,n.end):t;if(_f(i,(s-e)/1e3),e=s,!n)break;xf(i,n)}i.last=t}function _f(i,t){if(!(t<=0))for(const e of Zt(i,"bay")){if(e.lvl<1)continue;const n=Ri(e),s=i.bay[e.id]||0;s>=n||(i.bay[e.id]=Math.min(n,s+Ya(i,e.id)*t))}}function Ta(i,t){switch(t.kind){case"collect":return(i.stats.collects||0)>=(t.n||1);case"craft":return(i.stats.crafts||0)>=(t.n||1);case"harvest":return(i.stats.harvests||0)>=(t.n||1);case"botLevel":return i.bots.some(e=>e.lvl>=(t.n||1));case"ownSpecies":return i.bots.some(e=>e.sp===t.t);case"bayEl":return Zt(i,"bay").some(e=>e.el===t.t&&e.lvl>0);case"cc":return vi(i)>=(t.n||1);case"decor":return(i.stats.decor||0)>=(t.n||1);case"bayLevel":return Zt(i,"bay").some(e=>e.lvl>=(t.n||1));case"land":return i.landBought>=(t.n||1);case"bots":return i.bots.length>=(t.n||1);case"level":return i.lvl>=(t.n||1);case"rarity":return i.bots.some(e=>gt[e.sp].rarity===t.t);case"build":return Zt(i,t.t||"").some(e=>e.lvl>0);case"fusions":return(i.stats.fusions||0)>=(t.n||1);case"boots":return(i.stats.boots||0)>=(t.n||1);case"helper":return i.bots.some(e=>!!e.post);case"dex":return Gl(i)>=(t.n||1);case"arenaWins":return(i.stats.arenaWins||0)>=(t.n||1);case"trophies":return(i.arena&&i.arena.best||0)>=(t.n||1)}return!1}const lr=i=>wa[i.obj.i]||null;function $h(i){const t=lr(i);return!t||!Ta(i,t)?null:(Qn(i,t.reward),i.obj.claimed[t.id]=Date.now(),i.obj.i++,Be(i,10+i.obj.i*3),t)}const tr=i=>Bo(i.lvl),Wh=i=>bh(i),yf=Object.freeze(Object.defineProperty({__proto__:null,BOT_MAX:Xa,addXp:Be,advance:or,areaFree:Xi,bayCap:Ri,bayCapAt:Wh,bayRate:Ya,botEarn:li,botsIn:pi,build:Ph,buildersBusy:Wa,buyPlot:Vh,canBuild:Ti,canBuyPlot:Zl,canCraft:Hh,canPay:gf,canRecruit:ql,canUpgrade:Wl,ccLevel:vi,claimStep:$h,collectBay:Yl,craft:Gh,currentStep:lr,dims:Qe,dmCost:qi,events:Yn,feed:Xl,feedCost:qa,finishNow:Oh,give:Qn,harvest:Kl,homeFor:es,item:Me,itemsOf:Zt,jobOf:Fe,maxLevelOf:Lh,moveBot:kh,moveItem:Uh,pay:vf,plotOf:Rh,plotState:Ka,recipesFor:zh,recruit:Bh,sellDecor:Fh,stepDone:Ta,tileOpen:Ch,upgrade:Dh,xpNeedOf:tr},Symbol.toStringTag,{value:"Module"}));const Jl="187",bf=0,qc=1,Mf=2,va=1,Xh=2,er=3,Ki=0,qe=1,Cn=2,Cs=0,cr=1,pr=2,Yc=3,Kc=4,Sf=5,As=100,wf=101,Ef=102,Af=103,Tf=104,Rf=200,Cf=201,Pf=202,Lf=203,qh=204,Yh=205,Df=206,If=207,Nf=208,Uf=209,Ff=210,Of=211,Bf=212,kf=213,zf=214,$o=0,Wo=1,Xo=2,mr=3,qo=4,Yo=5,Ko=6,Zo=7,Kh=0,Hf=1,Gf=2,mi=0,Zh=1,Jh=2,jh=3,jl=4,Qh=5,tu=6,eu=7,nu=300,Os=301,gr=302,so=303,ro=304,Ra=1e3,hi=1001,Jo=1002,Ge=1003,Vf=1004,Cr=1005,en=1006,ao=1007,ui=1008,an=1009,iu=1010,su=1011,vr=1012,Ql=1013,Jn=1014,Pn=1015,jn=1016,tc=1017,ec=1018,Bs=1020,ru=35902,au=35899,ou=1021,lu=1022,Kn=1023,Ni=1026,Di=1027,nc=1028,ic=1029,Zi=1030,sc=1031,rc=1033,xa=33776,_a=33777,ya=33778,ba=33779,jo=35840,Qo=35841,tl=35842,el=35843,nl=36196,il=37492,sl=37496,rl=37488,al=37489,Ca=37490,ol=37491,ll=37808,cl=37809,dl=37810,hl=37811,ul=37812,fl=37813,pl=37814,ml=37815,gl=37816,vl=37817,xl=37818,_l=37819,yl=37820,bl=37821,Ml=36492,Sl=36494,wl=36495,El=36283,Al=36284,Pa=36285,Tl=36286,$f=3200,Rl=0,Wf=1,di="",He="srgb",La="srgb-linear",Da="linear",ae="srgb",oo=7680,Xf=519,qf=512,Yf=513,Kf=514,cu=515,Zf=516,Jf=517,du=518,hu=519,uu=35044,Zc="300 es",Ln=2e3,xr=2001;function jf(i){for(let t=i.length-1;t>=0;--t)if(i[t]>=65535)return!0;return!1}function Ia(i){return document.createElementNS("http://www.w3.org/1999/xhtml",i)}function Qf(){const i=Ia("canvas");return i.style.display="block",i}const Jc={};function Na(...i){const t="THREE."+i.shift();console.log(t,...i)}function fu(i){const t=i[0];if(typeof t=="string"&&t.startsWith("TSL:")){const e=i[1];e&&e.isStackTrace?i[0]+=" "+e.getLocation():i[1]='Stack trace not available. Enable "THREE.Node.captureStackTrace" to capture stack traces.'}return i}function Lt(...i){i=fu(i);const t="THREE."+i.shift();{const e=i[0];e&&e.isStackTrace?console.warn(e.getError(t)):console.warn(t,...i)}}function ee(...i){i=fu(i);const t="THREE."+i.shift();{const e=i[0];e&&e.isStackTrace?console.error(e.getError(t)):console.error(t,...i)}}function Ma(...i){const t=i.join(" ");t in Jc||(Jc[t]=!0,Lt(...i))}function tp(i,t,e){return new Promise(function(n,s){function r(){switch(i.clientWaitSync(t,i.SYNC_FLUSH_COMMANDS_BIT,0)){case i.WAIT_FAILED:s();break;case i.TIMEOUT_EXPIRED:setTimeout(r,e);break;default:n()}}setTimeout(r,e)})}const ep={[$o]:$o,[Xo]:Ko,[qo]:qo,[mr]:Yo,[Wo]:Wo,[Ko]:Xo,[Zo]:Zo,[Yo]:mr};class ns{addEventListener(t,e){this._listeners===void 0&&(this._listeners={});const n=this._listeners;n[t]===void 0&&(n[t]=[]),n[t].indexOf(e)===-1&&n[t].push(e)}hasEventListener(t,e){const n=this._listeners;return n===void 0?!1:n[t]!==void 0&&n[t].indexOf(e)!==-1}removeEventListener(t,e){const n=this._listeners;if(n===void 0)return;const s=n[t];if(s!==void 0){const r=s.indexOf(e);r!==-1&&s.splice(r,1)}}dispatchEvent(t){const e=this._listeners;if(e===void 0)return;const n=e[t.type];if(n!==void 0){t.target=this;const s=n.slice(0);for(let r=0,a=s.length;r<a;r++)s[r].call(this,t);t.target=null}}}const We=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"];let jc=1234567;const Ps=Math.PI/180,_r=180/Math.PI;function Fi(){const i=Math.random()*4294967295|0,t=Math.random()*4294967295|0,e=Math.random()*4294967295|0,n=Math.random()*4294967295|0;return(We[i&255]+We[i>>8&255]+We[i>>16&255]+We[i>>24&255]+"-"+We[t&255]+We[t>>8&255]+"-"+We[t>>16&15|64]+We[t>>24&255]+"-"+We[e&63|128]+We[e>>8&255]+"-"+We[e>>16&255]+We[e>>24&255]+We[n&255]+We[n>>8&255]+We[n>>16&255]+We[n>>24&255]).toLowerCase()}function Kt(i,t,e){return Math.max(t,Math.min(e,i))}function ac(i,t){return(i%t+t)%t}function np(i,t,e,n,s){return n+(i-t)*(s-n)/(e-t)}function ip(i,t,e){return i!==t?(e-i)/(t-i):0}function dr(i,t,e){return(1-e)*i+e*t}function sp(i,t,e,n){return dr(i,t,1-Math.exp(-e*n))}function rp(i,t=1){return t-Math.abs(ac(i,t*2)-t)}function ap(i,t,e){return i<=t?0:i>=e?1:(i=(i-t)/(e-t),i*i*(3-2*i))}function op(i,t,e){return i<=t?0:i>=e?1:(i=(i-t)/(e-t),i*i*i*(i*(i*6-15)+10))}function lp(i,t){return i+Math.floor(Math.random()*(t-i+1))}function cp(i,t){return i+Math.random()*(t-i)}function dp(i){return i*(.5-Math.random())}function hp(i){i!==void 0&&(jc=i);let t=jc+=1831565813;return t=Math.imul(t^t>>>15,t|1),t^=t+Math.imul(t^t>>>7,t|61),((t^t>>>14)>>>0)/4294967296}function up(i){return i*Ps}function fp(i){return i*_r}function pp(i){return i>0&&Number.isInteger(i)&&2**Math.round(Math.log2(i))===i}function mp(i){return Math.pow(2,Math.ceil(Math.log(i)/Math.LN2))}function pu(i){return Math.pow(2,Math.floor(Math.log(i)/Math.LN2))}function gp(i,t,e,n,s){const r=Math.cos,a=Math.sin,o=r(e/2),l=a(e/2),c=r((t+n)/2),d=a((t+n)/2),h=r((t-n)/2),u=a((t-n)/2),f=r((n-t)/2),g=a((n-t)/2);switch(s){case"XYX":i.set(o*d,l*h,l*u,o*c);break;case"YZY":i.set(l*u,o*d,l*h,o*c);break;case"ZXZ":i.set(l*h,l*u,o*d,o*c);break;case"XZX":i.set(o*d,l*g,l*f,o*c);break;case"YXY":i.set(l*f,o*d,l*g,o*c);break;case"ZYZ":i.set(l*g,l*f,o*d,o*c);break;default:Lt("MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+s)}}function Za(i){switch(i.constructor){case Uint32Array:return 4294967295;case Uint16Array:return 65535;case Uint8Array:case Uint8ClampedArray:return 255;case Int32Array:return 2147483647;case Int16Array:return 32767;case Int8Array:return 127;default:return}}function oc(i,t){if(t.constructor===Float32Array)return i;const e=Za(t);if(e===void 0)throw new Error("THREE.MathUtils: Invalid component type.");return Math.max(i/e,-1)}function lc(i,t){if(t.constructor===Float32Array)return i;const e=Za(t);if(e===void 0)throw new Error("THREE.MathUtils: Invalid component type.");return Math.round(i*e)}const Ua={DEG2RAD:Ps,RAD2DEG:_r,generateUUID:Fi,clamp:Kt,euclideanModulo:ac,mapLinear:np,inverseLerp:ip,lerp:dr,damp:sp,pingpong:rp,smoothstep:ap,smootherstep:op,randInt:lp,randFloat:cp,randFloatSpread:dp,seededRandom:hp,degToRad:up,radToDeg:fp,isPowerOfTwo:pp,ceilPowerOfTwo:mp,floorPowerOfTwo:pu,setQuaternionFromProperEuler:gp,normalize:lc,denormalize:oc},Tc=class Tc{constructor(t=0,e=0){this.x=t,this.y=e}get width(){return this.x}set width(t){this.x=t}get height(){return this.y}set height(t){this.y=t}set(t,e){return this.x=t,this.y=e,this}setScalar(t){return this.x=t,this.y=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;default:throw new Error("THREE.Vector2: index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;default:throw new Error("THREE.Vector2: index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y)}copy(t){return this.x=t.x,this.y=t.y,this}add(t){return this.x+=t.x,this.y+=t.y,this}addScalar(t){return this.x+=t,this.y+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this}subScalar(t){return this.x-=t,this.y-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this}multiply(t){return this.x*=t.x,this.y*=t.y,this}multiplyScalar(t){return this.x*=t,this.y*=t,this}divide(t){return this.x/=t.x,this.y/=t.y,this}divideScalar(t){return this.multiplyScalar(1/t)}applyMatrix3(t){const e=this.x,n=this.y,s=t.elements;return this.x=s[0]*e+s[3]*n+s[6],this.y=s[1]*e+s[4]*n+s[7],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this}clamp(t,e){return this.x=Kt(this.x,t.x,e.x),this.y=Kt(this.y,t.y,e.y),this}clampScalar(t,e){return this.x=Kt(this.x,t,e),this.y=Kt(this.y,t,e),this}clampLength(t,e){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Kt(n,t,e))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(t){return this.x*t.x+this.y*t.y}cross(t){return this.x*t.y-this.y*t.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(t){const e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;const n=this.dot(t)/e;return Math.acos(Kt(n,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){const e=this.x-t.x,n=this.y-t.y;return e*e+n*n}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this}equals(t){return t.x===this.x&&t.y===this.y}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this}rotateAround(t,e){const n=Math.cos(e),s=Math.sin(e),r=this.x-t.x,a=this.y-t.y;return this.x=r*n-a*s+t.x,this.y=r*s+a*n+t.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}};Tc.prototype.isVector2=!0;let Dt=Tc;class xi{constructor(t=0,e=0,n=0,s=1){this.isQuaternion=!0,this._x=t,this._y=e,this._z=n,this._w=s}static slerpFlat(t,e,n,s,r,a,o){let l=n[s+0],c=n[s+1],d=n[s+2],h=n[s+3],u=r[a+0],f=r[a+1],g=r[a+2],x=r[a+3];if(h!==x||l!==u||c!==f||d!==g){let m=l*u+c*f+d*g+h*x;m<0&&(u=-u,f=-f,g=-g,x=-x,m=-m);let p=1-o;if(m<.9995){const _=Math.acos(m),S=Math.sin(_);p=Math.sin(p*_)/S,o=Math.sin(o*_)/S,l=l*p+u*o,c=c*p+f*o,d=d*p+g*o,h=h*p+x*o}else{l=l*p+u*o,c=c*p+f*o,d=d*p+g*o,h=h*p+x*o;const _=1/Math.sqrt(l*l+c*c+d*d+h*h);l*=_,c*=_,d*=_,h*=_}}t[e]=l,t[e+1]=c,t[e+2]=d,t[e+3]=h}static multiplyQuaternionsFlat(t,e,n,s,r,a){const o=n[s],l=n[s+1],c=n[s+2],d=n[s+3],h=r[a],u=r[a+1],f=r[a+2],g=r[a+3];return t[e]=o*g+d*h+l*f-c*u,t[e+1]=l*g+d*u+c*h-o*f,t[e+2]=c*g+d*f+o*u-l*h,t[e+3]=d*g-o*h-l*u-c*f,t}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get w(){return this._w}set w(t){this._w=t,this._onChangeCallback()}set(t,e,n,s){return this._x=t,this._y=e,this._z=n,this._w=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(t){return this._x=t.x,this._y=t.y,this._z=t.z,this._w=t.w,this._onChangeCallback(),this}setFromEuler(t,e=!0){const n=t._x,s=t._y,r=t._z,a=t._order,o=Math.cos,l=Math.sin,c=o(n/2),d=o(s/2),h=o(r/2),u=l(n/2),f=l(s/2),g=l(r/2);switch(a){case"XYZ":this._x=u*d*h+c*f*g,this._y=c*f*h-u*d*g,this._z=c*d*g+u*f*h,this._w=c*d*h-u*f*g;break;case"YXZ":this._x=u*d*h+c*f*g,this._y=c*f*h-u*d*g,this._z=c*d*g-u*f*h,this._w=c*d*h+u*f*g;break;case"ZXY":this._x=u*d*h-c*f*g,this._y=c*f*h+u*d*g,this._z=c*d*g+u*f*h,this._w=c*d*h-u*f*g;break;case"ZYX":this._x=u*d*h-c*f*g,this._y=c*f*h+u*d*g,this._z=c*d*g-u*f*h,this._w=c*d*h+u*f*g;break;case"YZX":this._x=u*d*h+c*f*g,this._y=c*f*h+u*d*g,this._z=c*d*g-u*f*h,this._w=c*d*h-u*f*g;break;case"XZY":this._x=u*d*h-c*f*g,this._y=c*f*h-u*d*g,this._z=c*d*g+u*f*h,this._w=c*d*h+u*f*g;break;default:Lt("Quaternion: .setFromEuler() encountered an unknown order: "+a)}return e===!0&&this._onChangeCallback(),this}setFromAxisAngle(t,e){const n=e/2,s=Math.sin(n);return this._x=t.x*s,this._y=t.y*s,this._z=t.z*s,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(t){const e=t.elements,n=e[0],s=e[4],r=e[8],a=e[1],o=e[5],l=e[9],c=e[2],d=e[6],h=e[10],u=n+o+h;if(u>0){const f=.5/Math.sqrt(u+1);this._w=.25/f,this._x=(d-l)*f,this._y=(r-c)*f,this._z=(a-s)*f}else if(n>o&&n>h){const f=2*Math.sqrt(1+n-o-h);this._w=(d-l)/f,this._x=.25*f,this._y=(s+a)/f,this._z=(r+c)/f}else if(o>h){const f=2*Math.sqrt(1+o-n-h);this._w=(r-c)/f,this._x=(s+a)/f,this._y=.25*f,this._z=(l+d)/f}else{const f=2*Math.sqrt(1+h-n-o);this._w=(a-s)/f,this._x=(r+c)/f,this._y=(l+d)/f,this._z=.25*f}return this._onChangeCallback(),this}setFromUnitVectors(t,e){let n=t.dot(e)+1;return n<1e-8?(n=0,Math.abs(t.x)>Math.abs(t.z)?(this._x=-t.y,this._y=t.x,this._z=0,this._w=n):(this._x=0,this._y=-t.z,this._z=t.y,this._w=n)):(this._x=t.y*e.z-t.z*e.y,this._y=t.z*e.x-t.x*e.z,this._z=t.x*e.y-t.y*e.x,this._w=n),this.normalize()}angleTo(t){return 2*Math.acos(Math.abs(Kt(this.dot(t),-1,1)))}rotateTowards(t,e){const n=this.angleTo(t);if(n===0)return this;const s=Math.min(1,e/n);return this.slerp(t,s),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(t){return this._x*t._x+this._y*t._y+this._z*t._z+this._w*t._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let t=this.length();return t===0?(this._x=0,this._y=0,this._z=0,this._w=1):(t=1/t,this._x=this._x*t,this._y=this._y*t,this._z=this._z*t,this._w=this._w*t),this._onChangeCallback(),this}multiply(t){return this.multiplyQuaternions(this,t)}premultiply(t){return this.multiplyQuaternions(t,this)}multiplyQuaternions(t,e){const n=t._x,s=t._y,r=t._z,a=t._w,o=e._x,l=e._y,c=e._z,d=e._w;return this._x=n*d+a*o+s*c-r*l,this._y=s*d+a*l+r*o-n*c,this._z=r*d+a*c+n*l-s*o,this._w=a*d-n*o-s*l-r*c,this._onChangeCallback(),this}slerp(t,e){let n=t._x,s=t._y,r=t._z,a=t._w,o=this.dot(t);o<0&&(n=-n,s=-s,r=-r,a=-a,o=-o);let l=1-e;if(o<.9995){const c=Math.acos(o),d=Math.sin(c);l=Math.sin(l*c)/d,e=Math.sin(e*c)/d,this._x=this._x*l+n*e,this._y=this._y*l+s*e,this._z=this._z*l+r*e,this._w=this._w*l+a*e,this._onChangeCallback()}else this._x=this._x*l+n*e,this._y=this._y*l+s*e,this._z=this._z*l+r*e,this._w=this._w*l+a*e,this.normalize();return this}slerpQuaternions(t,e,n){return this.copy(t).slerp(e,n)}random(){const t=2*Math.PI*Math.random(),e=2*Math.PI*Math.random(),n=Math.random(),s=Math.sqrt(1-n),r=Math.sqrt(n);return this.set(s*Math.sin(t),s*Math.cos(t),r*Math.sin(e),r*Math.cos(e))}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._w===this._w}fromArray(t,e=0){return this._x=t[e],this._y=t[e+1],this._z=t[e+2],this._w=t[e+3],this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._w,t}fromBufferAttribute(t,e){return this._x=t.getX(e),this._y=t.getY(e),this._z=t.getZ(e),this._w=t.getW(e),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}const Rc=class Rc{constructor(t=0,e=0,n=0){this.x=t,this.y=e,this.z=n}set(t,e,n){return n===void 0&&(n=this.z),this.x=t,this.y=e,this.z=n,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;default:throw new Error("THREE.Vector3: index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("THREE.Vector3: index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this}multiplyVectors(t,e){return this.x=t.x*e.x,this.y=t.y*e.y,this.z=t.z*e.z,this}applyEuler(t){return this.applyQuaternion(Qc.setFromEuler(t))}applyAxisAngle(t,e){return this.applyQuaternion(Qc.setFromAxisAngle(t,e))}applyMatrix3(t){const e=this.x,n=this.y,s=this.z,r=t.elements;return this.x=r[0]*e+r[3]*n+r[6]*s,this.y=r[1]*e+r[4]*n+r[7]*s,this.z=r[2]*e+r[5]*n+r[8]*s,this}applyNormalMatrix(t){return this.applyMatrix3(t).normalize()}applyMatrix4(t){const e=this.x,n=this.y,s=this.z,r=t.elements,a=1/(r[3]*e+r[7]*n+r[11]*s+r[15]);return this.x=(r[0]*e+r[4]*n+r[8]*s+r[12])*a,this.y=(r[1]*e+r[5]*n+r[9]*s+r[13])*a,this.z=(r[2]*e+r[6]*n+r[10]*s+r[14])*a,this}applyQuaternion(t){const e=this.x,n=this.y,s=this.z,r=t.x,a=t.y,o=t.z,l=t.w,c=2*(a*s-o*n),d=2*(o*e-r*s),h=2*(r*n-a*e);return this.x=e+l*c+a*h-o*d,this.y=n+l*d+o*c-r*h,this.z=s+l*h+r*d-a*c,this}project(t){return this.applyMatrix4(t.matrixWorldInverse).applyMatrix4(t.projectionMatrix)}unproject(t){return this.applyMatrix4(t.projectionMatrixInverse).applyMatrix4(t.matrixWorld)}transformDirection(t){const e=this.x,n=this.y,s=this.z,r=t.elements;return this.x=r[0]*e+r[4]*n+r[8]*s,this.y=r[1]*e+r[5]*n+r[9]*s,this.z=r[2]*e+r[6]*n+r[10]*s,this.normalize()}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this}divideScalar(t){return this.multiplyScalar(1/t)}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this}clamp(t,e){return this.x=Kt(this.x,t.x,e.x),this.y=Kt(this.y,t.y,e.y),this.z=Kt(this.z,t.z,e.z),this}clampScalar(t,e){return this.x=Kt(this.x,t,e),this.y=Kt(this.y,t,e),this.z=Kt(this.z,t,e),this}clampLength(t,e){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Kt(n,t,e))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this.z=t.z+(e.z-t.z)*n,this}cross(t){return this.crossVectors(this,t)}crossVectors(t,e){const n=t.x,s=t.y,r=t.z,a=e.x,o=e.y,l=e.z;return this.x=s*l-r*o,this.y=r*a-n*l,this.z=n*o-s*a,this}projectOnVector(t){const e=t.lengthSq();if(e===0)return this.set(0,0,0);const n=t.dot(this)/e;return this.copy(t).multiplyScalar(n)}projectOnPlane(t){return lo.copy(this).projectOnVector(t),this.sub(lo)}reflect(t){return this.sub(lo.copy(t).multiplyScalar(2*this.dot(t)))}angleTo(t){const e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;const n=this.dot(t)/e;return Math.acos(Kt(n,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){const e=this.x-t.x,n=this.y-t.y,s=this.z-t.z;return e*e+n*n+s*s}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)+Math.abs(this.z-t.z)}setFromSpherical(t){return this.setFromSphericalCoords(t.radius,t.phi,t.theta)}setFromSphericalCoords(t,e,n){const s=Math.sin(e)*t;return this.x=s*Math.sin(n),this.y=Math.cos(e)*t,this.z=s*Math.cos(n),this}setFromCylindrical(t){return this.setFromCylindricalCoords(t.radius,t.theta,t.y)}setFromCylindricalCoords(t,e,n){return this.x=t*Math.sin(e),this.y=n,this.z=t*Math.cos(e),this}setFromMatrixPosition(t){const e=t.elements;return this.x=e[12],this.y=e[13],this.z=e[14],this}setFromMatrixScale(t){const e=this.setFromMatrixColumn(t,0).length(),n=this.setFromMatrixColumn(t,1).length(),s=this.setFromMatrixColumn(t,2).length();return this.x=e,this.y=n,this.z=s,this}setFromMatrixColumn(t,e){return this.fromArray(t.elements,e*4)}setFromMatrix3Column(t,e){return this.fromArray(t.elements,e*3)}setFromEuler(t){return this.x=t._x,this.y=t._y,this.z=t._z,this}setFromColor(t){return this.x=t.r,this.y=t.g,this.z=t.b,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const t=Math.random()*Math.PI*2,e=Math.random()*2-1,n=Math.sqrt(1-e*e);return this.x=n*Math.cos(t),this.y=e,this.z=n*Math.sin(t),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}};Rc.prototype.isVector3=!0;let I=Rc;const lo=new I,Qc=new xi,Cc=class Cc{constructor(t,e,n,s,r,a,o,l,c){this.elements=[1,0,0,0,1,0,0,0,1],t!==void 0&&this.set(t,e,n,s,r,a,o,l,c)}set(t,e,n,s,r,a,o,l,c){const d=this.elements;return d[0]=t,d[1]=s,d[2]=o,d[3]=e,d[4]=r,d[5]=l,d[6]=n,d[7]=a,d[8]=c,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(t){const e=this.elements,n=t.elements;return e[0]=n[0],e[1]=n[1],e[2]=n[2],e[3]=n[3],e[4]=n[4],e[5]=n[5],e[6]=n[6],e[7]=n[7],e[8]=n[8],this}extractBasis(t,e,n){return t.setFromMatrix3Column(this,0),e.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(t){const e=t.elements;return this.set(e[0],e[4],e[8],e[1],e[5],e[9],e[2],e[6],e[10]),this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){const n=t.elements,s=e.elements,r=this.elements,a=n[0],o=n[3],l=n[6],c=n[1],d=n[4],h=n[7],u=n[2],f=n[5],g=n[8],x=s[0],m=s[3],p=s[6],_=s[1],S=s[4],y=s[7],A=s[2],E=s[5],v=s[8];return r[0]=a*x+o*_+l*A,r[3]=a*m+o*S+l*E,r[6]=a*p+o*y+l*v,r[1]=c*x+d*_+h*A,r[4]=c*m+d*S+h*E,r[7]=c*p+d*y+h*v,r[2]=u*x+f*_+g*A,r[5]=u*m+f*S+g*E,r[8]=u*p+f*y+g*v,this}multiplyScalar(t){const e=this.elements;return e[0]*=t,e[3]*=t,e[6]*=t,e[1]*=t,e[4]*=t,e[7]*=t,e[2]*=t,e[5]*=t,e[8]*=t,this}determinant(){const t=this.elements,e=t[0],n=t[1],s=t[2],r=t[3],a=t[4],o=t[5],l=t[6],c=t[7],d=t[8];return e*a*d-e*o*c-n*r*d+n*o*l+s*r*c-s*a*l}invert(){const t=this.elements,e=t[0],n=t[1],s=t[2],r=t[3],a=t[4],o=t[5],l=t[6],c=t[7],d=t[8],h=d*a-o*c,u=o*l-d*r,f=c*r-a*l,g=e*h+n*u+s*f;if(g===0)return this.set(0,0,0,0,0,0,0,0,0);const x=1/g;return t[0]=h*x,t[1]=(s*c-d*n)*x,t[2]=(o*n-s*a)*x,t[3]=u*x,t[4]=(d*e-s*l)*x,t[5]=(s*r-o*e)*x,t[6]=f*x,t[7]=(n*l-c*e)*x,t[8]=(a*e-n*r)*x,this}transpose(){let t;const e=this.elements;return t=e[1],e[1]=e[3],e[3]=t,t=e[2],e[2]=e[6],e[6]=t,t=e[5],e[5]=e[7],e[7]=t,this}getNormalMatrix(t){return this.setFromMatrix4(t).invert().transpose()}transposeIntoArray(t){const e=this.elements;return t[0]=e[0],t[1]=e[3],t[2]=e[6],t[3]=e[1],t[4]=e[4],t[5]=e[7],t[6]=e[2],t[7]=e[5],t[8]=e[8],this}setUvTransform(t,e,n,s,r,a,o){const l=Math.cos(r),c=Math.sin(r);return this.set(n*l,n*c,-n*(l*a+c*o)+a+t,-s*c,s*l,-s*(-c*a+l*o)+o+e,0,0,1),this}scale(t,e){return Ma("Matrix3: .scale() is deprecated. Use .makeScale() instead."),this.premultiply(co.makeScale(t,e)),this}rotate(t){return Ma("Matrix3: .rotate() is deprecated. Use .makeRotation() instead."),this.premultiply(co.makeRotation(-t)),this}translate(t,e){return Ma("Matrix3: .translate() is deprecated. Use .makeTranslation() instead."),this.premultiply(co.makeTranslation(t,e)),this}makeTranslation(t,e){return t.isVector2?this.set(1,0,t.x,0,1,t.y,0,0,1):this.set(1,0,t,0,1,e,0,0,1),this}makeRotation(t){const e=Math.cos(t),n=Math.sin(t);return this.set(e,-n,0,n,e,0,0,0,1),this}makeScale(t,e){return this.set(t,0,0,0,e,0,0,0,1),this}equals(t){const e=this.elements,n=t.elements;for(let s=0;s<9;s++)if(e[s]!==n[s])return!1;return!0}fromArray(t,e=0){for(let n=0;n<9;n++)this.elements[n]=t[n+e];return this}toArray(t=[],e=0){const n=this.elements;return t[e]=n[0],t[e+1]=n[1],t[e+2]=n[2],t[e+3]=n[3],t[e+4]=n[4],t[e+5]=n[5],t[e+6]=n[6],t[e+7]=n[7],t[e+8]=n[8],t}clone(){return new this.constructor().fromArray(this.elements)}};Cc.prototype.isMatrix3=!0;let Ot=Cc;const co=new Ot,td=new Ot().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),ed=new Ot().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function vp(){const i={enabled:!0,workingColorSpace:La,spaces:{},convert:function(s,r,a){return this.enabled===!1||r===a||!r||!a||(this.spaces[r].transfer===ae&&(s.r=gi(s.r),s.g=gi(s.g),s.b=gi(s.b)),this.spaces[r].primaries!==this.spaces[a].primaries&&(s.applyMatrix3(this.spaces[r].toXYZ),s.applyMatrix3(this.spaces[a].fromXYZ)),this.spaces[a].transfer===ae&&(s.r=Ls(s.r),s.g=Ls(s.g),s.b=Ls(s.b))),s},workingToColorSpace:function(s,r){return this.convert(s,this.workingColorSpace,r)},colorSpaceToWorking:function(s,r){return this.convert(s,r,this.workingColorSpace)},getPrimaries:function(s){return this.spaces[s].primaries},getTransfer:function(s){return s===di?Da:this.spaces[s].transfer},getToneMappingMode:function(s){return this.spaces[s].outputColorSpaceConfig.toneMappingMode||"standard"},getLuminanceCoefficients:function(s,r=this.workingColorSpace){return s.fromArray(this.spaces[r].luminanceCoefficients)},define:function(s){Object.assign(this.spaces,s)},_getMatrix:function(s,r,a){return s.copy(this.spaces[a].fromXYZ).multiply(this.spaces[r].toXYZ)},_getDrawingBufferColorSpace:function(s){return this.spaces[s].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(s=this.workingColorSpace){return this.spaces[s].workingColorSpaceConfig.unpackColorSpace}},t=[.64,.33,.3,.6,.15,.06],e=[.2126,.7152,.0722],n=[.3127,.329];return i.define({[La]:{primaries:t,whitePoint:n,transfer:Da,toXYZ:td,fromXYZ:ed,luminanceCoefficients:e,workingColorSpaceConfig:{unpackColorSpace:He},outputColorSpaceConfig:{drawingBufferColorSpace:He}},[He]:{primaries:t,whitePoint:n,transfer:ae,toXYZ:td,fromXYZ:ed,luminanceCoefficients:e,outputColorSpaceConfig:{drawingBufferColorSpace:He}}}),i}const Jt=vp();function gi(i){return i<.04045?i*.0773993808:Math.pow(i*.9478672986+.0521327014,2.4)}function Ls(i){return i<.0031308?i*12.92:1.055*Math.pow(i,.41666)-.055}let ls;class xp{static getDataURL(t,e="image/png"){if(/^data:/i.test(t.src)||typeof HTMLCanvasElement>"u")return t.src;let n;if(t instanceof HTMLCanvasElement)n=t;else{ls===void 0&&(ls=Ia("canvas")),ls.width=t.width,ls.height=t.height;const s=ls.getContext("2d");t instanceof ImageData?s.putImageData(t,0,0):s.drawImage(t,0,0,t.width,t.height),n=ls}return n.toDataURL(e)}static sRGBToLinear(t){if(typeof HTMLImageElement<"u"&&t instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&t instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&t instanceof ImageBitmap){const e=Ia("canvas");e.width=t.width,e.height=t.height;const n=e.getContext("2d");n.drawImage(t,0,0,t.width,t.height);const s=n.getImageData(0,0,t.width,t.height),r=s.data;for(let a=0;a<r.length;a++)r[a]=gi(r[a]/255)*255;return n.putImageData(s,0,0),e}else if(t.data){const e=t.data.slice(0);for(let n=0;n<e.length;n++)e instanceof Uint8Array||e instanceof Uint8ClampedArray?e[n]=Math.floor(gi(e[n]/255)*255):e[n]=gi(e[n]);return{data:e,width:t.width,height:t.height}}else return Lt("ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),t}}let _p=0;class cc{constructor(t=null){this.isTextureSource=!0,Object.defineProperty(this,"id",{value:_p++}),this.uuid=Fi(),this.data=t,this.dataReady=!0,this.version=0}getSize(t){const e=this.data;return typeof HTMLVideoElement<"u"&&e instanceof HTMLVideoElement?t.set(e.videoWidth,e.videoHeight,0):typeof VideoFrame<"u"&&e instanceof VideoFrame?t.set(e.displayWidth,e.displayHeight,0):e!==null?t.set(e.width||0,e.height||0,e.depth||0):t.set(0,0,0),t}set needsUpdate(t){t===!0&&this.version++}toJSON(t){const e=t===void 0||typeof t=="string";if(!e&&t.images[this.uuid]!==void 0)return t.images[this.uuid];const n={uuid:this.uuid,url:""},s=this.data;if(s!==null){let r;if(Array.isArray(s)){r=[];for(let a=0,o=s.length;a<o;a++)s[a].isDataTexture?r.push(ho(s[a].image)):r.push(ho(s[a]))}else r=ho(s);n.url=r}return e||(t.images[this.uuid]=n),n}}function ho(i){return typeof HTMLImageElement<"u"&&i instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&i instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&i instanceof ImageBitmap?xp.getDataURL(i):i.data?{data:Array.from(i.data),width:i.width,height:i.height,type:i.data.constructor.name}:(Lt("Texture: Unable to serialize Texture."),{})}let yp=0;const uo=new I;class Ye extends ns{constructor(t=Ye.DEFAULT_IMAGE,e=Ye.DEFAULT_MAPPING,n=hi,s=hi,r=en,a=ui,o=Kn,l=an,c=Ye.DEFAULT_ANISOTROPY,d=di){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:yp++}),this.uuid=Fi(),this.name="",this.source=new cc(t),this.mipmaps=[],this.mapping=e,this.channel=0,this.wrapS=n,this.wrapT=s,this.magFilter=r,this.minFilter=a,this.anisotropy=c,this.format=o,this.internalFormat=null,this.type=l,this.offset=new Dt(0,0),this.repeat=new Dt(1,1),this.center=new Dt(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new Ot,this.generateMipmaps=!0,this.mipmapsAutoUpdate=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=d,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(t&&t.depth&&t.depth>1),this.pmremVersion=0,this.isPMREMTexture=!1,this.normalized=!1}get width(){return this.source.getSize(uo).x}get height(){return this.source.getSize(uo).y}get depth(){return this.source.getSize(uo).z}get image(){return this.source.data}set image(t){this.source.data=t}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(t){return this.name=t.name,this.source=t.source,this.mipmaps=t.mipmaps.slice(0),this.mapping=t.mapping,this.channel=t.channel,this.wrapS=t.wrapS,this.wrapT=t.wrapT,this.magFilter=t.magFilter,this.minFilter=t.minFilter,this.anisotropy=t.anisotropy,this.format=t.format,this.internalFormat=t.internalFormat,this.type=t.type,this.normalized=t.normalized,this.offset.copy(t.offset),this.repeat.copy(t.repeat),this.center.copy(t.center),this.rotation=t.rotation,this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrix.copy(t.matrix),this.generateMipmaps=t.generateMipmaps,this.mipmapsAutoUpdate=t.mipmapsAutoUpdate,this.premultiplyAlpha=t.premultiplyAlpha,this.flipY=t.flipY,this.unpackAlignment=t.unpackAlignment,this.colorSpace=t.colorSpace,this.renderTarget=t.renderTarget,this.isRenderTargetTexture=t.isRenderTargetTexture,this.isPMREMTexture=t.isPMREMTexture,this.isArrayTexture=t.isArrayTexture,this.userData=JSON.parse(JSON.stringify(t.userData)),this.needsUpdate=!0,this}setValues(t){for(const e in t){const n=t[e];if(n===void 0){Lt(`Texture.setValues(): parameter '${e}' has value of undefined.`);continue}const s=this[e];if(s===void 0){Lt(`Texture.setValues(): property '${e}' does not exist.`);continue}s&&n&&s.isVector2&&n.isVector2||s&&n&&s.isVector3&&n.isVector3||s&&n&&s.isMatrix3&&n.isMatrix3?s.copy(n):this[e]=n}}toJSON(t){const e=t===void 0||typeof t=="string";if(!e&&t.textures[this.uuid]!==void 0)return t.textures[this.uuid];const n={metadata:{version:4.7,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(t).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,normalized:this.normalized,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,mipmapsAutoUpdate:this.mipmapsAutoUpdate,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),e||(t.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(t){if(this.mapping!==nu)return t;if(t.applyMatrix3(this.matrix),t.x<0||t.x>1)switch(this.wrapS){case Ra:t.x=t.x-Math.floor(t.x);break;case hi:t.x=t.x<0?0:1;break;case Jo:Math.abs(Math.floor(t.x)%2)===1?t.x=Math.ceil(t.x)-t.x:t.x=t.x-Math.floor(t.x);break}if(t.y<0||t.y>1)switch(this.wrapT){case Ra:t.y=t.y-Math.floor(t.y);break;case hi:t.y=t.y<0?0:1;break;case Jo:Math.abs(Math.floor(t.y)%2)===1?t.y=Math.ceil(t.y)-t.y:t.y=t.y-Math.floor(t.y);break}return this.flipY&&(t.y=1-t.y),t}set needsUpdate(t){t===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(t){t===!0&&this.pmremVersion++}}Ye.DEFAULT_IMAGE=null;Ye.DEFAULT_MAPPING=nu;Ye.DEFAULT_ANISOTROPY=1;const Pc=class Pc{constructor(t=0,e=0,n=0,s=1){this.x=t,this.y=e,this.z=n,this.w=s}get width(){return this.z}set width(t){this.z=t}get height(){return this.w}set height(t){this.w=t}set(t,e,n,s){return this.x=t,this.y=e,this.z=n,this.w=s,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this.w=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setW(t){return this.w=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;case 3:this.w=e;break;default:throw new Error("THREE.Vector4: index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("THREE.Vector4: index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this.w=t.w!==void 0?t.w:1,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this.w+=t.w,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this.w+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this.w=t.w+e.w,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this.w+=t.w*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this.w-=t.w,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this.w-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this.w=t.w-e.w,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this.w*=t.w,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this.w*=t,this}applyMatrix4(t){const e=this.x,n=this.y,s=this.z,r=this.w,a=t.elements;return this.x=a[0]*e+a[4]*n+a[8]*s+a[12]*r,this.y=a[1]*e+a[5]*n+a[9]*s+a[13]*r,this.z=a[2]*e+a[6]*n+a[10]*s+a[14]*r,this.w=a[3]*e+a[7]*n+a[11]*s+a[15]*r,this}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this.w/=t.w,this}divideScalar(t){return this.multiplyScalar(1/t)}setAxisAngleFromQuaternion(t){this.w=2*Math.acos(t.w);const e=Math.sqrt(1-t.w*t.w);return e<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=t.x/e,this.y=t.y/e,this.z=t.z/e),this}setAxisAngleFromRotationMatrix(t){let e,n,s,r;const l=t.elements,c=l[0],d=l[4],h=l[8],u=l[1],f=l[5],g=l[9],x=l[2],m=l[6],p=l[10];if(Math.abs(d-u)<.01&&Math.abs(h-x)<.01&&Math.abs(g-m)<.01){if(Math.abs(d+u)<.1&&Math.abs(h+x)<.1&&Math.abs(g+m)<.1&&Math.abs(c+f+p-3)<.1)return this.set(1,0,0,0),this;e=Math.PI;const S=(c+1)/2,y=(f+1)/2,A=(p+1)/2,E=(d+u)/4,v=(h+x)/4,w=(g+m)/4;return S>y&&S>A?S<.01?(n=0,s=.707106781,r=.707106781):(n=Math.sqrt(S),s=E/n,r=v/n):y>A?y<.01?(n=.707106781,s=0,r=.707106781):(s=Math.sqrt(y),n=E/s,r=w/s):A<.01?(n=.707106781,s=.707106781,r=0):(r=Math.sqrt(A),n=v/r,s=w/r),this.set(n,s,r,e),this}let _=Math.sqrt((m-g)*(m-g)+(h-x)*(h-x)+(u-d)*(u-d));return Math.abs(_)<.001&&(_=1),this.x=(m-g)/_,this.y=(h-x)/_,this.z=(u-d)/_,this.w=Math.acos((c+f+p-1)/2),this}setFromMatrixPosition(t){const e=t.elements;return this.x=e[12],this.y=e[13],this.z=e[14],this.w=e[15],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this.w=Math.min(this.w,t.w),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this.w=Math.max(this.w,t.w),this}clamp(t,e){return this.x=Kt(this.x,t.x,e.x),this.y=Kt(this.y,t.y,e.y),this.z=Kt(this.z,t.z,e.z),this.w=Kt(this.w,t.w,e.w),this}clampScalar(t,e){return this.x=Kt(this.x,t,e),this.y=Kt(this.y,t,e),this.z=Kt(this.z,t,e),this.w=Kt(this.w,t,e),this}clampLength(t,e){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Kt(n,t,e))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z+this.w*t.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this.w+=(t.w-this.w)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this.z=t.z+(e.z-t.z)*n,this.w=t.w+(e.w-t.w)*n,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z&&t.w===this.w}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this.w=t[e+3],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t[e+3]=this.w,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this.w=t.getW(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}};Pc.prototype.isVector4=!0;let _e=Pc;class bp extends ns{constructor(t=1,e=1,n={}){super(),n=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:en,depthBuffer:!0,stencilBuffer:!1,resolveColorBuffer:!0,resolveDepthBuffer:!0,resolveStencilBuffer:!0,storeMultisampledColorBuffer:!0,storeMultisampledDepthBuffer:!0,storeMultisampledStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1,useArrayDepthTexture:!1},n),this.isRenderTarget=!0,this.width=t,this.height=e,this.depth=n.depth,this.scissor=new _e(0,0,t,e),this.scissorTest=!1,this.viewport=new _e(0,0,t,e),this.textures=[];const s=n.count;for(let r=0;r<s;r++)this.textures[r]=new Ye({width:t,height:e,depth:n.depth}),this.textures[r].isRenderTargetTexture=!0,this.textures[r].renderTarget=this;this._setTextureOptions(n),this.depthBuffer=n.depthBuffer,this.stencilBuffer=n.stencilBuffer,this.resolveColorBuffer=n.resolveColorBuffer,this.resolveDepthBuffer=n.resolveDepthBuffer,this.resolveStencilBuffer=n.resolveStencilBuffer,this.storeMultisampledColorBuffer=n.storeMultisampledColorBuffer,this.storeMultisampledDepthBuffer=n.storeMultisampledDepthBuffer,this.storeMultisampledStencilBuffer=n.storeMultisampledStencilBuffer,this._depthTexture=null,this.depthTexture=n.depthTexture,this.samples=n.samples,this.multiview=n.multiview,this.useArrayDepthTexture=n.useArrayDepthTexture}_setTextureOptions(t={}){const e={minFilter:en,generateMipmaps:!1,flipY:!1,internalFormat:null};t.mapping!==void 0&&(e.mapping=t.mapping),t.wrapS!==void 0&&(e.wrapS=t.wrapS),t.wrapT!==void 0&&(e.wrapT=t.wrapT),t.wrapR!==void 0&&(e.wrapR=t.wrapR),t.magFilter!==void 0&&(e.magFilter=t.magFilter),t.minFilter!==void 0&&(e.minFilter=t.minFilter),t.format!==void 0&&(e.format=t.format),t.type!==void 0&&(e.type=t.type),t.anisotropy!==void 0&&(e.anisotropy=t.anisotropy),t.colorSpace!==void 0&&(e.colorSpace=t.colorSpace),t.flipY!==void 0&&(e.flipY=t.flipY),t.generateMipmaps!==void 0&&(e.generateMipmaps=t.generateMipmaps),t.mipmapsAutoUpdate!==void 0&&(e.mipmapsAutoUpdate=t.mipmapsAutoUpdate),t.internalFormat!==void 0&&(e.internalFormat=t.internalFormat);for(let n=0;n<this.textures.length;n++)this.textures[n].setValues(e)}get texture(){return this.textures[0]}set texture(t){this.textures[0]=t}set depthTexture(t){this._depthTexture!==null&&this._depthTexture.renderTarget===this&&(this._depthTexture.renderTarget=null),t!==null&&t.renderTarget===null&&(t.renderTarget=this),this._depthTexture=t}get depthTexture(){return this._depthTexture}setSize(t,e,n=1){if(this.width!==t||this.height!==e||this.depth!==n){this.width=t,this.height=e,this.depth=n;for(let s=0,r=this.textures.length;s<r;s++)this.textures[s].image.width=t,this.textures[s].image.height=e,this.textures[s].image.depth=n,this.textures[s].isData3DTexture!==!0&&(this.textures[s].isArrayTexture=this.textures[s].image.depth>1);this.dispose()}this.viewport.set(0,0,t,e),this.scissor.set(0,0,t,e)}clone(){return new this.constructor().copy(this)}copy(t){this.width=t.width,this.height=t.height,this.depth=t.depth,this.scissor.copy(t.scissor),this.scissorTest=t.scissorTest,this.viewport.copy(t.viewport),this.textures.length=0;for(let e=0,n=t.textures.length;e<n;e++){this.textures[e]=t.textures[e].clone(),this.textures[e].isRenderTargetTexture=!0,this.textures[e].renderTarget=this;const s=Object.assign({},t.textures[e].image);this.textures[e].source=new cc(s)}if(this.depthBuffer=t.depthBuffer,this.stencilBuffer=t.stencilBuffer,this.resolveColorBuffer=t.resolveColorBuffer,this.resolveDepthBuffer=t.resolveDepthBuffer,this.resolveStencilBuffer=t.resolveStencilBuffer,this.storeMultisampledColorBuffer=t.storeMultisampledColorBuffer,this.storeMultisampledDepthBuffer=t.storeMultisampledDepthBuffer,this.storeMultisampledStencilBuffer=t.storeMultisampledStencilBuffer,t.depthTexture!==null)if(t.depthTexture.renderTarget===t){const e=t.depthTexture.clone();e.renderTarget=null,this.depthTexture=e}else this.depthTexture=t.depthTexture;else this.depthTexture=null;return this.samples=t.samples,this.multiview=t.multiview,this.useArrayDepthTexture=t.useArrayDepthTexture,this}dispose(){this.dispatchEvent({type:"dispose"})}}class Sn extends bp{constructor(t=1,e=1,n={}){super(t,e,n),this.isWebGLRenderTarget=!0}}class mu extends Ye{constructor(t=null,e=1,n=1,s=1){super(null),this.isDataArrayTexture=!0,this.image={data:t,width:e,height:n,depth:s},this.magFilter=Ge,this.minFilter=Ge,this.wrapR=hi,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}copy(t){return super.copy(t),this.wrapR=t.wrapR,this}addLayerUpdate(t){this.layerUpdates.add(t)}clearLayerUpdates(){this.layerUpdates.clear()}}class Mp extends Ye{constructor(t=null,e=1,n=1,s=1){super(null),this.isData3DTexture=!0,this.image={data:t,width:e,height:n,depth:s},this.magFilter=Ge,this.minFilter=Ge,this.wrapR=hi,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}copy(t){return super.copy(t),this.wrapR=t.wrapR,this}}const $a=class $a{constructor(t,e,n,s,r,a,o,l,c,d,h,u,f,g,x,m){this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],t!==void 0&&this.set(t,e,n,s,r,a,o,l,c,d,h,u,f,g,x,m)}set(t,e,n,s,r,a,o,l,c,d,h,u,f,g,x,m){const p=this.elements;return p[0]=t,p[4]=e,p[8]=n,p[12]=s,p[1]=r,p[5]=a,p[9]=o,p[13]=l,p[2]=c,p[6]=d,p[10]=h,p[14]=u,p[3]=f,p[7]=g,p[11]=x,p[15]=m,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new $a().fromArray(this.elements)}copy(t){const e=this.elements,n=t.elements;return e[0]=n[0],e[1]=n[1],e[2]=n[2],e[3]=n[3],e[4]=n[4],e[5]=n[5],e[6]=n[6],e[7]=n[7],e[8]=n[8],e[9]=n[9],e[10]=n[10],e[11]=n[11],e[12]=n[12],e[13]=n[13],e[14]=n[14],e[15]=n[15],this}copyPosition(t){const e=this.elements,n=t.elements;return e[12]=n[12],e[13]=n[13],e[14]=n[14],this}setFromMatrix3(t){const e=t.elements;return this.set(e[0],e[3],e[6],0,e[1],e[4],e[7],0,e[2],e[5],e[8],0,0,0,0,1),this}extractBasis(t,e,n){return this.determinantAffine()===0?(t.set(1,0,0),e.set(0,1,0),n.set(0,0,1),this):(t.setFromMatrixColumn(this,0),e.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this)}makeBasis(t,e,n){return this.set(t.x,e.x,n.x,0,t.y,e.y,n.y,0,t.z,e.z,n.z,0,0,0,0,1),this}extractRotation(t){if(t.determinantAffine()===0)return this.identity();const e=this.elements,n=t.elements,s=1/cs.setFromMatrixColumn(t,0).length(),r=1/cs.setFromMatrixColumn(t,1).length(),a=1/cs.setFromMatrixColumn(t,2).length();return e[0]=n[0]*s,e[1]=n[1]*s,e[2]=n[2]*s,e[3]=0,e[4]=n[4]*r,e[5]=n[5]*r,e[6]=n[6]*r,e[7]=0,e[8]=n[8]*a,e[9]=n[9]*a,e[10]=n[10]*a,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromEuler(t){const e=this.elements,n=t.x,s=t.y,r=t.z,a=Math.cos(n),o=Math.sin(n),l=Math.cos(s),c=Math.sin(s),d=Math.cos(r),h=Math.sin(r);if(t.order==="XYZ"){const u=a*d,f=a*h,g=o*d,x=o*h;e[0]=l*d,e[4]=-l*h,e[8]=c,e[1]=f+g*c,e[5]=u-x*c,e[9]=-o*l,e[2]=x-u*c,e[6]=g+f*c,e[10]=a*l}else if(t.order==="YXZ"){const u=l*d,f=l*h,g=c*d,x=c*h;e[0]=u+x*o,e[4]=g*o-f,e[8]=a*c,e[1]=a*h,e[5]=a*d,e[9]=-o,e[2]=f*o-g,e[6]=x+u*o,e[10]=a*l}else if(t.order==="ZXY"){const u=l*d,f=l*h,g=c*d,x=c*h;e[0]=u-x*o,e[4]=-a*h,e[8]=g+f*o,e[1]=f+g*o,e[5]=a*d,e[9]=x-u*o,e[2]=-a*c,e[6]=o,e[10]=a*l}else if(t.order==="ZYX"){const u=a*d,f=a*h,g=o*d,x=o*h;e[0]=l*d,e[4]=g*c-f,e[8]=u*c+x,e[1]=l*h,e[5]=x*c+u,e[9]=f*c-g,e[2]=-c,e[6]=o*l,e[10]=a*l}else if(t.order==="YZX"){const u=a*l,f=a*c,g=o*l,x=o*c;e[0]=l*d,e[4]=x-u*h,e[8]=g*h+f,e[1]=h,e[5]=a*d,e[9]=-o*d,e[2]=-c*d,e[6]=f*h+g,e[10]=u-x*h}else if(t.order==="XZY"){const u=a*l,f=a*c,g=o*l,x=o*c;e[0]=l*d,e[4]=-h,e[8]=c*d,e[1]=u*h+x,e[5]=a*d,e[9]=f*h-g,e[2]=g*h-f,e[6]=o*d,e[10]=x*h+u}return e[3]=0,e[7]=0,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromQuaternion(t){return this.compose(Sp,t,wp)}lookAt(t,e,n){const s=this.elements;return ln.subVectors(t,e),ln.lengthSq()===0&&(ln.z=1),ln.normalize(),Mi.crossVectors(n,ln),Mi.lengthSq()===0&&(Math.abs(n.z)===1?ln.x+=1e-4:ln.z+=1e-4,ln.normalize(),Mi.crossVectors(n,ln)),Mi.normalize(),Pr.crossVectors(ln,Mi),s[0]=Mi.x,s[4]=Pr.x,s[8]=ln.x,s[1]=Mi.y,s[5]=Pr.y,s[9]=ln.y,s[2]=Mi.z,s[6]=Pr.z,s[10]=ln.z,this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){const n=t.elements,s=e.elements,r=this.elements,a=n[0],o=n[4],l=n[8],c=n[12],d=n[1],h=n[5],u=n[9],f=n[13],g=n[2],x=n[6],m=n[10],p=n[14],_=n[3],S=n[7],y=n[11],A=n[15],E=s[0],v=s[4],w=s[8],N=s[12],R=s[1],L=s[5],F=s[9],V=s[13],D=s[2],H=s[6],q=s[10],k=s[14],tt=s[3],W=s[7],j=s[11],Q=s[15];return r[0]=a*E+o*R+l*D+c*tt,r[4]=a*v+o*L+l*H+c*W,r[8]=a*w+o*F+l*q+c*j,r[12]=a*N+o*V+l*k+c*Q,r[1]=d*E+h*R+u*D+f*tt,r[5]=d*v+h*L+u*H+f*W,r[9]=d*w+h*F+u*q+f*j,r[13]=d*N+h*V+u*k+f*Q,r[2]=g*E+x*R+m*D+p*tt,r[6]=g*v+x*L+m*H+p*W,r[10]=g*w+x*F+m*q+p*j,r[14]=g*N+x*V+m*k+p*Q,r[3]=_*E+S*R+y*D+A*tt,r[7]=_*v+S*L+y*H+A*W,r[11]=_*w+S*F+y*q+A*j,r[15]=_*N+S*V+y*k+A*Q,this}multiplyScalar(t){const e=this.elements;return e[0]*=t,e[4]*=t,e[8]*=t,e[12]*=t,e[1]*=t,e[5]*=t,e[9]*=t,e[13]*=t,e[2]*=t,e[6]*=t,e[10]*=t,e[14]*=t,e[3]*=t,e[7]*=t,e[11]*=t,e[15]*=t,this}determinant(){const t=this.elements,e=t[0],n=t[4],s=t[8],r=t[12],a=t[1],o=t[5],l=t[9],c=t[13],d=t[2],h=t[6],u=t[10],f=t[14],g=t[3],x=t[7],m=t[11],p=t[15],_=l*f-c*u,S=o*f-c*h,y=o*u-l*h,A=a*f-c*d,E=a*u-l*d,v=a*h-o*d;return e*(x*_-m*S+p*y)-n*(g*_-m*A+p*E)+s*(g*S-x*A+p*v)-r*(g*y-x*E+m*v)}determinantAffine(){const t=this.elements,e=t[0],n=t[4],s=t[8],r=t[1],a=t[5],o=t[9],l=t[2],c=t[6],d=t[10];return e*(a*d-o*c)-n*(r*d-o*l)+s*(r*c-a*l)}transpose(){const t=this.elements;let e;return e=t[1],t[1]=t[4],t[4]=e,e=t[2],t[2]=t[8],t[8]=e,e=t[6],t[6]=t[9],t[9]=e,e=t[3],t[3]=t[12],t[12]=e,e=t[7],t[7]=t[13],t[13]=e,e=t[11],t[11]=t[14],t[14]=e,this}setPosition(t,e,n){const s=this.elements;return t.isVector3?(s[12]=t.x,s[13]=t.y,s[14]=t.z):(s[12]=t,s[13]=e,s[14]=n),this}invert(){const t=this.elements,e=t[0],n=t[1],s=t[2],r=t[3],a=t[4],o=t[5],l=t[6],c=t[7],d=t[8],h=t[9],u=t[10],f=t[11],g=t[12],x=t[13],m=t[14],p=t[15],_=e*o-n*a,S=e*l-s*a,y=e*c-r*a,A=n*l-s*o,E=n*c-r*o,v=s*c-r*l,w=d*x-h*g,N=d*m-u*g,R=d*p-f*g,L=h*m-u*x,F=h*p-f*x,V=u*p-f*m,D=_*V-S*F+y*L+A*R-E*N+v*w;if(D===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const H=1/D;return t[0]=(o*V-l*F+c*L)*H,t[1]=(s*F-n*V-r*L)*H,t[2]=(x*v-m*E+p*A)*H,t[3]=(u*E-h*v-f*A)*H,t[4]=(l*R-a*V-c*N)*H,t[5]=(e*V-s*R+r*N)*H,t[6]=(m*y-g*v-p*S)*H,t[7]=(d*v-u*y+f*S)*H,t[8]=(a*F-o*R+c*w)*H,t[9]=(n*R-e*F-r*w)*H,t[10]=(g*E-x*y+p*_)*H,t[11]=(h*y-d*E-f*_)*H,t[12]=(o*N-a*L-l*w)*H,t[13]=(e*L-n*N+s*w)*H,t[14]=(x*S-g*A-m*_)*H,t[15]=(d*A-h*S+u*_)*H,this}scale(t){const e=this.elements,n=t.x,s=t.y,r=t.z;return e[0]*=n,e[4]*=s,e[8]*=r,e[1]*=n,e[5]*=s,e[9]*=r,e[2]*=n,e[6]*=s,e[10]*=r,e[3]*=n,e[7]*=s,e[11]*=r,this}getMaxScaleOnAxis(){const t=this.elements,e=t[0]*t[0]+t[1]*t[1]+t[2]*t[2],n=t[4]*t[4]+t[5]*t[5]+t[6]*t[6],s=t[8]*t[8]+t[9]*t[9]+t[10]*t[10];return Math.sqrt(Math.max(e,n,s))}makeTranslation(t,e,n){return t.isVector3?this.set(1,0,0,t.x,0,1,0,t.y,0,0,1,t.z,0,0,0,1):this.set(1,0,0,t,0,1,0,e,0,0,1,n,0,0,0,1),this}makeRotationX(t){const e=Math.cos(t),n=Math.sin(t);return this.set(1,0,0,0,0,e,-n,0,0,n,e,0,0,0,0,1),this}makeRotationY(t){const e=Math.cos(t),n=Math.sin(t);return this.set(e,0,n,0,0,1,0,0,-n,0,e,0,0,0,0,1),this}makeRotationZ(t){const e=Math.cos(t),n=Math.sin(t);return this.set(e,-n,0,0,n,e,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(t,e){const n=Math.cos(e),s=Math.sin(e),r=1-n,a=t.x,o=t.y,l=t.z,c=r*a,d=r*o;return this.set(c*a+n,c*o-s*l,c*l+s*o,0,c*o+s*l,d*o+n,d*l-s*a,0,c*l-s*o,d*l+s*a,r*l*l+n,0,0,0,0,1),this}makeScale(t,e,n){return this.set(t,0,0,0,0,e,0,0,0,0,n,0,0,0,0,1),this}makeShear(t,e,n,s,r,a){return this.set(1,n,r,0,t,1,a,0,e,s,1,0,0,0,0,1),this}compose(t,e,n){const s=this.elements,r=e._x,a=e._y,o=e._z,l=e._w,c=r+r,d=a+a,h=o+o,u=r*c,f=r*d,g=r*h,x=a*d,m=a*h,p=o*h,_=l*c,S=l*d,y=l*h,A=n.x,E=n.y,v=n.z;return s[0]=(1-(x+p))*A,s[1]=(f+y)*A,s[2]=(g-S)*A,s[3]=0,s[4]=(f-y)*E,s[5]=(1-(u+p))*E,s[6]=(m+_)*E,s[7]=0,s[8]=(g+S)*v,s[9]=(m-_)*v,s[10]=(1-(u+x))*v,s[11]=0,s[12]=t.x,s[13]=t.y,s[14]=t.z,s[15]=1,this}decompose(t,e,n){const s=this.elements;t.x=s[12],t.y=s[13],t.z=s[14];const r=this.determinantAffine();if(r===0)return n.set(1,1,1),e.identity(),this;let a=cs.set(s[0],s[1],s[2]).length();const o=cs.set(s[4],s[5],s[6]).length(),l=cs.set(s[8],s[9],s[10]).length();r<0&&(a=-a),En.copy(this);const c=1/a,d=1/o,h=1/l;return En.elements[0]*=c,En.elements[1]*=c,En.elements[2]*=c,En.elements[4]*=d,En.elements[5]*=d,En.elements[6]*=d,En.elements[8]*=h,En.elements[9]*=h,En.elements[10]*=h,e.setFromRotationMatrix(En),n.x=a,n.y=o,n.z=l,this}makePerspective(t,e,n,s,r,a,o=Ln,l=!1){const c=this.elements,d=2*r/(e-t),h=2*r/(n-s),u=(e+t)/(e-t),f=(n+s)/(n-s);let g,x;if(l)g=r/(a-r),x=a*r/(a-r);else if(o===Ln)g=-(a+r)/(a-r),x=-2*a*r/(a-r);else if(o===xr)g=-a/(a-r),x=-a*r/(a-r);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+o);return c[0]=d,c[4]=0,c[8]=u,c[12]=0,c[1]=0,c[5]=h,c[9]=f,c[13]=0,c[2]=0,c[6]=0,c[10]=g,c[14]=x,c[3]=0,c[7]=0,c[11]=-1,c[15]=0,this}makeOrthographic(t,e,n,s,r,a,o=Ln,l=!1){const c=this.elements,d=2/(e-t),h=2/(n-s),u=-(e+t)/(e-t),f=-(n+s)/(n-s);let g,x;if(l)g=1/(a-r),x=a/(a-r);else if(o===Ln)g=-2/(a-r),x=-(a+r)/(a-r);else if(o===xr)g=-1/(a-r),x=-r/(a-r);else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+o);return c[0]=d,c[4]=0,c[8]=0,c[12]=u,c[1]=0,c[5]=h,c[9]=0,c[13]=f,c[2]=0,c[6]=0,c[10]=g,c[14]=x,c[3]=0,c[7]=0,c[11]=0,c[15]=1,this}equals(t){const e=this.elements,n=t.elements;for(let s=0;s<16;s++)if(e[s]!==n[s])return!1;return!0}fromArray(t,e=0){for(let n=0;n<16;n++)this.elements[n]=t[n+e];return this}toArray(t=[],e=0){const n=this.elements;return t[e]=n[0],t[e+1]=n[1],t[e+2]=n[2],t[e+3]=n[3],t[e+4]=n[4],t[e+5]=n[5],t[e+6]=n[6],t[e+7]=n[7],t[e+8]=n[8],t[e+9]=n[9],t[e+10]=n[10],t[e+11]=n[11],t[e+12]=n[12],t[e+13]=n[13],t[e+14]=n[14],t[e+15]=n[15],t}};$a.prototype.isMatrix4=!0;let jt=$a;const cs=new I,En=new jt,Sp=new I(0,0,0),wp=new I(1,1,1),Mi=new I,Pr=new I,ln=new I,nd=new jt,id=new xi;class kn{constructor(t=0,e=0,n=0,s=kn.DEFAULT_ORDER){this.isEuler=!0,this._x=t,this._y=e,this._z=n,this._order=s}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get order(){return this._order}set order(t){this._order=t,this._onChangeCallback()}set(t,e,n,s=this._order){return this._x=t,this._y=e,this._z=n,this._order=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(t){return this._x=t._x,this._y=t._y,this._z=t._z,this._order=t._order,this._onChangeCallback(),this}setFromRotationMatrix(t,e=this._order,n=!0){const s=t.elements,r=s[0],a=s[4],o=s[8],l=s[1],c=s[5],d=s[9],h=s[2],u=s[6],f=s[10];switch(e){case"XYZ":this._y=Math.asin(Kt(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(-d,f),this._z=Math.atan2(-a,r)):(this._x=Math.atan2(u,c),this._z=0);break;case"YXZ":this._x=Math.asin(-Kt(d,-1,1)),Math.abs(d)<.9999999?(this._y=Math.atan2(o,f),this._z=Math.atan2(l,c)):(this._y=Math.atan2(-h,r),this._z=0);break;case"ZXY":this._x=Math.asin(Kt(u,-1,1)),Math.abs(u)<.9999999?(this._y=Math.atan2(-h,f),this._z=Math.atan2(-a,c)):(this._y=0,this._z=Math.atan2(l,r));break;case"ZYX":this._y=Math.asin(-Kt(h,-1,1)),Math.abs(h)<.9999999?(this._x=Math.atan2(u,f),this._z=Math.atan2(l,r)):(this._x=0,this._z=Math.atan2(-a,c));break;case"YZX":this._z=Math.asin(Kt(l,-1,1)),Math.abs(l)<.9999999?(this._x=Math.atan2(-d,c),this._y=Math.atan2(-h,r)):(this._x=0,this._y=Math.atan2(o,f));break;case"XZY":this._z=Math.asin(-Kt(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(u,c),this._y=Math.atan2(o,r)):(this._x=Math.atan2(-d,f),this._y=0);break;default:Lt("Euler: .setFromRotationMatrix() encountered an unknown order: "+e)}return this._order=e,n===!0&&this._onChangeCallback(),this}setFromQuaternion(t,e,n){return nd.makeRotationFromQuaternion(t),this.setFromRotationMatrix(nd,e,n)}setFromVector3(t,e=this._order){return this.set(t.x,t.y,t.z,e)}reorder(t){return id.setFromEuler(this),this.setFromQuaternion(id,t)}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._order===this._order}fromArray(t){return this._x=t[0],this._y=t[1],this._z=t[2],t[3]!==void 0&&(this._order=t[3]),this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._order,t}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}kn.DEFAULT_ORDER="XYZ";class dc{constructor(){this.mask=1}set(t){this.mask=(1<<t|0)>>>0}enable(t){this.mask|=1<<t|0}enableAll(){this.mask=-1}toggle(t){this.mask^=1<<t|0}disable(t){this.mask&=~(1<<t|0)}disableAll(){this.mask=0}test(t){return(this.mask&t.mask)!==0}isEnabled(t){return(this.mask&(1<<t|0))!==0}}let Ep=0;const sd=new I,ds=new xi,ei=new jt,Lr=new I,Vs=new I,Ap=new I,Tp=new xi,rd=new I(1,0,0),ad=new I(0,1,0),od=new I(0,0,1),ld={type:"added"},Rp={type:"removed"},hs={type:"childadded",child:null},fo={type:"childremoved",child:null};class Ae extends ns{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:Ep++}),this.uuid=Fi(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=Ae.DEFAULT_UP.clone();const t=new I,e=new kn,n=new xi,s=new I(1,1,1);function r(){n.setFromEuler(e,!1)}function a(){e.setFromQuaternion(n,void 0,!1)}e._onChange(r),n._onChange(a),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:t},rotation:{configurable:!0,enumerable:!0,value:e},quaternion:{configurable:!0,enumerable:!0,value:n},scale:{configurable:!0,enumerable:!0,value:s},modelViewMatrix:{value:new jt},normalMatrix:{value:new Ot}}),this.matrix=new jt,this.matrixWorld=new jt,this.matrixAutoUpdate=Ae.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=Ae.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new dc,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.static=!1,this.userData={},this.pivot=null}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(t){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(t),this.matrix.decompose(this.position,this.quaternion,this.scale),this.pivot!==null&&this.position.copy(this.pivot).applyMatrix4(this.matrix).sub(this.pivot)}applyQuaternion(t){return this.quaternion.premultiply(t),this}setRotationFromAxisAngle(t,e){this.quaternion.setFromAxisAngle(t,e)}setRotationFromEuler(t){this.quaternion.setFromEuler(t,!0)}setRotationFromMatrix(t){this.quaternion.setFromRotationMatrix(t)}setRotationFromQuaternion(t){this.quaternion.copy(t)}rotateOnAxis(t,e){return ds.setFromAxisAngle(t,e),this.quaternion.multiply(ds),this}rotateOnWorldAxis(t,e){return ds.setFromAxisAngle(t,e),this.quaternion.premultiply(ds),this}rotateX(t){return this.rotateOnAxis(rd,t)}rotateY(t){return this.rotateOnAxis(ad,t)}rotateZ(t){return this.rotateOnAxis(od,t)}translateOnAxis(t,e){return sd.copy(t).applyQuaternion(this.quaternion),this.position.add(sd.multiplyScalar(e)),this}translateX(t){return this.translateOnAxis(rd,t)}translateY(t){return this.translateOnAxis(ad,t)}translateZ(t){return this.translateOnAxis(od,t)}localToWorld(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(this.matrixWorld)}worldToLocal(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(ei.copy(this.matrixWorld).invert())}lookAt(t,e,n){t.isVector3?Lr.copy(t):Lr.set(t,e,n);const s=this.parent;this.updateWorldMatrix(!0,!1),Vs.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?ei.lookAt(Vs,Lr,this.up):ei.lookAt(Lr,Vs,this.up),this.quaternion.setFromRotationMatrix(ei),s&&(ei.extractRotation(s.matrixWorld),ds.setFromRotationMatrix(ei),this.quaternion.premultiply(ds.invert()))}add(t){if(arguments.length>1){for(let e=0;e<arguments.length;e++)this.add(arguments[e]);return this}return t===this?(ee("Object3D.add: object can't be added as a child of itself.",t),this):(t&&t.isObject3D?(t.removeFromParent(),t.parent=this,this.children.push(t),t.dispatchEvent(ld),hs.child=t,this.dispatchEvent(hs),hs.child=null):ee("Object3D.add: object not an instance of THREE.Object3D.",t),this)}remove(t){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.remove(arguments[n]);return this}const e=this.children.indexOf(t);return e!==-1&&(t.parent=null,this.children.splice(e,1),t.dispatchEvent(Rp),fo.child=t,this.dispatchEvent(fo),fo.child=null),this}removeFromParent(){const t=this.parent;return t!==null&&t.remove(this),this}clear(){return this.remove(...this.children)}attach(t){return this.updateWorldMatrix(!0,!1),ei.copy(this.matrixWorld).invert(),t.parent!==null&&(t.parent.updateWorldMatrix(!0,!1),ei.multiply(t.parent.matrixWorld)),t.applyMatrix4(ei),t.removeFromParent(),t.parent=this,this.children.push(t),t.updateWorldMatrix(!1,!0),t.dispatchEvent(ld),hs.child=t,this.dispatchEvent(hs),hs.child=null,this}getObjectById(t){return this.getObjectByProperty("id",t)}getObjectByName(t){return this.getObjectByProperty("name",t)}getObjectByProperty(t,e){if(this[t]===e)return this;for(let n=0,s=this.children.length;n<s;n++){const a=this.children[n].getObjectByProperty(t,e);if(a!==void 0)return a}}getObjectsByProperty(t,e,n=[]){this[t]===e&&n.push(this);const s=this.children;for(let r=0,a=s.length;r<a;r++)s[r].getObjectsByProperty(t,e,n);return n}getWorldPosition(t){return this.updateWorldMatrix(!0,!1),t.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Vs,t,Ap),t}getWorldScale(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Vs,Tp,t),t}getWorldDirection(t){this.updateWorldMatrix(!0,!1);const e=this.matrixWorld.elements;return t.set(e[8],e[9],e[10]).normalize()}raycast(){}intersectsFrustum(){return!0}traverse(t){t(this);const e=this.children;for(let n=0,s=e.length;n<s;n++)e[n].traverse(t)}traverseVisible(t){if(this.visible===!1)return;t(this);const e=this.children;for(let n=0,s=e.length;n<s;n++)e[n].traverseVisible(t)}traverseAncestors(t){const e=this.parent;e!==null&&(t(e),e.traverseAncestors(t))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale);const t=this.pivot;if(t!==null){const e=t.x,n=t.y,s=t.z,r=this.matrix.elements;r[12]+=e-r[0]*e-r[4]*n-r[8]*s,r[13]+=n-r[1]*e-r[5]*n-r[9]*s,r[14]+=s-r[2]*e-r[6]*n-r[10]*s}this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(t){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||t)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,t=!0);const e=this.children;for(let n=0,s=e.length;n<s;n++)e[n].updateMatrixWorld(t)}updateWorldMatrix(t,e,n=!1){const s=this.parent;if(t===!0&&s!==null&&s.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||n)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,n=!0),e===!0){const r=this.children;for(let a=0,o=r.length;a<o;a++)r[a].updateWorldMatrix(!1,!0,n)}}toJSON(t){const e=t===void 0||typeof t=="string",n={};e&&(t={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.7,type:"Object",generator:"Object3D.toJSON"});const s={};s.uuid=this.uuid,s.type=this.type,s.name=this.name,s.castShadow=this.castShadow,s.receiveShadow=this.receiveShadow,s.visible=this.visible,s.frustumCulled=this.frustumCulled,s.renderOrder=this.renderOrder,s.static=this.static,s.matrixAutoUpdate=this.matrixAutoUpdate,Object.keys(this.userData).length>0&&(s.userData=this.userData),s.layers=this.layers.mask,s.matrix=this.matrix.toArray(),s.up=this.up.toArray(),this.pivot!==null&&(s.pivot=this.pivot.toArray()),this.morphTargetDictionary!==void 0&&(s.morphTargetDictionary=Object.assign({},this.morphTargetDictionary)),this.morphTargetInfluences!==void 0&&(s.morphTargetInfluences=this.morphTargetInfluences.slice()),this.isInstancedMesh&&(s.type="InstancedMesh",s.count=this.count,s.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(s.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(s.type="BatchedMesh",s.perObjectFrustumCulled=this.perObjectFrustumCulled,s.sortObjects=this.sortObjects,s.drawRanges=this._drawRanges,s.reservedRanges=this._reservedRanges,s.geometryInfo=this._geometryInfo.map(o=>({...o,boundingBox:o.boundingBox?o.boundingBox.toJSON():void 0,boundingSphere:o.boundingSphere?o.boundingSphere.toJSON():void 0})),s.instanceInfo=this._instanceInfo.map(o=>({...o})),s.availableInstanceIds=this._availableInstanceIds.slice(),s.availableGeometryIds=this._availableGeometryIds.slice(),s.nextIndexStart=this._nextIndexStart,s.nextVertexStart=this._nextVertexStart,s.geometryCount=this._geometryCount,s.maxInstanceCount=this._maxInstanceCount,s.maxVertexCount=this._maxVertexCount,s.maxIndexCount=this._maxIndexCount,s.geometryInitialized=this._geometryInitialized,s.matricesTexture=this._matricesTexture.toJSON(t),s.indirectTexture=this._indirectTexture.toJSON(t),this._colorsTexture!==null&&(s.colorsTexture=this._colorsTexture.toJSON(t)),this.boundingSphere!==null&&(s.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(s.boundingBox=this.boundingBox.toJSON()));function r(o,l){return o[l.uuid]===void 0&&(o[l.uuid]=l.toJSON(t)),l.uuid}if(this.isScene)this.background&&(this.background.isColor?s.background=this.background.toJSON():this.background.isTexture&&(s.background=this.background.toJSON(t).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(s.environment=this.environment.toJSON(t).uuid);else if(this.isMesh||this.isLine||this.isPoints){s.geometry=r(t.geometries,this.geometry);const o=this.geometry.parameters;if(o!==void 0&&o.shapes!==void 0){const l=o.shapes;if(Array.isArray(l))for(let c=0,d=l.length;c<d;c++){const h=l[c];r(t.shapes,h)}else r(t.shapes,l)}}if(this.isSkinnedMesh&&(s.bindMode=this.bindMode,s.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(r(t.skeletons,this.skeleton),s.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const o=[];for(let l=0,c=this.material.length;l<c;l++)o.push(r(t.materials,this.material[l]));s.material=o}else s.material=r(t.materials,this.material);if(this.children.length>0){s.children=[];for(let o=0;o<this.children.length;o++)s.children.push(this.children[o].toJSON(t).object)}if(this.animations.length>0){s.animations=[];for(let o=0;o<this.animations.length;o++){const l=this.animations[o];s.animations.push(r(t.animations,l))}}if(e){const o=a(t.geometries),l=a(t.materials),c=a(t.textures),d=a(t.images),h=a(t.shapes),u=a(t.skeletons),f=a(t.animations),g=a(t.nodes);o.length>0&&(n.geometries=o),l.length>0&&(n.materials=l),c.length>0&&(n.textures=c),d.length>0&&(n.images=d),h.length>0&&(n.shapes=h),u.length>0&&(n.skeletons=u),f.length>0&&(n.animations=f),g.length>0&&(n.nodes=g)}return n.object=s,n;function a(o){const l=[];for(const c in o){const d=o[c];delete d.metadata,l.push(d)}return l}}clone(t){return new this.constructor().copy(this,t)}copy(t,e=!0){if(this.name=t.name,this.up.copy(t.up),this.position.copy(t.position),this.rotation.order=t.rotation.order,this.quaternion.copy(t.quaternion),this.scale.copy(t.scale),this.pivot=t.pivot!==null?t.pivot.clone():null,this.matrix.copy(t.matrix),this.matrixWorld.copy(t.matrixWorld),this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrixWorldAutoUpdate=t.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=t.matrixWorldNeedsUpdate,this.layers.mask=t.layers.mask,this.visible=t.visible,this.castShadow=t.castShadow,this.receiveShadow=t.receiveShadow,this.frustumCulled=t.frustumCulled,this.renderOrder=t.renderOrder,this.static=t.static,this.animations=t.animations.slice(),this.userData=JSON.parse(JSON.stringify(t.userData)),e===!0)for(let n=0;n<t.children.length;n++){const s=t.children[n];this.add(s.clone())}return this}dispose(){this.dispatchEvent({type:"dispose"})}}Ae.DEFAULT_UP=new I(0,1,0);Ae.DEFAULT_MATRIX_AUTO_UPDATE=!0;Ae.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;class Ce extends Ae{constructor(){super(),this.isGroup=!0,this.type="Group"}}const Cp={type:"move"};class po{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new Ce,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new Ce,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new I,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new I),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new Ce,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new I,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new I,this._grip.eventsEnabled=!1),this._grip}dispatchEvent(t){return this._targetRay!==null&&this._targetRay.dispatchEvent(t),this._grip!==null&&this._grip.dispatchEvent(t),this._hand!==null&&this._hand.dispatchEvent(t),this}connect(t){if(t&&t.hand){const e=this._hand;if(e)for(const n of t.hand.values())this._getHandJoint(e,n)}return this.dispatchEvent({type:"connected",data:t}),this}disconnect(t){return this.dispatchEvent({type:"disconnected",data:t}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(t,e,n){let s=null,r=null,a=null;const o=this._targetRay,l=this._grip,c=this._hand;if(t&&e.session.visibilityState!=="visible-blurred"){if(c&&t.hand){a=!0;for(const x of t.hand.values()){const m=e.getJointPose(x,n),p=this._getHandJoint(c,x);m!==null&&(p.matrix.fromArray(m.transform.matrix),p.matrix.decompose(p.position,p.quaternion,p.scale),p.matrixWorldNeedsUpdate=!0,p.jointRadius=m.radius),p.visible=m!==null}const d=c.joints["index-finger-tip"],h=c.joints["thumb-tip"],u=d.position.distanceTo(h.position),f=.02,g=.005;c.inputState.pinching&&u>f+g?(c.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:t.handedness,target:this})):!c.inputState.pinching&&u<=f-g&&(c.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:t.handedness,target:this}))}else l!==null&&t.gripSpace&&(r=e.getPose(t.gripSpace,n),r!==null&&(l.matrix.fromArray(r.transform.matrix),l.matrix.decompose(l.position,l.quaternion,l.scale),l.matrixWorldNeedsUpdate=!0,r.linearVelocity?(l.hasLinearVelocity=!0,l.linearVelocity.copy(r.linearVelocity)):l.hasLinearVelocity=!1,r.angularVelocity?(l.hasAngularVelocity=!0,l.angularVelocity.copy(r.angularVelocity)):l.hasAngularVelocity=!1,l.eventsEnabled&&l.dispatchEvent({type:"gripUpdated",data:t,target:this})));o!==null&&(s=e.getPose(t.targetRaySpace,n),s===null&&r!==null&&(s=r),s!==null&&(o.matrix.fromArray(s.transform.matrix),o.matrix.decompose(o.position,o.quaternion,o.scale),o.matrixWorldNeedsUpdate=!0,s.linearVelocity?(o.hasLinearVelocity=!0,o.linearVelocity.copy(s.linearVelocity)):o.hasLinearVelocity=!1,s.angularVelocity?(o.hasAngularVelocity=!0,o.angularVelocity.copy(s.angularVelocity)):o.hasAngularVelocity=!1,this.dispatchEvent(Cp)))}return o!==null&&(o.visible=s!==null),l!==null&&(l.visible=r!==null),c!==null&&(c.visible=a!==null),this}_getHandJoint(t,e){if(t.joints[e.jointName]===void 0){const n=new Ce;n.matrixAutoUpdate=!1,n.visible=!1,t.joints[e.jointName]=n,t.add(n)}return t.joints[e.jointName]}}const gu={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},Si={h:0,s:0,l:0},Dr={h:0,s:0,l:0};function mo(i,t,e){return e<0&&(e+=1),e>1&&(e-=1),e<1/6?i+(t-i)*6*e:e<1/2?t:e<2/3?i+(t-i)*6*(2/3-e):i}class Nt{constructor(t,e,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(t,e,n)}set(t,e,n){if(e===void 0&&n===void 0){const s=t;s&&s.isColor?this.copy(s):typeof s=="number"?this.setHex(s):typeof s=="string"&&this.setStyle(s)}else this.setRGB(t,e,n);return this}setScalar(t){return this.r=t,this.g=t,this.b=t,this}setHex(t,e=He){return t=Math.floor(t),this.r=(t>>16&255)/255,this.g=(t>>8&255)/255,this.b=(t&255)/255,Jt.colorSpaceToWorking(this,e),this}setRGB(t,e,n,s=Jt.workingColorSpace){return this.r=t,this.g=e,this.b=n,Jt.colorSpaceToWorking(this,s),this}setHSL(t,e,n,s=Jt.workingColorSpace){if(t=ac(t,1),e=Kt(e,0,1),n=Kt(n,0,1),e===0)this.r=this.g=this.b=n;else{const r=n<=.5?n*(1+e):n+e-n*e,a=2*n-r;this.r=mo(a,r,t+1/3),this.g=mo(a,r,t),this.b=mo(a,r,t-1/3)}return Jt.colorSpaceToWorking(this,s),this}setStyle(t,e=He){function n(r){r!==void 0&&parseFloat(r)<1&&Lt("Color: Alpha component of "+t+" will be ignored.")}let s;if(s=/^(\w+)\(([^\)]*)\)/.exec(t)){let r;const a=s[1],o=s[2];switch(a){case"rgb":case"rgba":if(r=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d+(?:\.\d+)?|\.\d+)\s*)?$/.exec(o))return n(r[4]),this.setRGB(Math.min(255,parseInt(r[1],10))/255,Math.min(255,parseInt(r[2],10))/255,Math.min(255,parseInt(r[3],10))/255,e);if(r=/^\s*(\d+(?:\.\d+)?|\.\d+)\%\s*,\s*(\d+(?:\.\d+)?|\.\d+)\%\s*,\s*(\d+(?:\.\d+)?|\.\d+)\%\s*(?:,\s*(\d+(?:\.\d+)?|\.\d+)\s*)?$/.exec(o))return n(r[4]),this.setRGB(Math.min(100,parseFloat(r[1]))/100,Math.min(100,parseFloat(r[2]))/100,Math.min(100,parseFloat(r[3]))/100,e);break;case"hsl":case"hsla":if(r=/^\s*([+-]?(?:\d+(?:\.\d+)?|\.\d+))\s*,\s*(\d+(?:\.\d+)?|\.\d+)\%\s*,\s*(\d+(?:\.\d+)?|\.\d+)\%\s*(?:,\s*(\d+(?:\.\d+)?|\.\d+)\s*)?$/.exec(o))return n(r[4]),this.setHSL(parseFloat(r[1])/360,parseFloat(r[2])/100,parseFloat(r[3])/100,e);break;default:Lt("Color: Unknown color model "+t)}}else if(s=/^\#([A-Fa-f\d]+)$/.exec(t)){const r=s[1],a=r.length;if(a===3)return this.setRGB(parseInt(r.charAt(0),16)/15,parseInt(r.charAt(1),16)/15,parseInt(r.charAt(2),16)/15,e);if(a===6)return this.setHex(parseInt(r,16),e);Lt("Color: Invalid hex color "+t)}else if(t&&t.length>0)return this.setColorName(t,e);return this}setColorName(t,e=He){const n=gu[t.toLowerCase()];return n!==void 0?this.setHex(n,e):Lt("Color: Unknown color "+t),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(t){return this.r=t.r,this.g=t.g,this.b=t.b,this}copySRGBToLinear(t){return this.r=gi(t.r),this.g=gi(t.g),this.b=gi(t.b),this}copyLinearToSRGB(t){return this.r=Ls(t.r),this.g=Ls(t.g),this.b=Ls(t.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(t=He){return Jt.workingToColorSpace(Xe.copy(this),t),Math.round(Kt(Xe.r*255,0,255))*65536+Math.round(Kt(Xe.g*255,0,255))*256+Math.round(Kt(Xe.b*255,0,255))}getHexString(t=He){return("000000"+this.getHex(t).toString(16)).slice(-6)}getHSL(t,e=Jt.workingColorSpace){Jt.workingToColorSpace(Xe.copy(this),e);const n=Xe.r,s=Xe.g,r=Xe.b,a=Math.max(n,s,r),o=Math.min(n,s,r);let l,c;const d=(o+a)/2;if(o===a)l=0,c=0;else{const h=a-o;switch(c=d<=.5?h/(a+o):h/(2-a-o),a){case n:l=(s-r)/h+(s<r?6:0);break;case s:l=(r-n)/h+2;break;case r:l=(n-s)/h+4;break}l/=6}return t.h=l,t.s=c,t.l=d,t}getRGB(t,e=Jt.workingColorSpace){return Jt.workingToColorSpace(Xe.copy(this),e),t.r=Xe.r,t.g=Xe.g,t.b=Xe.b,t}getStyle(t=He){Jt.workingToColorSpace(Xe.copy(this),t);const e=Xe.r,n=Xe.g,s=Xe.b;return t!==He?`color(${t} ${e.toFixed(3)} ${n.toFixed(3)} ${s.toFixed(3)})`:`rgb(${Math.round(e*255)},${Math.round(n*255)},${Math.round(s*255)})`}offsetHSL(t,e,n){return this.getHSL(Si),this.setHSL(Si.h+t,Si.s+e,Si.l+n)}add(t){return this.r+=t.r,this.g+=t.g,this.b+=t.b,this}addColors(t,e){return this.r=t.r+e.r,this.g=t.g+e.g,this.b=t.b+e.b,this}addScalar(t){return this.r+=t,this.g+=t,this.b+=t,this}sub(t){return this.r=Math.max(0,this.r-t.r),this.g=Math.max(0,this.g-t.g),this.b=Math.max(0,this.b-t.b),this}multiply(t){return this.r*=t.r,this.g*=t.g,this.b*=t.b,this}multiplyScalar(t){return this.r*=t,this.g*=t,this.b*=t,this}lerp(t,e){return this.r+=(t.r-this.r)*e,this.g+=(t.g-this.g)*e,this.b+=(t.b-this.b)*e,this}lerpColors(t,e,n){return this.r=t.r+(e.r-t.r)*n,this.g=t.g+(e.g-t.g)*n,this.b=t.b+(e.b-t.b)*n,this}lerpHSL(t,e){this.getHSL(Si),t.getHSL(Dr);const n=dr(Si.h,Dr.h,e),s=dr(Si.s,Dr.s,e),r=dr(Si.l,Dr.l,e);return this.setHSL(n,s,r),this}setFromVector3(t){return this.r=t.x,this.g=t.y,this.b=t.z,this}applyMatrix3(t){const e=this.r,n=this.g,s=this.b,r=t.elements;return this.r=r[0]*e+r[3]*n+r[6]*s,this.g=r[1]*e+r[4]*n+r[7]*s,this.b=r[2]*e+r[5]*n+r[8]*s,this}equals(t){return t.r===this.r&&t.g===this.g&&t.b===this.b}fromArray(t,e=0){return this.r=t[e],this.g=t[e+1],this.b=t[e+2],this}toArray(t=[],e=0){return t[e]=this.r,t[e+1]=this.g,t[e+2]=this.b,t}fromBufferAttribute(t,e){return this.r=t.getX(e),this.g=t.getY(e),this.b=t.getZ(e),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const Xe=new Nt;Nt.NAMES=gu;class hc extends Ae{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new kn,this.environmentIntensity=1,this.environmentRotation=new kn,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(t,e){return super.copy(t,e),this.background=t.background!==null?t.background.clone():null,this.environment=t.environment!==null?t.environment.clone():null,this.fog=t.fog!==null?t.fog.clone():null,this.backgroundBlurriness=t.backgroundBlurriness,this.backgroundIntensity=t.backgroundIntensity,this.backgroundRotation.copy(t.backgroundRotation),this.environmentIntensity=t.environmentIntensity,this.environmentRotation.copy(t.environmentRotation),this.overrideMaterial=t.overrideMaterial!==null?t.overrideMaterial.clone():null,this.matrixAutoUpdate=t.matrixAutoUpdate,this}toJSON(t){const e=super.toJSON(t);return this.fog!==null&&(e.object.fog=this.fog.toJSON()),e.object.backgroundBlurriness=this.backgroundBlurriness,e.object.backgroundIntensity=this.backgroundIntensity,e.object.backgroundRotation=this.backgroundRotation.toArray(),e.object.environmentIntensity=this.environmentIntensity,e.object.environmentRotation=this.environmentRotation.toArray(),e}}const An=new I,ni=new I,go=new I,ii=new I,us=new I,fs=new I,cd=new I,vo=new I,xo=new I,_o=new I,yo=new _e,bo=new _e,Mo=new _e;class hn{constructor(t=new I,e=new I,n=new I){this.a=t,this.b=e,this.c=n}static getNormal(t,e,n,s){s.subVectors(n,e),An.subVectors(t,e),s.cross(An);const r=s.lengthSq();return r>0?s.multiplyScalar(1/Math.sqrt(r)):s.set(0,0,0)}static getBarycoord(t,e,n,s,r){An.subVectors(s,e),ni.subVectors(n,e),go.subVectors(t,e);const a=An.dot(An),o=An.dot(ni),l=An.dot(go),c=ni.dot(ni),d=ni.dot(go),h=a*c-o*o;if(h===0)return r.set(0,0,0),null;const u=1/h,f=(c*l-o*d)*u,g=(a*d-o*l)*u;return r.set(1-f-g,g,f)}static containsPoint(t,e,n,s){return this.getBarycoord(t,e,n,s,ii)===null?!1:ii.x>=0&&ii.y>=0&&ii.x+ii.y<=1}static getInterpolation(t,e,n,s,r,a,o,l){return this.getBarycoord(t,e,n,s,ii)===null?(l.x=0,l.y=0,"z"in l&&(l.z=0),"w"in l&&(l.w=0),null):(l.setScalar(0),l.addScaledVector(r,ii.x),l.addScaledVector(a,ii.y),l.addScaledVector(o,ii.z),l)}static getInterpolatedAttribute(t,e,n,s,r,a){return yo.setScalar(0),bo.setScalar(0),Mo.setScalar(0),yo.fromBufferAttribute(t,e),bo.fromBufferAttribute(t,n),Mo.fromBufferAttribute(t,s),a.setScalar(0),a.addScaledVector(yo,r.x),a.addScaledVector(bo,r.y),a.addScaledVector(Mo,r.z),a}static isFrontFacing(t,e,n,s){return An.subVectors(n,e),ni.subVectors(t,e),An.cross(ni).dot(s)<0}set(t,e,n){return this.a.copy(t),this.b.copy(e),this.c.copy(n),this}setFromPointsAndIndices(t,e,n,s){return this.a.copy(t[e]),this.b.copy(t[n]),this.c.copy(t[s]),this}setFromAttributeAndIndices(t,e,n,s){return this.a.fromBufferAttribute(t,e),this.b.fromBufferAttribute(t,n),this.c.fromBufferAttribute(t,s),this}clone(){return new this.constructor().copy(this)}copy(t){return this.a.copy(t.a),this.b.copy(t.b),this.c.copy(t.c),this}getArea(){return An.subVectors(this.c,this.b),ni.subVectors(this.a,this.b),An.cross(ni).length()*.5}getMidpoint(t){return t.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(t){return hn.getNormal(this.a,this.b,this.c,t)}getPlane(t){return t.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(t,e){return hn.getBarycoord(t,this.a,this.b,this.c,e)}getInterpolation(t,e,n,s,r){return hn.getInterpolation(t,this.a,this.b,this.c,e,n,s,r)}containsPoint(t){return hn.containsPoint(t,this.a,this.b,this.c)}isFrontFacing(t){return hn.isFrontFacing(this.a,this.b,this.c,t)}intersectsBox(t){return t.intersectsTriangle(this)}closestPointToPoint(t,e){const n=this.a,s=this.b,r=this.c;let a,o;us.subVectors(s,n),fs.subVectors(r,n),vo.subVectors(t,n);const l=us.dot(vo),c=fs.dot(vo);if(l<=0&&c<=0)return e.copy(n);xo.subVectors(t,s);const d=us.dot(xo),h=fs.dot(xo);if(d>=0&&h<=d)return e.copy(s);const u=l*h-d*c;if(u<=0&&l>=0&&d<=0&&l-d>0)return a=l/(l-d),e.copy(n).addScaledVector(us,a);_o.subVectors(t,r);const f=us.dot(_o),g=fs.dot(_o);if(g>=0&&f<=g)return e.copy(r);const x=f*c-l*g;if(x<=0&&c>=0&&g<=0)return o=c/(c-g),e.copy(n).addScaledVector(fs,o);const m=d*g-f*h;if(m<=0&&h-d>=0&&f-g>=0)return cd.subVectors(r,s),o=(h-d)/(h-d+(f-g)),e.copy(s).addScaledVector(cd,o);const p=1/(m+x+u);return a=x*p,o=u*p,e.copy(n).addScaledVector(us,a).addScaledVector(fs,o)}equals(t){return t.a.equals(this.a)&&t.b.equals(this.b)&&t.c.equals(this.c)}}class is{constructor(t=new I(1/0,1/0,1/0),e=new I(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=t,this.max=e}set(t,e){return this.min.copy(t),this.max.copy(e),this}setFromArray(t){this.makeEmpty();for(let e=0,n=t.length;e<n;e+=3)this.expandByPoint(Tn.fromArray(t,e));return this}setFromBufferAttribute(t){this.makeEmpty();for(let e=0,n=t.count;e<n;e++)this.expandByPoint(Tn.fromBufferAttribute(t,e));return this}setFromPoints(t){this.makeEmpty();for(let e=0,n=t.length;e<n;e++)this.expandByPoint(t[e]);return this}setFromCenterAndSize(t,e){const n=Tn.copy(e).multiplyScalar(.5);return this.min.copy(t).sub(n),this.max.copy(t).add(n),this}setFromObject(t,e=!1){return this.makeEmpty(),this.expandByObject(t,e)}clone(){return new this.constructor().copy(this)}copy(t){return this.min.copy(t.min),this.max.copy(t.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(t){return this.isEmpty()?t.set(0,0,0):t.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(t){return this.isEmpty()?t.set(0,0,0):t.subVectors(this.max,this.min)}expandByPoint(t){return this.min.min(t),this.max.max(t),this}expandByVector(t){return this.min.sub(t),this.max.add(t),this}expandByScalar(t){return this.min.addScalar(-t),this.max.addScalar(t),this}expandByObject(t,e=!1){t.updateWorldMatrix(!1,!1);const n=t.geometry;if(n!==void 0){const r=n.getAttribute("position");if(e===!0&&r!==void 0&&t.isInstancedMesh!==!0&&t.isBatchedMesh!==!0)for(let a=0,o=r.count;a<o;a++)t.isMesh===!0?t.getVertexPosition(a,Tn):Tn.fromBufferAttribute(r,a),Tn.applyMatrix4(t.matrixWorld),this.expandByPoint(Tn);else t.boundingBox!==void 0?(t.boundingBox===null&&t.computeBoundingBox(),Ir.copy(t.boundingBox)):(n.boundingBox===null&&n.computeBoundingBox(),Ir.copy(n.boundingBox)),Ir.applyMatrix4(t.matrixWorld),this.union(Ir)}const s=t.children;for(let r=0,a=s.length;r<a;r++)this.expandByObject(s[r],e);return this}containsPoint(t){return t.x>=this.min.x&&t.x<=this.max.x&&t.y>=this.min.y&&t.y<=this.max.y&&t.z>=this.min.z&&t.z<=this.max.z}containsBox(t){return this.min.x<=t.min.x&&t.max.x<=this.max.x&&this.min.y<=t.min.y&&t.max.y<=this.max.y&&this.min.z<=t.min.z&&t.max.z<=this.max.z}getParameter(t,e){return e.set((t.x-this.min.x)/(this.max.x-this.min.x),(t.y-this.min.y)/(this.max.y-this.min.y),(t.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(t){return t.max.x>=this.min.x&&t.min.x<=this.max.x&&t.max.y>=this.min.y&&t.min.y<=this.max.y&&t.max.z>=this.min.z&&t.min.z<=this.max.z}intersectsSphere(t){return this.clampPoint(t.center,Tn),Tn.distanceToSquared(t.center)<=t.radius*t.radius}intersectsPlane(t){let e,n;return t.normal.x>0?(e=t.normal.x*this.min.x,n=t.normal.x*this.max.x):(e=t.normal.x*this.max.x,n=t.normal.x*this.min.x),t.normal.y>0?(e+=t.normal.y*this.min.y,n+=t.normal.y*this.max.y):(e+=t.normal.y*this.max.y,n+=t.normal.y*this.min.y),t.normal.z>0?(e+=t.normal.z*this.min.z,n+=t.normal.z*this.max.z):(e+=t.normal.z*this.max.z,n+=t.normal.z*this.min.z),e<=-t.constant&&n>=-t.constant}intersectsTriangle(t){if(this.isEmpty())return!1;this.getCenter($s),Nr.subVectors(this.max,$s),ps.subVectors(t.a,$s),ms.subVectors(t.b,$s),gs.subVectors(t.c,$s),wi.subVectors(ms,ps),Ei.subVectors(gs,ms),Hi.subVectors(ps,gs);let e=[0,-wi.z,wi.y,0,-Ei.z,Ei.y,0,-Hi.z,Hi.y,wi.z,0,-wi.x,Ei.z,0,-Ei.x,Hi.z,0,-Hi.x,-wi.y,wi.x,0,-Ei.y,Ei.x,0,-Hi.y,Hi.x,0];return!So(e,ps,ms,gs,Nr)||(e=[1,0,0,0,1,0,0,0,1],!So(e,ps,ms,gs,Nr))?!1:(Ur.crossVectors(wi,Ei),e=[Ur.x,Ur.y,Ur.z],So(e,ps,ms,gs,Nr))}clampPoint(t,e){return e.copy(t).clamp(this.min,this.max)}distanceToPoint(t){return this.clampPoint(t,Tn).distanceTo(t)}getBoundingSphere(t){return this.isEmpty()?t.makeEmpty():(this.getCenter(t.center),t.radius=this.getSize(Tn).length()*.5),t}intersect(t){return this.min.max(t.min),this.max.min(t.max),this.isEmpty()&&this.makeEmpty(),this}union(t){return this.min.min(t.min),this.max.max(t.max),this}applyMatrix4(t){return this.isEmpty()?this:(si[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(t),si[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(t),si[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(t),si[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(t),si[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(t),si[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(t),si[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(t),si[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(t),this.setFromPoints(si),this)}translate(t){return this.min.add(t),this.max.add(t),this}equals(t){return t.min.equals(this.min)&&t.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(t){return this.min.fromArray(t.min),this.max.fromArray(t.max),this}}const si=[new I,new I,new I,new I,new I,new I,new I,new I],Tn=new I,Ir=new is,ps=new I,ms=new I,gs=new I,wi=new I,Ei=new I,Hi=new I,$s=new I,Nr=new I,Ur=new I,Gi=new I;function So(i,t,e,n,s){for(let r=0,a=i.length-3;r<=a;r+=3){Gi.fromArray(i,r);const o=s.x*Math.abs(Gi.x)+s.y*Math.abs(Gi.y)+s.z*Math.abs(Gi.z),l=t.dot(Gi),c=e.dot(Gi),d=n.dot(Gi);if(Math.max(-Math.max(l,c,d),Math.min(l,c,d))>o)return!1}return!0}const Ee=new I,Fr=new Dt;let Pp=0;class Ke extends ns{constructor(t,e,n=!1){if(super(),Array.isArray(t))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:Pp++}),this.name="",this.array=t,this.itemSize=e,this.count=t!==void 0?t.length/e:0,this.normalized=n,this.usage=uu,this.updateRanges=[],this.gpuType=Pn,this.version=0,this._normalizationScale=t!==void 0?Za(t):void 0}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}setUsage(t){return this.usage=t,this}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.name=t.name,this.array=new t.array.constructor(t.array),this.itemSize=t.itemSize,this.count=t.count,this.normalized=t.normalized,this.usage=t.usage,this.gpuType=t.gpuType,this._normalizationScale=t._normalizationScale,this}copyAt(t,e,n){t*=this.itemSize,n*=e.itemSize;for(let s=0,r=this.itemSize;s<r;s++)this.array[t+s]=e.array[n+s];return this}copyArray(t){return this.array.set(t),this}applyMatrix3(t){if(this.itemSize===2)for(let e=0,n=this.count;e<n;e++)Fr.fromBufferAttribute(this,e),Fr.applyMatrix3(t),this.setXY(e,Fr.x,Fr.y);else if(this.itemSize===3)for(let e=0,n=this.count;e<n;e++)Ee.fromBufferAttribute(this,e),Ee.applyMatrix3(t),this.setXYZ(e,Ee.x,Ee.y,Ee.z);return this}applyMatrix4(t){for(let e=0,n=this.count;e<n;e++)Ee.fromBufferAttribute(this,e),Ee.applyMatrix4(t),this.setXYZ(e,Ee.x,Ee.y,Ee.z);return this}applyNormalMatrix(t){for(let e=0,n=this.count;e<n;e++)Ee.fromBufferAttribute(this,e),Ee.applyNormalMatrix(t),this.setXYZ(e,Ee.x,Ee.y,Ee.z);return this}transformDirection(t){for(let e=0,n=this.count;e<n;e++)Ee.fromBufferAttribute(this,e),Ee.transformDirection(t),this.setXYZ(e,Ee.x,Ee.y,Ee.z);return this}set(t,e=0){return this.array.set(t,e),this}getComponent(t,e){let n=this.array[t*this.itemSize+e];return this.normalized&&(n=this._denormalize(n)),n}setComponent(t,e,n){return this.normalized&&(n=this._normalize(n)),this.array[t*this.itemSize+e]=n,this}getX(t){let e=this.array[t*this.itemSize];return this.normalized&&(e=this._denormalize(e)),e}setX(t,e){return this.normalized&&(e=this._normalize(e)),this.array[t*this.itemSize]=e,this}getY(t){let e=this.array[t*this.itemSize+1];return this.normalized&&(e=this._denormalize(e)),e}setY(t,e){return this.normalized&&(e=this._normalize(e)),this.array[t*this.itemSize+1]=e,this}getZ(t){let e=this.array[t*this.itemSize+2];return this.normalized&&(e=this._denormalize(e)),e}setZ(t,e){return this.normalized&&(e=this._normalize(e)),this.array[t*this.itemSize+2]=e,this}getW(t){let e=this.array[t*this.itemSize+3];return this.normalized&&(e=this._denormalize(e)),e}setW(t,e){return this.normalized&&(e=this._normalize(e)),this.array[t*this.itemSize+3]=e,this}setXY(t,e,n){return t*=this.itemSize,this.normalized&&(e=this._normalize(e),n=this._normalize(n)),this.array[t+0]=e,this.array[t+1]=n,this}setXYZ(t,e,n,s){return t*=this.itemSize,this.normalized&&(e=this._normalize(e),n=this._normalize(n),s=this._normalize(s)),this.array[t+0]=e,this.array[t+1]=n,this.array[t+2]=s,this}setXYZW(t,e,n,s,r){return t*=this.itemSize,this.normalized&&(e=this._normalize(e),n=this._normalize(n),s=this._normalize(s),r=this._normalize(r)),this.array[t+0]=e,this.array[t+1]=n,this.array[t+2]=s,this.array[t+3]=r,this}onUpload(t){return this.onUploadCallback=t,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const t={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return t.name=this.name,t.usage=this.usage,t.gpuType=this.gpuType,t}dispose(){this.dispatchEvent({type:"dispose"})}_denormalize(t){const e=this._normalizationScale;return e!==void 0?Math.max(t/e,-1):oc(t,this.array)}_normalize(t){const e=this._normalizationScale;return e!==void 0?Math.round(t*e):lc(t,this.array)}}class vu extends Ke{constructor(t,e,n){super(new Uint16Array(t),e,n)}}class xu extends Ke{constructor(t,e,n){super(new Uint32Array(t),e,n)}}class ne extends Ke{constructor(t,e,n){super(new Float32Array(t),e,n)}}const Lp=new is,Ws=new I,wo=new I;class ss{constructor(t=new I,e=-1){this.isSphere=!0,this.center=t,this.radius=e}set(t,e){return this.center.copy(t),this.radius=e,this}setFromPoints(t,e){const n=this.center;e!==void 0?n.copy(e):Lp.setFromPoints(t).getCenter(n);let s=0;for(let r=0,a=t.length;r<a;r++)s=Math.max(s,n.distanceToSquared(t[r]));return this.radius=Math.sqrt(s),this}copy(t){return this.center.copy(t.center),this.radius=t.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(t){return t.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(t){return t.distanceTo(this.center)-this.radius}intersectsSphere(t){const e=this.radius+t.radius;return t.center.distanceToSquared(this.center)<=e*e}intersectsBox(t){return t.intersectsSphere(this)}intersectsPlane(t){return Math.abs(t.distanceToPoint(this.center))<=this.radius}clampPoint(t,e){const n=this.center.distanceToSquared(t);return e.copy(t),n>this.radius*this.radius&&(e.sub(this.center).normalize(),e.multiplyScalar(this.radius).add(this.center)),e}getBoundingBox(t){return this.isEmpty()?(t.makeEmpty(),t):(t.set(this.center,this.center),t.expandByScalar(this.radius),t)}applyMatrix4(t){return this.center.applyMatrix4(t),this.radius=this.radius*t.getMaxScaleOnAxis(),this}translate(t){return this.center.add(t),this}expandByPoint(t){if(this.isEmpty())return this.center.copy(t),this.radius=0,this;Ws.subVectors(t,this.center);const e=Ws.lengthSq();if(e>this.radius*this.radius){const n=Math.sqrt(e),s=(n-this.radius)*.5;this.center.addScaledVector(Ws,s/n),this.radius+=s}return this}union(t){return t.isEmpty()?this:this.isEmpty()?(this.copy(t),this):(this.center.equals(t.center)===!0?this.radius=Math.max(this.radius,t.radius):(wo.subVectors(t.center,this.center).setLength(t.radius),this.expandByPoint(Ws.copy(t.center).add(wo)),this.expandByPoint(Ws.copy(t.center).sub(wo))),this)}equals(t){return t.center.equals(this.center)&&t.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(t){return this.radius=t.radius,this.center.fromArray(t.center),this}}let Dp=0;const yn=new jt,Eo=new Ae,vs=new I,cn=new is,Xs=new is,Ue=new I;class be extends ns{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:Dp++}),this.uuid=Fi(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.indirectOffset=0,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={},this._transformed=!1}getIndex(){return this.index}setIndex(t){return Array.isArray(t)?this.index=new(jf(t)?xu:vu)(t,1):this.index=t,this}setIndirect(t,e=0){return this.indirect=t,this.indirectOffset=e,this}getIndirect(){return this.indirect}getAttribute(t){return this.attributes[t]}setAttribute(t,e){return this.attributes[t]=e,this}deleteAttribute(t){return delete this.attributes[t],this}hasAttribute(t){return this.attributes[t]!==void 0}addGroup(t,e,n=0){this.groups.push({start:t,count:e,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(t,e){this.drawRange.start=t,this.drawRange.count=e}applyMatrix4(t){const e=this.attributes.position;e!==void 0&&(e.applyMatrix4(t),e.needsUpdate=!0);const n=this.attributes.normal;if(n!==void 0){const r=new Ot().getNormalMatrix(t);n.applyNormalMatrix(r),n.needsUpdate=!0}const s=this.attributes.tangent;return s!==void 0&&(s.transformDirection(t),s.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this._transformed=!0,this}applyQuaternion(t){return yn.makeRotationFromQuaternion(t),this.applyMatrix4(yn),this}rotateX(t){return yn.makeRotationX(t),this.applyMatrix4(yn),this}rotateY(t){return yn.makeRotationY(t),this.applyMatrix4(yn),this}rotateZ(t){return yn.makeRotationZ(t),this.applyMatrix4(yn),this}translate(t,e,n){return yn.makeTranslation(t,e,n),this.applyMatrix4(yn),this}scale(t,e,n){return yn.makeScale(t,e,n),this.applyMatrix4(yn),this}lookAt(t){return Eo.lookAt(t),Eo.updateMatrix(),this.applyMatrix4(Eo.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(vs).negate(),this.translate(vs.x,vs.y,vs.z),this}setFromPoints(t){const e=this.getAttribute("position");if(e===void 0){const n=[];for(let s=0,r=t.length;s<r;s++){const a=t[s];n.push(a.x,a.y,a.z||0)}this.setAttribute("position",new ne(n,3))}else{const n=Math.min(t.length,e.count);for(let s=0;s<n;s++){const r=t[s];e.setXYZ(s,r.x,r.y,r.z||0)}t.length>e.count&&Lt("BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),e.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new is);const t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){ee("BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new I(-1/0,-1/0,-1/0),new I(1/0,1/0,1/0));return}if(t!==void 0){if(this.boundingBox.setFromBufferAttribute(t),e)for(let n=0,s=e.length;n<s;n++){const r=e[n];cn.setFromBufferAttribute(r),this.morphTargetsRelative?(Ue.addVectors(this.boundingBox.min,cn.min),this.boundingBox.expandByPoint(Ue),Ue.addVectors(this.boundingBox.max,cn.max),this.boundingBox.expandByPoint(Ue)):(this.boundingBox.expandByPoint(cn.min),this.boundingBox.expandByPoint(cn.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&ee('BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new ss);const t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){ee("BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new I,1/0);return}if(t){const n=this.boundingSphere.center;if(cn.setFromBufferAttribute(t),e)for(let r=0,a=e.length;r<a;r++){const o=e[r];Xs.setFromBufferAttribute(o),this.morphTargetsRelative?(Ue.addVectors(cn.min,Xs.min),cn.expandByPoint(Ue),Ue.addVectors(cn.max,Xs.max),cn.expandByPoint(Ue)):(cn.expandByPoint(Xs.min),cn.expandByPoint(Xs.max))}cn.getCenter(n);let s=0;for(let r=0,a=t.count;r<a;r++)Ue.fromBufferAttribute(t,r),s=Math.max(s,n.distanceToSquared(Ue));if(e)for(let r=0,a=e.length;r<a;r++){const o=e[r],l=this.morphTargetsRelative;for(let c=0,d=o.count;c<d;c++)Ue.fromBufferAttribute(o,c),l&&(vs.fromBufferAttribute(t,c),Ue.add(vs)),s=Math.max(s,n.distanceToSquared(Ue))}this.boundingSphere.radius=Math.sqrt(s),isNaN(this.boundingSphere.radius)&&ee('BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const t=this.index,e=this.attributes;if(t===null||e.position===void 0||e.normal===void 0||e.uv===void 0){ee("BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const n=e.position,s=e.normal,r=e.uv;let a=this.getAttribute("tangent");(a===void 0||a.count!==n.count)&&(a=new Ke(new Float32Array(4*n.count),4),this.setAttribute("tangent",a));const o=[],l=[],c=new Uint8Array(n.count);for(let N=0;N<n.count;N++)o[N]=new I,l[N]=new I;const d=new I,h=new I,u=new I,f=new Dt,g=new Dt,x=new Dt,m=new I,p=new I;function _(N,R,L){c[N]=c[R]=c[L]=1,d.fromBufferAttribute(n,N),h.fromBufferAttribute(n,R),u.fromBufferAttribute(n,L),f.fromBufferAttribute(r,N),g.fromBufferAttribute(r,R),x.fromBufferAttribute(r,L),h.sub(d),u.sub(d),g.sub(f),x.sub(f);const F=1/(g.x*x.y-x.x*g.y);isFinite(F)&&(m.copy(h).multiplyScalar(x.y).addScaledVector(u,-g.y).multiplyScalar(F),p.copy(u).multiplyScalar(g.x).addScaledVector(h,-x.x).multiplyScalar(F),o[N].add(m),o[R].add(m),o[L].add(m),l[N].add(p),l[R].add(p),l[L].add(p))}let S=this.groups;S.length===0&&(S=[{start:0,count:t.count}]);for(let N=0,R=S.length;N<R;++N){const L=S[N],F=L.start,V=L.count;for(let D=F,H=F+V;D<H;D+=3)_(t.getX(D+0),t.getX(D+1),t.getX(D+2))}const y=new I,A=new I,E=new I,v=new I;function w(N){E.fromBufferAttribute(s,N),v.copy(E);const R=o[N];y.copy(R),y.sub(E.multiplyScalar(E.dot(R))).normalize(),A.crossVectors(v,R);const F=A.dot(l[N])<0?-1:1;a.setXYZW(N,y.x,y.y,y.z,F)}for(let N=0,R=n.count;N<R;++N)c[N]&&w(N);this._transformed=!0}computeVertexNormals(){const t=this.index,e=this.getAttribute("position");if(e!==void 0){let n=this.getAttribute("normal");if(n===void 0||n.count!==e.count)n=new Ke(new Float32Array(e.count*3),3),this.setAttribute("normal",n);else for(let u=0,f=n.count;u<f;u++)n.setXYZ(u,0,0,0);const s=new I,r=new I,a=new I,o=new I,l=new I,c=new I,d=new I,h=new I;if(t)for(let u=0,f=t.count;u<f;u+=3){const g=t.getX(u+0),x=t.getX(u+1),m=t.getX(u+2);s.fromBufferAttribute(e,g),r.fromBufferAttribute(e,x),a.fromBufferAttribute(e,m),d.subVectors(a,r),h.subVectors(s,r),d.cross(h),o.fromBufferAttribute(n,g),l.fromBufferAttribute(n,x),c.fromBufferAttribute(n,m),o.add(d),l.add(d),c.add(d),n.setXYZ(g,o.x,o.y,o.z),n.setXYZ(x,l.x,l.y,l.z),n.setXYZ(m,c.x,c.y,c.z)}else for(let u=0,f=e.count;u<f;u+=3)s.fromBufferAttribute(e,u+0),r.fromBufferAttribute(e,u+1),a.fromBufferAttribute(e,u+2),d.subVectors(a,r),h.subVectors(s,r),d.cross(h),n.setXYZ(u+0,d.x,d.y,d.z),n.setXYZ(u+1,d.x,d.y,d.z),n.setXYZ(u+2,d.x,d.y,d.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){const t=this.attributes.normal;for(let e=0,n=t.count;e<n;e++)Ue.fromBufferAttribute(t,e),Ue.normalize(),t.setXYZ(e,Ue.x,Ue.y,Ue.z)}toNonIndexed(){function t(o,l){const c=o.array,d=o.itemSize,h=o.normalized,u=new c.constructor(l.length*d);let f=0,g=0;for(let x=0,m=l.length;x<m;x++){o.isInterleavedBufferAttribute?f=l[x]*o.data.stride+o.offset:f=l[x]*d;for(let p=0;p<d;p++)u[g++]=c[f++]}return new Ke(u,d,h)}if(this.index===null)return Lt("BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const e=new be,n=this.index.array,s=this.attributes;for(const o in s){const l=s[o],c=t(l,n);e.setAttribute(o,c)}const r=this.morphAttributes;for(const o in r){const l=[],c=r[o];for(let d=0,h=c.length;d<h;d++){const u=c[d],f=t(u,n);l.push(f)}e.morphAttributes[o]=l}e.morphTargetsRelative=this.morphTargetsRelative;const a=this.groups;for(let o=0,l=a.length;o<l;o++){const c=a[o];e.addGroup(c.start,c.count,c.materialIndex)}return e}toJSON(){const t={metadata:{version:4.7,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(t.uuid=this.uuid,t.type=this.parameters!==void 0&&this._transformed===!0?"BufferGeometry":this.type,t.name=this.name,Object.keys(this.userData).length>0&&(t.userData=this.userData),this.parameters!==void 0&&this._transformed!==!0){const l=this.parameters;for(const c in l)l[c]!==void 0&&(t[c]=l[c]);return t}t.data={attributes:{}};const e=this.index;e!==null&&(t.data.index={type:e.array.constructor.name,array:Array.prototype.slice.call(e.array)});const n=this.attributes;for(const l in n){const c=n[l];t.data.attributes[l]=c.toJSON(t.data)}const s={};let r=!1;for(const l in this.morphAttributes){const c=this.morphAttributes[l],d=[];for(let h=0,u=c.length;h<u;h++){const f=c[h];d.push(f.toJSON(t.data))}d.length>0&&(s[l]=d,r=!0)}r&&(t.data.morphAttributes=s,t.data.morphTargetsRelative=this.morphTargetsRelative);const a=this.groups;a.length>0&&(t.data.groups=JSON.parse(JSON.stringify(a)));const o=this.boundingSphere;return o!==null&&(t.data.boundingSphere=o.toJSON()),t}clone(){return new this.constructor().copy(this)}copy(t){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const e={};this.name=t.name;const n=t.index;n!==null&&this.setIndex(n.clone());const s=t.attributes;for(const c in s){const d=s[c];this.setAttribute(c,d.clone(e))}const r=t.morphAttributes;for(const c in r){const d=[],h=r[c];for(let u=0,f=h.length;u<f;u++)d.push(h[u].clone(e));this.morphAttributes[c]=d}this.morphTargetsRelative=t.morphTargetsRelative;const a=t.groups;for(let c=0,d=a.length;c<d;c++){const h=a[c];this.addGroup(h.start,h.count,h.materialIndex)}const o=t.boundingBox;o!==null&&(this.boundingBox=o.clone());const l=t.boundingSphere;return l!==null&&(this.boundingSphere=l.clone()),this.drawRange.start=t.drawRange.start,this.drawRange.count=t.drawRange.count,this.userData=t.userData,this._transformed=t._transformed,this}dispose(){this.dispatchEvent({type:"dispose"})}}class Ip{constructor(t,e){this.isInterleavedBuffer=!0,this.array=t,this.stride=e,this.count=t!==void 0?t.length/e:0,this.usage=uu,this.updateRanges=[],this.version=0,this.uuid=Fi()}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}setUsage(t){return this.usage=t,this}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.array=new t.array.constructor(t.array),this.count=t.count,this.stride=t.stride,this.usage=t.usage,this}copyAt(t,e,n){t*=this.stride,n*=e.stride;for(let s=0,r=this.stride;s<r;s++)this.array[t+s]=e.array[n+s];return this}set(t,e=0){return this.array.set(t,e),this}clone(t){t.arrayBuffers===void 0&&(t.arrayBuffers={});const e=dd(this.array);t.arrayBuffers[e]===void 0&&(t.arrayBuffers[e]=this.array.slice(0).buffer);const n=new this.array.constructor(t.arrayBuffers[e]),s=new this.constructor(n,this.stride);return s.setUsage(this.usage),s}onUpload(t){return this.onUploadCallback=t,this}toJSON(t){t.arrayBuffers===void 0&&(t.arrayBuffers={});const e=dd(this.array);t.arrayBuffers[e]===void 0&&(t.arrayBuffers[e]=Array.from(new Uint32Array(this.array.slice(0).buffer)));const n={uuid:this.uuid,buffer:e,type:this.array.constructor.name,stride:this.stride};return n.usage=this.usage,n}}function dd(i){return i.buffer._uuid===void 0&&(i.buffer._uuid=Fi()),i.byteOffset===0&&i.byteLength===i.buffer.byteLength?i.buffer._uuid:i.buffer._uuid+":"+i.byteOffset+":"+i.byteLength}const Je=new I;class Fa{constructor(t,e,n,s=!1){this.isInterleavedBufferAttribute=!0,this.name="",this.data=t,this.itemSize=e,this.offset=n,this.normalized=s,this._normalizationScale=t!==void 0?Za(t.array):void 0}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(t){this.data.needsUpdate=t}applyMatrix4(t){for(let e=0,n=this.data.count;e<n;e++)Je.fromBufferAttribute(this,e),Je.applyMatrix4(t),this.setXYZ(e,Je.x,Je.y,Je.z);return this}applyNormalMatrix(t){for(let e=0,n=this.count;e<n;e++)Je.fromBufferAttribute(this,e),Je.applyNormalMatrix(t),this.setXYZ(e,Je.x,Je.y,Je.z);return this}transformDirection(t){for(let e=0,n=this.count;e<n;e++)Je.fromBufferAttribute(this,e),Je.transformDirection(t),this.setXYZ(e,Je.x,Je.y,Je.z);return this}getComponent(t,e){let n=this.array[t*this.data.stride+this.offset+e];return this.normalized&&(n=this._denormalize(n)),n}setComponent(t,e,n){return this.normalized&&(n=this._normalize(n)),this.data.array[t*this.data.stride+this.offset+e]=n,this}setX(t,e){return this.normalized&&(e=this._normalize(e)),this.data.array[t*this.data.stride+this.offset]=e,this}setY(t,e){return this.normalized&&(e=this._normalize(e)),this.data.array[t*this.data.stride+this.offset+1]=e,this}setZ(t,e){return this.normalized&&(e=this._normalize(e)),this.data.array[t*this.data.stride+this.offset+2]=e,this}setW(t,e){return this.normalized&&(e=this._normalize(e)),this.data.array[t*this.data.stride+this.offset+3]=e,this}getX(t){let e=this.data.array[t*this.data.stride+this.offset];return this.normalized&&(e=this._denormalize(e)),e}getY(t){let e=this.data.array[t*this.data.stride+this.offset+1];return this.normalized&&(e=this._denormalize(e)),e}getZ(t){let e=this.data.array[t*this.data.stride+this.offset+2];return this.normalized&&(e=this._denormalize(e)),e}getW(t){let e=this.data.array[t*this.data.stride+this.offset+3];return this.normalized&&(e=this._denormalize(e)),e}setXY(t,e,n){return t=t*this.data.stride+this.offset,this.normalized&&(e=this._normalize(e),n=this._normalize(n)),this.data.array[t+0]=e,this.data.array[t+1]=n,this}setXYZ(t,e,n,s){return t=t*this.data.stride+this.offset,this.normalized&&(e=this._normalize(e),n=this._normalize(n),s=this._normalize(s)),this.data.array[t+0]=e,this.data.array[t+1]=n,this.data.array[t+2]=s,this}setXYZW(t,e,n,s,r){return t=t*this.data.stride+this.offset,this.normalized&&(e=this._normalize(e),n=this._normalize(n),s=this._normalize(s),r=this._normalize(r)),this.data.array[t+0]=e,this.data.array[t+1]=n,this.data.array[t+2]=s,this.data.array[t+3]=r,this}clone(t){if(t===void 0){Na("InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");const e=[];for(let n=0;n<this.count;n++){const s=n*this.data.stride+this.offset;for(let r=0;r<this.itemSize;r++)e.push(this.data.array[s+r])}return new Ke(new this.array.constructor(e),this.itemSize,this.normalized)}else return t.interleavedBuffers===void 0&&(t.interleavedBuffers={}),t.interleavedBuffers[this.data.uuid]===void 0&&(t.interleavedBuffers[this.data.uuid]=this.data.clone(t)),new Fa(t.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(t){if(t===void 0){Na("InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");const e=[];for(let n=0;n<this.count;n++){const s=n*this.data.stride+this.offset;for(let r=0;r<this.itemSize;r++)e.push(this.data.array[s+r])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:e,normalized:this.normalized}}else return t.interleavedBuffers===void 0&&(t.interleavedBuffers={}),t.interleavedBuffers[this.data.uuid]===void 0&&(t.interleavedBuffers[this.data.uuid]=this.data.toJSON(t)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}_denormalize(t){const e=this._normalizationScale;return e!==void 0?Math.max(t/e,-1):oc(t,this.data.array)}_normalize(t){const e=this._normalizationScale;return e!==void 0?Math.round(t*e):lc(t,this.data.array)}}const Ao=new I,Np=new I,Up=new Ot;class ci{constructor(t=new I(1,0,0),e=0){this.isPlane=!0,this.normal=t,this.constant=e}set(t,e){return this.normal.copy(t),this.constant=e,this}setComponents(t,e,n,s){return this.normal.set(t,e,n),this.constant=s,this}setFromNormalAndCoplanarPoint(t,e){return this.normal.copy(t),this.constant=-e.dot(this.normal),this}setFromCoplanarPoints(t,e,n){const s=Ao.subVectors(n,e).cross(Np.subVectors(t,e)).normalize();return this.setFromNormalAndCoplanarPoint(s,t),this}copy(t){return this.normal.copy(t.normal),this.constant=t.constant,this}normalize(){const t=1/this.normal.length();return this.normal.multiplyScalar(t),this.constant*=t,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(t){return this.normal.dot(t)+this.constant}distanceToSphere(t){return this.distanceToPoint(t.center)-t.radius}projectPoint(t,e){return e.copy(t).addScaledVector(this.normal,-this.distanceToPoint(t))}intersectLine(t,e,n=!0){const s=t.delta(Ao),r=this.normal.dot(s);if(r===0)return this.distanceToPoint(t.start)===0?e.copy(t.start):null;const a=-(t.start.dot(this.normal)+this.constant)/r;return n===!0&&(a<0||a>1)?null:e.copy(t.start).addScaledVector(s,a)}intersectsLine(t){const e=this.distanceToPoint(t.start),n=this.distanceToPoint(t.end);return e<0&&n>0||n<0&&e>0}intersectsBox(t){return t.intersectsPlane(this)}intersectsSphere(t){return t.intersectsPlane(this)}coplanarPoint(t){return t.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(t,e){const n=e||Up.getNormalMatrix(t),s=this.coplanarPoint(Ao).applyMatrix4(t),r=this.normal.applyMatrix3(n).normalize();return this.constant=-s.dot(r),this}translate(t){return this.constant-=t.dot(this.normal),this}equals(t){return t.normal.equals(this.normal)&&t.constant===this.constant}clone(){return new this.constructor().copy(this)}toJSON(){return{normal:this.normal.toArray(),constant:this.constant}}fromJSON(t){return this.normal.fromArray(t.normal),this.constant=t.constant,this}}let Fp=0;class Oi extends ns{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:Fp++}),this.uuid=Fi(),this.name="",this.type="Material",this.blending=cr,this.side=Ki,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=qh,this.blendDst=Yh,this.blendEquation=As,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new Nt(0,0,0),this.blendAlpha=0,this.depthFunc=mr,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=Xf,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=oo,this.stencilZFail=oo,this.stencilZPass=oo,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(t){this._alphaTest>0!=t>0&&this.version++,this._alphaTest=t}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(t){if(t!==void 0)for(const e in t){const n=t[e];if(n===void 0){Lt(`Material: parameter '${e}' has value of undefined.`);continue}const s=this[e];if(s===void 0){Lt(`Material: '${e}' is not a property of THREE.${this.type}.`);continue}s&&s.isColor?s.set(n):s&&s.isVector2&&n&&n.isVector2||s&&s.isEuler&&n&&n.isEuler||s&&s.isVector3&&n&&n.isVector3?s.copy(n):this[e]=n}}toJSON(t){const e=t===void 0||typeof t=="string";e&&(t={textures:{},images:{}});const n={metadata:{version:4.7,type:"Material",generator:"Material.toJSON"}};n.uuid=this.uuid,n.type=this.type,n.blending=this.blending,n.side=this.side,n.shadowSide=this.shadowSide,n.vertexColors=this.vertexColors,n.opacity=this.opacity,n.transparent=this.transparent,n.blendSrc=this.blendSrc,n.blendDst=this.blendDst,n.blendEquation=this.blendEquation,n.blendSrcAlpha=this.blendSrcAlpha,n.blendDstAlpha=this.blendDstAlpha,n.blendEquationAlpha=this.blendEquationAlpha,n.blendColor=this.blendColor.getHex(),n.blendAlpha=this.blendAlpha,n.depthFunc=this.depthFunc,n.depthTest=this.depthTest,n.depthWrite=this.depthWrite,n.colorWrite=this.colorWrite,n.clipIntersection=this.clipIntersection,n.clipShadows=this.clipShadows,n.stencilWriteMask=this.stencilWriteMask,n.stencilFunc=this.stencilFunc,n.stencilRef=this.stencilRef,n.stencilFuncMask=this.stencilFuncMask,n.stencilFail=this.stencilFail,n.stencilZFail=this.stencilZFail,n.stencilZPass=this.stencilZPass,n.stencilWrite=this.stencilWrite,n.polygonOffset=this.polygonOffset,n.polygonOffsetFactor=this.polygonOffsetFactor,n.polygonOffsetUnits=this.polygonOffsetUnits,n.dithering=this.dithering,n.alphaTest=this.alphaTest,n.alphaHash=this.alphaHash,n.alphaToCoverage=this.alphaToCoverage,n.premultipliedAlpha=this.premultipliedAlpha,n.forceSinglePass=this.forceSinglePass,n.allowOverride=this.allowOverride,n.visible=this.visible,n.toneMapped=this.toneMapped,n.name=this.name,this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.diffuseRoughness!==void 0&&(n.diffuseRoughness=this.diffuseRoughness),this.diffuseRoughnessMap&&this.diffuseRoughnessMap.isTexture&&(n.diffuseRoughnessMap=this.diffuseRoughnessMap.toJSON(t).uuid),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(t).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(t).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(t).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.sheenColorMap&&this.sheenColorMap.isTexture&&(n.sheenColorMap=this.sheenColorMap.toJSON(t).uuid),this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture&&(n.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(t).uuid),this.dispersion!==void 0&&(n.dispersion=this.dispersion),this.retroreflectivity!==void 0&&(n.retroreflectivity=this.retroreflectivity),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessMinimum!==void 0&&(n.iridescenceThicknessMinimum=this.iridescenceThicknessMinimum),this.iridescenceThicknessMaximum!==void 0&&(n.iridescenceThicknessMaximum=this.iridescenceThicknessMaximum),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(t).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(t).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(t).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(t).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(t).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(t).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(t).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(t).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(t).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(t).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(t).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(t).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(t).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(t).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(t).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(t).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(t).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(t).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapRotation!==void 0&&(n.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(t).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(t).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(t).uuid),this.attenuationDistance!==void 0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),Array.isArray(this.clippingPlanes)&&this.clippingPlanes.length>0&&(n.clippingPlanes=this.clippingPlanes.map(r=>r.toJSON())),this.rotation!==void 0&&(n.rotation=this.rotation),this.depthPacking!==void 0&&(n.depthPacking=this.depthPacking),this.linewidth!==void 0&&(n.linewidth=this.linewidth),this.linecap!==void 0&&(n.linecap=this.linecap),this.linejoin!==void 0&&(n.linejoin=this.linejoin),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.wireframe!==void 0&&(n.wireframe=this.wireframe),this.wireframeLinewidth!==void 0&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!==void 0&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!==void 0&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading!==void 0&&(n.flatShading=this.flatShading),this.fog!==void 0&&(n.fog=this.fog),Object.keys(this.userData).length>0&&(n.userData=this.userData);function s(r){const a=[];for(const o in r){const l=r[o];delete l.metadata,a.push(l)}return a}if(e){const r=s(t.textures),a=s(t.images);r.length>0&&(n.textures=r),a.length>0&&(n.images=a)}return n}fromJSON(t,e){if(t.uuid!==void 0&&(this.uuid=t.uuid),t.name!==void 0&&(this.name=t.name),t.color!==void 0&&this.color!==void 0&&this.color.setHex(t.color),t.roughness!==void 0&&(this.roughness=t.roughness),t.metalness!==void 0&&(this.metalness=t.metalness),t.sheen!==void 0&&(this.sheen=t.sheen),t.sheenColor!==void 0&&(this.sheenColor=new Nt().setHex(t.sheenColor)),t.sheenRoughness!==void 0&&(this.sheenRoughness=t.sheenRoughness),t.emissive!==void 0&&this.emissive!==void 0&&this.emissive.setHex(t.emissive),t.specular!==void 0&&this.specular!==void 0&&this.specular.setHex(t.specular),t.specularIntensity!==void 0&&(this.specularIntensity=t.specularIntensity),t.specularColor!==void 0&&this.specularColor!==void 0&&this.specularColor.setHex(t.specularColor),t.shininess!==void 0&&(this.shininess=t.shininess),t.clearcoat!==void 0&&(this.clearcoat=t.clearcoat),t.clearcoatRoughness!==void 0&&(this.clearcoatRoughness=t.clearcoatRoughness),t.diffuseRoughness!==void 0&&(this.diffuseRoughness=t.diffuseRoughness),t.dispersion!==void 0&&(this.dispersion=t.dispersion),t.retroreflectivity!==void 0&&(this.retroreflectivity=t.retroreflectivity),t.iridescence!==void 0&&(this.iridescence=t.iridescence),t.iridescenceIOR!==void 0&&(this.iridescenceIOR=t.iridescenceIOR),t.iridescenceThicknessMinimum!==void 0&&(this.iridescenceThicknessMinimum=t.iridescenceThicknessMinimum),t.iridescenceThicknessMaximum!==void 0&&(this.iridescenceThicknessMaximum=t.iridescenceThicknessMaximum),t.iridescenceThicknessRange!==void 0&&(this.iridescenceThicknessMinimum=t.iridescenceThicknessRange[0],this.iridescenceThicknessMaximum=t.iridescenceThicknessRange[1]),t.transmission!==void 0&&(this.transmission=t.transmission),t.thickness!==void 0&&(this.thickness=t.thickness),t.attenuationDistance!==void 0&&(this.attenuationDistance=t.attenuationDistance),t.attenuationColor!==void 0&&this.attenuationColor!==void 0&&this.attenuationColor.setHex(t.attenuationColor),t.anisotropy!==void 0&&(this.anisotropy=t.anisotropy),t.anisotropyRotation!==void 0&&(this.anisotropyRotation=t.anisotropyRotation),t.fog!==void 0&&(this.fog=t.fog),t.flatShading!==void 0&&(this.flatShading=t.flatShading),t.blending!==void 0&&(this.blending=t.blending),t.combine!==void 0&&(this.combine=t.combine),t.side!==void 0&&(this.side=t.side),t.shadowSide!==void 0&&(this.shadowSide=t.shadowSide),t.opacity!==void 0&&(this.opacity=t.opacity),t.transparent!==void 0&&(this.transparent=t.transparent),t.alphaTest!==void 0&&(this.alphaTest=t.alphaTest),t.alphaHash!==void 0&&(this.alphaHash=t.alphaHash),t.depthFunc!==void 0&&(this.depthFunc=t.depthFunc),t.depthTest!==void 0&&(this.depthTest=t.depthTest),t.depthWrite!==void 0&&(this.depthWrite=t.depthWrite),t.colorWrite!==void 0&&(this.colorWrite=t.colorWrite),t.clippingPlanes!==void 0&&(this.clippingPlanes=t.clippingPlanes.map(n=>new ci().fromJSON(n))),t.clipIntersection!==void 0&&(this.clipIntersection=t.clipIntersection),t.clipShadows!==void 0&&(this.clipShadows=t.clipShadows),t.depthPacking!==void 0&&(this.depthPacking=t.depthPacking),t.blendSrc!==void 0&&(this.blendSrc=t.blendSrc),t.blendDst!==void 0&&(this.blendDst=t.blendDst),t.blendEquation!==void 0&&(this.blendEquation=t.blendEquation),t.blendSrcAlpha!==void 0&&(this.blendSrcAlpha=t.blendSrcAlpha),t.blendDstAlpha!==void 0&&(this.blendDstAlpha=t.blendDstAlpha),t.blendEquationAlpha!==void 0&&(this.blendEquationAlpha=t.blendEquationAlpha),t.blendColor!==void 0&&this.blendColor!==void 0&&this.blendColor.setHex(t.blendColor),t.blendAlpha!==void 0&&(this.blendAlpha=t.blendAlpha),t.stencilWriteMask!==void 0&&(this.stencilWriteMask=t.stencilWriteMask),t.stencilFunc!==void 0&&(this.stencilFunc=t.stencilFunc),t.stencilRef!==void 0&&(this.stencilRef=t.stencilRef),t.stencilFuncMask!==void 0&&(this.stencilFuncMask=t.stencilFuncMask),t.stencilFail!==void 0&&(this.stencilFail=t.stencilFail),t.stencilZFail!==void 0&&(this.stencilZFail=t.stencilZFail),t.stencilZPass!==void 0&&(this.stencilZPass=t.stencilZPass),t.stencilWrite!==void 0&&(this.stencilWrite=t.stencilWrite),t.wireframe!==void 0&&(this.wireframe=t.wireframe),t.wireframeLinewidth!==void 0&&(this.wireframeLinewidth=t.wireframeLinewidth),t.wireframeLinecap!==void 0&&(this.wireframeLinecap=t.wireframeLinecap),t.wireframeLinejoin!==void 0&&(this.wireframeLinejoin=t.wireframeLinejoin),t.rotation!==void 0&&(this.rotation=t.rotation),t.linewidth!==void 0&&(this.linewidth=t.linewidth),t.linecap!==void 0&&(this.linecap=t.linecap),t.linejoin!==void 0&&(this.linejoin=t.linejoin),t.dashSize!==void 0&&(this.dashSize=t.dashSize),t.gapSize!==void 0&&(this.gapSize=t.gapSize),t.scale!==void 0&&(this.scale=t.scale),t.polygonOffset!==void 0&&(this.polygonOffset=t.polygonOffset),t.polygonOffsetFactor!==void 0&&(this.polygonOffsetFactor=t.polygonOffsetFactor),t.polygonOffsetUnits!==void 0&&(this.polygonOffsetUnits=t.polygonOffsetUnits),t.dithering!==void 0&&(this.dithering=t.dithering),t.alphaToCoverage!==void 0&&(this.alphaToCoverage=t.alphaToCoverage),t.premultipliedAlpha!==void 0&&(this.premultipliedAlpha=t.premultipliedAlpha),t.forceSinglePass!==void 0&&(this.forceSinglePass=t.forceSinglePass),t.allowOverride!==void 0&&(this.allowOverride=t.allowOverride),t.visible!==void 0&&(this.visible=t.visible),t.toneMapped!==void 0&&(this.toneMapped=t.toneMapped),t.userData!==void 0&&(this.userData=t.userData),t.vertexColors!==void 0&&(typeof t.vertexColors=="number"?this.vertexColors=t.vertexColors>0:this.vertexColors=t.vertexColors),t.size!==void 0&&(this.size=t.size),t.sizeAttenuation!==void 0&&(this.sizeAttenuation=t.sizeAttenuation),t.map!==void 0&&(this.map=e[t.map]||null),t.matcap!==void 0&&(this.matcap=e[t.matcap]||null),t.alphaMap!==void 0&&(this.alphaMap=e[t.alphaMap]||null),t.bumpMap!==void 0&&(this.bumpMap=e[t.bumpMap]||null),t.bumpScale!==void 0&&(this.bumpScale=t.bumpScale),t.normalMap!==void 0&&(this.normalMap=e[t.normalMap]||null),t.normalMapType!==void 0&&(this.normalMapType=t.normalMapType),t.normalScale!==void 0){let n=t.normalScale;Array.isArray(n)===!1&&(n=[n,n]),this.normalScale=new Dt().fromArray(n)}return t.displacementMap!==void 0&&(this.displacementMap=e[t.displacementMap]||null),t.displacementScale!==void 0&&(this.displacementScale=t.displacementScale),t.displacementBias!==void 0&&(this.displacementBias=t.displacementBias),t.roughnessMap!==void 0&&(this.roughnessMap=e[t.roughnessMap]||null),t.metalnessMap!==void 0&&(this.metalnessMap=e[t.metalnessMap]||null),t.emissiveMap!==void 0&&(this.emissiveMap=e[t.emissiveMap]||null),t.emissiveIntensity!==void 0&&(this.emissiveIntensity=t.emissiveIntensity),t.specularMap!==void 0&&(this.specularMap=e[t.specularMap]||null),t.specularIntensityMap!==void 0&&(this.specularIntensityMap=e[t.specularIntensityMap]||null),t.specularColorMap!==void 0&&(this.specularColorMap=e[t.specularColorMap]||null),t.envMap!==void 0&&(this.envMap=e[t.envMap]||null),t.envMapRotation!==void 0&&this.envMapRotation.fromArray(t.envMapRotation),t.envMapIntensity!==void 0&&(this.envMapIntensity=t.envMapIntensity),t.reflectivity!==void 0&&(this.reflectivity=t.reflectivity),t.refractionRatio!==void 0&&(this.refractionRatio=t.refractionRatio),t.lightMap!==void 0&&(this.lightMap=e[t.lightMap]||null),t.lightMapIntensity!==void 0&&(this.lightMapIntensity=t.lightMapIntensity),t.aoMap!==void 0&&(this.aoMap=e[t.aoMap]||null),t.aoMapIntensity!==void 0&&(this.aoMapIntensity=t.aoMapIntensity),t.gradientMap!==void 0&&(this.gradientMap=e[t.gradientMap]||null),t.clearcoatMap!==void 0&&(this.clearcoatMap=e[t.clearcoatMap]||null),t.clearcoatRoughnessMap!==void 0&&(this.clearcoatRoughnessMap=e[t.clearcoatRoughnessMap]||null),t.clearcoatNormalMap!==void 0&&(this.clearcoatNormalMap=e[t.clearcoatNormalMap]||null),t.clearcoatNormalScale!==void 0&&(this.clearcoatNormalScale=new Dt().fromArray(t.clearcoatNormalScale)),t.diffuseRoughnessMap!==void 0&&(this.diffuseRoughnessMap=e[t.diffuseRoughnessMap]||null),t.iridescenceMap!==void 0&&(this.iridescenceMap=e[t.iridescenceMap]||null),t.iridescenceThicknessMap!==void 0&&(this.iridescenceThicknessMap=e[t.iridescenceThicknessMap]||null),t.transmissionMap!==void 0&&(this.transmissionMap=e[t.transmissionMap]||null),t.thicknessMap!==void 0&&(this.thicknessMap=e[t.thicknessMap]||null),t.anisotropyMap!==void 0&&(this.anisotropyMap=e[t.anisotropyMap]||null),t.sheenColorMap!==void 0&&(this.sheenColorMap=e[t.sheenColorMap]||null),t.sheenRoughnessMap!==void 0&&(this.sheenRoughnessMap=e[t.sheenRoughnessMap]||null),this}clone(){return new this.constructor().copy(this)}copy(t){this.name=t.name,this.blending=t.blending,this.side=t.side,this.vertexColors=t.vertexColors,this.opacity=t.opacity,this.transparent=t.transparent,this.blendSrc=t.blendSrc,this.blendDst=t.blendDst,this.blendEquation=t.blendEquation,this.blendSrcAlpha=t.blendSrcAlpha,this.blendDstAlpha=t.blendDstAlpha,this.blendEquationAlpha=t.blendEquationAlpha,this.blendColor.copy(t.blendColor),this.blendAlpha=t.blendAlpha,this.depthFunc=t.depthFunc,this.depthTest=t.depthTest,this.depthWrite=t.depthWrite,this.stencilWriteMask=t.stencilWriteMask,this.stencilFunc=t.stencilFunc,this.stencilRef=t.stencilRef,this.stencilFuncMask=t.stencilFuncMask,this.stencilFail=t.stencilFail,this.stencilZFail=t.stencilZFail,this.stencilZPass=t.stencilZPass,this.stencilWrite=t.stencilWrite;const e=t.clippingPlanes;let n=null;if(e!==null){const s=e.length;n=new Array(s);for(let r=0;r!==s;++r)n[r]=e[r].clone()}return this.clippingPlanes=n,this.clipIntersection=t.clipIntersection,this.clipShadows=t.clipShadows,this.shadowSide=t.shadowSide,this.colorWrite=t.colorWrite,this.precision=t.precision,this.polygonOffset=t.polygonOffset,this.polygonOffsetFactor=t.polygonOffsetFactor,this.polygonOffsetUnits=t.polygonOffsetUnits,this.dithering=t.dithering,this.alphaTest=t.alphaTest,this.alphaHash=t.alphaHash,this.alphaToCoverage=t.alphaToCoverage,this.premultipliedAlpha=t.premultipliedAlpha,this.forceSinglePass=t.forceSinglePass,this.allowOverride=t.allowOverride,this.visible=t.visible,this.toneMapped=t.toneMapped,this.userData=JSON.parse(JSON.stringify(t.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(t){t===!0&&this.version++}}class _u extends Oi{constructor(t){super(),this.isSpriteMaterial=!0,this.type="SpriteMaterial",this.color=new Nt(16777215),this.map=null,this.alphaMap=null,this.rotation=0,this.sizeAttenuation=!0,this.transparent=!0,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.alphaMap=t.alphaMap,this.rotation=t.rotation,this.sizeAttenuation=t.sizeAttenuation,this.fog=t.fog,this}}let xs;const qs=new I,_s=new I,ys=new I,bs=new Dt,Ys=new Dt,yu=new jt,Or=new I,Ks=new I,Br=new I,hd=new Dt,To=new Dt,ud=new Dt;class Op extends Ae{constructor(t=new _u){if(super(),this.isSprite=!0,this.type="Sprite",xs===void 0){xs=new be;const e=new Float32Array([-.5,-.5,0,0,0,.5,-.5,0,1,0,.5,.5,0,1,1,-.5,.5,0,0,1]),n=new Ip(e,5);xs.setIndex([0,1,2,0,2,3]),xs.setAttribute("position",new Fa(n,3,0,!1)),xs.setAttribute("uv",new Fa(n,2,3,!1))}this.geometry=xs,this.material=t,this.center=new Dt(.5,.5),this.count=1}intersectsFrustum(t){return t.intersectsSprite(this)}raycast(t,e){t.camera===null&&ee('Sprite: "Raycaster.camera" needs to be set in order to raycast against sprites.'),_s.setFromMatrixScale(this.matrixWorld),yu.copy(t.camera.matrixWorld),this.modelViewMatrix.multiplyMatrices(t.camera.matrixWorldInverse,this.matrixWorld),ys.setFromMatrixPosition(this.modelViewMatrix),t.camera.isPerspectiveCamera&&this.material.sizeAttenuation===!1&&_s.multiplyScalar(-ys.z);const n=this.material.rotation;let s,r;n!==0&&(r=Math.cos(n),s=Math.sin(n));const a=this.center;kr(Or.set(-.5,-.5,0),ys,a,_s,s,r),kr(Ks.set(.5,-.5,0),ys,a,_s,s,r),kr(Br.set(.5,.5,0),ys,a,_s,s,r),hd.set(0,0),To.set(1,0),ud.set(1,1);let o=t.ray.intersectTriangle(Or,Ks,Br,!1,qs);if(o===null&&(kr(Ks.set(-.5,.5,0),ys,a,_s,s,r),To.set(0,1),o=t.ray.intersectTriangle(Or,Br,Ks,!1,qs),o===null))return;const l=t.ray.origin.distanceTo(qs);l<t.near||l>t.far||e.push({distance:l,point:qs.clone(),uv:hn.getInterpolation(qs,Or,Ks,Br,hd,To,ud,new Dt),face:null,object:this})}copy(t,e){return super.copy(t,e),t.center!==void 0&&this.center.copy(t.center),this.material=t.material,this}toJSON(t){const e=super.toJSON(t);return e.object.center=this.center.toArray(),e}}function kr(i,t,e,n,s,r){bs.subVectors(i,e).addScalar(.5).multiply(n),s!==void 0?(Ys.x=r*bs.x-s*bs.y,Ys.y=s*bs.x+r*bs.y):Ys.copy(bs),i.copy(t),i.x+=Ys.x,i.y+=Ys.y,i.applyMatrix4(yu)}const ri=new I,Ro=new I,zr=new I,Hr=new I;class Ja{constructor(t=new I,e=new I(0,0,-1)){this.origin=t,this.direction=e}set(t,e){return this.origin.copy(t),this.direction.copy(e),this}copy(t){return this.origin.copy(t.origin),this.direction.copy(t.direction),this}at(t,e){return e.copy(this.origin).addScaledVector(this.direction,t)}lookAt(t){return this.direction.copy(t).sub(this.origin).normalize(),this}recast(t){return this.origin.copy(this.at(t,ri)),this}closestPointToPoint(t,e){e.subVectors(t,this.origin);const n=e.dot(this.direction);return n<0?e.copy(this.origin):e.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(t){return Math.sqrt(this.distanceSqToPoint(t))}distanceSqToPoint(t){const e=ri.subVectors(t,this.origin).dot(this.direction);return e<0?this.origin.distanceToSquared(t):(ri.copy(this.origin).addScaledVector(this.direction,e),ri.distanceToSquared(t))}distanceSqToSegment(t,e,n,s){Ro.copy(t).add(e).multiplyScalar(.5),zr.copy(e).sub(t).normalize(),Hr.copy(this.origin).sub(Ro);const r=t.distanceTo(e)*.5,a=-this.direction.dot(zr),o=Hr.dot(this.direction),l=-Hr.dot(zr),c=Hr.lengthSq(),d=Math.abs(1-a*a);let h,u,f,g;if(d>0)if(h=a*l-o,u=a*o-l,g=r*d,h>=0)if(u>=-g)if(u<=g){const x=1/d;h*=x,u*=x,f=h*(h+a*u+2*o)+u*(a*h+u+2*l)+c}else u=r,h=Math.max(0,-(a*u+o)),f=-h*h+u*(u+2*l)+c;else u=-r,h=Math.max(0,-(a*u+o)),f=-h*h+u*(u+2*l)+c;else u<=-g?(h=Math.max(0,-(-a*r+o)),u=h>0?-r:Math.min(Math.max(-r,-l),r),f=-h*h+u*(u+2*l)+c):u<=g?(h=0,u=Math.min(Math.max(-r,-l),r),f=u*(u+2*l)+c):(h=Math.max(0,-(a*r+o)),u=h>0?r:Math.min(Math.max(-r,-l),r),f=-h*h+u*(u+2*l)+c);else u=a>0?-r:r,h=Math.max(0,-(a*u+o)),f=-h*h+u*(u+2*l)+c;return n&&n.copy(this.origin).addScaledVector(this.direction,h),s&&s.copy(Ro).addScaledVector(zr,u),f}intersectSphere(t,e){if(t.radius<0)return null;ri.subVectors(t.center,this.origin);const n=ri.dot(this.direction),s=ri.dot(ri)-n*n,r=t.radius*t.radius;if(s>r)return null;const a=Math.sqrt(r-s),o=n-a,l=n+a;return l<0?null:o<0?this.at(l,e):this.at(o,e)}intersectsSphere(t){return t.radius<0?!1:this.distanceSqToPoint(t.center)<=t.radius*t.radius}distanceToPlane(t){const e=t.normal.dot(this.direction);if(e===0)return t.distanceToPoint(this.origin)===0?0:null;const n=-(this.origin.dot(t.normal)+t.constant)/e;return n>=0?n:null}intersectPlane(t,e){const n=this.distanceToPlane(t);return n===null?null:this.at(n,e)}intersectsPlane(t){const e=t.distanceToPoint(this.origin);return e===0||t.normal.dot(this.direction)*e<0}intersectBox(t,e){let n,s,r,a,o,l;const c=1/this.direction.x,d=1/this.direction.y,h=1/this.direction.z,u=this.origin;return c>=0?(n=(t.min.x-u.x)*c,s=(t.max.x-u.x)*c):(n=(t.max.x-u.x)*c,s=(t.min.x-u.x)*c),d>=0?(r=(t.min.y-u.y)*d,a=(t.max.y-u.y)*d):(r=(t.max.y-u.y)*d,a=(t.min.y-u.y)*d),n>a||r>s||((r>n||isNaN(n))&&(n=r),(a<s||isNaN(s))&&(s=a),h>=0?(o=(t.min.z-u.z)*h,l=(t.max.z-u.z)*h):(o=(t.max.z-u.z)*h,l=(t.min.z-u.z)*h),n>l||o>s)||((o>n||n!==n)&&(n=o),(l<s||s!==s)&&(s=l),s<0)?null:this.at(n>=0?n:s,e)}intersectsBox(t){return this.intersectBox(t,ri)!==null}intersectTriangle(t,e,n,s,r){const a=this.origin,o=this.direction,l=o.x,c=o.y,d=o.z,h=t.x-a.x,u=t.y-a.y,f=t.z-a.z,g=e.x-a.x,x=e.y-a.y,m=e.z-a.z,p=n.x-a.x,_=n.y-a.y,S=n.z-a.z,y=Math.abs(l),A=Math.abs(c),E=Math.abs(d);let v,w,N,R,L,F,V,D,H,q,k,tt;if(y>=A&&y>=E?(N=l,F=h,H=g,tt=p,l>=0?(v=c,w=d,R=u,L=f,V=x,D=m,q=_,k=S):(v=d,w=c,R=f,L=u,V=m,D=x,q=S,k=_)):A>=E?(N=c,F=u,H=x,tt=_,c>=0?(v=d,w=l,R=f,L=h,V=m,D=g,q=S,k=p):(v=l,w=d,R=h,L=f,V=g,D=m,q=p,k=S)):(N=d,F=f,H=m,tt=S,d>=0?(v=l,w=c,R=h,L=u,V=g,D=x,q=p,k=_):(v=c,w=l,R=u,L=h,V=x,D=g,q=_,k=p)),N===0)return null;const W=v/N,j=w/N,Q=1/N,wt=R-W*F,Bt=L-j*F,K=V-W*H,mt=D-j*H,bt=q-W*tt,Rt=k-j*tt,vt=bt*mt-Rt*K,zt=wt*Rt-Bt*bt,Se=K*Bt-mt*wt;if(s){if(vt<0||zt<0||Se<0)return null}else if((vt<0||zt<0||Se<0)&&(vt>0||zt>0||Se>0))return null;const Pt=vt+zt+Se;if(Pt===0)return null;const se=Q*(vt*F+zt*H+Se*tt);return(Pt>0?se<0:se>0)?null:this.at(se/Pt,r)}applyMatrix4(t){return this.origin.applyMatrix4(t),this.direction.transformDirection(t),this}equals(t){return t.origin.equals(this.origin)&&t.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class Oe extends Oi{constructor(t){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new Nt(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new kn,this.combine=Kh,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.specularMap=t.specularMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapRotation.copy(t.envMapRotation),this.combine=t.combine,this.reflectivity=t.reflectivity,this.refractionRatio=t.refractionRatio,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.fog=t.fog,this}}const fd=new jt,Vi=new Ja,Gr=new ss,pd=new I,Vr=new I,$r=new I,Wr=new I,Co=new I,Xr=new I,md=new I,qr=new I;class $t extends Ae{constructor(t=new be,e=new Oe){super(),this.isMesh=!0,this.type="Mesh",this.geometry=t,this.material=e,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),t.morphTargetInfluences!==void 0?this.morphTargetInfluences=t.morphTargetInfluences.slice():this.morphTargetInfluences=void 0,t.morphTargetDictionary!==void 0?this.morphTargetDictionary=Object.assign({},t.morphTargetDictionary):this.morphTargetDictionary=void 0,this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}updateMorphTargets(){const e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){const s=e[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,a=s.length;r<a;r++){const o=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=r}}}}getVertexPosition(t,e){const n=this.geometry,s=n.attributes.position,r=n.morphAttributes.position,a=n.morphTargetsRelative;e.fromBufferAttribute(s,t);const o=this.morphTargetInfluences;if(r&&o){Xr.set(0,0,0);for(let l=0,c=r.length;l<c;l++){const d=o[l],h=r[l];d!==0&&(Co.fromBufferAttribute(h,t),a?Xr.addScaledVector(Co,d):Xr.addScaledVector(Co.sub(e),d))}e.add(Xr)}return e}intersectsFrustum(t){return t.intersectsObject(this)}raycast(t,e){const n=this.geometry,s=this.material,r=this.matrixWorld;s!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),Gr.copy(n.boundingSphere),Gr.applyMatrix4(r),Vi.copy(t.ray).recast(t.near),!(Gr.containsPoint(Vi.origin)===!1&&(Vi.intersectSphere(Gr,pd)===null||Vi.origin.distanceToSquared(pd)>(t.far-t.near)**2))&&(fd.copy(r).invert(),Vi.copy(t.ray).applyMatrix4(fd),!(n.boundingBox!==null&&Vi.intersectsBox(n.boundingBox)===!1)&&this._computeIntersections(t,e,Vi)))}_computeIntersections(t,e,n){let s;const r=this.geometry,a=this.material,o=r.index,l=r.attributes.position,c=r.attributes.uv,d=r.attributes.uv1,h=r.attributes.normal,u=r.groups,f=r.drawRange;if(o!==null)if(Array.isArray(a))for(let g=0,x=u.length;g<x;g++){const m=u[g],p=a[m.materialIndex],_=Math.max(m.start,f.start),S=Math.min(o.count,Math.min(m.start+m.count,f.start+f.count));for(let y=_,A=S;y<A;y+=3){const E=o.getX(y),v=o.getX(y+1),w=o.getX(y+2);s=Yr(this,p,t,n,c,d,h,E,v,w),s&&(s.faceIndex=Math.floor(y/3),s.face.materialIndex=m.materialIndex,e.push(s))}}else{const g=Math.max(0,f.start),x=Math.min(o.count,f.start+f.count);for(let m=g,p=x;m<p;m+=3){const _=o.getX(m),S=o.getX(m+1),y=o.getX(m+2);s=Yr(this,a,t,n,c,d,h,_,S,y),s&&(s.faceIndex=Math.floor(m/3),e.push(s))}}else if(l!==void 0)if(Array.isArray(a))for(let g=0,x=u.length;g<x;g++){const m=u[g],p=a[m.materialIndex],_=Math.max(m.start,f.start),S=Math.min(l.count,Math.min(m.start+m.count,f.start+f.count));for(let y=_,A=S;y<A;y+=3){const E=y,v=y+1,w=y+2;s=Yr(this,p,t,n,c,d,h,E,v,w),s&&(s.faceIndex=Math.floor(y/3),s.face.materialIndex=m.materialIndex,e.push(s))}}else{const g=Math.max(0,f.start),x=Math.min(l.count,f.start+f.count);for(let m=g,p=x;m<p;m+=3){const _=m,S=m+1,y=m+2;s=Yr(this,a,t,n,c,d,h,_,S,y),s&&(s.faceIndex=Math.floor(m/3),e.push(s))}}}}function Bp(i,t,e,n,s,r,a,o){let l;if(t.side===qe?l=n.intersectTriangle(a,r,s,!0,o):l=n.intersectTriangle(s,r,a,t.side===Ki,o),l===null)return null;qr.copy(o),qr.applyMatrix4(i.matrixWorld);const c=e.ray.origin.distanceTo(qr);return c<e.near||c>e.far?null:{distance:c,point:qr.clone(),object:i}}function Yr(i,t,e,n,s,r,a,o,l,c){i.getVertexPosition(o,Vr),i.getVertexPosition(l,$r),i.getVertexPosition(c,Wr);const d=Bp(i,t,e,n,Vr,$r,Wr,md);if(d){const h=new I;hn.getBarycoord(md,Vr,$r,Wr,h),s&&(d.uv=hn.getInterpolatedAttribute(s,o,l,c,h,new Dt)),r&&(d.uv1=hn.getInterpolatedAttribute(r,o,l,c,h,new Dt)),a&&(d.normal=hn.getInterpolatedAttribute(a,o,l,c,h,new I),d.normal.dot(n.direction)>0&&d.normal.multiplyScalar(-1));const u={a:o,b:l,c,normal:new I,materialIndex:0};hn.getNormal(Vr,$r,Wr,u.normal),d.face=u,d.barycoord=h}return d}class bu extends Ye{constructor(t=null,e=1,n=1,s,r,a,o,l,c=Ge,d=Ge,h,u){super(null,a,o,l,c,d,s,r,h,u),this.isDataTexture=!0,this.image={data:t,width:e,height:n},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class gd extends Ke{constructor(t,e,n,s=1){super(t,e,n),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=s}copy(t){return super.copy(t),this.meshPerAttribute=t.meshPerAttribute,this}toJSON(){const t=super.toJSON();return t.meshPerAttribute=this.meshPerAttribute,t.isInstancedBufferAttribute=!0,t}}const Ms=new jt,vd=new jt,Kr=[],xd=new is,kp=new jt,Zs=new $t,Js=new ss;class Zr extends $t{constructor(t,e,n){super(t,e),this.isInstancedMesh=!0,this.instanceMatrix=new gd(new Float32Array(n*16),16),this.instanceColor=null,this.morphTexture=null,this.count=n,this.boundingBox=null,this.boundingSphere=null;for(let s=0;s<n;s++)this.setMatrixAt(s,kp)}computeBoundingBox(){const t=this.geometry,e=this.count;this.boundingBox===null&&(this.boundingBox=new is),t.boundingBox===null&&t.computeBoundingBox(),this.boundingBox.makeEmpty();for(let n=0;n<e;n++)this.getMatrixAt(n,Ms),xd.copy(t.boundingBox).applyMatrix4(Ms),this.boundingBox.union(xd)}computeBoundingSphere(){const t=this.geometry,e=this.count;this.boundingSphere===null&&(this.boundingSphere=new ss),t.boundingSphere===null&&t.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let n=0;n<e;n++)this.getMatrixAt(n,Ms),Js.copy(t.boundingSphere).applyMatrix4(Ms),this.boundingSphere.union(Js)}copy(t,e){return super.copy(t,e),this.instanceMatrix.copy(t.instanceMatrix),this.morphTexture=t.morphTexture!==null?t.morphTexture.clone():null,this.instanceColor=t.instanceColor!==null?t.instanceColor.clone():null,this.count=t.count,this.boundingBox=t.boundingBox!==null?t.boundingBox.clone():null,this.boundingSphere=t.boundingSphere!==null?t.boundingSphere.clone():null,this}getColorAt(t,e){return this.instanceColor===null?e.setRGB(1,1,1):e.fromArray(this.instanceColor.array,t*3)}getMatrixAt(t,e){return e.fromArray(this.instanceMatrix.array,t*16)}getMorphAt(t,e){const n=e.morphTargetInfluences,s=this.morphTexture.source.data.data,r=n.length+1,a=t*r+1;for(let o=0;o<n.length;o++)n[o]=s[a+o]}raycast(t,e){const n=this.matrixWorld,s=this.count;if(Zs.geometry=this.geometry,Zs.material=this.material,Zs.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),Js.copy(this.boundingSphere),Js.applyMatrix4(n),t.ray.intersectsSphere(Js)!==!1))for(let r=0;r<s;r++){this.getMatrixAt(r,Ms),vd.multiplyMatrices(n,Ms),Zs.matrixWorld=vd,Zs.raycast(t,Kr);for(let a=0,o=Kr.length;a<o;a++){const l=Kr[a];l.instanceId=r,l.object=this,e.push(l)}Kr.length=0}}setColorAt(t,e){return this.instanceColor===null&&(this.instanceColor=new gd(new Float32Array(this.instanceMatrix.count*3).fill(1),3)),e.toArray(this.instanceColor.array,t*3),this}setMatrixAt(t,e){return e.toArray(this.instanceMatrix.array,t*16),this}setMorphAt(t,e){const n=e.morphTargetInfluences,s=n.length+1;this.morphTexture===null&&(this.morphTexture=new bu(new Float32Array(s*this.count),s,this.count,nc,Pn));const r=this.morphTexture.source.data.data;let a=0;for(let c=0;c<n.length;c++)a+=n[c];const o=this.geometry.morphTargetsRelative?1:1-a,l=s*t;return r[l]=o,r.set(n,l+1),this}updateMorphTargets(){}dispose(){super.dispose(),this.instanceMatrix.dispose(),this.instanceColor!==null&&this.instanceColor.dispose(),this.morphTexture!==null&&(this.morphTexture.dispose(),this.morphTexture=null)}}const $i=new ss,zp=new Dt(.5,.5),Jr=new I;class yr{constructor(t=new ci,e=new ci,n=new ci,s=new ci,r=new ci,a=new ci){this.planes=[t,e,n,s,r,a]}set(t,e,n,s,r,a){const o=this.planes;return o[0].copy(t),o[1].copy(e),o[2].copy(n),o[3].copy(s),o[4].copy(r),o[5].copy(a),this}copy(t){const e=this.planes;for(let n=0;n<6;n++)e[n].copy(t.planes[n]);return this}setFromProjectionMatrix(t,e=Ln,n=!1){const s=this.planes,r=t.elements,a=r[0],o=r[1],l=r[2],c=r[3],d=r[4],h=r[5],u=r[6],f=r[7],g=r[8],x=r[9],m=r[10],p=r[11],_=r[12],S=r[13],y=r[14],A=r[15];if(s[0].setComponents(c-a,f-d,p-g,A-_).normalize(),s[1].setComponents(c+a,f+d,p+g,A+_).normalize(),s[2].setComponents(c+o,f+h,p+x,A+S).normalize(),s[3].setComponents(c-o,f-h,p-x,A-S).normalize(),n)s[4].setComponents(l,u,m,y).normalize(),s[5].setComponents(c-l,f-u,p-m,A-y).normalize();else if(s[4].setComponents(c-l,f-u,p-m,A-y).normalize(),e===Ln)s[5].setComponents(c+l,f+u,p+m,A+y).normalize();else if(e===xr)s[5].setComponents(l,u,m,y).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+e);return this}intersectsObject(t){if(t.boundingSphere!==void 0)t.boundingSphere===null&&t.computeBoundingSphere(),$i.copy(t.boundingSphere).applyMatrix4(t.matrixWorld);else{const e=t.geometry;e.boundingSphere===null&&e.computeBoundingSphere(),$i.copy(e.boundingSphere).applyMatrix4(t.matrixWorld)}return this.intersectsSphere($i)}intersectsSprite(t){$i.center.set(0,0,0);const e=zp.distanceTo(t.center);return $i.radius=.7071067811865476+e,$i.applyMatrix4(t.matrixWorld),this.intersectsSphere($i)}intersectsSphere(t){const e=this.planes,n=t.center,s=-t.radius;for(let r=0;r<6;r++)if(e[r].distanceToPoint(n)<s)return!1;return!0}intersectsBox(t){const e=this.planes;for(let n=0;n<6;n++){const s=e[n];if(Jr.x=s.normal.x>0?t.max.x:t.min.x,Jr.y=s.normal.y>0?t.max.y:t.min.y,Jr.z=s.normal.z>0?t.max.z:t.min.z,s.distanceToPoint(Jr)<0)return!1}return!0}containsPoint(t){const e=this.planes;for(let n=0;n<6;n++)if(e[n].distanceToPoint(t)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}const _d=new jt;class uc{constructor(){this.coordinateSystem=Ln,this._frustums=[],this._count=0}setFromArrayCamera(t){const e=t.cameras,n=this._frustums;for(let s=0;s<e.length;s++){const r=e[s];_d.multiplyMatrices(r.projectionMatrix,r.matrixWorldInverse),n[s]===void 0&&(n[s]=new yr),n[s].setFromProjectionMatrix(_d,r.coordinateSystem,r.reversedDepth)}return this._count=e.length,this}getFrustum(t){return this._frustums[t]}intersectsObject(t){const e=this._frustums;for(let n=0;n<this._count;n++)if(e[n].intersectsObject(t))return!0;return!1}intersectsSprite(t){const e=this._frustums;for(let n=0;n<this._count;n++)if(e[n].intersectsSprite(t))return!0;return!1}intersectsSphere(t){const e=this._frustums;for(let n=0;n<this._count;n++)if(e[n].intersectsSphere(t))return!0;return!1}intersectsBox(t){const e=this._frustums;for(let n=0;n<this._count;n++)if(e[n].intersectsBox(t))return!0;return!1}containsPoint(t){const e=this._frustums;for(let n=0;n<this._count;n++)if(e[n].containsPoint(t))return!0;return!1}copy(t){this.coordinateSystem=t.coordinateSystem;const e=this._frustums,n=t._frustums;for(let s=0;s<t._count;s++)e[s]===void 0&&(e[s]=new yr),e[s].copy(n[s]);return this._count=t._count,this}clone(){return new uc().copy(this)}}class Cl extends Oi{constructor(t){super(),this.isLineBasicMaterial=!0,this.type="LineBasicMaterial",this.color=new Nt(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.linewidth=t.linewidth,this.linecap=t.linecap,this.linejoin=t.linejoin,this.fog=t.fog,this}}const Oa=new I,Ba=new I,yd=new jt,js=new Ja,jr=new ss,Po=new I,bd=new I;class Hp extends Ae{constructor(t=new be,e=new Cl){super(),this.isLine=!0,this.type="Line",this.geometry=t,this.material=e,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),t.morphTargetInfluences!==void 0?this.morphTargetInfluences=t.morphTargetInfluences.slice():this.morphTargetInfluences=void 0,t.morphTargetDictionary!==void 0?this.morphTargetDictionary=Object.assign({},t.morphTargetDictionary):this.morphTargetDictionary=void 0,this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}computeLineDistances(){const t=this.geometry;if(t.index===null){const e=t.attributes.position,n=[0];for(let s=1,r=e.count;s<r;s++)Oa.fromBufferAttribute(e,s-1),Ba.fromBufferAttribute(e,s),n[s]=n[s-1],n[s]+=Oa.distanceTo(Ba);t.setAttribute("lineDistance",new ne(n,1))}else Lt("Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}intersectsFrustum(t){return t.intersectsObject(this)}raycast(t,e){const n=this.geometry,s=this.matrixWorld,r=t.params.Line.threshold,a=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),jr.copy(n.boundingSphere),jr.applyMatrix4(s),jr.radius+=r,t.ray.intersectsSphere(jr)===!1)return;yd.copy(s).invert(),js.copy(t.ray).applyMatrix4(yd);const o=r/((this.scale.x+this.scale.y+this.scale.z)/3),l=o*o,c=this.isLineSegments?2:1,d=n.index,u=n.attributes.position;if(d!==null){const f=Math.max(0,a.start),g=Math.min(d.count,a.start+a.count);for(let x=f,m=g-1;x<m;x+=c){const p=d.getX(x),_=d.getX(x+1),S=Qr(this,t,js,l,p,_,x);S&&e.push(S)}if(this.isLineLoop){const x=d.getX(g-1),m=d.getX(f),p=Qr(this,t,js,l,x,m,g-1);p&&e.push(p)}}else{const f=Math.max(0,a.start),g=Math.min(u.count,a.start+a.count);for(let x=f,m=g-1;x<m;x+=c){const p=Qr(this,t,js,l,x,x+1,x);p&&e.push(p)}if(this.isLineLoop){const x=Qr(this,t,js,l,g-1,f,g-1);x&&e.push(x)}}}updateMorphTargets(){const e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){const s=e[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,a=s.length;r<a;r++){const o=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=r}}}}}function Qr(i,t,e,n,s,r,a){const o=i.geometry.attributes.position;if(Oa.fromBufferAttribute(o,s),Ba.fromBufferAttribute(o,r),e.distanceSqToSegment(Oa,Ba,Po,bd)>n)return;Po.applyMatrix4(i.matrixWorld);const c=t.ray.origin.distanceTo(Po);if(!(c<t.near||c>t.far))return{distance:c,point:bd.clone().applyMatrix4(i.matrixWorld),index:a,face:null,faceIndex:null,barycoord:null,object:i}}const Md=new I,Sd=new I;class wd extends Hp{constructor(t,e){super(t,e),this.isLineSegments=!0,this.type="LineSegments"}computeLineDistances(){const t=this.geometry;if(t.index===null){const e=t.attributes.position,n=[];for(let s=0,r=e.count;s<r;s+=2)Md.fromBufferAttribute(e,s),Sd.fromBufferAttribute(e,s+1),n[s]=s===0?0:n[s-1],n[s+1]=n[s]+Md.distanceTo(Sd);t.setAttribute("lineDistance",new ne(n,1))}else Lt("LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}}class fc extends Oi{constructor(t){super(),this.isPointsMaterial=!0,this.type="PointsMaterial",this.color=new Nt(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.alphaMap=t.alphaMap,this.size=t.size,this.sizeAttenuation=t.sizeAttenuation,this.fog=t.fog,this}}const Ed=new jt,Pl=new Ja,ta=new ss,ea=new I;class Mu extends Ae{constructor(t=new be,e=new fc){super(),this.isPoints=!0,this.type="Points",this.geometry=t,this.material=e,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),t.morphTargetInfluences!==void 0?this.morphTargetInfluences=t.morphTargetInfluences.slice():this.morphTargetInfluences=void 0,t.morphTargetDictionary!==void 0?this.morphTargetDictionary=Object.assign({},t.morphTargetDictionary):this.morphTargetDictionary=void 0,this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}intersectsFrustum(t){return t.intersectsObject(this)}raycast(t,e){const n=this.geometry,s=this.matrixWorld,r=t.params.Points.threshold,a=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),ta.copy(n.boundingSphere),ta.applyMatrix4(s),ta.radius+=r,t.ray.intersectsSphere(ta)===!1)return;Ed.copy(s).invert(),Pl.copy(t.ray).applyMatrix4(Ed);const o=r/((this.scale.x+this.scale.y+this.scale.z)/3),l=o*o,c=n.index,h=n.attributes.position;if(c!==null){const u=Math.max(0,a.start),f=Math.min(c.count,a.start+a.count);for(let g=u,x=f;g<x;g++){const m=c.getX(g);ea.fromBufferAttribute(h,m),Ad(ea,m,l,s,t,e,this)}}else{const u=Math.max(0,a.start),f=Math.min(h.count,a.start+a.count);for(let g=u,x=f;g<x;g++)ea.fromBufferAttribute(h,g),Ad(ea,g,l,s,t,e,this)}}updateMorphTargets(){const e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){const s=e[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,a=s.length;r<a;r++){const o=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=r}}}}}function Ad(i,t,e,n,s,r,a){const o=Pl.distanceSqToPoint(i);if(o<e){const l=new I;Pl.closestPointToPoint(i,l),l.applyMatrix4(n);const c=s.ray.origin.distanceTo(l);if(c<s.near||c>s.far)return;r.push({distance:c,distanceToRay:Math.sqrt(o),point:l,index:t,face:null,faceIndex:null,barycoord:null,object:a})}}class Su extends Ye{constructor(t=[],e=Os,n,s,r,a,o,l,c,d){super(t,e,n,s,r,a,o,l,c,d),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(t){this.image=t}}class wu extends Ye{constructor(t,e,n,s,r,a,o,l,c){super(t,e,n,s,r,a,o,l,c),this.isCanvasTexture=!0,this.needsUpdate=!0}}class ks extends Ye{constructor(t,e,n=Jn,s,r,a,o=Ge,l=Ge,c,d=Ni,h=1){if(d!==Ni&&d!==Di)throw new Error("THREE.DepthTexture: format must be either THREE.DepthFormat or THREE.DepthStencilFormat");const u={width:t,height:e,depth:h};super(u,s,r,a,o,l,d,n,c),this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(t){return super.copy(t),this.source=new cc(Object.assign({},t.image)),this.compareFunction=t.compareFunction,this}toJSON(t){const e=super.toJSON(t);return e.compareFunction=this.compareFunction,e}}class Eu extends ks{constructor(t,e=Jn,n=Os,s,r,a=Ge,o=Ge,l,c=Ni){const d={width:t,height:t,depth:1},h=[d,d,d,d,d,d];super(t,t,e,n,s,r,a,o,l,c),this.image=h,this.isCubeDepthTexture=!0,this.isCubeTexture=!0}get images(){return this.image}set images(t){this.image=t}}class Au extends Ye{constructor(t=null){super(),this.sourceTexture=t,this.isExternalTexture=!0}copy(t){return super.copy(t),this.sourceTexture=t.sourceTexture,this}}class zn extends be{constructor(t=1,e=1,n=1,s=1,r=1,a=1){super(),this.type="BoxGeometry",this.parameters={width:t,height:e,depth:n,widthSegments:s,heightSegments:r,depthSegments:a};const o=this;s=Math.floor(s),r=Math.floor(r),a=Math.floor(a);const l=[],c=[],d=[],h=[];let u=0,f=0;g("z","y","x",-1,-1,n,e,t,a,r,0),g("z","y","x",1,-1,n,e,-t,a,r,1),g("x","z","y",1,1,t,n,e,s,a,2),g("x","z","y",1,-1,t,n,-e,s,a,3),g("x","y","z",1,-1,t,e,n,s,r,4),g("x","y","z",-1,-1,t,e,-n,s,r,5),this.setIndex(l),this.setAttribute("position",new ne(c,3)),this.setAttribute("normal",new ne(d,3)),this.setAttribute("uv",new ne(h,2));function g(x,m,p,_,S,y,A,E,v,w,N){const R=y/v,L=A/w,F=y/2,V=A/2,D=E/2,H=v+1,q=w+1;let k=0,tt=0;const W=new I;for(let j=0;j<q;j++){const Q=j*L-V;for(let wt=0;wt<H;wt++){const Bt=wt*R-F;W[x]=Bt*_,W[m]=Q*S,W[p]=D,c.push(W.x,W.y,W.z),W[x]=0,W[m]=0,W[p]=E>0?1:-1,d.push(W.x,W.y,W.z),h.push(wt/v),h.push(1-j/w),k+=1}}for(let j=0;j<w;j++)for(let Q=0;Q<v;Q++){const wt=u+Q+H*j,Bt=u+Q+H*(j+1),K=u+(Q+1)+H*(j+1),mt=u+(Q+1)+H*j;l.push(wt,Bt,mt),l.push(Bt,K,mt),tt+=6}o.addGroup(f,tt,N),f+=tt,u+=k}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new zn(t.width,t.height,t.depth,t.widthSegments,t.heightSegments,t.depthSegments)}}class pc extends be{constructor(t=1,e=32,n=0,s=Math.PI*2){super(),this.type="CircleGeometry",this.parameters={radius:t,segments:e,thetaStart:n,thetaLength:s},e=Math.max(3,e);const r=[],a=[],o=[],l=[],c=new I,d=new Dt;a.push(0,0,0),o.push(0,0,1),l.push(.5,.5);for(let h=0,u=3;h<=e;h++,u+=3){const f=n+h/e*s;c.x=t*Math.cos(f),c.y=t*Math.sin(f),a.push(c.x,c.y,c.z),o.push(0,0,1),d.x=(a[u]/t+1)/2,d.y=(a[u+1]/t+1)/2,l.push(d.x,d.y)}for(let h=1;h<=e;h++)r.push(h,h+1,0);this.setIndex(r),this.setAttribute("position",new ne(a,3)),this.setAttribute("normal",new ne(o,3)),this.setAttribute("uv",new ne(l,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new pc(t.radius,t.segments,t.thetaStart,t.thetaLength)}}class mn extends be{constructor(t=1,e=1,n=1,s=32,r=1,a=!1,o=0,l=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:t,radiusBottom:e,height:n,radialSegments:s,heightSegments:r,openEnded:a,thetaStart:o,thetaLength:l};const c=this;s=Math.floor(s),r=Math.floor(r);const d=[],h=[],u=[],f=[];let g=0;const x=[],m=n/2;let p=0;_(),a===!1&&(t>0&&S(!0),e>0&&S(!1)),this.setIndex(d),this.setAttribute("position",new ne(h,3)),this.setAttribute("normal",new ne(u,3)),this.setAttribute("uv",new ne(f,2));function _(){const y=new I,A=new I;let E=0;const v=(e-t)/n;for(let w=0;w<=r;w++){const N=[],R=w/r,L=R*(e-t)+t;for(let F=0;F<=s;F++){const V=F/s,D=V*l+o,H=Math.sin(D),q=Math.cos(D);A.x=L*H,A.y=-R*n+m,A.z=L*q,h.push(A.x,A.y,A.z),y.set(H,v,q).normalize(),u.push(y.x,y.y,y.z),f.push(V,1-R),N.push(g++)}x.push(N)}for(let w=0;w<s;w++)for(let N=0;N<r;N++){const R=x[N][w],L=x[N+1][w],F=x[N+1][w+1],V=x[N][w+1];(t>0||N!==0)&&(d.push(R,L,V),E+=3),(e>0||N!==r-1)&&(d.push(L,F,V),E+=3)}c.addGroup(p,E,0),p+=E}function S(y){const A=g,E=new Dt,v=new I;let w=0;const N=y===!0?t:e,R=y===!0?1:-1;for(let F=1;F<=s;F++)h.push(0,m*R,0),u.push(0,R,0),f.push(.5,.5),g++;const L=g;for(let F=0;F<=s;F++){const D=F/s*l+o,H=Math.cos(D),q=Math.sin(D);v.x=N*q,v.y=m*R,v.z=N*H,h.push(v.x,v.y,v.z),u.push(0,R,0),E.x=H*.5+.5,E.y=q*.5*R+.5,f.push(E.x,E.y),g++}for(let F=0;F<s;F++){const V=A+F,D=L+F;y===!0?d.push(D,D+1,V):d.push(D+1,D,V),w+=3}c.addGroup(p,w,y===!0?1:2),p+=w}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new mn(t.radiusTop,t.radiusBottom,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}}class Ji extends mn{constructor(t=1,e=1,n=32,s=1,r=!1,a=0,o=Math.PI*2){super(0,t,e,n,s,r,a,o),this.type="ConeGeometry",this.parameters={radius:t,height:e,radialSegments:n,heightSegments:s,openEnded:r,thetaStart:a,thetaLength:o}}static fromJSON(t){return new Ji(t.radius,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}}class Sr extends be{constructor(t=[],e=[],n=1,s=0){super(),this.type="PolyhedronGeometry",this.parameters={vertices:t,indices:e,radius:n,detail:s};const r=[],a=[];o(s),c(n),d(),this.setAttribute("position",new ne(r,3)),this.setAttribute("normal",new ne(r.slice(),3)),this.setAttribute("uv",new ne(a,2)),s===0?this.computeVertexNormals():this.normalizeNormals();function o(_){const S=new I,y=new I,A=new I;for(let E=0;E<e.length;E+=3)f(e[E+0],S),f(e[E+1],y),f(e[E+2],A),l(S,y,A,_)}function l(_,S,y,A){const E=A+1,v=[];for(let w=0;w<=E;w++){v[w]=[];const N=_.clone().lerp(y,w/E),R=S.clone().lerp(y,w/E),L=E-w;for(let F=0;F<=L;F++)F===0&&w===E?v[w][F]=N:v[w][F]=N.clone().lerp(R,F/L)}for(let w=0;w<E;w++)for(let N=0;N<2*(E-w)-1;N++){const R=Math.floor(N/2);N%2===0?(u(v[w][R+1]),u(v[w+1][R]),u(v[w][R])):(u(v[w][R+1]),u(v[w+1][R+1]),u(v[w+1][R]))}}function c(_){const S=new I;for(let y=0;y<r.length;y+=3)S.x=r[y+0],S.y=r[y+1],S.z=r[y+2],S.normalize().multiplyScalar(_),r[y+0]=S.x,r[y+1]=S.y,r[y+2]=S.z}function d(){const _=new I;for(let S=0;S<r.length;S+=3){_.x=r[S+0],_.y=r[S+1],_.z=r[S+2];const y=m(_)/2/Math.PI+.5,A=p(_)/Math.PI+.5;a.push(y,1-A)}g(),h()}function h(){for(let _=0;_<a.length;_+=6){const S=a[_+0],y=a[_+2],A=a[_+4],E=Math.max(S,y,A),v=Math.min(S,y,A);E>.9&&v<.1&&(S<.2&&(a[_+0]+=1),y<.2&&(a[_+2]+=1),A<.2&&(a[_+4]+=1))}}function u(_){r.push(_.x,_.y,_.z)}function f(_,S){const y=_*3;S.x=t[y+0],S.y=t[y+1],S.z=t[y+2]}function g(){const _=new I,S=new I,y=new I,A=new I,E=new Dt,v=new Dt,w=new Dt;for(let N=0,R=0;N<r.length;N+=9,R+=6){_.set(r[N+0],r[N+1],r[N+2]),S.set(r[N+3],r[N+4],r[N+5]),y.set(r[N+6],r[N+7],r[N+8]),E.set(a[R+0],a[R+1]),v.set(a[R+2],a[R+3]),w.set(a[R+4],a[R+5]),A.copy(_).add(S).add(y).divideScalar(3);const L=m(A);x(E,R+0,_,L),x(v,R+2,S,L),x(w,R+4,y,L)}}function x(_,S,y,A){A<0&&_.x===1&&(a[S]=_.x-1),y.x===0&&y.z===0&&(a[S]=A/2/Math.PI+.5)}function m(_){return Math.atan2(_.z,-_.x)}function p(_){return Math.atan2(-_.y,Math.sqrt(_.x*_.x+_.z*_.z))}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new Sr(t.vertices,t.indices,t.radius,t.detail)}}class br extends Sr{constructor(t=1,e=0){const n=(1+Math.sqrt(5))/2,s=1/n,r=[-1,-1,-1,-1,-1,1,-1,1,-1,-1,1,1,1,-1,-1,1,-1,1,1,1,-1,1,1,1,0,-s,-n,0,-s,n,0,s,-n,0,s,n,-s,-n,0,-s,n,0,s,-n,0,s,n,0,-n,0,-s,n,0,-s,-n,0,s,n,0,s],a=[3,11,7,3,7,15,3,15,13,7,19,17,7,17,6,7,6,15,17,4,8,17,8,10,17,10,6,8,0,16,8,16,2,8,2,10,0,12,1,0,1,18,0,18,16,6,10,2,6,2,13,6,13,15,2,16,18,2,18,3,2,3,13,18,1,9,18,9,11,18,11,3,4,14,12,4,12,0,4,0,8,11,9,5,11,5,19,11,19,7,19,5,14,19,14,4,19,4,17,1,12,14,1,14,5,1,5,9];super(r,a,t,e),this.type="DodecahedronGeometry",this.parameters={radius:t,detail:e}}static fromJSON(t){return new br(t.radius,t.detail)}}const na=new I,ia=new I,Lo=new I,sa=new hn;class Gp extends be{constructor(t=null,e=1){if(super(),this.type="EdgesGeometry",this.parameters={geometry:t,thresholdAngle:e},t!==null){const s=Math.pow(10,4),r=Math.cos(Ps*e),a=t.getIndex(),o=t.getAttribute("position"),l=a?a.count:o.count,c=[0,0,0],d=["a","b","c"],h=new Array(3),u=new Map,f=[];for(let g=0;g<l;g+=3){a?(c[0]=a.getX(g),c[1]=a.getX(g+1),c[2]=a.getX(g+2)):(c[0]=g,c[1]=g+1,c[2]=g+2);const{a:x,b:m,c:p}=sa;if(x.fromBufferAttribute(o,c[0]),m.fromBufferAttribute(o,c[1]),p.fromBufferAttribute(o,c[2]),sa.getNormal(Lo),h[0]=`${Math.round(x.x*s)},${Math.round(x.y*s)},${Math.round(x.z*s)}`,h[1]=`${Math.round(m.x*s)},${Math.round(m.y*s)},${Math.round(m.z*s)}`,h[2]=`${Math.round(p.x*s)},${Math.round(p.y*s)},${Math.round(p.z*s)}`,!(h[0]===h[1]||h[1]===h[2]||h[2]===h[0]))for(let _=0;_<3;_++){const S=(_+1)%3,y=h[_],A=h[S],E=sa[d[_]],v=sa[d[S]],w=`${y}_${A}`,N=`${A}_${y}`,R=u.get(N);R?(Lo.dot(R.normal)<=r&&(f.push(E.x,E.y,E.z),f.push(v.x,v.y,v.z)),u.set(N,null)):u.has(w)||u.set(w,{index0:c[_],index1:c[S],normal:Lo.clone()})}}for(const g of u.values())if(g){const{index0:x,index1:m}=g;na.fromBufferAttribute(o,x),ia.fromBufferAttribute(o,m),f.push(na.x,na.y,na.z),f.push(ia.x,ia.y,ia.z)}this.setAttribute("position",new ne(f,3))}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}}class _i extends Sr{constructor(t=1,e=0){const n=(1+Math.sqrt(5))/2,s=[-1,n,0,1,n,0,-1,-n,0,1,-n,0,0,-1,n,0,1,n,0,-1,-n,0,1,-n,n,0,-1,n,0,1,-n,0,-1,-n,0,1],r=[0,11,5,0,5,1,0,1,7,0,7,10,0,10,11,1,5,9,5,11,4,11,10,2,10,7,6,7,1,8,3,9,4,3,4,2,3,2,6,3,6,8,3,8,9,4,9,5,2,4,11,6,2,10,8,6,7,9,8,1];super(s,r,t,e),this.type="IcosahedronGeometry",this.parameters={radius:t,detail:e}}static fromJSON(t){return new _i(t.radius,t.detail)}}class Yi extends Sr{constructor(t=1,e=0){const n=[1,0,0,-1,0,0,0,1,0,0,-1,0,0,0,1,0,0,-1],s=[0,2,4,0,4,3,0,3,5,0,5,2,1,2,5,1,5,3,1,3,4,1,4,2];super(n,s,t,e),this.type="OctahedronGeometry",this.parameters={radius:t,detail:e}}static fromJSON(t){return new Yi(t.radius,t.detail)}}class rs extends be{constructor(t=1,e=1,n=1,s=1){super(),this.type="PlaneGeometry",this.parameters={width:t,height:e,widthSegments:n,heightSegments:s};const r=t/2,a=e/2,o=Math.floor(n),l=Math.floor(s),c=o+1,d=l+1,h=t/o,u=e/l,f=[],g=[],x=[],m=[];for(let p=0;p<d;p++){const _=p*u-a;for(let S=0;S<c;S++){const y=S*h-r;g.push(y,-_,0),x.push(0,0,1),m.push(S/o),m.push(1-p/l)}}for(let p=0;p<l;p++)for(let _=0;_<o;_++){const S=_+c*p,y=_+c*(p+1),A=_+1+c*(p+1),E=_+1+c*p;f.push(S,y,E),f.push(y,A,E)}this.setIndex(f),this.setAttribute("position",new ne(g,3)),this.setAttribute("normal",new ne(x,3)),this.setAttribute("uv",new ne(m,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new rs(t.width,t.height,t.widthSegments,t.heightSegments)}}class mc extends be{constructor(t=.5,e=1,n=32,s=1,r=0,a=Math.PI*2){super(),this.type="RingGeometry",this.parameters={innerRadius:t,outerRadius:e,thetaSegments:n,phiSegments:s,thetaStart:r,thetaLength:a},n=Math.max(3,n),s=Math.max(1,s);const o=[],l=[],c=[],d=[];let h=t;const u=(e-t)/s,f=new I,g=new Dt;for(let x=0;x<=s;x++){for(let m=0;m<=n;m++){const p=r+m/n*a;f.x=h*Math.cos(p),f.y=h*Math.sin(p),l.push(f.x,f.y,f.z),c.push(0,0,1),g.x=(f.x/e+1)/2,g.y=(f.y/e+1)/2,d.push(g.x,g.y)}h+=u}for(let x=0;x<s;x++){const m=x*(n+1);for(let p=0;p<n;p++){const _=p+m,S=_,y=_+n+1,A=_+n+2,E=_+1;o.push(S,y,E),o.push(y,A,E)}}this.setIndex(o),this.setAttribute("position",new ne(l,3)),this.setAttribute("normal",new ne(c,3)),this.setAttribute("uv",new ne(d,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new mc(t.innerRadius,t.outerRadius,t.thetaSegments,t.phiSegments,t.thetaStart,t.thetaLength)}}class fn extends be{constructor(t=1,e=32,n=16,s=0,r=Math.PI*2,a=0,o=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:t,widthSegments:e,heightSegments:n,phiStart:s,phiLength:r,thetaStart:a,thetaLength:o},e=Math.max(3,Math.floor(e)),n=Math.max(2,Math.floor(n));const l=Math.min(a+o,Math.PI);let c=0;const d=[],h=new I,u=new I,f=[],g=[],x=[],m=[];for(let p=0;p<=n;p++){const _=[],S=p/n,y=a+S*o,A=t*Math.cos(y),E=Math.sqrt(t*t-A*A);let v=0;p===0&&a===0?v=.5/e:p===n&&l===Math.PI&&(v=-.5/e);for(let w=0;w<=e;w++){const N=w/e,R=s+N*r;h.x=-E*Math.cos(R),h.y=A,h.z=E*Math.sin(R),g.push(h.x,h.y,h.z),u.copy(h).normalize(),x.push(u.x,u.y,u.z),m.push(N+v,1-S),_.push(c++)}d.push(_)}for(let p=0;p<n;p++)for(let _=0;_<e;_++){const S=d[p][_+1],y=d[p][_],A=d[p+1][_],E=d[p+1][_+1];(p!==0||a>0)&&f.push(S,y,E),(p!==n-1||l<Math.PI)&&f.push(y,A,E)}this.setIndex(f),this.setAttribute("position",new ne(g,3)),this.setAttribute("normal",new ne(x,3)),this.setAttribute("uv",new ne(m,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new fn(t.radius,t.widthSegments,t.heightSegments,t.phiStart,t.phiLength,t.thetaStart,t.thetaLength)}}class nn extends be{constructor(t=1,e=.4,n=12,s=48,r=Math.PI*2,a=0,o=Math.PI*2){super(),this.type="TorusGeometry",this.parameters={radius:t,tube:e,radialSegments:n,tubularSegments:s,arc:r,thetaStart:a,thetaLength:o},n=Math.floor(n),s=Math.floor(s);const l=[],c=[],d=[],h=[],u=new I,f=new I,g=new I;for(let x=0;x<=n;x++){const m=a+x/n*o;for(let p=0;p<=s;p++){const _=p/s*r;f.x=(t+e*Math.cos(m))*Math.cos(_),f.y=(t+e*Math.cos(m))*Math.sin(_),f.z=e*Math.sin(m),c.push(f.x,f.y,f.z),u.x=t*Math.cos(_),u.y=t*Math.sin(_),g.subVectors(f,u).normalize(),d.push(g.x,g.y,g.z),h.push(p/s),h.push(x/n)}}for(let x=1;x<=n;x++)for(let m=1;m<=s;m++){const p=(s+1)*x+m-1,_=(s+1)*(x-1)+m-1,S=(s+1)*(x-1)+m,y=(s+1)*x+m;l.push(p,_,y),l.push(_,S,y)}this.setIndex(l),this.setAttribute("position",new ne(c,3)),this.setAttribute("normal",new ne(d,3)),this.setAttribute("uv",new ne(h,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new nn(t.radius,t.tube,t.radialSegments,t.tubularSegments,t.arc,t.thetaStart,t.thetaLength)}}function zs(i){const t={};for(const e in i){t[e]={};for(const n in i[e]){const s=i[e][n];if(Td(s))s.isRenderTargetTexture?(Lt("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),t[e][n]=null):t[e][n]=s.clone();else if(Array.isArray(s))if(Td(s[0])){const r=[];for(let a=0,o=s.length;a<o;a++)r[a]=s[a].clone();t[e][n]=r}else t[e][n]=s.slice();else t[e][n]=s}}return t}function je(i){const t={};for(let e=0;e<i.length;e++){const n=zs(i[e]);for(const s in n)t[s]=n[s]}return t}function Td(i){return i&&(i.isColor||i.isMatrix3||i.isMatrix4||i.isVector2||i.isVector3||i.isVector4||i.isTexture||i.isQuaternion)}function Vp(i){const t=[];for(let e=0;e<i.length;e++)t.push(i[e].clone());return t}function Tu(i){const t=i.getRenderTarget();return t===null?i.outputColorSpace:t.isXRRenderTarget===!0?t.texture.colorSpace:Jt.workingColorSpace}const $p={clone:zs,merge:je};var Wp=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,Xp=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class Un extends Oi{constructor(t){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=Wp,this.fragmentShader=Xp,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,t!==void 0&&this.setValues(t)}copy(t){return super.copy(t),this.fragmentShader=t.fragmentShader,this.vertexShader=t.vertexShader,this.uniforms=zs(t.uniforms),this.uniformsGroups=Vp(t.uniformsGroups),this.defines=Object.assign({},t.defines),this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.fog=t.fog,this.lights=t.lights,this.clipping=t.clipping,this.extensions=Object.assign({},t.extensions),this.glslVersion=t.glslVersion,this.defaultAttributeValues=Object.assign({},t.defaultAttributeValues),this.index0AttributeName=t.index0AttributeName,this.uniformsNeedUpdate=t.uniformsNeedUpdate,this}toJSON(t){const e=super.toJSON(t);e.glslVersion=this.glslVersion,e.uniforms={};for(const s in this.uniforms){const a=this.uniforms[s].value;a&&a.isTexture?e.uniforms[s]={type:"t",value:a.toJSON(t).uuid}:a&&a.isColor?e.uniforms[s]={type:"c",value:a.getHex()}:a&&a.isVector2?e.uniforms[s]={type:"v2",value:a.toArray()}:a&&a.isVector3?e.uniforms[s]={type:"v3",value:a.toArray()}:a&&a.isVector4?e.uniforms[s]={type:"v4",value:a.toArray()}:a&&a.isMatrix3?e.uniforms[s]={type:"m3",value:a.toArray()}:a&&a.isMatrix4?e.uniforms[s]={type:"m4",value:a.toArray()}:e.uniforms[s]={value:a}}Object.keys(this.defines).length>0&&(e.defines=this.defines),e.vertexShader=this.vertexShader,e.fragmentShader=this.fragmentShader,e.lights=this.lights,e.clipping=this.clipping;const n={};for(const s in this.extensions)this.extensions[s]===!0&&(n[s]=!0);return Object.keys(n).length>0&&(e.extensions=n),e}fromJSON(t,e){if(super.fromJSON(t,e),t.uniforms!==void 0)for(const n in t.uniforms){const s=t.uniforms[n];switch(this.uniforms[n]={},s.type){case"t":this.uniforms[n].value=e[s.value]||null;break;case"c":this.uniforms[n].value=new Nt().setHex(s.value);break;case"v2":this.uniforms[n].value=new Dt().fromArray(s.value);break;case"v3":this.uniforms[n].value=new I().fromArray(s.value);break;case"v4":this.uniforms[n].value=new _e().fromArray(s.value);break;case"m3":this.uniforms[n].value=new Ot().fromArray(s.value);break;case"m4":this.uniforms[n].value=new jt().fromArray(s.value);break;default:this.uniforms[n].value=s.value}}if(t.defines!==void 0&&(this.defines=t.defines),t.vertexShader!==void 0&&(this.vertexShader=t.vertexShader),t.fragmentShader!==void 0&&(this.fragmentShader=t.fragmentShader),t.glslVersion!==void 0&&(this.glslVersion=t.glslVersion),t.extensions!==void 0)for(const n in t.extensions)this.extensions[n]=t.extensions[n];return t.lights!==void 0&&(this.lights=t.lights),t.clipping!==void 0&&(this.clipping=t.clipping),this}}class qp extends Un{constructor(t){super(t),this.isRawShaderMaterial=!0,this.type="RawShaderMaterial"}}class Dn extends Oi{constructor(t){super(),this.isMeshStandardMaterial=!0,this.type="MeshStandardMaterial",this.defines={STANDARD:""},this.color=new Nt(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new Nt(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=Rl,this.normalScale=new Dt(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new kn,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.defines={STANDARD:""},this.color.copy(t.color),this.roughness=t.roughness,this.metalness=t.metalness,this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.emissive.copy(t.emissive),this.emissiveMap=t.emissiveMap,this.emissiveIntensity=t.emissiveIntensity,this.bumpMap=t.bumpMap,this.bumpScale=t.bumpScale,this.normalMap=t.normalMap,this.normalMapType=t.normalMapType,this.normalScale.copy(t.normalScale),this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.roughnessMap=t.roughnessMap,this.metalnessMap=t.metalnessMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapRotation.copy(t.envMapRotation),this.envMapIntensity=t.envMapIntensity,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.flatShading=t.flatShading,this.fog=t.fog,this}}class Yp extends Oi{constructor(t){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=$f,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(t)}copy(t){return super.copy(t),this.depthPacking=t.depthPacking,this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this}}class Kp extends Oi{constructor(t){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(t)}copy(t){return super.copy(t),this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this}}class ja extends Ae{static registerNode(t){this.prototype._lightNode=t}constructor(t,e=1){super(),this.isLight=!0,this.type="Light",this.color=new Nt(t),this.intensity=e}copy(t,e){return super.copy(t,e),this.color.copy(t.color),this.intensity=t.intensity,this}toJSON(t){const e=super.toJSON(t);return e.object.color=this.color.getHex(),e.object.intensity=this.intensity,e}}class Ru extends ja{constructor(t,e,n){super(t,n),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(Ae.DEFAULT_UP),this.updateMatrix(),this.groundColor=new Nt(e)}copy(t,e){return super.copy(t,e),this.groundColor.copy(t.groundColor),this}toJSON(t){const e=super.toJSON(t);return e.object.groundColor=this.groundColor.getHex(),e}}const Do=new jt,Rd=new I,Cd=new I;class Cu{constructor(t){this.camera=t,this.intensity=1,this.bias=0,this.biasNode=null,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new Dt(512,512),this.mapType=an,this.map=null,this.mapPass=null,this.matrix=new jt,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new yr,this._frameExtents=new Dt(1,1),this._viewportCount=1,this._viewports=[new _e(0,0,1,1)]}getViewportCount(){return this._viewportCount}getCamera(){return this.camera}getFrustum(){return this._frustum}updateMatrices(t){const e=this.camera;Rd.setFromMatrixPosition(t.matrixWorld),e.position.copy(Rd),Cd.setFromMatrixPosition(t.target.matrixWorld),e.lookAt(Cd),e.updateMatrixWorld(),this._updateMatrix(e,this.matrix,this._frustum)}_updateMatrix(t,e,n,s){Do.multiplyMatrices(t.projectionMatrix,t.matrixWorldInverse),n.setFromProjectionMatrix(Do,t.coordinateSystem,t.reversedDepth);const r=this._frameExtents,a=s?s.z/r.x:1,o=s?s.w/r.y:1,l=s?s.x/r.x:0,c=s?s.y/r.y:0;t.coordinateSystem===xr||t.reversedDepth?e.set(.5*a,0,0,.5*a+l,0,.5*o,0,.5*o+c,0,0,1,0,0,0,0,1):e.set(.5*a,0,0,.5*a+l,0,.5*o,0,.5*o+c,0,0,.5,.5,0,0,0,1),e.multiply(Do)}getViewport(t){return this._viewports[t]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(t){return this.camera=t.camera.clone(),this.intensity=t.intensity,this.bias=t.bias,this.radius=t.radius,this.autoUpdate=t.autoUpdate,this.needsUpdate=t.needsUpdate,this.normalBias=t.normalBias,this.blurSamples=t.blurSamples,this.mapSize.copy(t.mapSize),this.mapType=t.mapType,this.biasNode=t.biasNode,this}clone(){return new this.constructor().copy(this)}toJSON(){const t={};return t.intensity=this.intensity,t.bias=this.bias,t.normalBias=this.normalBias,t.radius=this.radius,t.blurSamples=this.blurSamples,t.mapSize=this.mapSize.toArray(),t.mapType=this.mapType,t.camera=this.camera.toJSON(!1).object,delete t.camera.matrix,t}}const ra=new I,aa=new xi,Vn=new I;class Pu extends Ae{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new jt,this.projectionMatrix=new jt,this.projectionMatrixInverse=new jt,this.coordinateSystem=Ln,this._reversedDepth=!1}get reversedDepth(){return this._reversedDepth}copy(t,e){return super.copy(t,e),this.matrixWorldInverse.copy(t.matrixWorldInverse),this.projectionMatrix.copy(t.projectionMatrix),this.projectionMatrixInverse.copy(t.projectionMatrixInverse),this.coordinateSystem=t.coordinateSystem,this}getWorldDirection(t){return super.getWorldDirection(t).negate()}updateMatrixWorld(t){super.updateMatrixWorld(t),this.matrixWorld.decompose(ra,aa,Vn),Vn.x===1&&Vn.y===1&&Vn.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(ra,aa,Vn.set(1,1,1)).invert()}updateWorldMatrix(t,e,n=!1){super.updateWorldMatrix(t,e,n),this.matrixWorld.decompose(ra,aa,Vn),Vn.x===1&&Vn.y===1&&Vn.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(ra,aa,Vn.set(1,1,1)).invert()}clone(){return new this.constructor().copy(this)}}const Ai=new I,Pd=new Dt,Ld=new Dt;class dn extends Pu{constructor(t=50,e=1,n=.1,s=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=t,this.zoom=1,this.near=n,this.far=s,this.focus=10,this.aspect=e,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.fov=t.fov,this.zoom=t.zoom,this.near=t.near,this.far=t.far,this.focus=t.focus,this.aspect=t.aspect,this.view=t.view===null?null:Object.assign({},t.view),this.filmGauge=t.filmGauge,this.filmOffset=t.filmOffset,this}setFocalLength(t){const e=.5*this.getFilmHeight()/t;this.fov=_r*2*Math.atan(e),this.updateProjectionMatrix()}getFocalLength(){const t=Math.tan(Ps*.5*this.fov);return .5*this.getFilmHeight()/t}getEffectiveFOV(){return _r*2*Math.atan(Math.tan(Ps*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(t,e,n){Ai.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),e.set(Ai.x,Ai.y).multiplyScalar(-t/Ai.z),Ai.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),n.set(Ai.x,Ai.y).multiplyScalar(-t/Ai.z)}getViewSize(t,e){return this.getViewBounds(t,Pd,Ld),e.subVectors(Ld,Pd)}setViewOffset(t,e,n,s,r,a){this.aspect=t/e,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=n,this.view.offsetY=s,this.view.width=r,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const t=this.near;let e=t*Math.tan(Ps*.5*this.fov)/this.zoom,n=2*e,s=this.aspect*n,r=-.5*s;const a=this.view;if(this.view!==null&&this.view.enabled){const l=a.fullWidth,c=a.fullHeight;r+=a.offsetX*s/l,e-=a.offsetY*n/c,s*=a.width/l,n*=a.height/c}const o=this.filmOffset;o!==0&&(r+=t*o/this.getFilmWidth()),this.projectionMatrix.makePerspective(r,r+s,e,e-n,t,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){const e=super.toJSON(t);return e.object.fov=this.fov,e.object.zoom=this.zoom,e.object.near=this.near,e.object.far=this.far,e.object.focus=this.focus,e.object.aspect=this.aspect,this.view!==null&&(e.object.view=Object.assign({},this.view)),e.object.filmGauge=this.filmGauge,e.object.filmOffset=this.filmOffset,e}}class Zp extends Cu{constructor(){super(new dn(90,1,.5,500)),this.isPointLightShadow=!0}}class Jp extends ja{constructor(t,e,n=0,s=2){super(t,e),this.isPointLight=!0,this.type="PointLight",this.distance=n,this.decay=s,this.shadow=new Zp}get power(){return this.intensity*4*Math.PI}set power(t){this.intensity=t/(4*Math.PI)}dispose(){super.dispose(),this.shadow.dispose()}copy(t,e){return super.copy(t,e),this.distance=t.distance,this.decay=t.decay,this.shadow=t.shadow.clone(),this}toJSON(t){const e=super.toJSON(t);return e.object.distance=this.distance,e.object.decay=this.decay,e.object.shadow=this.shadow.toJSON(),e}}class gc extends Pu{constructor(t=-1,e=1,n=1,s=-1,r=.1,a=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=t,this.right=e,this.top=n,this.bottom=s,this.near=r,this.far=a,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.left=t.left,this.right=t.right,this.top=t.top,this.bottom=t.bottom,this.near=t.near,this.far=t.far,this.zoom=t.zoom,this.view=t.view===null?null:Object.assign({},t.view),this}setViewOffset(t,e,n,s,r,a){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=n,this.view.offsetY=s,this.view.width=r,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const t=(this.right-this.left)/(2*this.zoom),e=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,s=(this.top+this.bottom)/2;let r=n-t,a=n+t,o=s+e,l=s-e;if(this.view!==null&&this.view.enabled){const c=(this.right-this.left)/this.view.fullWidth/this.zoom,d=(this.top-this.bottom)/this.view.fullHeight/this.zoom;r+=c*this.view.offsetX,a=r+c*this.view.width,o-=d*this.view.offsetY,l=o-d*this.view.height}this.projectionMatrix.makeOrthographic(r,a,o,l,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){const e=super.toJSON(t);return e.object.zoom=this.zoom,e.object.left=this.left,e.object.right=this.right,e.object.top=this.top,e.object.bottom=this.bottom,e.object.near=this.near,e.object.far=this.far,this.view!==null&&(e.object.view=Object.assign({},this.view)),e}}class jp extends Cu{constructor(){super(new gc(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}}class ka extends ja{constructor(t,e){super(t,e),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(Ae.DEFAULT_UP),this.updateMatrix(),this.target=new Ae,this.shadow=new jp}dispose(){super.dispose(),this.shadow.dispose()}copy(t){return super.copy(t),this.target=t.target.clone(),this.shadow=t.shadow.clone(),this}toJSON(t){const e=super.toJSON(t);return e.object.shadow=this.shadow.toJSON(),e.object.target=this.target.uuid,e}}class Qp extends ja{constructor(t,e){super(t,e),this.isAmbientLight=!0,this.type="AmbientLight"}}const Ss=-90,ws=1;class Ll extends Ae{constructor(t,e,n){super(),this.type="CubeCamera",this.renderTarget=n,this.coordinateSystem=null,this.activeMipmapLevel=0;const s=new dn(Ss,ws,t,e);s.layers=this.layers,this.add(s);const r=new dn(Ss,ws,t,e);r.layers=this.layers,this.add(r);const a=new dn(Ss,ws,t,e);a.layers=this.layers,this.add(a);const o=new dn(Ss,ws,t,e);o.layers=this.layers,this.add(o);const l=new dn(Ss,ws,t,e);l.layers=this.layers,this.add(l);const c=new dn(Ss,ws,t,e);c.layers=this.layers,this.add(c)}updateCoordinateSystem(){const t=this.coordinateSystem,e=this.children.concat(),[n,s,r,a,o,l]=e;for(const c of e)this.remove(c);if(t===Ln)n.up.set(0,1,0),n.lookAt(1,0,0),s.up.set(0,1,0),s.lookAt(-1,0,0),r.up.set(0,0,-1),r.lookAt(0,1,0),a.up.set(0,0,1),a.lookAt(0,-1,0),o.up.set(0,1,0),o.lookAt(0,0,1),l.up.set(0,1,0),l.lookAt(0,0,-1);else if(t===xr)n.up.set(0,-1,0),n.lookAt(-1,0,0),s.up.set(0,-1,0),s.lookAt(1,0,0),r.up.set(0,0,1),r.lookAt(0,1,0),a.up.set(0,0,-1),a.lookAt(0,-1,0),o.up.set(0,-1,0),o.lookAt(0,0,1),l.up.set(0,-1,0),l.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+t);for(const c of e)this.add(c),c.updateMatrixWorld()}update(t,e){this.parent===null&&this.updateMatrixWorld();const{renderTarget:n,activeMipmapLevel:s}=this;this.coordinateSystem!==t.coordinateSystem&&(this.coordinateSystem=t.coordinateSystem,this.updateCoordinateSystem());const[r,a,o,l,c,d]=this.children,h=t.getRenderTarget(),u=t.getActiveCubeFace(),f=t.getActiveMipmapLevel(),g=t.xr.enabled;t.xr.enabled=!1;const x=n.texture.mipmapsAutoUpdate;n.texture.mipmapsAutoUpdate=!1;let m=!1;t.isWebGLRenderer===!0?m=t.state.buffers.depth.getReversed():m=t.reversedDepthBuffer,t.setRenderTarget(n,0,s),m&&t.autoClear===!1&&t.clearDepth(),t.render(e,r),t.setRenderTarget(n,1,s),m&&t.autoClear===!1&&t.clearDepth(),t.render(e,a),t.setRenderTarget(n,2,s),m&&t.autoClear===!1&&t.clearDepth(),t.render(e,o),t.setRenderTarget(n,3,s),m&&t.autoClear===!1&&t.clearDepth(),t.render(e,l),t.setRenderTarget(n,4,s),m&&t.autoClear===!1&&t.clearDepth(),t.render(e,c),n.texture.mipmapsAutoUpdate=x,t.setRenderTarget(n,5,s),m&&t.autoClear===!1&&t.clearDepth(),t.render(e,d),t.setRenderTarget(h,u,f),t.xr.enabled=g,n.texture.needsPMREMUpdate=!0}}class tm extends dn{constructor(t=[]){super(),this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=t,this.perCameraFrustumCulled=!1}}const Dd=new jt;class em{constructor(t,e,n=0,s=1/0){this.ray=new Ja(t,e),this.near=n,this.far=s,this.camera=null,this.layers=new dc,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(t,e){this.ray.set(t,e)}setFromCamera(t,e){e.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(e.matrixWorld),this.ray.direction.set(t.x,t.y,.5).unproject(e).sub(this.ray.origin).normalize(),this.camera=e):e.isOrthographicCamera?(this.ray.origin.set(t.x,t.y,e.projectionMatrix.elements[14]).unproject(e),this.ray.direction.set(0,0,-1).transformDirection(e.matrixWorld),this.camera=e):ee("Raycaster: Unsupported camera type: "+e.type)}setFromXRController(t){return Dd.identity().extractRotation(t.matrixWorld),this.ray.origin.setFromMatrixPosition(t.matrixWorld),this.ray.direction.set(0,0,-1).applyMatrix4(Dd),this}intersectObject(t,e=!0,n=[]){return Dl(t,this,n,e),n.sort(Id),n}intersectObjects(t,e=!0,n=[]){for(let s=0,r=t.length;s<r;s++)Dl(t[s],this,n,e);return n.sort(Id),n}}function Id(i,t){return i.distance-t.distance}function Dl(i,t,e,n){let s=!0;if(i.layers.test(t.layers)&&i.raycast(t,e)===!1&&(s=!1),s===!0&&n===!0){const r=i.children;for(let a=0,o=r.length;a<o;a++)Dl(r[a],t,e,!0)}}function Nd(i,t,e,n){const s=nm(n);switch(e){case ou:return i*t;case nc:return i*t/s.components*s.byteLength;case ic:return i*t/s.components*s.byteLength;case Zi:return i*t*2/s.components*s.byteLength;case sc:return i*t*2/s.components*s.byteLength;case lu:return i*t*3/s.components*s.byteLength;case Kn:return i*t*4/s.components*s.byteLength;case rc:return i*t*4/s.components*s.byteLength;case xa:case _a:return Math.floor((i+3)/4)*Math.floor((t+3)/4)*8;case ya:case ba:return Math.floor((i+3)/4)*Math.floor((t+3)/4)*16;case Qo:case el:return Math.max(i,16)*Math.max(t,8)/4;case jo:case tl:return Math.max(i,8)*Math.max(t,8)/2;case nl:case il:case rl:case al:return Math.floor((i+3)/4)*Math.floor((t+3)/4)*8;case sl:case Ca:case ol:return Math.floor((i+3)/4)*Math.floor((t+3)/4)*16;case ll:return Math.floor((i+3)/4)*Math.floor((t+3)/4)*16;case cl:return Math.floor((i+4)/5)*Math.floor((t+3)/4)*16;case dl:return Math.floor((i+4)/5)*Math.floor((t+4)/5)*16;case hl:return Math.floor((i+5)/6)*Math.floor((t+4)/5)*16;case ul:return Math.floor((i+5)/6)*Math.floor((t+5)/6)*16;case fl:return Math.floor((i+7)/8)*Math.floor((t+4)/5)*16;case pl:return Math.floor((i+7)/8)*Math.floor((t+5)/6)*16;case ml:return Math.floor((i+7)/8)*Math.floor((t+7)/8)*16;case gl:return Math.floor((i+9)/10)*Math.floor((t+4)/5)*16;case vl:return Math.floor((i+9)/10)*Math.floor((t+5)/6)*16;case xl:return Math.floor((i+9)/10)*Math.floor((t+7)/8)*16;case _l:return Math.floor((i+9)/10)*Math.floor((t+9)/10)*16;case yl:return Math.floor((i+11)/12)*Math.floor((t+9)/10)*16;case bl:return Math.floor((i+11)/12)*Math.floor((t+11)/12)*16;case Ml:case Sl:case wl:return Math.ceil(i/4)*Math.ceil(t/4)*16;case El:case Al:return Math.ceil(i/4)*Math.ceil(t/4)*8;case Pa:case Tl:return Math.ceil(i/4)*Math.ceil(t/4)*16}throw new Error(`Unable to determine texture byte length for ${e} format.`)}function nm(i){switch(i){case an:case iu:return{byteLength:1,components:1};case vr:case su:case jn:return{byteLength:2,components:1};case tc:case ec:return{byteLength:2,components:4};case Jn:case Ql:case Pn:return{byteLength:4,components:1};case ru:case au:return{byteLength:4,components:3}}throw new Error(`THREE.TextureUtils: Unknown texture type ${i}.`)}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:Jl}}));typeof window<"u"&&(window.__THREE__?Lt("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=Jl);function Lu(){let i=null,t=!1,e=null,n=null;function s(r,a){n=i.requestAnimationFrame(s),e(r,a)}return{start:function(){t!==!0&&e!==null&&i!==null&&(n=i.requestAnimationFrame(s),t=!0)},stop:function(){i!==null&&i.cancelAnimationFrame(n),t=!1},setAnimationLoop:function(r){e=r},setContext:function(r){i=r}}}function im(i){const t=new WeakMap;function e(o,l){const c=o.array,d=o.usage,h=c.byteLength,u=i.createBuffer();i.bindBuffer(l,u),i.bufferData(l,c,d),o.onUploadCallback();let f;if(c instanceof Float32Array)f=i.FLOAT;else if(typeof Float16Array<"u"&&c instanceof Float16Array)f=i.HALF_FLOAT;else if(c instanceof Uint16Array)o.isFloat16BufferAttribute?f=i.HALF_FLOAT:f=i.UNSIGNED_SHORT;else if(c instanceof Int16Array)f=i.SHORT;else if(c instanceof Uint32Array)f=i.UNSIGNED_INT;else if(c instanceof Int32Array)f=i.INT;else if(c instanceof Int8Array)f=i.BYTE;else if(c instanceof Uint8Array)f=i.UNSIGNED_BYTE;else if(c instanceof Uint8ClampedArray)f=i.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+c);return{buffer:u,type:f,bytesPerElement:c.BYTES_PER_ELEMENT,version:o.version,size:h}}function n(o,l,c){const d=l.array,h=l.updateRanges;if(i.bindBuffer(c,o),h.length===0)i.bufferSubData(c,0,d);else{h.sort((f,g)=>f.start-g.start);let u=0;for(let f=1;f<h.length;f++){const g=h[u],x=h[f];x.start<=g.start+g.count+1?g.count=Math.max(g.count,x.start+x.count-g.start):(++u,h[u]=x)}h.length=u+1;for(let f=0,g=h.length;f<g;f++){const x=h[f];i.bufferSubData(c,x.start*d.BYTES_PER_ELEMENT,d,x.start,x.count)}l.clearUpdateRanges()}l.onUploadCallback()}function s(o){return o.isInterleavedBufferAttribute&&(o=o.data),t.get(o)}function r(o){o.isInterleavedBufferAttribute&&(o=o.data);const l=t.get(o);l&&(i.deleteBuffer(l.buffer),t.delete(o))}function a(o,l){if(o.isInterleavedBufferAttribute&&(o=o.data),o.isGLBufferAttribute){const d=t.get(o);(!d||d.version<o.version)&&t.set(o,{buffer:o.buffer,type:o.type,bytesPerElement:o.elementSize,version:o.version});return}const c=t.get(o);if(c===void 0)t.set(o,e(o,l));else if(c.version<o.version){if(c.size!==o.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");n(c.buffer,o,l),c.version=o.version}}return{get:s,remove:r,update:a}}var sm=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,rm=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,am=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,om=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,lm=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,cm=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,dm=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,hm=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,um=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec4 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 );
	}
#endif`,fm=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,pm=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,mm=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,gm=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,vm=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,xm=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,_m=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,ym=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,bm=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,Mm=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,Sm=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#endif`,wm=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#endif`,Em=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec4 vColor;
#endif`,Am=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec4( 1.0 );
#endif
#ifdef USE_COLOR_ALPHA
	vColor *= color;
#elif defined( USE_COLOR )
	vColor.rgb *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.rgb *= instanceColor.rgb;
#endif
#ifdef USE_BATCHING_COLOR
	vColor *= getBatchingColor( getIndirectIndex( gl_DrawID ) );
#endif`,Tm=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
#define inverseTransformDirection transformDirectionByInverseViewMatrix
vec3 transformNormalByInverseViewMatrix( in vec3 normal, in mat4 viewMatrix ) {
	return normalize( ( vec4( normal, 0.0 ) * viewMatrix ).xyz );
}
vec3 transformDirectionByInverseViewMatrix( in vec3 dir, in mat4 viewMatrix ) {
	return normalize( ( vec4( dir, 0.0 ) * viewMatrix ).xyz );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,Rm=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
#endif`,Cm=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,Pm=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,Lm=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,Dm=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,Im="gl_FragColor = linearToOutputTexel( gl_FragColor );",Nm=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,Um=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * reflectVec );
		#ifdef ENVMAP_BLENDING_MULTIPLY
			outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_MIX )
			outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_ADD )
			outgoingLight += envColor.xyz * specularStrength * reflectivity;
		#endif
	#endif
#endif`,Fm=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform mat3 envMapRotation;
	uniform samplerCube envMap;
	#ifdef ENVMAP_TYPE_PMREM
		float roughnessToMip( const in float roughness ) {
			float r = clamp( roughness, 0.0, 1.0 );
			return ENVMAP_MAX_LOD * r * ( 2.0 - r );
		}
	#endif
#endif`,Om=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,Bm=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,km=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,zm=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,Hm=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,Gm=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,Vm=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,$m=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,Wm=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,Xm=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,qm=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,Ym=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_SUN_LIGHTS > 0
	struct SunLight {
		vec3 direction;
		vec3 color;
	};
	uniform SunLight sunLights[ NUM_SUN_LIGHTS ];
	void getSunLightInfo( const in SunLight sunLight, out IncidentLight light ) {
		light.color = sunLight.color;
		light.direction = sunLight.direction;
		light.visible = true;
	}
#endif
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif
#include <lightprobes_pars_fragment>`,Km=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_PMREM
			vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
			vec4 envMapColor = textureLod( envMap, envMapRotation * worldNormal, ENVMAP_MAX_LOD );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_PMREM
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, pow4( roughness ) ) );
			reflectVec = transformDirectionByInverseViewMatrix( reflectVec, viewMatrix );
			vec4 envMapColor = textureLod( envMap, envMapRotation * reflectVec, roughnessToMip( roughness ) );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_RETROREFLECTION
		vec3 getIBLRetroRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
			#ifdef ENVMAP_TYPE_PMREM
				vec3 retroVec = normalize( mix( viewDir, normal, pow4( roughness ) ) );
				retroVec = transformDirectionByInverseViewMatrix( retroVec, viewMatrix );
				vec4 envMapColor = textureLod( envMap, envMapRotation * retroVec, roughnessToMip( roughness ) );
				return envMapColor.rgb * envMapIntensity;
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_PMREM
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
		#ifdef USE_RETROREFLECTION
			vec3 getIBLAnisotropyRetroRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
				#ifdef ENVMAP_TYPE_PMREM
					vec3 bentNormal = cross( bitangent, viewDir );
					bentNormal = normalize( cross( bentNormal, bitangent ) );
					bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
					return getIBLRetroRadiance( viewDir, bentNormal, roughness );
				#else
					return vec3( 0.0 );
				#endif
			}
		#endif
	#endif
#endif`,Zm=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,Jm=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,jm=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,Qm=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,t0=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.diffuseContribution = diffuseColor.rgb * ( 1.0 - metalnessFactor );
material.metalness = metalnessFactor;
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.045 );
material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef USE_DIFFUSE_ROUGHNESS
	float diffuseRoughnessFactor = diffuseRoughness;
	#ifdef USE_DIFFUSE_ROUGHNESSMAP
		diffuseRoughnessFactor *= texture2D( diffuseRoughnessMap, vDiffuseRoughnessMapUv ).r;
	#endif
	material.diffuseRoughness = saturate( diffuseRoughnessFactor );
#endif
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor;
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = vec3( 0.04 );
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.045 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_RETROREFLECTION
	material.retroreflectivity = retroreflectivity;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.0001, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,e0=`uniform sampler2D dfgLUT;
struct PhysicalMaterial {
	vec3 diffuseColor;
	vec3 diffuseContribution;
	vec3 specularColor;
	vec3 specularColorBlended;
	float roughness;
	float metalness;
	float specularF90;
	float dispersion;
	vec2 dfg;
	vec3 multiScatteringCompensation;
	#ifdef USE_DIFFUSE_ROUGHNESS
		float diffuseRoughness;
	#endif
	#ifdef USE_RETROREFLECTION
		float retroreflectivity;
	#endif
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0Dielectric;
		vec3 iridescenceF0Metallic;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
#ifdef USE_DIFFUSE_ROUGHNESS
	const float EON_EPSILON = 1e-7;
	float FON_DirectionalAlbedo( const in float mu, const in float roughness, const in float A ) {
		float muComp = 1.0 - mu;
		float gOverPi = muComp * ( 0.0571085289 + muComp * ( 0.491881867 + muComp * ( - 0.332181442 + muComp * 0.0714429953 ) ) );
		return A * ( 1.0 + roughness * gOverPi );
	}
	vec3 BRDF_EON( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 diffuseColor, const in float roughness ) {
		vec3 rho = saturate( diffuseColor );
		if ( roughness <= EON_EPSILON ) return BRDF_Lambert( rho );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float s = dot( lightDir, viewDir ) - dotNL * dotNV;
		float sOverT = ( s > 0.0 ) ? s / max( max( dotNL, dotNV ), EON_EPSILON ) : s;
		float A = 1.0 / ( 1.0 + ( 0.5 - 2.0 / ( 3.0 * PI ) ) * roughness );
		vec3 singleScatter = rho * RECIPROCAL_PI * A * ( 1.0 + roughness * sOverT );
		float averageAlbedo = A * ( 1.0 + ( 2.0 / 3.0 - 28.0 / ( 15.0 * PI ) ) * roughness );
		float albedoV = FON_DirectionalAlbedo( dotNV, roughness, A );
		float albedoL = FON_DirectionalAlbedo( dotNL, roughness, A );
		vec3 rhoMultiScatter = rho * rho * averageAlbedo / max( vec3( EON_EPSILON ), vec3( 1.0 ) - rho * ( 1.0 - averageAlbedo ) );
		vec3 multiScatter = rhoMultiScatter * RECIPROCAL_PI
			* max( EON_EPSILON, 1.0 - albedoV )
			* max( EON_EPSILON, 1.0 - albedoL )
			/ max( EON_EPSILON, 1.0 - averageAlbedo );
		return singleScatter + multiScatter;
	}
	vec3 EON_DirectionalAlbedo( const in vec3 diffuseColor, const in float roughness, const in float dotNV ) {
		vec3 rho = saturate( diffuseColor );
		if ( roughness <= EON_EPSILON ) return rho;
		float A = 1.0 / ( 1.0 + ( 0.5 - 2.0 / ( 3.0 * PI ) ) * roughness );
		float directionalAlbedo = FON_DirectionalAlbedo( dotNV, roughness, A );
		float averageAlbedo = A * ( 1.0 + ( 2.0 / 3.0 - 28.0 / ( 15.0 * PI ) ) * roughness );
		vec3 rhoMultiScatter = rho * rho * averageAlbedo / max( vec3( EON_EPSILON ), vec3( 1.0 ) - rho * ( 1.0 - averageAlbedo ) );
		return rho * directionalAlbedo + rhoMultiScatter * ( 1.0 - directionalAlbedo );
	}
#endif
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		return 0.5 / max( gv + gl, EPSILON );
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = max( material.clearcoatRoughness, 0.045 );
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColorBlended;
	float f90 = material.specularF90;
	float roughness = max( material.roughness, 0.045 );
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float alphaT = max( material.alphaT, alpha );
		float V = V_GGX_SmithCorrelated_Anisotropic( alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transpose( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float rInv = 1.0 / ( roughness + 0.1 );
	float a = -1.9362 + 1.0678 * roughness + 0.4573 * r2 - 0.8469 * rInv;
	float b = -0.6014 + 0.5538 * roughness - 0.4670 * r2 - 0.1255 * rInv;
	float DG = exp( a * dotNV + b );
	return saturate( DG );
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec2 fab, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec2 fab, const in vec3 specularColor, const in float specularF90, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColorBlended * t2.x + ( material.specularF90 - material.specularColorBlended ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseContribution * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
		#ifdef USE_CLEARCOAT
			vec3 Ncc = geometryClearcoatNormal;
			vec2 uvClearcoat = LTC_Uv( Ncc, viewDir, material.clearcoatRoughness );
			vec4 t1Clearcoat = texture2D( ltc_1, uvClearcoat );
			vec4 t2Clearcoat = texture2D( ltc_2, uvClearcoat );
			mat3 mInvClearcoat = mat3(
				vec3( t1Clearcoat.x, 0, t1Clearcoat.y ),
				vec3(             0, 1,             0 ),
				vec3( t1Clearcoat.z, 0, t1Clearcoat.w )
			);
			vec3 fresnelClearcoat = material.clearcoatF0 * t2Clearcoat.x + ( material.clearcoatF90 - material.clearcoatF0 ) * t2Clearcoat.y;
			clearcoatSpecularDirect += lightColor * fresnelClearcoat * LTC_Evaluate( Ncc, viewDir, position, mInvClearcoat, rectCoords );
		#endif
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
 
 		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
 
 		float sheenAlbedoV = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
 		float sheenAlbedoL = IBLSheenBRDF( geometryNormal, directLight.direction, material.sheenRoughness );
 
 		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * max( sheenAlbedoV, sheenAlbedoL );
 
 		irradiance *= sheenEnergyComp;
 
 	#endif
	vec3 specularBRDF = BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	#ifdef USE_RETROREFLECTION
		vec3 retroViewDir = reflect( - geometryViewDir, geometryNormal );
		vec3 retroSpecularBRDF = BRDF_GGX( directLight.direction, retroViewDir, geometryNormal, material );
		specularBRDF = mix( specularBRDF, retroSpecularBRDF, saturate( material.retroreflectivity ) );
	#endif
	reflectedLight.directSpecular += irradiance * specularBRDF * material.multiScatteringCompensation;
	vec3 halfDir = normalize( directLight.direction + geometryViewDir );
	float dotVH = saturate( dot( geometryViewDir, halfDir ) );
	vec3 F = F_Schlick( material.specularColor, material.specularF90, dotVH );
	#ifdef USE_RETROREFLECTION
		vec3 retroHalfDir = normalize( directLight.direction + retroViewDir );
		float dotRetroVH = saturate( dot( retroViewDir, retroHalfDir ) );
		vec3 retroF = F_Schlick( material.specularColor, material.specularF90, dotRetroVH );
		F = mix( F, retroF, saturate( material.retroreflectivity ) );
	#endif
	#ifdef USE_DIFFUSE_ROUGHNESS
		vec3 diffuseBRDF = BRDF_EON( directLight.direction, geometryViewDir, geometryNormal, material.diffuseColor, material.diffuseRoughness ) * ( 1.0 - material.metalness );
	#else
		vec3 diffuseBRDF = BRDF_Lambert( material.diffuseContribution );
	#endif
	reflectedLight.directDiffuse += irradiance * diffuseBRDF * ( 1.0 - F );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( material.dfg, material.specularColor, material.specularF90, material.iridescence, material.iridescenceF0Dielectric, singleScattering, multiScattering );
	#else
		computeMultiscattering( material.dfg, material.specularColor, material.specularF90, singleScattering, multiScattering );
	#endif
	#ifdef USE_DIFFUSE_ROUGHNESS
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		vec3 diffuseAlbedo = EON_DirectionalAlbedo( material.diffuseColor, material.diffuseRoughness, dotNV ) * ( 1.0 - material.metalness );
		vec3 diffuse = irradiance * RECIPROCAL_PI * diffuseAlbedo * ( 1.0 - singleScattering - multiScattering );
	#else
		vec3 diffuse = irradiance * BRDF_Lambert( material.diffuseContribution ) * ( 1.0 - singleScattering - multiScattering );
	#endif
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		sheenSpecularIndirect += irradiance * material.sheenColor * sheenAlbedo * RECIPROCAL_PI;
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		diffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectDiffuse += diffuse;
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness ) * RECIPROCAL_PI;
 	#endif
	vec3 singleScatteringDielectric = vec3( 0.0 );
	vec3 multiScatteringDielectric = vec3( 0.0 );
	vec3 singleScatteringMetallic = vec3( 0.0 );
	vec3 multiScatteringMetallic = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( material.dfg, material.specularColor, material.specularF90, material.iridescence, material.iridescenceF0Dielectric, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscatteringIridescence( material.dfg, material.diffuseColor, material.specularF90, material.iridescence, material.iridescenceF0Metallic, singleScatteringMetallic, multiScatteringMetallic );
	#else
		computeMultiscattering( material.dfg, material.specularColor, material.specularF90, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscattering( material.dfg, material.diffuseColor, material.specularF90, singleScatteringMetallic, multiScatteringMetallic );
	#endif
	vec3 singleScattering = mix( singleScatteringDielectric, singleScatteringMetallic, material.metalness );
	vec3 multiScattering = mix( multiScatteringDielectric, multiScatteringMetallic, material.metalness );
	vec3 totalScatteringDielectric = singleScatteringDielectric + multiScatteringDielectric;
	#ifdef USE_DIFFUSE_ROUGHNESS
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		vec3 diffuse = EON_DirectionalAlbedo( material.diffuseColor, material.diffuseRoughness, dotNV ) * ( 1.0 - material.metalness ) * ( 1.0 - totalScatteringDielectric );
	#else
		vec3 diffuse = material.diffuseContribution * ( 1.0 - totalScatteringDielectric );
	#endif
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	vec3 indirectSpecular = radiance * singleScattering;
	indirectSpecular += multiScattering * cosineWeightedIrradiance;
	vec3 indirectDiffuse = diffuse * cosineWeightedIrradiance;
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		indirectSpecular *= sheenEnergyComp;
		indirectDiffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectSpecular += indirectSpecular;
	reflectedLight.indirectDiffuse += indirectDiffuse;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,n0=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		vec3 iridescenceFresnelDielectric = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		vec3 iridescenceFresnelMetallic = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.diffuseColor );
		material.iridescenceFresnel = mix( iridescenceFresnelDielectric, iridescenceFresnelMetallic, material.metalness );
		material.iridescenceF0Dielectric = Schlick_to_F0( iridescenceFresnelDielectric, 1.0, dotNVi );
		material.iridescenceF0Metallic = Schlick_to_F0( iridescenceFresnelMetallic, 1.0, dotNVi );
	}
#endif
#ifdef STANDARD
	float dotNVms = saturate( dot( geometryNormal, geometryViewDir ) );
	material.dfg = texture2D( dfgLUT, vec2( material.roughness, dotNVms ) ).rg;
	#if ( NUM_SUN_LIGHTS > 0 || NUM_DIR_LIGHTS > 0 || NUM_POINT_LIGHTS > 0 || NUM_SPOT_LIGHTS > 0 )
		float EssMs = material.dfg.x + material.dfg.y;
		material.multiScatteringCompensation = 1.0 + material.specularColorBlended * ( 1.0 / EssMs - 1.0 );
	#endif
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS ) && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SUN_LIGHTS > 0 ) && defined( RE_Direct )
	SunLight sunLight;
	#if defined( USE_SHADOWMAP ) && NUM_SUN_LIGHT_SHADOWS > 0
	SunLightShadow sunLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SUN_LIGHTS; i ++ ) {
		sunLight = sunLights[ i ];
		getSunLightInfo( sunLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SUN_LIGHT_SHADOWS )
		sunLightShadow = sunLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getSunShadow( sunShadowMap[ i ], sunLightShadow, UNROLLED_LOOP_INDEX ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_LIGHT_PROBE_GRIDS > 0
		vec3 probeWorldPos = ( ( vec4( geometryPosition, 1.0 ) - viewMatrix[ 3 ] ) * viewMatrix ).xyz;
		vec3 probeWorldNormal = transformNormalByInverseViewMatrix( geometryNormal, viewMatrix );
		int probeGrid = - 1;
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_LIGHT_PROBE_GRIDS; i ++ ) {
			if ( isInsideLightProbeGrid( probeWorldPos, probeWorldNormal, probesMin[ i ], probesMax[ i ], probesResolution[ i ] ) ) probeGrid = UNROLLED_LOOP_INDEX;
		}
		#pragma unroll_loop_end
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_LIGHT_PROBE_GRIDS; i ++ ) {
			if ( probeGrid == UNROLLED_LOOP_INDEX ) irradiance += getLightProbeGridIrradiance( probesSH[ i ], probesMin[ i ], probesMax[ i ], probesResolution[ i ], probeWorldPos, probeWorldNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,i0=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( ENVMAP_TYPE_PMREM )
		#if defined( STANDARD ) || defined( LAMBERT ) || defined( PHONG )
			iblIrradiance += getIBLIrradiance( geometryNormal );
		#endif
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		vec3 iblRadiance = getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		vec3 iblRadiance = getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_RETROREFLECTION
		#ifdef USE_ANISOTROPY
			vec3 retroIBLRadiance = getIBLAnisotropyRetroRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
		#else
			vec3 retroIBLRadiance = getIBLRetroRadiance( geometryViewDir, geometryNormal, material.roughness );
		#endif
		iblRadiance = mix( iblRadiance, retroIBLRadiance, saturate( material.retroreflectivity ) );
	#endif
	radiance += iblRadiance;
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,s0=`#if defined( RE_IndirectDiffuse )
	#if defined( LAMBERT ) || defined( PHONG )
		irradiance += iblIrradiance;
	#endif
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,r0=`#if NUM_LIGHT_PROBE_GRIDS > 0
uniform highp sampler3D probesSH[ NUM_LIGHT_PROBE_GRIDS ];
uniform vec3 probesMin[ NUM_LIGHT_PROBE_GRIDS ];
uniform vec3 probesMax[ NUM_LIGHT_PROBE_GRIDS ];
uniform vec3 probesResolution[ NUM_LIGHT_PROBE_GRIDS ];
bool isInsideLightProbeGrid( vec3 worldPos, vec3 worldNormal, vec3 probesMin, vec3 probesMax, vec3 probesResolution ) {
	vec3 spacing = ( probesMax - probesMin ) / probesResolution;
	vec3 samplePos = worldPos + worldNormal * spacing * 0.5;
	vec3 margin = spacing * 0.01;
	return all( greaterThanEqual( samplePos, probesMin - margin ) ) && all( lessThanEqual( samplePos, probesMax + margin ) );
}
vec3 getLightProbeGridIrradiance( highp sampler3D probesSH, vec3 probesMin, vec3 probesMax, vec3 probesResolution, vec3 worldPos, vec3 worldNormal ) {
	vec3 res = probesResolution;
	vec3 gridRange = probesMax - probesMin;
	vec3 probeSpacing = gridRange / res;
	vec3 samplePos = worldPos + worldNormal * probeSpacing * 0.5;
	vec3 uvw = clamp( ( samplePos - probesMin ) / gridRange, 0.5 / res, 1.0 - 0.5 / res );
	float nz          = res.z;
	float paddedSlices = nz + 2.0;
	float atlasDepth  = 7.0 * paddedSlices;
	float uvZBase     = uvw.z * nz + 1.0;
	vec4 s0 = texture( probesSH, vec3( uvw.xy, ( uvZBase                       ) / atlasDepth ) );
	vec4 s1 = texture( probesSH, vec3( uvw.xy, ( uvZBase +       paddedSlices   ) / atlasDepth ) );
	vec4 s2 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 2.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s3 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 3.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s4 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 4.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s5 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 5.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s6 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 6.0 * paddedSlices   ) / atlasDepth ) );
	vec3 c0 = s0.xyz;
	vec3 c1 = vec3( s0.w, s1.xy );
	vec3 c2 = vec3( s1.zw, s2.x );
	vec3 c3 = s2.yzw;
	vec3 c4 = s3.xyz;
	vec3 c5 = vec3( s3.w, s4.xy );
	vec3 c6 = vec3( s4.zw, s5.x );
	vec3 c7 = s5.yzw;
	vec3 c8 = s6.xyz;
	float x = worldNormal.x, y = worldNormal.y, z = worldNormal.z;
	vec3 result = c0 * 0.886227;
	result += c1 * 2.0 * 0.511664 * y;
	result += c2 * 2.0 * 0.511664 * z;
	result += c3 * 2.0 * 0.511664 * x;
	result += c4 * 2.0 * 0.429043 * x * y;
	result += c5 * 2.0 * 0.429043 * y * z;
	result += c6 * ( 0.743125 * z * z - 0.247708 );
	result += c7 * 2.0 * 0.429043 * x * z;
	result += c8 * 0.429043 * ( x * x - y * y );
	return max( result, vec3( 0.0 ) );
}
#endif`,a0=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,o0=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,l0=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,c0=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,d0=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,h0=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,u0=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,f0=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,p0=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,m0=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,g0=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,v0=`#if defined( USE_MORPHCOLORS )
	#if defined( USE_COLOR_ALPHA )
		vColor *= morphTargetBaseInfluence;
	#elif defined( USE_COLOR )
		vColor.rgb *= morphTargetBaseInfluence;
	#endif
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor.rgb += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,x0=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,_0=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,y0=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,b0=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#ifdef DOUBLE_SIDED
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#ifdef DOUBLE_SIDED
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,M0=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#if defined( USE_PACKED_NORMALMAP )
		mapN = vec3( mapN.xy, sqrt( saturate( 1.0 - dot( mapN.xy, mapN.xy ) ) ) );
	#endif
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,S0=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,w0=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,E0=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
		#ifdef FLIP_SIDED
			vBitangent = - vBitangent;
		#endif
	#endif
#endif`,A0=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,T0=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,R0=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,C0=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,P0=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,L0=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,D0=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	#ifdef USE_REVERSED_DEPTH_BUFFER
	
		return depth * ( far - near ) - far;
	#else
		return depth * ( near - far ) - near;
	#endif
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	
	#ifdef USE_REVERSED_DEPTH_BUFFER
		return ( near * far ) / ( ( near - far ) * depth - near );
	#else
		return ( near * far ) / ( ( far - near ) * depth - far );
	#endif
}`,I0=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,N0=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,U0=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,F0=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,O0=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,B0=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,k0=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
		#define SUN_LIGHT_CASCADES 2
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow sunShadowMap[ NUM_SUN_LIGHT_SHADOWS ];
		#else
			uniform sampler2D sunShadowMap[ NUM_SUN_LIGHT_SHADOWS ];
		#endif
		uniform mat4 sunShadowMatrix[ NUM_SUN_LIGHT_SHADOWS * SUN_LIGHT_CASCADES ];
		uniform vec4 sunShadowCascade[ NUM_SUN_LIGHT_SHADOWS * SUN_LIGHT_CASCADES ];
		varying vec4 vSunShadowWorldPosition;
		varying vec3 vSunShadowWorldNormal;
		struct SunLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SunLightShadow sunLightShadows[ NUM_SUN_LIGHT_SHADOWS ];
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#else
			uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#endif
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#else
			uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#endif
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform samplerCubeShadow pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#elif defined( SHADOWMAP_TYPE_BASIC )
			uniform samplerCube pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#endif
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float interleavedGradientNoise( vec2 position ) {
			return fract( 52.9829189 * fract( dot( position, vec2( 0.06711056, 0.00583715 ) ) ) );
		}
		vec2 vogelDiskSample( int sampleIndex, int samplesCount, float phi ) {
			const float goldenAngle = 2.399963229728653;
			float r = sqrt( ( float( sampleIndex ) + 0.5 ) / float( samplesCount ) );
			float theta = float( sampleIndex ) * goldenAngle + phi;
			return vec2( cos( theta ), sin( theta ) ) * r;
		}
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float getShadow( sampler2DShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
				vec2 radius = shadowRadius * texelSize;
				float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
				shadow = (
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 0, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 1, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 2, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 3, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 4, 5, phi ) * radius, shadowCoord.z ) )
				) * 0.2;
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#elif defined( SHADOWMAP_TYPE_VSM )
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 distribution = texture2D( shadowMap, shadowCoord.xy ).rg;
				float mean = distribution.x;
				float variance = distribution.y * distribution.y;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					float hard_shadow = step( mean, shadowCoord.z );
				#else
					float hard_shadow = step( shadowCoord.z, mean );
				#endif
				
				if ( hard_shadow == 1.0 ) {
					shadow = 1.0;
				} else {
					variance = max( variance, 0.0000001 );
					float d = shadowCoord.z - mean;
					float p_max = variance / ( variance + d * d );
					p_max = clamp( ( p_max - 0.3 ) / 0.65, 0.0, 1.0 );
					shadow = max( hard_shadow, p_max );
				}
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#else
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				float depth = texture2D( shadowMap, shadowCoord.xy ).r;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					shadow = step( depth, shadowCoord.z );
				#else
					shadow = step( shadowCoord.z, depth );
				#endif
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#endif
	#if NUM_SUN_LIGHT_SHADOWS > 0
		float getSunShadow(
			#if defined( SHADOWMAP_TYPE_PCF )
				sampler2DShadow shadowMap,
			#else
				sampler2D shadowMap,
			#endif
			SunLightShadow sunLightShadow,
			int shadowIndex
		) {
			vec4 shadowWorldPosition = vec4( vSunShadowWorldPosition.xyz + vSunShadowWorldNormal * sunLightShadow.shadowNormalBias, 1.0 );
			float viewDepth = vSunShadowWorldPosition.w;
			int cascadeOffset = shadowIndex * SUN_LIGHT_CASCADES;
			float shadow = 1.0;
			for ( int i = SUN_LIGHT_CASCADES - 1; i >= 0; i -- ) {
				vec4 cascade = sunShadowCascade[ cascadeOffset + i ];
				if ( viewDepth >= cascade.x && viewDepth < cascade.y ) {
					float cascadeShadow = getShadow(
						shadowMap,
						sunLightShadow.shadowMapSize,
						sunLightShadow.shadowIntensity,
						sunLightShadow.shadowBias,
						sunLightShadow.shadowRadius,
						sunShadowMatrix[ cascadeOffset + i ] * shadowWorldPosition
					);
					shadow = mix( cascadeShadow, shadow, smoothstep( cascade.z, cascade.y, viewDepth ) );
				}
			}
			return shadow;
		}
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	#if defined( SHADOWMAP_TYPE_PCF )
	float getPointShadow( samplerCubeShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 bd3D = normalize( lightToPosition );
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			float lightDistance = length( lightToPosition );
			float depthRange = shadowCameraFar - shadowCameraNear;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				float depthA = - shadowCameraNear / depthRange - shadowBias;
				float depthB = shadowCameraNear * shadowCameraFar / ( depthRange * lightDistance );
			#else
				float depthA = shadowCameraFar / depthRange + shadowBias;
				float depthB = - shadowCameraNear * shadowCameraFar / ( depthRange * lightDistance );
			#endif
			float texelSize = shadowRadius / shadowMapSize.x;
			vec3 absDir = abs( bd3D );
			vec3 tangent = absDir.x > absDir.z ? vec3( 0.0, 1.0, 0.0 ) : vec3( 1.0, 0.0, 0.0 );
			tangent = normalize( cross( bd3D, tangent ) );
			vec3 bitangent = cross( bd3D, tangent );
			float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
			shadow = 0.0;
			for ( int i = 0; i < 5; i ++ ) {
				vec2 offset = vogelDiskSample( i, 5, phi );
				vec3 direction = bd3D + ( tangent * offset.x + bitangent * offset.y ) * texelSize;
				vec3 absDirection = abs( direction );
				float dp = depthA + depthB / max( max( absDirection.x, absDirection.y ), absDirection.z );
				shadow += texture( shadowMap, vec4( direction, dp ) );
			}
			shadow *= 0.2;
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#elif defined( SHADOWMAP_TYPE_BASIC )
	float getPointShadow( samplerCube shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			float depth = textureCube( shadowMap, bd3D ).r;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				depth = 1.0 - depth;
			#endif
			shadow = step( dp, depth );
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#endif
	#endif
#endif`,z0=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
		varying vec4 vSunShadowWorldPosition;
		varying vec3 vSunShadowWorldNormal;
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,H0=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_SUN_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	#ifdef HAS_NORMAL
		vec3 shadowWorldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
	#else
		vec3 shadowWorldNormal = vec3( 0.0 );
	#endif
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_SUN_LIGHT_SHADOWS > 0
		vSunShadowWorldPosition = vec4( worldPosition.xyz, - mvPosition.z );
		vSunShadowWorldNormal = shadowWorldNormal;
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,G0=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
	SunLightShadow sunLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SUN_LIGHT_SHADOWS; i ++ ) {
		sunLight = sunLightShadows[ i ];
		shadow *= receiveShadow ? getSunShadow( sunShadowMap[ i ], sunLight, UNROLLED_LOOP_INDEX ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0 && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,V0=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,$0=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,W0=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,X0=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,q0=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,Y0=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,K0=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,Z0=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,J0=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseContribution, material.specularColorBlended, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,j0=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,Q0=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_DIFFUSE_ROUGHNESSMAP
	varying vec2 vDiffuseRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,tg=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_DIFFUSE_ROUGHNESSMAP
	uniform mat3 diffuseRoughnessMapTransform;
	varying vec2 vDiffuseRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,eg=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DIFFUSE_ROUGHNESSMAP
	vDiffuseRoughnessMapUv = ( diffuseRoughnessMapTransform * vec3( DIFFUSE_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,ng=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const ig=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,sg=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,rg=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,ag=`uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <envmap_common_pars_fragment>
void main() {
	#ifdef ENVMAP_TYPE_PMREM
		vec4 texColor = textureLod( envMap, backgroundRotation * vWorldDirection, roughnessToMip( backgroundBlurriness ) );
	#else
		vec4 texColor = textureCube( envMap, backgroundRotation * vWorldDirection );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,og=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,lg=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,cg=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,dg=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,hg=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,ug=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = vec4( dist, 0.0, 0.0, 1.0 );
}`,fg=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,pg=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,mg=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,gg=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,vg=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,xg=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,_g=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,yg=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,bg=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,Mg=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Sg=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,wg=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( normalize( normal ) * 0.5 + 0.5, diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,Eg=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Ag=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Tg=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,Rg=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DIFFUSE_ROUGHNESS
	uniform float diffuseRoughness;
	#ifdef USE_DIFFUSE_ROUGHNESSMAP
		uniform sampler2D diffuseRoughnessMap;
	#endif
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_RETROREFLECTION
	uniform float retroreflectivity;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
 
		outgoingLight = outgoingLight + sheenSpecularDirect + sheenSpecularIndirect;
 
 	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Cg=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Pg=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Lg=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,Dg=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Ig=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Ng=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Ug=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Fg=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Vt={alphahash_fragment:sm,alphahash_pars_fragment:rm,alphamap_fragment:am,alphamap_pars_fragment:om,alphatest_fragment:lm,alphatest_pars_fragment:cm,aomap_fragment:dm,aomap_pars_fragment:hm,batching_pars_vertex:um,batching_vertex:fm,begin_vertex:pm,beginnormal_vertex:mm,bsdfs:gm,iridescence_fragment:vm,bumpmap_pars_fragment:xm,clipping_planes_fragment:_m,clipping_planes_pars_fragment:ym,clipping_planes_pars_vertex:bm,clipping_planes_vertex:Mm,color_fragment:Sm,color_pars_fragment:wm,color_pars_vertex:Em,color_vertex:Am,common:Tm,defaultnormal_vertex:Rm,displacementmap_pars_vertex:Cm,displacementmap_vertex:Pm,emissivemap_fragment:Lm,emissivemap_pars_fragment:Dm,colorspace_fragment:Im,colorspace_pars_fragment:Nm,envmap_fragment:Um,envmap_common_pars_fragment:Fm,envmap_pars_fragment:Om,envmap_pars_vertex:Bm,envmap_physical_pars_fragment:Km,envmap_vertex:km,fog_vertex:zm,fog_pars_vertex:Hm,fog_fragment:Gm,fog_pars_fragment:Vm,gradientmap_pars_fragment:$m,lightmap_pars_fragment:Wm,lights_lambert_fragment:Xm,lights_lambert_pars_fragment:qm,lights_pars_begin:Ym,lights_toon_fragment:Zm,lights_toon_pars_fragment:Jm,lights_phong_fragment:jm,lights_phong_pars_fragment:Qm,lights_physical_fragment:t0,lights_physical_pars_fragment:e0,lights_fragment_begin:n0,lights_fragment_maps:i0,lights_fragment_end:s0,lightprobes_pars_fragment:r0,logdepthbuf_fragment:a0,logdepthbuf_pars_fragment:o0,logdepthbuf_pars_vertex:l0,logdepthbuf_vertex:c0,map_fragment:d0,map_pars_fragment:h0,map_particle_fragment:u0,map_particle_pars_fragment:f0,metalnessmap_fragment:p0,metalnessmap_pars_fragment:m0,morphinstance_vertex:g0,morphcolor_vertex:v0,morphnormal_vertex:x0,morphtarget_pars_vertex:_0,morphtarget_vertex:y0,normal_fragment_begin:b0,normal_fragment_maps:M0,normal_pars_fragment:S0,normal_pars_vertex:w0,normal_vertex:E0,normalmap_pars_fragment:A0,clearcoat_normal_fragment_begin:T0,clearcoat_normal_fragment_maps:R0,clearcoat_pars_fragment:C0,iridescence_pars_fragment:P0,opaque_fragment:L0,packing:D0,premultiplied_alpha_fragment:I0,project_vertex:N0,dithering_fragment:U0,dithering_pars_fragment:F0,roughnessmap_fragment:O0,roughnessmap_pars_fragment:B0,shadowmap_pars_fragment:k0,shadowmap_pars_vertex:z0,shadowmap_vertex:H0,shadowmask_pars_fragment:G0,skinbase_vertex:V0,skinning_pars_vertex:$0,skinning_vertex:W0,skinnormal_vertex:X0,specularmap_fragment:q0,specularmap_pars_fragment:Y0,tonemapping_fragment:K0,tonemapping_pars_fragment:Z0,transmission_fragment:J0,transmission_pars_fragment:j0,uv_pars_fragment:Q0,uv_pars_vertex:tg,uv_vertex:eg,worldpos_vertex:ng,background_vert:ig,background_frag:sg,backgroundCube_vert:rg,backgroundCube_frag:ag,cube_vert:og,cube_frag:lg,depth_vert:cg,depth_frag:dg,distance_vert:hg,distance_frag:ug,equirect_vert:fg,equirect_frag:pg,linedashed_vert:mg,linedashed_frag:gg,meshbasic_vert:vg,meshbasic_frag:xg,meshlambert_vert:_g,meshlambert_frag:yg,meshmatcap_vert:bg,meshmatcap_frag:Mg,meshnormal_vert:Sg,meshnormal_frag:wg,meshphong_vert:Eg,meshphong_frag:Ag,meshphysical_vert:Tg,meshphysical_frag:Rg,meshtoon_vert:Cg,meshtoon_frag:Pg,points_vert:Lg,points_frag:Dg,shadow_vert:Ig,shadow_frag:Ng,sprite_vert:Ug,sprite_frag:Fg},pt={common:{diffuse:{value:new Nt(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new Ot},alphaMap:{value:null},alphaMapTransform:{value:new Ot},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new Ot}},envmap:{envMap:{value:null},envMapRotation:{value:new Ot},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98},dfgLUT:{value:null}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new Ot}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new Ot}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new Ot},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new Ot},normalScale:{value:new Dt(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new Ot},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new Ot}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new Ot}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new Ot}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new Nt(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},sunLights:{value:[],properties:{direction:{},color:{}}},sunLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},sunShadowMatrix:{value:[]},sunShadowCascade:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null},probesSH:{value:[]},probesMin:{value:[]},probesMax:{value:[]},probesResolution:{value:[]}},points:{diffuse:{value:new Nt(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new Ot},alphaTest:{value:0},uvTransform:{value:new Ot}},sprite:{diffuse:{value:new Nt(16777215)},opacity:{value:1},center:{value:new Dt(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new Ot},alphaMap:{value:null},alphaMapTransform:{value:new Ot},alphaTest:{value:0}}},Wn={basic:{uniforms:je([pt.common,pt.specularmap,pt.envmap,pt.aomap,pt.lightmap,pt.fog]),vertexShader:Vt.meshbasic_vert,fragmentShader:Vt.meshbasic_frag},lambert:{uniforms:je([pt.common,pt.specularmap,pt.envmap,pt.aomap,pt.lightmap,pt.emissivemap,pt.bumpmap,pt.normalmap,pt.displacementmap,pt.fog,pt.lights,{emissive:{value:new Nt(0)},envMapIntensity:{value:1}}]),vertexShader:Vt.meshlambert_vert,fragmentShader:Vt.meshlambert_frag},phong:{uniforms:je([pt.common,pt.specularmap,pt.envmap,pt.aomap,pt.lightmap,pt.emissivemap,pt.bumpmap,pt.normalmap,pt.displacementmap,pt.fog,pt.lights,{emissive:{value:new Nt(0)},specular:{value:new Nt(1118481)},shininess:{value:30},envMapIntensity:{value:1}}]),vertexShader:Vt.meshphong_vert,fragmentShader:Vt.meshphong_frag},standard:{uniforms:je([pt.common,pt.envmap,pt.aomap,pt.lightmap,pt.emissivemap,pt.bumpmap,pt.normalmap,pt.displacementmap,pt.roughnessmap,pt.metalnessmap,pt.fog,pt.lights,{emissive:{value:new Nt(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:Vt.meshphysical_vert,fragmentShader:Vt.meshphysical_frag},toon:{uniforms:je([pt.common,pt.aomap,pt.lightmap,pt.emissivemap,pt.bumpmap,pt.normalmap,pt.displacementmap,pt.gradientmap,pt.fog,pt.lights,{emissive:{value:new Nt(0)}}]),vertexShader:Vt.meshtoon_vert,fragmentShader:Vt.meshtoon_frag},matcap:{uniforms:je([pt.common,pt.bumpmap,pt.normalmap,pt.displacementmap,pt.fog,{matcap:{value:null}}]),vertexShader:Vt.meshmatcap_vert,fragmentShader:Vt.meshmatcap_frag},points:{uniforms:je([pt.points,pt.fog]),vertexShader:Vt.points_vert,fragmentShader:Vt.points_frag},dashed:{uniforms:je([pt.common,pt.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:Vt.linedashed_vert,fragmentShader:Vt.linedashed_frag},depth:{uniforms:je([pt.common,pt.displacementmap]),vertexShader:Vt.depth_vert,fragmentShader:Vt.depth_frag},normal:{uniforms:je([pt.common,pt.bumpmap,pt.normalmap,pt.displacementmap,{opacity:{value:1}}]),vertexShader:Vt.meshnormal_vert,fragmentShader:Vt.meshnormal_frag},sprite:{uniforms:je([pt.sprite,pt.fog]),vertexShader:Vt.sprite_vert,fragmentShader:Vt.sprite_frag},background:{uniforms:{uvTransform:{value:new Ot},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:Vt.background_vert,fragmentShader:Vt.background_frag},backgroundCube:{uniforms:{envMap:{value:null},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new Ot}},vertexShader:Vt.backgroundCube_vert,fragmentShader:Vt.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:Vt.cube_vert,fragmentShader:Vt.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:Vt.equirect_vert,fragmentShader:Vt.equirect_frag},distance:{uniforms:je([pt.common,pt.displacementmap,{referencePosition:{value:new I},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:Vt.distance_vert,fragmentShader:Vt.distance_frag},shadow:{uniforms:je([pt.lights,pt.fog,{color:{value:new Nt(0)},opacity:{value:1}}]),vertexShader:Vt.shadow_vert,fragmentShader:Vt.shadow_frag}};Wn.physical={uniforms:je([Wn.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new Ot},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new Ot},clearcoatNormalScale:{value:new Dt(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new Ot},diffuseRoughness:{value:0},diffuseRoughnessMap:{value:null},diffuseRoughnessMapTransform:{value:new Ot},dispersion:{value:0},retroreflectivity:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new Ot},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new Ot},sheen:{value:0},sheenColor:{value:new Nt(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new Ot},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new Ot},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new Ot},transmissionSamplerSize:{value:new Dt},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new Ot},attenuationDistance:{value:0},attenuationColor:{value:new Nt(0)},specularColor:{value:new Nt(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new Ot},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new Ot},anisotropyVector:{value:new Dt},anisotropyMap:{value:null},anisotropyMapTransform:{value:new Ot}}]),vertexShader:Vt.meshphysical_vert,fragmentShader:Vt.meshphysical_frag};const oa={r:0,b:0,g:0},Og=new jt,Du=new Ot;Du.set(-1,0,0,0,1,0,0,0,1);function Bg(i,t,e,n,s,r){const a=new Nt(0);let o=s===!0?0:1,l,c,d=null,h=0,u=null;function f(_){let S=_.isScene===!0?_.background:null;if(S&&S.isTexture){const y=_.backgroundBlurriness>0;S=t.get(S,y)}return S}function g(_){let S=!1;const y=f(_);y===null?m(a,o):y&&y.isColor&&(m(y,1),S=!0);const A=i.xr.getEnvironmentBlendMode();A==="additive"?e.buffers.color.setClear(0,0,0,1,r):A==="alpha-blend"&&e.buffers.color.setClear(0,0,0,0,r),(i.autoClear||S)&&(e.buffers.depth.setTest(!0),e.buffers.depth.setMask(!0),e.buffers.color.setMask(!0),i.clear(i.autoClearColor,i.autoClearDepth,i.autoClearStencil))}function x(_,S){const y=f(S);y&&y.isCubeTexture?(c===void 0&&(c=new $t(new zn(1,1,1),new Un({name:"BackgroundCubeMaterial",uniforms:zs(Wn.backgroundCube.uniforms),vertexShader:Wn.backgroundCube.vertexShader,fragmentShader:Wn.backgroundCube.fragmentShader,side:qe,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),c.geometry.deleteAttribute("normal"),c.geometry.deleteAttribute("uv"),c.onBeforeRender=function(A,E,v){this.matrixWorld.copyPosition(v.matrixWorld)},Object.defineProperty(c.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),n.update(c)),c.material.uniforms.envMap.value=y,c.material.uniforms.backgroundBlurriness.value=S.backgroundBlurriness,c.material.uniforms.backgroundIntensity.value=S.backgroundIntensity,c.material.uniforms.backgroundRotation.value.setFromMatrix4(Og.makeRotationFromEuler(S.backgroundRotation)).transpose(),y.isRenderTargetTexture===!1&&c.material.uniforms.backgroundRotation.value.premultiply(Du),c.material.toneMapped=Jt.getTransfer(y.colorSpace)!==ae,(d!==y||h!==y.version||u!==i.toneMapping)&&(c.material.needsUpdate=!0,d=y,h=y.version,u=i.toneMapping),c.layers.enableAll(),_.unshift(c,c.geometry,c.material,0,0,null)):y&&y.isTexture&&(l===void 0&&(l=new $t(new rs(2,2),new Un({name:"BackgroundMaterial",uniforms:zs(Wn.background.uniforms),vertexShader:Wn.background.vertexShader,fragmentShader:Wn.background.fragmentShader,side:Ki,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),l.geometry.deleteAttribute("normal"),Object.defineProperty(l.material,"map",{get:function(){return this.uniforms.t2D.value}}),n.update(l)),l.material.uniforms.t2D.value=y,l.material.uniforms.backgroundIntensity.value=S.backgroundIntensity,l.material.toneMapped=Jt.getTransfer(y.colorSpace)!==ae,y.matrixAutoUpdate===!0&&y.updateMatrix(),l.material.uniforms.uvTransform.value.copy(y.matrix),(d!==y||h!==y.version||u!==i.toneMapping)&&(l.material.needsUpdate=!0,d=y,h=y.version,u=i.toneMapping),l.layers.enableAll(),_.unshift(l,l.geometry,l.material,0,0,null))}function m(_,S){_.getRGB(oa,Tu(i)),e.buffers.color.setClear(oa.r,oa.g,oa.b,S,r)}function p(){c!==void 0&&(c.geometry.dispose(),c.material.dispose(),c=void 0),l!==void 0&&(l.geometry.dispose(),l.material.dispose(),l=void 0)}return{getClearColor:function(){return a},setClearColor:function(_,S=1){a.set(_),o=S,m(a,o)},getClearAlpha:function(){return o},setClearAlpha:function(_){o=_,m(a,o)},render:g,addToRenderList:x,dispose:p}}function kg(i,t){const e=i.getParameter(i.MAX_VERTEX_ATTRIBS),n={},s=u(null);let r=s,a=!1;function o(L,F,V,D,H){let q=!1;const k=h(L,D,V,F);r!==k&&(r=k,c(r.object)),q=f(L,D,V,H),q&&g(L,D,V,H),H!==null&&t.update(H,i.ELEMENT_ARRAY_BUFFER),(q||a)&&(a=!1,y(L,F,V,D),H!==null&&i.bindBuffer(i.ELEMENT_ARRAY_BUFFER,t.get(H).buffer))}function l(){return i.createVertexArray()}function c(L){return i.bindVertexArray(L)}function d(L){return i.deleteVertexArray(L)}function h(L,F,V,D){const H=D.wireframe===!0;let q=n[F.id];q===void 0&&(q={},n[F.id]=q);const k=L.isInstancedMesh===!0?L.id:0;let tt=q[k];tt===void 0&&(tt={},q[k]=tt);let W=tt[V.id];W===void 0&&(W={},tt[V.id]=W);let j=W[H];return j===void 0&&(j=u(l()),W[H]=j),j}function u(L){const F=[],V=[],D=[];for(let H=0;H<e;H++)F[H]=0,V[H]=0,D[H]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:F,enabledAttributes:V,attributeDivisors:D,object:L,attributes:{},index:null}}function f(L,F,V,D){const H=r.attributes,q=F.attributes;let k=0;const tt=V.getAttributes();for(const W in tt)if(tt[W].location>=0){const Q=H[W];let wt=q[W];if(wt===void 0&&(W==="instanceMatrix"&&L.instanceMatrix&&(wt=L.instanceMatrix),W==="instanceColor"&&L.instanceColor&&(wt=L.instanceColor)),Q===void 0||Q.attribute!==wt||wt&&Q.data!==wt.data)return!0;k++}return r.attributesNum!==k||r.index!==D}function g(L,F,V,D){const H={},q=F.attributes;let k=0;const tt=V.getAttributes();for(const W in tt)if(tt[W].location>=0){let Q=q[W];Q===void 0&&(W==="instanceMatrix"&&L.instanceMatrix&&(Q=L.instanceMatrix),W==="instanceColor"&&L.instanceColor&&(Q=L.instanceColor));const wt={};wt.attribute=Q,Q&&Q.data&&(wt.data=Q.data),H[W]=wt,k++}r.attributes=H,r.attributesNum=k,r.index=D}function x(){const L=r.newAttributes;for(let F=0,V=L.length;F<V;F++)L[F]=0}function m(L){p(L,0)}function p(L,F){const V=r.newAttributes,D=r.enabledAttributes,H=r.attributeDivisors;V[L]=1,D[L]===0&&(i.enableVertexAttribArray(L),D[L]=1),H[L]!==F&&(i.vertexAttribDivisor(L,F),H[L]=F)}function _(){const L=r.newAttributes,F=r.enabledAttributes;for(let V=0,D=F.length;V<D;V++)F[V]!==L[V]&&(i.disableVertexAttribArray(V),F[V]=0)}function S(L,F,V,D,H,q,k){k===!0?i.vertexAttribIPointer(L,F,V,H,q):i.vertexAttribPointer(L,F,V,D,H,q)}function y(L,F,V,D){x();const H=D.attributes,q=V.getAttributes(),k=F.defaultAttributeValues;for(const tt in q){const W=q[tt];if(W.location>=0){let j=H[tt];if(j===void 0&&(tt==="instanceMatrix"&&L.instanceMatrix&&(j=L.instanceMatrix),tt==="instanceColor"&&L.instanceColor&&(j=L.instanceColor)),j!==void 0){const Q=j.normalized,wt=j.itemSize,Bt=t.get(j);if(Bt===void 0)continue;const K=Bt.buffer,mt=Bt.type,bt=Bt.bytesPerElement,Rt=mt===i.INT||mt===i.UNSIGNED_INT||j.gpuType===Ql;if(j.isInterleavedBufferAttribute){const vt=j.data,zt=vt.isInterleavedBuffer===!0?vt.stride:vt.itemSize,Se=j.offset;if(vt.isInstancedInterleavedBuffer||vt.isInstancedBufferAttribute){for(let Pt=0;Pt<W.locationSize;Pt++)p(W.location+Pt,vt.meshPerAttribute);L.isInstancedMesh!==!0&&D._maxInstanceCount===void 0&&(D._maxInstanceCount=vt.meshPerAttribute*vt.count)}else for(let Pt=0;Pt<W.locationSize;Pt++)m(W.location+Pt);i.bindBuffer(i.ARRAY_BUFFER,K);for(let Pt=0;Pt<W.locationSize;Pt++)S(W.location+Pt,wt/W.locationSize,mt,Q,zt*bt,(Se+wt/W.locationSize*Pt)*bt,Rt)}else{if(j.isInstancedBufferAttribute){for(let vt=0;vt<W.locationSize;vt++)p(W.location+vt,j.meshPerAttribute);L.isInstancedMesh!==!0&&D._maxInstanceCount===void 0&&(D._maxInstanceCount=j.meshPerAttribute*j.count)}else for(let vt=0;vt<W.locationSize;vt++)m(W.location+vt);i.bindBuffer(i.ARRAY_BUFFER,K);for(let vt=0;vt<W.locationSize;vt++)S(W.location+vt,wt/W.locationSize,mt,Q,wt*bt,wt/W.locationSize*vt*bt,Rt)}}else if(k!==void 0){const Q=k[tt];if(Q!==void 0)switch(Q.length){case 2:i.vertexAttrib2fv(W.location,Q);break;case 3:i.vertexAttrib3fv(W.location,Q);break;case 4:i.vertexAttrib4fv(W.location,Q);break;default:i.vertexAttrib1fv(W.location,Q)}}}}_()}function A(){N();for(const L in n){const F=n[L];for(const V in F){const D=F[V];for(const H in D){const q=D[H];for(const k in q)d(q[k].object),delete q[k];delete D[H]}}delete n[L]}}function E(L){if(n[L.id]===void 0)return;const F=n[L.id];for(const V in F){const D=F[V];for(const H in D){const q=D[H];for(const k in q)d(q[k].object),delete q[k];delete D[H]}}delete n[L.id]}function v(L){for(const F in n){const V=n[F];for(const D in V){const H=V[D];if(H[L.id]===void 0)continue;const q=H[L.id];for(const k in q)d(q[k].object),delete q[k];delete H[L.id]}}}function w(L){for(const F in n){const V=n[F],D=L.isInstancedMesh===!0?L.id:0,H=V[D];if(H!==void 0){for(const q in H){const k=H[q];for(const tt in k)d(k[tt].object),delete k[tt];delete H[q]}delete V[D],Object.keys(V).length===0&&delete n[F]}}}function N(){R(),a=!0,r!==s&&(r=s,c(r.object))}function R(){s.geometry=null,s.program=null,s.wireframe=!1}return{setup:o,reset:N,resetDefaultState:R,dispose:A,releaseStatesOfGeometry:E,releaseStatesOfObject:w,releaseStatesOfProgram:v,initAttributes:x,enableAttribute:m,disableUnusedAttributes:_}}function zg(i,t,e){let n;function s(l){n=l}function r(l,c){i.drawArrays(n,l,c),e.update(c,n,1)}function a(l,c,d){d!==0&&(i.drawArraysInstanced(n,l,c,d),e.update(c,n,d))}function o(l,c,d){if(d===0)return;t.get("WEBGL_multi_draw").multiDrawArraysWEBGL(n,l,0,c,0,d);let u=0;for(let f=0;f<d;f++)u+=c[f];e.update(u,n,1)}this.setMode=s,this.render=r,this.renderInstances=a,this.renderMultiDraw=o}function Hg(i,t,e,n){let s;function r(){if(s!==void 0)return s;if(t.has("EXT_texture_filter_anisotropic")===!0){const v=t.get("EXT_texture_filter_anisotropic");s=i.getParameter(v.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else s=0;return s}function a(v){return!(v!==Kn&&n.convert(v)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_FORMAT))}function o(v){const w=v===jn&&(t.has("EXT_color_buffer_half_float")||t.has("EXT_color_buffer_float"));return!(v!==an&&v!==Pn&&!w&&n.convert(v)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_TYPE))}function l(v){if(v==="highp"){if(i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.HIGH_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.HIGH_FLOAT).precision>0)return"highp";v="mediump"}return v==="mediump"&&i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.MEDIUM_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let c=e.precision!==void 0?e.precision:"highp";const d=l(c);d!==c&&(Lt("WebGLRenderer:",c,"not supported, using",d,"instead."),c=d);const h=e.reversedDepthBuffer===!0&&t.has("EXT_clip_control"),u=e.logarithmicDepthBuffer===!0&&h===!1;e.reversedDepthBuffer===!0&&h===!1&&Lt("WebGLRenderer: Unable to use reversed depth buffer due to missing EXT_clip_control extension. Fallback to default depth buffer."),e.logarithmicDepthBuffer===!0&&h===!0&&Lt("WebGLRenderer: Logarithmic depth buffer is ignored when reversed depth buffer is enabled.");const f=i.getParameter(i.MAX_TEXTURE_IMAGE_UNITS),g=i.getParameter(i.MAX_VERTEX_TEXTURE_IMAGE_UNITS),x=i.getParameter(i.MAX_TEXTURE_SIZE),m=i.getParameter(i.MAX_CUBE_MAP_TEXTURE_SIZE),p=i.getParameter(i.MAX_VERTEX_ATTRIBS),_=i.getParameter(i.MAX_VERTEX_UNIFORM_VECTORS),S=i.getParameter(i.MAX_VARYING_VECTORS),y=i.getParameter(i.MAX_FRAGMENT_UNIFORM_VECTORS),A=i.getParameter(i.MAX_SAMPLES),E=i.getParameter(i.SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:r,getMaxPrecision:l,textureFormatReadable:a,textureTypeReadable:o,precision:c,logarithmicDepthBuffer:u,reversedDepthBuffer:h,maxTextures:f,maxVertexTextures:g,maxTextureSize:x,maxCubemapSize:m,maxAttributes:p,maxVertexUniforms:_,maxVaryings:S,maxFragmentUniforms:y,maxSamples:A,samples:E}}function Gg(i){const t=this;let e=null,n=0,s=!1,r=!1;const a=new ci,o=new Ot,l={value:null,needsUpdate:!1};this.uniform=l,this.numPlanes=0,this.numIntersection=0,this.init=function(h,u){const f=h.length!==0||u||n!==0||s;return s=u,n=h.length,f},this.beginShadows=function(){r=!0,d(null)},this.endShadows=function(){r=!1},this.setGlobalState=function(h,u){e=d(h,u,0)},this.setState=function(h,u,f){const g=h.clippingPlanes,x=h.clipIntersection,m=h.clipShadows,p=i.get(h);if(!s||g===null||g.length===0||r&&!m)r?d(null):c();else{const _=r?0:n,S=_*4;let y=p.clippingState||null;l.value=y,y=d(g,u,S,f);for(let A=0;A!==S;++A)y[A]=e[A];p.clippingState=y,this.numIntersection=x?this.numPlanes:0,this.numPlanes+=_}};function c(){l.value!==e&&(l.value=e,l.needsUpdate=n>0),t.numPlanes=n,t.numIntersection=0}function d(h,u,f,g){const x=h!==null?h.length:0;let m=null;if(x!==0){if(m=l.value,g!==!0||m===null){const p=f+x*4,_=u.matrixWorldInverse;o.getNormalMatrix(_),(m===null||m.length<p)&&(m=new Float32Array(p));for(let S=0,y=f;S!==x;++S,y+=4)a.copy(h[S]).applyMatrix4(_,o),a.normal.toArray(m,y),m[y+3]=a.constant}l.value=m,l.needsUpdate=!0}return t.numPlanes=x,t.numIntersection=0,m}}class vc extends Sn{constructor(t=1,e={}){super(t,t,e),this.isWebGLCubeRenderTarget=!0;const n={width:t,height:t,depth:1},s=[n,n,n,n,n,n];this.texture=new Su(s),this._setTextureOptions(e),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(t,e){this.texture.type=e.type,this.texture.colorSpace=e.colorSpace,this.texture.generateMipmaps=e.generateMipmaps,this.texture.minFilter=e.minFilter,this.texture.magFilter=e.magFilter;const n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},s=new zn(5,5,5),r=new Un({name:"CubemapFromEquirect",uniforms:zs(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:qe,blending:Cs});r.uniforms.tEquirect.value=e;const a=new $t(s,r),o=e.minFilter;return e.minFilter===ui&&(e.minFilter=en),new Ll(1,10,this).update(t,a),e.minFilter=o,a.geometry.dispose(),a.material.dispose(),this}clear(t,e=!0,n=!0,s=!0){const r=t.getRenderTarget();for(let a=0;a<6;a++)t.setRenderTarget(this,a),t.clear(e,n,s);t.setRenderTarget(r)}}const Ud=256,Vg=3,$g=20,Iu=256,Nu=16,Wg=3,Xg=new I,qg=new Nt;class za{constructor(t){this._renderer=t,this._cubeSize=0,this._sourceTarget=null,this._cubeCamera=new Ll(1,10,null),this._boxMesh=new $t(new zn(5,5,5),null),this._cubemapMaterial=null,this._equirectMaterial=null,this._blurMaterial=null,this._ggxMaterial=null,this._integrationMaterial=null}fromScene(t,e=0,n=.1,s=100,r={}){const{size:a=256,position:o=Xg}=r,l=this._renderer;this._setSize(a);const c=this._allocateTarget(),d=this._getSourceTarget(!0);e>0&&(d.texture.mipmapsAutoUpdate=!1);const h=l.autoClear,u=l.autoClearColor,f=l.autoClearDepth,g=l.autoClearStencil,x=t.background;l.autoClear=!0,l.autoClearColor=!0,l.autoClearDepth=!0,l.autoClearStencil=!0,x===null&&(t.background=l.getClearColor(qg));const m=new Ll(n,s,d);return m.position.copy(o),m.update(l,t),l.autoClear=h,l.autoClearColor=u,l.autoClearDepth=f,l.autoClearStencil=g,t.background=x,e>0&&(d.texture.mipmapsAutoUpdate=!0,this._blur(c,e)),this._applyPMREM(c),c}fromEquirectangular(t,e=null){return this._fromTexture(t,e)}fromCubemap(t,e=null){return this._fromTexture(t,e)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=Bd(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=Od(),this._compileMaterial(this._equirectMaterial))}dispose(){this._sourceTarget!==null&&this._sourceTarget.dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose(),this._blurMaterial!==null&&this._blurMaterial.dispose(),this._ggxMaterial!==null&&this._ggxMaterial.dispose(),this._integrationMaterial!==null&&this._integrationMaterial.dispose(),this._boxMesh.geometry.dispose()}static lodToRoughness(t,e){return e>0?1-Math.sqrt(1-t/e):0}_setSize(t){this._cubeSize=Math.max(Ud,pu(t))}_fromTexture(t,e){t.mapping===Os||t.mapping===gr?this._setSize(t.image.length===0?Ud:t.image[0].width||t.image[0].image.width):this._setSize(t.image.width/4);const n=e||this._allocateTarget();return this._textureToCubemap(t),this._applyPMREM(n),n}_allocateTarget(){const t=this._cubeSize,e=Fd(t,!1,!1),n=Math.log2(t)-Vg;for(let s=0;s<=n;s++)e.texture.mipmaps.push({width:t>>s,height:t>>s});return e.texture.name="PMREM",e.texture.isPMREMTexture=!0,e}_getSourceTarget(t=!1){const e=this._cubeSize,n=this._sourceTarget;return(n===null||n.width!==e||t&&n.depthBuffer===!1)&&(n!==null&&n.dispose(),this._sourceTarget=Fd(e,!0,t)),this._sourceTarget}_compileMaterial(t){this._boxMesh.material=t,this._renderer.compile(this._boxMesh,this._cubeCamera.children[0])}_renderCube(t,e,n){const s=this._boxMesh,r=this._cubeCamera;s.material=n,r.renderTarget=t,r.activeMipmapLevel=e;const a=t.width>>e;t.viewport.set(0,0,a,a),r.update(this._renderer,s),t.viewport.set(0,0,t.width,t.height)}_textureToCubemap(t){let e;t.mapping===Os||t.mapping===gr?(this._cubemapMaterial===null&&(this._cubemapMaterial=Bd()),e=this._cubemapMaterial,e.uniforms.flipEnvMap.value=t.isRenderTargetTexture===!1?-1:1):(this._equirectMaterial===null&&(this._equirectMaterial=Od()),e=this._equirectMaterial),e.uniforms.envMap.value=t,this._renderCube(this._getSourceTarget(),0,e)}_applyPMREM(t){this._ggxMaterial===null&&(this._ggxMaterial=Yg(),this._integrationMaterial=Kg());const e=this._cubeSize,n=t.texture.mipmaps.length-1,s=this._ggxMaterial.uniforms;s.envMap.value=this._sourceTarget.texture;const r=this._integrationMaterial.uniforms;r.envMap.value=this._sourceTarget.texture,r.sourceLod.value=Math.log2(e/Nu);for(let a=0;a<=n;a++){const o=za.lodToRoughness(a,n);if(a>n-Wg)r.roughness.value=o,this._renderCube(t,a,this._integrationMaterial);else{const l=o>0?Math.log2(e)+.5*Math.log2(6/(Iu*Math.pow(o,4)))+.5:0;s.roughness.value=o,s.lodBias.value=l,this._renderCube(t,a,this._ggxMaterial)}}}_blur(t,e){this._blurMaterial===null&&(this._blurMaterial=Zg());const n=this._blurMaterial,s=n.uniforms,r=this._sourceTarget;s.sigma.value=Math.min(e,Math.PI)/Math.SQRT2,s.envMap.value=r.texture,this._renderCube(t,0,n),s.envMap.value=t.texture,this._renderCube(r,0,n)}}function Fd(i,t,e){return new vc(i,{minFilter:ui,generateMipmaps:t,type:jn,colorSpace:La,depthBuffer:e})}function wr(i,t,e){return new Un({name:i,uniforms:t,vertexShader:Vt.cube_vert,fragmentShader:e,side:qe,blending:Cs,depthTest:!1,depthWrite:!1})}function Yg(){return wr("PMREMGGXConvolution",{envMap:{value:null},roughness:{value:0},lodBias:{value:0}},`

		#define GGX_SAMPLES ${Iu}u

		varying vec3 vWorldDirection;

		uniform samplerCube envMap;
		uniform float roughness;
		uniform float lodBias;

		#include <common>

		// Van der Corput radical inverse
		float radicalInverse_VdC( uint bits ) {

			bits = ( bits << 16u ) | ( bits >> 16u );
			bits = ( ( bits & 0x55555555u ) << 1u ) | ( ( bits & 0xAAAAAAAAu ) >> 1u );
			bits = ( ( bits & 0x33333333u ) << 2u ) | ( ( bits & 0xCCCCCCCCu ) >> 2u );
			bits = ( ( bits & 0x0F0F0F0Fu ) << 4u ) | ( ( bits & 0xF0F0F0F0u ) >> 4u );
			bits = ( ( bits & 0x00FF00FFu ) << 8u ) | ( ( bits & 0xFF00FF00u ) >> 8u );
			return float( bits ) * 2.3283064365386963e-10; // / 0x100000000

		}

		// Hammersley sequence
		vec2 hammersley( uint i, uint N ) {

			return vec2( float( i ) / float( N ), radicalInverse_VdC( i ) );

		}

		void main() {

			vec3 N = normalize( vWorldDirection );

			// For very low roughness, just sample the environment directly
			if ( roughness < 0.001 ) {

				gl_FragColor = vec4( textureLod( envMap, N, 0.0 ).rgb, 1.0 );
				return;

			}

			float alpha = roughness * roughness;
			float alpha2 = alpha * alpha;

			// Tangent space basis for VNDF sampling
			vec3 up = abs( N.z ) < 0.999 ? vec3( 0.0, 0.0, 1.0 ) : vec3( 1.0, 0.0, 0.0 );
			vec3 tangent = normalize( cross( up, N ) );
			vec3 bitangent = cross( N, tangent );

			vec3 prefilteredColor = vec3( 0.0 );
			float totalWeight = 0.0;

			for ( uint i = 0u; i < GGX_SAMPLES; i ++ ) {

				vec2 Xi = hammersley( i, GGX_SAMPLES );

				// With V = N, sample the reflected direction directly.
				float invQ = 1.0 / ( 1.0 - Xi.x + alpha2 * Xi.x );
				float NdotL = ( 1.0 - Xi.x - alpha2 * Xi.x ) * invQ;

				if ( NdotL > 0.0 ) {

					float phi = 2.0 * PI * Xi.y;
					float sinTheta = 2.0 * alpha * sqrt( Xi.x * ( 1.0 - Xi.x ) ) * invQ;
					vec3 L = N * NdotL + ( tangent * cos( phi ) + bitangent * sin( phi ) ) * sinTheta;

					// Match the source mip to the sample's solid angle. The terms
					// independent of the sample are precomputed in lodBias.
					float d = alpha2 * invQ;
					float lod = max( log2( d ) + lodBias, 0.0 );

					// Weight by NdotL for the split-sum approximation
					prefilteredColor += textureLod( envMap, L, lod ).rgb * NdotL;
					totalWeight += NdotL;

				}

			}

			gl_FragColor = vec4( prefilteredColor / totalWeight, 1.0 );

		}
	`)}function Kg(){return wr("PMREMGGXIntegration",{envMap:{value:null},roughness:{value:0},sourceLod:{value:0},sourceSize:{value:Nu}},`

		varying vec3 vWorldDirection;

		uniform samplerCube envMap;
		uniform float roughness;
		uniform float sourceLod;
		uniform int sourceSize;

		void main() {

			vec3 N = normalize( vWorldDirection );

			float alpha = roughness * roughness;
			float alpha2 = alpha * alpha;

			float texelSize = 2.0 / float( sourceSize );

			vec3 prefilteredColor = vec3( 0.0 );
			float totalWeight = 0.0;

			// Pair opposite texels: only the one in N's hemisphere contributes.
			for ( int face = 0; face < 3; face ++ ) {

				for ( int y = 0; y < sourceSize; y ++ ) {

					for ( int x = 0; x < sourceSize; x ++ ) {

						vec2 uv = ( vec2( x, y ) + 0.5 ) * texelSize - 1.0;
						vec3 texelDirection = face == 0 ? vec3( 1.0, uv ) : ( face == 1 ? vec3( uv.x, 1.0, uv.y ) : vec3( uv, 1.0 ) );

						float invDistance = inversesqrt( 1.0 + dot( uv, uv ) );
						float NdotL = dot( N, texelDirection );
						texelDirection *= NdotL < 0.0 ? - 1.0 : 1.0;
						NdotL = abs( NdotL ) * invDistance;

						// With V = N, NdotH squared is ( 1 + NdotL ) / 2. Common factors
						// in the GGX distribution and texel solid angle cancel when normalized.
						float d = 1.0 + alpha2 + ( alpha2 - 1.0 ) * NdotL;
						float weight = NdotL * invDistance * invDistance * invDistance / ( d * d );

						prefilteredColor += textureLod( envMap, texelDirection, sourceLod ).rgb * weight;
						totalWeight += weight;

					}

				}

			}

			gl_FragColor = vec4( prefilteredColor / totalWeight, 1.0 );

		}
	`)}function Zg(){return wr("PMREMSphericalGaussianBlur",{envMap:{value:null},sigma:{value:0}},`

		#define SAMPLES ${$g}
		#define GOLDEN_ANGLE 2.39996322973

		varying vec3 vWorldDirection;

		uniform samplerCube envMap;
		uniform float sigma;

		#include <common>

		void main() {

			vec3 outputDirection = normalize( vWorldDirection );

			vec3 up = abs( outputDirection.z ) < 0.999 ? vec3( 0.0, 0.0, 1.0 ) : vec3( 1.0, 0.0, 0.0 );
			vec3 tangent = normalize( cross( up, outputDirection ) );
			vec3 bitangent = cross( outputDirection, tangent );

			// Truncate the kernel at three standard deviations or at the antipode.
			float thetaMax = min( 3.0 * sigma, PI );
			float truncation = 1.0 - exp( - 0.5 * thetaMax * thetaMax / ( sigma * sigma ) );

			vec3 accumColor = vec3( 0.0 );
			float accumWeight = 0.0;

			for ( int i = 0; i < SAMPLES; i ++ ) {

				// Stratified inverse-CDF sampling of the Gaussian, placed on a golden-angle spiral.
				float stratum = ( float( i ) + 0.5 ) / float( SAMPLES );
				float theta = sigma * sqrt( - 2.0 * log( 1.0 - stratum * truncation ) );
				float phi = float( i ) * GOLDEN_ANGLE;

				vec3 offset = cos( phi ) * tangent + sin( phi ) * bitangent;
				vec3 sampleDirection = cos( theta ) * outputDirection + sin( theta ) * offset;

				// Correct the planar sample density to solid angle.
				float weight = sin( theta ) / theta;

				accumColor += weight * textureLod( envMap, sampleDirection, 0.0 ).rgb;
				accumWeight += weight;

			}

			gl_FragColor = vec4( accumColor / accumWeight, 1.0 );

		}
	`)}function Od(){return wr("PMREMEquirectangularToCubemap",{envMap:{value:null}},`

		varying vec3 vWorldDirection;

		uniform sampler2D envMap;

		#include <common>

		void main() {

			// Average four subpixel samples to preserve small, bright features.
			vec3 direction = normalize( vWorldDirection );
			vec3 dx = dFdx( direction ) * 0.25;
			vec3 dy = dFdy( direction ) * 0.25;

			vec3 color = textureLod( envMap, equirectUv( normalize( direction - dx - dy ) ), 0.0 ).rgb;
			color += textureLod( envMap, equirectUv( normalize( direction + dx - dy ) ), 0.0 ).rgb;
			color += textureLod( envMap, equirectUv( normalize( direction - dx + dy ) ), 0.0 ).rgb;
			color += textureLod( envMap, equirectUv( normalize( direction + dx + dy ) ), 0.0 ).rgb;
			gl_FragColor = vec4( color * 0.25, 1.0 );

		}
	`)}function Bd(){return wr("PMREMCubemapToCubemap",{envMap:{value:null},flipEnvMap:{value:-1}},`

		varying vec3 vWorldDirection;

		uniform samplerCube envMap;
		uniform float flipEnvMap;

		void main() {

			gl_FragColor = vec4( textureCube( envMap, vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) ).rgb, 1.0 );

		}
	`)}function Jg(i){let t=new WeakMap,e=new WeakMap,n=null;function s(u,f=!1){return u==null?null:f?a(u):r(u)}function r(u){if(u&&u.isTexture){const f=u.mapping;if(f===so||f===ro)if(t.has(u)){const g=t.get(u).texture;return o(g,u.mapping)}else{const g=u.image;if(g&&g.height>0){const x=new vc(g.height);return x.fromEquirectangularTexture(i,u),t.set(u,x),u.addEventListener("dispose",c),o(x.texture,u.mapping)}else return null}}return u}function a(u){if(u&&u.isTexture&&u.isPMREMTexture!==!0){const f=u.mapping,g=f===so||f===ro,x=f===Os||f===gr;if(g||x){let m=e.get(u);const p=m!==void 0?m.texture.pmremVersion:0;if(u.isRenderTargetTexture&&u.pmremVersion!==p)return n===null&&(n=new za(i)),m=g?n.fromEquirectangular(u,m):n.fromCubemap(u,m),m.texture.pmremVersion=u.pmremVersion,e.set(u,m),m.texture;if(m!==void 0)return m.texture;{const _=u.image;return g&&_&&_.height>0||x&&_&&l(_)?(n===null&&(n=new za(i)),m=g?n.fromEquirectangular(u):n.fromCubemap(u),m.texture.pmremVersion=u.pmremVersion,e.set(u,m),u.addEventListener("dispose",d),m.texture):null}}}return u}function o(u,f){return f===so?u.mapping=Os:f===ro&&(u.mapping=gr),u}function l(u){let f=0;const g=6;for(let x=0;x<g;x++)u[x]!==void 0&&f++;return f===g}function c(u){const f=u.target;f.removeEventListener("dispose",c);const g=t.get(f);g!==void 0&&(t.delete(f),g.dispose())}function d(u){const f=u.target;f.removeEventListener("dispose",d);const g=e.get(f);g!==void 0&&(e.delete(f),g.dispose())}function h(){t=new WeakMap,e=new WeakMap,n!==null&&(n.dispose(),n=null)}return{get:s,dispose:h}}function jg(i){const t={};function e(n){if(t[n]!==void 0)return t[n];const s=i.getExtension(n);return t[n]=s,s}return{has:function(n){return e(n)!==null},init:function(){e("EXT_color_buffer_float"),e("WEBGL_clip_cull_distance"),e("OES_texture_float_linear"),e("EXT_color_buffer_half_float"),e("WEBGL_multisampled_render_to_texture"),e("WEBGL_render_shared_exponent")},get:function(n){const s=e(n);return s===null&&Ma("WebGLRenderer: "+n+" extension not supported."),s}}}function Qg(i,t,e,n){const s={},r=new WeakMap,a=new FinalizationRegistry(g=>delete s[g]);function o(g){l(g.target)}function l(g){g.index!==null&&t.remove(g.index);for(const m in g.attributes)t.remove(g.attributes[m]);g.removeEventListener("dispose",o),delete s[g.id],a.unregister(g);const x=r.get(g);x&&(t.remove(x),r.delete(g)),n.releaseStatesOfGeometry(g),g.isInstancedBufferGeometry===!0&&delete g._maxInstanceCount,e.memory.geometries--}function c(g,x){return s[x.id]!==void 0||(x.addEventListener("dispose",o),s[x.id]=new WeakRef(x),a.register(x,x.id,x),e.memory.geometries++),x}function d(g){const x=g.attributes;for(const m in x)t.update(x[m],i.ARRAY_BUFFER)}function h(g){const x=g.index,m=g.attributes.position;let p=0;if(m===void 0)return;const _=x!==null?x.array.length:m.array.length/3-1,S=m.count>=65535?xu:vu,y=new S(Math.ceil(_/3)*6,1),A=y.array;if(x!==null){const v=x.array;p=x.version;for(let w=0,N=0;w<_;w+=3){const R=v[w+0],L=v[w+1],F=v[w+2];A[N++]=R,A[N++]=L,A[N++]=L,A[N++]=F,A[N++]=F,A[N++]=R}}else{p=m.version;for(let v=0,w=0;v<_;v+=3){const N=v+0,R=v+1,L=v+2;A[w++]=N,A[w++]=R,A[w++]=R,A[w++]=L,A[w++]=L,A[w++]=N}}y.version=p;const E=r.get(g);E&&t.remove(E),r.set(g,y)}function u(g){const x=r.get(g);if(x){const m=g.index;m!==null&&x.version<m.version&&h(g)}else h(g);return r.get(g)}function f(){for(const g in s){const x=s[g].deref();x!==void 0&&l(x)}}return{get:c,update:d,getWireframeAttribute:u,dispose:f}}function tv(i,t,e){let n;function s(h){n=h}let r,a;function o(h){r=h.type,a=h.bytesPerElement}function l(h,u){i.drawElements(n,u,r,h*a),e.update(u,n,1)}function c(h,u,f){f!==0&&(i.drawElementsInstanced(n,u,r,h*a,f),e.update(u,n,f))}function d(h,u,f){if(f===0)return;t.get("WEBGL_multi_draw").multiDrawElementsWEBGL(n,u,0,r,h,0,f);let x=0;for(let m=0;m<f;m++)x+=u[m];e.update(x,n,1)}this.setMode=s,this.setIndex=o,this.render=l,this.renderInstances=c,this.renderMultiDraw=d}function ev(i){const t={geometries:0,textures:0},e={frame:0,calls:0,triangles:0,points:0,lines:0};function n(r,a,o){switch(e.calls++,a){case i.TRIANGLES:e.triangles+=o*(r/3);break;case i.LINES:e.lines+=o*(r/2);break;case i.LINE_STRIP:e.lines+=o*(r-1);break;case i.LINE_LOOP:e.lines+=o*r;break;case i.POINTS:e.points+=o*r;break;default:ee("WebGLInfo: Unknown draw mode:",a);break}}function s(){e.calls=0,e.triangles=0,e.points=0,e.lines=0}return{memory:t,render:e,programs:null,autoReset:!0,reset:s,update:n}}function nv(i,t,e){const n=new WeakMap,s=new _e;function r(a,o,l){const c=a.morphTargetInfluences,d=o.morphAttributes.position||o.morphAttributes.normal||o.morphAttributes.color,h=d!==void 0?d.length:0;let u=n.get(o);if(u===void 0||u.count!==h){let R=function(){w.dispose(),n.delete(o),o.removeEventListener("dispose",R)};var f=R;u!==void 0&&u.texture.dispose();const g=o.morphAttributes.position!==void 0,x=o.morphAttributes.normal!==void 0,m=o.morphAttributes.color!==void 0,p=o.morphAttributes.position||[],_=o.morphAttributes.normal||[],S=o.morphAttributes.color||[];let y=0;g===!0&&(y=1),x===!0&&(y=2),m===!0&&(y=3);let A=o.attributes.position.count*y,E=1;A>t.maxTextureSize&&(E=Math.ceil(A/t.maxTextureSize),A=t.maxTextureSize);const v=new Float32Array(A*E*4*h),w=new mu(v,A,E,h);w.type=Pn,w.needsUpdate=!0;const N=y*4;for(let L=0;L<h;L++){const F=p[L],V=_[L],D=S[L],H=A*E*4*L;for(let q=0;q<F.count;q++){const k=q*N;g===!0&&(s.fromBufferAttribute(F,q),v[H+k+0]=s.x,v[H+k+1]=s.y,v[H+k+2]=s.z,v[H+k+3]=0),x===!0&&(s.fromBufferAttribute(V,q),v[H+k+4]=s.x,v[H+k+5]=s.y,v[H+k+6]=s.z,v[H+k+7]=0),m===!0&&(s.fromBufferAttribute(D,q),v[H+k+8]=s.x,v[H+k+9]=s.y,v[H+k+10]=s.z,v[H+k+11]=D.itemSize===4?s.w:1)}}u={count:h,texture:w,size:new Dt(A,E)},n.set(o,u),o.addEventListener("dispose",R)}if(a.isInstancedMesh===!0&&a.morphTexture!==null)l.getUniforms().setValue(i,"morphTexture",a.morphTexture,e);else{let g=0;for(let m=0;m<c.length;m++)g+=c[m];const x=o.morphTargetsRelative?1:1-g;l.getUniforms().setValue(i,"morphTargetBaseInfluence",x),l.getUniforms().setValue(i,"morphTargetInfluences",c)}l.getUniforms().setValue(i,"morphTargetsTexture",u.texture,e),l.getUniforms().setValue(i,"morphTargetsTextureSize",u.size)}return{update:r}}function iv(i,t,e,n,s){let r=new WeakMap;function a(c){const d=s.render.frame,h=c.geometry,u=t.get(c,h);if(r.get(u)!==d&&(t.update(u),r.set(u,d)),c.isInstancedMesh&&(c.hasEventListener("dispose",l)===!1&&c.addEventListener("dispose",l),r.get(c)!==d&&(e.update(c.instanceMatrix,i.ARRAY_BUFFER),c.instanceColor!==null&&e.update(c.instanceColor,i.ARRAY_BUFFER),r.set(c,d))),c.isSkinnedMesh){const f=c.skeleton;r.get(f)!==d&&(f.update(),r.set(f,d))}return u}function o(){r=new WeakMap}function l(c){const d=c.target;d.removeEventListener("dispose",l),n.releaseStatesOfObject(d),e.remove(d.instanceMatrix),d.instanceColor!==null&&e.remove(d.instanceColor)}return{update:a,dispose:o}}const sv={[Zh]:"LINEAR_TONE_MAPPING",[Jh]:"REINHARD_TONE_MAPPING",[jh]:"CINEON_TONE_MAPPING",[jl]:"ACES_FILMIC_TONE_MAPPING",[tu]:"AGX_TONE_MAPPING",[eu]:"NEUTRAL_TONE_MAPPING",[Qh]:"CUSTOM_TONE_MAPPING"};function rv(i,t,e,n,s,r){const a=new Sn(t,e,{type:i,depthBuffer:s,stencilBuffer:r,samples:n?4:0,storeMultisampledDepthBuffer:!1,storeMultisampledStencilBuffer:!1,resolveDepthBuffer:!1,resolveStencilBuffer:!1});let o=null,l=null,c=null;const d=new be;d.setAttribute("position",new ne([-1,3,0,-1,-1,0,3,-1,0],3)),d.setAttribute("uv",new ne([0,2,0,0,2,0],2));const h=new qp({uniforms:{tDiffuse:{value:null}},vertexShader:`
			precision highp float;

			uniform mat4 modelViewMatrix;
			uniform mat4 projectionMatrix;

			attribute vec3 position;
			attribute vec2 uv;

			varying vec2 vUv;

			void main() {
				vUv = uv;
				gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
			}`,fragmentShader:`
			precision highp float;

			uniform sampler2D tDiffuse;

			varying vec2 vUv;

			#include <tonemapping_pars_fragment>
			#include <colorspace_pars_fragment>

			void main() {
				gl_FragColor = texture2D( tDiffuse, vUv );

				#ifdef LINEAR_TONE_MAPPING
					gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );
				#elif defined( REINHARD_TONE_MAPPING )
					gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );
				#elif defined( CINEON_TONE_MAPPING )
					gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );
				#elif defined( ACES_FILMIC_TONE_MAPPING )
					gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );
				#elif defined( AGX_TONE_MAPPING )
					gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );
				#elif defined( NEUTRAL_TONE_MAPPING )
					gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );
				#elif defined( CUSTOM_TONE_MAPPING )
					gl_FragColor.rgb = CustomToneMapping( gl_FragColor.rgb );
				#endif

				#ifdef SRGB_TRANSFER
					gl_FragColor = sRGBTransferOETF( gl_FragColor );
				#endif
			}`,depthTest:!1,depthWrite:!1}),u=new $t(d,h),f=new gc(-1,1,1,-1,0,1);let g=null,x=null,m=!1,p,_=null,S=[],y=!1;this.setSize=function(A,E){a.setSize(A,E),o!==null&&o.setSize(A,E),l!==null&&l.setSize(A,E);for(let v=0;v<S.length;v++){const w=S[v];w.setSize&&w.setSize(A,E)}},this.setEffects=function(A){S=A,y=S.length>0&&S[0].isRenderPass===!0;const E=a.width,v=a.height;S.length>0&&o===null&&(o=new Sn(E,v,{type:jn,depthBuffer:!1,stencilBuffer:!1}),l=new Sn(E,v,{type:jn,depthBuffer:!1,stencilBuffer:!1}));const w=s===!0&&S.some(N=>N.needsDepthTexture===!0);w!==(a.depthTexture!==null)&&(w===!0&&c===null&&(c=new ks(E,v),r===!0&&(c.format=Di,c.type=Bs)),a.dispose(),a.depthTexture=w?c:null,a.resolveDepthBuffer=w,a.storeMultisampledDepthBuffer=w);for(let N=0;N<S.length;N++){const R=S[N];R.setSize&&R.setSize(E,v),w&&R.needsDepthTexture===!0&&R.setDepthTexture&&R.setDepthTexture(c)}},this.begin=function(A,E){if(m||A.toneMapping===mi&&S.length===0)return!1;if(_=E,E!==null){const v=E.width,w=E.height;(a.width!==v||a.height!==w)&&this.setSize(v,w)}return y===!1&&A.setRenderTarget(a),p=A.toneMapping,A.toneMapping=mi,!0},this.hasRenderPass=function(){return y},this.end=function(A,E){A.toneMapping=p,m=!0;let v=a,w=o;for(let N=0;N<S.length;N++){const R=S[N];R.enabled!==!1&&(R.render(A,w,v,E),R.needsSwap!==!1&&(v=w,w=w===o?l:o))}if(g!==A.outputColorSpace||x!==A.toneMapping){g=A.outputColorSpace,x=A.toneMapping,h.defines={},Jt.getTransfer(g)===ae&&(h.defines.SRGB_TRANSFER="");const N=sv[x];N&&(h.defines[N]=""),h.needsUpdate=!0}h.uniforms.tDiffuse.value=v.texture,A.setRenderTarget(_),A.render(u,f),_=null,m=!1},this.isCompositing=function(){return m},this.dispose=function(){a.dispose(),o!==null&&o.dispose(),l!==null&&l.dispose(),d.dispose(),h.dispose()}}const Uu=new Ye,Fu=new ks(1,1),Ou=new Eu(1),Bu=new mu,ku=new Mp,zu=new Su,kd=[],zd=[],Hd=new Float32Array(16),Gd=new Float32Array(9),Vd=new Float32Array(4);function Hs(i,t,e){const n=i[0];if(n<=0||n>0)return i;const s=t*e;let r=kd[s];if(r===void 0&&(r=new Float32Array(s),kd[s]=r),t!==0){n.toArray(r,0);for(let a=1,o=0;a!==t;++a)o+=e,i[a].toArray(r,o)}return r}function Pe(i,t){if(i.length!==t.length)return!1;for(let e=0,n=i.length;e<n;e++)if(i[e]!==t[e])return!1;return!0}function Le(i,t){for(let e=0,n=t.length;e<n;e++)i[e]=t[e]}function Qa(i,t){let e=zd[t];e===void 0&&(e=new Int32Array(t),zd[t]=e);for(let n=0;n!==t;++n)e[n]=i.allocateTextureUnit();return e}function av(i,t){const e=this.cache;e[0]!==t&&(i.uniform1f(this.addr,t),e[0]=t)}function ov(i,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(i.uniform2f(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Pe(e,t))return;i.uniform2fv(this.addr,t),Le(e,t)}}function lv(i,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(i.uniform3f(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else if(t.r!==void 0)(e[0]!==t.r||e[1]!==t.g||e[2]!==t.b)&&(i.uniform3f(this.addr,t.r,t.g,t.b),e[0]=t.r,e[1]=t.g,e[2]=t.b);else{if(Pe(e,t))return;i.uniform3fv(this.addr,t),Le(e,t)}}function cv(i,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(i.uniform4f(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Pe(e,t))return;i.uniform4fv(this.addr,t),Le(e,t)}}function dv(i,t){const e=this.cache,n=t.elements;if(n===void 0){if(Pe(e,t))return;i.uniformMatrix2fv(this.addr,!1,t),Le(e,t)}else{if(Pe(e,n))return;Vd.set(n),i.uniformMatrix2fv(this.addr,!1,Vd),Le(e,n)}}function hv(i,t){const e=this.cache,n=t.elements;if(n===void 0){if(Pe(e,t))return;i.uniformMatrix3fv(this.addr,!1,t),Le(e,t)}else{if(Pe(e,n))return;Gd.set(n),i.uniformMatrix3fv(this.addr,!1,Gd),Le(e,n)}}function uv(i,t){const e=this.cache,n=t.elements;if(n===void 0){if(Pe(e,t))return;i.uniformMatrix4fv(this.addr,!1,t),Le(e,t)}else{if(Pe(e,n))return;Hd.set(n),i.uniformMatrix4fv(this.addr,!1,Hd),Le(e,n)}}function fv(i,t){const e=this.cache;e[0]!==t&&(i.uniform1i(this.addr,t),e[0]=t)}function pv(i,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(i.uniform2i(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Pe(e,t))return;i.uniform2iv(this.addr,t),Le(e,t)}}function mv(i,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(i.uniform3i(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(Pe(e,t))return;i.uniform3iv(this.addr,t),Le(e,t)}}function gv(i,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(i.uniform4i(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Pe(e,t))return;i.uniform4iv(this.addr,t),Le(e,t)}}function vv(i,t){const e=this.cache;e[0]!==t&&(i.uniform1ui(this.addr,t),e[0]=t)}function xv(i,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(i.uniform2ui(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Pe(e,t))return;i.uniform2uiv(this.addr,t),Le(e,t)}}function _v(i,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(i.uniform3ui(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(Pe(e,t))return;i.uniform3uiv(this.addr,t),Le(e,t)}}function yv(i,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(i.uniform4ui(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Pe(e,t))return;i.uniform4uiv(this.addr,t),Le(e,t)}}function to(i){return i.version===0&&(i.compareFunction=hu,i.needsUpdate=!0),i}function bv(i,t,e){const n=this.cache,s=e.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s);let r;this.type===i.SAMPLER_2D_SHADOW?r=to(Fu):r=Uu,e.setTexture2D(t||r,s)}function Mv(i,t,e){const n=this.cache,s=e.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),e.setTexture3D(t||ku,s)}function Sv(i,t,e){const n=this.cache,s=e.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s);let r;this.type===i.SAMPLER_CUBE_SHADOW?r=to(Ou):r=zu,e.setTextureCube(t||r,s)}function wv(i,t,e){const n=this.cache,s=e.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),e.setTexture2DArray(t||Bu,s)}function Ev(i){switch(i){case 5126:return av;case 35664:return ov;case 35665:return lv;case 35666:return cv;case 35674:return dv;case 35675:return hv;case 35676:return uv;case 5124:case 35670:return fv;case 35667:case 35671:return pv;case 35668:case 35672:return mv;case 35669:case 35673:return gv;case 5125:return vv;case 36294:return xv;case 36295:return _v;case 36296:return yv;case 35678:case 36198:case 36298:case 36306:case 35682:return bv;case 35679:case 36299:case 36307:return Mv;case 35680:case 36300:case 36308:case 36293:return Sv;case 36289:case 36303:case 36311:case 36292:return wv}}function Av(i,t){i.uniform1fv(this.addr,t)}function Tv(i,t){const e=Hs(t,this.size,2);i.uniform2fv(this.addr,e)}function Rv(i,t){const e=Hs(t,this.size,3);i.uniform3fv(this.addr,e)}function Cv(i,t){const e=Hs(t,this.size,4);i.uniform4fv(this.addr,e)}function Pv(i,t){const e=Hs(t,this.size,4);i.uniformMatrix2fv(this.addr,!1,e)}function Lv(i,t){const e=Hs(t,this.size,9);i.uniformMatrix3fv(this.addr,!1,e)}function Dv(i,t){const e=Hs(t,this.size,16);i.uniformMatrix4fv(this.addr,!1,e)}function Iv(i,t){i.uniform1iv(this.addr,t)}function Nv(i,t){i.uniform2iv(this.addr,t)}function Uv(i,t){i.uniform3iv(this.addr,t)}function Fv(i,t){i.uniform4iv(this.addr,t)}function Ov(i,t){i.uniform1uiv(this.addr,t)}function Bv(i,t){i.uniform2uiv(this.addr,t)}function kv(i,t){i.uniform3uiv(this.addr,t)}function zv(i,t){i.uniform4uiv(this.addr,t)}function Hv(i,t,e){const n=this.cache,s=t.length,r=Qa(e,s);Pe(n,r)||(i.uniform1iv(this.addr,r),Le(n,r));let a;this.type===i.SAMPLER_2D_SHADOW?a=to(Fu):a=Uu;for(let o=0;o!==s;++o)e.setTexture2D(t[o]||a,r[o])}function Gv(i,t,e){const n=this.cache,s=t.length,r=Qa(e,s);Pe(n,r)||(i.uniform1iv(this.addr,r),Le(n,r));for(let a=0;a!==s;++a)e.setTexture3D(t[a]||ku,r[a])}function Vv(i,t,e){const n=this.cache,s=t.length,r=Qa(e,s);Pe(n,r)||(i.uniform1iv(this.addr,r),Le(n,r));let a;this.type===i.SAMPLER_CUBE_SHADOW?a=to(Ou):a=zu;for(let o=0;o!==s;++o)e.setTextureCube(t[o]||a,r[o])}function $v(i,t,e){const n=this.cache,s=t.length,r=Qa(e,s);Pe(n,r)||(i.uniform1iv(this.addr,r),Le(n,r));for(let a=0;a!==s;++a)e.setTexture2DArray(t[a]||Bu,r[a])}function Wv(i){switch(i){case 5126:return Av;case 35664:return Tv;case 35665:return Rv;case 35666:return Cv;case 35674:return Pv;case 35675:return Lv;case 35676:return Dv;case 5124:case 35670:return Iv;case 35667:case 35671:return Nv;case 35668:case 35672:return Uv;case 35669:case 35673:return Fv;case 5125:return Ov;case 36294:return Bv;case 36295:return kv;case 36296:return zv;case 35678:case 36198:case 36298:case 36306:case 35682:return Hv;case 35679:case 36299:case 36307:return Gv;case 35680:case 36300:case 36308:case 36293:return Vv;case 36289:case 36303:case 36311:case 36292:return $v}}class Xv{constructor(t,e,n){this.id=t,this.addr=n,this.cache=[],this.type=e.type,this.setValue=Ev(e.type)}}class qv{constructor(t,e,n){this.id=t,this.addr=n,this.cache=[],this.type=e.type,this.size=e.size,this.setValue=Wv(e.type)}}class Yv{constructor(t){this.id=t,this.seq=[],this.map={}}setValue(t,e,n){const s=this.seq;for(let r=0,a=s.length;r!==a;++r){const o=s[r];o.setValue(t,e[o.id],n)}}}const Io=/(\w+)(\])?(\[|\.)?/g;function $d(i,t){i.seq.push(t),i.map[t.id]=t}function Kv(i,t,e){const n=i.name,s=n.length;for(Io.lastIndex=0;;){const r=Io.exec(n),a=Io.lastIndex;let o=r[1];const l=r[2]==="]",c=r[3];if(l&&(o=o|0),c===void 0||c==="["&&a+2===s){$d(e,c===void 0?new Xv(o,i,t):new qv(o,i,t));break}else{let h=e.map[o];h===void 0&&(h=new Yv(o),$d(e,h)),e=h}}}class Sa{constructor(t,e){this.seq=[],this.map={};const n=t.getProgramParameter(e,t.ACTIVE_UNIFORMS);for(let a=0;a<n;++a){const o=t.getActiveUniform(e,a),l=t.getUniformLocation(e,o.name);Kv(o,l,this)}const s=[],r=[];for(const a of this.seq)a.type===t.SAMPLER_2D_SHADOW||a.type===t.SAMPLER_CUBE_SHADOW||a.type===t.SAMPLER_2D_ARRAY_SHADOW?s.push(a):r.push(a);s.length>0&&(this.seq=s.concat(r))}setValue(t,e,n,s){const r=this.map[e];r!==void 0&&r.setValue(t,n,s)}setOptional(t,e,n){const s=e[n];s!==void 0&&this.setValue(t,n,s)}static upload(t,e,n,s){for(let r=0,a=e.length;r!==a;++r){const o=e[r],l=n[o.id];l.needsUpdate!==!1&&o.setValue(t,l.value,s)}}static seqWithValue(t,e){const n=[];for(let s=0,r=t.length;s!==r;++s){const a=t[s];a.id in e&&n.push(a)}return n}}function Wd(i,t,e){const n=i.createShader(t);return i.shaderSource(n,e),i.compileShader(n),n}const Zv=37297;let Jv=0;function jv(i,t){const e=i.split(`
`),n=[],s=Math.max(t-6,0),r=Math.min(t+6,e.length);for(let a=s;a<r;a++){const o=a+1;n.push(`${o===t?">":" "} ${o}: ${e[a]}`)}return n.join(`
`)}const Xd=new Ot;function Qv(i){Jt._getMatrix(Xd,Jt.workingColorSpace,i);const t=`mat3( ${Xd.elements.map(e=>e.toFixed(4))} )`;switch(Jt.getTransfer(i)){case Da:return[t,"LinearTransferOETF"];case ae:return[t,"sRGBTransferOETF"];default:return Lt("WebGLProgram: Unsupported color space: ",i),[t,"LinearTransferOETF"]}}function qd(i,t,e){const n=i.getShaderParameter(t,i.COMPILE_STATUS),r=(i.getShaderInfoLog(t)||"").trim();if(n&&r==="")return"";const a=/ERROR: 0:(\d+)/.exec(r);if(a){const o=parseInt(a[1]);return e.toUpperCase()+`

`+r+`

`+jv(i.getShaderSource(t),o)}else return r}function tx(i,t){const e=Qv(t);return[`vec4 ${i}( vec4 value ) {`,`	return ${e[1]}( vec4( ${e[0]} * value.rgb, value.a ) );`,"}"].join(`
`)}const ex={[Zh]:"Linear",[Jh]:"Reinhard",[jh]:"Cineon",[jl]:"ACESFilmic",[tu]:"AgX",[eu]:"Neutral",[Qh]:"Custom"};function nx(i,t){const e=ex[t];return e===void 0?(Lt("WebGLProgram: Unsupported toneMapping:",t),"vec3 "+i+"( vec3 color ) { return LinearToneMapping( color ); }"):"vec3 "+i+"( vec3 color ) { return "+e+"ToneMapping( color ); }"}const la=new I;function ix(){Jt.getLuminanceCoefficients(la);const i=la.x.toFixed(4),t=la.y.toFixed(4),e=la.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${i}, ${t}, ${e} );`,"	return dot( weights, rgb );","}"].join(`
`)}function sx(i){return[i.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",i.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(nr).join(`
`)}function rx(i){const t=[];for(const e in i){const n=i[e];n!==!1&&t.push("#define "+e+" "+n)}return t.join(`
`)}function ax(i,t){const e={},n=i.getProgramParameter(t,i.ACTIVE_ATTRIBUTES);for(let s=0;s<n;s++){const r=i.getActiveAttrib(t,s),a=r.name;let o=1;r.type===i.FLOAT_MAT2&&(o=2),r.type===i.FLOAT_MAT3&&(o=3),r.type===i.FLOAT_MAT4&&(o=4),e[a]={type:r.type,location:i.getAttribLocation(t,a),locationSize:o}}return e}function nr(i){return i!==""}function Yd(i,t){const e=t.numSpotLightShadows+t.numSpotLightMaps-t.numSpotLightShadowsWithMaps;return i.replace(/NUM_SUN_LIGHTS/g,t.numSunLights).replace(/NUM_DIR_LIGHTS/g,t.numDirLights).replace(/NUM_SPOT_LIGHTS/g,t.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,t.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,e).replace(/NUM_RECT_AREA_LIGHTS/g,t.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,t.numPointLights).replace(/NUM_HEMI_LIGHTS/g,t.numHemiLights).replace(/NUM_SUN_LIGHT_SHADOWS/g,t.numSunLightShadows).replace(/NUM_DIR_LIGHT_SHADOWS/g,t.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,t.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,t.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,t.numPointLightShadows).replace(/NUM_LIGHT_PROBE_GRIDS/g,t.numLightProbeGrids)}function Kd(i,t){return i.replace(/NUM_CLIPPING_PLANES/g,t.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,t.numClippingPlanes-t.numClipIntersection)}const ox=/^[ \t]*#include +<([\w\d./]+)>/gm;function Il(i){return i.replace(ox,lx)}function lx(i,t){const e=Vt[t];if(e===void 0)throw new Error("THREE.WebGLProgram: Can not resolve #include <"+t+">");return Il(e)}const cx=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function Zd(i){return i.replace(cx,dx)}function dx(i,t,e,n){let s="";for(let r=parseInt(t);r<parseInt(e);r++)s+=n.replace(/\[\s*i\s*\]/g,"[ "+r+" ]").replace(/UNROLLED_LOOP_INDEX/g,r);return s}function Jd(i){let t=`precision ${i.precision} float;
	precision ${i.precision} int;
	precision ${i.precision} sampler2D;
	precision ${i.precision} samplerCube;
	precision ${i.precision} sampler3D;
	precision ${i.precision} sampler2DArray;
	precision ${i.precision} sampler2DShadow;
	precision ${i.precision} samplerCubeShadow;
	precision ${i.precision} sampler2DArrayShadow;
	precision ${i.precision} isampler2D;
	precision ${i.precision} isampler3D;
	precision ${i.precision} isamplerCube;
	precision ${i.precision} isampler2DArray;
	precision ${i.precision} usampler2D;
	precision ${i.precision} usampler3D;
	precision ${i.precision} usamplerCube;
	precision ${i.precision} usampler2DArray;
	`;return i.precision==="highp"?t+=`
#define HIGH_PRECISION`:i.precision==="mediump"?t+=`
#define MEDIUM_PRECISION`:i.precision==="lowp"&&(t+=`
#define LOW_PRECISION`),t}const hx={[va]:"SHADOWMAP_TYPE_PCF",[er]:"SHADOWMAP_TYPE_VSM"};function ux(i){return hx[i.shadowMapType]||"SHADOWMAP_TYPE_BASIC"}const fx={[gr]:"ENVMAP_MODE_REFRACTION"};function px(i){return i.envMap===!1?"ENVMAP_MODE_REFLECTION":fx[i.envMapMode]||"ENVMAP_MODE_REFLECTION"}const mx={[Kh]:"ENVMAP_BLENDING_MULTIPLY",[Hf]:"ENVMAP_BLENDING_MIX",[Gf]:"ENVMAP_BLENDING_ADD"};function gx(i){return i.envMap===!1?"ENVMAP_BLENDING_NONE":mx[i.combine]||"ENVMAP_BLENDING_NONE"}function vx(i,t,e,n){const s=i.getContext(),r=e.defines;let a=e.vertexShader,o=e.fragmentShader;const l=ux(e),c=e.envMapPMREM===!0?"ENVMAP_TYPE_PMREM":"ENVMAP_TYPE_CUBE",d=px(e),h=gx(e),u=sx(e),f=rx(r),g=s.createProgram();let x,m,p=e.glslVersion?"#version "+e.glslVersion+`
`:"";e.isRawShaderMaterial?(x=["#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,f].filter(nr).join(`
`),x.length>0&&(x+=`
`),m=["#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,f].filter(nr).join(`
`),m.length>0&&(m+=`
`)):(x=[Jd(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,f,e.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",e.batching?"#define USE_BATCHING":"",e.batchingColor?"#define USE_BATCHING_COLOR":"",e.instancing?"#define USE_INSTANCING":"",e.instancingColor?"#define USE_INSTANCING_COLOR":"",e.instancingMorph?"#define USE_INSTANCING_MORPH":"",e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.map?"#define USE_MAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+d:"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.displacementMap?"#define USE_DISPLACEMENTMAP":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.diffuseRoughnessMap?"#define USE_DIFFUSE_ROUGHNESSMAP":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.mapUv?"#define MAP_UV "+e.mapUv:"",e.alphaMapUv?"#define ALPHAMAP_UV "+e.alphaMapUv:"",e.lightMapUv?"#define LIGHTMAP_UV "+e.lightMapUv:"",e.aoMapUv?"#define AOMAP_UV "+e.aoMapUv:"",e.emissiveMapUv?"#define EMISSIVEMAP_UV "+e.emissiveMapUv:"",e.bumpMapUv?"#define BUMPMAP_UV "+e.bumpMapUv:"",e.normalMapUv?"#define NORMALMAP_UV "+e.normalMapUv:"",e.displacementMapUv?"#define DISPLACEMENTMAP_UV "+e.displacementMapUv:"",e.metalnessMapUv?"#define METALNESSMAP_UV "+e.metalnessMapUv:"",e.roughnessMapUv?"#define ROUGHNESSMAP_UV "+e.roughnessMapUv:"",e.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+e.anisotropyMapUv:"",e.clearcoatMapUv?"#define CLEARCOATMAP_UV "+e.clearcoatMapUv:"",e.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+e.clearcoatNormalMapUv:"",e.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+e.clearcoatRoughnessMapUv:"",e.diffuseRoughnessMapUv?"#define DIFFUSE_ROUGHNESSMAP_UV "+e.diffuseRoughnessMapUv:"",e.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+e.iridescenceMapUv:"",e.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+e.iridescenceThicknessMapUv:"",e.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+e.sheenColorMapUv:"",e.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+e.sheenRoughnessMapUv:"",e.specularMapUv?"#define SPECULARMAP_UV "+e.specularMapUv:"",e.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+e.specularColorMapUv:"",e.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+e.specularIntensityMapUv:"",e.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+e.transmissionMapUv:"",e.thicknessMapUv?"#define THICKNESSMAP_UV "+e.thicknessMapUv:"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexNormals?"#define HAS_NORMAL":"",e.vertexColors?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.flatShading?"#define FLAT_SHADED":"",e.skinning?"#define USE_SKINNING":"",e.morphTargets?"#define USE_MORPHTARGETS":"",e.morphNormals&&e.flatShading===!1?"#define USE_MORPHNORMALS":"",e.morphColors?"#define USE_MORPHCOLORS":"",e.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+e.morphTextureStride:"",e.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+e.morphTargetsCount:"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+l:"",e.sizeAttenuation?"#define USE_SIZEATTENUATION":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",e.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(nr).join(`
`),m=[Jd(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,f,e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",e.map?"#define USE_MAP":"",e.matcap?"#define USE_MATCAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+c:"",e.envMap?"#define "+d:"",e.envMap?"#define "+h:"",e.envMapPMREM?"#define ENVMAP_MAX_LOD "+e.envMapMaxLod+".0":"",e.envMapPMREM?"#define ENVMAP_SIZE "+e.envMapSize+".0":"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.packedNormalMap?"#define USE_PACKED_NORMALMAP":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoat?"#define USE_CLEARCOAT":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.diffuseRoughness?"#define USE_DIFFUSE_ROUGHNESS":"",e.diffuseRoughnessMap?"#define USE_DIFFUSE_ROUGHNESSMAP":"",e.dispersion?"#define USE_DISPERSION":"",e.retroreflection?"#define USE_RETROREFLECTION":"",e.iridescence?"#define USE_IRIDESCENCE":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaTest?"#define USE_ALPHATEST":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.sheen?"#define USE_SHEEN":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors||e.instancingColor?"#define USE_COLOR":"",e.vertexAlphas||e.batchingColor?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.gradientMap?"#define USE_GRADIENTMAP":"",e.flatShading?"#define FLAT_SHADED":"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+l:"",e.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",e.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",e.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",e.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",e.toneMapping!==mi?"#define TONE_MAPPING":"",e.toneMapping!==mi?Vt.tonemapping_pars_fragment:"",e.toneMapping!==mi?nx("toneMapping",e.toneMapping):"",e.dithering?"#define DITHERING":"",e.opaque?"#define OPAQUE":"",Vt.colorspace_pars_fragment,tx("linearToOutputTexel",e.outputColorSpace),ix(),e.useDepthPacking?"#define DEPTH_PACKING "+e.depthPacking:"",`
`].filter(nr).join(`
`)),a=Il(a),a=Yd(a,e),a=Kd(a,e),o=Il(o),o=Yd(o,e),o=Kd(o,e),a=Zd(a),o=Zd(o),e.isRawShaderMaterial!==!0&&(p=`#version 300 es
`,x=[u,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+x,m=["#define varying in",e.glslVersion===Zc?"":"layout(location = 0) out highp vec4 pc_fragColor;",e.glslVersion===Zc?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+m);const _=p+x+a,S=p+m+o,y=Wd(s,s.VERTEX_SHADER,_),A=Wd(s,s.FRAGMENT_SHADER,S);s.attachShader(g,y),s.attachShader(g,A),e.index0AttributeName!==void 0?s.bindAttribLocation(g,0,e.index0AttributeName):e.hasPositionAttribute===!0&&s.bindAttribLocation(g,0,"position"),s.linkProgram(g);function E(R){if(i.debug.checkShaderErrors){const L=s.getProgramInfoLog(g)||"",F=s.getShaderInfoLog(y)||"",V=s.getShaderInfoLog(A)||"",D=L.trim(),H=F.trim(),q=V.trim();let k=!0,tt=!0;if(s.getProgramParameter(g,s.LINK_STATUS)===!1)if(k=!1,typeof i.debug.onShaderError=="function")i.debug.onShaderError(s,g,y,A);else{const W=qd(s,y,"vertex"),j=qd(s,A,"fragment");ee("WebGLProgram: Shader Error "+s.getError()+" - VALIDATE_STATUS "+s.getProgramParameter(g,s.VALIDATE_STATUS)+`

Material Name: `+R.name+`
Material Type: `+R.type+`

Program Info Log: `+D+`
`+W+`
`+j)}else D!==""?Lt("WebGLProgram: Program Info Log:",D):(H===""||q==="")&&(tt=!1);tt&&(R.diagnostics={runnable:k,programLog:D,vertexShader:{log:H,prefix:x},fragmentShader:{log:q,prefix:m}})}s.deleteShader(y),s.deleteShader(A),v=new Sa(s,g),w=ax(s,g)}let v;this.getUniforms=function(){return v===void 0&&E(this),v};let w;this.getAttributes=function(){return w===void 0&&E(this),w};let N=e.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return N===!1&&(N=s.getProgramParameter(g,Zv)),N},this.destroy=function(){n.releaseStatesOfProgram(this),s.deleteProgram(g),this.program=void 0},this.type=e.shaderType,this.name=e.shaderName,this.id=Jv++,this.cacheKey=t,this.usedTimes=1,this.program=g,this.vertexShader=y,this.fragmentShader=A,this}let xx=0;class _x{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(t,e,n){const s=this._getShaderCacheForMaterial(t);return s.has(e)===!1&&(s.add(e),e.usedTimes++),s.has(n)===!1&&(s.add(n),n.usedTimes++),this}remove(t){const e=this.materialCache.get(t);for(const n of e)n.usedTimes--,n.usedTimes===0&&this.shaderCache.delete(n.code);return this.materialCache.delete(t),this}getVertexShaderStage(t){return this._getShaderStage(t.vertexShader)}getFragmentShaderStage(t){return this._getShaderStage(t.fragmentShader)}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(t){const e=this.materialCache;let n=e.get(t);return n===void 0&&(n=new Set,e.set(t,n)),n}_getShaderStage(t){const e=this.shaderCache;let n=e.get(t);return n===void 0&&(n=new yx(t),e.set(t,n)),n}}class yx{constructor(t){this.id=xx++,this.code=t,this.usedTimes=0}}function bx(i){return i===Zi||i===Ca||i===Pa}function Mx(i,t,e,n,s,r){const a=new dc,o=new _x,l=new Set,c=[],d=new Map,h=n.logarithmicDepthBuffer,u={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distance",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function f(v){return l.add(v),v===0?"uv":`uv${v}`}function g(v,w,N,R,L,F){const V=R.fog,D=L.geometry,H=v.isMeshStandardMaterial||v.isMeshLambertMaterial||v.isMeshPhongMaterial?R.environment:null,q=v.isMeshStandardMaterial||v.isMeshLambertMaterial&&!v.envMap||v.isMeshPhongMaterial&&!v.envMap,k=t.get(v.envMap||H,q),tt=u[v.type];let W=n.precision;v.precision!==null&&(W=n.getMaxPrecision(v.precision),W!==v.precision&&Lt("WebGLProgram.getParameters:",v.precision,"not supported, using",W,"instead."));const j=D.morphAttributes.position||D.morphAttributes.normal||D.morphAttributes.color,Q=j!==void 0?j.length:0;let wt=0;D.morphAttributes.position!==void 0&&(wt=1),D.morphAttributes.normal!==void 0&&(wt=2),D.morphAttributes.color!==void 0&&(wt=3);let Bt,K,mt,bt;if(tt){const ft=Wn[tt];Bt=ft.vertexShader,K=ft.fragmentShader}else{Bt=v.vertexShader,K=v.fragmentShader;const ft=o.getVertexShaderStage(v),re=o.getFragmentShaderStage(v);o.update(v,ft,re),mt=ft.id,bt=re.id}const Rt=i.getRenderTarget(),vt=i.state.buffers.depth.getReversed(),zt=L.isInstancedMesh===!0,Se=L.isBatchedMesh===!0,Pt=!!v.map,se=!!v.matcap,le=!!k,Xt=le&&k.isPMREMTexture===!0,ke=!!v.aoMap,Te=!!v.lightMap,rn=!!v.bumpMap&&v.wireframe===!1,ve=!!v.normalMap,Hn=!!v.displacementMap,De=!!v.emissiveMap,gn=!!v.metalnessMap,vn=!!v.roughnessMap,xn=v.anisotropy>0,U=v.clearcoat>0,_n=v.diffuseRoughness>0,fe=v.dispersion>0,pe=v.retroreflectivity>0,ut=v.iridescence>0,Re=v.sheen>0,Ct=v.transmission>0,Ft=xn&&!!v.anisotropyMap,T=U&&!!v.clearcoatMap,b=U&&!!v.clearcoatNormalMap,B=U&&!!v.clearcoatRoughnessMap,et=_n&&!!v.diffuseRoughnessMap,J=ut&&!!v.iridescenceMap,st=ut&&!!v.iridescenceThicknessMap,dt=Re&&!!v.sheenColorMap,X=Re&&!!v.sheenRoughnessMap,Y=!!v.specularMap,at=!!v.specularColorMap,C=!!v.specularIntensityMap,Z=Ct&&!!v.transmissionMap,$=Ct&&!!v.thicknessMap,ot=!!v.gradientMap,it=!!v.alphaMap,rt=v.alphaTest>0,At=!!v.alphaHash,Gt=!!v.extensions;let nt=mi;v.toneMapped&&(Rt===null||Rt.isXRRenderTarget===!0)&&(nt=i.toneMapping);const Tt=Xt?k.isCompressedCubeTexture?k.image[0].mipmaps:k.mipmaps:null,Ht={shaderID:tt,shaderType:v.type,shaderName:v.name,vertexShader:Bt,fragmentShader:K,defines:v.defines,customVertexShaderID:mt,customFragmentShaderID:bt,isRawShaderMaterial:v.isRawShaderMaterial===!0,glslVersion:v.glslVersion,precision:W,batching:Se,batchingColor:Se&&L._colorsTexture!==null,instancing:zt,instancingColor:zt&&L.instanceColor!==null,instancingMorph:zt&&L.morphTexture!==null,outputColorSpace:Rt===null?i.outputColorSpace:Rt.isXRRenderTarget===!0?Rt.texture.colorSpace:Jt.workingColorSpace,alphaToCoverage:!!v.alphaToCoverage,map:Pt,matcap:se,envMap:le,envMapMode:le&&k.mapping,envMapPMREM:Xt,envMapMaxLod:Xt?Tt.length-1:null,envMapSize:Xt?Tt[0].width:null,aoMap:ke,lightMap:Te,bumpMap:rn,normalMap:ve,displacementMap:Hn,emissiveMap:De,normalMapObjectSpace:ve&&v.normalMapType===Wf,normalMapTangentSpace:ve&&v.normalMapType===Rl,packedNormalMap:ve&&v.normalMapType===Rl&&bx(v.normalMap.format),metalnessMap:gn,roughnessMap:vn,anisotropy:xn,anisotropyMap:Ft,clearcoat:U,clearcoatMap:T,clearcoatNormalMap:b,clearcoatRoughnessMap:B,diffuseRoughness:_n,diffuseRoughnessMap:et,dispersion:fe,retroreflection:pe,iridescence:ut,iridescenceMap:J,iridescenceThicknessMap:st,sheen:Re,sheenColorMap:dt,sheenRoughnessMap:X,specularMap:Y,specularColorMap:at,specularIntensityMap:C,transmission:Ct,transmissionMap:Z,thicknessMap:$,gradientMap:ot,opaque:v.transparent===!1&&v.blending===cr&&v.alphaToCoverage===!1,alphaMap:it,alphaTest:rt,alphaHash:At,combine:v.combine,mapUv:Pt&&f(v.map.channel),aoMapUv:ke&&f(v.aoMap.channel),lightMapUv:Te&&f(v.lightMap.channel),bumpMapUv:rn&&f(v.bumpMap.channel),normalMapUv:ve&&f(v.normalMap.channel),displacementMapUv:Hn&&f(v.displacementMap.channel),emissiveMapUv:De&&f(v.emissiveMap.channel),metalnessMapUv:gn&&f(v.metalnessMap.channel),roughnessMapUv:vn&&f(v.roughnessMap.channel),anisotropyMapUv:Ft&&f(v.anisotropyMap.channel),clearcoatMapUv:T&&f(v.clearcoatMap.channel),clearcoatNormalMapUv:b&&f(v.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:B&&f(v.clearcoatRoughnessMap.channel),diffuseRoughnessMapUv:et&&f(v.diffuseRoughnessMap.channel),iridescenceMapUv:J&&f(v.iridescenceMap.channel),iridescenceThicknessMapUv:st&&f(v.iridescenceThicknessMap.channel),sheenColorMapUv:dt&&f(v.sheenColorMap.channel),sheenRoughnessMapUv:X&&f(v.sheenRoughnessMap.channel),specularMapUv:Y&&f(v.specularMap.channel),specularColorMapUv:at&&f(v.specularColorMap.channel),specularIntensityMapUv:C&&f(v.specularIntensityMap.channel),transmissionMapUv:Z&&f(v.transmissionMap.channel),thicknessMapUv:$&&f(v.thicknessMap.channel),alphaMapUv:it&&f(v.alphaMap.channel),vertexTangents:!!D.attributes.tangent&&(ve||xn),vertexNormals:!!D.attributes.normal,vertexColors:v.vertexColors,vertexAlphas:v.vertexColors===!0&&!!D.attributes.color&&D.attributes.color.itemSize===4,pointsUvs:L.isPoints===!0&&!!D.attributes.uv&&(Pt||it),fog:!!V,useFog:v.fog===!0,fogExp2:!!V&&V.isFogExp2,flatShading:v.wireframe===!1&&(v.flatShading===!0||D.attributes.normal===void 0&&ve===!1&&(v.isMeshLambertMaterial||v.isMeshPhongMaterial||v.isMeshStandardMaterial||v.isMeshPhysicalMaterial)),sizeAttenuation:v.sizeAttenuation===!0,logarithmicDepthBuffer:h,reversedDepthBuffer:vt,skinning:L.isSkinnedMesh===!0,hasPositionAttribute:D.attributes.position!==void 0,morphTargets:D.morphAttributes.position!==void 0,morphNormals:D.morphAttributes.normal!==void 0,morphColors:D.morphAttributes.color!==void 0,morphTargetsCount:Q,morphTextureStride:wt,numSunLights:w.sun.length,numDirLights:w.directional.length,numPointLights:w.point.length,numSpotLights:w.spot.length,numSpotLightMaps:w.spotLightMap.length,numRectAreaLights:w.rectArea.length,numHemiLights:w.hemi.length,numSunLightShadows:w.sunShadowMap.length,numDirLightShadows:w.directionalShadowMap.length,numPointLightShadows:w.pointShadowMap.length,numSpotLightShadows:w.spotShadowMap.length,numSpotLightShadowsWithMaps:w.numSpotLightShadowsWithMaps,numLightProbes:w.numLightProbes,numLightProbeGrids:F.filter(ft=>ft.texture!==null).length,numClippingPlanes:r.numPlanes,numClipIntersection:r.numIntersection,dithering:v.dithering,shadowMapEnabled:i.shadowMap.enabled&&N.length>0,shadowMapType:i.shadowMap.type,toneMapping:nt,decodeVideoTexture:Pt&&v.map.isVideoTexture===!0&&Jt.getTransfer(v.map.colorSpace)===ae,decodeVideoTextureEmissive:De&&v.emissiveMap.isVideoTexture===!0&&Jt.getTransfer(v.emissiveMap.colorSpace)===ae,premultipliedAlpha:v.premultipliedAlpha,doubleSided:v.side===Cn,flipSided:v.side===qe,useDepthPacking:v.depthPacking>=0,depthPacking:v.depthPacking||0,index0AttributeName:v.index0AttributeName,extensionClipCullDistance:Gt&&v.extensions.clipCullDistance===!0&&e.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(Gt&&v.extensions.multiDraw===!0||Se)&&e.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:e.has("KHR_parallel_shader_compile"),customProgramCacheKey:v.customProgramCacheKey()};return Ht.vertexUv1s=l.has(1),Ht.vertexUv2s=l.has(2),Ht.vertexUv3s=l.has(3),l.clear(),Ht}function x(v){const w=[];if(v.shaderID?w.push(v.shaderID):(w.push(v.customVertexShaderID),w.push(v.customFragmentShaderID)),v.defines!==void 0)for(const N in v.defines)w.push(N),w.push(v.defines[N]);return v.isRawShaderMaterial===!1&&(m(w,v),p(w,v),w.push(i.outputColorSpace)),w.push(v.customProgramCacheKey),w.join()}function m(v,w){v.push(w.precision),v.push(w.outputColorSpace),v.push(w.envMapMode),v.push(w.envMapPMREM),v.push(w.envMapMaxLod),v.push(w.envMapSize),v.push(w.mapUv),v.push(w.alphaMapUv),v.push(w.lightMapUv),v.push(w.aoMapUv),v.push(w.bumpMapUv),v.push(w.normalMapUv),v.push(w.displacementMapUv),v.push(w.emissiveMapUv),v.push(w.metalnessMapUv),v.push(w.roughnessMapUv),v.push(w.anisotropyMapUv),v.push(w.clearcoatMapUv),v.push(w.clearcoatNormalMapUv),v.push(w.clearcoatRoughnessMapUv),v.push(w.diffuseRoughnessMapUv),v.push(w.iridescenceMapUv),v.push(w.iridescenceThicknessMapUv),v.push(w.sheenColorMapUv),v.push(w.sheenRoughnessMapUv),v.push(w.specularMapUv),v.push(w.specularColorMapUv),v.push(w.specularIntensityMapUv),v.push(w.transmissionMapUv),v.push(w.thicknessMapUv),v.push(w.combine),v.push(w.fogExp2),v.push(w.sizeAttenuation),v.push(w.morphTargetsCount),v.push(w.numSunLights),v.push(w.numDirLights),v.push(w.numPointLights),v.push(w.numSpotLights),v.push(w.numSpotLightMaps),v.push(w.numHemiLights),v.push(w.numRectAreaLights),v.push(w.numSunLightShadows),v.push(w.numDirLightShadows),v.push(w.numPointLightShadows),v.push(w.numSpotLightShadows),v.push(w.numSpotLightShadowsWithMaps),v.push(w.numLightProbes),v.push(w.numLightProbeGrids),v.push(w.shadowMapType),v.push(w.toneMapping),v.push(w.numClippingPlanes),v.push(w.numClipIntersection),v.push(w.depthPacking)}function p(v,w){a.disableAll(),w.instancing&&a.enable(0),w.instancingColor&&a.enable(1),w.instancingMorph&&a.enable(2),w.matcap&&a.enable(3),w.envMap&&a.enable(4),w.normalMapObjectSpace&&a.enable(5),w.normalMapTangentSpace&&a.enable(6),w.clearcoat&&a.enable(7),w.iridescence&&a.enable(8),w.alphaTest&&a.enable(9),w.vertexColors&&a.enable(10),w.vertexAlphas&&a.enable(11),w.vertexUv1s&&a.enable(12),w.vertexUv2s&&a.enable(13),w.vertexUv3s&&a.enable(14),w.vertexTangents&&a.enable(15),w.anisotropy&&a.enable(16),w.alphaHash&&a.enable(17),w.batching&&a.enable(18),w.dispersion&&a.enable(19),w.retroreflection&&a.enable(24),w.diffuseRoughness&&a.enable(25),w.batchingColor&&a.enable(20),w.gradientMap&&a.enable(21),w.packedNormalMap&&a.enable(22),w.vertexNormals&&a.enable(23),v.push(a.mask),a.disableAll(),w.fog&&a.enable(0),w.useFog&&a.enable(1),w.flatShading&&a.enable(2),w.logarithmicDepthBuffer&&a.enable(3),w.reversedDepthBuffer&&a.enable(4),w.skinning&&a.enable(5),w.morphTargets&&a.enable(6),w.morphNormals&&a.enable(7),w.morphColors&&a.enable(8),w.premultipliedAlpha&&a.enable(9),w.shadowMapEnabled&&a.enable(10),w.doubleSided&&a.enable(11),w.flipSided&&a.enable(12),w.useDepthPacking&&a.enable(13),w.dithering&&a.enable(14),w.transmission&&a.enable(15),w.sheen&&a.enable(16),w.opaque&&a.enable(17),w.pointsUvs&&a.enable(18),w.decodeVideoTexture&&a.enable(19),w.decodeVideoTextureEmissive&&a.enable(20),w.alphaToCoverage&&a.enable(21),w.numLightProbeGrids>0&&a.enable(22),w.hasPositionAttribute&&a.enable(23),v.push(a.mask)}function _(v){const w=u[v.type];let N;if(w){const R=Wn[w];N=$p.clone(R.uniforms)}else N=v.uniforms;return N}function S(v,w){let N=d.get(w);return N!==void 0?++N.usedTimes:(N=new vx(i,w,v,s),c.push(N),d.set(w,N)),N}function y(v){if(--v.usedTimes===0){const w=c.indexOf(v);c[w]=c[c.length-1],c.pop(),d.delete(v.cacheKey),v.destroy()}}function A(v){o.remove(v)}function E(){o.dispose()}return{getParameters:g,getProgramCacheKey:x,getUniforms:_,acquireProgram:S,releaseProgram:y,releaseShaderCache:A,programs:c,dispose:E}}function Sx(){let i=new WeakMap;function t(a){return i.has(a)}function e(a){let o=i.get(a);return o===void 0&&(o={},i.set(a,o)),o}function n(a){i.delete(a)}function s(a,o,l){i.get(a)[o]=l}function r(){i=new WeakMap}return{has:t,get:e,remove:n,update:s,dispose:r}}function wx(i,t){return i.groupOrder!==t.groupOrder?i.groupOrder-t.groupOrder:i.renderOrder!==t.renderOrder?i.renderOrder-t.renderOrder:i.material.id!==t.material.id?i.material.id-t.material.id:i.materialVariant!==t.materialVariant?i.materialVariant-t.materialVariant:i.z!==t.z?i.z-t.z:i.id-t.id}function jd(i,t){return i.groupOrder!==t.groupOrder?i.groupOrder-t.groupOrder:i.renderOrder!==t.renderOrder?i.renderOrder-t.renderOrder:i.z!==t.z?t.z-i.z:i.id-t.id}function Qd(){const i=[];let t=0;const e=[],n=[],s=[];function r(){t=0,e.length=0,n.length=0,s.length=0}function a(u){let f=0;return u.isInstancedMesh&&(f+=2),u.isSkinnedMesh&&(f+=1),f}function o(u,f,g,x,m,p){let _=i[t];return _===void 0?(_={id:u.id,object:u,geometry:f,material:g,materialVariant:a(u),groupOrder:x,renderOrder:u.renderOrder,z:m,group:p},i[t]=_):(_.id=u.id,_.object=u,_.geometry=f,_.material=g,_.materialVariant=a(u),_.groupOrder=x,_.renderOrder=u.renderOrder,_.z=m,_.group=p),t++,_}function l(u,f,g,x,m,p,_){_.reversedDepth===!0&&(m=-m);const S=o(u,f,g,x,m,p);g.transmission>0?n.push(S):g.transparent===!0?s.push(S):e.push(S)}function c(u,f,g,x,m,p){const _=o(u,f,g,x,m,p);g.transmission>0?n.unshift(_):g.transparent===!0?s.unshift(_):e.unshift(_)}function d(u,f){e.length>1&&e.sort(u||wx),n.length>1&&n.sort(f||jd),s.length>1&&s.sort(f||jd)}function h(){for(let u=t,f=i.length;u<f;u++){const g=i[u];if(g.id===null)break;g.id=null,g.object=null,g.geometry=null,g.material=null,g.group=null}}return{opaque:e,transmissive:n,transparent:s,init:r,push:l,unshift:c,finish:h,sort:d}}function Ex(){let i=new WeakMap;function t(n,s){const r=i.get(n);let a;return r===void 0?(a=new Qd,i.set(n,[a])):s>=r.length?(a=new Qd,r.push(a)):a=r[s],a}function e(){i=new WeakMap}return{get:t,dispose:e}}function Ax(){const i={};return{get:function(t){if(i[t.id]!==void 0)return i[t.id];let e;switch(t.type){case"SunLight":case"DirectionalLight":e={direction:new I,color:new Nt};break;case"SpotLight":e={position:new I,direction:new I,color:new Nt,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":e={position:new I,color:new Nt,distance:0,decay:0};break;case"HemisphereLight":e={direction:new I,skyColor:new Nt,groundColor:new Nt};break;case"RectAreaLight":e={color:new Nt,position:new I,halfWidth:new I,halfHeight:new I};break}return i[t.id]=e,e}}}function Tx(){const i={};return{get:function(t){if(i[t.id]!==void 0)return i[t.id];let e;switch(t.type){case"SunLight":case"DirectionalLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Dt};break;case"SpotLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Dt};break;case"PointLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Dt,shadowCameraNear:1,shadowCameraFar:1e3};break}return i[t.id]=e,e}}}let Rx=0;function Cx(i,t){return(t.castShadow?2:0)-(i.castShadow?2:0)+(t.map?1:0)-(i.map?1:0)}function Px(i){const t=new Ax,e=Tx(),n={version:0,hash:{sunLength:-1,directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numSunShadows:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],sun:[],sunShadow:[],sunShadowMap:[],sunShadowMatrix:[],sunShadowCascade:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let c=0;c<9;c++)n.probe.push(new I);const s=new I,r=new jt,a=new jt;function o(c){let d=0,h=0,u=0;for(let F=0;F<9;F++)n.probe[F].set(0,0,0);let f=0,g=0,x=0,m=0,p=0,_=0,S=0,y=0,A=0,E=0,v=0,w=0,N=0,R=0;c.sort(Cx);for(let F=0,V=c.length;F<V;F++){const D=c[F],H=D.color,q=D.intensity,k=D.distance;let tt=null;if(D.shadow&&D.shadow.map&&(D.shadow.map.texture.format===Zi?tt=D.shadow.map.texture:tt=D.shadow.map.depthTexture||D.shadow.map.texture),D.isAmbientLight)d+=H.r*q,h+=H.g*q,u+=H.b*q;else if(D.isLightProbe){for(let W=0;W<9;W++)n.probe[W].addScaledVector(D.sh.coefficients[W],q);R++}else if(D.isSunLight){const W=t.get(D);if(W.color.copy(D.color).multiplyScalar(D.intensity),D.castShadow){const j=D.shadow,Q=e.get(D);Q.shadowIntensity=j.intensity,Q.shadowBias=j.bias,Q.shadowNormalBias=j.normalBias,Q.shadowRadius=j.radius,Q.shadowMapSize.copy(j.mapSize).multiply(j.getFrameExtents()),n.sunShadow[g]=Q,n.sunShadowMap[g]=tt;const wt=j.getViewportCount();for(let Bt=0;Bt<wt;Bt++)n.sunShadowMatrix[x+Bt]=j.getMatrix(Bt),n.sunShadowCascade[x+Bt]=j._cascadeData[Bt];x+=wt,g++}n.sun[f]=W,f++}else if(D.isDirectionalLight){const W=t.get(D);if(W.color.copy(D.color).multiplyScalar(D.intensity),D.castShadow){const j=D.shadow,Q=e.get(D);Q.shadowIntensity=j.intensity,Q.shadowBias=j.bias,Q.shadowNormalBias=j.normalBias,Q.shadowRadius=j.radius,Q.shadowMapSize=j.mapSize,n.directionalShadow[m]=Q,n.directionalShadowMap[m]=tt,n.directionalShadowMatrix[m]=D.shadow.matrix,A++}n.directional[m]=W,m++}else if(D.isSpotLight){const W=t.get(D);W.position.setFromMatrixPosition(D.matrixWorld),W.color.copy(H).multiplyScalar(q),W.distance=k,W.coneCos=Math.cos(D.angle),W.penumbraCos=Math.cos(D.angle*(1-D.penumbra)),W.decay=D.decay,n.spot[_]=W;const j=D.shadow;if(D.map&&(n.spotLightMap[w]=D.map,w++,j.updateMatrices(D),D.castShadow&&N++),n.spotLightMatrix[_]=j.matrix,D.castShadow){const Q=e.get(D);Q.shadowIntensity=j.intensity,Q.shadowBias=j.bias,Q.shadowNormalBias=j.normalBias,Q.shadowRadius=j.radius,Q.shadowMapSize=j.mapSize,n.spotShadow[_]=Q,n.spotShadowMap[_]=tt,v++}_++}else if(D.isRectAreaLight){const W=t.get(D);W.color.copy(H).multiplyScalar(q),W.halfWidth.set(D.width*.5,0,0),W.halfHeight.set(0,D.height*.5,0),n.rectArea[S]=W,S++}else if(D.isPointLight){const W=t.get(D);if(W.color.copy(D.color).multiplyScalar(D.intensity),W.distance=D.distance,W.decay=D.decay,D.castShadow){const j=D.shadow,Q=e.get(D);Q.shadowIntensity=j.intensity,Q.shadowBias=j.bias,Q.shadowNormalBias=j.normalBias,Q.shadowRadius=j.radius,Q.shadowMapSize=j.mapSize,Q.shadowCameraNear=j.camera.near,Q.shadowCameraFar=j.camera.far,n.pointShadow[p]=Q,n.pointShadowMap[p]=tt,n.pointShadowMatrix[p]=D.shadow.matrix,E++}n.point[p]=W,p++}else if(D.isHemisphereLight){const W=t.get(D);W.skyColor.copy(D.color).multiplyScalar(q),W.groundColor.copy(D.groundColor).multiplyScalar(q),n.hemi[y]=W,y++}}S>0&&(i.has("OES_texture_float_linear")===!0?(n.rectAreaLTC1=pt.LTC_FLOAT_1,n.rectAreaLTC2=pt.LTC_FLOAT_2):(n.rectAreaLTC1=pt.LTC_HALF_1,n.rectAreaLTC2=pt.LTC_HALF_2)),n.ambient[0]=d,n.ambient[1]=h,n.ambient[2]=u;const L=n.hash;(L.sunLength!==f||L.directionalLength!==m||L.pointLength!==p||L.spotLength!==_||L.rectAreaLength!==S||L.hemiLength!==y||L.numSunShadows!==g||L.numDirectionalShadows!==A||L.numPointShadows!==E||L.numSpotShadows!==v||L.numSpotMaps!==w||L.numLightProbes!==R)&&(n.sun.length=f,n.directional.length=m,n.spot.length=_,n.rectArea.length=S,n.point.length=p,n.hemi.length=y,n.sunShadow.length=g,n.sunShadowMap.length=g,n.sunShadowMatrix.length=x,n.sunShadowCascade.length=x,n.directionalShadow.length=A,n.directionalShadowMap.length=A,n.directionalShadowMatrix.length=A,n.pointShadow.length=E,n.pointShadowMap.length=E,n.pointShadowMatrix.length=E,n.spotShadow.length=v,n.spotShadowMap.length=v,n.spotLightMatrix.length=v+w-N,n.spotLightMap.length=w,n.numSpotLightShadowsWithMaps=N,n.numLightProbes=R,L.sunLength=f,L.directionalLength=m,L.pointLength=p,L.spotLength=_,L.rectAreaLength=S,L.hemiLength=y,L.numSunShadows=g,L.numDirectionalShadows=A,L.numPointShadows=E,L.numSpotShadows=v,L.numSpotMaps=w,L.numLightProbes=R,n.version=Rx++)}function l(c,d){let h=0,u=0,f=0,g=0,x=0,m=0;const p=d.matrixWorldInverse;for(let _=0,S=c.length;_<S;_++){const y=c[_];if(y.isSunLight){const A=n.sun[h];A.direction.setFromMatrixPosition(y.matrixWorld),A.direction.transformDirection(p),h++}else if(y.isDirectionalLight){const A=n.directional[u];A.direction.setFromMatrixPosition(y.matrixWorld),s.setFromMatrixPosition(y.target.matrixWorld),A.direction.sub(s),A.direction.transformDirection(p),u++}else if(y.isSpotLight){const A=n.spot[g];A.position.setFromMatrixPosition(y.matrixWorld),A.position.applyMatrix4(p),A.direction.setFromMatrixPosition(y.matrixWorld),s.setFromMatrixPosition(y.target.matrixWorld),A.direction.sub(s),A.direction.transformDirection(p),g++}else if(y.isRectAreaLight){const A=n.rectArea[x];A.position.setFromMatrixPosition(y.matrixWorld),A.position.applyMatrix4(p),a.identity(),r.copy(y.matrixWorld),r.premultiply(p),a.extractRotation(r),A.halfWidth.set(y.width*.5,0,0),A.halfHeight.set(0,y.height*.5,0),A.halfWidth.applyMatrix4(a),A.halfHeight.applyMatrix4(a),x++}else if(y.isPointLight){const A=n.point[f];A.position.setFromMatrixPosition(y.matrixWorld),A.position.applyMatrix4(p),f++}else if(y.isHemisphereLight){const A=n.hemi[m];A.direction.setFromMatrixPosition(y.matrixWorld),A.direction.transformDirection(p),m++}}}return{setup:o,setupView:l,state:n}}function th(i){const t=new Px(i),e=[],n=[],s=[];function r(h){d.camera=h,e.length=0,n.length=0,s.length=0}function a(h){h.isLightProbeGrid?s.push(h):e.push(h)}function o(h){n.push(h)}function l(){t.setup(e),s.sort((h,u)=>h.priority-u.priority||h.id-u.id)}function c(h){t.setupView(e,h)}const d={lightsArray:e,shadowsArray:n,lightProbeGridArray:s,camera:null,lights:t,transmissionRenderTarget:{},textureUnits:0};return{init:r,state:d,setupLights:l,setupLightsView:c,pushLight:a,pushShadow:o}}function Lx(i){let t=new WeakMap;function e(s,r=0){const a=t.get(s);let o;return a===void 0?(o=new th(i),t.set(s,[o])):r>=a.length?(o=new th(i),a.push(o)):o=a[r],o}function n(){t=new WeakMap}return{get:e,dispose:n}}const Dx=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,Ix=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ).rg;
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ).r;
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( max( 0.0, squared_mean - mean * mean ) );
	gl_FragColor = vec4( mean, std_dev, 0.0, 1.0 );
}`,Nx=[new I(1,0,0),new I(-1,0,0),new I(0,1,0),new I(0,-1,0),new I(0,0,1),new I(0,0,-1)],Ux=[new I(0,-1,0),new I(0,-1,0),new I(0,0,1),new I(0,0,-1),new I(0,-1,0),new I(0,-1,0)],eh=new jt,Qs=new I,No=new I;function Fx(i,t,e){let n=new yr;const s=new Dt,r=new Dt,a=new _e,o=new Yp,l=new Kp,c={},d=e.maxTextureSize,h={[Ki]:qe,[qe]:Ki,[Cn]:Cn},u=new Un({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new Dt},radius:{value:4}},vertexShader:Dx,fragmentShader:Ix}),f=u.clone();f.defines.HORIZONTAL_PASS=1;const g=new be;g.setAttribute("position",new Ke(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const x=new $t(g,u),m=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=va;let p=this.type;this.render=function(E,v,w){if(m.enabled===!1||m.autoUpdate===!1&&m.needsUpdate===!1||E.length===0)return;this.type===Xh&&(Lt("WebGLShadowMap: PCFSoftShadowMap has been removed. Using PCFShadowMap instead."),this.type=va);const N=i.getRenderTarget(),R=i.getActiveCubeFace(),L=i.getActiveMipmapLevel(),F=i.state;F.setBlending(Cs),F.buffers.depth.getReversed()===!0?F.buffers.color.setClear(0,0,0,0):F.buffers.color.setClear(1,1,1,1),F.buffers.depth.setTest(!0),F.setScissorTest(!1);const V=p!==this.type;V&&v.traverse(function(D){D.material&&(Array.isArray(D.material)?D.material.forEach(H=>H.needsUpdate=!0):D.material.needsUpdate=!0)});for(let D=0,H=E.length;D<H;D++){const q=E[D],k=q.shadow;if(k===void 0){Lt("WebGLShadowMap:",q,"has no shadow.");continue}if(k.autoUpdate===!1&&k.needsUpdate===!1)continue;s.copy(k.mapSize);const tt=k.getFrameExtents();s.multiply(tt),r.copy(k.mapSize),(s.x>d||s.y>d)&&(s.x>d&&(r.x=Math.floor(d/tt.x),s.x=r.x*tt.x,k.mapSize.x=r.x),s.y>d&&(r.y=Math.floor(d/tt.y),s.y=r.y*tt.y,k.mapSize.y=r.y));const W=i.state.buffers.depth.getReversed();if(k.camera._reversedDepth=W,k.map===null||V===!0){if(k.map!==null&&(k.map.depthTexture!==null&&(k.map.depthTexture.dispose(),k.map.depthTexture=null),k.map.dispose()),this.type===er){if(q.isPointLight){Lt("WebGLShadowMap: VSM shadow maps are not supported for PointLights. Use PCF or BasicShadowMap instead.");continue}k.map=new Sn(s.x,s.y,{format:Zi,type:jn,minFilter:en,magFilter:en,generateMipmaps:!1}),k.map.texture.name=q.name+".shadowMap",k.map.depthTexture=new ks(s.x,s.y,Pn),k.map.depthTexture.name=q.name+".shadowMapDepth",k.map.depthTexture.format=Ni,k.map.depthTexture.compareFunction=null,k.map.depthTexture.minFilter=Ge,k.map.depthTexture.magFilter=Ge}else q.isPointLight?(k.map=new vc(s.x),k.map.depthTexture=new Eu(s.x,Jn)):(k.map=new Sn(s.x,s.y),k.map.depthTexture=new ks(s.x,s.y,Jn)),k.map.depthTexture.name=q.name+".shadowMap",k.map.depthTexture.format=Ni,this.type===va?(k.map.depthTexture.compareFunction=W?du:cu,k.map.depthTexture.minFilter=en,k.map.depthTexture.magFilter=en):(k.map.depthTexture.compareFunction=null,k.map.depthTexture.minFilter=Ge,k.map.depthTexture.magFilter=Ge);k.camera.updateProjectionMatrix()}k.map.isWebGLCubeRenderTarget!==!0&&(k.map.width!==s.x||k.map.height!==s.y)&&k.map.setSize(s.x,s.y);const j=k.map.isWebGLCubeRenderTarget?6:k.getViewportCount();q.isPointLight!==!0&&k.updateMatrices(q,w);const Q=(k.camera.layers.mask&4294967294)!==0?k.camera.layers:w.layers;for(let wt=0;wt<j;wt++){const Bt=k.getCamera(wt);if(q.isPointLight){const K=k.camera,mt=k.matrix,bt=q.distance||K.far;bt!==K.far&&(K.far=bt,K.updateProjectionMatrix()),Qs.setFromMatrixPosition(q.matrixWorld),K.position.copy(Qs),No.copy(K.position),No.add(Nx[wt]),K.up.copy(Ux[wt]),K.lookAt(No),K.updateMatrixWorld(),mt.makeTranslation(-Qs.x,-Qs.y,-Qs.z),eh.multiplyMatrices(K.projectionMatrix,K.matrixWorldInverse),k._frustum.setFromProjectionMatrix(eh,K.coordinateSystem,K.reversedDepth)}if(k.map.isWebGLCubeRenderTarget)i.setRenderTarget(k.map,wt),i.clear();else{wt===0&&(i.setRenderTarget(k.map),i.clear());const K=k.getViewport(wt);a.set(r.x*K.x,r.y*K.y,r.x*K.z,r.y*K.w),F.viewport(a)}n=k.getFrustum(wt),y(v,w,Bt,q,Q,this.type)}k.isPointLightShadow!==!0&&this.type===er&&_(k,w),k.needsUpdate=!1}p=this.type,m.needsUpdate=!1,i.setRenderTarget(N,R,L)};function _(E,v){const w=t.update(x);u.defines.VSM_SAMPLES!==E.blurSamples&&(u.defines.VSM_SAMPLES=E.blurSamples,f.defines.VSM_SAMPLES=E.blurSamples,u.needsUpdate=!0,f.needsUpdate=!0),E.mapPass===null?E.mapPass=new Sn(s.x,s.y,{format:Zi,type:jn}):(E.mapPass.width!==E.map.width||E.mapPass.height!==E.map.height)&&E.mapPass.setSize(E.map.width,E.map.height),u.uniforms.shadow_pass.value=E.map.depthTexture,u.uniforms.resolution.value.set(E.map.width,E.map.height),u.uniforms.radius.value=E.radius,i.setRenderTarget(E.mapPass),i.clear(),i.renderBufferDirect(v,null,w,u,x,null),f.uniforms.shadow_pass.value=E.mapPass.texture,f.uniforms.resolution.value.set(E.map.width,E.map.height),f.uniforms.radius.value=E.radius,i.setRenderTarget(E.map),i.clear(),i.renderBufferDirect(v,null,w,f,x,null)}function S(E,v,w,N){let R=null;const L=w.isPointLight===!0?E.customDistanceMaterial:E.customDepthMaterial;if(L!==void 0)R=L;else if(R=w.isPointLight===!0?l:o,i.localClippingEnabled&&v.clipShadows===!0&&Array.isArray(v.clippingPlanes)&&v.clippingPlanes.length!==0||v.displacementMap&&v.displacementScale!==0||v.alphaMap&&v.alphaTest>0||v.map&&v.alphaTest>0||v.alphaToCoverage===!0){const F=R.uuid,V=v.uuid;let D=c[F];D===void 0&&(D={},c[F]=D);let H=D[V];H===void 0&&(H=R.clone(),D[V]=H,v.addEventListener("dispose",A)),R=H}if(R.visible=v.visible,R.wireframe=v.wireframe,N===er?R.side=v.shadowSide!==null?v.shadowSide:v.side:R.side=v.shadowSide!==null?v.shadowSide:h[v.side],R.alphaMap=v.alphaMap,R.alphaTest=v.alphaToCoverage===!0?.5:v.alphaTest,R.map=v.map,R.clipShadows=v.clipShadows,R.clippingPlanes=v.clippingPlanes,R.clipIntersection=v.clipIntersection,R.displacementMap=v.displacementMap,R.displacementScale=v.displacementScale,R.displacementBias=v.displacementBias,R.wireframeLinewidth=v.wireframeLinewidth,R.linewidth=v.linewidth,w.isPointLight===!0&&R.isMeshDistanceMaterial===!0){const F=i.properties.get(R);F.light=w}return R}function y(E,v,w,N,R,L){if(E.visible===!1)return;if(E.layers.test(R)&&(E.isMesh||E.isLine||E.isPoints)&&(E.castShadow||E.receiveShadow&&L===er)&&(!E.frustumCulled||E.intersectsFrustum(n))){E.modelViewMatrix.multiplyMatrices(w.matrixWorldInverse,E.matrixWorld);const D=t.update(E),H=E.material;if(Array.isArray(H)){const q=D.groups;for(let k=0,tt=q.length;k<tt;k++){const W=q[k],j=H[W.materialIndex];if(j&&j.visible){const Q=S(E,j,N,L);E.onBeforeShadow(i,E,v,w,D,Q,W),i.renderBufferDirect(w,null,D,Q,E,W),E.onAfterShadow(i,E,v,w,D,Q,W)}}}else if(H.visible){const q=S(E,H,N,L);E.onBeforeShadow(i,E,v,w,D,q,null),i.renderBufferDirect(w,null,D,q,E,null),E.onAfterShadow(i,E,v,w,D,q,null)}}const V=E.children;for(let D=0,H=V.length;D<H;D++)y(V[D],v,w,N,R,L)}function A(E){E.target.removeEventListener("dispose",A);for(const w in c){const N=c[w],R=E.target.uuid;R in N&&(N[R].dispose(),delete N[R])}}}function Ox(i,t){function e(){let C=!1;const Z=new _e;let $=null;const ot=new _e(0,0,0,0);return{setMask:function(it){$!==it&&!C&&(i.colorMask(it,it,it,it),$=it)},setLocked:function(it){C=it},setClear:function(it,rt,At,Gt,nt){nt===!0&&(it*=Gt,rt*=Gt,At*=Gt),Z.set(it,rt,At,Gt),ot.equals(Z)===!1&&(i.clearColor(it,rt,At,Gt),ot.copy(Z))},reset:function(){C=!1,$=null,ot.set(-1,0,0,0)}}}function n(){let C=!1,Z=!1,$=null,ot=null,it=null;return{setReversed:function(rt){if(Z!==rt){const At=t.get("EXT_clip_control");rt?At.clipControlEXT(At.LOWER_LEFT_EXT,At.ZERO_TO_ONE_EXT):At.clipControlEXT(At.LOWER_LEFT_EXT,At.NEGATIVE_ONE_TO_ONE_EXT),Z=rt;const Gt=it;it=null,this.setClear(Gt)}},getReversed:function(){return Z},setTest:function(rt){rt?vt(i.DEPTH_TEST):zt(i.DEPTH_TEST)},setMask:function(rt){$!==rt&&!C&&(i.depthMask(rt),$=rt)},setFunc:function(rt){if(Z&&(rt=ep[rt]),ot!==rt){switch(rt){case $o:i.depthFunc(i.NEVER);break;case Wo:i.depthFunc(i.ALWAYS);break;case Xo:i.depthFunc(i.LESS);break;case mr:i.depthFunc(i.LEQUAL);break;case qo:i.depthFunc(i.EQUAL);break;case Yo:i.depthFunc(i.GEQUAL);break;case Ko:i.depthFunc(i.GREATER);break;case Zo:i.depthFunc(i.NOTEQUAL);break;default:i.depthFunc(i.LEQUAL)}ot=rt}},setLocked:function(rt){C=rt},setClear:function(rt){it!==rt&&(it=rt,Z&&(rt=1-rt),i.clearDepth(rt))},reset:function(){C=!1,$=null,ot=null,it=null,Z=!1}}}function s(){let C=!1,Z=null,$=null,ot=null,it=null,rt=null,At=null,Gt=null,nt=null;return{setTest:function(Tt){C||(Tt?vt(i.STENCIL_TEST):zt(i.STENCIL_TEST))},setMask:function(Tt){Z!==Tt&&!C&&(i.stencilMask(Tt),Z=Tt)},setFunc:function(Tt,Ht,ft){($!==Tt||ot!==Ht||it!==ft)&&(i.stencilFunc(Tt,Ht,ft),$=Tt,ot=Ht,it=ft)},setOp:function(Tt,Ht,ft){(rt!==Tt||At!==Ht||Gt!==ft)&&(i.stencilOp(Tt,Ht,ft),rt=Tt,At=Ht,Gt=ft)},setLocked:function(Tt){C=Tt},setClear:function(Tt){nt!==Tt&&(i.clearStencil(Tt),nt=Tt)},reset:function(){C=!1,Z=null,$=null,ot=null,it=null,rt=null,At=null,Gt=null,nt=null}}}const r=new e,a=new n,o=new s;let l={};const c=new WeakMap;let d={},h={},u={},f=new WeakMap,g=[],x=null,m=!1,p=null,_=null,S=null,y=null,A=null,E=null,v=null,w=new Nt(0,0,0),N=0,R=!1,L=null,F=null,V=null,D=null,H=null;const q=i.getParameter(i.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let k=!1,tt=0;const W=i.getParameter(i.VERSION);W.indexOf("WebGL")!==-1?(tt=parseFloat(/^WebGL (\d)/.exec(W)[1]),k=tt>=1):W.indexOf("OpenGL ES")!==-1&&(tt=parseFloat(/^OpenGL ES (\d)/.exec(W)[1]),k=tt>=2);let j=null,Q={};const wt=i.getParameter(i.SCISSOR_BOX),Bt=i.getParameter(i.VIEWPORT),K=new _e().fromArray(wt),mt=new _e().fromArray(Bt);function bt(C,Z,$,ot){const it=new Uint8Array(4),rt=i.createTexture();i.bindTexture(C,rt),i.texParameteri(C,i.TEXTURE_MIN_FILTER,i.NEAREST),i.texParameteri(C,i.TEXTURE_MAG_FILTER,i.NEAREST);for(let At=0;At<$;At++)C===i.TEXTURE_3D||C===i.TEXTURE_2D_ARRAY?i.texImage3D(Z,0,i.RGBA,1,1,ot,0,i.RGBA,i.UNSIGNED_BYTE,it):i.texImage2D(Z+At,0,i.RGBA,1,1,0,i.RGBA,i.UNSIGNED_BYTE,it);return rt}const Rt={};Rt[i.TEXTURE_2D]=bt(i.TEXTURE_2D,i.TEXTURE_2D,1),Rt[i.TEXTURE_CUBE_MAP]=bt(i.TEXTURE_CUBE_MAP,i.TEXTURE_CUBE_MAP_POSITIVE_X,6),Rt[i.TEXTURE_2D_ARRAY]=bt(i.TEXTURE_2D_ARRAY,i.TEXTURE_2D_ARRAY,1,1),Rt[i.TEXTURE_3D]=bt(i.TEXTURE_3D,i.TEXTURE_3D,1,1),r.setClear(0,0,0,1),a.setClear(1),o.setClear(0),vt(i.DEPTH_TEST),a.setFunc(mr),rn(!1),ve(qc),vt(i.CULL_FACE),ke(Cs);function vt(C){d[C]!==!0&&(i.enable(C),d[C]=!0)}function zt(C){d[C]!==!1&&(i.disable(C),d[C]=!1)}function Se(C,Z){return u[C]!==Z?(i.bindFramebuffer(C,Z),u[C]=Z,C===i.DRAW_FRAMEBUFFER&&(u[i.FRAMEBUFFER]=Z),C===i.FRAMEBUFFER&&(u[i.DRAW_FRAMEBUFFER]=Z),!0):!1}function Pt(C,Z){let $=g,ot=!1;if(C){$=f.get(Z),$===void 0&&($=[],f.set(Z,$));const it=C.textures;if($.length!==it.length||$[0]!==i.COLOR_ATTACHMENT0){for(let rt=0,At=it.length;rt<At;rt++)$[rt]=i.COLOR_ATTACHMENT0+rt;$.length=it.length,ot=!0}}else $[0]!==i.BACK&&($[0]=i.BACK,ot=!0);ot&&i.drawBuffers($)}function se(C){return x!==C?(i.useProgram(C),x=C,!0):!1}const le={[As]:i.FUNC_ADD,[wf]:i.FUNC_SUBTRACT,[Ef]:i.FUNC_REVERSE_SUBTRACT};le[Af]=i.MIN,le[Tf]=i.MAX;const Xt={[Rf]:i.ZERO,[Cf]:i.ONE,[Pf]:i.SRC_COLOR,[qh]:i.SRC_ALPHA,[Ff]:i.SRC_ALPHA_SATURATE,[Nf]:i.DST_COLOR,[Df]:i.DST_ALPHA,[Lf]:i.ONE_MINUS_SRC_COLOR,[Yh]:i.ONE_MINUS_SRC_ALPHA,[Uf]:i.ONE_MINUS_DST_COLOR,[If]:i.ONE_MINUS_DST_ALPHA,[Of]:i.CONSTANT_COLOR,[Bf]:i.ONE_MINUS_CONSTANT_COLOR,[kf]:i.CONSTANT_ALPHA,[zf]:i.ONE_MINUS_CONSTANT_ALPHA};function ke(C,Z,$,ot,it,rt,At,Gt,nt,Tt){if(C===Cs){m===!0&&(zt(i.BLEND),m=!1);return}if(m===!1&&(vt(i.BLEND),m=!0),C!==Sf){if(C!==p||Tt!==R){if((_!==As||A!==As)&&(i.blendEquation(i.FUNC_ADD),_=As,A=As),Tt)switch(C){case cr:i.blendFuncSeparate(i.ONE,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case pr:i.blendFunc(i.ONE,i.ONE);break;case Yc:i.blendFuncSeparate(i.ZERO,i.ONE_MINUS_SRC_COLOR,i.ZERO,i.ONE);break;case Kc:i.blendFuncSeparate(i.DST_COLOR,i.ONE_MINUS_SRC_ALPHA,i.ZERO,i.ONE);break;default:ee("WebGLState: Invalid blending: ",C);break}else switch(C){case cr:i.blendFuncSeparate(i.SRC_ALPHA,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case pr:i.blendFuncSeparate(i.SRC_ALPHA,i.ONE,i.ONE,i.ONE);break;case Yc:ee("WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true");break;case Kc:ee("WebGLState: MultiplyBlending requires material.premultipliedAlpha = true");break;default:ee("WebGLState: Invalid blending: ",C);break}S=null,y=null,E=null,v=null,w.set(0,0,0),N=0,p=C,R=Tt}return}it=it||Z,rt=rt||$,At=At||ot,(Z!==_||it!==A)&&(i.blendEquationSeparate(le[Z],le[it]),_=Z,A=it),($!==S||ot!==y||rt!==E||At!==v)&&(i.blendFuncSeparate(Xt[$],Xt[ot],Xt[rt],Xt[At]),S=$,y=ot,E=rt,v=At),(Gt.equals(w)===!1||nt!==N)&&(i.blendColor(Gt.r,Gt.g,Gt.b,nt),w.copy(Gt),N=nt),p=C,R=!1}function Te(C,Z){C.side===Cn?zt(i.CULL_FACE):vt(i.CULL_FACE);let $=C.side===qe;Z&&($=!$),rn($),C.blending===cr&&C.transparent===!1?ke(Cs):ke(C.blending,C.blendEquation,C.blendSrc,C.blendDst,C.blendEquationAlpha,C.blendSrcAlpha,C.blendDstAlpha,C.blendColor,C.blendAlpha,C.premultipliedAlpha),a.setFunc(C.depthFunc),a.setTest(C.depthTest),a.setMask(C.depthWrite),r.setMask(C.colorWrite);const ot=C.stencilWrite;o.setTest(ot),ot&&(o.setMask(C.stencilWriteMask),o.setFunc(C.stencilFunc,C.stencilRef,C.stencilFuncMask),o.setOp(C.stencilFail,C.stencilZFail,C.stencilZPass)),De(C.polygonOffset,C.polygonOffsetFactor,C.polygonOffsetUnits),C.alphaToCoverage===!0?vt(i.SAMPLE_ALPHA_TO_COVERAGE):zt(i.SAMPLE_ALPHA_TO_COVERAGE)}function rn(C){L!==C&&(C?i.frontFace(i.CW):i.frontFace(i.CCW),L=C)}function ve(C){C!==bf?(vt(i.CULL_FACE),C!==F&&(C===qc?i.cullFace(i.BACK):C===Mf?i.cullFace(i.FRONT):i.cullFace(i.FRONT_AND_BACK))):zt(i.CULL_FACE),F=C}function Hn(C){C!==V&&(k&&i.lineWidth(C),V=C)}function De(C,Z,$){C?(vt(i.POLYGON_OFFSET_FILL),(D!==Z||H!==$)&&(D=Z,H=$,a.getReversed()&&(Z=-Z,$=-$),i.polygonOffset(Z,$))):zt(i.POLYGON_OFFSET_FILL)}function gn(C){C?vt(i.SCISSOR_TEST):zt(i.SCISSOR_TEST)}function vn(C){C===void 0&&(C=i.TEXTURE0+q-1),j!==C&&(i.activeTexture(C),j=C)}function xn(C,Z,$){$===void 0&&(j===null?$=i.TEXTURE0+q-1:$=j);let ot=Q[$];ot===void 0&&(ot={type:void 0,texture:void 0},Q[$]=ot),(ot.type!==C||ot.texture!==Z)&&(j!==$&&(i.activeTexture($),j=$),i.bindTexture(C,Z||Rt[C]),ot.type=C,ot.texture=Z)}function U(){const C=Q[j];C!==void 0&&C.type!==void 0&&(i.bindTexture(C.type,null),C.type=void 0,C.texture=void 0)}function _n(){try{i.compressedTexImage2D(...arguments)}catch(C){ee("WebGLState:",C)}}function fe(){try{i.compressedTexImage3D(...arguments)}catch(C){ee("WebGLState:",C)}}function pe(){try{i.texSubImage2D(...arguments)}catch(C){ee("WebGLState:",C)}}function ut(){try{i.texSubImage3D(...arguments)}catch(C){ee("WebGLState:",C)}}function Re(){try{i.compressedTexSubImage2D(...arguments)}catch(C){ee("WebGLState:",C)}}function Ct(){try{i.compressedTexSubImage3D(...arguments)}catch(C){ee("WebGLState:",C)}}function Ft(){try{i.texStorage2D(...arguments)}catch(C){ee("WebGLState:",C)}}function T(){try{i.texStorage3D(...arguments)}catch(C){ee("WebGLState:",C)}}function b(){try{i.texImage2D(...arguments)}catch(C){ee("WebGLState:",C)}}function B(){try{i.texImage3D(...arguments)}catch(C){ee("WebGLState:",C)}}function et(C){return h[C]!==void 0?h[C]:i.getParameter(C)}function J(C,Z){h[C]!==Z&&(i.pixelStorei(C,Z),h[C]=Z)}function st(C){K.equals(C)===!1&&(i.scissor(C.x,C.y,C.z,C.w),K.copy(C))}function dt(C){mt.equals(C)===!1&&(i.viewport(C.x,C.y,C.z,C.w),mt.copy(C))}function X(C,Z){let $=c.get(Z);$===void 0&&($=new WeakMap,c.set(Z,$));let ot=$.get(C);ot===void 0&&(ot=i.getUniformBlockIndex(Z,C.name),i.uniformBlockBinding(Z,ot,ot),$.set(C,ot))}function Y(C,Z,$){const it=c.get(Z).get(C);l[it]!==$&&(i.bindBufferBase(i.UNIFORM_BUFFER,it,$),l[it]=$)}function at(){i.disable(i.BLEND),i.disable(i.CULL_FACE),i.disable(i.DEPTH_TEST),i.disable(i.POLYGON_OFFSET_FILL),i.disable(i.SCISSOR_TEST),i.disable(i.STENCIL_TEST),i.disable(i.SAMPLE_ALPHA_TO_COVERAGE),i.blendEquation(i.FUNC_ADD),i.blendFunc(i.ONE,i.ZERO),i.blendFuncSeparate(i.ONE,i.ZERO,i.ONE,i.ZERO),i.blendColor(0,0,0,0),i.colorMask(!0,!0,!0,!0),i.clearColor(0,0,0,0),i.depthMask(!0),i.depthFunc(i.LESS),a.setReversed(!1),i.clearDepth(1),i.stencilMask(4294967295),i.stencilFunc(i.ALWAYS,0,4294967295),i.stencilOp(i.KEEP,i.KEEP,i.KEEP),i.clearStencil(0),i.cullFace(i.BACK),i.frontFace(i.CCW),i.polygonOffset(0,0),i.activeTexture(i.TEXTURE0),i.bindFramebuffer(i.FRAMEBUFFER,null),i.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),i.bindFramebuffer(i.READ_FRAMEBUFFER,null),i.useProgram(null),i.lineWidth(1),i.scissor(0,0,i.canvas.width,i.canvas.height),i.viewport(0,0,i.canvas.width,i.canvas.height),i.pixelStorei(i.PACK_ALIGNMENT,4),i.pixelStorei(i.UNPACK_ALIGNMENT,4),i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,!1),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,!1),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,i.BROWSER_DEFAULT_WEBGL),i.pixelStorei(i.PACK_ROW_LENGTH,0),i.pixelStorei(i.PACK_SKIP_PIXELS,0),i.pixelStorei(i.PACK_SKIP_ROWS,0),i.pixelStorei(i.UNPACK_ROW_LENGTH,0),i.pixelStorei(i.UNPACK_IMAGE_HEIGHT,0),i.pixelStorei(i.UNPACK_SKIP_PIXELS,0),i.pixelStorei(i.UNPACK_SKIP_ROWS,0),i.pixelStorei(i.UNPACK_SKIP_IMAGES,0),d={},h={},j=null,Q={},u={},l={},f=new WeakMap,g=[],x=null,m=!1,p=null,_=null,S=null,y=null,A=null,E=null,v=null,w=new Nt(0,0,0),N=0,R=!1,L=null,F=null,V=null,D=null,H=null,K.set(0,0,i.canvas.width,i.canvas.height),mt.set(0,0,i.canvas.width,i.canvas.height),r.reset(),a.reset(),o.reset()}return{buffers:{color:r,depth:a,stencil:o},enable:vt,disable:zt,bindFramebuffer:Se,drawBuffers:Pt,useProgram:se,setBlending:ke,setMaterial:Te,setFlipSided:rn,setCullFace:ve,setLineWidth:Hn,setPolygonOffset:De,setScissorTest:gn,activeTexture:vn,bindTexture:xn,unbindTexture:U,compressedTexImage2D:_n,compressedTexImage3D:fe,texImage2D:b,texImage3D:B,pixelStorei:J,getParameter:et,updateUBOMapping:X,uniformBlockBinding:Y,texStorage2D:Ft,texStorage3D:T,texSubImage2D:pe,texSubImage3D:ut,compressedTexSubImage2D:Re,compressedTexSubImage3D:Ct,scissor:st,viewport:dt,reset:at}}function Bx(i,t,e,n,s,r,a){const o=t.has("WEBGL_multisampled_render_to_texture")?t.get("WEBGL_multisampled_render_to_texture"):null,l=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),c=new Dt,d=new WeakMap,h=new Set;let u;const f=new WeakMap,g=new Set,x=new FinalizationRegistry(T=>g.delete(T));let m=!1;try{m=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function p(T,b){return m?new OffscreenCanvas(T,b):Ia("canvas")}function _(T,b,B){let et=1;const J=Ft(T);if((J.width>B||J.height>B)&&(et=B/Math.max(J.width,J.height)),et<1)if(typeof HTMLImageElement<"u"&&T instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&T instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&T instanceof ImageBitmap||typeof VideoFrame<"u"&&T instanceof VideoFrame){const st=Math.floor(et*J.width),dt=Math.floor(et*J.height);u===void 0&&(u=p(st,dt));const X=b?p(st,dt):u;return X.width=st,X.height=dt,X.getContext("2d").drawImage(T,0,0,st,dt),Lt("WebGLRenderer: Texture has been resized from ("+J.width+"x"+J.height+") to ("+st+"x"+dt+")."),X}else return"data"in T&&Lt("WebGLRenderer: Image in DataTexture is too big ("+J.width+"x"+J.height+")."),T;return T}function S(T){return T.generateMipmaps}function y(T){i.generateMipmap(T)}function A(T){return T.isWebGLCubeRenderTarget?i.TEXTURE_CUBE_MAP:T.isWebGL3DRenderTarget?i.TEXTURE_3D:T.isWebGLArrayRenderTarget||T.isCompressedArrayTexture?i.TEXTURE_2D_ARRAY:i.TEXTURE_2D}function E(T,b,B,et,J,st=!1){if(T!==null){if(i[T]!==void 0)return i[T];Lt("WebGLRenderer: Attempt to use non-existing WebGL internal format '"+T+"'")}let dt;et&&(dt=t.get("EXT_texture_norm16"),dt||Lt("WebGLRenderer: Unable to use normalized textures without EXT_texture_norm16 extension"));let X=b;if(b===i.RED&&(B===i.FLOAT&&(X=i.R32F),B===i.HALF_FLOAT&&(X=i.R16F),B===i.UNSIGNED_BYTE&&(X=i.R8),B===i.UNSIGNED_SHORT&&dt&&(X=dt.R16_EXT),B===i.SHORT&&dt&&(X=dt.R16_SNORM_EXT)),b===i.RED_INTEGER&&(B===i.UNSIGNED_BYTE&&(X=i.R8UI),B===i.UNSIGNED_SHORT&&(X=i.R16UI),B===i.UNSIGNED_INT&&(X=i.R32UI),B===i.BYTE&&(X=i.R8I),B===i.SHORT&&(X=i.R16I),B===i.INT&&(X=i.R32I)),b===i.RG&&(B===i.FLOAT&&(X=i.RG32F),B===i.HALF_FLOAT&&(X=i.RG16F),B===i.UNSIGNED_BYTE&&(X=i.RG8),B===i.UNSIGNED_SHORT&&dt&&(X=dt.RG16_EXT),B===i.SHORT&&dt&&(X=dt.RG16_SNORM_EXT)),b===i.RG_INTEGER&&(B===i.UNSIGNED_BYTE&&(X=i.RG8UI),B===i.UNSIGNED_SHORT&&(X=i.RG16UI),B===i.UNSIGNED_INT&&(X=i.RG32UI),B===i.BYTE&&(X=i.RG8I),B===i.SHORT&&(X=i.RG16I),B===i.INT&&(X=i.RG32I)),b===i.RGB_INTEGER&&(B===i.UNSIGNED_BYTE&&(X=i.RGB8UI),B===i.UNSIGNED_SHORT&&(X=i.RGB16UI),B===i.UNSIGNED_INT&&(X=i.RGB32UI),B===i.BYTE&&(X=i.RGB8I),B===i.SHORT&&(X=i.RGB16I),B===i.INT&&(X=i.RGB32I)),b===i.RGBA_INTEGER&&(B===i.UNSIGNED_BYTE&&(X=i.RGBA8UI),B===i.UNSIGNED_SHORT&&(X=i.RGBA16UI),B===i.UNSIGNED_INT&&(X=i.RGBA32UI),B===i.BYTE&&(X=i.RGBA8I),B===i.SHORT&&(X=i.RGBA16I),B===i.INT&&(X=i.RGBA32I)),b===i.RGB&&(B===i.UNSIGNED_SHORT&&dt&&(X=dt.RGB16_EXT),B===i.SHORT&&dt&&(X=dt.RGB16_SNORM_EXT),B===i.UNSIGNED_INT_5_9_9_9_REV&&(X=i.RGB9_E5),B===i.UNSIGNED_INT_10F_11F_11F_REV&&(X=i.R11F_G11F_B10F)),b===i.RGBA){const Y=st?Da:Jt.getTransfer(J);B===i.FLOAT&&(X=i.RGBA32F),B===i.HALF_FLOAT&&(X=i.RGBA16F),B===i.UNSIGNED_BYTE&&(X=Y===ae?i.SRGB8_ALPHA8:i.RGBA8),B===i.UNSIGNED_SHORT&&dt&&(X=dt.RGBA16_EXT),B===i.SHORT&&dt&&(X=dt.RGBA16_SNORM_EXT),B===i.UNSIGNED_SHORT_4_4_4_4&&(X=i.RGBA4),B===i.UNSIGNED_SHORT_5_5_5_1&&(X=i.RGB5_A1)}return(X===i.R16F||X===i.R32F||X===i.RG16F||X===i.RG32F||X===i.RGBA16F||X===i.RGBA32F)&&t.get("EXT_color_buffer_float"),X}function v(T,b){let B;return T?b===null||b===Jn||b===Bs?B=i.DEPTH24_STENCIL8:b===Pn?B=i.DEPTH32F_STENCIL8:b===vr&&(B=i.DEPTH24_STENCIL8,Lt("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):b===null||b===Jn||b===Bs?B=i.DEPTH_COMPONENT24:b===Pn?B=i.DEPTH_COMPONENT32F:b===vr&&(B=i.DEPTH_COMPONENT16),B}function w(T,b){return S(T)===!0||T.isFramebufferTexture&&T.minFilter!==Ge&&T.minFilter!==en?Math.log2(Math.max(b.width,b.height))+1:T.mipmaps.length>0?T.mipmaps.length:T.isCompressedTexture&&Array.isArray(T.image)?b.mipmaps.length:1}function N(T){const b=new WeakRef(T);n.get(T).__ref=b,g.add(b),x.register(T,b,b)}function R(T){const b=n.get(T).__ref;b!==void 0&&(g.delete(b),x.unregister(b))}function L(T){V(T.target)}function F(T){D(T.target)}function V(T){T.removeEventListener("dispose",L),R(T),q(T),T.isVideoTexture&&d.delete(T),T.isHTMLTexture&&h.delete(T)}function D(T){T.removeEventListener("dispose",F),R(T),tt(T)}function H(){for(const T of g){const b=T.deref();b!==void 0&&(b.isRenderTarget===!0?D(b):V(b))}g.clear(),h.clear()}function q(T){const b=n.get(T);if(b.__webglInit===void 0)return;const B=T.source,et=f.get(B);if(et){const J=et[b.__cacheKey];J.usedTimes--,J.usedTimes===0&&k(T),Object.keys(et).length===0&&f.delete(B)}n.remove(T)}function k(T){const b=n.get(T);i.deleteTexture(b.__webglTexture);const B=T.source,et=f.get(B);delete et[b.__cacheKey],a.memory.textures--}function tt(T){const b=n.get(T);b.__depthDisposeCallback&&b.__depthDisposeCallback();const B=T.depthTexture;if(B&&B.renderTarget===T&&V(B),T.isWebGLCubeRenderTarget)for(let J=0;J<6;J++){if(Array.isArray(b.__webglFramebuffer[J]))for(let st=0;st<b.__webglFramebuffer[J].length;st++)i.deleteFramebuffer(b.__webglFramebuffer[J][st]);else i.deleteFramebuffer(b.__webglFramebuffer[J]);b.__webglDepthbuffer&&i.deleteRenderbuffer(b.__webglDepthbuffer[J])}else{if(Array.isArray(b.__webglFramebuffer))for(let J=0;J<b.__webglFramebuffer.length;J++)i.deleteFramebuffer(b.__webglFramebuffer[J]);else i.deleteFramebuffer(b.__webglFramebuffer);if(b.__webglDepthbuffer&&i.deleteRenderbuffer(b.__webglDepthbuffer),b.__webglMultisampledFramebuffer&&i.deleteFramebuffer(b.__webglMultisampledFramebuffer),b.__webglColorRenderbuffer)for(let J=0;J<b.__webglColorRenderbuffer.length;J++)b.__webglColorRenderbuffer[J]&&i.deleteRenderbuffer(b.__webglColorRenderbuffer[J]);b.__webglDepthRenderbuffer&&i.deleteRenderbuffer(b.__webglDepthRenderbuffer)}const et=T.textures;for(let J=0,st=et.length;J<st;J++){const dt=n.get(et[J]);dt.__webglTexture&&(i.deleteTexture(dt.__webglTexture),a.memory.textures--),n.remove(et[J])}n.remove(T)}let W=0;function j(){W=0}function Q(){return W}function wt(T){W=T}function Bt(){const T=W;return T>=s.maxTextures&&Lt("WebGLTextures: Trying to use "+(T+1)+" texture units while this GPU supports only "+s.maxTextures),W+=1,T}function K(T){const b=[];return b.push(T.wrapS),b.push(T.wrapT),b.push(T.wrapR||0),b.push(T.magFilter),b.push(T.minFilter),b.push(T.anisotropy),b.push(T.internalFormat),b.push(T.format),b.push(T.type),b.push(T.generateMipmaps),b.push(T.mipmapsAutoUpdate),b.push(T.premultiplyAlpha),b.push(T.flipY),b.push(T.unpackAlignment),b.push(T.colorSpace),b.join()}function mt(T,b){const B=n.get(T);if(T.isVideoTexture&&Re(T),T.isRenderTargetTexture===!1&&T.isExternalTexture!==!0&&T.version>0&&B.__version!==T.version){const et=T.image;if(et===null)Lt("WebGLRenderer: Texture marked for update but no image data found.");else if(et.complete===!1)Lt("WebGLRenderer: Texture marked for update but image is incomplete");else{Te(B,T,b);return}}else T.isExternalTexture&&(B.__webglTexture=T.sourceTexture?T.sourceTexture:null);e.bindTexture(i.TEXTURE_2D,B.__webglTexture,i.TEXTURE0+b)}function bt(T,b){const B=n.get(T);if(T.isRenderTargetTexture===!1&&T.version>0&&B.__version!==T.version){Te(B,T,b);return}else T.isExternalTexture&&(B.__webglTexture=T.sourceTexture?T.sourceTexture:null);e.bindTexture(i.TEXTURE_2D_ARRAY,B.__webglTexture,i.TEXTURE0+b)}function Rt(T,b){const B=n.get(T);if(T.isRenderTargetTexture===!1&&T.version>0&&B.__version!==T.version){Te(B,T,b);return}e.bindTexture(i.TEXTURE_3D,B.__webglTexture,i.TEXTURE0+b)}function vt(T,b){const B=n.get(T);if(T.version>0&&B.__version!==T.version){rn(B,T,b);return}e.bindTexture(i.TEXTURE_CUBE_MAP,B.__webglTexture,i.TEXTURE0+b)}const zt={[Ra]:i.REPEAT,[hi]:i.CLAMP_TO_EDGE,[Jo]:i.MIRRORED_REPEAT},Se={[Ge]:i.NEAREST,[Vf]:i.NEAREST_MIPMAP_NEAREST,[Cr]:i.NEAREST_MIPMAP_LINEAR,[en]:i.LINEAR,[ao]:i.LINEAR_MIPMAP_NEAREST,[ui]:i.LINEAR_MIPMAP_LINEAR},Pt={[qf]:i.NEVER,[hu]:i.ALWAYS,[Yf]:i.LESS,[cu]:i.LEQUAL,[Kf]:i.EQUAL,[du]:i.GEQUAL,[Zf]:i.GREATER,[Jf]:i.NOTEQUAL};function se(T,b){if(b.type===Pn&&t.has("OES_texture_float_linear")===!1&&(b.magFilter===en||b.magFilter===ao||b.magFilter===Cr||b.magFilter===ui||b.minFilter===en||b.minFilter===ao||b.minFilter===Cr||b.minFilter===ui)&&Lt("WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),i.texParameteri(T,i.TEXTURE_WRAP_S,zt[b.wrapS]),i.texParameteri(T,i.TEXTURE_WRAP_T,zt[b.wrapT]),(T===i.TEXTURE_3D||T===i.TEXTURE_2D_ARRAY)&&i.texParameteri(T,i.TEXTURE_WRAP_R,zt[b.wrapR]),i.texParameteri(T,i.TEXTURE_MAG_FILTER,Se[b.magFilter]),i.texParameteri(T,i.TEXTURE_MIN_FILTER,Se[b.minFilter]),b.compareFunction&&(i.texParameteri(T,i.TEXTURE_COMPARE_MODE,i.COMPARE_REF_TO_TEXTURE),i.texParameteri(T,i.TEXTURE_COMPARE_FUNC,Pt[b.compareFunction])),t.has("EXT_texture_filter_anisotropic")===!0){if(b.magFilter===Ge||b.minFilter!==Cr&&b.minFilter!==ui||b.type===Pn&&t.has("OES_texture_float_linear")===!1)return;if(b.anisotropy>1||n.get(b).__currentAnisotropy){const B=t.get("EXT_texture_filter_anisotropic");i.texParameterf(T,B.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(b.anisotropy,s.getMaxAnisotropy())),n.get(b).__currentAnisotropy=b.anisotropy}}}function le(T,b){let B=!1;T.__webglInit===void 0&&(T.__webglInit=!0,b.addEventListener("dispose",L),N(b));const et=b.source;let J=f.get(et);J===void 0&&(J={},f.set(et,J));const st=K(b);if(st!==T.__cacheKey){J[st]===void 0&&(J[st]={texture:i.createTexture(),usedTimes:0},a.memory.textures++,B=!0),J[st].usedTimes++;const dt=J[T.__cacheKey];dt!==void 0&&(J[T.__cacheKey].usedTimes--,dt.usedTimes===0&&k(b)),T.__cacheKey=st,T.__webglTexture=J[st].texture}return B}function Xt(T,b,B){return Math.floor(Math.floor(T/B)/b)}function ke(T,b,B,et){const st=T.updateRanges;if(st.length===0)e.texSubImage2D(i.TEXTURE_2D,0,0,0,b.width,b.height,B,et,b.data);else{st.sort((C,Z)=>C.start-Z.start);let dt=0;for(let C=1;C<st.length;C++){const Z=st[dt],$=st[C],ot=Z.start+Z.count,it=Xt($.start,b.width,4),rt=Xt(Z.start,b.width,4);$.start<=ot+1&&it===rt&&Xt($.start+$.count-1,b.width,4)===it?Z.count=Math.max(Z.count,$.start+$.count-Z.start):(++dt,st[dt]=$)}st.length=dt+1;const X=e.getParameter(i.UNPACK_ROW_LENGTH),Y=e.getParameter(i.UNPACK_SKIP_PIXELS),at=e.getParameter(i.UNPACK_SKIP_ROWS);e.pixelStorei(i.UNPACK_ROW_LENGTH,b.width);for(let C=0,Z=st.length;C<Z;C++){const $=st[C],ot=Math.floor($.start/4),it=Math.ceil($.count/4),rt=ot%b.width,At=Math.floor(ot/b.width),Gt=it,nt=1;e.pixelStorei(i.UNPACK_SKIP_PIXELS,rt),e.pixelStorei(i.UNPACK_SKIP_ROWS,At),e.texSubImage2D(i.TEXTURE_2D,0,rt,At,Gt,nt,B,et,b.data)}T.clearUpdateRanges(),e.pixelStorei(i.UNPACK_ROW_LENGTH,X),e.pixelStorei(i.UNPACK_SKIP_PIXELS,Y),e.pixelStorei(i.UNPACK_SKIP_ROWS,at)}}function Te(T,b,B){let et=i.TEXTURE_2D;(b.isDataArrayTexture||b.isCompressedArrayTexture)&&(et=i.TEXTURE_2D_ARRAY),b.isData3DTexture&&(et=i.TEXTURE_3D);const J=le(T,b),st=b.source;e.bindTexture(et,T.__webglTexture,i.TEXTURE0+B);const dt=n.get(st);if(st.version!==dt.__version||J===!0){if(e.activeTexture(i.TEXTURE0+B),(typeof ImageBitmap<"u"&&b.image instanceof ImageBitmap)===!1){const nt=Jt.getPrimaries(Jt.workingColorSpace),Tt=b.colorSpace===di?null:Jt.getPrimaries(b.colorSpace),Ht=b.colorSpace===di||nt===Tt?i.NONE:i.BROWSER_DEFAULT_WEBGL;e.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,b.flipY),e.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,b.premultiplyAlpha),e.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,Ht)}e.pixelStorei(i.UNPACK_ALIGNMENT,b.unpackAlignment);let Y=_(b.image,!1,s.maxTextureSize);Y=Ct(b,Y);const at=r.convert(b.format,b.colorSpace),C=r.convert(b.type);let Z=E(b.internalFormat,at,C,b.normalized,b.colorSpace,b.isVideoTexture);se(et,b);let $;const ot=b.mipmaps,it=b.isVideoTexture!==!0,rt=dt.__version===void 0||J===!0,At=st.dataReady,Gt=w(b,Y);if(b.isDepthTexture)Z=v(b.format===Di,b.type),rt&&(it?e.texStorage2D(i.TEXTURE_2D,1,Z,Y.width,Y.height):e.texImage2D(i.TEXTURE_2D,0,Z,Y.width,Y.height,0,at,C,null));else if(b.isDataTexture)if(ot.length>0){it&&rt&&e.texStorage2D(i.TEXTURE_2D,Gt,Z,ot[0].width,ot[0].height);for(let nt=0,Tt=ot.length;nt<Tt;nt++)$=ot[nt],it?At&&e.texSubImage2D(i.TEXTURE_2D,nt,0,0,$.width,$.height,at,C,$.data):e.texImage2D(i.TEXTURE_2D,nt,Z,$.width,$.height,0,at,C,$.data);b.generateMipmaps=!1}else it?(rt&&e.texStorage2D(i.TEXTURE_2D,Gt,Z,Y.width,Y.height),At&&ke(b,Y,at,C)):e.texImage2D(i.TEXTURE_2D,0,Z,Y.width,Y.height,0,at,C,Y.data);else if(b.isCompressedTexture)if(b.isCompressedArrayTexture){it&&rt&&e.texStorage3D(i.TEXTURE_2D_ARRAY,Gt,Z,ot[0].width,ot[0].height,Y.depth);for(let nt=0,Tt=ot.length;nt<Tt;nt++)if($=ot[nt],b.format!==Kn)if(at!==null)if(it){if(At)if(b.layerUpdates.size>0){const Ht=Nd($.width,$.height,b.format,b.type);for(const ft of b.layerUpdates){const re=$.data.subarray(ft*Ht/$.data.BYTES_PER_ELEMENT,(ft+1)*Ht/$.data.BYTES_PER_ELEMENT);e.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,nt,0,0,ft,$.width,$.height,1,at,re)}}else e.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,nt,0,0,0,$.width,$.height,Y.depth,at,$.data)}else e.compressedTexImage3D(i.TEXTURE_2D_ARRAY,nt,Z,$.width,$.height,Y.depth,0,$.data,0,0);else Lt("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else it?At&&e.texSubImage3D(i.TEXTURE_2D_ARRAY,nt,0,0,0,$.width,$.height,Y.depth,at,C,$.data):e.texImage3D(i.TEXTURE_2D_ARRAY,nt,Z,$.width,$.height,Y.depth,0,at,C,$.data);b.layerUpdates.size>0&&b.clearLayerUpdates()}else{it&&rt&&e.texStorage2D(i.TEXTURE_2D,Gt,Z,ot[0].width,ot[0].height);for(let nt=0,Tt=ot.length;nt<Tt;nt++)$=ot[nt],b.format!==Kn?at!==null?it?At&&e.compressedTexSubImage2D(i.TEXTURE_2D,nt,0,0,$.width,$.height,at,$.data):e.compressedTexImage2D(i.TEXTURE_2D,nt,Z,$.width,$.height,0,$.data):Lt("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):it?At&&e.texSubImage2D(i.TEXTURE_2D,nt,0,0,$.width,$.height,at,C,$.data):e.texImage2D(i.TEXTURE_2D,nt,Z,$.width,$.height,0,at,C,$.data)}else if(b.isDataArrayTexture)if(it){if(rt&&e.texStorage3D(i.TEXTURE_2D_ARRAY,Gt,Z,Y.width,Y.height,Y.depth),At)if(b.layerUpdates.size>0){const nt=Nd(Y.width,Y.height,b.format,b.type);for(const Tt of b.layerUpdates){const Ht=Y.data.subarray(Tt*nt/Y.data.BYTES_PER_ELEMENT,(Tt+1)*nt/Y.data.BYTES_PER_ELEMENT);e.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,Tt,Y.width,Y.height,1,at,C,Ht)}b.clearLayerUpdates()}else e.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,0,Y.width,Y.height,Y.depth,at,C,Y.data)}else e.texImage3D(i.TEXTURE_2D_ARRAY,0,Z,Y.width,Y.height,Y.depth,0,at,C,Y.data);else if(b.isData3DTexture)it?(rt&&e.texStorage3D(i.TEXTURE_3D,Gt,Z,Y.width,Y.height,Y.depth),At&&e.texSubImage3D(i.TEXTURE_3D,0,0,0,0,Y.width,Y.height,Y.depth,at,C,Y.data)):e.texImage3D(i.TEXTURE_3D,0,Z,Y.width,Y.height,Y.depth,0,at,C,Y.data);else if(b.isFramebufferTexture){if(rt)if(it)e.texStorage2D(i.TEXTURE_2D,Gt,Z,Y.width,Y.height);else{let nt=Y.width,Tt=Y.height;for(let Ht=0;Ht<Gt;Ht++)e.texImage2D(i.TEXTURE_2D,Ht,Z,nt,Tt,0,at,C,null),nt>>=1,Tt>>=1}}else if(b.isHTMLTexture){if("texElementImage2D"in i){const nt=i.canvas;if(nt.hasAttribute("layoutsubtree")||nt.setAttribute("layoutsubtree","true"),Y.parentNode!==nt){nt.appendChild(Y),h.add(b),nt.onpaint=Tt=>{const Ht=Tt.changedElements;for(const ft of h)Ht.includes(ft.image)&&(ft.needsUpdate=!0)},nt.requestPaint();return}if(i.texElementImage2D.length===3)i.texElementImage2D(i.TEXTURE_2D,i.RGBA8,Y);else{const Ht=i.RGBA,ft=i.RGBA,re=i.UNSIGNED_BYTE;i.texElementImage2D(i.TEXTURE_2D,0,Ht,ft,re,Y)}i.texParameteri(i.TEXTURE_2D,i.TEXTURE_MIN_FILTER,i.LINEAR),i.texParameteri(i.TEXTURE_2D,i.TEXTURE_WRAP_S,i.CLAMP_TO_EDGE),i.texParameteri(i.TEXTURE_2D,i.TEXTURE_WRAP_T,i.CLAMP_TO_EDGE)}}else if(ot.length>0){if(it&&rt){const nt=Ft(ot[0]);e.texStorage2D(i.TEXTURE_2D,Gt,Z,nt.width,nt.height)}for(let nt=0,Tt=ot.length;nt<Tt;nt++)$=ot[nt],it?At&&e.texSubImage2D(i.TEXTURE_2D,nt,0,0,at,C,$):e.texImage2D(i.TEXTURE_2D,nt,Z,at,C,$);b.generateMipmaps=!1}else if(it){if(rt){const nt=Ft(Y);e.texStorage2D(i.TEXTURE_2D,Gt,Z,nt.width,nt.height)}At&&e.texSubImage2D(i.TEXTURE_2D,0,0,0,at,C,Y)}else e.texImage2D(i.TEXTURE_2D,0,Z,at,C,Y);S(b)&&b.mipmapsAutoUpdate===!0&&y(et),dt.__version=st.version,b.onUpdate&&b.onUpdate(b)}T.__version=b.version}function rn(T,b,B){if(b.image.length!==6)return;const et=le(T,b),J=b.source;e.bindTexture(i.TEXTURE_CUBE_MAP,T.__webglTexture,i.TEXTURE0+B);const st=n.get(J);if(J.version!==st.__version||et===!0){e.activeTexture(i.TEXTURE0+B);const dt=Jt.getPrimaries(Jt.workingColorSpace),X=b.colorSpace===di?null:Jt.getPrimaries(b.colorSpace),Y=b.colorSpace===di||dt===X?i.NONE:i.BROWSER_DEFAULT_WEBGL;e.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,b.flipY),e.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,b.premultiplyAlpha),e.pixelStorei(i.UNPACK_ALIGNMENT,b.unpackAlignment),e.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,Y);const at=b.isCompressedTexture||b.image[0].isCompressedTexture,C=b.image[0]&&b.image[0].isDataTexture,Z=[];for(let ft=0;ft<6;ft++)!at&&!C?Z[ft]=_(b.image[ft],!0,s.maxCubemapSize):Z[ft]=C?b.image[ft].image:b.image[ft],Z[ft]=Ct(b,Z[ft]);const $=Z[0],ot=r.convert(b.format,b.colorSpace),it=r.convert(b.type);let rt=E(b.internalFormat,ot,it,b.normalized,b.colorSpace);const At=b.isVideoTexture!==!0,Gt=st.__version===void 0||et===!0,nt=J.dataReady;let Tt=w(b,$);se(i.TEXTURE_CUBE_MAP,b);let Ht;if(b.isDepthTexture){if(rt=v(b.format===Di,b.type),Gt)if(At)e.texStorage2D(i.TEXTURE_CUBE_MAP,1,rt,$.width,$.height);else for(let ft=0;ft<6;ft++)e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ft,0,rt,$.width,$.height,0,ot,it,null)}else if(at){At&&Gt&&e.texStorage2D(i.TEXTURE_CUBE_MAP,Tt,rt,$.width,$.height);for(let ft=0;ft<6;ft++){Ht=Z[ft].mipmaps;for(let re=0;re<Ht.length;re++){const Ie=Ht[re];b.format!==Kn?ot!==null?At?nt&&e.compressedTexSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ft,re,0,0,Ie.width,Ie.height,ot,Ie.data):e.compressedTexImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ft,re,rt,Ie.width,Ie.height,0,Ie.data):Lt("WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):At?nt&&e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ft,re,0,0,Ie.width,Ie.height,ot,it,Ie.data):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ft,re,rt,Ie.width,Ie.height,0,ot,it,Ie.data)}}}else{if(Ht=b.mipmaps,At&&Gt){Ht.length>0&&Tt++;const ft=Ft(Z[0]);e.texStorage2D(i.TEXTURE_CUBE_MAP,Tt,rt,ft.width,ft.height)}for(let ft=0;ft<6;ft++)if(C){At?nt&&e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ft,0,0,0,Z[ft].width,Z[ft].height,ot,it,Z[ft].data):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ft,0,rt,Z[ft].width,Z[ft].height,0,ot,it,Z[ft].data);for(let re=0;re<Ht.length;re++){const yi=Ht[re].image[ft].image;At?nt&&e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ft,re+1,0,0,yi.width,yi.height,ot,it,yi.data):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ft,re+1,rt,yi.width,yi.height,0,ot,it,yi.data)}}else{At?nt&&e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ft,0,0,0,ot,it,Z[ft]):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ft,0,rt,ot,it,Z[ft]);for(let re=0;re<Ht.length;re++){const Ie=Ht[re];At?nt&&e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ft,re+1,0,0,ot,it,Ie.image[ft]):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ft,re+1,rt,ot,it,Ie.image[ft])}}}S(b)&&b.mipmapsAutoUpdate===!0&&y(i.TEXTURE_CUBE_MAP),st.__version=J.version,b.onUpdate&&b.onUpdate(b)}T.__version=b.version}function ve(T,b,B,et,J,st){const dt=r.convert(B.format,B.colorSpace),X=r.convert(B.type),Y=E(B.internalFormat,dt,X,B.normalized,B.colorSpace),at=n.get(b),C=n.get(B);if(C.__renderTarget=b,!at.__hasExternalTextures){const Z=Math.max(1,b.width>>st),$=Math.max(1,b.height>>st);J===i.TEXTURE_3D||J===i.TEXTURE_2D_ARRAY?e.texImage3D(J,st,Y,Z,$,b.depth,0,dt,X,null):e.texImage2D(J,st,Y,Z,$,0,dt,X,null)}e.bindFramebuffer(i.FRAMEBUFFER,T),ut(b)?o.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,et,J,C.__webglTexture,0,pe(b)):(J===i.TEXTURE_2D||J>=i.TEXTURE_CUBE_MAP_POSITIVE_X&&J<=i.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&i.framebufferTexture2D(i.FRAMEBUFFER,et,J,C.__webglTexture,st),e.bindFramebuffer(i.FRAMEBUFFER,null)}function Hn(T,b,B){if(i.bindRenderbuffer(i.RENDERBUFFER,T),b.depthBuffer){const et=b.depthTexture,J=et&&et.isDepthTexture?et.type:null,st=v(b.stencilBuffer,J),dt=b.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT;ut(b)?o.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,pe(b),st,b.width,b.height):B?i.renderbufferStorageMultisample(i.RENDERBUFFER,pe(b),st,b.width,b.height):i.renderbufferStorage(i.RENDERBUFFER,st,b.width,b.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,dt,i.RENDERBUFFER,T)}else{const et=b.textures;for(let J=0;J<et.length;J++){const st=et[J],dt=r.convert(st.format,st.colorSpace),X=r.convert(st.type),Y=E(st.internalFormat,dt,X,st.normalized,st.colorSpace);ut(b)?o.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,pe(b),Y,b.width,b.height):B?i.renderbufferStorageMultisample(i.RENDERBUFFER,pe(b),Y,b.width,b.height):i.renderbufferStorage(i.RENDERBUFFER,Y,b.width,b.height)}}i.bindRenderbuffer(i.RENDERBUFFER,null)}function De(T,b,B){const et=b.isWebGLCubeRenderTarget===!0;if(e.bindFramebuffer(i.FRAMEBUFFER,T),!(b.depthTexture&&b.depthTexture.isDepthTexture))throw new Error("THREE.WebGLTextures: renderTarget.depthTexture must be an instance of THREE.DepthTexture.");const J=n.get(b.depthTexture);J.__renderTarget=b;const st=et?b.depthTexture.image[0]:b.depthTexture.image;(!J.__webglTexture||st.width!==b.width||st.height!==b.height)&&(st.width=b.width,st.height=b.height,b.depthTexture.needsUpdate=!0),et?vt(b.depthTexture,0):mt(b.depthTexture,0);const dt=J.__webglTexture,X=pe(b),Y=et?i.TEXTURE_CUBE_MAP_POSITIVE_X+B:i.TEXTURE_2D,at=b.depthTexture.format===Di?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT;if(b.depthTexture.format===Ni)ut(b)?o.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,at,Y,dt,0,X):i.framebufferTexture2D(i.FRAMEBUFFER,at,Y,dt,0);else if(b.depthTexture.format===Di)ut(b)?o.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,at,Y,dt,0,X):i.framebufferTexture2D(i.FRAMEBUFFER,at,Y,dt,0);else throw new Error("THREE.WebGLTextures: Unknown depthTexture format.")}function gn(T){const b=n.get(T),B=T.isWebGLCubeRenderTarget===!0;if(b.__boundDepthTexture!==T.depthTexture){const et=T.depthTexture;if(b.__depthDisposeCallback&&b.__depthDisposeCallback(),et){const J=()=>{delete b.__boundDepthTexture,delete b.__depthDisposeCallback,et.removeEventListener("dispose",J)};et.addEventListener("dispose",J),b.__depthDisposeCallback=J}b.__boundDepthTexture=et}if(T.depthTexture&&!b.__autoAllocateDepthBuffer)if(B)for(let et=0;et<6;et++)De(b.__webglFramebuffer[et],T,et);else T.texture.mipmaps.length>0?De(b.__webglFramebuffer[0],T,0):De(b.__webglFramebuffer,T,0);else if(B){b.__webglDepthbuffer=[];for(let et=0;et<6;et++)if(e.bindFramebuffer(i.FRAMEBUFFER,b.__webglFramebuffer[et]),b.__webglDepthbuffer[et]===void 0)b.__webglDepthbuffer[et]=i.createRenderbuffer(),Hn(b.__webglDepthbuffer[et],T,!1);else{const J=T.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,st=b.__webglDepthbuffer[et];i.bindRenderbuffer(i.RENDERBUFFER,st),i.framebufferRenderbuffer(i.FRAMEBUFFER,J,i.RENDERBUFFER,st)}}else if(T.texture.mipmaps.length>0?e.bindFramebuffer(i.FRAMEBUFFER,b.__webglFramebuffer[0]):e.bindFramebuffer(i.FRAMEBUFFER,b.__webglFramebuffer),b.__webglDepthbuffer===void 0)b.__webglDepthbuffer=i.createRenderbuffer(),Hn(b.__webglDepthbuffer,T,!1);else{const J=T.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,st=b.__webglDepthbuffer;i.bindRenderbuffer(i.RENDERBUFFER,st),i.framebufferRenderbuffer(i.FRAMEBUFFER,J,i.RENDERBUFFER,st)}e.bindFramebuffer(i.FRAMEBUFFER,null)}function vn(T,b,B){const et=n.get(T);b!==void 0&&ve(et.__webglFramebuffer,T,T.texture,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,0),B!==void 0&&gn(T)}function xn(T){const b=T.texture,B=n.get(T),et=n.get(b);T.addEventListener("dispose",F),N(T);const J=T.textures,st=T.isWebGLCubeRenderTarget===!0,dt=J.length>1;if(dt||(et.__webglTexture===void 0&&(et.__webglTexture=i.createTexture()),et.__version=b.version,a.memory.textures++),st){B.__webglFramebuffer=[];for(let X=0;X<6;X++)if(b.mipmaps.length>0){B.__webglFramebuffer[X]=[];for(let Y=0;Y<b.mipmaps.length;Y++)B.__webglFramebuffer[X][Y]=i.createFramebuffer()}else B.__webglFramebuffer[X]=i.createFramebuffer()}else{if(b.mipmaps.length>0){B.__webglFramebuffer=[];for(let X=0;X<b.mipmaps.length;X++)B.__webglFramebuffer[X]=i.createFramebuffer()}else B.__webglFramebuffer=i.createFramebuffer();if(dt)for(let X=0,Y=J.length;X<Y;X++){const at=n.get(J[X]);at.__webglTexture===void 0&&(at.__webglTexture=i.createTexture(),a.memory.textures++)}if(T.samples>0&&ut(T)===!1){B.__webglMultisampledFramebuffer=i.createFramebuffer(),B.__webglColorRenderbuffer=[],e.bindFramebuffer(i.FRAMEBUFFER,B.__webglMultisampledFramebuffer);for(let X=0;X<J.length;X++){const Y=J[X];B.__webglColorRenderbuffer[X]=i.createRenderbuffer(),i.bindRenderbuffer(i.RENDERBUFFER,B.__webglColorRenderbuffer[X]);const at=r.convert(Y.format,Y.colorSpace),C=r.convert(Y.type),Z=E(Y.internalFormat,at,C,Y.normalized,Y.colorSpace,T.isXRRenderTarget===!0),$=pe(T);i.renderbufferStorageMultisample(i.RENDERBUFFER,$,Z,T.width,T.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+X,i.RENDERBUFFER,B.__webglColorRenderbuffer[X])}i.bindRenderbuffer(i.RENDERBUFFER,null),T.depthBuffer&&(B.__webglDepthRenderbuffer=i.createRenderbuffer(),Hn(B.__webglDepthRenderbuffer,T,!0)),e.bindFramebuffer(i.FRAMEBUFFER,null)}}if(st){e.bindTexture(i.TEXTURE_CUBE_MAP,et.__webglTexture),se(i.TEXTURE_CUBE_MAP,b);for(let X=0;X<6;X++)if(b.mipmaps.length>0)for(let Y=0;Y<b.mipmaps.length;Y++)ve(B.__webglFramebuffer[X][Y],T,b,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+X,Y);else ve(B.__webglFramebuffer[X],T,b,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+X,0);S(b)?y(i.TEXTURE_CUBE_MAP):b.mipmaps.length>0&&i.texParameteri(i.TEXTURE_CUBE_MAP,i.TEXTURE_MAX_LEVEL,b.mipmaps.length-1),e.unbindTexture()}else if(dt){for(let X=0,Y=J.length;X<Y;X++){const at=J[X],C=n.get(at);let Z=i.TEXTURE_2D;(T.isWebGL3DRenderTarget||T.isWebGLArrayRenderTarget)&&(Z=T.isWebGL3DRenderTarget?i.TEXTURE_3D:i.TEXTURE_2D_ARRAY),e.bindTexture(Z,C.__webglTexture),se(Z,at),ve(B.__webglFramebuffer,T,at,i.COLOR_ATTACHMENT0+X,Z,0),S(at)&&y(Z)}e.unbindTexture()}else{let X=i.TEXTURE_2D;if((T.isWebGL3DRenderTarget||T.isWebGLArrayRenderTarget)&&(X=T.isWebGL3DRenderTarget?i.TEXTURE_3D:i.TEXTURE_2D_ARRAY),e.bindTexture(X,et.__webglTexture),se(X,b),b.mipmaps.length>0)for(let Y=0;Y<b.mipmaps.length;Y++)ve(B.__webglFramebuffer[Y],T,b,i.COLOR_ATTACHMENT0,X,Y);else ve(B.__webglFramebuffer,T,b,i.COLOR_ATTACHMENT0,X,0);S(b)?y(X):b.mipmaps.length>0&&i.texParameteri(X,i.TEXTURE_MAX_LEVEL,b.mipmaps.length-1),e.unbindTexture()}T.depthBuffer&&gn(T)}function U(T){const b=T.textures;for(let B=0,et=b.length;B<et;B++){const J=b[B];if(S(J)&&J.mipmapsAutoUpdate===!0){const st=A(T),dt=n.get(J).__webglTexture;e.bindTexture(st,dt),y(st),e.unbindTexture()}}}const _n=[];function fe(T){if(T.samples>0){if(ut(T)===!1){const b=T.textures,B=T.width,et=T.height;let J=i.COLOR_BUFFER_BIT;const st=T.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,dt=n.get(T),X=b.length>1;if(X)for(let at=0;at<b.length;at++)e.bindFramebuffer(i.FRAMEBUFFER,dt.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+at,i.RENDERBUFFER,null),e.bindFramebuffer(i.FRAMEBUFFER,dt.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+at,i.TEXTURE_2D,null,0);e.bindFramebuffer(i.READ_FRAMEBUFFER,dt.__webglMultisampledFramebuffer),T.texture.mipmaps.length>0?e.bindFramebuffer(i.DRAW_FRAMEBUFFER,dt.__webglFramebuffer[0]):e.bindFramebuffer(i.DRAW_FRAMEBUFFER,dt.__webglFramebuffer);for(let at=0;at<b.length;at++){if(T.resolveDepthBuffer&&(T.depthBuffer&&(J|=i.DEPTH_BUFFER_BIT),T.stencilBuffer&&T.resolveStencilBuffer&&(J|=i.STENCIL_BUFFER_BIT)),X){i.framebufferRenderbuffer(i.READ_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.RENDERBUFFER,dt.__webglColorRenderbuffer[at]);const C=n.get(b[at]).__webglTexture;i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,C,0)}i.blitFramebuffer(0,0,B,et,0,0,B,et,J,i.NEAREST),l===!0&&(_n.length=0,_n.push(i.COLOR_ATTACHMENT0+at),T.depthBuffer&&T.storeMultisampledDepthBuffer===!1&&_n.push(st),i.invalidateFramebuffer(i.READ_FRAMEBUFFER,_n))}if(e.bindFramebuffer(i.READ_FRAMEBUFFER,null),e.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),X)for(let at=0;at<b.length;at++){e.bindFramebuffer(i.FRAMEBUFFER,dt.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+at,i.RENDERBUFFER,dt.__webglColorRenderbuffer[at]);const C=n.get(b[at]).__webglTexture;e.bindFramebuffer(i.FRAMEBUFFER,dt.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+at,i.TEXTURE_2D,C,0)}e.bindFramebuffer(i.DRAW_FRAMEBUFFER,dt.__webglMultisampledFramebuffer)}else if(T.depthBuffer&&T.storeMultisampledDepthBuffer===!1&&l){const b=T.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT;i.invalidateFramebuffer(i.DRAW_FRAMEBUFFER,[b])}}}function pe(T){return Math.min(s.maxSamples,T.samples)}function ut(T){const b=n.get(T);return T.samples>0&&t.has("WEBGL_multisampled_render_to_texture")===!0&&b.__useRenderToTexture!==!1}function Re(T){const b=a.render.frame;d.get(T)!==b&&(d.set(T,b),T.update())}function Ct(T,b){const B=T.colorSpace,et=T.format,J=T.type;return T.isCompressedTexture===!0||T.isVideoTexture===!0||B!==La&&B!==di&&(Jt.getTransfer(B)===ae?(et!==Kn||J!==an)&&Lt("WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):ee("WebGLTextures: Unsupported texture color space:",B)),b}function Ft(T){return typeof HTMLImageElement<"u"&&T instanceof HTMLImageElement?(c.width=T.naturalWidth||T.width,c.height=T.naturalHeight||T.height):typeof VideoFrame<"u"&&T instanceof VideoFrame?(c.width=T.displayWidth,c.height=T.displayHeight):(c.width=T.width,c.height=T.height),c}this.allocateTextureUnit=Bt,this.resetTextureUnits=j,this.getTextureUnits=Q,this.setTextureUnits=wt,this.setTexture2D=mt,this.setTexture2DArray=bt,this.setTexture3D=Rt,this.setTextureCube=vt,this.rebindTextures=vn,this.setupRenderTarget=xn,this.updateRenderTargetMipmap=U,this.updateMultisampleRenderTarget=fe,this.setupDepthRenderbuffer=gn,this.setupFrameBufferTexture=ve,this.useMultisampledRTT=ut,this.dispose=H}function kx(i,t){function e(n,s=di){let r;const a=Jt.getTransfer(s);if(n===an)return i.UNSIGNED_BYTE;if(n===tc)return i.UNSIGNED_SHORT_4_4_4_4;if(n===ec)return i.UNSIGNED_SHORT_5_5_5_1;if(n===ru)return i.UNSIGNED_INT_5_9_9_9_REV;if(n===au)return i.UNSIGNED_INT_10F_11F_11F_REV;if(n===iu)return i.BYTE;if(n===su)return i.SHORT;if(n===vr)return i.UNSIGNED_SHORT;if(n===Ql)return i.INT;if(n===Jn)return i.UNSIGNED_INT;if(n===Pn)return i.FLOAT;if(n===jn)return i.HALF_FLOAT;if(n===ou)return i.ALPHA;if(n===lu)return i.RGB;if(n===Kn)return i.RGBA;if(n===Ni)return i.DEPTH_COMPONENT;if(n===Di)return i.DEPTH_STENCIL;if(n===nc)return i.RED;if(n===ic)return i.RED_INTEGER;if(n===Zi)return i.RG;if(n===sc)return i.RG_INTEGER;if(n===rc)return i.RGBA_INTEGER;if(n===xa||n===_a||n===ya||n===ba)if(a===ae)if(r=t.get("WEBGL_compressed_texture_s3tc_srgb"),r!==null){if(n===xa)return r.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(n===_a)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(n===ya)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(n===ba)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(r=t.get("WEBGL_compressed_texture_s3tc"),r!==null){if(n===xa)return r.COMPRESSED_RGB_S3TC_DXT1_EXT;if(n===_a)return r.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(n===ya)return r.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(n===ba)return r.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(n===jo||n===Qo||n===tl||n===el)if(r=t.get("WEBGL_compressed_texture_pvrtc"),r!==null){if(n===jo)return r.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(n===Qo)return r.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(n===tl)return r.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(n===el)return r.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(n===nl||n===il||n===sl||n===rl||n===al||n===Ca||n===ol)if(r=t.get("WEBGL_compressed_texture_etc"),r!==null){if(n===nl||n===il)return a===ae?r.COMPRESSED_SRGB8_ETC2:r.COMPRESSED_RGB8_ETC2;if(n===sl)return a===ae?r.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:r.COMPRESSED_RGBA8_ETC2_EAC;if(n===rl)return r.COMPRESSED_R11_EAC;if(n===al)return r.COMPRESSED_SIGNED_R11_EAC;if(n===Ca)return r.COMPRESSED_RG11_EAC;if(n===ol)return r.COMPRESSED_SIGNED_RG11_EAC}else return null;if(n===ll||n===cl||n===dl||n===hl||n===ul||n===fl||n===pl||n===ml||n===gl||n===vl||n===xl||n===_l||n===yl||n===bl)if(r=t.get("WEBGL_compressed_texture_astc"),r!==null){if(n===ll)return a===ae?r.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:r.COMPRESSED_RGBA_ASTC_4x4_KHR;if(n===cl)return a===ae?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:r.COMPRESSED_RGBA_ASTC_5x4_KHR;if(n===dl)return a===ae?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:r.COMPRESSED_RGBA_ASTC_5x5_KHR;if(n===hl)return a===ae?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:r.COMPRESSED_RGBA_ASTC_6x5_KHR;if(n===ul)return a===ae?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:r.COMPRESSED_RGBA_ASTC_6x6_KHR;if(n===fl)return a===ae?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:r.COMPRESSED_RGBA_ASTC_8x5_KHR;if(n===pl)return a===ae?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:r.COMPRESSED_RGBA_ASTC_8x6_KHR;if(n===ml)return a===ae?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:r.COMPRESSED_RGBA_ASTC_8x8_KHR;if(n===gl)return a===ae?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:r.COMPRESSED_RGBA_ASTC_10x5_KHR;if(n===vl)return a===ae?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:r.COMPRESSED_RGBA_ASTC_10x6_KHR;if(n===xl)return a===ae?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:r.COMPRESSED_RGBA_ASTC_10x8_KHR;if(n===_l)return a===ae?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:r.COMPRESSED_RGBA_ASTC_10x10_KHR;if(n===yl)return a===ae?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:r.COMPRESSED_RGBA_ASTC_12x10_KHR;if(n===bl)return a===ae?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:r.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(n===Ml||n===Sl||n===wl)if(r=t.get("EXT_texture_compression_bptc"),r!==null){if(n===Ml)return a===ae?r.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:r.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(n===Sl)return r.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(n===wl)return r.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(n===El||n===Al||n===Pa||n===Tl)if(r=t.get("EXT_texture_compression_rgtc"),r!==null){if(n===El)return r.COMPRESSED_RED_RGTC1_EXT;if(n===Al)return r.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(n===Pa)return r.COMPRESSED_RED_GREEN_RGTC2_EXT;if(n===Tl)return r.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return n===Bs?i.UNSIGNED_INT_24_8:i[n]!==void 0?i[n]:null}return{convert:e}}const zx=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,Hx=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class Gx{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(t,e){if(this.texture===null){const n=new Au(t.texture);(t.depthNear!==e.depthNear||t.depthFar!==e.depthFar)&&(this.depthNear=t.depthNear,this.depthFar=t.depthFar),this.texture=n}}getMesh(t){if(this.texture!==null&&this.mesh===null){const e=t.cameras[0].viewport,n=new Un({vertexShader:zx,fragmentShader:Hx,uniforms:{depthColor:{value:this.texture},depthWidth:{value:e.z},depthHeight:{value:e.w}}});this.mesh=new $t(new rs(20,20),n)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class Vx extends ns{constructor(t,e){super();const n=this;let s=null,r=1,a=null,o="local-floor",l=1,c=null,d=null,h=null,u=null,f=null,g=null;const x=typeof XRWebGLBinding<"u",m=new Gx,p={},_=e.getContextAttributes();let S=null,y=null;const A=[],E=[],v=new Dt;let w=null,N=null;const R=new dn;R.viewport=new _e;const L=new dn;L.viewport=new _e;const F=[R,L],V=new tm;let D=null,H=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(K){let mt=A[K];return mt===void 0&&(mt=new po,A[K]=mt),mt.getTargetRaySpace()},this.getControllerGrip=function(K){let mt=A[K];return mt===void 0&&(mt=new po,A[K]=mt),mt.getGripSpace()},this.getHand=function(K){let mt=A[K];return mt===void 0&&(mt=new po,A[K]=mt),mt.getHandSpace()};function q(K){const mt=E.indexOf(K.inputSource);if(mt===-1)return;const bt=A[mt];bt!==void 0&&(bt.update(K.inputSource,K.frame,c||a),bt.dispatchEvent({type:K.type,data:K.inputSource}))}function k(){s.removeEventListener("select",q),s.removeEventListener("selectstart",q),s.removeEventListener("selectend",q),s.removeEventListener("squeeze",q),s.removeEventListener("squeezestart",q),s.removeEventListener("squeezeend",q),s.removeEventListener("end",k),s.removeEventListener("inputsourceschange",tt);for(let K=0;K<A.length;K++){const mt=E[K];mt!==null&&(E[K]=null,A[K].disconnect(mt))}D=null,H=null,m.reset();for(const K in p)delete p[K];if(t.setRenderTarget(S),f=null,u=null,h=null,s=null,y=null,Bt.stop(),n.isPresenting=!1,t.setPixelRatio(w),t.setSize(v.width,v.height,!1),N!==null){const K=N.camera;K.fov=N.fov,K.zoom=N.zoom,K.updateProjectionMatrix(),N=null}n.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(K){r=K,n.isPresenting===!0&&Lt("WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(K){o=K,n.isPresenting===!0&&Lt("WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return c||a},this.setReferenceSpace=function(K){c=K},this.getBaseLayer=function(){return u!==null?u:f},this.getBinding=function(){return h===null&&x&&(h=new XRWebGLBinding(s,e)),h},this.getFrame=function(){return g},this.getSession=function(){return s},this.setSession=async function(K){if(s=K,s!==null){if(S=t.getRenderTarget(),s.addEventListener("select",q),s.addEventListener("selectstart",q),s.addEventListener("selectend",q),s.addEventListener("squeeze",q),s.addEventListener("squeezestart",q),s.addEventListener("squeezeend",q),s.addEventListener("end",k),s.addEventListener("inputsourceschange",tt),_.xrCompatible!==!0&&await e.makeXRCompatible(),w=t.getPixelRatio(),t.getSize(v),x&&"createProjectionLayer"in XRWebGLBinding.prototype){let bt=null,Rt=null,vt=null;_.depth&&(vt=_.stencil?e.DEPTH24_STENCIL8:e.DEPTH_COMPONENT24,bt=_.stencil?Di:Ni,Rt=_.stencil?Bs:Jn);const zt={colorFormat:e.RGBA8,depthFormat:vt,scaleFactor:r};h=this.getBinding(),u=h.createProjectionLayer(zt),s.updateRenderState({layers:[u]}),t.setPixelRatio(1),t.setSize(u.textureWidth,u.textureHeight,!1),y=new Sn(u.textureWidth,u.textureHeight,{format:Kn,type:an,depthTexture:new ks(u.textureWidth,u.textureHeight,Rt,void 0,void 0,void 0,void 0,void 0,void 0,bt),stencilBuffer:_.stencil,colorSpace:t.outputColorSpace,samples:_.antialias?4:0,resolveDepthBuffer:u.ignoreDepthValues===!1,resolveStencilBuffer:u.ignoreDepthValues===!1,storeMultisampledDepthBuffer:u.ignoreDepthValues===!1,storeMultisampledStencilBuffer:u.ignoreDepthValues===!1})}else{const bt={antialias:_.antialias,alpha:!0,depth:_.depth,stencil:_.stencil,framebufferScaleFactor:r};f=new XRWebGLLayer(s,e,bt),s.updateRenderState({baseLayer:f}),t.setPixelRatio(1),t.setSize(f.framebufferWidth,f.framebufferHeight,!1),y=new Sn(f.framebufferWidth,f.framebufferHeight,{format:Kn,type:an,colorSpace:t.outputColorSpace,stencilBuffer:_.stencil,resolveDepthBuffer:f.ignoreDepthValues===!1,resolveStencilBuffer:f.ignoreDepthValues===!1,storeMultisampledDepthBuffer:f.ignoreDepthValues===!1,storeMultisampledStencilBuffer:f.ignoreDepthValues===!1})}y.isXRRenderTarget=!0,this.setFoveation(l),c=null,a=await s.requestReferenceSpace(o),Bt.setContext(s),Bt.start(),n.isPresenting=!0,n.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(s!==null)return s.environmentBlendMode},this.getDepthTexture=function(){return m.getDepthTexture()};function tt(K){for(let mt=0;mt<K.removed.length;mt++){const bt=K.removed[mt],Rt=E.indexOf(bt);Rt>=0&&(E[Rt]=null,A[Rt].disconnect(bt))}for(let mt=0;mt<K.added.length;mt++){const bt=K.added[mt];let Rt=E.indexOf(bt);if(Rt===-1){for(let zt=0;zt<A.length;zt++)if(zt>=E.length){E.push(bt),Rt=zt;break}else if(E[zt]===null){E[zt]=bt,Rt=zt;break}if(Rt===-1)break}const vt=A[Rt];vt&&vt.connect(bt)}}function W(K,mt){mt===null?K.matrixWorld.copy(K.matrix):K.matrixWorld.multiplyMatrices(mt.matrixWorld,K.matrix),K.matrixWorldInverse.copy(K.matrixWorld).invert()}this.updateCamera=function(K){if(s===null)return;let mt=K.near,bt=K.far;m.texture!==null&&(m.depthNear>0&&(mt=m.depthNear),m.depthFar>0&&(bt=m.depthFar)),V.near=L.near=R.near=mt,V.far=L.far=R.far=bt,(D!==V.near||H!==V.far)&&(s.updateRenderState({depthNear:V.near,depthFar:V.far}),D=V.near,H=V.far),V.layers.mask=K.layers.mask|6,R.layers.mask=V.layers.mask&-5,L.layers.mask=V.layers.mask&-3;const Rt=K.parent,vt=V.cameras;W(V,Rt);for(let zt=0;zt<vt.length;zt++)W(vt[zt],Rt);V.projectionMatrix.copy(R.projectionMatrix),V.projectionMatrixInverse.copy(R.projectionMatrixInverse),N===null&&K.isPerspectiveCamera&&(N={camera:K,fov:K.fov,zoom:K.zoom}),j(K,V,Rt)};function j(K,mt,bt){bt===null?K.matrix.copy(mt.matrixWorld):(K.matrix.copy(bt.matrixWorld),K.matrix.invert(),K.matrix.multiply(mt.matrixWorld)),K.matrix.decompose(K.position,K.quaternion,K.scale),K.updateMatrixWorld(!0),K.projectionMatrix.copy(mt.projectionMatrix),K.projectionMatrixInverse.copy(mt.projectionMatrixInverse),K.isPerspectiveCamera&&(K.fov=_r*2*Math.atan(1/K.projectionMatrix.elements[5]),K.zoom=1)}this.getCamera=function(){return V},this.getFoveation=function(){if(!(u===null&&f===null))return l},this.setFoveation=function(K){l=K,u!==null&&(u.fixedFoveation=K),f!==null&&f.fixedFoveation!==void 0&&(f.fixedFoveation=K)},this.hasDepthSensing=function(){return m.texture!==null},this.getDepthSensingMesh=function(){return m.getMesh(V)},this.getCameraTexture=function(K){return p[K]};let Q=null;function wt(K,mt){if(d=mt.getViewerPose(c||a),g=mt,d!==null){const bt=d.views;f!==null&&(t.setRenderTargetFramebuffer(y,f.framebuffer),t.setRenderTarget(y));let Rt=!1;bt.length!==V.cameras.length&&(V.cameras.length=0,Rt=!0);for(let Pt=0;Pt<bt.length;Pt++){const se=bt[Pt];let le=null;if(f!==null)le=f.getViewport(se);else{const ke=h.getViewSubImage(u,se);le=ke.viewport,Pt===0&&(t.setRenderTargetTextures(y,ke.colorTexture,ke.depthStencilTexture),t.setRenderTarget(y))}let Xt=F[Pt];Xt===void 0&&(Xt=new dn,Xt.layers.enable(Pt),Xt.viewport=new _e,F[Pt]=Xt),Xt.matrix.fromArray(se.transform.matrix),Xt.matrix.decompose(Xt.position,Xt.quaternion,Xt.scale),Xt.projectionMatrix.fromArray(se.projectionMatrix),Xt.projectionMatrixInverse.copy(Xt.projectionMatrix).invert(),Xt.viewport.set(le.x,le.y,le.width,le.height),Pt===0&&(V.matrix.copy(Xt.matrix),V.matrix.decompose(V.position,V.quaternion,V.scale)),Rt===!0&&V.cameras.push(Xt)}const vt=s.enabledFeatures;if(vt&&vt.includes("depth-sensing")&&s.depthUsage=="gpu-optimized"&&x){h=n.getBinding();const Pt=h.getDepthInformation(bt[0]);Pt&&Pt.isValid&&Pt.texture&&m.init(Pt,s.renderState)}if(vt&&vt.includes("camera-access")&&x){t.state.unbindTexture(),h=n.getBinding();for(let Pt=0;Pt<bt.length;Pt++){const se=bt[Pt].camera;if(se){let le=p[se];le||(le=new Au,p[se]=le);const Xt=h.getCameraImage(se);le.sourceTexture=Xt}}}}for(let bt=0;bt<A.length;bt++){const Rt=E[bt],vt=A[bt];Rt!==null&&vt!==void 0&&vt.update(Rt,mt,c||a)}Q&&Q(K,mt),mt.detectedPlanes&&n.dispatchEvent({type:"planesdetected",data:mt}),g=null}const Bt=new Lu;Bt.setAnimationLoop(wt),this.setAnimationLoop=function(K){Q=K},this.dispose=function(){}}}const $x=new jt,Hu=new Ot;Hu.set(-1,0,0,0,1,0,0,0,1);function Wx(i,t){function e(m,p){m.matrixAutoUpdate===!0&&m.updateMatrix(),p.value.copy(m.matrix)}function n(m,p){p.color.getRGB(m.fogColor.value,Tu(i)),p.isFog?(m.fogNear.value=p.near,m.fogFar.value=p.far):p.isFogExp2&&(m.fogDensity.value=p.density)}function s(m,p,_,S,y){p.isNodeMaterial?p.uniformsNeedUpdate=!1:p.isMeshBasicMaterial?r(m,p):p.isMeshLambertMaterial?(r(m,p),p.envMap&&(m.envMapIntensity.value=p.envMapIntensity)):p.isMeshToonMaterial?(r(m,p),h(m,p)):p.isMeshPhongMaterial?(r(m,p),d(m,p),p.envMap&&(m.envMapIntensity.value=p.envMapIntensity)):p.isMeshStandardMaterial?(r(m,p),u(m,p),p.isMeshPhysicalMaterial&&f(m,p,y)):p.isMeshMatcapMaterial?(r(m,p),g(m,p)):p.isMeshDepthMaterial?r(m,p):p.isMeshDistanceMaterial?(r(m,p),x(m,p)):p.isMeshNormalMaterial?r(m,p):p.isLineBasicMaterial?(a(m,p),p.isLineDashedMaterial&&o(m,p)):p.isPointsMaterial?l(m,p,_,S):p.isSpriteMaterial?c(m,p):p.isShadowMaterial?(m.color.value.copy(p.color),m.opacity.value=p.opacity):p.isShaderMaterial&&(p.uniformsNeedUpdate=!1)}function r(m,p){m.opacity.value=p.opacity,p.color&&m.diffuse.value.copy(p.color),p.emissive&&m.emissive.value.copy(p.emissive).multiplyScalar(p.emissiveIntensity),p.map&&(m.map.value=p.map,e(p.map,m.mapTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,e(p.alphaMap,m.alphaMapTransform)),p.bumpMap&&(m.bumpMap.value=p.bumpMap,e(p.bumpMap,m.bumpMapTransform),m.bumpScale.value=p.bumpScale,p.side===qe&&(m.bumpScale.value*=-1)),p.normalMap&&(m.normalMap.value=p.normalMap,e(p.normalMap,m.normalMapTransform),m.normalScale.value.copy(p.normalScale),p.side===qe&&m.normalScale.value.negate()),p.displacementMap&&(m.displacementMap.value=p.displacementMap,e(p.displacementMap,m.displacementMapTransform),m.displacementScale.value=p.displacementScale,m.displacementBias.value=p.displacementBias),p.emissiveMap&&(m.emissiveMap.value=p.emissiveMap,e(p.emissiveMap,m.emissiveMapTransform)),p.specularMap&&(m.specularMap.value=p.specularMap,e(p.specularMap,m.specularMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest);const _=t.get(p),S=_.envMap,y=_.envMapRotation;S&&(m.envMap.value=S,m.envMapRotation.value.setFromMatrix4($x.makeRotationFromEuler(y)).transpose(),S.isCubeTexture&&S.isRenderTargetTexture===!1&&m.envMapRotation.value.premultiply(Hu),m.reflectivity.value=p.reflectivity,m.ior.value=p.ior,m.refractionRatio.value=p.refractionRatio),p.lightMap&&(m.lightMap.value=p.lightMap,m.lightMapIntensity.value=p.lightMapIntensity,e(p.lightMap,m.lightMapTransform)),p.aoMap&&(m.aoMap.value=p.aoMap,m.aoMapIntensity.value=p.aoMapIntensity,e(p.aoMap,m.aoMapTransform))}function a(m,p){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,p.map&&(m.map.value=p.map,e(p.map,m.mapTransform))}function o(m,p){m.dashSize.value=p.dashSize,m.totalSize.value=p.dashSize+p.gapSize,m.scale.value=p.scale}function l(m,p,_,S){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,m.size.value=p.size*_,m.scale.value=S*.5,p.map&&(m.map.value=p.map,e(p.map,m.uvTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,e(p.alphaMap,m.alphaMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest)}function c(m,p){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,m.rotation.value=p.rotation,p.map&&(m.map.value=p.map,e(p.map,m.mapTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,e(p.alphaMap,m.alphaMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest)}function d(m,p){m.specular.value.copy(p.specular),m.shininess.value=Math.max(p.shininess,1e-4)}function h(m,p){p.gradientMap&&(m.gradientMap.value=p.gradientMap)}function u(m,p){m.metalness.value=p.metalness,p.metalnessMap&&(m.metalnessMap.value=p.metalnessMap,e(p.metalnessMap,m.metalnessMapTransform)),m.roughness.value=p.roughness,p.roughnessMap&&(m.roughnessMap.value=p.roughnessMap,e(p.roughnessMap,m.roughnessMapTransform)),p.envMap&&(m.envMapIntensity.value=p.envMapIntensity)}function f(m,p,_){m.ior.value=p.ior,p.diffuseRoughness>0&&(m.diffuseRoughness.value=p.diffuseRoughness,p.diffuseRoughnessMap&&(m.diffuseRoughnessMap.value=p.diffuseRoughnessMap,e(p.diffuseRoughnessMap,m.diffuseRoughnessMapTransform))),p.sheen>0&&(m.sheenColor.value.copy(p.sheenColor).multiplyScalar(p.sheen),m.sheenRoughness.value=p.sheenRoughness,p.sheenColorMap&&(m.sheenColorMap.value=p.sheenColorMap,e(p.sheenColorMap,m.sheenColorMapTransform)),p.sheenRoughnessMap&&(m.sheenRoughnessMap.value=p.sheenRoughnessMap,e(p.sheenRoughnessMap,m.sheenRoughnessMapTransform))),p.clearcoat>0&&(m.clearcoat.value=p.clearcoat,m.clearcoatRoughness.value=p.clearcoatRoughness,p.clearcoatMap&&(m.clearcoatMap.value=p.clearcoatMap,e(p.clearcoatMap,m.clearcoatMapTransform)),p.clearcoatRoughnessMap&&(m.clearcoatRoughnessMap.value=p.clearcoatRoughnessMap,e(p.clearcoatRoughnessMap,m.clearcoatRoughnessMapTransform)),p.clearcoatNormalMap&&(m.clearcoatNormalMap.value=p.clearcoatNormalMap,e(p.clearcoatNormalMap,m.clearcoatNormalMapTransform),m.clearcoatNormalScale.value.copy(p.clearcoatNormalScale),p.side===qe&&m.clearcoatNormalScale.value.negate())),p.dispersion>0&&(m.dispersion.value=p.dispersion),p.retroreflectivity>0&&(m.retroreflectivity.value=p.retroreflectivity),p.iridescence>0&&(m.iridescence.value=p.iridescence,m.iridescenceIOR.value=p.iridescenceIOR,m.iridescenceThicknessMinimum.value=p.iridescenceThicknessMinimum,m.iridescenceThicknessMaximum.value=p.iridescenceThicknessMaximum,p.iridescenceMap&&(m.iridescenceMap.value=p.iridescenceMap,e(p.iridescenceMap,m.iridescenceMapTransform)),p.iridescenceThicknessMap&&(m.iridescenceThicknessMap.value=p.iridescenceThicknessMap,e(p.iridescenceThicknessMap,m.iridescenceThicknessMapTransform))),p.transmission>0&&(m.transmission.value=p.transmission,m.transmissionSamplerMap.value=_.texture,m.transmissionSamplerSize.value.set(_.width,_.height),p.transmissionMap&&(m.transmissionMap.value=p.transmissionMap,e(p.transmissionMap,m.transmissionMapTransform)),m.thickness.value=p.thickness,p.thicknessMap&&(m.thicknessMap.value=p.thicknessMap,e(p.thicknessMap,m.thicknessMapTransform)),m.attenuationDistance.value=p.attenuationDistance,m.attenuationColor.value.copy(p.attenuationColor)),p.anisotropy>0&&(m.anisotropyVector.value.set(p.anisotropy*Math.cos(p.anisotropyRotation),p.anisotropy*Math.sin(p.anisotropyRotation)),p.anisotropyMap&&(m.anisotropyMap.value=p.anisotropyMap,e(p.anisotropyMap,m.anisotropyMapTransform))),m.specularIntensity.value=p.specularIntensity,m.specularColor.value.copy(p.specularColor),p.specularColorMap&&(m.specularColorMap.value=p.specularColorMap,e(p.specularColorMap,m.specularColorMapTransform)),p.specularIntensityMap&&(m.specularIntensityMap.value=p.specularIntensityMap,e(p.specularIntensityMap,m.specularIntensityMapTransform))}function g(m,p){p.matcap&&(m.matcap.value=p.matcap)}function x(m,p){const _=t.get(p).light;m.referencePosition.value.setFromMatrixPosition(_.matrixWorld),m.nearDistance.value=_.shadow.camera.near,m.farDistance.value=_.shadow.camera.far}return{refreshFogUniforms:n,refreshMaterialUniforms:s}}function Xx(i,t,e,n){let s={},r={};function a(_,S){const y=S.program;n.uniformBlockBinding(_,y,s[_.id])}function o(_,S){let y=s[_.id];y===void 0&&(g(_),y=l(_),s[_.id]=y,_.addEventListener("dispose",m));const A=S.program;n.updateUBOMapping(_,A);const E=t.render.frame;r[_.id]!==E&&(c(_),r[_.id]=E)}function l(_){const S=i.createBuffer(),y=_.__size,A=_.usage;return i.bindBuffer(i.UNIFORM_BUFFER,S),i.bufferData(i.UNIFORM_BUFFER,y,A),i.bindBuffer(i.UNIFORM_BUFFER,null),S}function c(_){const S=s[_.id],y=_.uniforms,A=_.__cache;i.bindBuffer(i.UNIFORM_BUFFER,S);for(let E=0,v=y.length;E<v;E++){const w=y[E];if(Array.isArray(w))for(let N=0,R=w.length;N<R;N++)d(w[N],E,N,A);else d(w,E,0,A)}i.bindBuffer(i.UNIFORM_BUFFER,null)}function d(_,S,y,A){if(u(_,S,y,A)===!0){const E=_.__offset,v=_.value;if(Array.isArray(v)){let w=0;for(let N=0;N<v.length;N++){const R=v[N],L=x(R,!0);h(R,_.__data,w),w+=L.storage/Float32Array.BYTES_PER_ELEMENT}}else h(v,_.__data,0);i.bufferSubData(i.UNIFORM_BUFFER,E,_.__data)}}function h(_,S,y){typeof _=="number"||typeof _=="boolean"?S[y]=_:_.isMatrix3?(S[y]=_.elements[0],S[y+1]=_.elements[1],S[y+2]=_.elements[2],S[y+3]=0,S[y+4]=_.elements[3],S[y+5]=_.elements[4],S[y+6]=_.elements[5],S[y+7]=0,S[y+8]=_.elements[6],S[y+9]=_.elements[7],S[y+10]=_.elements[8],S[y+11]=0):ArrayBuffer.isView(_)?S.set(_.subarray(0,S.length-y),y):_.toArray(S,y)}function u(_,S,y,A){const E=_.value,v=S+"_"+y;if(Array.isArray(E)){A[v]===void 0&&(A[v]=[]);const w=A[v];let N=!1;for(let R=0;R<E.length;R++)f(E[R],w,R)===!0&&(N=!0);return N}return f(E,A,v)}function f(_,S,y){if(S[y]===void 0)return typeof _=="number"||typeof _=="boolean"?S[y]=_:ArrayBuffer.isView(_)?S[y]=_.slice():S[y]=_.clone(),!0;{const A=S[y];if(typeof _=="number"||typeof _=="boolean"){if(A!==_)return S[y]=_,!0}else{if(ArrayBuffer.isView(_))return!0;if(A.equals(_)===!1)return A.copy(_),!0}}return!1}function g(_){const S=_.uniforms;let y=0;const A=16;for(let v=0,w=S.length;v<w;v++){const N=Array.isArray(S[v])?S[v]:[S[v]];for(let R=0,L=N.length;R<L;R++){const F=N[R],V=Array.isArray(F.value)?F.value:[F.value],D=Array.isArray(S[v])||Array.isArray(F.value);let H=y;for(let k=0,tt=V.length;k<tt;k++){const W=V[k],j=x(W,D),Q=y%A,wt=Q%j.boundary,Bt=Q+wt;y+=wt,Bt!==0&&A-Bt<j.storage&&(y+=A-Bt),k===0&&(H=y),y+=j.storage}const q=F.type==="int"?Int32Array:F.type==="uint"?Uint32Array:Float32Array;F.__data=new q((y-H)/Float32Array.BYTES_PER_ELEMENT),F.__offset=H}}const E=y%A;return E>0&&(y+=A-E),_.__size=y,_.__cache={},this}function x(_,S){const y={boundary:0,storage:0};return typeof _=="number"||typeof _=="boolean"?(y.boundary=4,y.storage=4):_.isVector2?(y.boundary=8,y.storage=8):_.isVector3||_.isColor?(y.boundary=16,y.storage=12):_.isVector4?(y.boundary=16,y.storage=16):_.isMatrix3?(y.boundary=16,y.storage=48):_.isMatrix4?(y.boundary=16,y.storage=64):_.isTexture?Lt("WebGLRenderer: Texture samplers can not be part of an uniforms group."):ArrayBuffer.isView(_)?(y.boundary=16,y.storage=_.byteLength):Lt("WebGLRenderer: Unsupported uniform value type.",_),S===!0&&(y.boundary=16,y.storage=Math.ceil(y.storage/16)*16),y}function m(_){const S=_.target;S.removeEventListener("dispose",m),i.deleteBuffer(s[S.id]),delete s[S.id],delete r[S.id]}function p(){for(const _ in s)i.deleteBuffer(s[_]);s={},r={}}return{bind:a,update:o,dispose:p}}const qx=new Uint16Array([12469,15057,12620,14925,13266,14620,13807,14376,14323,13990,14545,13625,14713,13328,14840,12882,14931,12528,14996,12233,15039,11829,15066,11525,15080,11295,15085,10976,15082,10705,15073,10495,13880,14564,13898,14542,13977,14430,14158,14124,14393,13732,14556,13410,14702,12996,14814,12596,14891,12291,14937,11834,14957,11489,14958,11194,14943,10803,14921,10506,14893,10278,14858,9960,14484,14039,14487,14025,14499,13941,14524,13740,14574,13468,14654,13106,14743,12678,14818,12344,14867,11893,14889,11509,14893,11180,14881,10751,14852,10428,14812,10128,14765,9754,14712,9466,14764,13480,14764,13475,14766,13440,14766,13347,14769,13070,14786,12713,14816,12387,14844,11957,14860,11549,14868,11215,14855,10751,14825,10403,14782,10044,14729,9651,14666,9352,14599,9029,14967,12835,14966,12831,14963,12804,14954,12723,14936,12564,14917,12347,14900,11958,14886,11569,14878,11247,14859,10765,14828,10401,14784,10011,14727,9600,14660,9289,14586,8893,14508,8533,15111,12234,15110,12234,15104,12216,15092,12156,15067,12010,15028,11776,14981,11500,14942,11205,14902,10752,14861,10393,14812,9991,14752,9570,14682,9252,14603,8808,14519,8445,14431,8145,15209,11449,15208,11451,15202,11451,15190,11438,15163,11384,15117,11274,15055,10979,14994,10648,14932,10343,14871,9936,14803,9532,14729,9218,14645,8742,14556,8381,14461,8020,14365,7603,15273,10603,15272,10607,15267,10619,15256,10631,15231,10614,15182,10535,15118,10389,15042,10167,14963,9787,14883,9447,14800,9115,14710,8665,14615,8318,14514,7911,14411,7507,14279,7198,15314,9675,15313,9683,15309,9712,15298,9759,15277,9797,15229,9773,15166,9668,15084,9487,14995,9274,14898,8910,14800,8539,14697,8234,14590,7790,14479,7409,14367,7067,14178,6621,15337,8619,15337,8631,15333,8677,15325,8769,15305,8871,15264,8940,15202,8909,15119,8775,15022,8565,14916,8328,14804,8009,14688,7614,14569,7287,14448,6888,14321,6483,14088,6171,15350,7402,15350,7419,15347,7480,15340,7613,15322,7804,15287,7973,15229,8057,15148,8012,15046,7846,14933,7611,14810,7357,14682,7069,14552,6656,14421,6316,14251,5948,14007,5528,15356,5942,15356,5977,15353,6119,15348,6294,15332,6551,15302,6824,15249,7044,15171,7122,15070,7050,14949,6861,14818,6611,14679,6349,14538,6067,14398,5651,14189,5311,13935,4958,15359,4123,15359,4153,15356,4296,15353,4646,15338,5160,15311,5508,15263,5829,15188,6042,15088,6094,14966,6001,14826,5796,14678,5543,14527,5287,14377,4985,14133,4586,13869,4257,15360,1563,15360,1642,15358,2076,15354,2636,15341,3350,15317,4019,15273,4429,15203,4732,15105,4911,14981,4932,14836,4818,14679,4621,14517,4386,14359,4156,14083,3795,13808,3437,15360,122,15360,137,15358,285,15355,636,15344,1274,15322,2177,15281,2765,15215,3223,15120,3451,14995,3569,14846,3567,14681,3466,14511,3305,14344,3121,14037,2800,13753,2467,15360,0,15360,1,15359,21,15355,89,15346,253,15325,479,15287,796,15225,1148,15133,1492,15008,1749,14856,1882,14685,1886,14506,1783,14324,1608,13996,1398,13702,1183]);let $n=null;function Yx(){return $n===null&&($n=new bu(qx,16,16,Zi,jn),$n.name="DFG_LUT",$n.minFilter=en,$n.magFilter=en,$n.wrapS=hi,$n.wrapT=hi,$n.generateMipmaps=!1,$n.needsUpdate=!0),$n}class Kx{constructor(t={}){const{canvas:e=Qf(),context:n=null,depth:s=!0,stencil:r=!1,alpha:a=!1,antialias:o=!1,premultipliedAlpha:l=!0,preserveDrawingBuffer:c=!1,powerPreference:d="default",failIfMajorPerformanceCaveat:h=!1,reversedDepthBuffer:u=!1,outputBufferType:f=an}=t;this.isWebGLRenderer=!0;let g;if(n!==null){if(typeof WebGLRenderingContext<"u"&&n instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");g=n.getContextAttributes().alpha}else g=a;const x=f,m=new Set([rc,sc,ic]),p=new Set([an,Jn,vr,Bs,tc,ec]),_=new Uint32Array(4),S=new Int32Array(4),y={textures:[],min:[],max:[],resolution:[]};let A=null,E=null;const v=[],w=[];let N=null;this.domElement=e,this.debug={checkShaderErrors:!0,diagnostics:{keywords:!1},onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=mi,this.toneMappingExposure=1,this.transmissionResolutionScale=1;const R=this;let L=!1,F=null,V=null,D=null,H=null;this._outputColorSpace=He;let q=0,k=0,tt=null,W=-1,j=null;const Q=new _e,wt=new _e;let Bt=null;const K=new Nt(0);let mt=0,bt=e.width,Rt=e.height,vt=1,zt=null,Se=null;const Pt=new _e(0,0,bt,Rt),se=new _e(0,0,bt,Rt);let le=!1;const Xt=new yr,ke=new uc;let Te=!1,rn=!1;const ve=new jt,Hn=new I,De=new _e,gn={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let vn=!1;function xn(){return tt===null?vt:1}let U=n;function _n(M,P){return e.getContext(M,P)}let fe,pe,ut,Re,Ct,Ft,T,b,B,et,J,st,dt,X,Y,at,C,Z,$,ot,it,rt,At;try{const M={alpha:!0,depth:s,stencil:r,antialias:o,premultipliedAlpha:l,preserveDrawingBuffer:c,powerPreference:d,failIfMajorPerformanceCaveat:h};if("setAttribute"in e&&e.setAttribute("data-engine",`three.js r${Jl}`),e.addEventListener("webglcontextlost",Tt,!1),e.addEventListener("webglcontextrestored",Ht,!1),e.addEventListener("webglcontextcreationerror",ft,!1),U===null){const P="webgl2";if(U=_n(P,M),U===null)throw _n(P)?new Error("THREE.WebGLRenderer: Error creating WebGL context with your selected attributes."):new Error("THREE.WebGLRenderer: Error creating WebGL context.")}Gt()}catch(M){throw e.removeEventListener("webglcontextlost",Tt,!1),e.removeEventListener("webglcontextrestored",Ht,!1),e.removeEventListener("webglcontextcreationerror",ft,!1),ee("WebGLRenderer: "+M.message),M}function Gt(){fe=new jg(U),fe.init(),it=new kx(U,fe),pe=new Hg(U,fe,t,it),ut=new Ox(U,fe),pe.reversedDepthBuffer&&u&&ut.buffers.depth.setReversed(!0),V=U.createFramebuffer(),D=U.createFramebuffer(),H=U.createFramebuffer(),Re=new ev(U),Ct=new Sx,Ft=new Bx(U,fe,ut,Ct,pe,it,Re),T=new Jg(R),b=new im(U),rt=new kg(U,b),B=new Qg(U,b,Re,rt),et=new iv(U,B,b,rt,Re),Z=new nv(U,pe,Ft),Y=new Gg(Ct),J=new Mx(R,T,fe,pe,rt,Y),st=new Wx(R,Ct),dt=new Ex,X=new Lx(fe),C=new Bg(R,T,ut,et,g,l),at=new Fx(R,et,pe),At=new Xx(U,Re,pe,ut),$=new zg(U,fe,Re),ot=new tv(U,fe,Re),Re.programs=J.programs,R.capabilities=pe,R.extensions=fe,R.properties=Ct,R.renderLists=dt,R.shadowMap=at,R.state=ut,R.info=Re}x!==an&&(N=new rv(x,e.width,e.height,o,s,r));const nt=new Vx(R,U);this.xr=nt,this.getContext=function(){return U},this.getContextAttributes=function(){return U.getContextAttributes()},this.forceContextLoss=function(){const M=fe.get("WEBGL_lose_context");M&&M.loseContext()},this.forceContextRestore=function(){const M=fe.get("WEBGL_lose_context");M&&M.restoreContext()},this.getPixelRatio=function(){return vt},this.setPixelRatio=function(M){M!==void 0&&(vt=M,this.setSize(bt,Rt,!1))},this.getSize=function(M){return M.set(bt,Rt)},this.setSize=function(M,P,G=!0){if(nt.isPresenting){Lt("WebGLRenderer: Can't change size while VR device is presenting.");return}bt=M,Rt=P,e.width=Math.floor(M*vt),e.height=Math.floor(P*vt),G===!0&&(e.style.width=M+"px",e.style.height=P+"px"),N!==null&&N.setSize(e.width,e.height),this.setViewport(0,0,M,P)},this.getDrawingBufferSize=function(M){return M.set(bt*vt,Rt*vt).floor()},this.setDrawingBufferSize=function(M,P,G){bt=M,Rt=P,vt=G,e.width=Math.floor(M*G),e.height=Math.floor(P*G),this.setViewport(0,0,M,P)},this.setEffects=function(M){if(x===an){ee("WebGLRenderer: setEffects() requires outputBufferType set to HalfFloatType or FloatType.");return}if(M){for(let P=0;P<M.length;P++)if(M[P].isOutputPass===!0){Lt("WebGLRenderer: OutputPass is not needed in setEffects(). Tone mapping and color space conversion are applied automatically.");break}}N.setEffects(M||[])},this.getCurrentViewport=function(M){return M.copy(Q)},this.getViewport=function(M){return M.copy(Pt)},this.setViewport=function(M,P,G,O){M.isVector4?Pt.set(M.x,M.y,M.z,M.w):Pt.set(M,P,G,O),ut.viewport(Q.copy(Pt).multiplyScalar(xn()).round())},this.getScissor=function(M){return M.copy(se)},this.setScissor=function(M,P,G,O){M.isVector4?se.set(M.x,M.y,M.z,M.w):se.set(M,P,G,O),ut.scissor(wt.copy(se).multiplyScalar(xn()).round())},this.getScissorTest=function(){return le},this.setScissorTest=function(M){ut.setScissorTest(le=M)},this.setOpaqueSort=function(M){zt=M},this.setTransparentSort=function(M){Se=M},this.getClearColor=function(M){return M.copy(C.getClearColor())},this.setClearColor=function(){C.setClearColor(...arguments)},this.getClearAlpha=function(){return C.getClearAlpha()},this.setClearAlpha=function(){C.setClearAlpha(...arguments)},this.clear=function(M=!0,P=!0,G=!0){let O=0;if(M){let z=!1;if(tt!==null){const ht=tt.texture.format;z=m.has(ht)}if(z){const ht=tt.texture.type,_t=p.has(ht),lt=C.getClearColor(),xt=C.getClearAlpha(),Et=lt.r,kt=lt.g,qt=lt.b;_t?(_[0]=Et,_[1]=kt,_[2]=qt,_[3]=xt,U.clearBufferuiv(U.COLOR,0,_)):(S[0]=Et,S[1]=kt,S[2]=qt,S[3]=xt,U.clearBufferiv(U.COLOR,0,S))}else O|=U.COLOR_BUFFER_BIT}P&&(O|=U.DEPTH_BUFFER_BIT,this.state.buffers.depth.setMask(!0)),G&&(O|=U.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),O!==0&&U.clear(O)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.setNodesHandler=function(M){M.setRenderer(this),F=M},this.dispose=function(){e.removeEventListener("webglcontextlost",Tt,!1),e.removeEventListener("webglcontextrestored",Ht,!1),e.removeEventListener("webglcontextcreationerror",ft,!1),C.dispose(),dt.dispose(),X.dispose(),Ft.dispose(),Ct.dispose(),T.dispose(),et.dispose(),B.dispose(),rt.dispose(),At.dispose(),J.dispose(),nt.dispose(),nt.removeEventListener("sessionstart",Dc),nt.removeEventListener("sessionend",Ic),Bi.stop()};function Tt(M){M.preventDefault(),Na("WebGLRenderer: Context Lost."),L=!0}function Ht(){Na("WebGLRenderer: Context Restored."),L=!1;const M=Re.autoReset,P=at.enabled,G=at.autoUpdate,O=at.needsUpdate,z=at.type;Gt(),Re.autoReset=M,at.enabled=P,at.autoUpdate=G,at.needsUpdate=O,at.type=z}function ft(M){ee("WebGLRenderer: A WebGL context could not be created. Reason: ",M.statusMessage)}function re(M){const P=M.target;P.removeEventListener("dispose",re),Ie(P)}function Ie(M){yi(M),Ct.remove(M)}function yi(M){const P=Ct.get(M).programs;P!==void 0&&(P.forEach(function(G){J.releaseProgram(G)}),M.isShaderMaterial&&J.releaseShaderCache(M))}this.renderBufferDirect=function(M,P,G,O,z,ht){P===null&&(P=gn);const _t=z.isMesh&&z.matrixWorld.determinantAffine()<0,lt=ju(M,P,G,O,z);ut.setMaterial(O,_t);let xt=G.index,Et=1;if(O.wireframe===!0){if(xt=B.getWireframeAttribute(G),xt===void 0)return;Et=2}const kt=G.drawRange,qt=G.attributes.position;let Mt=kt.start*Et,Yt=(kt.start+kt.count)*Et;ht!==null&&(Mt=Math.max(Mt,ht.start*Et),Yt=Math.min(Yt,(ht.start+ht.count)*Et)),xt!==null?(Mt=Math.max(Mt,0),Yt=Math.min(Yt,xt.count)):qt!=null&&(Mt=Math.max(Mt,0),Yt=Math.min(Yt,qt.count));const we=Yt-Mt;if(we<0||we===1/0)return;rt.setup(z,O,lt,G,xt);let de,ce=$;if(xt!==null&&(de=b.get(xt),ce=ot,ce.setIndex(de)),z.isMesh)O.wireframe===!0?(ut.setLineWidth(O.wireframeLinewidth*xn()),ce.setMode(U.LINES)):ce.setMode(U.TRIANGLES);else if(z.isLine){let Ve=O.linewidth;Ve===void 0&&(Ve=1),ut.setLineWidth(Ve*xn()),z.isLineSegments?ce.setMode(U.LINES):z.isLineLoop?ce.setMode(U.LINE_LOOP):ce.setMode(U.LINE_STRIP)}else z.isPoints?ce.setMode(U.POINTS):z.isSprite&&ce.setMode(U.TRIANGLES);if(z.isBatchedMesh)if(fe.get("WEBGL_multi_draw"))ce.renderMultiDraw(z._multiDrawStarts,z._multiDrawCounts,z._multiDrawCount);else{const Ve=z._multiDrawStarts,St=z._multiDrawCounts,Ze=z._multiDrawCount,ie=xt?b.get(xt).bytesPerElement:1,ki=Ct.get(O).currentProgram.getUniforms();for(let $e=0;$e<Ze;$e++)ki.setValue(U,"_gl_DrawID",$e),ce.render(Ve[$e]/ie,St[$e])}else if(z.isInstancedMesh)ce.renderInstances(Mt,we,z.count);else if(G.isInstancedBufferGeometry){const Ve=G._maxInstanceCount!==void 0?G._maxInstanceCount:1/0,St=Math.min(G.instanceCount,Ve);ce.renderInstances(Mt,we,St)}else ce.render(Mt,we)};function Lc(M,P,G,O){F!==null&&M.isNodeMaterial&&F.setObject(O,M),Te===!0&&Y.setState(M,G,!1),M.transparent===!0&&M.side===Cn&&M.forceSinglePass===!1?(M.side=qe,M.needsUpdate=!0,Gs(M,P,O),M.side=Ki,M.needsUpdate=!0,Gs(M,P,O),M.side=Cn):Gs(M,P,O)}this.compile=function(M,P,G=null){G===null&&(G=M),F!==null&&F.renderStart(M,P,G),E=X.get(G),E.init(P),w.push(E),G.traverseVisible(function(z){z.isLight&&z.layers.test(P.layers)&&(E.pushLight(z),z.castShadow&&E.pushShadow(z))}),M!==G&&M.traverseVisible(function(z){z.isLight&&z.layers.test(P.layers)&&(E.pushLight(z),z.castShadow&&E.pushShadow(z))}),E.setupLights(),F!==null&&F.updateLights(E.state.lightsArray),rn=this.localClippingEnabled,Te=Y.init(this.clippingPlanes,rn),Te===!0&&Y.setGlobalState(this.clippingPlanes,P),F!==null&&at.render(E.state.shadowsArray,G,P);const O=new Set;return M.traverse(function(z){if(!(z.isMesh||z.isPoints||z.isLine||z.isSprite))return;const ht=z.material;if(ht)if(Array.isArray(ht))for(let _t=0;_t<ht.length;_t++){const lt=ht[_t];Lc(lt,G,P,z),O.add(lt)}else Lc(ht,G,P,z),O.add(ht)}),E=w.pop(),F!==null&&F.renderEnd(),O},this.compileAsync=function(M,P,G=null){const O=this.compile(M,P,G);return new Promise(z=>{function ht(){if(O.forEach(function(_t){const xt=Ct.get(_t).currentProgram;(xt===void 0||xt.isReady())&&O.delete(_t)}),O.size===0){z(M);return}setTimeout(ht,10)}fe.get("KHR_parallel_shader_compile")!==null?ht():setTimeout(ht,10)})};let no=null;function Zu(M){no&&no(M)}function Dc(){Bi.stop()}function Ic(){Bi.start()}const Bi=new Lu;Bi.setAnimationLoop(Zu),typeof self<"u"&&Bi.setContext(self),this.setAnimationLoop=function(M){no=M,nt.setAnimationLoop(M),M===null?Bi.stop():Bi.start()},nt.addEventListener("sessionstart",Dc),nt.addEventListener("sessionend",Ic),this.render=function(M,P){if(P!==void 0&&P.isCamera!==!0){ee("WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(L===!0)return;F!==null&&F.renderStart(M,P);const G=nt.enabled===!0&&nt.isPresenting===!0,O=N!==null&&(tt===null||G)&&N.begin(R,tt);if(M.matrixWorldAutoUpdate===!0&&M.updateMatrixWorld(),P.parent===null&&P.matrixWorldAutoUpdate===!0&&P.updateMatrixWorld(),nt.enabled===!0&&nt.isPresenting===!0&&(N===null||N.isCompositing()===!1)&&(nt.cameraAutoUpdate===!0&&nt.updateCamera(P),P=nt.getCamera()),M.isScene===!0&&M.onBeforeRender(R,M,P,tt),E=X.get(M,w.length),E.init(P),E.state.textureUnits=Ft.getTextureUnits(),w.push(E),ve.multiplyMatrices(P.projectionMatrix,P.matrixWorldInverse),P.isArrayCamera?ke.setFromArrayCamera(P):Xt.setFromProjectionMatrix(ve,Ln,P.reversedDepth),rn=this.localClippingEnabled,Te=Y.init(this.clippingPlanes,rn),A=dt.get(M,v.length),A.init(),v.push(A),this.info.render.frame++,nt.enabled===!0&&nt.isPresenting===!0){const _t=R.xr.getDepthSensingMesh();_t!==null&&io(_t,P,-1/0,R.sortObjects)}io(M,P,0,R.sortObjects),A.finish(),F!==null&&F.updateLights(E.state.lightsArray),R.sortObjects===!0&&A.sort(zt,Se),vn=nt.enabled===!1||nt.isPresenting===!1||nt.hasDepthSensing()===!1,vn&&C.addToRenderList(A,M),this.info.autoReset===!0&&this.info.reset(),Te===!0&&Y.beginShadows();const z=E.state.shadowsArray;if(at.render(z,M,P),Te===!0&&Y.endShadows(),(O&&N.hasRenderPass())===!1){const _t=A.opaque,lt=A.transmissive;if(E.setupLights(),P.isArrayCamera){const xt=P.cameras;if(lt.length>0)for(let Et=0,kt=xt.length;Et<kt;Et++){const qt=xt[Et];Uc(_t,lt,M,qt)}vn&&C.render(M);for(let Et=0,kt=xt.length;Et<kt;Et++){const qt=xt[Et];Nc(A,M,qt,qt.viewport)}}else lt.length>0&&Uc(_t,lt,M,P),vn&&C.render(M),Nc(A,M,P)}tt!==null&&k===0&&(Ft.updateMultisampleRenderTarget(tt),Ft.updateRenderTargetMipmap(tt)),O&&N.end(R),M.isScene===!0&&M.onAfterRender(R,M,P),rt.resetDefaultState(),W=-1,j=null,w.pop(),w.length>0?(E=w[w.length-1],Ft.setTextureUnits(E.state.textureUnits),Te===!0&&Y.setGlobalState(R.clippingPlanes,E.state.camera)):E=null,v.pop(),v.length>0?A=v[v.length-1]:A=null,F!==null&&F.renderEnd()};function io(M,P,G,O){if(M.visible===!1)return;if(M.layers.test(P.layers)){if(M.isGroup)G=M.renderOrder;else if(M.isLOD)M.autoUpdate===!0&&M.update(P);else if(M.isLight)E.pushLight(M),M.castShadow&&E.pushShadow(M);else if(M.isSprite){const _t=P.isArrayCamera?ke:Xt;if(!M.frustumCulled||M.intersectsFrustum(_t)){O&&De.setFromMatrixPosition(M.matrixWorld).applyMatrix4(ve);const lt=et.update(M),xt=M.material;xt.visible&&A.push(M,lt,xt,G,De.z,null,P)}}else if(M.isMesh||M.isLine||M.isPoints){const _t=P.isArrayCamera?ke:Xt;if(!M.frustumCulled||M.intersectsFrustum(_t)){const lt=et.update(M),xt=M.material;if(O&&(M.boundingSphere!==void 0?(M.boundingSphere===null&&M.computeBoundingSphere(),De.copy(M.boundingSphere.center)):(lt.boundingSphere===null&&lt.computeBoundingSphere(),De.copy(lt.boundingSphere.center)),De.applyMatrix4(M.matrixWorld).applyMatrix4(ve)),Array.isArray(xt)){const Et=lt.groups;for(let kt=0,qt=Et.length;kt<qt;kt++){const Mt=Et[kt],Yt=xt[Mt.materialIndex];Yt&&Yt.visible&&A.push(M,lt,Yt,G,De.z,Mt,P)}}else xt.visible&&A.push(M,lt,xt,G,De.z,null,P)}}}const ht=M.children;for(let _t=0,lt=ht.length;_t<lt;_t++)io(ht[_t],P,G,O)}function Nc(M,P,G,O){const{opaque:z,transmissive:ht,transparent:_t}=M;E.setupLightsView(G),Te===!0&&Y.setGlobalState(R.clippingPlanes,G),O&&ut.viewport(Q.copy(O)),z.length>0&&Ar(z,P,G),ht.length>0&&Ar(ht,P,G),_t.length>0&&Ar(_t,P,G),ut.buffers.depth.setTest(!0),ut.buffers.depth.setMask(!0),ut.buffers.color.setMask(!0),ut.setPolygonOffset(!1)}function Uc(M,P,G,O){if((G.isScene===!0?G.overrideMaterial:null)!==null)return;if(E.state.transmissionRenderTarget[O.id]===void 0){const Mt=fe.has("EXT_color_buffer_half_float")||fe.has("EXT_color_buffer_float");E.state.transmissionRenderTarget[O.id]=new Sn(1,1,{generateMipmaps:!0,type:Mt?jn:an,minFilter:ui,samples:Math.max(4,pe.samples),stencilBuffer:r,resolveDepthBuffer:!1,resolveStencilBuffer:!1,storeMultisampledDepthBuffer:!1,storeMultisampledStencilBuffer:!1,colorSpace:Jt.workingColorSpace})}const ht=E.state.transmissionRenderTarget[O.id],_t=O.viewport||Q;ht.setSize(_t.z*R.transmissionResolutionScale,_t.w*R.transmissionResolutionScale);const lt=R.getRenderTarget(),xt=R.getActiveCubeFace(),Et=R.getActiveMipmapLevel();R.setRenderTarget(ht),R.getClearColor(K),mt=R.getClearAlpha(),mt<1&&R.setClearColor(16777215,.5),R.clear(),vn&&C.render(G);const kt=R.toneMapping;R.toneMapping=mi;const qt=O.viewport;if(O.viewport!==void 0&&(O.viewport=void 0),E.setupLightsView(O),Te===!0&&Y.setGlobalState(R.clippingPlanes,O),Ar(M,G,O),Ft.updateMultisampleRenderTarget(ht),Ft.updateRenderTargetMipmap(ht),fe.has("WEBGL_multisampled_render_to_texture")===!1){let Mt=!1;for(let Yt=0,we=P.length;Yt<we;Yt++){const de=P[Yt],{object:ce,geometry:Ve,material:St,group:Ze}=de;if(St.side===Cn&&ce.layers.test(O.layers)){const ie=St.side;St.side=qe,St.needsUpdate=!0,Fc(ce,G,O,Ve,St,Ze),St.side=ie,St.needsUpdate=!0,Mt=!0}}Mt===!0&&(Ft.updateMultisampleRenderTarget(ht),Ft.updateRenderTargetMipmap(ht))}R.setRenderTarget(lt,xt,Et),R.setClearColor(K,mt),qt!==void 0&&(O.viewport=qt),R.toneMapping=kt}function Ar(M,P,G){const O=P.isScene===!0?P.overrideMaterial:null;for(let z=0,ht=M.length;z<ht;z++){const _t=M[z],{object:lt,geometry:xt,group:Et}=_t;let kt=_t.material;kt.allowOverride===!0&&O!==null&&(kt=O),lt.layers.test(G.layers)&&Fc(lt,P,G,xt,kt,Et)}}function Fc(M,P,G,O,z,ht){F!==null&&z.isNodeMaterial&&F.setObject(M,z),M.onBeforeRender(R,P,G,O,z,ht),M.modelViewMatrix.multiplyMatrices(G.matrixWorldInverse,M.matrixWorld),M.normalMatrix.getNormalMatrix(M.modelViewMatrix),z.onBeforeRender(R,P,G,O,M,ht),z.transparent===!0&&z.side===Cn&&z.forceSinglePass===!1?(z.side=qe,z.needsUpdate=!0,R.renderBufferDirect(G,P,O,z,M,ht),z.side=Ki,z.needsUpdate=!0,R.renderBufferDirect(G,P,O,z,M,ht),z.side=Cn):R.renderBufferDirect(G,P,O,z,M,ht),M.onAfterRender(R,P,G,O,z,ht)}function Oc(M){let P=0;for(const G of M)G.texture!==null&&P++;return P}function Gs(M,P,G){P.isScene!==!0&&(P=gn);const O=Ct.get(M),z=E.state.lights,ht=E.state.shadowsArray,_t=z.state.version,lt=J.getParameters(M,z.state,ht,P,G,E.state.lightProbeGridArray),xt=J.getProgramCacheKey(lt);let Et=O.programs;O.environment=M.isMeshStandardMaterial||M.isMeshLambertMaterial||M.isMeshPhongMaterial?P.environment:null,O.fog=P.fog;const kt=M.isMeshStandardMaterial||M.isMeshLambertMaterial&&!M.envMap||M.isMeshPhongMaterial&&!M.envMap;O.envMap=T.get(M.envMap||O.environment,kt),O.envMapRotation=O.environment!==null&&M.envMap===null?P.environmentRotation:M.envMapRotation,Et===void 0&&(M.addEventListener("dispose",re),Et=new Map,O.programs=Et,O.programVariants=new Map);let qt=Et.get(xt);if(qt!==void 0){if(O.currentProgram===qt&&O.lightsStateVersion===_t)return kc(M,lt),qt}else lt.uniforms=J.getUniforms(M),F!==null&&M.isNodeMaterial&&F.build(M,G,lt),M.onBeforeCompile(lt,R),qt=J.acquireProgram(lt,xt),Et.set(xt,qt),O.uniforms=lt.uniforms;const Mt=O.uniforms;return(!M.isShaderMaterial&&!M.isRawShaderMaterial||M.clipping===!0)&&(Mt.clippingPlanes=Y.uniform),kc(M,lt),O.needsLights=tf(M),O.lightsStateVersion=_t,O.needsLights&&(Mt.ambientLightColor.value=z.state.ambient,Mt.lightProbe.value=z.state.probe,Mt.sunLights.value=z.state.sun,Mt.sunLightShadows.value=z.state.sunShadow,Mt.directionalLights.value=z.state.directional,Mt.directionalLightShadows.value=z.state.directionalShadow,Mt.spotLights.value=z.state.spot,Mt.spotLightShadows.value=z.state.spotShadow,Mt.rectAreaLights.value=z.state.rectArea,Mt.ltc_1.value=z.state.rectAreaLTC1,Mt.ltc_2.value=z.state.rectAreaLTC2,Mt.pointLights.value=z.state.point,Mt.pointLightShadows.value=z.state.pointShadow,Mt.hemisphereLights.value=z.state.hemi,Mt.sunShadowMatrix.value=z.state.sunShadowMatrix,Mt.sunShadowCascade.value=z.state.sunShadowCascade,Mt.directionalShadowMatrix.value=z.state.directionalShadowMatrix,Mt.spotLightMatrix.value=z.state.spotLightMatrix,Mt.spotLightMap.value=z.state.spotLightMap,Mt.pointShadowMatrix.value=z.state.pointShadowMatrix),O.numLightProbeGrids=Oc(E.state.lightProbeGridArray),O.currentProgram=qt,O.uniformsList=null,qt}function Ju(M,P,G,O,z){const ht=Ct.get(M),_t=ht.currentProgram.id+","+O+","+z;let lt=ht.programVariants.get(_t);return lt===void 0?(lt=Gs(M,P,G),ht.programVariants.set(_t,lt)):(ht.currentProgram=lt,ht.uniformsList=null,ht.outputColorSpace=O,ht.toneMapping=z),lt}function Bc(M){if(M.uniformsList===null){const P=M.currentProgram.getUniforms();M.uniformsList=Sa.seqWithValue(P.seq,M.uniforms)}return M.uniformsList}function kc(M,P){const G=Ct.get(M);G.outputColorSpace=P.outputColorSpace,G.batching=P.batching,G.batchingColor=P.batchingColor,G.instancing=P.instancing,G.instancingColor=P.instancingColor,G.instancingMorph=P.instancingMorph,G.skinning=P.skinning,G.morphTargets=P.morphTargets,G.morphNormals=P.morphNormals,G.morphColors=P.morphColors,G.morphTargetsCount=P.morphTargetsCount,G.numClippingPlanes=P.numClippingPlanes,G.numIntersection=P.numClipIntersection,G.vertexAlphas=P.vertexAlphas,G.vertexTangents=P.vertexTangents,G.toneMapping=P.toneMapping}function ju(M,P,G,O,z){P.isScene!==!0&&(P=gn),Ft.resetTextureUnits();const ht=P.fog,_t=O.isMeshStandardMaterial||O.isMeshLambertMaterial||O.isMeshPhongMaterial?P.environment:null,lt=tt===null?R.outputColorSpace:tt.isXRRenderTarget===!0?tt.texture.colorSpace:Jt.workingColorSpace,xt=O.isMeshStandardMaterial||O.isMeshLambertMaterial&&!O.envMap||O.isMeshPhongMaterial&&!O.envMap,Et=T.get(O.envMap||_t,xt),kt=O.vertexColors===!0&&!!G.attributes.color&&G.attributes.color.itemSize===4,qt=!!G.attributes.tangent&&(!!O.normalMap||O.anisotropy>0),Mt=!!G.morphAttributes.position,Yt=!!G.morphAttributes.normal,we=!!G.morphAttributes.color;let de=mi;O.toneMapped&&(tt===null||tt.isXRRenderTarget===!0)&&(de=R.toneMapping);const ce=G.morphAttributes.position||G.morphAttributes.normal||G.morphAttributes.color,Ve=ce!==void 0?ce.length:0,St=Ct.get(O),Ze=E.state.lights;if(Te===!0&&(rn===!0||M!==j)){const xe=M===j&&O.id===W;Y.setState(O,M,xe)}let ie=!1,ki=!1;O.version===St.__version?St.needsLights&&St.lightsStateVersion!==Ze.state.version||z.isBatchedMesh&&St.batching===!1||!z.isBatchedMesh&&St.batching===!0||z.isBatchedMesh&&St.batchingColor===!0&&z._colorsTexture===null||z.isBatchedMesh&&St.batchingColor===!1&&z._colorsTexture!==null||z.isInstancedMesh&&St.instancing===!1||!z.isInstancedMesh&&St.instancing===!0||z.isSkinnedMesh&&St.skinning===!1||!z.isSkinnedMesh&&St.skinning===!0||z.isInstancedMesh&&St.instancingColor===!0&&z.instanceColor===null||z.isInstancedMesh&&St.instancingColor===!1&&z.instanceColor!==null||z.isInstancedMesh&&St.instancingMorph===!0&&z.morphTexture===null||z.isInstancedMesh&&St.instancingMorph===!1&&z.morphTexture!==null||St.envMap!==Et||O.fog===!0&&St.fog!==ht||St.numClippingPlanes!==void 0&&(St.numClippingPlanes!==Y.numPlanes||St.numIntersection!==Y.numIntersection)||St.vertexAlphas!==kt||St.vertexTangents!==qt||St.morphTargets!==Mt||St.morphNormals!==Yt||St.morphColors!==we||St.morphTargetsCount!==Ve||St.numLightProbeGrids!==Oc(E.state.lightProbeGridArray)?ie=!0:(St.outputColorSpace!==lt||St.toneMapping!==de)&&(ki=!0):(ie=!0,St.__version=O.version);let $e=St.currentProgram;(ie===!0||ki===!0)&&($e=ki===!0?Ju(O,P,z,lt,de):Gs(O,P,z),F&&O.isNodeMaterial&&F.onUpdateProgram(O,$e,St));let Tr=!1,bi=!1,zi=!1;const te=$e.getUniforms(),ze=St.uniforms;if(ut.useProgram($e.program)&&(Tr=!0,bi=!0,zi=!0),O.id!==W&&(W=O.id,bi=!0),Tr||j!==M){ut.buffers.depth.getReversed()&&M.reversedDepth!==!0&&(M._reversedDepth=!0,M.updateProjectionMatrix()),te.setValue(U,"projectionMatrix",M.projectionMatrix),te.setValue(U,"viewMatrix",M.matrixWorldInverse);const Ne=te.map.cameraPosition;Ne!==void 0&&Ne.setValue(U,Hn.setFromMatrixPosition(M.matrixWorld)),pe.logarithmicDepthBuffer&&te.setValue(U,"logDepthBufFC",2/(Math.log(M.far+1)/Math.LN2)),(O.isMeshPhongMaterial||O.isMeshToonMaterial||O.isMeshLambertMaterial||O.isMeshBasicMaterial||O.isMeshStandardMaterial||O.isShaderMaterial)&&te.setValue(U,"isOrthographic",M.isOrthographicCamera===!0),j!==M&&(j=M,bi=!0,zi=!0)}if(St.needsLights&&(Ze.state.sunShadowMap.length>0&&te.setValue(U,"sunShadowMap",Ze.state.sunShadowMap,Ft),Ze.state.directionalShadowMap.length>0&&te.setValue(U,"directionalShadowMap",Ze.state.directionalShadowMap,Ft),Ze.state.spotShadowMap.length>0&&te.setValue(U,"spotShadowMap",Ze.state.spotShadowMap,Ft),Ze.state.pointShadowMap.length>0&&te.setValue(U,"pointShadowMap",Ze.state.pointShadowMap,Ft)),z.isSkinnedMesh){te.setOptional(U,z,"bindMatrix"),te.setOptional(U,z,"bindMatrixInverse");const xe=z.skeleton;xe&&(xe.boneTexture===null&&xe.computeBoneTexture(),te.setValue(U,"boneTexture",xe.boneTexture,Ft))}z.isBatchedMesh&&(te.setOptional(U,z,"batchingTexture"),te.setValue(U,"batchingTexture",z._matricesTexture,Ft),te.setOptional(U,z,"batchingIdTexture"),te.setValue(U,"batchingIdTexture",z._indirectTexture,Ft),te.setOptional(U,z,"batchingColorTexture"),z._colorsTexture!==null&&te.setValue(U,"batchingColorTexture",z._colorsTexture,Ft));const wn=G.morphAttributes;if((wn.position!==void 0||wn.normal!==void 0||wn.color!==void 0)&&Z.update(z,G,$e),(bi||St.receiveShadow!==z.receiveShadow)&&(St.receiveShadow=z.receiveShadow,te.setValue(U,"receiveShadow",z.receiveShadow)),(O.isMeshStandardMaterial||O.isMeshLambertMaterial||O.isMeshPhongMaterial)&&O.envMap===null&&P.environment!==null&&(ze.envMapIntensity.value=P.environmentIntensity),ze.dfgLUT!==void 0&&(ze.dfgLUT.value=Yx()),bi){if(te.setValue(U,"toneMappingExposure",R.toneMappingExposure),St.needsLights&&Qu(ze,zi),ht&&O.fog===!0&&st.refreshFogUniforms(ze,ht),st.refreshMaterialUniforms(ze,O,vt,Rt,E.state.transmissionRenderTarget[M.id]),St.needsLights&&St.numLightProbeGrids>0){const xe=y;let Ne=0;for(const ti of E.state.lightProbeGridArray)ti.texture!==null&&(xe.textures[Ne]=ti.texture,xe.min[Ne]=ti.boundingBox.min,xe.max[Ne]=ti.boundingBox.max,xe.resolution[Ne]=ti.resolution,Ne++);for(const ti in xe)xe[ti].length=Ne;ze.probesSH.value=xe.textures,ze.probesMin.value=xe.min,ze.probesMax.value=xe.max,ze.probesResolution.value=xe.resolution}Sa.upload(U,Bc(St),ze,Ft)}if(O.isShaderMaterial&&O.uniformsNeedUpdate===!0&&(Sa.upload(U,Bc(St),ze,Ft),O.uniformsNeedUpdate=!1),O.isSpriteMaterial&&te.setValue(U,"center",z.center),te.setValue(U,"modelViewMatrix",z.modelViewMatrix),te.setValue(U,"normalMatrix",z.normalMatrix),te.setValue(U,"modelMatrix",z.matrixWorld),O.uniformsGroups!==void 0){const xe=O.uniformsGroups;for(let Ne=0,ti=xe.length;Ne<ti;Ne++){const Hc=xe[Ne];At.update(Hc,$e),At.bind(Hc,$e)}}return $e}function Qu(M,P){M.ambientLightColor.needsUpdate=P,M.lightProbe.needsUpdate=P,M.sunLights.needsUpdate=P,M.sunLightShadows.needsUpdate=P,M.directionalLights.needsUpdate=P,M.directionalLightShadows.needsUpdate=P,M.pointLights.needsUpdate=P,M.pointLightShadows.needsUpdate=P,M.spotLights.needsUpdate=P,M.spotLightShadows.needsUpdate=P,M.rectAreaLights.needsUpdate=P,M.hemisphereLights.needsUpdate=P}function tf(M){return M.isMeshLambertMaterial||M.isMeshToonMaterial||M.isMeshPhongMaterial||M.isMeshStandardMaterial||M.isShadowMaterial||M.isShaderMaterial&&M.lights===!0}this.getActiveCubeFace=function(){return q},this.getActiveMipmapLevel=function(){return k},this.getRenderTarget=function(){return tt},this.setRenderTargetTextures=function(M,P,G){const O=Ct.get(M);O.__autoAllocateDepthBuffer=M.resolveDepthBuffer===!1,O.__autoAllocateDepthBuffer===!1&&(O.__useRenderToTexture=!1),Ct.get(M.texture).__webglTexture=P,Ct.get(M.depthTexture).__webglTexture=O.__autoAllocateDepthBuffer?void 0:G,O.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(M,P){const G=Ct.get(M);G.__webglFramebuffer=P,G.__useDefaultFramebuffer=P===void 0},this.setRenderTarget=function(M,P=0,G=0){tt=M,q=P,k=G;let O=null,z=!1,ht=!1;if(M){const lt=Ct.get(M);if(lt.__useDefaultFramebuffer!==void 0){ut.bindFramebuffer(U.FRAMEBUFFER,lt.__webglFramebuffer),Q.copy(M.viewport),wt.copy(M.scissor),Bt=M.scissorTest,ut.viewport(Q),ut.scissor(wt),ut.setScissorTest(Bt),W=-1;return}else if(lt.__webglFramebuffer===void 0)Ft.setupRenderTarget(M);else if(lt.__hasExternalTextures)Ft.rebindTextures(M,Ct.get(M.texture).__webglTexture,Ct.get(M.depthTexture).__webglTexture);else if(M.depthBuffer){const kt=M.depthTexture;if(lt.__boundDepthTexture!==kt){if(kt!==null&&Ct.has(kt)&&(M.width!==kt.image.width||M.height!==kt.image.height))throw new Error("THREE.WebGLRenderer: Attached DepthTexture is initialized to the incorrect size.");Ft.setupDepthRenderbuffer(M)}}const xt=M.texture;(xt.isData3DTexture||xt.isDataArrayTexture||xt.isCompressedArrayTexture)&&(ht=!0);const Et=Ct.get(M).__webglFramebuffer;M.isWebGLCubeRenderTarget?(Array.isArray(Et[P])?O=Et[P][G]:O=Et[P],z=!0):M.samples>0&&Ft.useMultisampledRTT(M)===!1?O=Ct.get(M).__webglMultisampledFramebuffer:Array.isArray(Et)?O=Et[G]:O=Et,Q.copy(M.viewport),wt.copy(M.scissor),Bt=M.scissorTest}else Q.copy(Pt).multiplyScalar(vt).floor(),wt.copy(se).multiplyScalar(vt).floor(),Bt=le;if(G!==0&&(O=V),ut.bindFramebuffer(U.FRAMEBUFFER,O)&&ut.drawBuffers(M,O),ut.viewport(Q),ut.scissor(wt),ut.setScissorTest(Bt),z){const lt=Ct.get(M.texture);U.framebufferTexture2D(U.FRAMEBUFFER,U.COLOR_ATTACHMENT0,U.TEXTURE_CUBE_MAP_POSITIVE_X+P,lt.__webglTexture,G)}else if(ht){const lt=P;for(let xt=0;xt<M.textures.length;xt++){const Et=Ct.get(M.textures[xt]);U.framebufferTextureLayer(U.FRAMEBUFFER,U.COLOR_ATTACHMENT0+xt,Et.__webglTexture,G,lt)}}else if(M!==null&&G!==0){const lt=Ct.get(M.texture);U.framebufferTexture2D(U.FRAMEBUFFER,U.COLOR_ATTACHMENT0,U.TEXTURE_2D,lt.__webglTexture,G)}W=-1};function zc(M){const P=Ct.get(M);return(P.__readFormat!==M.format||P.__readType!==M.type)&&(P.__readFormat=M.format,P.__readType=M.type,P.__formatReadable=pe.textureFormatReadable(M.format),P.__typeReadable=pe.textureTypeReadable(M.type)),P}this.readRenderTargetPixels=function(M,P,G,O,z,ht,_t,lt=0){if(!(M&&M.isWebGLRenderTarget)){ee("WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let xt=Ct.get(M).__webglFramebuffer;if(M.isWebGLCubeRenderTarget&&_t!==void 0&&(xt=xt[_t],Array.isArray(xt)&&(xt=xt[0])),xt){ut.bindFramebuffer(U.FRAMEBUFFER,xt);try{const Et=M.textures[lt],kt=Et.format,qt=Et.type;M.textures.length>1&&U.readBuffer(U.COLOR_ATTACHMENT0+lt);const Mt=zc(Et);if(Mt.__formatReadable===!1){ee("WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(Mt.__typeReadable===!1){ee("WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}P>=0&&P<=M.width-O&&G>=0&&G<=M.height-z&&U.readPixels(P,G,O,z,it.convert(kt),it.convert(qt),ht)}finally{const Et=tt!==null?Ct.get(tt).__webglFramebuffer:null;ut.bindFramebuffer(U.FRAMEBUFFER,Et)}}},this.readRenderTargetPixelsAsync=async function(M,P,G,O,z,ht,_t,lt=0){if(!(M&&M.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let xt=Ct.get(M).__webglFramebuffer;if(M.isWebGLCubeRenderTarget&&_t!==void 0&&(xt=xt[_t],Array.isArray(xt)&&(xt=xt[0])),xt)if(P>=0&&P<=M.width-O&&G>=0&&G<=M.height-z){ut.bindFramebuffer(U.FRAMEBUFFER,xt);const Et=M.textures[lt],kt=Et.format,qt=Et.type;M.textures.length>1&&U.readBuffer(U.COLOR_ATTACHMENT0+lt);const Mt=zc(Et);if(Mt.__formatReadable===!1)throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(Mt.__typeReadable===!1)throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");const Yt=U.createBuffer();U.bindBuffer(U.PIXEL_PACK_BUFFER,Yt),U.bufferData(U.PIXEL_PACK_BUFFER,ht.byteLength,U.STREAM_READ),U.readPixels(P,G,O,z,it.convert(kt),it.convert(qt),0),U.bindBuffer(U.PIXEL_PACK_BUFFER,null);const we=tt!==null?Ct.get(tt).__webglFramebuffer:null;ut.bindFramebuffer(U.FRAMEBUFFER,we);const de=U.fenceSync(U.SYNC_GPU_COMMANDS_COMPLETE,0);return U.flush(),await tp(U,de,4),U.bindBuffer(U.PIXEL_PACK_BUFFER,Yt),U.getBufferSubData(U.PIXEL_PACK_BUFFER,0,ht),U.bindBuffer(U.PIXEL_PACK_BUFFER,null),U.deleteBuffer(Yt),U.deleteSync(de),ht}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")},this.copyFramebufferToTexture=function(M,P=null,G=0){const O=Math.pow(2,-G),z=Math.floor(M.image.width*O),ht=Math.floor(M.image.height*O),_t=P!==null?P.x:0,lt=P!==null?P.y:0;Ft.setTexture2D(M,0),U.copyTexSubImage2D(U.TEXTURE_2D,G,0,0,_t,lt,z,ht),ut.unbindTexture()},this.copyTextureToTexture=function(M,P,G=null,O=null,z=0,ht=0){let _t,lt,xt,Et,kt,qt,Mt,Yt,we;const de=M.isCompressedTexture?M.mipmaps[ht]:M.image;if(G!==null)_t=G.max.x-G.min.x,lt=G.max.y-G.min.y,xt=G.isBox3?G.max.z-G.min.z:1,Et=G.min.x,kt=G.min.y,qt=G.isBox3?G.min.z:0;else{const te=Math.pow(2,-z);_t=Math.floor(de.width*te),lt=Math.floor(de.height*te),M.isDataArrayTexture?xt=de.depth:M.isData3DTexture?xt=Math.floor(de.depth*te):xt=1,Et=0,kt=0,qt=0}O!==null?(Mt=O.x,Yt=O.y,we=O.z):(Mt=0,Yt=0,we=0);const ce=it.convert(P.format),Ve=it.convert(P.type);let St;P.isData3DTexture?(Ft.setTexture3D(P,0),St=U.TEXTURE_3D):P.isDataArrayTexture||P.isCompressedArrayTexture?(Ft.setTexture2DArray(P,0),St=U.TEXTURE_2D_ARRAY):(Ft.setTexture2D(P,0),St=U.TEXTURE_2D),ut.activeTexture(U.TEXTURE0),ut.pixelStorei(U.UNPACK_FLIP_Y_WEBGL,P.flipY),ut.pixelStorei(U.UNPACK_PREMULTIPLY_ALPHA_WEBGL,P.premultiplyAlpha),ut.pixelStorei(U.UNPACK_ALIGNMENT,P.unpackAlignment);const Ze=ut.getParameter(U.UNPACK_ROW_LENGTH),ie=ut.getParameter(U.UNPACK_IMAGE_HEIGHT),ki=ut.getParameter(U.UNPACK_SKIP_PIXELS),$e=ut.getParameter(U.UNPACK_SKIP_ROWS),Tr=ut.getParameter(U.UNPACK_SKIP_IMAGES);ut.pixelStorei(U.UNPACK_ROW_LENGTH,de.width),ut.pixelStorei(U.UNPACK_IMAGE_HEIGHT,de.height),ut.pixelStorei(U.UNPACK_SKIP_PIXELS,Et),ut.pixelStorei(U.UNPACK_SKIP_ROWS,kt),ut.pixelStorei(U.UNPACK_SKIP_IMAGES,qt);const bi=M.isDataArrayTexture||M.isData3DTexture,zi=P.isDataArrayTexture||P.isData3DTexture;if(M.isDepthTexture){const te=Ct.get(M),ze=Ct.get(P),wn=Ct.get(te.__renderTarget),xe=Ct.get(ze.__renderTarget);ut.bindFramebuffer(U.READ_FRAMEBUFFER,wn.__webglFramebuffer),ut.bindFramebuffer(U.DRAW_FRAMEBUFFER,xe.__webglFramebuffer);for(let Ne=0;Ne<xt;Ne++)bi&&(U.framebufferTextureLayer(U.READ_FRAMEBUFFER,U.COLOR_ATTACHMENT0,Ct.get(M).__webglTexture,z,qt+Ne),U.framebufferTextureLayer(U.DRAW_FRAMEBUFFER,U.COLOR_ATTACHMENT0,Ct.get(P).__webglTexture,ht,we+Ne)),U.blitFramebuffer(Et,kt,Et+_t,kt+lt,Mt,Yt,Mt+_t,Yt+lt,U.DEPTH_BUFFER_BIT,U.NEAREST);ut.bindFramebuffer(U.READ_FRAMEBUFFER,null),ut.bindFramebuffer(U.DRAW_FRAMEBUFFER,null)}else if(z!==0||M.isRenderTargetTexture||Ct.has(M)){const te=Ct.get(M),ze=Ct.get(P);ut.bindFramebuffer(U.READ_FRAMEBUFFER,D),ut.bindFramebuffer(U.DRAW_FRAMEBUFFER,H);for(let wn=0;wn<xt;wn++)bi?U.framebufferTextureLayer(U.READ_FRAMEBUFFER,U.COLOR_ATTACHMENT0,te.__webglTexture,z,qt+wn):U.framebufferTexture2D(U.READ_FRAMEBUFFER,U.COLOR_ATTACHMENT0,U.TEXTURE_2D,te.__webglTexture,z),zi?U.framebufferTextureLayer(U.DRAW_FRAMEBUFFER,U.COLOR_ATTACHMENT0,ze.__webglTexture,ht,we+wn):U.framebufferTexture2D(U.DRAW_FRAMEBUFFER,U.COLOR_ATTACHMENT0,U.TEXTURE_2D,ze.__webglTexture,ht),z!==0?U.blitFramebuffer(Et,kt,Et+_t,kt+lt,Mt,Yt,Mt+_t,Yt+lt,U.COLOR_BUFFER_BIT,U.NEAREST):zi?U.copyTexSubImage3D(St,ht,Mt,Yt,we+wn,Et,kt,_t,lt):U.copyTexSubImage2D(St,ht,Mt,Yt,Et,kt,_t,lt);ut.bindFramebuffer(U.READ_FRAMEBUFFER,null),ut.bindFramebuffer(U.DRAW_FRAMEBUFFER,null)}else zi?M.isDataTexture||M.isData3DTexture?U.texSubImage3D(St,ht,Mt,Yt,we,_t,lt,xt,ce,Ve,de.data):P.isCompressedArrayTexture?U.compressedTexSubImage3D(St,ht,Mt,Yt,we,_t,lt,xt,ce,de.data):U.texSubImage3D(St,ht,Mt,Yt,we,_t,lt,xt,ce,Ve,de):M.isDataTexture?U.texSubImage2D(U.TEXTURE_2D,ht,Mt,Yt,_t,lt,ce,Ve,de.data):M.isCompressedTexture?U.compressedTexSubImage2D(U.TEXTURE_2D,ht,Mt,Yt,de.width,de.height,ce,de.data):U.texSubImage2D(U.TEXTURE_2D,ht,Mt,Yt,_t,lt,ce,Ve,de);ut.pixelStorei(U.UNPACK_ROW_LENGTH,Ze),ut.pixelStorei(U.UNPACK_IMAGE_HEIGHT,ie),ut.pixelStorei(U.UNPACK_SKIP_PIXELS,ki),ut.pixelStorei(U.UNPACK_SKIP_ROWS,$e),ut.pixelStorei(U.UNPACK_SKIP_IMAGES,Tr),ht===0&&P.generateMipmaps===!0&&P.mipmapsAutoUpdate===!0&&U.generateMipmap(St),ut.unbindTexture()},this.initRenderTarget=function(M){Ct.get(M).__webglFramebuffer===void 0&&Ft.setupRenderTarget(M)},this.initTexture=function(M){M.isCubeTexture?Ft.setTextureCube(M,0):M.isData3DTexture?Ft.setTexture3D(M,0):M.isDataArrayTexture||M.isCompressedArrayTexture?Ft.setTexture2DArray(M,0):Ft.setTexture2D(M,0),ut.unbindTexture()},this.resetState=function(){q=0,k=0,tt=null,ut.reset(),rt.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return Ln}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(t){this._outputColorSpace=t;const e=this.getContext();e.drawingBufferColorSpace=Jt._getDrawingBufferColorSpace(t),e.unpackColorSpace=Jt._getUnpackColorSpace()}}const Zx=`
vec3 mod289(vec3 x){return x-floor(x*(1.0/289.0))*289.0;} vec4 mod289(vec4 x){return x-floor(x*(1.0/289.0))*289.0;}
vec4 permute(vec4 x){return mod289(((x*34.0)+1.0)*x);} vec4 taylorInvSqrt(vec4 r){return 1.79284291400159-0.85373472095314*r;}
float snoise(vec3 v){ const vec2 C=vec2(1.0/6.0,1.0/3.0); const vec4 D=vec4(0.0,0.5,1.0,2.0);
  vec3 i=floor(v+dot(v,C.yyy)); vec3 x0=v-i+dot(i,C.xxx); vec3 g=step(x0.yzx,x0.xyz); vec3 l=1.0-g; vec3 i1=min(g.xyz,l.zxy); vec3 i2=max(g.xyz,l.zxy);
  vec3 x1=x0-i1+C.xxx; vec3 x2=x0-i2+C.yyy; vec3 x3=x0-D.yyy; i=mod289(i);
  vec4 p=permute(permute(permute(i.z+vec4(0.0,i1.z,i2.z,1.0))+i.y+vec4(0.0,i1.y,i2.y,1.0))+i.x+vec4(0.0,i1.x,i2.x,1.0));
  float n_=0.142857142857; vec3 ns=n_*D.wyz-D.xzx; vec4 j=p-49.0*floor(p*ns.z*ns.z); vec4 x_=floor(j*ns.z); vec4 y_=floor(j-7.0*x_);
  vec4 x=x_*ns.x+ns.yyyy; vec4 y=y_*ns.x+ns.yyyy; vec4 h=1.0-abs(x)-abs(y); vec4 b0=vec4(x.xy,y.xy); vec4 b1=vec4(x.zw,y.zw);
  vec4 s0=floor(b0)*2.0+1.0; vec4 s1=floor(b1)*2.0+1.0; vec4 sh=-step(h,vec4(0.0)); vec4 a0=b0.xzyw+s0.xzyw*sh.xxyy; vec4 a1=b1.xzyw+s1.xzyw*sh.zzww;
  vec3 p0=vec3(a0.xy,h.x); vec3 p1=vec3(a0.zw,h.y); vec3 p2=vec3(a1.xy,h.z); vec3 p3=vec3(a1.zw,h.w);
  vec4 norm=taylorInvSqrt(vec4(dot(p0,p0),dot(p1,p1),dot(p2,p2),dot(p3,p3))); p0*=norm.x; p1*=norm.y; p2*=norm.z; p3*=norm.w;
  vec4 m=max(0.6-vec4(dot(x0,x0),dot(x1,x1),dot(x2,x2),dot(x3,x3)),0.0); m=m*m;
  return 42.0*dot(m*m,vec4(dot(p0,x0),dot(p1,x1),dot(p2,x2),dot(p3,x3))); }
float fbm(vec3 p, int oct){ float s=0.0, a=0.5; for(int i=0;i<8;i++){ if(i>=oct) break; s+=a*snoise(p); p=p*2.03+vec3(1.7,9.2,3.1); a*=0.5; } return s; }
vec3 hash3(vec3 p){ p=fract(p*vec3(0.1031,0.1030,0.0973)); p+=dot(p,p.yxz+33.33); return fract((p.xxy+p.yxx)*p.zyx); }
float craters(vec3 p){ vec3 i=floor(p), f=fract(p); float c=0.0; for(int x=-1;x<=1;x++) for(int y=-1;y<=1;y++) for(int z=-1;z<=1;z++){ vec3 o=vec3(float(x),float(y),float(z)); vec3 h=hash3(i+o); vec3 d=o+h-f; float r=0.15+0.3*h.x; float dd=length(d)/r; if(dd<1.0){ c+= (dd<0.8? -0.6*(1.0-dd*dd*1.4) : 0.0) + (dd>=0.75 ? 0.5*(1.0-abs(dd-0.88)/0.13) : 0.0); } } return c; }`,Jx="varying vec2 vUv; void main(){ vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }",jx=`precision highp float; varying vec2 vUv; uniform int uMode; uniform float uSeed;
${Zx}
vec3 dirOf(vec2 uv){ float lon = (uv.x - 0.5) * 6.2831853; float lat = (uv.y - 0.5) * 3.1415926; return vec3(cos(lat)*cos(lon), sin(lat), cos(lat)*sin(lon)); }
void main(){ vec3 n = dirOf(vUv); vec3 p = n*1.2 + vec3(uSeed*7.31, uSeed*3.17, uSeed*1.91);
  if (uMode == 0) { // Earth albedo (rgb) + water mask (a)
    float h = fbm(p*1.6, 7) + 0.35*fbm(p*5.0, 4); float wl = 0.02; vec3 col; float water = 0.0;
    if (h < wl) { float dpt = clamp((wl-h)*3.0, 0.0, 1.0); col = mix(vec3(0.12,0.42,0.65), vec3(0.04,0.16,0.36), dpt); water = 1.0; }
    else { float e = clamp((h-wl)/0.73, 0.0, 1.0); float dry = smoothstep(0.1, 0.5, snoise(p*1.3+4.0)*0.5+0.5) * (1.0-abs(n.y));
      vec3 green = mix(vec3(0.20,0.45,0.18), vec3(0.62,0.55,0.34), dry); col = e < 0.45 ? mix(green, vec3(0.55,0.5,0.36), e/0.45) : mix(vec3(0.55,0.5,0.36), vec3(0.92,0.9,0.86), (e-0.45)/0.55); }
    float lat = abs(n.y) + 0.06*snoise(p*2.0); float ice = smoothstep(0.84, 0.89, lat); col = mix(col, vec3(0.94,0.96,1.0), ice); water *= 1.0-ice;
    gl_FragColor = vec4(col, water); }
  else if (uMode == 1) { // clouds (r), city lights (g)
    float cl = smoothstep(0.36, 0.78, fbm(n*2.2 + vec3(uSeed), 6)*0.5+0.5); cl = max(cl, smoothstep(0.55, 0.9, fbm(n*vec3(1.0,3.5,1.0)*2.0+3.0, 4)*0.5+0.5)*0.8*(1.0-abs(n.y)));
    float h = fbm(p*1.6, 7) + 0.35*fbm(p*5.0, 4); float land = smoothstep(0.03, 0.12, h-0.02);
    float region = smoothstep(0.55, 0.8, snoise(p*5.0)*0.5+0.5); float dots = smoothstep(0.6, 0.9, snoise(p*70.0)*0.5+0.5) + 0.35*smoothstep(0.7, 0.95, snoise(p*26.0)*0.5+0.5);
    gl_FragColor = vec4(cl, region*dots*land*(1.0-smoothstep(0.75, 0.9, abs(n.y))), 0.0, 1.0); }
  else if (uMode == 2) { // Moon albedo
    float h = fbm(p*1.6, 6)*0.6 + craters(n*6.0+uSeed)*0.5 + craters(n*15.0+uSeed*2.0)*0.25; float mare = smoothstep(0.1, -0.2, fbm(p*0.9+2.0, 4));
    vec3 col = mix(vec3(0.62,0.61,0.59), vec3(0.36,0.36,0.37), mare) * (0.8 + h*0.35); gl_FragColor = vec4(col, 1.0); }
  else { // nebula sky
    float n1 = fbm(n*1.8 + 1.3, 5)*0.5+0.5; float n2 = fbm(n*4.0 + 3.0, 4)*0.5+0.5; vec3 col = vec3(0.004,0.006,0.016) + vec3(0.12,0.22,0.5)*pow(n1, 3.4)*0.6 + vec3(0.25,0.08,0.3)*pow(n2, 4.0)*0.5;
    float band = exp(-pow(n.y*3.2 + 0.4*snoise(n*3.0), 2.0)); col += vec3(0.16,0.15,0.2)*band*(0.5+0.5*n1);
    gl_FragColor = vec4(col, 1.0); } }`;function ca(i,t,e,n,s=1){const r=new Sn(e,n,{type:an,generateMipmaps:!0,minFilter:ui,magFilter:en,wrapS:Ra}),a=new hc,o=new gc(-1,1,1,-1,0,1),l=new Un({vertexShader:Jx,fragmentShader:jx,uniforms:{uMode:{value:t},uSeed:{value:s}}}),c=new $t(new rs(2,2),l);a.add(c);const d=i.getRenderTarget();return i.setRenderTarget(r),i.render(a,o),i.setRenderTarget(d),l.dispose(),c.geometry.dispose(),r.texture.colorSpace=t===1?di:He,r}const Qx="varying vec3 vN; varying vec3 vW; varying vec2 vUv; void main(){ vUv = uv; vN = normalize(mat3(modelMatrix)*normal); vec4 w = modelMatrix*vec4(position,1.0); vW = w.xyz; gl_Position = projectionMatrix*viewMatrix*w; }",t_=`uniform sampler2D uDay; uniform sampler2D uAux; uniform vec3 uSun; uniform float uTime; varying vec3 vN; varying vec3 vW; varying vec2 vUv;
void main(){ vec3 n = normalize(vN); vec3 v = normalize(cameraPosition - vW); float ndl = dot(n, uSun);
  vec4 day = texture2D(uDay, vUv); vec4 aux = texture2D(uAux, vUv); float cl = texture2D(uAux, vUv + vec2(uTime*0.0016, 0.0)).r;
  float diff = max(ndl, 0.0); vec3 col = day.rgb*(0.025 + diff*1.1);
  vec3 h = normalize(uSun + v); col += vec3(1.0,0.93,0.8)*pow(max(dot(n,h),0.0), 70.0)*day.a*diff*0.9;
  col = mix(col, vec3(1.0)*(0.04 + diff*1.15), cl*0.9);
  col += vec3(1.0,0.72,0.38)*aux.g*(1.0-cl*0.85)*smoothstep(0.05,-0.25,ndl)*1.6;
  float limb = pow(1.0 - max(dot(n, v), 0.0), 3.0); col += vec3(0.32,0.58,1.0)*limb*(0.15 + diff*0.95);
  col = mix(col, col*vec3(1.15,0.85,0.7), smoothstep(0.2,0.0,ndl)*smoothstep(-0.1,0.05,ndl)*0.6);
  gl_FragColor = vec4(col, 1.0); }`,e_=`uniform vec3 uSun; varying vec3 vN; varying vec3 vW; void main(){ vec3 n = normalize(vN); vec3 v = normalize(cameraPosition - vW); float rim = pow(1.0 - abs(dot(n, v)), 2.6);
  float lit = clamp(dot(n, uSun)*0.9 + 0.35, 0.0, 1.0); gl_FragColor = vec4(vec3(0.35,0.62,1.0)*rim*lit*1.6, rim*lit); }`,nh="varying vec3 vN; varying vec3 vW; varying vec2 vUv; void main(){ vUv = uv; vN = normalize(mat3(modelMatrix)*normal); vec4 w = modelMatrix*vec4(position,1.0); vW = w.xyz; gl_Position = projectionMatrix*viewMatrix*w; }",n_="uniform sampler2D uMap; uniform vec3 uSun; varying vec3 vN; varying vec2 vUv; void main(){ float d = max(dot(normalize(vN), uSun), 0.0); gl_FragColor = vec4(texture2D(uMap, vUv).rgb*(0.02 + d*1.2), 1.0); }";class i_{constructor(t,e,n){this.group=new Ce,this.targets=[],this.sunDir=e.clone().normalize();const s=n==="high",r=s?2048:1024,a=ca(t,0,r,r/2,1),o=ca(t,1,r,r/2,1),l=ca(t,2,512,256,4),c=ca(t,3,s?1024:512,s?512:256,2);this.targets.push(a,o,l,c);const d=3e3,h=d*Math.sin(Ua.degToRad(50));this.uniforms={uDay:{value:a.texture},uAux:{value:o.texture},uSun:{value:this.sunDir},uTime:{value:0}},this.earth=new $t(new fn(h,s?128:72,s?64:40),new Un({vertexShader:Qx,fragmentShader:t_,uniforms:this.uniforms})),this.earth.position.set(0,-d,0),this.earth.rotation.z=.35,this.group.add(this.earth);const u=new $t(new fn(h*1.03,64,32),new Un({vertexShader:nh,fragmentShader:e_,uniforms:{uSun:{value:this.sunDir}},side:qe,transparent:!0,blending:pr,depthWrite:!1}));u.position.copy(this.earth.position),this.group.add(u),this.moon=new $t(new fn(160,40,24),new Un({vertexShader:nh,fragmentShader:n_,uniforms:{uMap:{value:l.texture},uSun:{value:this.sunDir}}})),this.moon.position.set(-3400,900,-4200),this.group.add(this.moon);const f=new $t(new fn(9e3,48,24),new Oe({map:c.texture,side:qe,depthWrite:!1}));this.group.add(f);const g=s?3500:1800,x=new Float32Array(g*3),m=new Float32Array(g*3),p=new Nt;for(let A=0;A<g;A++){const E=Math.random()*2-1,v=Math.random()*Math.PI*2,w=Math.sqrt(1-E*E);x.set([w*Math.cos(v)*8500,E*8500,w*Math.sin(v)*8500],A*3),p.setHSL(.55+Math.random()*.15-(Math.random()<.2?.45:0),.5,.75+Math.random()*.25),m.set([p.r,p.g,p.b],A*3)}const _=new be;_.setAttribute("position",new Ke(x,3)),_.setAttribute("color",new Ke(m,3)),this.group.add(new Mu(_,new fc({size:s?2.2:1.8,sizeAttenuation:!1,vertexColors:!0,depthWrite:!1,transparent:!0,opacity:.95})));const S=(()=>{const A=document.createElement("canvas");A.width=A.height=128;const E=A.getContext("2d"),v=E.createRadialGradient(64,64,0,64,64,64);v.addColorStop(0,"rgba(255,255,240,1)"),v.addColorStop(.12,"rgba(255,248,220,0.95)"),v.addColorStop(.35,"rgba(255,220,160,0.25)"),v.addColorStop(1,"rgba(255,200,120,0)"),E.fillStyle=v,E.fillRect(0,0,128,128);const w=new wu(A);return w.colorSpace=He,w})(),y=new Op(new _u({map:S,depthWrite:!1,blending:pr,transparent:!0}));y.position.copy(this.sunDir).multiplyScalar(7e3),y.scale.setScalar(1300),this.group.add(y)}update(t,e){this.uniforms.uTime.value=t,this.earth.rotation.y=t*.004,this.group.position.set(e.position.x*.98,0,e.position.z*.98)}}const It=he*zo;class s_{constructor(){this.group=new Ce,this.grid=null,this.holo=new Ce,this.debris=null,this.dInfo=[],this.key="",this.flora=[],this.floraKey="",this.group.add(this.holo)}build(t,e,n="haven"){const s=t.join("|")+"#"+e.join("|")+n;if(s===this.key)return;this.key=s,this.floraKey="";for(const S of[...this.group.children])S!==this.holo&&(this.group.remove(S),r_(S));this.holo.clear(),this.flora=[];const r=new Set(t),a=(S,y)=>S>=0&&y>=0&&S<It&&y<It&&r.has(`${Math.floor(S/he)},${Math.floor(y/he)}`),o=Nn(7),l=[],c=[],d=new Nt,h=(S,y,A,E,v)=>{l.push(...S,...y,...A,...S,...A,...E);for(let w=0;w<6;w++)c.push(v.r,v.g,v.b)};for(let S=0;S<It;S++)for(let y=0;y<It;y++){if(!a(S,y))continue;const A=S-It/2,E=y-It/2,v=!a(S-1,y)||!a(S+1,y)||!a(S,y-1)||!a(S,y+1),w=(o()-.5)*.05+((S+y)%2?.012:-.012);d.setHSL(v?.24:.3+(o()-.5)*.02,v?.42:.55,(v?.5:.43)+w),h([A,0,E],[A,0,E+1],[A+1,0,E+1],[A+1,0,E],d);const N=[[!a(S,y-1),[A+1,0,E],[A,0,E]],[!a(S,y+1),[A,0,E+1],[A+1,0,E+1]],[!a(S-1,y),[A,0,E],[A,0,E+1]],[!a(S+1,y),[A+1,0,E+1],[A+1,0,E]]];for(const[R,L,F]of N)R&&(d.setHSL(.08,.42,.33+(o()-.5)*.04),h(L,[L[0],-.45,L[2]],[F[0],-.45,F[2]],F,d),d.setHSL(.07,.25,.22),h([L[0],-.45,L[2]],[L[0],-.9,L[2]],[F[0],-.9,F[2]],[F[0],-.45,F[2]],d))}const u=new be;u.setAttribute("position",new ne(l,3)),u.setAttribute("color",new ne(c,3)),u.computeVertexNormals();const f=new $t(u,new Dn({vertexColors:!0,roughness:.92,metalness:0,flatShading:!0}));f.receiveShadow=!0,f.name="ground",this.group.add(f);const g=new Dn({vertexColors:!0,flatShading:!0,roughness:.95});for(const S of t){const[y,A]=S.split(",").map(Number),E=y*he+he/2-It/2,v=A*he+he/2-It/2,w=Nn(y*31+A*7+3),N=4+w()*3.5,R=new Ji(he*.62,N,9,4,!0);R.rotateX(Math.PI),R.translate(0,-.85-N/2,0);const L=R.attributes.position,F=new Float32Array(L.count*3);for(let H=0;H<L.count;H++){const q=L.getY(H),k=(-q-.85)/N,tt=1-k*.15;L.setX(H,L.getX(H)*tt+(w()-.5)*.5*(1-k)),L.setZ(H,L.getZ(H)*tt+(w()-.5)*.5*(1-k)),L.setY(H,q+(w()-.5)*.35*(k>.02?1:0)),d.setHSL(.07-k*.02,.28-k*.12,.27-k*.12+(w()-.5)*.04),F.set([d.r,d.g,d.b],H*3)}R.setAttribute("color",new Ke(F,3)),R.computeVertexNormals();const V=new $t(R,g);V.position.set(E,0,v),V.castShadow=!0,this.group.add(V);const D=new $t(new Yi(.22,0),new Oe({color:"#7af7ff",toneMapped:!1}));D.position.set(E+(w()-.5)*3,-1.6-w()*1.4,v+(w()-.5)*3),D.scale.y=2,this.group.add(D)}const x=[];for(let S=0;S<It;S++)for(let y=0;y<It;y++){if(!a(S,y)||(S+y)%2)continue;const A=S-It/2+.5,E=y-It/2+.5;a(S,y-1)||x.push(new I(A,-.2,E-.5)),a(S,y+1)||x.push(new I(A,-.2,E+.5)),a(S-1,y)||x.push(new I(A-.5,-.2,E)),a(S+1,y)||x.push(new I(A+.5,-.2,E))}if(x.length){const S=new Zr(new fn(.06,6,4),new Oe({color:"#7af7ff",toneMapped:!1}),x.length),y=new jt;x.forEach((A,E)=>{y.makeTranslation(A.x,A.y,A.z),S.setMatrixAt(E,y)}),this.group.add(S)}const m=26;this.debris=new Zr(new br(.5,0),g.clone(),m),this.debris.material.vertexColors=!1,this.debris.material.color.set("#6b5a4a"),this.debris.castShadow=!0,this.dInfo=[];for(let S=0;S<m;S++){const y=o()*Math.PI*2,A=14+o()*12;this.dInfo.push({p:new I(Math.cos(y)*A,-3-o()*6,Math.sin(y)*A),s:.3+o()*1.1,r:o()*6,ph:o()*6})}this.group.add(this.debris);for(const S of e){const[y,A]=S.split(",").map(Number),E=y*he+he/2-It/2,v=A*he+he/2-It/2,w=new $t(new zn(he-.3,.08,he-.3),new Oe({color:"#4fd8ff",transparent:!0,opacity:.12,depthWrite:!1}));w.position.set(E,-.1,v),w.userData.plot=S,this.holo.add(w);const N=new wd(new Gp(new zn(he-.3,.08,he-.3)),new Cl({color:"#7af7ff",transparent:!0,opacity:.35}));N.position.copy(w.position),this.holo.add(N)}const p=[];for(let S=0;S<=It;S++)for(let y=0;y<It;y++)(a(S,y)||a(S-1,y))&&p.push(S-It/2,.02,y-It/2,S-It/2,.02,y+1-It/2);for(let S=0;S<=It;S++)for(let y=0;y<It;y++)(a(y,S)||a(y,S-1))&&p.push(y-It/2,.02,S-It/2,y+1-It/2,.02,S-It/2);const _=new be;_.setAttribute("position",new ne(p,3)),this.grid=new wd(_,new Cl({color:"#ffffff",transparent:!0,opacity:.18})),this.grid.visible=!1,this.group.add(this.grid)}holoMeshes(){return this.holo.children.filter(t=>t.userData.plot)}scatter(t,e){const n=t.join("|")+"#"+[...e].sort().join(",");if(n===this.floraKey)return;this.floraKey=n,this.flora.forEach(h=>{this.group.remove(h),h.geometry.dispose()}),this.flora=[];const s=new Set(t),r=Nn(99),a=[],o=[],l=new xi,c=new kn,d=["#ffd84a","#ff7ab8","#ffffff","#9fd0ff","#ff9a4a"];for(let h=0;h<It;h++)for(let u=0;u<It;u++){if(!s.has(`${Math.floor(h/he)},${Math.floor(u/he)}`)||e.has(h+","+u))continue;const f=r()<.55?1+Math.floor(r()*3):0;for(let g=0;g<f;g++){c.set(0,r()*6,(r()-.5)*.3),l.setFromEuler(c);const x=.6+r()*.7;a.push(new jt().compose(new I(h-It/2+.15+r()*.7,0,u-It/2+.15+r()*.7),l,new I(x,x*(.8+r()*.6),x)))}if(r()<.12){const g=new Nt(d[Math.floor(r()*d.length)]);o.push({m:new jt().makeTranslation(h-It/2+.2+r()*.6,.09,u-It/2+.2+r()*.6),c:g})}}if(a.length){const h=new Ji(.045,.2,3);h.translate(0,.1,0);const u=new Zr(h,new Dn({color:"#5fb04a",flatShading:!0,roughness:.9}),a.length);a.forEach((f,g)=>u.setMatrixAt(g,f)),u.receiveShadow=!0,this.group.add(u),this.flora.push(u)}if(o.length){const h=new _i(.045,0),u=new Zr(h,new Dn({color:"#ffffff",roughness:.6,emissive:"#222222"}),o.length);o.forEach((f,g)=>{u.setMatrixAt(g,f.m),u.setColorAt(g,f.c)}),this.group.add(u),this.flora.push(u)}}update(t){if(this.debris){const e=new jt,n=new xi,s=new kn,r=new I;this.dInfo.forEach((a,o)=>{s.set(a.r+t*.1,a.r*2+t*.07,0),n.setFromEuler(s),r.setScalar(a.s),e.compose(new I(a.p.x,a.p.y+Math.sin(t*.4+a.ph)*.4,a.p.z),n,r),this.debris.setMatrixAt(o,e)}),this.debris.instanceMatrix.needsUpdate=!0}this.holo.children.forEach(e=>{const n=e.material;n&&"opacity"in n&&e.userData.plot&&(n.opacity=.05+Math.sin(t*2)*.025)})}}function r_(i){i.traverse(t=>{const e=t;e.geometry&&e.geometry.dispose()})}function a_(i,t=!1){const e=i[0].index!==null,n=new Set(Object.keys(i[0].attributes)),s=new Set(Object.keys(i[0].morphAttributes)),r={},a={},o=i[0].morphTargetsRelative,l=new be;l.morphTargetsRelative=o;let c=0;for(let d=0;d<i.length;++d){const h=i[d];let u=0,f=0;if(e!==(h.index!==null))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+d+". All geometries must have compatible attributes; make sure index attribute exists among all geometries, or in none of them."),null;for(const g in h.attributes){if(!n.has(g))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+d+'. All geometries must have compatible attributes; make sure "'+g+'" attribute exists among all geometries, or in none of them.'),null;r[g]===void 0&&(r[g]=[]),r[g].push(h.attributes[g]),u++}if(u!==n.size)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+d+". Make sure all geometries have the same number of attributes."),null;if(o!==h.morphTargetsRelative)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+d+". .morphTargetsRelative must be consistent throughout all geometries."),null;for(const g in h.morphAttributes){if(!s.has(g))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+d+".  .morphAttributes must be consistent throughout all geometries."),null;if(h.morphAttributes[g].length!==i[0].morphAttributes[g].length)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+d+'. All geometries must have the same number of morph targets for the "'+g+'" morph attribute.'),null;a[g]===void 0&&(a[g]=[]),a[g].push(h.morphAttributes[g]),f++}if(f!==s.size)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+d+". Make sure all geometries have the same number of morph attributes."),null;if(t){let g;if(e)g=h.index.count;else if(h.attributes.position!==void 0)g=h.attributes.position.count;else return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+d+". The geometry must have either an index or a position attribute"),null;l.addGroup(c,g,d),c+=g}}if(e){let d=0;const h=[];for(let u=0;u<i.length;++u){const f=i[u].index;for(let g=0;g<f.count;++g)h.push(f.getX(g)+d);d+=i[u].attributes.position.count}l.setIndex(h)}for(const d in r){const h=ih(r[d]);if(!h)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+d+" attribute."),null;l.setAttribute(d,h)}for(const d in a){const h=a[d][0].length;if(h!==0){l.morphAttributes=l.morphAttributes||{},l.morphAttributes[d]=[];for(let u=0;u<h;++u){const f=[];for(let x=0;x<a[d].length;++x)f.push(a[d][x][u]);const g=ih(f);if(!g)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+d+" morphAttribute."),null;l.morphAttributes[d].push(g)}}}return l}function ih(i){let t,e,n,s=-1,r=0;for(let c=0;c<i.length;++c){const d=i[c];if(t===void 0&&(t=d.array.constructor),t!==d.array.constructor)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.array must be of consistent array types across matching attributes."),null;if(e===void 0&&(e=d.itemSize),e!==d.itemSize)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.itemSize must be consistent across matching attributes."),null;if(n===void 0&&(n=d.normalized),n!==d.normalized)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.normalized must be consistent across matching attributes."),null;if(s===-1&&(s=d.gpuType),s!==d.gpuType)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.gpuType must be consistent across matching attributes."),null;r+=d.count*e}const a=new t(r),o=new Ke(a,e,n);let l=0;for(let c=0;c<i.length;++c){const d=i[c];if(d.isInterleavedBufferAttribute){const h=l/e;for(let u=0,f=d.count;u<f;u++)for(let g=0;g<e;g++){const x=d.getComponent(u,g);o.setComponent(u+h,g,x)}}else a.set(d.array,l);l+=d.count*e}return s!==void 0&&(o.gpuType=s),o}const da=new Nt,hr={body:new Dn({vertexColors:!0,flatShading:!0,roughness:.62,metalness:.12}),glow:new Oe({vertexColors:!0,toneMapped:!1}),glass:new Dn({vertexColors:!0,transparent:!0,opacity:.38,roughness:.08,metalness:.2,depthWrite:!1}),ghostOk:new Oe({color:6160282,transparent:!0,opacity:.45,depthWrite:!1}),ghostBad:new Oe({color:16734826,transparent:!0,opacity:.45,depthWrite:!1})};class sn{constructor(){this.parts={body:[],glow:[],glass:[]}}add(t,e,n=0,s=0,r=0,a={}){let o=t.index?t.toNonIndexed():t.clone();o.attributes.uv&&o.deleteAttribute("uv"),o.attributes.uv1&&o.deleteAttribute("uv1");const l=new jt().compose(new I(n,s,r),new xi().setFromEuler(new kn(a.rx||0,a.ry||0,a.rz||0)),new I(a.sx??1,a.sy??1,a.sz??1));o.applyMatrix4(l),da.set(e);const c=o.attributes.position.count,d=new Float32Array(c*3);for(let h=0;h<c;h++)d[h*3]=da.r,d[h*3+1]=da.g,d[h*3+2]=da.b;return o.setAttribute("color",new Ke(d,3)),this.parts[a.glow?"glow":a.glass?"glass":"body"].push(o),t.dispose(),this}box(t,e,n,s,r=0,a=0,o=0,l={}){return this.add(new zn(t,e,n),s,r,a+e/2,o,l)}cyl(t,e,n,s,r,a=0,o=0,l=0,c={}){return this.add(new mn(t,e,n,s),r,a,o+n/2,l,c)}sphere(t,e,n=0,s=0,r=0,a={}){return this.add(new fn(t,a.w||10,a.h||7,0,Math.PI*2,0,a.theta||Math.PI),e,n,s,r,a)}build(t=""){const e=new Ce;e.name=t;for(const n of["body","glow","glass"]){const s=this.parts[n];if(!s.length)continue;const r=a_(s,!1);if(s.forEach(o=>o.dispose()),!r)continue;const a=new $t(r,hr[n]);a.castShadow=n==="body",a.receiveShadow=n==="body",a.userData.bucket=n,e.add(a)}return e}}const Fn=(i,t)=>{const e=new Nt(i);return t<0?e.lerp(new Nt(0),-t):e.lerp(new Nt(16777215),t),"#"+e.getHexString()},sh=(i,t,e)=>"#"+new Nt(i).lerp(new Nt(t),e).getHexString(),Wt={solar:{name:"Solar",color:"#ffb23e",glow:"#ffe08a",glyph:"☀",strong:["bio","cryo"],blurb:"Runs on starlight. Hums when the Sun is up."},plasma:{name:"Plasma",color:"#ff5a3c",glow:"#ffb08a",glyph:"♨",strong:["alloy","bio"],blurb:"Contained fire at ten thousand degrees."},hydro:{name:"Hydro",color:"#2f8cff",glow:"#9fd0ff",glyph:"≈",strong:["plasma","geo"],blurb:"Pumps, cleans and cools. Every colony needs water."},cryo:{name:"Cryo",color:"#7fe4ff",glow:"#dff8ff",glyph:"❄",strong:["aero","bio"],blurb:"Supercooled circuits, near absolute zero."},geo:{name:"Geo",color:"#b07a4a",glow:"#e2b48c",glyph:"▲",strong:["volt","plasma"],blurb:"Drills, diggers and regolith movers."},bio:{name:"Bio",color:"#4fcf5a",glow:"#b6ffb0",glyph:"❦",strong:["hydro","geo"],blurb:"Gardeners of greenhouses and living hulls."},volt:{name:"Volt",color:"#ffe23a",glow:"#fff6a8",glyph:"ϟ",strong:["hydro","aero"],blurb:"Lightning in a capacitor."},alloy:{name:"Alloy",color:"#9aa7b8",glow:"#e6edf5",glyph:"⚙",strong:["cryo","kinetic"],blurb:"Armour, welders and heavy lifting."},void:{name:"Void",color:"#6b3fd6",glow:"#c2a6ff",glyph:"◐",strong:["photon","neural"],blurb:"Built for the dark between stars."},photon:{name:"Photon",color:"#fff4c2",glow:"#ffffff",glyph:"✦",strong:["void","chrono"],blurb:"Lasers, lenses and light."},kinetic:{name:"Kinetic",color:"#ff7a1a",glow:"#ffc28a",glyph:"✊",strong:["alloy","gravity"],blurb:"Impact, momentum, mass drivers."},aero:{name:"Aero",color:"#b9f0e6",glow:"#ecfffb",glyph:"༄",strong:["geo","kinetic"],blurb:"Flyers and atmosphere shapers."},gravity:{name:"Gravity",color:"#3c4aa8",glow:"#9aa6ff",glyph:"◉",strong:["aero","photon"],blurb:"Bends space a little, on purpose."},chrono:{name:"Chrono",color:"#c9a2ff",glow:"#eedcff",glyph:"⧗",strong:["neural","volt"],blurb:"Clocks running a little sideways."},neural:{name:"Neural",color:"#ff6fd8",glow:"#ffc4f0",glyph:"✺",strong:["kinetic","gravity"],blurb:"Artificial minds. They learn from everything."},relic:{name:"Relic",color:"#d8b46a",glow:"#fff0c4",glyph:"⌬",relic:!0,strong:[],blurb:"Precursor make, older than our species."},aurora:{name:"Aurora",color:"#6fffc8",glow:"#d6fff0",glyph:"❈",relic:!0,strong:[],blurb:"Beauty as a power source."},arcana:{name:"Arcana",color:"#8a5cff",glow:"#d7c6ff",glyph:"✧",relic:!0,strong:[],blurb:"Technology indistinguishable from magic."},entropy:{name:"Entropy",color:"#ff3d6e",glow:"#ffb3c6",glyph:"✹",relic:!0,strong:[],blurb:"Chaos, harnessed."},joy:{name:"Joy",color:"#ffd24a",glow:"#fff2b8",glyph:"☺",relic:!0,strong:[],blurb:"Precursor machines made to be happy."},reverie:{name:"Reverie",color:"#7aa8ff",glow:"#d2e2ff",glyph:"☾",relic:!0,strong:[],blurb:"They dream in mathematics."},soul:{name:"Soul",color:"#f2f2ff",glow:"#ffffff",glyph:"❂",relic:!0,strong:[],blurb:"Something in them is alive."}},o_=Object.keys(Wt).filter(i=>!Wt[i].relic),Mn="#c8d0da",On="#3a4250",eo="#bfe9ff",Ds="#ffe9a8";function un(i,t){return new $t(i,new Oe({color:t,toneMapped:!1}))}function xc(i,t=.7,e=.45){const n=l_(i.banner),s=new rs(t,e,8,1);s.translate(t/2,0,0);const r=new $t(s,new Dn({map:n,side:Cn,roughness:.8}));r.castShadow=!0;const a=s.attributes.position.array.slice();return r.userData.wave=o=>{const l=s.attributes.position.array;for(let c=0;c<l.length;c+=3){const d=a[c];l[c+2]=Math.sin(d*7-o*4)*.06*(d/t)}s.attributes.position.needsUpdate=!0},r}const rh=new Map;function l_(i){const t=i.bg+i.fg+i.emblem,e=rh.get(t);if(e)return e;const n=document.createElement("canvas");n.width=128,n.height=80;const s=n.getContext("2d");s.fillStyle=i.bg,s.fillRect(0,0,128,80),s.fillStyle=Fn(i.bg,-.25),s.fillRect(0,64,128,16),s.fillStyle=i.fg,s.translate(64,36),_c(s,i.emblem,22),s.fill();const r=new wu(n);return r.colorSpace=He,rh.set(t,r),r}function _c(i,t,e){if(i.beginPath(),t==="star")for(let n=0;n<10;n++){const s=-Math.PI/2+n*Math.PI/5,r=n%2?e*.45:e;i.lineTo(Math.cos(s)*r,Math.sin(s)*r)}else if(t==="planet")i.arc(0,0,e*.6,0,7),i.moveTo(e,0),i.ellipse(0,0,e,e*.28,-.3,0,7);else if(t==="bolt")i.moveTo(e*.2,-e),i.lineTo(-e*.5,e*.1),i.lineTo(0,e*.1),i.lineTo(-e*.2,e),i.lineTo(e*.5,-e*.1),i.lineTo(0,-e*.1);else if(t==="gear")for(let n=0;n<16;n++){const s=n*Math.PI/8,r=n%2?e*.7:e;i.lineTo(Math.cos(s)*r,Math.sin(s)*r)}else t==="rocket"?(i.moveTo(0,-e),i.quadraticCurveTo(e*.45,-e*.3,e*.3,e*.5),i.lineTo(e*.6,e),i.lineTo(-e*.6,e),i.lineTo(-e*.3,e*.5),i.quadraticCurveTo(-e*.45,-e*.3,0,-e)):i.arc(0,0,e*.8,0,7);i.closePath()}function c_(i,t){const e=new sn,n=t.primary,s=t.accent,r=Math.min(5,1+Math.floor((i-1)/3));e.cyl(1.95,1.95,.28,8,Fn(n,-.18),0,0,0,{ry:Math.PI/8}),e.cyl(1.88,1.88,.05,8,s,0,.28,0,{ry:Math.PI/8,glow:!0});const a=1.25;for(const[x,m]of[[a,a],[-a,a],[a,-a],[-a,-a]]){const p=.55+Math.min(.5,i*.04);e.box(.85,p,.85,n,x,.33,m),e.box(.87,.07,.87,s,x,.33+p,m),e.box(.6,.09,.02,Ds,x,.33+p*.55,m+.43,{glow:!0}),e.box(.02,.09,.6,Ds,x+.43*Math.sign(x),.33+p*.55,m,{glow:!0})}let o=.33,l=1.15;for(let x=0;x<r;x++){const m=.62-x*.04;e.cyl(l,l*1.04,m,12,x%2?Fn(n,-.08):n,0,o,0),e.cyl(l*1.03,l*1.03,.06,12,s,0,o+m-.12,0,{glow:x===r-1});for(let p=0;p<8;p++){const _=p/8*Math.PI*2;e.box(.18,.12,.02,Ds,Math.cos(_)*l*1.02,o+m*.45,Math.sin(_)*l*1.02,{ry:-_+Math.PI/2,glow:!0})}o+=m,l*=.84}e.sphere(l*1.05,eo,0,o,0,{theta:Math.PI/2,w:14,h:6,glass:!0}),e.sphere(l*.45,s,0,o+.05,0,{glow:!0,w:8,h:5}),i>=5&&(e.cyl(.62,.62,.05,10,On,1.35,.3,-1.35),e.cyl(.5,.5,.06,10,"#ffcc33",1.35,.3,-1.35),e.cyl(.42,.42,.07,10,On,1.35,.3,-1.35)),i>=8&&(e.cyl(.05,.08,.6,6,Mn,-1.25,.95+Math.min(.5,i*.04),1.25),e.sphere(.32,Mn,-1.25,1.62+Math.min(.5,i*.04),1.25,{theta:Math.PI/2,rx:Math.PI*.75}));const c=e.build("command"),d=o+l*1.05,h=new $t(new mn(.02,.035,.9,5),hr.body);h.position.set(0,d+.45,0),h.geometry.setAttribute("color",new Ke(new Float32Array(h.geometry.attributes.position.count*3).fill(.8),3)),c.add(h);const u=un(new fn(.07,8,6),"#ff4a4a");u.position.set(0,d+.92,0),c.add(u);const f=new $t(new mn(.025,.025,1.5,5),new Dn({color:Mn}));f.position.set(-1.7,1.03,-1.7),f.castShadow=!0,c.add(f);const g=xc(t);return g.position.set(-1.68,1.55,-1.7),c.add(g),{group:c,height:d+1,anim:x=>{u.material.color.set(Math.sin(x*3)>0?"#ff4a4a":"#3a0a0a"),g.userData.wave(x)}}}function d_(i,t,e){const n=new sn,s=e.primary,r=(Wt[t]||Wt.solar).color,a=(Wt[t]||Wt.solar).glow;n.cyl(1.42,1.48,.22,6,Fn(s,-.12),0,0,0,{ry:Math.PI/6}),n.cyl(1.36,1.36,.04,6,sh(s,r,.35),0,.22,0,{ry:Math.PI/6}),n.cyl(.62,.62,.03,16,r,0,.26,0,{glow:!0}),n.cyl(.5,.5,.035,16,Fn(r,-.5),0,.26,0);const o=i>=4?6:3,l=.7+Math.min(.8,i*.07);for(let u=0;u<o;u++){const f=u/o*Math.PI*2+Math.PI/6,g=Math.cos(f)*1.18,x=Math.sin(f)*1.18;n.box(.16,l,.16,s,g,.26,x,{ry:-f}),n.box(.2,.08,.2,ah(e),g,.26+l,x,{ry:-f}),n.box(.06,l*.6,.02,r,g*.99,.26+l*.25,x*.99,{ry:-f+Math.PI/2,glow:!0})}i>=4&&n.add(new nn(1.18,.05,6,24),ah(e),0,.26+l+.06,0,{rx:Math.PI/2}),i>=7&&n.sphere(1.25,sh(a,"#ffffff",.4),0,.26,0,{theta:Math.PI/2,w:18,h:8,glass:!0});const c=2+Math.floor((i-1)/3);for(let u=0;u<c;u++){const f=u/c*Math.PI*2+.4;n.cyl(.17,.17,.03,8,Fn(r,.2),Math.cos(f)*.86,.26,Math.sin(f)*.86,{glow:!0})}const d=n.build("bay"),h=un(new Yi(.18,0),a);return h.position.y=.26+l+.45,h.material.transparent=!0,h.material.opacity=.85,d.add(h),{group:d,height:.26+l+.7,anim:u=>{h.rotation.y=u*1.4,h.position.y=.26+l+.45+Math.sin(u*2)*.06}}}const ah=i=>i.accent;function h_(i,t){const e=new sn,n=t.primary,s=t.accent,r="#9dff5a";e.box(2.7,.18,2.7,Fn(n,-.2),0,0,0),e.box(1.7,1+Math.min(.4,i*.04),1.5,n,-.35,.18,-.4),e.box(1.74,.1,1.54,s,-.35,1.18+Math.min(.4,i*.04),-.4),e.box(1,.12,.02,Ds,-.35,.75,.36,{glow:!0}),e.box(.4,.55,.03,On,.25,.18,.36);const a=1+Math.min(3,Math.floor(i/3));for(let f=0;f<a;f++)e.cyl(.13,.16,.7+f*.1,8,Mn,-.9+f*.38,1.28,-.85),e.cyl(.15,.15,.06,8,s,-.9+f*.38,1.9+f*.1,-.85);e.box(2.2,.12,.4,On,0,.18,.95);for(let f=0;f<5;f++)e.box(.18,.18,.22,r,-.8+f*.4,.3,.95,{glow:!0});const o=e.build("fab"),l=new sn;l.cyl(.42,.42,1.25,14,eo,0,0,0,{glass:!0}),l.cyl(.46,.46,.08,14,s,0,1.25,0),l.cyl(.46,.46,.1,14,Mn,0,-.02,0);const c=l.build("tank");c.position.set(.85,.18,-.55),o.add(c);const d=un(new mn(.36,.36,1,14),r);d.geometry.translate(0,.5,0),d.position.set(.85,.22,-.55),o.add(d);const h=new Ce,u=new sn;return u.box(.1,.6,.1,"#ffb23e",0,0,0),u.box(.5,.08,.08,"#ffb23e",.22,.56,0),u.box(.08,.18,.08,On,.45,.4,0),h.add(u.build()),h.position.set(.95,.3,.6),o.add(h),{group:o,height:2.1,anim:(f,g)=>{const x=g.ready?1:g.working?.15+.7*(f*.08%1):.08;d.scale.y=Ua.lerp(d.scale.y||.1,x*1.2,.08),h.rotation.y=g.working?Math.sin(f*2.4)*.9:0,d.material.color.set(g.ready&&Math.sin(f*5)>0?"#c8ff7a":r)}}}function u_(i,t){const e=new sn,n=t.primary,s=t.accent,r=Math.min(3,1+Math.floor((i-1)/3));e.box(2.8,.2,2.8,Fn(n,-.2),0,0,0),e.box(2.6,.05,.4,"#ffcc33",0,.2,1.05),e.box(2,.6,.7,n,0,.2,-.95),e.box(2.04,.06,.74,s,0,.8,-.95),e.box(1.4,.1,.02,Ds,0,.55,-.59,{glow:!0});const a=[-.85,0,.85];for(let h=0;h<3;h++){const u=h<r;e.cyl(.36,.4,.14,12,u?Mn:On,a[h],.2,.15),u&&(e.cyl(.32,.32,.9,12,eo,a[h],.34,.15,{glass:!0}),e.cyl(.36,.36,.08,12,s,a[h],1.24,.15))}const o=e.build("assembly"),l=new Ce,c=new sn;c.box(.08,1.5,.08,"#ffb23e",-1.3,0,-.3),c.box(2.7,.08,.08,"#ffb23e",0,1.5,-.3),c.box(.12,.3,.12,On,0,1.22,-.3),l.add(c.build()),l.position.y=.2,o.add(l);const d=[];for(let h=0;h<3;h++){const u=un(new _i(.17,1),"#ffffff");u.position.set(a[h],.8,.15),u.visible=!1,o.add(u),d.push(u)}return{group:o,height:1.8,anim:(h,u)=>{const f=u.cores||[];d.forEach((g,x)=>{const m=f[x];if(g.visible=!!m&&x<r,!m)return;g.material.color.set(m.color),g.rotation.y=h*(m.ready?3:1.2),g.rotation.x=h*.7;const p=m.ready?1+Math.sin(h*6)*.15:.85+Math.sin(h*2+x)*.08;g.scale.setScalar(p),g.position.y=.8+Math.sin(h*1.5+x)*.05}),l.position.x=f.some(g=>!g.ready)?Math.sin(h*.9)*.8:l.position.x*.95}}}function f_(i,t){const e=new sn,n=t.primary,s=t.accent;e.box(3.8,.22,2.8,Fn(n,-.2),0,0,0),e.box(3.6,.04,.3,s,0,.22,1.15,{glow:!0});for(const h of[-1.25,1.25])e.cyl(.62,.7,.35,12,n,h,.22,0),e.cyl(.66,.66,.06,12,s,h,.57,0),e.sphere(.58,eo,h,.62,0,{theta:Math.PI/2,w:16,h:7,glass:!0}),e.cyl(.4,.4,.03,14,"#b06dff",h,.6,0,{glow:!0});e.cyl(.22,.3,1+Math.min(.4,i*.04),10,Mn,0,.22,0),e.box(2,.12,.18,On,0,.62,0),e.box(.7,.5,.6,n,0,.22,-.95),e.box(.5,.08,.02,Ds,0,.5,-.64,{glow:!0});const r=e.build("fusion"),a=1.25+Math.min(.4,i*.04),o=new Ce,l=new sn;l.add(new nn(.55,.07,8,32),s),l.add(new nn(.42,.03,6,28),"#b06dff",0,0,0,{glow:!0}),o.add(l.build()),o.position.y=a,r.add(o);const c=un(new _i(.16,1),"#e2c8ff");c.position.y=a,r.add(c);const d=un(new mn(.035,.035,2.5,6),"#d6b8ff");return d.rotation.z=Math.PI/2,d.position.y=.95,d.visible=!1,r.add(d),{group:r,height:a+.6,anim:(h,u)=>{o.rotation.x=Math.PI/2+Math.sin(h*.5)*.2,o.rotation.z=h*(u.working?4:.4),c.scale.setScalar(u.working?1+Math.sin(h*9)*.25:.7),d.visible=!!u.working,d.scale.x=1+Math.sin(h*20)*.3,c.material.color.set(u.ready?"#fff2a8":"#e2c8ff")}}}function p_(i,t){const e=new sn,n=t.primary,s=t.accent;e.cyl(1.9,2,.25,24,Fn(n,-.2),0,0,0),e.cyl(1.7,1.7,.04,32,"#2a3446",0,.25,0),e.add(new nn(1.7,.05,6,48),s,0,.29,0,{rx:Math.PI/2,glow:!0});for(const[d,h]of[[-.8,"#4aa8ff"],[.8,"#ff5a6a"]])e.cyl(.42,.42,.03,18,h,d,.29,0,{glow:!0});const r=6+Math.min(6,i);for(let d=0;d<r;d++){const h=d/r*Math.PI*2;e.box(.14,.9+d%2*.3,.14,n,Math.cos(h)*1.75,.25,Math.sin(h)*1.75),e.box(.17,.08,.17,s,Math.cos(h)*1.75,1.15+d%2*.3,Math.sin(h)*1.75,{glow:!0})}const a=e.build("arena"),o=new $t(new nn(1.25,.04,6,48),new Oe({color:"#7af7ff",toneMapped:!1,transparent:!0,opacity:.85}));o.position.y=1.5,o.rotation.x=Math.PI/2,a.add(o);const l=xc(t,.55,.34);l.position.set(.02,2,0);const c=new $t(new mn(.02,.02,1,5),new Dn({color:Mn}));return c.position.set(0,1.7,0),a.add(c,l),{group:a,height:2.3,anim:d=>{o.rotation.z=d*.8,o.position.y=1.4+Math.sin(d*1.5)*.1,l.userData.wave(d)}}}function m_(i,t){const e=new sn;switch(i){case"tree":{e.cyl(.05,.08,.45,6,"#7a5232"),e.add(new _i(.32,0),"#47c95a",0,.68,0),e.add(new _i(.22,0),"#6ee36f",.12,.88,.05);for(const[n,s,r]of[[.2,.62,.15],[-.18,.75,.12],[.05,.6,-.25]])e.sphere(.045,"#aaffee",n,s,r,{glow:!0,w:6,h:4});return{group:e.build("tree"),height:1.1}}case"rock":{const n=new br(.32,0),s=n.attributes.position;for(let r=0;r<s.count;r++)s.setY(r,s.getY(r)*.7);return e.add(n,"#8a8f99",0,.18,0,{ry:.7}),e.add(new br(.14,0),"#6c717b",.28,.08,.12),{group:e.build("rock"),height:.5}}case"path":return e.box(.98,.04,.98,"#cfd6df"),e.box(.86,.045,.86,"#e7ecf2"),{group:e.build("path"),height:.1};case"lamp":{e.cyl(.08,.1,.1,6,On),e.cyl(.03,.03,.95,6,Mn,0,.1),e.box(.24,.04,.06,Mn,.1,1.02,0);const n=e.build("lamp"),s=un(new fn(.07,8,6),"#ffe7a0");s.position.set(.2,.98,0),n.add(s);const r=new Jp("#ffd890",1.2,3.2,2);return r.position.set(.2,.92,0),n.add(r),{group:n,height:1.2}}case"flag":{e.cyl(.07,.09,.08,6,On);const n=e.build("flag"),s=new $t(new mn(.02,.02,1.4,5),new Dn({color:Mn}));s.position.y=.75,n.add(s);const r=xc(t,.6,.38);return r.position.set(.02,1.25,0),n.add(r),{group:n,height:1.5,anim:a=>r.userData.wave(a)}}case"crystal":{for(const[r,a,o,l]of[[0,0,.7,.13],[.16,.08,.45,.09],[-.14,.1,.5,.1],[.05,-.16,.38,.08]])e.add(new Yi(l,0),"#c48bff",r,o/2,a,{sy:o/l/2,glass:!0});e.cyl(.25,.3,.06,7,"#5d5468");const n=e.build("crystal"),s=un(new Yi(.06,0),"#f0d8ff");return s.position.y=.3,n.add(s),{group:n,height:.8}}case"fountain":{e.cyl(.85,.9,.22,16,"#d9dee5"),e.cyl(.72,.72,.03,16,"#2f8cff",0,.2,0,{glass:!0}),e.cyl(.12,.16,.55,8,"#c8d0da",0,.2),e.cyl(.3,.3,.05,12,"#c8d0da",0,.75);const n=e.build("fountain"),s=new Ce;for(let r=0;r<6;r++){const a=un(new nn(.28,.02,4,12,Math.PI),"#9fd8ff");a.rotation.y=r/6*Math.PI*2,a.position.y=.78,a.rotation.z=0,s.add(a)}return s.children.forEach(r=>{r.geometry.translate(.28,0,0)}),n.add(s),{group:n,height:1.2,anim:r=>{s.rotation.y=r*.6,s.scale.y=1+Math.sin(r*3)*.08}}}case"dish":{e.box(.9,.2,.9,"#9aa4b1"),e.cyl(.1,.14,.6,8,Mn,0,.2),e.sphere(.65,"#e9eef5",0,1.05,0,{theta:Math.PI/2.6,rx:Math.PI*.8,w:16,h:6}),e.cyl(.02,.02,.5,4,On,.12,.95,.1,{rx:-.6});const n=e.build("dish"),s=un(new fn(.05,6,4),"#7af7ff");return s.position.set(.22,1.32,.3),n.add(s),{group:n,height:1.6}}case"arch":{for(const r of[-.75,.75])e.cyl(.12,.16,.12,8,"#c8d0da",r,0),e.cyl(.07,.07,.6,8,"#e9eef5",r,.12);e.add(new nn(.75,.07,8,28,Math.PI),"#e6b84a",0,.72,0),e.add(new nn(.62,.025,6,28,Math.PI),"#fff4c2",0,.72,0,{glow:!0});const n=e.build("arch"),s=new Ce;for(let r=0;r<7;r++){const a=un(new Yi(.04,0),"#fff4c2"),o=r/6*Math.PI;a.position.set(Math.cos(o)*.75,.72+Math.sin(o)*.75,0),s.add(a)}return n.add(s),{group:n,height:1.6,anim:r=>s.children.forEach((a,o)=>{a.scale.setScalar(.6+.6*Math.abs(Math.sin(r*2+o))),a.rotation.y=r*3})}}case"statue":return e.box(1.2,.3,1.2,"#d9dee5"),e.box(1,.5,1,"#c3cad4",0,.3),e.sphere(.38,"#e6b84a",0,1.22,0,{w:14,h:10}),e.add(new nn(.52,.05,6,24),"#e6b84a",0,1.22,0,{rx:1.2}),e.sphere(.1,"#fff4c2",0,1.26,.33,{glow:!0}),{group:e.build("statue"),height:1.8}}return e.box(.8,.4,.8,"#ff00ff"),{group:e.build("?"),height:.5}}function Nl(i,t,e,n){const s=Math.max(1,t);return i==="command"?c_(s,n):i==="bay"?d_(s,e||"solar",n):i==="fab"?h_(s,n):i==="assembly"?u_(s,n):i==="fusion"?f_(s,n):i==="arena"?p_(s,n):m_(i,n)}function g_(){const i=new sn;i.cyl(.32,.42,.7,8,"#e9eef5",0,.1),i.cyl(.43,.43,.08,8,"#ff7a3c",0,.3),i.add(new Ji(.32,.4,8),"#e9eef5",0,1,0),i.box(.3,.2,.02,"#2c3340",0,.42,.37);for(let s=0;s<4;s++){const r=s/4*Math.PI*2+Math.PI/4;i.box(.05,.35,.22,"#ff7a3c",Math.cos(r)*.38,0,Math.sin(r)*.38,{ry:-r})}const t=i.build("pod"),e=un(new Ji(.2,.7,8),"#ffd27a");e.rotation.x=Math.PI,e.position.y=-.3,t.add(e);const n=un(new fn(.06,8,6),"#7cf29a");return n.position.y=1.22,t.add(n),t.userData.flame=e,t.userData.beacon=n,t}function v_(i,t,e){const n=new Ce,s=new Dn({color:"#f2b233",roughness:.6,metalness:.3}),r=new mn(.035,.035,e,5),a=new mn(.025,.025,1,4),o=[-i/2+.1,i/2-.1],l=[-t/2+.1,t/2-.1];for(const d of o)for(const h of l){const u=new $t(r,s);u.position.set(d,e/2,h),u.castShadow=!0,n.add(u)}for(let d=.4;d<e;d+=.6){for(const h of l){const u=new $t(a,s);u.scale.y=i-.2,u.rotation.z=Math.PI/2,u.position.set(0,d,h),n.add(u)}for(const h of o){const u=new $t(a,s);u.scale.y=t-.2,u.rotation.x=Math.PI/2,u.position.set(h,d,0),n.add(u)}}const c=new $t(new zn(.08,.08,Math.max(i,t)*.9),s);return c.position.set(0,e+.1,0),c.name="crane",n.add(c),n}const In=(i=Date.now())=>{const t=new Date(i);return`${t.getFullYear()}-${String(t.getMonth()+1).padStart(2,"0")}-${String(t.getDate()).padStart(2,"0")}`},x_=(i=Date.now())=>In(i-864e5);function ue(i){const t=i;return t.daily||(t.daily={day:0,cycle:0,last:"",streak:0,best:0,total:0,mDate:"",missions:[],mBase:{},mClaimed:[],bonus:!1,drop:Date.now()+8*6e4,drops:0,dropAt:null,spin:"",adSpin:"",ach:{}}),t.daily}const ji=i=>1+i.lvl*.6,Gu={2:{dm:10,label:"Dark Matter"},6:{core:"advanced",label:"Advanced core"},9:{dm:20,label:"Dark Matter"},13:{core:"elite",label:"Elite core"},16:{dm:30,label:"Dark Matter"},20:{decor:"arch",label:"Starlight Arch"},23:{dm:40,label:"Dark Matter"},27:{core:"epic",label:"Epic core"}};function Vu(i,t,e=ue(i).cycle){const n=ji(i)*(1+t*.07)*(1+e*.5),s=Gu[t],r=t%2?{cells:ge(60*n)}:{credits:ge(250*n)};s&&s.dm&&(r.dm=s.dm+e*10);const a=s&&s.core?on[Math.min(on.length-1,on.indexOf(s.core)+e)]:void 0;return{res:r,core:a,decor:s&&s.decor,label:s?s.label:""}}const yc=(i,t=Date.now())=>ue(i).last!==In(t);function __(i,t,e){let n=Xn.filter(a=>gt[a].rarity===t);if(t==="standard"&&!Zt(i,"assembly").some(a=>a.lvl>0)){const a=n.filter(o=>es(i,o));a.length&&(n=a)}const s=n.filter(a=>!i.dex[a]),r=s.length&&Nn(e)()<.75?s:n;return r[Math.floor(Nn(e+7)()*r.length)]}function Er(i,t,e,n=Date.now()){const s=__(i,t,e),r=Zt(i,"assembly")[0];if(r&&r.lvl>0)return $l(i,s,"gift",n),{sp:s,core:!0};const a=t==="standard"?es(i,s):null;return a?(i.bots.push({id:pn("b"),sp:s,lvl:1,fed:0,bay:a.id,born:n}),Hl(i,s,n),Yn.push({kind:"newBot",bot:i.bots[i.bots.length-1].id}),{sp:s,core:!1}):(i.cores.push({id:pn("c"),sp:s,from:"gift",state:"waiting",at:n}),{sp:s,core:!0})}function y_(i,t=Date.now()){const e=ue(i);if(!yc(i,t))return null;const n=Vu(i,e.day);Qn(i,n.res);let s=null;n.core&&(s=Er(i,n.core,Ns(In(t))+e.total,t)),n.decor&&(i.stats["decor_"+n.decor]=(i.stats["decor_"+n.decor]||0)+1),e.streak=e.last===x_(t)?e.streak+1:1,e.best=Math.max(e.best,e.streak),e.total++,e.last=In(t);const r=e.day;return e.day++,e.day>=28&&(e.day=0,e.cycle++),Be(i,20+r*2),{...n,day:r,gift:s}}const b_=[{id:"collect",kind:"collects",n:()=>8,text:i=>`Collect credits from your bays ${i} times`},{id:"credits",kind:"collected",n:i=>ge(1500*ji(i)),text:i=>`Collect ${i.toLocaleString()} credits`},{id:"harvest",kind:"harvests",n:()=>3,text:i=>`Harvest ${i} Fabricator recipes`},{id:"feed",kind:"feeds",n:()=>12,text:i=>`Feed your bots ${i} times`},{id:"craft",kind:"crafts",n:()=>4,text:i=>`Start ${i} Fabricator recipes`},{id:"upgrade",kind:"upgrades",n:()=>2,text:i=>`Start ${i} upgrades`},{id:"recruit",kind:"recruits",n:()=>1,text:()=>"Recruit a bot from the shop"},{id:"decor",kind:"decor",n:()=>2,text:i=>`Place ${i} decorations`},{id:"fuse",kind:"fusions",n:()=>1,text:()=>"Fuse two bots",need:i=>Zt(i,"fusion").some(t=>t.lvl>0)},{id:"boot",kind:"boots",n:()=>1,text:()=>"Activate a core in the Assembly Bay",need:i=>Zt(i,"assembly").some(t=>t.lvl>0)},{id:"drop",kind:"drops",n:()=>1,text:()=>"Open a supply drop"},{id:"arena",kind:"arenaWins",n:()=>2,text:i=>`Win ${i} Arena battles`,need:i=>Zt(i,"arena").some(t=>t.lvl>0)}],M_=(i,t)=>t===0?{credits:ge(500*ji(i))}:t===1?{cells:ge(150*ji(i))}:{dm:5};function Ha(i,t=Date.now()){const e=ue(i),n=In(t);if(e.mDate===n)return!1;const s=Nn(Ns(n)^i.created>>>0),r=b_.filter(o=>!o.need||o.need(i)),a=[];for(;a.length<3&&r.length;)a.push(r.splice(Math.floor(s()*r.length),1)[0]);return e.missions=a.map((o,l)=>{const c=o.n(i);return{id:o.id,kind:o.kind,n:c,text:o.text(c),reward:M_(i,l)}}),e.mBase={...i.stats},e.mClaimed=[!1,!1,!1],e.bonus=!1,e.mDate=n,!0}const bc=(i,t)=>Math.max(0,(i.stats[t.kind]||0)-(ue(i).mBase[t.kind]||0));function S_(i,t){const e=ue(i),n=e.missions[t];return!n||e.mClaimed[t]||bc(i,n)<n.n?null:(e.mClaimed[t]=!0,Qn(i,n.reward),Be(i,15),n)}const ur=i=>{const t=ue(i);return t.missions.length===3&&t.mClaimed.every(Boolean)&&!t.bonus};function w_(i,t=Date.now()){const e=ue(i);if(!ur(i))return null;e.bonus=!0;const n={dm:10,cells:ge(250*ji(i))};Qn(i,n);const s=Nn(Ns(e.mDate)+3)(),r=s<.35?Er(i,s<.06?"elite":"advanced",Ns(e.mDate)+11,t):null;return Be(i,30),{res:n,gift:r}}const Ga=4*36e5,Ul=2;function oh(i,t=Date.now()){const e=ue(i);for(;e.drops<Ul&&t>=e.drop;)e.drops++,e.drop+=Ga;e.drops>=Ul&&e.drop<t&&(e.drop=t+Ga)}function E_(i,t=Date.now()){const e=ue(i);if(e.drops<=0)return null;e.drops--,e.drops===Ul-1&&e.drop-t>Ga&&(e.drop=t+Ga);const n=Nn(t/1e3>>>0),s={credits:ge(350*ji(i)*(.7+n()*.8)),cells:ge(90*ji(i)*(.7+n()*.8))};n()<.35&&(s.dm=2+Math.floor(n()*5)),Qn(i,s);const r=n(),a=r<.12?Er(i,r<.025?"elite":r<.12&&vi(i)>=3?"advanced":"standard",t/1e3>>>0,t):null;return i.stats.drops=(i.stats.drops||0)+1,Be(i,10),{res:s,gift:a}}const Mc=(i,t=Date.now())=>ue(i).spin!==In(t);function lh(i,t=!1,e=Date.now()){const n=ue(i);if(!t&&!Mc(i,e)||t&&n.adSpin===In(e))return null;const s=Nn(Ns(In(e)+(t?"ad":""))^i.created>>>0),r=s(),a=r<.04?"elite":r<.3?"advanced":"standard";t?n.adSpin=In(e):n.spin=In(e);const o=Er(i,a,s()*1e9>>>0,e);return Be(i,10),{rarity:a,...o}}const Sc=[{id:"collector",name:"Credit Collector",tiers:[1e4,2e5,5e6,1e8],stat:i=>i.stats.collected||0,unit:"credits collected"},{id:"crew",name:"Crew Chief",tiers:[5,12,25,50],stat:i=>i.bots.length,unit:"bots"},{id:"dex",name:"Botanist of Bots",tiers:[10,25,50,82],stat:i=>Gl(i),unit:"species discovered"},{id:"fuser",name:"Fusion Pioneer",tiers:[1,10,50,250],stat:i=>i.stats.fusions||0,unit:"fusions"},{id:"feeder",name:"Snack Time",tiers:[50,500,5e3,5e4],stat:i=>i.stats.feeds||0,unit:"feedings"},{id:"farmer",name:"Power Farmer",tiers:[10,100,1e3,5e3],stat:i=>i.stats.harvests||0,unit:"harvests"},{id:"builder",name:"Master Builder",tiers:[3,6,10,15],stat:i=>vi(i),unit:"Command Center level"},{id:"loyal",name:"Loyal Commander",tiers:[3,7,28,100],stat:i=>ue(i).total,unit:"days logged in"},{id:"streak",name:"On a Roll",tiers:[3,7,14,30],stat:i=>ue(i).best,unit:"day streak"},{id:"land",name:"Land Baron",tiers:[1,4,8,16],stat:i=>i.landBought,unit:"plots bought"},{id:"decorator",name:"Interior Designer",tiers:[5,25,75,200],stat:i=>i.stats.decor||0,unit:"decorations"},{id:"veteran",name:"Veteran",tiers:[5,15,30,60],stat:i=>i.lvl,unit:"Commander level"},{id:"champion",name:"Arena Champion",tiers:[5,50,250,1e3],stat:i=>i.stats.arenaWins||0,unit:"Arena wins"},{id:"hoarder",name:"Supply Hoarder",tiers:[5,30,150,600],stat:i=>i.stats.drops||0,unit:"supply drops"}],Fl=[5,15,40,100],wc=(i,t)=>ue(i).ach[t.id]||0,Va=(i,t)=>{const e=wc(i,t);return e<t.tiers.length&&t.stat(i)>=t.tiers[e]};function A_(i,t){const e=Sc.find(s=>s.id===t);if(!e||!Va(i,e))return null;const n=wc(i,e);return ue(i).ach[t]=n+1,i.res.dm+=Fl[n],Be(i,25*(n+1)),{a:e,tier:n,dm:Fl[n]}}function Uo(i,t=Date.now()){const e=ue(i);return{day:yc(i,t),missions:e.missions.some((n,s)=>!e.mClaimed[s]&&bc(i,n)>=n.n)||ur(i),ach:Sc.some(n=>Va(i,n)),spin:Mc(i,t),drop:e.drops>0}}const Rn="#2c3340",ha="#cdd5df";function Ec(i,t=1){const e=gt[i],n=Wt[e.el[0]].color,s=e.el[1]?Wt[e.el[1]].color:Fn(n,-.35),r=Qt[e.rarity].color,a=new Ce,o=new sn;let l=0;const c=x=>(a.add(x),x),d=x=>{const m=new sn;return x(m),m.build()};let h=()=>{};switch(e.chassis){case"orb":{l=.55,o.sphere(.26,n,0,0,0,{w:14,h:10}),o.sphere(.27,s,0,0,0,{w:14,h:4,theta:Math.PI*.18}),o.sphere(.09,r,0,.02,.22,{glow:!0,w:8,h:6}),o.sphere(.05,"#ffffff",.02,.05,.27,{glow:!0,w:6,h:4});const x=c(d(m=>m.add(new nn(.38,.025,5,28),s)));x.rotation.x=Math.PI/2.4,h=m=>{x.rotation.z=m*1.8};break}case"drone":{l=.6,o.box(.34,.14,.34,n,0,-.07,0),o.sphere(.16,s,0,.05,0,{theta:Math.PI/2,w:10,h:5}),o.box(.12,.05,.02,r,0,-.01,.18,{glow:!0});const x=[];for(const[m,p]of[[.28,.28],[-.28,.28],[.28,-.28],[-.28,-.28]]){o.box(.24,.03,.04,Rn,m/2,0,p/2,{ry:Math.atan2(m,p)});const _=c(d(S=>{S.cyl(.13,.13,.012,10,ha,0,0,0,{glass:!0}),S.box(.24,.01,.03,Rn)}));_.position.set(m,.02,p),x.push(_)}h=m=>x.forEach((p,_)=>{p.rotation.y=m*30*(_%2?1:-1)});break}case"rover":{o.box(.5,.18,.36,n,0,.12,0),o.box(.3,.1,.3,s,-.05,.3,0),o.cyl(.02,.02,.22,5,ha,.12,.3,0),o.box(.14,.08,.08,Rn,.12,.52,0),o.box(.02,.04,.06,r,.19,.53,0,{glow:!0});const x=[];for(const[m,p]of[[.17,.2],[-.17,.2],[.17,-.2],[-.17,-.2]]){const _=c(d(S=>S.cyl(.09,.09,.07,10,Rn,0,-.035,0,{rx:Math.PI/2})));_.position.set(m,.09,p),x.push(_)}i==="digger"&&o.add(new Ji(.08,.22,7),ha,.32,.18,0,{rz:-Math.PI/2}),i==="ember"&&o.cyl(.035,.035,.2,5,Rn,.25,.28,0,{rz:-.9}),h=(m,p)=>x.forEach(_=>{_.rotation.z=p?-m*8:0});break}case"walker":{const x=c(d(p=>{p.box(.36,.22,.3,n,0,0,0),p.box(.3,.06,.26,s,0,.22,0),p.box(.14,.05,.02,r,.06,.12,.16,{glow:!0}),p.box(.06,.05,.02,r,-.08,.12,.16,{glow:!0})}));x.position.y=.34;const m=[];for(const p of[.11,-.11]){const _=c(d(S=>{S.box(.07,.32,.07,Rn,0,-.32,0),S.box(.13,.04,.16,s,0,-.34,.02)}));_.position.set(p,.36,0),m.push(_)}h=(p,_)=>{m.forEach((S,y)=>{S.rotation.x=_?Math.sin(p*9+y*Math.PI)*.5:0}),x.position.y=.34+(_?Math.abs(Math.sin(p*9))*.03:0)};break}case"android":{const x=c(d(p=>{p.box(.24,.3,.16,n,0,0,0),p.box(.26,.06,.18,s,0,.24,0),p.sphere(.12,ha,0,.42,0,{w:10,h:8}),p.box(.18,.05,.05,r,0,.43,.09,{glow:!0}),p.sphere(.035,r,0,.12,.085,{glow:!0,w:6,h:4})}));x.position.y=.3;const m=[];for(const[p,_,S,y]of[[.16,.56,.26,s],[-.16,.56,.26,s],[.07,.3,.3,Rn],[-.07,.3,.3,Rn]]){const A=c(d(E=>E.box(.07,S,.07,y,0,-S,0)));A.position.set(p,_,0),m.push(A)}i==="sprout"&&o.add(new _i(.08,0),"#5fdc5a",0,.86,0),h=(p,_)=>{m.forEach((S,y)=>{S.rotation.x=_?Math.sin(p*8+y%2*Math.PI+(y>1?Math.PI:0))*.55:Math.sin(p*1.5+y)*.05})};break}case"mech":{const x=c(d(p=>{p.box(.46,.34,.34,n,0,0,0),p.box(.2,.12,.2,s,0,.34,0),p.box(.16,.05,.02,r,0,.4,.105,{glow:!0});for(const _ of[.29,-.29])p.box(.14,.14,.2,s,_,.16,0),p.box(.11,.3,.11,Rn,_,-.14,.02)}));x.position.y=.36;const m=[];for(const p of[.13,-.13]){const _=c(d(S=>{S.box(.12,.34,.12,Rn,0,-.34,0),S.box(.18,.05,.22,s,0,-.36,.02)}));_.position.set(p,.38,0),m.push(_)}h=(p,_)=>{m.forEach((S,y)=>{S.rotation.x=_?Math.sin(p*5+y*Math.PI)*.35:0}),x.rotation.y=_?Math.sin(p*5)*.06:0};break}case"crawler":{const x=c(d(p=>{p.sphere(.16,n,.18,0,0,{w:10,h:7}),p.sphere(.13,s,0,0,0,{w:10,h:7}),p.sphere(.11,n,-.16,0,0,{w:10,h:7}),p.sphere(.035,r,.31,.04,.06,{glow:!0,w:6,h:4}),p.sphere(.035,r,.31,.04,-.06,{glow:!0,w:6,h:4})}));x.position.y=.2;const m=[];for(let p=0;p<6;p++){const _=.16-(p>>1)*.16,S=p%2?1:-1,y=c(d(A=>A.box(.03,.03,.24,Rn,0,0,.1*S)));y.position.set(_,.18,.08*S),y.rotation.x=.5*S,m.push(y)}h=(p,_)=>m.forEach((S,y)=>{S.rotation.y=_?Math.sin(p*14+y)*.35:0});break}}const u=o.build("bot");a.add(u),(e.chassis==="orb"||e.chassis==="drone")&&(u.position.y=0);const f=new Ce;for(;a.children.length;)f.add(a.children[0]);if(f.position.y=l,a.add(f),l){const x=new $t(new pc(.22,12),new Oe({color:Wt[e.el[0]].glow,transparent:!0,opacity:.35,depthWrite:!1}));x.rotation.x=-Math.PI/2,x.position.y=.02,x.name="hoverGlow",a.add(x)}const g=.95+on.indexOf(e.rarity)*.08+Math.min(.25,(t-1)*.008);return a.scale.setScalar(g),a.traverse(x=>{x.isMesh&&(x.castShadow=!0)}),{group:a,hover:l,anim:(x,m)=>{h(x,m),l&&(f.position.y=l+Math.sin(x*2.2+t)*.05)}}}const Ui={strike:{name:"Strike",el:"none",power:.8,desc:"A plain, honest hit."},solar:{name:"Sunburst",el:"solar",power:1,fx:"drain",desc:"Heals for a third of the damage dealt."},plasma:{name:"Plasma Torch",el:"plasma",power:1.2,fx:"burn",chance:.4,desc:"May set the target burning."},hydro:{name:"Tidal Jet",el:"hydro",power:1.15,desc:"A crushing jet of water."},cryo:{name:"Cryo Lance",el:"cryo",power:1,fx:"freeze",chance:.3,desc:"May freeze the target for a turn."},geo:{name:"Rockslide",el:"geo",power:1.25,desc:"Heavy and hard to argue with."},bio:{name:"Overgrowth",el:"bio",power:.75,fx:"heal",desc:"Strikes, then restores 18% of its hull."},volt:{name:"Arc Discharge",el:"volt",power:1.1,fx:"stun",chance:.2,desc:"May short-circuit the target."},alloy:{name:"Plate Up",el:"alloy",power:.6,fx:"shield",desc:"Hits, then halves the next blow it takes."},void:{name:"Null Pulse",el:"void",power:1.25,desc:"A wave of absolute nothing."},photon:{name:"Prism Laser",el:"photon",power:1.1,fx:"pierce",desc:"Cuts straight through shields."},kinetic:{name:"Mass Driver",el:"kinetic",power:1.45,fx:"reckless",chance:.2,desc:"Devastating, but misses one shot in five."},aero:{name:"Cyclone",el:"aero",power:1,fx:"first",desc:"Always strikes first."},gravity:{name:"Crush",el:"gravity",power:1,fx:"crush",desc:"Hits harder the healthier the target is."},chrono:{name:"Rewind",el:"chrono",power:.7,fx:"heal",desc:"Strikes, then winds back 18% of its damage."},neural:{name:"Overload",el:"neural",power:1,fx:"weaken",desc:"Lowers the target's attack by 20%."}},$u=i=>[...gt[i].el.filter(t=>Ui[t]).map(t=>t),"strike"];function Ac(i,t){if(i==="none")return 1;const e=t.some(s=>Wt[i].strong.includes(s)),n=t.some(s=>(Wt[s].strong||[]).includes(i));return e&&!n?1.35:n&&!e?.8:1}const T_={drone:14,orb:12,android:11,rover:10,crawler:9,walker:8,mech:6};function ch(i,t,e,n){const s=Vl({sp:i,lvl:t});return{sp:i,lvl:t,name:e||gt[i].name,hp:s.hp,max:s.hp,atk:Math.round(s.atk*1.6),spd:T_[gt[i].chassis]+t*.25+on.indexOf(gt[i].rarity),shield:!1,burn:0,frozen:!1,weak:0,bot:n}}const fi=i=>Math.round(i.reduce((t,e)=>{const n=Vl({sp:e.sp,lvl:e.lvl});return t+Math.sqrt(n.hp*n.atk)},0));function R_(i,t,e){return{A:i,B:t,a:0,b:0,turn:0,seed:e,over:""}}function C_(i,t,e,n){const s=t==="A"?i.A[i.a]:i.B[i.b],r=t==="A"?i.B[i.b]:i.A[i.a],a=Ui[e],o={side:t,who:t==="A"?i.a:i.b,target:t==="A"?i.b:i.a,move:e,dmg:0,eff:1,crit:!1,miss:!1,heal:0,status:"",ko:!1};if(s.frozen)return s.frozen=!1,o.status="frozen",o.miss=!0,o;if(a.fx==="reckless"&&n()<(a.chance||0))return o.miss=!0,o;o.eff=Ac(a.el,gt[r.sp].el),o.crit=n()<.1;let l=s.atk*(1-s.weak)*a.power*o.eff*(.9+n()*.2)*(o.crit?1.5:1);return a.fx==="crush"&&(l*=.7+.6*(r.hp/r.max)),r.shield&&a.fx!=="pierce"&&(l*=.5,r.shield=!1,o.status="shielded"),o.dmg=Math.max(1,Math.round(l)),r.hp=Math.max(0,r.hp-o.dmg),a.fx==="drain"&&(o.heal=Math.round(o.dmg/3),s.hp=Math.min(s.max,s.hp+o.heal)),a.fx==="heal"&&(o.heal=Math.round(s.max*.18),s.hp=Math.min(s.max,s.hp+o.heal)),a.fx==="shield"&&(s.shield=!0),a.fx==="weaken"&&(r.weak=Math.min(.5,r.weak+.2),o.status="weakened"),(a.fx==="burn"||a.fx==="freeze"||a.fx==="stun")&&r.hp>0&&n()<(a.chance||0)&&(a.fx==="burn"?(r.burn=3,o.status="burning"):(r.frozen=!0,o.status=a.fx==="freeze"?"frozen solid":"stunned")),o.ko=r.hp<=0,o}function Fo(i,t){const e=t==="A"?i.A[i.a]:i.B[i.b],n=t==="A"?i.B[i.b]:i.A[i.a];let s="strike",r=-1;for(const a of $u(e.sp)){const o=Ui[a];let l=o.power*Ac(o.el,gt[n.sp].el)*(o.fx==="reckless"?.8:1);(o.fx==="heal"||o.fx==="drain")&&e.hp<e.max*.45&&(l*=1.6),o.fx==="shield"&&!e.shield&&e.hp<e.max*.6&&(l+=.5),o.fx==="weaken"&&n.weak<.2&&(l+=.2),l>r&&(r=l,s=a)}return s}function P_(i,t,e){if(i.over)return[];const n=Nn(i.seed+ ++i.turn*104729),s=[],r=i.A[i.a],a=i.B[i.b],o=(Ui[t].fx==="first"?100:0)+r.spd,l=(Ui[e].fx==="first"?100:0)+a.spd,c=o>l||o===l&&n()<.5?[["A",t],["B",e]]:[["B",e],["A",t]];for(const[d,h]of c)(d==="A"?i.A[i.a]:i.B[i.b]).hp<=0||(d==="A"?i.B[i.b]:i.A[i.a]).hp<=0||s.push(C_(i,d,h,n));for(const[d,h]of[["A",i.A[i.a]],["B",i.B[i.b]]])if(h.hp>0&&h.burn>0){const u=Math.max(1,Math.round(h.max*.06));h.hp=Math.max(0,h.hp-u),h.burn--,s.push({side:d==="A"?"B":"A",who:-1,target:d==="A"?i.a:i.b,move:"burn",dmg:u,eff:1,crit:!1,miss:!1,heal:0,status:"burn",ko:h.hp<=0})}if(i.A[i.a].hp<=0){const d=i.A.findIndex(h=>h.hp>0);d<0?i.over="B":i.a=d}if(i.B[i.b].hp<=0){const d=i.B.findIndex(h=>h.hp>0);d<0?i.over=i.over?i.over:"A":i.b=d}return i.turn>=60&&!i.over&&(i.over=i.A.reduce((d,h)=>d+h.hp/h.max,0)>=i.B.reduce((d,h)=>d+h.hp/h.max,0)?"A":"B"),s}const Ii=[["Bronze III",0],["Bronze II",100],["Bronze I",200],["Silver III",350],["Silver II",500],["Silver I",650],["Gold III",850],["Gold II",1050],["Gold I",1250],["Platinum",1500],["Diamond",1800],["Singularity",2200]],ir=["#cd7f32","#cd7f32","#cd7f32","#c0c8d4","#c0c8d4","#c0c8d4","#ffd36a","#ffd36a","#ffd36a","#7af7ff","#9fd0ff","#c49bff"],Qi=i=>{let t=0;for(let e=0;e<Ii.length;e++)i>=Ii[e][1]&&(t=e);return t},ts=5,Ol=90*6e4;function Bn(i){const t=i;return t.arena||(t.arena={trophies:0,best:0,seasonBest:0,season:Wu(),tickets:ts,tAt:Date.now(),wins:0,losses:0,rivals:[],rAt:0,team:[],dayWins:0,day:""}),t.arena}const Wu=(i=Date.now())=>{const t=new Date(i),e=(t.getDay()+6)%7;return t.setHours(0,0,0,0),t.setDate(t.getDate()-e),`${t.getFullYear()}-${t.getMonth()+1}-${t.getDate()}`},L_=(i=Date.now())=>{const t=new Date(i),e=(t.getDay()+6)%7;return t.setHours(0,0,0,0),t.setDate(t.getDate()-e+7),t.getTime()};function Xu(i,t=Date.now()){const e=Bn(i);for(;e.tickets<ts&&t>=e.tAt+Ol;)e.tickets++,e.tAt+=Ol;e.tickets>=ts&&(e.tAt=t)}function qu(i,t){const e=1+i.lvl*.5;return{dm:10+t*8,cells:ge(300*e*(1+t*.4)),credits:ge(800*e*(1+t*.5))}}function Yu(i,t=Date.now()){const e=Bn(i),n=Wu(t);if(e.season===n)return null;const s=Qi(e.seasonBest),r=e.seasonBest>0?qu(i,s):null;return r&&Qn(i,r),e.season=n,e.trophies=Math.floor(e.trophies*.75),e.seasonBest=e.trophies,r?{league:s,reward:r}:null}const dh=["Nova","Astra","Kepler","Lumen","Vega","Orion","Tycho","Halley","Sagan","Ceres","Juno","Selene","Rhea","Titan","Helix","Zenith","Polaris","Draco","Lyra","Corvus"],hh=["Station","Colony","Outpost","Haven","Reach","Spire","Hold","Landing","Array","Ring"],uh=["#1b6fd8","#d83a3a","#1f9c5a","#7a3fd6","#e08a1a","#14202e","#0fb3c9","#c9324f"],fh=["star","planet","bolt","gear","rocket","circle"];function Is(i){const t=Bn(i);let e=t.team.map(n=>i.bots.find(s=>s.id===n)).filter(n=>!!n&&!n.stored);if(e.length<Math.min(3,i.bots.filter(n=>!n.stored).length)){const n=[...i.bots].filter(s=>!s.stored&&!e.includes(s)).sort((s,r)=>fi([r])-fi([s]));e=[...e,...n].slice(0,3),t.team=e.map(s=>s.id)}return e.slice(0,3)}function ph(i,t=Date.now()){const e=Bn(i),n=fi(Is(i).map(a=>({sp:a.sp,lvl:a.lvl}))),s=Nn(Ns(String(t>>>0))^i.created>>>0),r=Qi(e.trophies);return e.rivals=[0,1,2].map(a=>{const o=Math.max(40,n*[.78,.98,1.2][a]*(1+r*.02)),l=Math.min(6,Math.floor(r/2)+(a===2?2:1)),c=Xn.filter(h=>on.indexOf(gt[h].rarity)<=l),d=[];for(let h=0;h<3;h++){const u=c[Math.floor(s()*c.length)];let f=1;for(;f<40&&fi([...d,{sp:u,lvl:f+1}])<=o*((h+1)/3);)f++;d.push({sp:u,lvl:f})}return{name:`${dh[Math.floor(s()*dh.length)]} ${hh[Math.floor(s()*hh.length)]}`,banner:{bg:uh[Math.floor(s()*uh.length)],fg:s()<.5?"#ffd23a":"#ffffff",emblem:fh[Math.floor(s()*fh.length)]},team:d,diff:a,power:fi(d)}}),e.rAt=t,e.rivals}const Ku=[18,26,36];function sr(i){const t=Bn(i);return Zt(i,"arena").some(e=>e.lvl>0)?t.tickets<=0?{ok:!1,why:"No battle tickets: one recharges every 90 minutes"}:Is(i).length<1?{ok:!1,why:"You need bots to fight"}:{ok:!0}:{ok:!1,why:"Build the Arena first"}}function D_(i,t,e=Date.now()){const n=Bn(i);if(!sr(i).ok)return null;const r=n.rivals[t];if(!r)return null;n.tickets===ts&&(n.tAt=e),n.tickets--;const a=Is(i).map(o=>ch(o.sp,o.lvl,o.nick,o.id));return{bt:R_(a,r.team.map(o=>ch(o.sp,o.lvl)),e/1e3>>>0),rival:r}}function I_(i,t,e,n=Date.now()){const s=Bn(i),r=new Date(n).toDateString();s.day!==r&&(s.day=r,s.dayWins=0);const a=1+i.lvl*.5;let o,l;t?(l=Ku[e],s.wins++,s.dayWins++,o={credits:ge(300*a*(1+e*.5)),cells:ge(80*a*(1+e*.5))},s.dayWins===1&&(o.dm=5),i.stats.arenaWins=(i.stats.arenaWins||0)+1):(l=-14,s.losses++,o={credits:ge(60*a)});const c=Qi(s.trophies);s.trophies=Math.max(0,s.trophies+l),s.best=Math.max(s.best,s.trophies),s.seasonBest=Math.max(s.seasonBest,s.trophies);const d=Qi(s.trophies),h=(Zt(i,"arena")[0]||{lvl:1}).lvl;for(const u of Object.keys(o))u!=="dm"&&(o[u]=ge(o[u]*(1+.1*(h-1))));return Qn(i,o),Be(i,t?20+e*10:5),s.rivals=[],{reward:o,dt:l,promoted:d>c?d:-1,league:d}}const Bl=new I(0,0,-260),mh=new Set(["photon","volt","solar","neural","void"]);class N_{constructor(t){this.group=new Ce,this.A=[],this.B=[],this.t=0,this.anims=[],this.onImpact=()=>{};const e=new sn;e.cyl(7.2,7.6,.6,32,"#2a3446",0,-.6),e.cyl(7,7,.06,48,"#3a4a64",0,0),e.add(new nn(6.9,.08,6,64),"#6ee7ff",0,.05,0,{rx:Math.PI/2,glow:!0}),e.add(new nn(3.2,.05,6,48),"#6ee7ff",0,.06,0,{rx:Math.PI/2,glow:!0});for(const[s,r]of[[-3.2,"#4aa8ff"],[3.2,"#ff5a6a"]])e.cyl(1.4,1.4,.05,24,r,s,.05,0,{glow:!0}),e.cyl(1.25,1.25,.06,24,"#1a2232",s,.06,0);for(let s=0;s<10;s++){const r=s/10*Math.PI*2;e.box(.3,2.2,.3,"#c8d0da",Math.cos(r)*6.6,0,Math.sin(r)*6.6),e.box(.34,.12,.34,"#6ee7ff",Math.cos(r)*6.6,2.2,Math.sin(r)*6.6,{glow:!0})}e.cyl(.1,1.2,4,10,"#3a4250",0,-4.6,0);const n=e.build("arena");n.traverse(s=>{s.isMesh&&(s.receiveShadow=!0)}),this.group.add(n),this.ring=new $t(new nn(7.6,.03,4,96),new Oe({color:"#7af7ff",transparent:!0,opacity:.18})),this.ring.rotation.x=Math.PI/2,this.ring.position.y=6,this.group.add(this.ring),this.group.position.copy(Bl),t.add(this.group)}clear(){for(const t of[...this.A,...this.B])this.group.remove(t.m.group);this.A=[],this.B=[],this.anims=[]}setup(t){this.clear();const e=(s,r,a)=>{const o=s==="A"?-1:1;return a?new I(o*2.4,.1,0):new I(o*4.8,.1,r%2?1.8:-1.8)},n=(s,r,a,o)=>{const l=Ec(s.sp,s.lvl);l.group.scale.multiplyScalar(2.7);const c=e(r,a,o);return l.group.position.copy(c),l.group.rotation.y=r==="A"?Math.PI/2:-Math.PI/2,this.group.add(l.group),{m:l,home:c,ko:s.hp<=0,flash:0}};this.A=t.A.map((s,r)=>n(s,"A",r,r===t.a)),this.B=t.B.map((s,r)=>n(s,"B",r,r===t.b))}worldPos(t,e){const n=(t==="A"?this.A:this.B)[e];return n?n.m.group.position.clone().add(this.group.position).add(new I(0,1.4,0)):this.group.position.clone()}tween(t,e,n){this.anims.push({t:0,dur:t,fn:e,done:n})}play(t,e,n=1){return new Promise(s=>{let r=0;const a=()=>{if(r>=t.length){this.reposition(e,n,s);return}const o=t[r++];this.playHit(o,n,a)};a()})}playHit(t,e,n){const s=t.side==="A"?this.A:this.B,a=(t.side==="A"?this.B:this.A)[t.target];if(!a){n();return}if(t.move==="burn"){a.flash=1,this.onImpact(t,a.m.group.position.clone().add(this.group.position).add(new I(0,1.6,0))),this.tween(.35/e,()=>{},n);return}const o=s[t.who];if(!o){n();return}const l=Ui[t.move].el,c=l==="none"?"#ffffff":Wt[l].glow,d=o.m.group.position.clone(),h=d.clone().lerp(a.m.group.position,.18);this.tween(.18/e,u=>o.m.group.position.lerpVectors(d,h,Math.sin(u*Math.PI/2)),()=>{const u=o.m.group.position.clone().add(new I(0,1.2,0)),f=a.m.group.position.clone().add(new I(0,1.1,0));let g;if(mh.has(l)){const m=u.distanceTo(f),p=new $t(new mn(.09,.09,m,8),new Oe({color:c,toneMapped:!1,transparent:!0}));p.position.copy(u).lerp(f,.5),p.lookAt(f),p.rotateX(Math.PI/2),g=p}else g=new $t(new _i(.28,1),new Oe({color:c,toneMapped:!1})),g.position.copy(u);this.group.add(g);const x=mh.has(l);this.tween((x?.22:.32)/e,m=>{x?(g.material.opacity=1-m*.6,g.scale.x=g.scale.z=1+Math.sin(m*30)*.3):(g.position.lerpVectors(u,f,m),g.position.y+=Math.sin(m*Math.PI)*.8,g.rotation.y+=.3)},()=>{this.group.remove(g),t.miss||(a.flash=1),this.onImpact(t,f.clone().add(this.group.position)),this.tween(.22/e,m=>o.m.group.position.lerpVectors(h,d,m),()=>{t.ko?this.knockOut(a,e,n):n()})})})}knockOut(t,e,n){t.ko=!0;const s=t.m.group,r=s.rotation.z,a=s.position.y;this.tween(.5/e,o=>{s.rotation.z=r+o*1.4*(s.position.x<0?-1:1),s.position.y=a-o*.3,s.scale.setScalar(2.7*(1-o*.35))},()=>{s.visible=!1,n()})}reposition(t,e,n){const s=[];for(const[r,a,o]of[["A",this.A,t.a],["B",this.B,t.b]]){const l=a[o];if(!l||l.ko)continue;const c=new I((r==="A"?-1:1)*2.4,.1,0);if(l.m.group.position.distanceTo(c)>.1){const d=l.m.group.position.clone();s.push(()=>this.tween(.4/e,h=>l.m.group.position.lerpVectors(d,c,h))),l.home=c}}s.forEach(r=>r()),this.tween(s.length?.45/e:.05,()=>{},n)}update(t){this.t+=t;const e=this.t;this.ring.rotation.z=e*.2;for(const n of[...this.anims]){n.t+=t;const s=Math.min(1,n.t/n.dur);n.fn(s),s>=1&&(this.anims.splice(this.anims.indexOf(n),1),n.done&&n.done())}for(const n of[...this.A,...this.B])if(!n.ko&&(n.m.anim(e,!1),n.flash>0)){n.flash=Math.max(0,n.flash-t*4);const s=2.7*(1+n.flash*.12);n.m.group.scale.setScalar(s)}}}class U_{constructor(t,e){this.canvas=t,this.scene=new hc,this.island=new s_,this.views=new Map,this.bots=new Map,this.cam={x:0,z:1,dist:30,yaw:Math.PI/4,tx:0,tz:1,tdist:30,tyaw:Math.PI/4},this.ghost=null,this.ghostObj=null,this.ghostFoot=null,this.selected=null,this.t=0,this.ray=new em,this.ptr=new Dt,this.fx=[],this.onTap=()=>{},this.pod=null,this.podPick=null,this.podY=0,this.mode="island",this.arena=null,this.saved=null,this.onGhostMove=()=>{},this.look={primary:"#e9eef5",accent:"#22c7e8",banner:{bg:"#1b6fd8",fg:"#ffd23a",emblem:"star"}};const n=/Android|iPhone|iPad|iPod/i.test(navigator.userAgent)||navigator.maxTouchPoints>1&&Math.min(screen.width,screen.height)<820;this.quality=e==="auto"?n?"low":"high":e,this.renderer=new Kx({canvas:t,antialias:this.quality==="high",powerPreference:"high-performance"}),this.renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,this.quality==="high"?2:1.5)),this.renderer.outputColorSpace=He,this.renderer.toneMapping=jl,this.renderer.toneMappingExposure=1.05,this.renderer.shadowMap.enabled=!0,this.renderer.shadowMap.type=Xh,this.camera=new dn(30,1,1,16e3);const s=new I(-.55,.62,.42).normalize();this.sun=new ka("#fff3df",2.7),this.sun.position.copy(s).multiplyScalar(40),this.sun.castShadow=!0;const r=this.quality==="high"?2048:1024;this.sun.shadow.mapSize.set(r,r);const a=this.sun.shadow.camera;a.left=-22,a.right=22,a.top=22,a.bottom=-22,a.near=1,a.far=110,this.sun.shadow.bias=-5e-4,this.sun.shadow.normalBias=.02,this.scene.add(this.sun,this.sun.target),this.scene.add(new Ru("#bcd8ff","#3a2a22",.85)),this.scene.add(new Qp("#405070",.35));const o=new ka("#7ab6ff",.6);o.position.set(30,10,-30),this.scene.add(o),this.backdrop=new i_(this.renderer,s,this.quality),this.scene.add(this.backdrop.group),this.scene.add(this.island.group),this.selRing=new $t(new mc(.9,1,48),new Oe({color:"#6ee7ff",transparent:!0,opacity:.9,depthWrite:!1,side:Cn})),this.selRing.rotation.x=-Math.PI/2,this.selRing.visible=!1,this.scene.add(this.selRing),this.resize(),window.addEventListener("resize",()=>this.resize()),this.input()}enterArena(){this.arena||(this.arena=new N_(this.scene)),this.mode="arena",this.saved={x:this.cam.tx,z:this.cam.tz,dist:this.cam.tdist,yaw:this.cam.tyaw},this.cam.tx=Bl.x,this.cam.tz=Bl.z+.8,this.cam.tdist=19,this.cam.tyaw=0,this.select(null)}exitArena(){this.mode="island",this.saved&&(this.cam.tx=this.saved.x,this.cam.tz=this.saved.z,this.cam.tdist=this.saved.dist,this.cam.tyaw=this.saved.yaw)}resize(){const t=this.canvas.clientWidth||window.innerWidth,e=this.canvas.clientHeight||window.innerHeight;this.renderer.setSize(t,e,!1),this.camera.aspect=t/e,this.camera.updateProjectionMatrix()}placeCamera(){const t=this.cam,e=.18;t.x+=(t.tx-t.x)*e,t.z+=(t.tz-t.z)*e,t.dist+=(t.tdist-t.dist)*e,t.yaw+=(t.tyaw-t.yaw)*e;const n=Ua.degToRad(this.mode==="arena"?32:Ua.lerp(56,34,Ci((t.dist-14)/52))),s=this.camera.aspect<.8?this.mode==="arena"?1.6:1.35:1,r=t.dist*s;this.camera.position.set(t.x+Math.sin(t.yaw)*Math.cos(n)*r,Math.sin(n)*r,t.z+Math.cos(t.yaw)*Math.cos(n)*r),this.camera.lookAt(t.x,0,t.z),this.sun.target.position.set(t.x,0,t.z),this.sun.position.set(t.x-.55*40,.62*40,t.z+.42*40)}focus(t,e,n){this.cam.tx=t,this.cam.tz=e,n&&(this.cam.tdist=n)}clampCam(){const t=this.cam,e=It/2+2;t.tx=Ci(t.tx,-e,e),t.tz=Ci(t.tz,-e,e),t.tdist=Ci(t.tdist,12,66)}groundAt(t,e){const n=this.canvas.getBoundingClientRect();this.ptr.set((t-n.left)/n.width*2-1,-((e-n.top)/n.height)*2+1),this.ray.setFromCamera(this.ptr,this.camera);const s=new I;return this.ray.ray.intersectPlane(new ci(new I(0,1,0),0),s)?s:null}input(){const t=this.canvas,e=new Map;let n=!1,s=0,r=null,a=!1;const o=()=>{const[c,d]=[...e.values()];return{d:Math.hypot(c.x-d.x,c.y-d.y),a:Math.atan2(d.y-c.y,d.x-c.x),cx:(c.x+d.x)/2,cy:(c.y+d.y)/2}};t.addEventListener("pointerdown",c=>{if(this.mode!=="arena"&&(t.setPointerCapture(c.pointerId),e.set(c.pointerId,{x:c.clientX,y:c.clientY,sx:c.clientX,sy:c.clientY}),n=!1,s=performance.now(),e.size===2&&(r=o()),a=!1,this.ghost&&e.size===1)){const d=this.groundAt(c.clientX,c.clientY);if(d){const[h,u]=Qe({t:this.ghost.t,r:this.ghost.r}),f=this.ghost.x-It/2,g=this.ghost.z-It/2;d.x>=f-.5&&d.x<=f+h+.5&&d.z>=g-.5&&d.z<=g+u+.5&&(a=!0)}}}),t.addEventListener("pointermove",c=>{const d=e.get(c.pointerId);if(!d)return;const h=c.clientX-d.x,u=c.clientY-d.y;if(d.x=c.clientX,d.y=c.clientY,Math.hypot(d.x-d.sx,d.y-d.sy)>7&&(n=!0),!!n){if(e.size===1){if(a&&this.ghost){this.ghostTo(c.clientX,c.clientY);return}if(c.buttons===2){this.cam.tyaw-=h*.008;return}const f=this.cam.dist*.0021*(this.camera.aspect<.8?1.35:1),g=Math.cos(this.cam.yaw),x=Math.sin(this.cam.yaw);this.cam.tx-=(h*g+u*x*1.25)*f,this.cam.tz-=(-h*x+u*g*1.25)*f,this.clampCam()}else if(e.size===2&&r){const f=o();this.cam.tdist*=r.d/Math.max(1,f.d),this.cam.tyaw-=f.a-r.a,r=f,this.clampCam()}}});const l=c=>{const d=e.get(c.pointerId);e.delete(c.pointerId),e.size<2&&(r=null),!(!d||n||c.button===2)&&(performance.now()-s>600||this.tap(c.clientX,c.clientY))};t.addEventListener("pointerup",l),t.addEventListener("pointercancel",c=>e.delete(c.pointerId)),t.addEventListener("contextmenu",c=>c.preventDefault()),t.addEventListener("wheel",c=>{c.preventDefault(),this.mode!=="arena"&&(this.cam.tdist*=Math.pow(1.0015,c.deltaY),this.clampCam())},{passive:!1}),window.addEventListener("keydown",c=>{c.target.tagName!=="INPUT"&&((c.key==="q"||c.key==="Q")&&(this.cam.tyaw+=Math.PI/4),(c.key==="e"||c.key==="E")&&(this.cam.tyaw-=Math.PI/4))})}tap(t,e){if(this.ghost){this.ghostTo(t,e);return}const n=this.canvas.getBoundingClientRect();if(this.ptr.set((t-n.left)/n.width*2-1,-((e-n.top)/n.height)*2+1),this.ray.setFromCamera(this.ptr,this.camera),this.podPick&&this.pod&&this.pod.visible&&this.ray.intersectObject(this.podPick,!1)[0]){this.onTap({drop:!0});return}const s=this.ray.intersectObjects([...this.bots.values()].map(c=>c.pick),!1)[0];if(s){this.onTap({bot:s.object.userData.bot});return}const r=[...this.views.values()].map(c=>c.pick),a=this.ray.intersectObjects(r,!1)[0];if(a){this.onTap({item:a.object.userData.item});return}const o=this.ray.intersectObjects(this.island.holoMeshes(),!1)[0];if(o){this.onTap({plot:o.object.userData.plot});return}const l=this.groundAt(t,e);this.onTap(l?{tile:[Math.floor(l.x+It/2),Math.floor(l.z+It/2)]}:{})}startGhost(t){this.ghost=t,this.island.grid.visible=!0,this.rebuildGhost()}endGhost(){this.ghost=null,this.ghostObj&&this.scene.remove(this.ghostObj),this.ghostObj=null,this.island.grid.visible=!1}ghostTo(t,e){const n=this.groundAt(t,e);if(!n||!this.ghost)return;const[s,r]=Qe({t:this.ghost.t,r:this.ghost.r}),a=Math.round(n.x+It/2-s/2),o=Math.round(n.z+It/2-r/2);(a!==this.ghost.x||o!==this.ghost.z)&&(this.ghost.x=a,this.ghost.z=o,this.onGhostMove())}rotateGhost(){this.ghost&&(this.ghost.r=(this.ghost.r+1)%4,this.rebuildGhost(),this.onGhostMove())}rebuildGhost(){this.ghostObj&&this.scene.remove(this.ghostObj);const t=this.ghost,[e,n]=Qe({t:t.t,r:t.r}),s=new Ce,r=Nl(t.t,1,t.el,this.look);r.group.rotation.y=-t.r*Math.PI/2,r.group.traverse(a=>{const o=a;o.isMesh&&(o.castShadow=!1)}),s.add(r.group),this.ghostFoot=new $t(new rs(e,n),hr.ghostOk),this.ghostFoot.rotation.x=-Math.PI/2,this.ghostFoot.position.y=.04,s.add(this.ghostFoot),this.ghostObj=s,this.scene.add(s)}setGhostOk(t){this.ghost&&(this.ghost.ok=t),this.ghostFoot&&(this.ghostFoot.material=t?hr.ghostOk:hr.ghostBad)}sync(t){this.look={primary:t.paint.primary,accent:t.paint.accent,banner:t.banner};const e=JSON.stringify(this.look),n=[];for(let l=0;l<5;l++)for(let c=0;c<5;c++){const d=`${l},${c}`;Ka(t,d)==="buyable"&&n.push(d)}this.island.build(t.isl.plots,n);const s=new Set;for(const l of t.isl.items){const[c,d]=Qe(l);for(let h=l.x;h<l.x+c;h++)for(let u=l.z;u<l.z+d;u++)s.add(h+","+u)}this.island.scatter(t.isl.plots,s);const r=new Set;for(const l of t.isl.items){r.add(l.id);const c=Fe(t,l.id,"build"),d=`${l.t}|${l.lvl}|${l.el}|${l.r}|${e}|${c?1:0}`;let h=this.views.get(l.id);(!h||h.key!==d)&&(h&&this.scene.remove(h.root),h=this.makeView(l,d,!!c),this.views.set(l.id,h)),this.ghost&&this.ghost.move===l.id?h.root.visible=!1:h.root.visible=!0}for(const[l,c]of this.views)r.has(l)||(this.scene.remove(c.root),this.views.delete(l));const a=new Set;for(const l of t.bots){const c=l.post||l.bay;if(!c)continue;const d=Me(t,c);if(!d)continue;a.add(l.id);const h=`${l.sp}|${Math.floor(l.lvl/5)}`;let u=this.bots.get(l.id);if(!u||u.key!==h){u&&this.scene.remove(u.model.group);const f=Ec(l.sp,l.lvl),g=this.centerOf(d),x=new I(g.x+(Math.random()-.5)*1.6,.26,g.z+(Math.random()-.5)*1.6),m=new $t(new fn(.45,8,6),new Oe({visible:!1}));m.position.y=.45,m.userData.bot=l.id,f.group.add(m),f.group.position.copy(x),this.scene.add(f.group),u={key:h,model:f,pos:x,target:x.clone(),wait:Math.random()*2,bay:c,pick:m},this.bots.set(l.id,u)}u.bay!==c&&(u.bay=c,u.wait=0)}for(const[l,c]of this.bots)a.has(l)||(this.scene.remove(c.model.group),this.bots.delete(l));const o=ue(t);o.drops>0&&o.dropAt?(this.pod||(this.pod=g_(),this.podPick=new $t(new zn(1,1.6,1),new Oe({visible:!1})),this.podPick.position.y=.6,this.pod.add(this.podPick),this.pod.traverse(l=>{l.isMesh&&(l.castShadow=!0)}),this.scene.add(this.pod),this.podY=30),this.pod.position.set(o.dropAt[0]+.5-It/2,this.pod.position.y,o.dropAt[1]+.5-It/2),this.pod.visible=!0):this.pod&&(this.pod.visible=!1,this.scene.remove(this.pod),this.pod=null)}podTop(){return this.pod&&this.pod.visible?new I(this.pod.position.x,this.pod.position.y+1.6,this.pod.position.z):null}centerOf(t){const[e,n]=Qe(t);return new I(t.x+e/2-It/2,0,t.z+n/2-It/2)}topOf(t){const e=this.views.get(t);if(!e)return null;const n=e.root.position.clone();return n.y=e.model.height+.3,n}makeView(t,e,n){const s=new Ce,r=Nl(t.t,t.lvl,t.el,this.look);r.group.rotation.y=-t.r*Math.PI/2,s.add(r.group);const[a,o]=Qe(t);s.position.copy(this.centerOf(t));const l=new $t(new zn(a*.95,Math.max(.6,r.height),o*.95),new Oe({visible:!1}));l.position.y=Math.max(.6,r.height)/2,l.userData.item=t.id,s.add(l);let c;return n&&(c=v_(a,o,Math.max(.8,r.height*.8)),s.add(c),t.lvl===0&&(r.group.scale.y=.25)),this.scene.add(s),{key:e,root:s,model:r,pick:l,scaf:c}}select(t,e){if(this.selected=t,this.selRing.visible=!!t,t&&e){const n=Me(e,t);if(!n)return;const[s,r]=Qe(n),a=this.centerOf(n);this.selRing.position.set(a.x,.05,a.z),this.selRing.scale.setScalar(Math.max(s,r)*.72)}}burst(t,e,n=26){const s=new Float32Array(n*3),r=new Float32Array(n*3);for(let l=0;l<n;l++){s.set([t.x,t.y,t.z],l*3);const c=Math.random()*Math.PI*2,d=Math.random();r.set([Math.cos(c)*d*2.2,2+Math.random()*3,Math.sin(c)*d*2.2],l*3)}const a=new be;a.setAttribute("position",new Ke(s,3));const o=new Mu(a,new fc({color:e,size:.22,transparent:!0,depthWrite:!1,blending:pr}));this.scene.add(o),this.fx.push({pts:o,v:r,life:1})}project(t){const e=new I(t.x,t.y,t.z).project(this.camera),n=this.canvas.getBoundingClientRect();return{x:n.left+(e.x*.5+.5)*n.width,y:n.top+(-e.y*.5+.5)*n.height,vis:e.z<1&&e.z>-1}}frame(t,e){this.t+=t;const n=this.t;this.mode==="arena"&&(this.cam.tyaw=Math.sin(n*.15)*.35,this.arena?.update(t)),this.placeCamera(),this.backdrop.update(n,this.camera),this.island.update(n);for(const[s,r]of this.views){const a=!!(Fe(e,s,"craft")||Fe(e,s,"fuse")),o=Me(e,s),l=o&&o.t==="assembly"?e.cores.filter(c=>c.state!=="waiting").map(c=>({color:Qt[gt[c.sp].rarity].color,ready:c.state==="ready"})):void 0;if(r.model.anim?.(n,{working:a,ready:e.ready[s]?1:0,cores:l}),r.scaf){const c=r.scaf.getObjectByName("crane");c&&(c.rotation.y=n*.8)}}for(const[,s]of this.bots){const r=Me(e,s.bay);if(!r)continue;const a=this.centerOf(r),o=s.target.clone().sub(s.pos);o.y=0;const l=o.length();let c=!1;if(l>.05){c=!0,o.normalize(),s.pos.addScaledVector(o,Math.min(l,t*(l>2?2.2:.7))),s.pos.y+=(s.target.y-s.pos.y)*Math.min(1,t*4);const d=Math.atan2(o.x,o.z),h=s.model.group;let u=d-h.rotation.y;u=Math.atan2(Math.sin(u),Math.cos(u)),h.rotation.y+=u*Math.min(1,t*6)}else if(s.wait-=t,s.wait<=0){const d=Math.random()*Math.PI*2,h=r.t==="bay",[u,f]=Qe(r),g=h?.35+Math.random()*.75:Math.max(u,f)/2+.25+Math.random()*.3;s.target.set(a.x+Math.cos(d)*g,h?.26:0,a.z+Math.sin(d)*g),s.wait=(h?1.5:3)+Math.random()*4}s.model.group.position.copy(s.pos),s.model.anim(n,c)}if(this.selRing.visible&&(this.selRing.material.opacity=.55+Math.sin(n*4)*.3),this.pod&&this.pod.visible){this.podY=Math.max(0,this.podY-t*Math.max(4,this.podY*1.6)),this.pod.position.y=this.podY;const s=this.pod.userData.flame;s.visible=this.podY>.05,s.scale.y=.8+Math.random()*.5,this.pod.userData.beacon.material.color.set(Math.sin(n*5)>0?"#7cf29a":"#1a4a2a"),this.pod.rotation.y+=t*(this.podY>0?2:0)}if(this.ghost&&this.ghostObj){const[s,r]=Qe({t:this.ghost.t,r:this.ghost.r});this.ghostObj.position.set(this.ghost.x+s/2-It/2,.02+Math.sin(n*5)*.03,this.ghost.z+r/2-It/2)}for(const s of[...this.fx]){s.life-=t*1.1;const r=s.pts.geometry.attributes.position;for(let a=0;a<r.count;a++)s.v[a*3+1]-=t*6,r.setXYZ(a,r.getX(a)+s.v[a*3]*t,r.getY(a)+s.v[a*3+1]*t,r.getZ(a)+s.v[a*3+2]*t);r.needsUpdate=!0,s.pts.material.opacity=Math.max(0,s.life),s.life<=0&&(this.scene.remove(s.pts),s.pts.geometry.dispose(),this.fx.splice(this.fx.indexOf(s),1))}this.renderer.render(this.scene,this.camera)}}class F_{constructor(t){this.renderer=t,this.scene=new hc,this.cam=new dn(30,1,.1,100),this.cache=new Map,this.size=192,this.rt=new Sn(this.size,this.size,{samples:4}),this.rt.texture.colorSpace=He;const e=new ka("#fff3df",2.6);e.position.set(-3,5,4),this.scene.add(e,new Ru("#cfe4ff","#3a2a22",1.1));const n=new ka("#7ab6ff",.9);n.position.set(4,2,-4),this.scene.add(n)}shoot(t,e,n,s){const r=this.cache.get(e);if(r)return r;this.scene.add(t),this.cam.position.set(n*.7,s+n*.55,n*.85),this.cam.lookAt(0,s*.45,0);const a=this.renderer.getRenderTarget(),o=this.renderer.getClearColor(new Nt),l=this.renderer.getClearAlpha(),c=this.renderer.shadowMap.enabled;this.renderer.setClearColor(0,0),this.renderer.setRenderTarget(this.rt),this.renderer.clear(),this.renderer.render(this.scene,this.cam);const d=new Uint8Array(this.size*this.size*4);this.renderer.readRenderTargetPixels(this.rt,0,0,this.size,this.size,d),this.renderer.setRenderTarget(a),this.renderer.setClearColor(o,l),this.renderer.shadowMap.enabled=c,this.scene.remove(t);const h=document.createElement("canvas");h.width=h.height=this.size;const u=h.getContext("2d"),f=u.createImageData(this.size,this.size);for(let x=0;x<this.size;x++)f.data.set(d.subarray((this.size-1-x)*this.size*4,(this.size-x)*this.size*4),x*this.size*4);u.putImageData(f,0,0);const g=h.toDataURL("image/png");return this.cache.set(e,g),g}building(t,e,n,s){const r=Nl(t,e,n,s),[a,o]=oe[t].size,l=Math.max(a,o);return this.shoot(r.group,`b|${t}|${e}|${n}|${s.primary}${s.accent}${s.banner.bg}${s.banner.fg}${s.banner.emblem}`,l*1.55+.8,Math.max(.6,r.height*.6))}bot(t){const e=Ec(t,1);e.group.rotation.y=.5;const n=e.group.getObjectByName("hoverGlow");return n&&(n.visible=!1),this.shoot(e.group,`bot|${t}`,1.75,.55)}}const Wi={credits:'<span class="ic cr">C</span>',cells:'<span class="ic ce">⚡</span>',dm:'<span class="ic dm">◆</span>'},ua=i=>`<span class="els">${i.map(t=>`<span class="el" style="background:${Wt[t].color}" title="${Wt[t].name}">${Wt[t].glyph}</span>`).join("")}</span>`,fa=i=>{const t=Qt[gt[i].rarity];return`<span class="rar" style="color:${t.color}">${t.name}</span>`},Es=i=>i.t==="bay"?`${Wt[i.el].name} Bay`:oe[i.t].name;class O_{constructor(t){this.ui=t,this.fuseA=null,this.fuseB=null,this.dexR="all",this.picking=null}get s(){return this.ui.app.s}get app(){return this.ui.app}img(t,e=!0,n=0){return`<img src="${this.app.studio.bot(t)}" alt="" style="${n?`width:${n}px;height:${n}px;`:""}${e?"":"filter:brightness(0) opacity(0.55)"}">`}botPanel(t){const e=this.s,n=gt[t.sp],s=Vl(t),r=qa(t.lvl);let a=0;for(let l=t.fed;l<4;l++)a+=r;const o=t.post?`Helping at the ${Es(Me(e,t.post))}`:t.stored?"In storage (not earning)":t.bay?`Lives in the ${Es(Me(e,t.bay))}`:"";return`<button class="ibtn x" data-a="deselect">✕</button><div class="row" style="align-items:flex-start;gap:12px"><div class="pic" style="width:96px;height:96px;border-radius:16px;background:radial-gradient(circle at 50% 40%, ${Wt[n.el[0]].color}66, transparent 70%);flex:none;display:grid;place-items:center;overflow:hidden">${this.img(t.sp,!0,96)}</div>
      <div class="grow"><h2>${Ut(t.nick||n.name)} <button class="btn small" data-a="rename" data-bot="${t.id}" style="min-height:26px;padding:2px 8px">✎</button></h2><div class="sub">${t.nick?Ut(n.name)+" · ":""}${fa(t.sp)} · ${ua(n.el)}</div>
      <div class="sub">Level ${t.lvl}<span class="pips">${[0,1,2,3].map(l=>`<i class="${l<t.fed?"on":""}"></i>`).join("")}</span></div><div class="sub">${Ut(o)}</div></div></div>
      <p class="desc">${Ut(n.desc)}</p><table class="stats"><tr><td>Earns</td><td>${t.post||t.stored?"<s>":""}${Wi.credits} ${yt(li(t))}/min${t.post||t.stored?"</s>":""}</td></tr><tr><td>Hull · attack</td><td>${yt(s.hp)} · ${yt(s.atk)}</td></tr><tr><td>Moves from</td><td>${n.el.map(l=>Wt[l].name).join(", ")}</td></tr></table>
      ${t.lvl<Xa?`<div class="row"><button class="btn green small grow" data-a="feed" data-bot="${t.id}"><span class="cost" data-cost="cells:${r}">${Wi.cells}${yt(r)}</span> Feed</button><button class="btn green small grow" data-a="feedLvl" data-bot="${t.id}"><span class="cost" data-cost="cells:${a}">${Wi.cells}${yt(a)}</span> To level ${t.lvl+1}</button></div>`:'<p class="sub">Maximum level.</p>'}
      <div class="row" style="margin-top:8px">${t.stored?`<button class="btn small" data-a="unstore" data-bot="${t.id}">⬆ Activate</button>`:`<button class="btn small" data-a="pickBay" data-bot="${t.id}">⇄ Move</button>${t.post?`<button class="btn small" data-a="unpost" data-bot="${t.id}">↩ Back to bay</button>`:`<button class="btn small" data-a="pickPost" data-bot="${t.id}">🛠 Help a building</button>`}<button class="btn small" data-a="store" data-bot="${t.id}">❄ Store</button>`}
      <button class="btn small" data-a="release" data-bot="${t.id}">Release (${Wi.credits}${yt(Th(t))})</button></div>`}helpersHTML(t){if(!oi[t.t]||t.lvl<1)return"";const e=this.s,n=Aa(e,t.id),s=Us(t.lvl),r=Mr(e,t);return`<div class="sub" style="margin-top:10px">Helpers · +${Math.round(r*100)}% ${Xc[t.t]} · best: ${oi[t.t].map(a=>Wt[a].glyph).join(" ")} bots</div><div class="row">${n.map(a=>`<button class="btn small" data-a="selBot" data-bot="${a.id}" style="padding:2px 8px 2px 2px"><img src="${this.app.studio.bot(a.sp)}" style="width:30px;height:30px">L${a.lvl}</button>`).join("")}${n.length<s?`<button class="btn small" data-a="pickHelper" data-id="${t.id}">＋ Add helper (${n.length}/${s})</button>`:""}</div>`}fusionHTML(t){const e=this.s,n=Fe(e,t.id,"fuse");let s="";if(n){const r=qi((n.end-Date.now())/1e3);s+=`<div class="row" style="justify-content:center;gap:16px;margin:6px 0">${(n.parents||[]).map(a=>{const o=e.bots.find(l=>l.id===a);return o?`<div style="width:70px;text-align:center">${this.img(o.sp,!0,64)}<div class="sub" style="margin:0">L${o.lvl}</div></div>`:""}).join('<b style="font-size:24px">+</b>')}</div>
      <p class="desc" style="text-align:center">Fusing… the new core's rarity is revealed when it is done.</p><div class="bar"><i data-bar="${n.id}"></i></div><div class="row" style="margin-top:8px"><b class="grow" data-left="${n.id}"></b><button class="btn gold small" data-a="finish" data-job="${n.id}" data-dm="${n.id}">${r?`${Wi.dm}${r} Finish now`:"Finish (free)"}</button></div>`}else{const r=e.bots.find(l=>l.id===this.fuseA),a=e.bots.find(l=>l.id===this.fuseB),o=(l,c)=>`<button class="card" data-a="pickFuse" data-slot="${c}" style="width:46%;align-items:center;min-height:120px">${l?`${this.img(l.sp,!0,72)}<b>${Ut(l.nick||gt[l.sp].name)}</b><span class="sub" style="margin:0">L${l.lvl} ${ua(gt[l.sp].el)}</span>`:`<span style="font-size:34px;opacity:.6">＋</span><span class="sub" style="margin:0">Pick a bot<br>(level ${Pi}+)</span>`}</button>`;if(s+=`<p class="desc">Fuse two bots of level ${Pi} or more. Both parents stay with you; the child's elements come from both.</p><div class="row" style="justify-content:space-between">${o(r,"A")}${o(a,"B")}</div>`,r&&a&&r!==a){const l=wh(r,a),c=Eh(e,t,r.id,a.id);s+=`<div class="sub" style="margin-top:10px">Possible results</div><div class="bots" style="grid-template-columns:repeat(auto-fill,minmax(92px,1fr))">${l.map(d=>{const h=!!e.dex[d.sp];return`<div class="rec"><div style="width:56px;height:56px">${this.img(d.sp,h,56)}</div><b>${h?Ut(gt[d.sp].name):"???"}</b>${fa(d.sp)}<span class="out" style="font-size:13px">${(d.p*100).toFixed(d.p<.1?1:0)}%</span></div>`}).join("")}</div>
          <div class="row" style="margin-top:8px"><span class="grow"><span class="cost ${e.res.credits<(c.cost||0)?"short":""}" data-cost="credits:${c.cost||Ho(r,a)}">${Wi.credits}${yt(c.cost||Ho(r,a))}</span> · ${tn(Go(e,t,l[l.length-1].sp))}–${tn(Go(e,t,l[0].sp))}</span><button class="btn gold" data-a="fuse" data-id="${t.id}" ${c.ok?"":"disabled"}>🧬 Fuse</button></div>${c.ok?"":`<p class="why">${Ut(c.why||"")}</p>`}`}}return s+this.helpersHTML(t)}assemblyHTML(t){const e=this.s,n=e.cores.map(s=>{const r=e.jobs.find(l=>l.kind==="boot"&&l.core===s.id),a=Qt[gt[s.sp].rarity],o=`<div class="pic" style="width:48px;height:48px;border-radius:50%;background:radial-gradient(circle at 40% 35%, #fff, ${a.color} 45%, ${a.color}55 70%, transparent 72%)"></div>`;if(s.state==="ready")return`<div class="botc">${o}<div><b style="color:${a.color}">${a.name} core</b><div class="meta">Booted: ready to activate</div></div><button class="btn gold small" data-a="activate" data-core="${s.id}">Activate</button></div>`;if(r){const l=qi((r.end-Date.now())/1e3);return`<div class="botc">${o}<div><b style="color:${a.color}">${a.name} core</b><div class="meta">Booting · <span data-left="${r.id}">${tn((r.end-Date.now())/1e3)}</span></div><div class="bar" style="margin-top:4px"><i data-bar="${r.id}"></i></div></div><button class="btn gold small" data-a="finish" data-job="${r.id}" data-dm="${r.id}">${l?`${Wi.dm}${l}`:"Free"}</button></div>`}return`<div class="botc">${o}<div><b style="color:${a.color}">${a.name} core</b><div class="meta">Queued: waiting for a free pod</div></div><span></span></div>`}).join("");return`<p class="desc">${fr(t.lvl)} pod${fr(t.lvl)>1?"s":""} boot cores side by side. Cores arrive from the shop (Advanced bots), the Fusion Lab and events.</p><div class="bots">${n||'<p class="desc">No cores right now.</p>'}</div>`+this.helpersHTML(t)}picker(t,e){this.ui.modal(`<h1 style="font-size:20px">${t}</h1><div class="bots" style="max-height:56vh;overflow:auto;text-align:left">${e||'<p class="desc">Nobody fits yet.</p>'}</div><button class="btn" data-a="closeModal" style="margin-top:10px">Cancel</button>`)}pickRow(t,e,n="",s="Pick"){const r=gt[t.sp];return`<div class="botc"><div class="pic">${this.img(t.sp)}</div><div><b>${Ut(t.nick||r.name)}</b> ${ua(r.el)}<div class="meta">${fa(t.sp)} · L${t.lvl}${t.post?" · helping":""}${t.stored?" · stored":""}</div></div><button class="btn small gold" data-a="${e}" data-bot="${t.id}" ${n}>${s}</button></div>`}dexHTML(){const t=this.s,e=Gl(t),n=on.map(r=>[r,Xn.filter(a=>gt[a].rarity===r).length,Xn.filter(a=>gt[a].rarity===r&&t.dex[a]).length]),s=Xn.filter(r=>this.dexR==="all"||gt[r].rarity===this.dexR);return`<div class="head"><h1>Botdex</h1><span class="sub">${e} / ${Xn.length} discovered</span><button class="ibtn" data-a="close">✕</button></div>
      <div class="tabs"><button class="tab ${this.dexR==="all"?"on":""}" data-a="dexR" data-r="all">All</button>${n.map(([r,a,o])=>`<button class="tab ${this.dexR===r?"on":""}" data-a="dexR" data-r="${r}" style="color:${Qt[r].color}">${Qt[r].name} ${o}/${a}</button>`).join("")}</div>
      <div class="body"><p class="sub" style="text-align:center">Every new species pays Dark Matter (${Sh.map((r,a)=>`<span style="color:${Qt[on[a]].color}">${r}</span>`).join(" · ")} by rarity). Elements are shown so you can plan fusions.</p>
      <div class="grid" style="grid-template-columns:repeat(auto-fill,minmax(132px,1fr))">${s.map(r=>{const a=gt[r],o=!!t.dex[r],l=o?`${t.bots.filter(c=>c.sp===r).length} owned`:a.price?`Shop · level ${a.unlock}`:a.el.length>1?"Fusion":"";return`<div class="card" style="align-items:center;text-align:center;gap:3px;${o?"":"opacity:.8"}"><div class="thumb" style="height:96px;width:100%">${this.img(r,o)}</div><b>${o?Ut(a.name):"???"}</b>${fa(r)}${ua(a.el)}<span class="sub" style="margin:0">${l}</span></div>`}).join("")}</div></div>`}act(t,e){const n=this.s,s=this.app,r=this.ui,a=e.dataset.bot?n.bots.find(o=>o.id===e.dataset.bot):void 0;switch(t){case"selBot":return a&&(r.closeModal(),r.selectBot(a.id),s.audio.play("tap")),!0;case"feedLvl":if(a){let o=!1,l=0;for(;a.fed>0||!o;){const c=Xl(n,a);if(!c.ok){l||r.deny(c.why);break}if(l++,c.lvlUp){o=!0;break}}if(l){s.audio.play(o?"done":"feed");const c=e.getBoundingClientRect();r.popText(c.left+c.width/2,c.top,o?`Level ${a.lvl}!`:`+${l} feeds`,o?"#ffd36a":"#9dff5a"),s.changed(),r.renderPanel()}}return!0;case"rename":if(a){const o=prompt("Name this bot",a.nick||gt[a.sp].name);if(o!==null){const l=o.trim().slice(0,18);l&&l!==gt[a.sp].name?a.nick=l:delete a.nick,s.changed(),r.renderPanel()}}return!0;case"pickBay":if(a){const o=Zt(n,"bay").filter(l=>l.lvl>0&&l.el&&gt[a.sp].el.includes(l.el)&&l.id!==a.bay);this.ui.modal(`<h1 style="font-size:20px">Move ${Ut(a.nick||gt[a.sp].name)}</h1><div class="bots" style="text-align:left">${o.map(l=>{const c=pi(n,l.id).length,d=Rs(l.lvl);return`<div class="botc"><div class="pic" style="background:${Wt[l.el].color}44">${Wt[l.el].glyph}</div><div><b>${Es(l)}</b><div class="meta">Level ${l.lvl} · ${c}/${d} bots</div></div><button class="btn small gold" data-a="moveTo" data-bot="${a.id}" data-id="${l.id}" ${c<d?"":"disabled"}>Move</button></div>`}).join("")||`<p class="desc">No other ${gt[a.sp].el.map(l=>Wt[l].name).join("/")} Bay yet.</p>`}</div><button class="btn" data-a="closeModal" style="margin-top:10px">Cancel</button>`)}return!0;case"moveTo":return a&&e.dataset.id&&(kh(n,a,e.dataset.id)?(delete a.post,s.audio.play("place"),r.closeModal(),s.changed(),r.renderPanel()):r.deny("That bay is full")),!0;case"pickPost":if(a){const o=n.isl.items.filter(l=>oi[l.t]&&l.lvl>0);this.ui.modal(`<h1 style="font-size:20px">Where should ${Ut(a.nick||gt[a.sp].name)} help?</h1><p class="sub">A helper stops earning credits while it works. Bots with a matching element help 50% more.</p><div class="bots" style="text-align:left">${o.map(l=>{const c=Ah(n,a,l),d=gt[a.sp].el.some(h=>oi[l.t].includes(h));return`<div class="botc"><div class="pic" style="background:rgba(110,231,255,.12)">${{command:"🏛",fab:"⚡",fusion:"🧬",assembly:"🤖"}[l.t]||"🏗"}</div><div><b>${Es(l)}</b><div class="meta">${Xc[l.t]}${d?' · <b style="color:#7cf29a">element match</b>':""} · ${Aa(n,l.id).length}/${Us(l.lvl)}</div></div><button class="btn small gold" data-a="postTo" data-bot="${a.id}" data-id="${l.id}" ${c.ok?"":"disabled"}>Assign</button></div>`}).join("")}</div><button class="btn" data-a="closeModal" style="margin-top:10px">Cancel</button>`)}return!0;case"postTo":if(a&&e.dataset.id){const o=Me(n,e.dataset.id),l=df(n,a,o);l.ok?(s.audio.play("place"),r.closeModal(),s.changed(),r.renderPanel(),r.toast(`${a.nick||gt[a.sp].name} is now helping at the ${Es(o)}`,"good")):r.deny(l.why)}return!0;case"pickHelper":{const o=Me(n,e.dataset.id||"");if(!o)return!0;const l=n.bots.filter(c=>!c.stored&&c.post!==o.id).sort((c,d)=>Number(gt[d.sp].el.some(h=>oi[o.t].includes(h)))-Number(gt[c.sp].el.some(h=>oi[o.t].includes(h)))||d.lvl-c.lvl);return this.picker(`Helper for the ${Es(o)}`,l.map(c=>this.pickRow(c,"postTo",`data-id="${o.id}"`,gt[c.sp].el.some(d=>oi[o.t].includes(d))?"Assign ★":"Assign")).join("")),!0}case"unpost":return a&&(hf(a),s.changed(),r.renderPanel(),s.audio.play("tap")),!0;case"store":return a&&(uf(n,a),s.changed(),r.renderPanel(),s.audio.play("tap"),r.toast("Stored: it stops earning until you activate it","")),!0;case"unstore":if(a){const o=ff(n,a);o.ok?(s.audio.play("place"),s.changed(),r.renderPanel()):r.deny(o.why)}return!0;case"release":if(a){if(!e.dataset.sure)return e.dataset.sure="1",e.innerHTML="Tap again to release",!0;const o=pf(n,a);o.ok?(s.audio.play("buy"),r.select(null),s.changed(),r.toast(`Released for ${yt(o.cost||0)} credits`,"gold")):r.deny(o.why)}return!0;case"pickFuse":{const o=e.dataset.slot,l=o==="A"?this.fuseB:this.fuseA,c=n.bots.filter(d=>d.lvl>=Pi&&d.id!==l).sort((d,h)=>on.indexOf(gt[h.sp].rarity)-on.indexOf(gt[d.sp].rarity)||h.lvl-d.lvl);return this.picking={kind:"fuse",ctx:o},this.picker(`Parent ${o}`,c.map(d=>this.pickRow(d,"fusePick",`data-slot="${o}"`)).join("")||`<p class="desc">No bots at level ${Pi} yet: feed your crew Power Cells.</p>`),!0}case"fusePick":return a&&(e.dataset.slot==="A"?this.fuseA=a.id:this.fuseB=a.id,r.closeModal(),r.renderPanel(),s.audio.play("tap")),!0;case"fuse":{const o=Me(n,e.dataset.id||"");if(!o||!this.fuseA||!this.fuseB)return!0;const l=of(n,o,this.fuseA,this.fuseB);return l.ok?(s.audio.play("build"),this.fuseA=this.fuseB=null,s.changed(),r.renderPanel(),r.toast("Fusion started","good")):r.deny(l.why),!0}case"activate":{const o=cf(n,e.dataset.core||"");return o.ok&&o.bot?(s.audio.play("levelup"),s.changed(),r.renderPanel(),r.newBot(o.bot),o.bot.stored&&r.toast("No room in a matching bay: it waits in storage","gold")):r.deny(o.why),!0}case"dexR":return this.dexR=e.dataset.r||"all",r.renderOver(),s.audio.play("tap"),!0}return!1}}const rr={credits:'<span class="ic cr">C</span>',cells:'<span class="ic ce">⚡</span>',dm:'<span class="ic dm">◆</span>'},pa=i=>Object.entries(i).filter(([,t])=>t>0).map(([t,e])=>`<span class="cost">${rr[t]||""}${yt(e)}</span>`).join(" "),gh=(i,t=34)=>`<span style="display:inline-block;width:${t}px;height:${t}px;border-radius:50%;background:radial-gradient(circle at 40% 35%, #fff, ${Qt[i].color} 45%, ${Qt[i].color}55 70%, transparent 72%);vertical-align:middle"></span>`;class B_{constructor(t){this.ui=t,this.tab="calendar"}get s(){return this.ui.app.s}get app(){return this.ui.app}hudHTML(){const t=this.s,e=Uo(t),n=ue(t),s=r=>r?'<i class="rdot"></i>':"";return`<button class="ibtn" data-a="daily" title="Daily rewards">📅${s(e.day||e.missions||e.ach)}</button><button class="ibtn" data-a="spin" title="Free daily core">🎁${s(e.spin)}</button><button class="chip ${n.drops?"hot":""}" data-a="drop" title="Supply drop">📦 <span id="dropT">${n.drops?`Open${n.drops>1?" ×"+n.drops:""}!`:tn((n.drop-Date.now())/1e3)}</span></button>`}overHTML(){const t=this.s,e=ue(t),n=Uo(t),s=[["calendar","Calendar",n.day],["missions","Missions",n.missions],["ach","Achievements",n.ach]];let r="";if(this.tab==="calendar"){const a=yc(t);r=`<div class="row" style="justify-content:center;gap:18px;margin-bottom:10px"><div class="ox" style="font-size:18px">🔥 ${e.streak} day streak</div><div class="sub" style="margin:0">Best ${e.best} · ${e.total} days in all${e.cycle?` · cycle ${e.cycle+1}`:""}</div></div>
        <p class="sub" style="text-align:center">Rewards grow every day. Miss a day and the calendar simply waits for you: it never resets.</p><div class="cal">${Array.from({length:28},(o,l)=>{const c=Vu(t,l),d=l<e.day,h=l===e.day&&a,u=c.core?gh(c.core,30):c.decor?'<span style="font-size:26px">🌟</span>':c.res.dm&&!c.res.credits&&!c.res.cells?'<span style="font-size:22px">◆</span>':"";return`<div class="day ${d?"done":""} ${h?"today":""} ${Gu[l]?"special":""}" ${h?'data-a="claimDay"':""}><b>Day ${l+1}</b>${u}<span class="dr">${pa(c.res)}</span>${c.label?`<span class="lbl">${Ut(c.label)}</span>`:""}${d?'<span class="tick">✓</span>':""}</div>`}).join("")}</div>
        ${a?`<div class="row" style="justify-content:center;margin-top:12px"><button class="btn gold" data-a="claimDay">Claim day ${e.day+1}</button>${this.app.platform.adsAvailable?'<button class="btn" data-a="claimDayAd">▶ Watch an ad: double it</button>':""}</div>`:`<p class="sub" style="text-align:center;margin-top:12px">Come back tomorrow for day ${e.day+1}.</p>`}`}else this.tab==="missions"?(Ha(t),r=`<p class="sub" style="text-align:center">New missions every day. Finish all three for the bonus chest.</p><div class="bots" style="max-width:520px;margin:0 auto">${e.missions.map((a,o)=>{const l=Math.min(a.n,bc(t,a)),c=l>=a.n,d=e.mClaimed[o];return`<div class="botc" style="grid-template-columns:1fr auto"><div><b>${Ut(a.text)}</b><div class="bar" style="margin:6px 0 4px"><i style="width:${l/a.n*100}%"></i></div><div class="meta">${yt(l)} / ${yt(a.n)} · reward ${pa(a.reward)}</div></div>${d?'<span class="sub">✓ Done</span>':`<button class="btn ${c?"gold":""} small" data-a="claimMission" data-i="${o}" ${c?"":"disabled"}>Claim</button>`}</div>`}).join("")}
        <div class="botc chest ${ur(t)?"ready":""}" style="grid-template-columns:54px 1fr auto"><div style="font-size:36px;text-align:center">🧰</div><div><b>Bonus chest</b><div class="meta">Dark Matter, Power Cells and a chance of an Advanced or Elite core</div></div>${e.bonus?'<span class="sub">✓ Opened</span>':`<button class="btn ${ur(t)?"gold":""} small" data-a="claimBonus" ${ur(t)?"":"disabled"}>Open</button>`}</div></div>`):r=`<div class="bots" style="max-width:620px;margin:0 auto">${Sc.map(a=>{const o=wc(t,a),l=a.stat(t),c=o>=a.tiers.length,d=a.tiers[Math.min(o,a.tiers.length-1)];return`<div class="botc" style="grid-template-columns:44px 1fr auto"><div style="font:700 16px Oxanium;text-align:center;color:${["#9aa7b8","#cd7f32","#c0c8d4","#ffd36a","#7af7ff"][o]}">${["☆","★","★★","★★★","✦"][o]}</div><div><b>${Ut(a.name)}</b> <span class="sub">tier ${Math.min(o+1,a.tiers.length)}/${a.tiers.length}</span><div class="bar" style="margin:5px 0 3px"><i style="width:${c?100:Math.min(100,l/d*100)}%"></i></div><div class="meta">${yt(l)} / ${yt(d)} ${Ut(a.unit)}</div></div>
          ${c?'<span class="sub">Complete</span>':`<button class="btn ${Va(t,a)?"gold":""} small" data-a="claimAch" data-id="${a.id}" ${Va(t,a)?"":"disabled"}>${rr.dm}${Fl[o]}</button>`}</div>`}).join("")}</div>`;return`<div class="head"><h1>Daily</h1><button class="ibtn" data-a="close">✕</button></div><div class="tabs">${s.map(([a,o,l])=>`<button class="tab ${this.tab===a?"on":""}" data-a="dtab" data-t="${a}">${o}${l?' <i class="rdot" style="position:static;display:inline-block"></i>':""}</button>`).join("")}</div><div class="body">${r}</div>`}giftLine(t){if(!t)return"";const e=gt[t.sp].rarity;return`<div class="gift" style="--rc:${Qt[e].color}">${gh(e,40)}<span><b style="color:${Qt[e].color}">${Qt[e].name} core!</b><br><span class="sub" style="margin:0">${t.core?Zt(this.s,"assembly").some(n=>n.lvl>0)?"Booting in the Assembly Bay":"Waits for your Assembly Bay":"Joined your crew"}</span></span></div>`}dropReveal(t){const e=Object.entries(t.res).map(([n,s],r)=>`<div class="loot" style="animation-delay:${.25+r*.22}s">${rr[n].replace('class="ic','style="width:38px;height:38px;font-size:18px" class="ic')}<b>+${yt(s)}</b></div>`).join("");this.ui.modal(`<div class="ox sub" style="letter-spacing:.2em">SUPPLY DROP</div><div style="font-size:64px;line-height:1;margin:6px 0;animation:zoom .5s">📦</div><div class="lootrow">${e}</div>${t.gift?`<div style="animation:zoom .4s ${.3+Object.keys(t.res).length*.22}s both">${this.giftLine(t.gift)}</div>`:""}<button class="btn gold" data-a="closeModal" style="min-width:160px;margin-top:12px">Nice!</button>`,!0)}spinReveal(t){const e=Xn.filter(h=>["standard","advanced","elite"].includes(gt[h].rarity)),n=34,s=29,r=[];for(let h=0;h<n;h++){const u=h===s?t.sp:e[Math.floor(Math.random()*e.length)],f=gt[u].rarity;r.push(`<div class="rc" style="--rc:${Qt[f].color}"><img src="${this.app.studio.bot(u)}"></div>`)}this.ui.modal(`<div class="ox sub" style="letter-spacing:.2em">DAILY CORE</div><div class="reel"><div class="strip" id="strip">${r.join("")}</div><div class="needle"></div></div><div id="spinRes" style="min-height:96px"></div><button class="btn gold hidden" id="spinOk" data-a="closeModal" style="min-width:160px">Collect</button>`);const a=document.getElementById("strip"),o=96;requestAnimationFrame(()=>{a.style.transition="transform 4.2s cubic-bezier(.12,.62,.16,1)";const h=a.parentElement.clientWidth;a.style.transform=`translateX(${-2784+h/2-o/2}px)`});let l=0;const c=()=>{const h=new DOMMatrix(getComputedStyle(a).transform),u=Math.floor(-h.m41/o);u!==l&&(l=u,this.app.audio.play("tap"))},d=window.setInterval(c,30);window.setTimeout(()=>{clearInterval(d);const h=gt[t.sp],u=Qt[h.rarity];this.app.audio.play(on.indexOf(h.rarity)>=1?"levelup":"claim"),document.getElementById("spinRes").innerHTML=`<h1 style="color:${u.color};margin:10px 0 2px">${Ut(h.name)}</h1><div class="rar" style="color:${u.color}">${u.name}${this.s.dex[t.sp]&&Date.now()-this.s.dex[t.sp]<6e3?" · NEW SPECIES":""}</div><p class="sub">${t.core?Zt(this.s,"assembly").some(f=>f.lvl>0)?"Its core is booting in the Assembly Bay.":"Its core waits for your Assembly Bay (Commander level 4).":"It joined your crew."}</p>`,document.getElementById("spinOk").classList.remove("hidden")},4300)}offlineReport(t,e){const n=Uo(this.s),s=[];return e.credits>=1&&s.push(`${rr.credits} <b>${yt(e.credits)}</b> credits waiting in ${e.bays} bay${e.bays>1?"s":""}`),e.ready&&s.push(`${rr.cells} <b>${e.ready}</b> fabricator recipe${e.ready>1?"s":""} ready to harvest`),e.built&&s.push(`🏗 <b>${e.built}</b> construction${e.built>1?"s":""} finished`),e.cores&&s.push(`🤖 <b>${e.cores}</b> core${e.cores>1?"s":""} booted and ready`),n.drop&&s.push("📦 A supply drop has landed"),n.day&&s.push("📅 Today's calendar reward is waiting"),n.spin&&s.push("🎁 Your free daily core is ready"),s.length?(this.ui.modal(`<div class="ox sub" style="letter-spacing:.2em">WELCOME BACK</div><h1>While you were away</h1><p class="sub">${tn(t/1e3)} in orbit. Your crew kept working.</p><div class="report">${s.map(r=>`<div>${r}</div>`).join("")}</div>${e.credits>=1||e.ready?'<button class="btn gold" data-a="collectAll" style="min-width:180px">Collect everything</button>':`<button class="btn gold" data-a="closeModal">Let's go</button>`}`,!0),!0):!1}act(t,e){const n=this.s,s=this.app,r=this.ui;switch(t){case"daily":return Ha(n),r.openOver("daily"),s.audio.play("tap"),!0;case"dtab":return this.tab=e.dataset.t,r.renderOver(),s.audio.play("tap"),!0;case"claimDay":case"claimDayAd":{const a=o=>{const l={...n.res},c=y_(n);if(!c)return;o&&Qn(n,c.res),s.audio.play("claim"),s.changed(),r.renderOver(),r.renderHud();const d={};for(const h of["credits","cells","dm"]){const u=n.res[h]-l[h];u>0&&(d[h]=u)}r.modal(`<div class="ox sub" style="letter-spacing:.2em">DAY ${c.day+1}</div><h1>Daily reward</h1><div class="rewards">${pa(d)}</div>${this.giftLine(c.gift)}${c.decor?'<div class="gift"><span style="font-size:36px">🌟</span><span><b>Starlight Arch</b><br><span class="sub" style="margin:0">An exclusive decoration: place it from Shop → Decor</span></span></div>':""}<p class="sub">🔥 ${ue(n).streak} day streak</p><button class="btn gold" data-a="closeModal" style="min-width:160px">Thanks!</button>`,!0)};return t==="claimDayAd"?s.platform.rewarded(()=>s.audio.setMuted(!0)).then(o=>{s.audio.setMuted(s.platform.muted()),a(o)}):a(!1),!0}case"claimMission":{const a=S_(n,+(e.dataset.i||0));if(a){s.audio.play("claim");const o=e.getBoundingClientRect();for(const l of Object.keys(a.reward))r.flyTo(l,o.left+o.width/2,o.top);s.changed(),r.renderOver()}return!0}case"claimBonus":{const a=w_(n);return a&&(s.audio.play("levelup"),s.changed(),r.renderOver(),r.modal(`<div class="ox sub" style="letter-spacing:.2em">ALL MISSIONS DONE</div><div style="font-size:60px;line-height:1">🧰</div><h1>Bonus chest</h1><div class="rewards">${pa(a.res)}</div>${this.giftLine(a.gift)}<button class="btn gold" data-a="closeModal" style="min-width:160px">Awesome!</button>`,!0)),!0}case"claimAch":{const a=A_(n,e.dataset.id||"");return a&&(s.audio.play("claim"),r.toast(`${a.a.name} tier ${a.tier+1}: +${a.dm} Dark Matter`,"gold"),s.changed(),r.renderOver()),!0}case"spin":{if(!Mc(n))return s.platform.adsAvailable&&ue(n).adSpin!==In()?r.modal(`<h1>Daily core</h1><p class="desc">You have used today's free spin. Watch a short ad for one more?</p><div class="row" style="justify-content:center"><button class="btn" data-a="closeModal">No thanks</button><button class="btn gold" data-a="spinAd">▶ Watch ad</button></div>`):r.toast("Your next free core is ready tomorrow",""),!0;const a=lh(n);return a&&(s.changed(),this.spinReveal(a)),!0}case"spinAd":return r.closeModal(),s.platform.rewarded(()=>s.audio.setMuted(!0)).then(a=>{if(s.audio.setMuted(s.platform.muted()),!a)return;const o=lh(n,!0);o&&(s.changed(),this.spinReveal(o))}),!0;case"drop":{const a=E_(n);return a?(s.audio.play("harvest"),s.changed(),this.dropReveal(a),!0):(r.toast(`The next supply drop lands in ${tn((ue(n).drop-Date.now())/1e3)}`,""),!0)}case"collectAll":{let a=0,o=0;for(const l of Zt(n,"bay"))a+=Yl(n,l);for(const l of Zt(n,"fab"))o+=Kl(n,l);return r.closeModal(),s.audio.play("collect",a),a&&r.toast(`Collected ${yt(a)} credits${o?` and ${yt(o)} Power Cells`:""}`,"gold"),s.changed(),!0}}return!1}}const k_={credits:'<span class="ic cr">C</span>',cells:'<span class="ic ce">⚡</span>',dm:'<span class="ic dm">◆</span>'},vh=i=>Object.entries(i).filter(([,t])=>t>0).map(([t,e])=>`<span class="cost">${k_[t]||""}${yt(e)}</span>`).join(" "),Oo=i=>`<span class="els">${i.map(t=>`<span class="el" style="background:${Wt[t].color}">${Wt[t].glyph}</span>`).join("")}</span>`;class z_{constructor(t){this.ui=t,this.fight=null}get s(){return this.ui.app.s}get app(){return this.ui.app}banner(t,e=48){const n=document.createElement("canvas");n.width=96,n.height=60;const s=n.getContext("2d");return s.fillStyle=t.bg,s.fillRect(0,0,96,60),s.fillStyle=t.fg,s.translate(48,30),_c(s,t.emblem,20),s.fill(),`<img src="${n.toDataURL()}" style="width:${e}px;height:${e*60/96}px;border-radius:5px">`}overHTML(){const t=this.s,e=Bn(t);Xu(t);const n=Qi(e.trophies),s=Ii[n+1];e.rivals.length||ph(t);const r=Is(t),a=fi(r.map(d=>({sp:d.sp,lvl:d.lvl}))),o=Ii[n][1],l=s?s[1]:o+1,c=s?(e.trophies-o)/(l-o)*100:100;return`<div class="head"><h1>Arena</h1><span class="chip">🎟 ${e.tickets}/${ts}${e.tickets<ts?` · +1 in ${tn((e.tAt+Ol-Date.now())/1e3)}`:""}</span><button class="ibtn" data-a="close">✕</button></div><div class="body" style="max-width:820px;margin:0 auto;width:100%">
      <div class="card" style="flex-direction:row;align-items:center;gap:14px"><div style="font:700 40px Oxanium;color:${ir[n]};text-shadow:0 0 18px ${ir[n]}88">🏆</div><div class="grow"><b style="font-size:18px;color:${ir[n]}">${Ii[n][0]}</b> <span class="sub">${yt(e.trophies)} trophies · best ${yt(e.best)} · ${e.wins}W ${e.losses}L</span>
        <div class="bar gold" style="margin:6px 0"><i style="width:${c}%"></i></div><div class="sub" style="margin:0">${s?`${s[1]-e.trophies} to ${s[0]}`:"Top league!"} · season ends in ${tn((L_()-Date.now())/1e3)} · reward: ${vh(qu(t,Qi(e.seasonBest)))}</div></div></div>
      <h3 class="ox" style="margin:14px 0 6px">Your team <span class="sub">power ${yt(a)}</span></h3><div class="row">${[0,1,2].map(d=>{const h=r[d];return`<button class="card" data-a="pickTeam" data-i="${d}" style="width:32%;align-items:center;min-height:120px">${h?`<img src="${this.app.studio.bot(h.sp)}" style="width:70px;height:70px"><b>${Ut(h.nick||gt[h.sp].name)}</b><span class="sub" style="margin:0">L${h.lvl} ${Oo(gt[h.sp].el)}</span>`:'<span style="font-size:30px;opacity:.5">＋</span>'}</button>`}).join("")}</div>
      <h3 class="ox" style="margin:14px 0 6px">Rival colonies <button class="btn small" data-a="rerollRivals" style="margin-left:8px">↻ New rivals</button></h3><div class="bots">${e.rivals.map((d,h)=>`<div class="botc" style="grid-template-columns:56px 1fr auto">${this.banner(d.banner,56)}<div><b>${Ut(d.name)}</b> <span class="rar" style="color:${["#7cf29a","#ffd36a","#ff6b7a"][d.diff]}">${["Easy","Even","Hard"][d.diff]}</span><div class="row" style="gap:2px;margin:3px 0">${d.team.map(u=>`<img src="${this.app.studio.bot(u.sp)}" title="${gt[u.sp].name} L${u.lvl}" style="width:34px;height:34px">`).join("")}<span class="sub" style="margin:0 0 0 6px">power ${yt(d.power)}</span></div><div class="meta">Win: +${Ku[d.diff]} 🏆 and rewards</div></div><button class="btn gold small" data-a="fight" data-i="${h}" ${sr(t).ok?"":"disabled"}>⚔ Fight</button></div>`).join("")}</div>
      ${sr(t).ok?"":`<p class="why" style="text-align:center">${Ut(sr(t).why||"")}</p>`}<p class="sub" style="text-align:center">Rivals are rival colonies matched to your team's power. Element matchups matter: a super-effective move hits 35% harder.</p></div>`}start(t){const e=D_(this.s,t);if(!e){this.ui.deny(sr(this.s).why);return}this.fight={...e,busy:!1,auto:!1,speed:1},this.ui.closeOver(),this.ui.select(null);const n=this.app.world;n.enterArena(),n.arena.setup(e.bt),n.arena.onImpact=(s,r)=>this.impact(s,r),this.app.audio.play("whoosh"),this.app.changed(),this.renderHUD(),document.body.classList.add("fighting")}impact(t,e){const n=this.app.world.project(e),s=this.app.world;if(t.move==="burn"){this.ui.popText(n.x,n.y,`-${yt(t.dmg)} 🔥`,"#ff9a4a");return}if(t.miss){this.ui.popText(n.x,n.y,t.status==="frozen"?"Frozen!":"Miss!","#9fd0ff"),this.app.audio.play("deny");return}this.ui.popText(n.x,n.y-10,`-${yt(t.dmg)}${t.crit?"!":""}`,t.eff>1?"#ffd36a":t.eff<1?"#9aa7b8":"#ffffff"),t.eff!==1&&setTimeout(()=>this.ui.popText(n.x,n.y-34,t.eff>1?"Super effective!":"Resisted",t.eff>1?"#ffd36a":"#9aa7b8"),120),t.status&&t.status!=="shielded"&&setTimeout(()=>this.ui.popText(n.x+30,n.y+10,t.status,"#c49bff"),220),t.heal&&this.ui.popText(n.x-40,n.y-40,`+${yt(t.heal)}`,"#7cf29a"),s.burst(new I(e.x,e.y,e.z),H_(t.move),t.crit?34:20),this.app.audio.play(t.crit?"build":"tap"),this.renderHUD()}renderHUD(){const t=document.getElementById("battle"),e=this.fight;if(!e){t.classList.add("hidden");return}t.classList.remove("hidden");const n=e.bt,s=n.A[n.a],r=n.B[n.b],a=(l,c,d,h)=>{const u=l[c];return`<div class="bside ${d?"r":""}"><div class="bname"><b>${Ut(u.name)}</b> <span class="sub" style="margin:0">L${u.lvl}</span> ${Oo(gt[u.sp].el)}${u.shield?" 🛡":""}${u.burn?" 🔥":""}${u.frozen?" ❄":""}</div><div class="hp"><i style="width:${u.hp/u.max*100}%;background:${u.hp/u.max>.5?"#5fdc7a":u.hp/u.max>.25?"#ffd36a":"#ff6b7a"}"></i><span>${yt(u.hp)} / ${yt(u.max)}</span></div><div class="bench">${l.map((f,g)=>`<i class="${f.hp<=0?"ko":g===c?"on":""}"></i>`).join("")}<span class="sub" style="margin:0 6px">${Ut(h)}</span></div></div>`},o=$u(s.sp).map(l=>{const c=Ui[l],d=Ac(c.el,gt[r.sp].el),h=c.el==="none"?"#9aa7b8":Wt[c.el].color;return`<button class="mv" data-a="move" data-m="${l}" ${e.busy||n.over?"disabled":""} style="--mc:${h}" title="${Ut(c.desc)}"><b>${Ut(c.name)}</b><span>${c.el==="none"?"Neutral":Wt[c.el].name}${d>1?' · <em class="se">super effective</em>':d<1?' · <em class="re">resisted</em>':""}</span></button>`}).join("");t.innerHTML=`<div class="btop">${a(n.A,n.a,!1,this.s.name)}<div class="vs">VS</div>${a(n.B,n.b,!0,e.rival.name)}</div><div class="bbot"><div class="moves">${o}</div><div class="bopts"><button class="btn small ${e.auto?"gold":""}" data-a="autoBattle">⚡ Auto</button><button class="btn small" data-a="battleSpeed">${e.speed}×</button><button class="btn small" data-a="forfeit">Forfeit</button></div></div>`}async turn(t){const e=this.fight;if(!e||e.busy||e.bt.over)return;e.busy=!0,this.renderHUD();const n=e.bt,s=P_(n,t,Fo(n,"B"));if(await this.app.world.arena.play(s,n,e.speed),e.busy=!1,n.over){this.end(n.over==="A");return}this.renderHUD(),e.auto&&setTimeout(()=>this.turn(Fo(n,"A")),250/e.speed)}end(t){const e=this.fight,n=I_(this.s,t,e.rival.diff);this.app.audio.play(t?"levelup":"deny"),this.app.changed(),setTimeout(()=>{this.ui.modal(`<div class="ox sub" style="letter-spacing:.2em">${t?"VICTORY":"DEFEAT"}</div><div class="big" style="color:${t?"#ffd36a":"#ff6b7a"}">${t?"🏆":"💥"}</div><h1>${t?`You beat ${Ut(e.rival.name)}!`:`${Ut(e.rival.name)} won this time`}</h1>
      <div class="rewards"><span class="cost" style="color:${n.dt>0?"#7cf29a":"#ff6b7a"}">${n.dt>0?"+":""}${n.dt} 🏆</span>${vh(n.reward)}</div>${n.promoted>=0?`<p class="desc" style="color:${ir[n.promoted]};font:700 18px Oxanium">Promoted to ${Ii[n.promoted][0]}!</p>`:""}${t?"":'<p class="sub">Tip: feed your team, fuse rarer bots, and pick moves that are super effective against your rival.</p>'}
      <div class="row" style="justify-content:center"><button class="btn" data-a="leaveArena">Back to the colony</button><button class="btn gold" data-a="arenaAgain">Arena</button></div>`,t)},500/e.speed)}leave(){this.fight=null,this.renderHUD(),document.body.classList.remove("fighting"),this.app.world.exitArena(),this.ui.closeModal(),this.app.changed()}act(t,e){const n=this.s,s=this.app,r=this.ui;switch(t){case"arena":return n.isl.items.some(a=>a.t==="arena"&&a.lvl>0)?(Yu(n),r.openOver("arena"),s.audio.play("tap"),!0):(r.openOver("shop","buildings"),r.toast("Build the Arena first (Commander level 6)","gold"),!0);case"fight":return this.start(+(e.dataset.i||0)),!0;case"rerollRivals":return ph(n),r.renderOver(),s.audio.play("tap"),!0;case"pickTeam":{const a=+(e.dataset.i||0);Bn(n);const o=Is(n).map(c=>c.id),l=n.bots.filter(c=>!c.stored).sort((c,d)=>fi([{sp:d.sp,lvl:d.lvl}])-fi([{sp:c.sp,lvl:c.lvl}]));return r.modal(`<h1 style="font-size:20px">Team slot ${a+1}</h1><div class="bots" style="max-height:56vh;overflow:auto;text-align:left">${l.map(c=>`<div class="botc"><div class="pic"><img src="${s.studio.bot(c.sp)}"></div><div><b>${Ut(c.nick||gt[c.sp].name)}</b> ${Oo(gt[c.sp].el)}<div class="meta"><span class="rar" style="color:${Qt[gt[c.sp].rarity].color}">${Qt[gt[c.sp].rarity].name}</span> · L${c.lvl} · power ${yt(fi([{sp:c.sp,lvl:c.lvl}]))}</div></div><button class="btn small gold" data-a="setTeam" data-i="${a}" data-bot="${c.id}" ${o[a]===c.id?"disabled":""}>${o.includes(c.id)?"Swap":"Pick"}</button></div>`).join("")}</div><button class="btn" data-a="closeModal" style="margin-top:10px">Cancel</button>`),!0}case"setTeam":{const a=Bn(n),o=Is(n).map(h=>h.id),l=e.dataset.bot,c=+(e.dataset.i||0),d=o.indexOf(l);return d>=0&&(o[d]=o[c]),o[c]=l,a.team=o.filter(Boolean),a.rivals=[],r.closeModal(),r.renderOver(),s.audio.play("tap"),!0}case"move":return this.turn(e.dataset.m||"strike"),!0;case"autoBattle":return this.fight&&(this.fight.auto=!this.fight.auto,this.renderHUD(),this.fight.auto&&!this.fight.busy&&this.turn(Fo(this.fight.bt,"A"))),!0;case"battleSpeed":return this.fight&&(this.fight.speed=this.fight.speed===1?2:this.fight.speed===2?3:1,this.renderHUD()),!0;case"forfeit":return this.fight&&!this.fight.busy&&(this.fight.bt.over="B",this.end(!1)),!0;case"leaveArena":return this.leave(),!0;case"arenaAgain":return this.leave(),setTimeout(()=>this.act("arena",e),200),!0}return!1}}const H_=i=>{const t=Ui[i];return!t||t.el==="none"?"#ffffff":Wt[t.el].glow},me={credits:'<span class="ic cr">C</span>',cells:'<span class="ic ce">⚡</span>',dm:'<span class="ic dm">◆</span>'},xh=(i,t)=>Object.entries(i).filter(([,e])=>e>0).map(([e,n])=>`<span class="cost ">${me[e]||""}${yt(n)}</span>`).join(" "),ma=i=>`<span class="els">${i.map(t=>`<span class="el" style="background:${Wt[t].color}" title="${Wt[t].name}">${Wt[t].glyph}</span>`).join("")}</span>`,G_=o_,_h=[["#e9eef5","#22c7e8"],["#f4efe6","#ff7a3c"],["#dfe7d8","#4fcf5a"],["#2e3644","#ffd23a"],["#f2e8f7","#b06dff"],["#e6f1ff","#2f6bff"],["#3b2f2f","#ff4f6a"],["#fff6dc","#c9902a"]],V_=["#1b6fd8","#d83a3a","#1f9c5a","#7a3fd6","#e08a1a","#14202e","#e6e6ea","#0fb3c9"],$_=["star","planet","bolt","gear","rocket","circle"];class W_{constructor(t){this.app=t,this.sel=null,this.selBot=null,this.tab="bays",this.over="",this.bubbles=new Map,this.lastRes={credits:0,cells:0,dm:0},this.panelKey="",this.tick=0,this.dailyKey="",this.objKey="",this.crew=new O_(this),this.daily=new B_(this),this.arena=new z_(this),document.addEventListener("click",e=>{const n=e.target.closest("[data-a]");n&&(e.stopPropagation(),this.act(n.dataset.a,n))}),document.addEventListener("input",e=>{const n=e.target;n.dataset.set&&this.app.setSetting(n.dataset.set,n.type==="range"?+n.value:n.value),n.id==="cname"&&(this.s.name=n.value.slice(0,24)||"New Haven",this.renderHud())}),this.renderHud(),this.renderNav(),this.renderObj()}get s(){return this.app.s}get world(){return this.app.world}renderHud(){const t=this.s,e=t.xp/tr(t)*100;ye("#hud").innerHTML=`<div class="lvl" title="Commander level"><div class="badge" style="--p:${e}%"><b>${t.lvl}</b></div><div class="nm"><b>${Ut(t.name)}</b><i>${yt(t.xp)} / ${yt(tr(t))} XP</i></div></div>
      <div class="res" id="r-credits">${me.credits}<span class="v">${yt(t.res.credits)}</span></div><div class="res" id="r-cells">${me.cells}<span class="v">${yt(t.res.cells)}</span></div><div class="res" id="r-dm">${me.dm}<span class="v">${yt(t.res.dm)}</span></div>
      <div class="sp"></div><span id="dailyHud" class="row" style="gap:6px;flex-wrap:nowrap">${this.daily.hudHTML()}</span><button class="ibtn" data-a="settings" title="Settings">⚙</button>`}updHud(){const t=this.s;for(const n of["credits","cells","dm"]){const s=Math.floor(t.res[n]);if(s!==Math.floor(this.lastRes[n])){const r=ye(`#r-${n}`);r&&(r.querySelector(".v").textContent=yt(s),s>this.lastRes[n]&&(r.classList.remove("bump"),r.offsetWidth,r.classList.add("bump"))),this.lastRes[n]=s}}const e=ye(".lvl .badge");if(e){e.style.setProperty("--p",t.xp/tr(t)*100+"%"),e.querySelector("b").textContent=String(t.lvl);const n=ye(".lvl .nm i");n&&(n.textContent=`${yt(t.xp)} / ${yt(tr(t))} XP`)}}renderNav(){ye("#nav").innerHTML='<button data-a="shop" id="n-shop"><span class="g">🛒</span>Shop</button><button data-a="bots"><span class="g">🤖</span>Crew</button><button data-a="dex"><span class="g">📖</span>Botdex</button><button data-a="arena"><span class="g">⚔</span>Arena</button><button data-a="custom"><span class="g">🎨</span>Style</button><button data-a="zoomout"><span class="g">🛰</span>Overview</button>'}renderObj(){const t=this.s,e=lr(t),n=ye("#obj");if(!e){n.classList.add("hidden");return}n.classList.remove("hidden");const s=Ta(t,e);n.classList.toggle("done",s),n.innerHTML=`<div class="t">Mission ${t.obj.i+1} of ${wa.length}</div><p>${Ut(e.text)}</p><div class="rw">Reward: ${xh(e.reward)}</div>${s?'<button class="btn gold claim" data-a="claim">✓ Claim reward</button>':""}`}frame(){if(this.tick++,this.updHud(),this.placeBubbles(),this.tick%20===0){const t=this.daily.hudHTML();if(t!==this.dailyKey){this.dailyKey=t;const e=ye("#dailyHud");e&&(e.innerHTML=t)}}this.tick%15===0&&(this.refreshPanel(),this.renderObjIfChanged(),(this.over==="shop"||this.over==="bots")&&this.refreshOverCosts())}renderObjIfChanged(){const t=lr(this.s),e=(t?t.id:"-")+(t&&Ta(this.s,t)?1:0);e!==this.objKey&&(this.objKey=e,this.renderObj())}placeBubbles(){const t=this.s,e=this.world,n=new Set,s=ye("#bubbles"),r=(a,o,l,c,d,h)=>{if(!o)return;n.add(a);let u=this.bubbles.get(a);u||(u=document.createElement("div"),u.className="bub",d&&(u.dataset.a=d,h&&(u.dataset.id=h)),s.appendChild(u),this.bubbles.set(a,u)),u.dataset.h!==l+c&&(u.innerHTML=l,u.className="bub "+c,u.dataset.h=l+c);const f=e.project(o);u.style.left=f.x+"px",u.style.top=f.y+"px",u.style.display=f.vis&&!e.ghost&&e.mode==="island"?"":"none"};for(const a of t.isl.items){const o=e.topOf(a.id),l=Fe(t,a.id,"build");if(l){const c=(l.end-Date.now())/1e3,d=Ci(1-(l.end-Date.now())/(l.end-l.start));r("t"+a.id,o,`<span>${c>0?tn(c):"Done!"}</span><div class="bar"><i style="width:${d*100}%"></i></div>`,"timer","select",a.id);continue}if(a.t==="bay"){const c=Math.floor(t.bay[a.id]||0);c>=1&&r("c"+a.id,o,`${me.credits}${yt(c)}`,c>=Ri(a)*.98?"full":"","collect",a.id)}if(a.t==="fab"){const c=t.ready[a.id],d=Fe(t,a.id,"craft");if(c)r("r"+a.id,o,`${me.cells}+${yt(c.cells)}`,"ready","harvest",a.id);else if(d){const h=Ci(1-(d.end-Date.now())/(d.end-d.start));r("t"+a.id,o,`<span>${tn((d.end-Date.now())/1e3)}</span><div class="bar cell"><i style="width:${h*100}%"></i></div>`,"timer","select",a.id)}else a.lvl>0&&r("i"+a.id,o,`${me.cells}<span>Idle</span>`,"","select",a.id)}if(a.t==="assembly"&&a.lvl>0){const c=t.cores.filter(d=>d.state==="ready").length;c&&r("a"+a.id,o,`🤖 <span>${c} ready!</span>`,"ready","select",a.id)}if(a.t==="fusion"&&a.lvl>0){const c=Fe(t,a.id,"fuse");if(c){const d=Ci(1-(c.end-Date.now())/(c.end-c.start));r("t"+a.id,o,`<span>🧬 ${tn((c.end-Date.now())/1e3)}</span><div class="bar"><i style="width:${d*100}%"></i></div>`,"timer","select",a.id)}else t.bots.filter(d=>d.lvl>=Pi).length>=2&&r("i"+a.id,o,"🧬 <span>Fuse</span>","","select",a.id)}}for(let a=0;a<5;a++)for(let o=0;o<5;o++){const l=`${a},${o}`;if(Ka(t,l)!=="buyable")continue;const c={x:a*he+he/2-It/2,y:.4,z:o*he+he/2-It/2},d=lr(t);t.lvl>=zl(t.landBought)&&(e.cam.tdist>40||d&&d.kind==="land")&&r("p"+l,c,`＋ ${me.credits}${yt(kl(t.landBought))}`,"plot","plot",l)}for(const[a,o]of this.bubbles)n.has(a)||(o.remove(),this.bubbles.delete(a))}select(t){this.sel=t,this.selBot=null,this.world.select(t,this.s),this.panelKey="",this.renderPanel()}selectBot(t){this.sel=null,this.selBot=t,this.world.select(null),this.panelKey="",this.renderPanel()}panelSig(){const t=this.s;if(this.selBot){const s=t.bots.find(r=>r.id===this.selBot);return s?["bot",s.id,s.lvl,s.fed,s.post,s.bay,s.stored,s.nick].join("|"):""}const e=this.sel?Me(t,this.sel):null;if(!e)return"";const n=t.jobs.filter(s=>s.item===e.id).map(s=>s.id+s.kind).join();return[e.id,e.lvl,e.r,n,e.t==="bay"?pi(t,e.id).map(s=>s.id+s.lvl+s.fed+(s.post||"")).join():"",t.ready[e.id]?1:0,t.lvl,vi(t),Wa(t),Aa(t,e.id).map(s=>s.id).join(),e.t==="assembly"?t.cores.map(s=>s.id+s.state).join():"",this.crew.fuseA,this.crew.fuseB].join("|")}refreshPanel(){if(!this.sel&&!this.selBot)return;if(this.panelSig()!==this.panelKey){this.renderPanel();return}const e=this.s;if(this.selBot){as("#panel [data-cost]").forEach(s=>{const[r,a]=s.dataset.cost.split(":");s.classList.toggle("short",e.res[r]<+a)});return}const n=Me(e,this.sel);if(n){if(as("#panel [data-left]").forEach(s=>{const r=e.jobs.find(a=>a.id===s.dataset.left);r&&(s.textContent=tn((r.end-Date.now())/1e3))}),as("#panel [data-bar]").forEach(s=>{const r=e.jobs.find(a=>a.id===s.dataset.bar);r&&(s.style.width=Ci(1-(r.end-Date.now())/(r.end-r.start))*100+"%")}),as("#panel [data-dm]").forEach(s=>{const r=e.jobs.find(a=>a.id===s.dataset.dm);if(r){const a=qi((r.end-Date.now())/1e3);s.innerHTML=a?`${me.dm}${a} Finish now`:"Finish (free)"}}),n.t==="bay"){const s=ye("#panel .bar.gold i"),r=ye("#panel #bayv"),a=e.bay[n.id]||0;s&&(s.style.width=a/Ri(n)*100+"%"),r&&(r.textContent=`${yt(a)} / ${yt(Ri(n))}`)}as("#panel [data-cost]").forEach(s=>{const[r,a]=s.dataset.cost.split(":");s.classList.toggle("short",e.res[r]<+a)})}}renderPanel(){const t=ye("#panel"),e=this.s,n=this.selBot?e.bots.find(l=>l.id===this.selBot):null;if(n){t.classList.remove("hidden"),this.panelKey=this.panelSig(),t.innerHTML=this.crew.botPanel(n);return}const s=this.sel?Me(e,this.sel):null;if(!s){t.classList.add("hidden");return}t.classList.remove("hidden"),this.panelKey=this.panelSig();const r=oe[s.t],a=Fe(e,s.id,"build");let o=`<button class="ibtn x" data-a="deselect">✕</button><h2>${Ut(s.t==="bay"?`${Wt[s.el].name} Bay`:r.name)}</h2><div class="sub">${r.cat==="decor"?"Decoration":`Level ${s.lvl} / ${Lh(e,s)}`}</div>`;if(a){const l=qi((a.end-Date.now())/1e3);o+=`<p class="desc">${s.lvl===0?"Under construction":`Upgrading to level ${a.lvl}`}: builder drones at work.</p><div class="bar"><i data-bar="${a.id}"></i></div><div class="row" style="margin-top:8px"><b class="grow" data-left="${a.id}"></b><button class="btn gold small" data-a="finish" data-job="${a.id}" data-dm="${a.id}">${l?`${me.dm}${l} Finish now`:"Finish (free)"}</button></div>`}else if(s.t==="command"){const l=s.lvl+1;o+=`<p class="desc">${Ut(r.desc)}</p><table class="stats"><tr><td>Bays allowed</td><td>${Ea(s.lvl)}</td></tr><tr><td>Fabricators allowed</td><td>${ar(s.lvl)}</td></tr><tr><td>Max building level</td><td>${s.lvl}</td></tr><tr><td>Builder drones</td><td>${e.builders}</td></tr></table>`,s.lvl<r.max&&(o+=`<div class="sub">Level ${l}: ${Ea(l)} bays · ${ar(l)} fabricators · buildings to level ${l}${Ts[l]>e.lvl?` · needs Commander level ${Ts[l]}`:""}</div>`),o+=this.upgradeRow(s)+this.crew.helpersHTML(s)+`<div class="row" style="margin-top:8px"><button class="btn small" data-a="custom">🎨 Colony style</button><button class="btn small" data-a="move" data-id="${s.id}">✥ Move</button></div>`}else if(s.t==="arena"){const l=Bn(e),c=Qi(l.trophies);o+=`<p class="desc">${Ut(r.desc)}</p><div class="row"><b class="grow" style="color:${ir[c]}">🏆 ${Ii[c][0]} · ${yt(l.trophies)}</b><span class="chip">🎟 ${l.tickets}/${ts}</span></div><button class="btn gold" data-a="arena" style="width:100%;margin-top:8px">⚔ Enter the Arena</button>`+this.upgradeRow(s,s.lvl<r.max?`Level ${s.lvl+1}: battle rewards +${s.lvl*10}%`:"")+this.moveRow(s)}else if(s.t==="assembly"||s.t==="fusion")o+=(s.t==="assembly"?this.crew.assemblyHTML(s):this.crew.fusionHTML(s))+this.upgradeRow(s,s.lvl<r.max?s.t==="assembly"?`Level ${s.lvl+1}: boots 5% faster${fr(s.lvl+1)>fr(s.lvl)?", +1 pod":""}${Us(s.lvl+1)>Us(s.lvl)?", +1 helper slot":""}`:`Level ${s.lvl+1}: fuses 5% faster`:"")+this.moveRow(s);else if(s.t==="bay"){const l=pi(e,s.id),c=Rs(s.lvl),d=e.bay[s.id]||0,h=Ya(e,s.id)*60;o+=`<div class="row"><div class="grow"><div class="bar gold"><i style="width:${d/Ri(s)*100}%"></i></div></div><b id="bayv">${yt(d)} / ${yt(Ri(s))}</b></div><div class="row" style="margin:6px 0"><span class="grow sub">${me.credits} ${yt(h)} per minute · ${l.length}/${c} bots</span><button class="btn gold small" data-a="collect" data-id="${s.id}" ${d>=1?"":"disabled"}>Collect</button></div>`,o+=`<div class="bots">${l.map(u=>this.botCard(u)).join("")||'<p class="desc">No bots yet. Recruit one in the Shop.</p>'}</div>`,l.length<c&&(o+=`<button class="btn small" style="margin-top:8px;width:100%" data-a="shop" data-tab="bots">＋ Recruit a ${Wt[s.el].name} bot</button>`),o+=this.upgradeRow(s,s.lvl<r.max?`Level ${s.lvl+1}: holds ${yt(Wh(s.lvl+1))} credits${Rs(s.lvl+1)>c?`, ${Rs(s.lvl+1)} bots`:""}`:"")+this.moveRow(s)}else if(s.t==="fab"){const l=e.ready[s.id],c=Fe(e,s.id,"craft");if(l)o+=`<div class="row"><span class="grow desc">${yt(l.cells)} Power Cells are ready.</span><button class="btn green" data-a="harvest" data-id="${s.id}">${me.cells} Harvest</button></div>`;else if(c){const d=Fs[c.recipe||0],h=qi((c.end-Date.now())/1e3);o+=`<p class="desc">Printing <b>${Ut(d.name)}</b></p><div class="bar cell"><i data-bar="${c.id}"></i></div><div class="row" style="margin-top:8px"><b class="grow" data-left="${c.id}"></b><button class="btn gold small" data-a="finish" data-job="${c.id}" data-dm="${c.id}">${h?`${me.dm}${h} Finish now`:"Finish (free)"}</button></div>`}else o+=`<p class="desc">Pick a recipe. Longer recipes make more cells per credit: choose one that finishes when you'll be back.</p><div class="recipes">${zh(s).map(d=>`<div class="rec ${d.open?"":"locked"}"><b>${Ut(d.name)}</b><span class="out">⚡${yt(d.out)}</span><span class="sub">${tn(d.sec)}</span>${d.open?`<button class="btn small" data-a="craft" data-id="${s.id}" data-r="${d.i}"><span class="cost" data-cost="credits:${d.cost}">${me.credits}${yt(d.cost)}</span></button>`:`<span class="why">Level ${d.lvl}</span>`}</div>`).join("")}</div>`;o+=this.upgradeRow(s,s.lvl<r.max?`Level ${s.lvl+1}: +10% cells${Fs.some(d=>d.lvl===s.lvl+1)?", a new recipe":""}`:"")+this.crew.helpersHTML(s)+this.moveRow(s)}else o+=`<p class="desc">${Ut(r.desc)}</p><div class="row"><button class="btn small" data-a="move" data-id="${s.id}">✥ Move</button><button class="btn small" data-a="sell" data-id="${s.id}">Sell (${me.credits}${yt(Math.floor(r.buildCost(0)*.5))})</button></div>`;t.innerHTML=o}moveRow(t){return`<div class="row" style="margin-top:8px"><button class="btn small" data-a="move" data-id="${t.id}">✥ Move</button></div>`}upgradeRow(t,e=""){const n=this.s,s=oe[t.t];if(t.lvl>=s.max)return'<p class="sub">Maximum level.</p>';const r=Wl(n,t);return`${e?`<div class="sub">${e}</div>`:""}<div class="row" style="margin-top:8px"><span class="grow">${r.cost?`<span class="cost ${n.res.credits<r.cost?"short":""}" data-cost="credits:${r.cost}">${me.credits}${yt(r.cost)}</span> · ${tn(r.time||0)}`:""}</span><button class="btn gold" data-a="upgrade" data-id="${t.id}" ${r.ok?"":"disabled"}>⬆ Upgrade</button></div>${r.ok?"":`<p class="why">${Ut(r.why||"")}</p>`}`}botCard(t,e=!1){const n=this.s,s=gt[t.sp],r=qa(t.lvl),a=e&&t.bay?Me(n,t.bay):null;return`<div class="botc"><div class="pic" data-a="selBot" data-bot="${t.id}" style="cursor:pointer;background:radial-gradient(circle at 50% 40%, ${Wt[s.el[0]].color}55, transparent 70%)"><img src="${this.app.studio.bot(t.sp)}" alt=""></div>
      <div><b data-a="selBot" data-bot="${t.id}" style="cursor:pointer">${Ut(t.nick||s.name)}</b> ${ma(s.el)}<div class="meta"><span class="rar" style="color:${Qt[s.rarity].color}">${Qt[s.rarity].name}</span> · Level ${t.lvl}<span class="pips">${[0,1,2,3].map(o=>`<i class="${o<t.fed?"on":""}"></i>`).join("")}</span></div><div class="meta">${t.post?"🛠 helping":t.stored?"❄ stored":`${me.credits} ${yt(li(t))}/min`}${a?` · ${Wt[a.el].name} Bay`:""}</div></div>
      ${t.lvl<Xa?`<button class="btn small green" data-a="feed" data-bot="${t.id}"><span class="cost" data-cost="cells:${r}">${me.cells}${yt(r)}</span></button>`:'<span class="sub">MAX</span>'}</div>`}openOver(t,e){this.over=t,e&&(this.tab=e),this.select(null),this.renderOver(),this.app.platform.gameplayStop()}closeOver(){this.over="",ye("#over").classList.add("hidden"),this.app.platform.gameplayStart()}renderOver(){const t=ye("#over");t.classList.remove("hidden");const e=this.s;if(this.over==="shop"){const n=[["bays","Bays"],["bots","Bots"],["buildings","Buildings"],["decor","Decor"]];let s="";this.tab==="bays"?s=G_.map(r=>{const a=Ti(e,"bay",r),o=Zt(e,"bay").filter(l=>l.el===r).length;return this.shopCard(this.app.studio.building("bay",1,r,this.world.look),`${Wt[r].name} Bay`,`${Wt[r].blurb} ${o?`You have ${o}.`:""}`,a,`data-a="buyB" data-t="bay" data-el="${r}"`,ma([r]))}).join(""):this.tab==="bots"?s=Xn.filter(r=>gt[r].price).map(r=>{const a=gt[r],o=ql(e,r),l=e.bots.filter(c=>c.sp===r).length;return this.shopCard(this.app.studio.bot(r),a.name,a.desc+(a.rarity!=="standard"?` Boots in the Assembly Bay (${tn(Qt[a.rarity].assembly*.5)}).`:""),o,`data-a="recruit" data-sp="${r}"`,`${ma(a.el)} <span class="rar" style="color:${Qt[a.rarity].color}">${Qt[a.rarity].name}</span> · ${yt(li({sp:r,lvl:1}))}/min${l?` · owned ${l}`:""}${e.dex[r]?"":' · <b style="color:#ffd36a">new</b>'}`,(a.unlock||1)>e.lvl)}).join(""):this.tab==="buildings"?s=["fab","assembly","fusion"].map(r=>{const a=Ti(e,r);return this.shopCard(this.app.studio.building(r,1,void 0,this.world.look),oe[r].name,oe[r].desc,a,`data-a="buyB" data-t="${r}"`,r==="fab"?`${Zt(e,r).length}/${ar(vi(e))} built`:Zt(e,r).length?"Built":`Unlocks at Commander level ${oe[r].unlock}`,oe[r].unlock>e.lvl)}).join(""):s=[...e.stats.decor_arch?["arch"]:[],...Wc.filter(r=>oe[r].cat==="decor")].map(r=>{const a=Ti(e,r);return this.shopCard(this.app.studio.building(r,1,void 0,this.world.look),oe[r].name,oe[r].desc,a,`data-a="buyB" data-t="${r}"`,"",oe[r].unlock>e.lvl)}).join(""),t.innerHTML=`<div class="head"><h1>Shop</h1><div class="res">${me.credits}<span>${yt(e.res.credits)}</span></div><button class="ibtn" data-a="close">✕</button></div><div class="tabs">${n.map(([r,a])=>`<button class="tab ${this.tab===r?"on":""}" data-a="tab" data-tab="${r}">${a}</button>`).join("")}</div><div class="body"><div class="grid">${s}</div></div>`}else if(this.over==="bots"){const n=[...e.bots].sort((a,o)=>li(o)-li(a)),s=e.bots.reduce((a,o)=>a+li(o),0),r=e.cores.length?`<div class="botc" style="grid-template-columns:54px 1fr auto;border-color:var(--gold)"><div style="font-size:30px;text-align:center">🤖</div><div><b>${e.cores.length} core${e.cores.length>1?"s":""} waiting</b><div class="meta">${e.cores.map(a=>`<span style="color:${Qt[gt[a.sp].rarity].color}">●</span>`).join(" ")} ${Zt(e,"assembly").some(a=>a.lvl>0)?"in the Assembly Bay":"Build the Assembly Bay (Commander level 4) to boot them"}</div></div><span></span></div>`:"";t.innerHTML=`<div class="head"><h1>Your crew</h1><span class="sub">${e.bots.length} bots · ${me.credits} ${yt(s)}/min</span><button class="ibtn" data-a="close">✕</button></div><div class="body"><div class="bots" style="max-width:640px;margin:0 auto">${r}${n.map(a=>this.botCard(a,!0)).join("")}</div></div>`}else if(this.over==="custom")t.innerHTML=this.customHTML();else if(this.over==="dex")t.innerHTML=this.crew.dexHTML();else if(this.over==="daily")t.innerHTML=this.daily.overHTML();else if(this.over==="arena")t.innerHTML=this.arena.overHTML();else if(this.over==="settings"){const n=e.settings;t.innerHTML=`<div class="head"><h1>Settings</h1><button class="ibtn" data-a="close">✕</button></div><div class="body"><div class="card" style="max-width:420px;margin:0 auto;gap:12px">
      <label>Sound effects <input type="range" min="0" max="1" step="0.05" value="${n.sfx}" data-set="sfx" style="width:100%"></label><label>Music <input type="range" min="0" max="1" step="0.05" value="${n.music}" data-set="music" style="width:100%"></label>
      <label>Graphics <select data-set="quality" style="width:100%;padding:8px;border-radius:8px;background:#0d1a2e;color:#fff;border:1px solid var(--line)">${["auto","high","low"].map(s=>`<option ${n.quality===s?"selected":""}>${s}</option>`).join("")}</select></label>
      <p class="sub">Starward 3D · version ${this.app.version} · crazygames build. Your colony runs in real time, even while you are away.</p><button class="btn" data-a="reset">Reset progress</button></div></div>`}}shopCard(t,e,n,s,r,a="",o=!1){return`<div class="card ${o?"locked":""}"><div class="thumb"><img src="${t}" alt=""></div><b>${Ut(e)}</b>${a?`<div class="sub" style="margin:0">${a}</div>`:""}<p class="desc">${Ut(n)}</p>
      <button class="btn ${s.ok?"gold":""} small" ${r} ${s.ok?"":"disabled"}>${o?"🔒 ":""}${s.cost!==void 0?`<span class="cost" data-cost="credits:${s.cost}">${me.credits}${yt(s.cost)}</span>`:"Free"}</button>${s.ok?"":`<span class="why">${Ut(s.why||"")}</span>`}</div>`}refreshOverCosts(){as("#over [data-cost]").forEach(t=>{const[e,n]=t.dataset.cost.split(":");t.classList.toggle("short",this.s.res[e]<+n)})}customHTML(){const t=this.s,e=this.bannerSVG(t.banner);return`<div class="head"><h1>Colony style</h1><button class="ibtn" data-a="close">✕</button></div><div class="body"><div class="card" style="max-width:520px;margin:0 auto;gap:12px">
      <label class="ox">Colony name<input id="cname" value="${Ut(t.name)}" maxlength="24" style="width:100%;margin-top:6px;padding:10px;border-radius:10px;border:1px solid var(--line);background:#0d1a2e;color:#fff;font:600 16px Barlow"></label>
      <div><div class="ox">Paint scheme</div><div class="row" style="margin-top:6px">${_h.map(([n,s],r)=>`<button data-a="paint" data-i="${r}" style="width:46px;height:46px;border-radius:12px;border:2px solid ${t.paint.primary===n&&t.paint.accent===s?"#fff":"transparent"};background:linear-gradient(135deg, ${n} 55%, ${s} 55%)"></button>`).join("")}</div></div>
      <div><div class="ox">Banner</div><div class="row" style="margin-top:6px;align-items:flex-start"><div style="width:120px">${e}</div><div class="grow"><div class="row">${V_.map(n=>`<button data-a="bannerBg" data-c="${n}" style="width:30px;height:30px;border-radius:8px;background:${n};border:2px solid ${t.banner.bg===n?"#fff":"transparent"}"></button>`).join("")}</div>
        <div class="row" style="margin-top:6px">${["#ffd23a","#ffffff","#14202e","#ff4f6a","#6ee7ff","#7cf29a"].map(n=>`<button data-a="bannerFg" data-c="${n}" style="width:30px;height:30px;border-radius:50%;background:${n};border:2px solid ${t.banner.fg===n?"#6ee7ff":"rgba(255,255,255,0.2)"}"></button>`).join("")}</div>
        <div class="row" style="margin-top:6px">${$_.map(n=>`<button class="btn small ${t.banner.emblem===n?"gold":""}" data-a="emblem" data-e="${n}">${this.bannerSVG({bg:"transparent",fg:"#ffffff",emblem:n},22)}</button>`).join("")}</div></div></div></div>
      <p class="sub">Your paint scheme recolours every building's trim; your banner flies over the Command Center and on every Colony Flag. More decorations, paints and banner parts unlock as you level up.</p></div></div>`}bannerSVG(t,e=120){const n=document.createElement("canvas");n.width=128,n.height=80;const s=n.getContext("2d");return t.bg!=="transparent"&&(s.fillStyle=t.bg,s.fillRect(0,0,128,80)),s.fillStyle=t.fg,s.translate(64,40),_c(s,t.emblem,26),s.fill(),`<img src="${n.toDataURL()}" style="width:${e}px;height:${e*80/128}px;border-radius:6px;display:block">`}renderPlace(){const t=ye("#place"),e=this.world.ghost;if(!e){t.classList.add("hidden");return}t.classList.remove("hidden");const n=oe[e.t],s=e.move?null:Ti(this.s,e.t,e.el);t.innerHTML=`<span class="lbl">${Ut(e.t==="bay"?`${Wt[e.el].name} Bay`:n.name)}${s&&s.cost?` · ${me.credits}${yt(s.cost)}`:""}</span><button class="btn small" data-a="placeRot">⟳ Rotate</button><button class="btn small" data-a="placeCancel">✕</button><button class="btn green small" data-a="placeOk" ${e.ok?"":"disabled"}>✓ ${e.move?"Place":"Build"}</button>`}toast(t,e=""){const n=document.createElement("div");n.className="toast "+e,n.textContent=t,ye("#toasts").appendChild(n),setTimeout(()=>n.remove(),2600)}popText(t,e,n,s){const r=document.createElement("div");r.className="pop",r.style.left=t+"px",r.style.top=e+"px",r.style.color=s,r.textContent=n,document.body.appendChild(r),setTimeout(()=>r.remove(),1100)}flyTo(t,e,n,s=6){const r=ye(`#r-${t}`);if(!r)return;const a=r.getBoundingClientRect();for(let o=0;o<s;o++){const l=document.createElement("div");l.className="fly",l.innerHTML=me[t].replace('class="ic','style="width:26px;height:26px" class="ic'),l.style.left=e-13+(Math.random()-.5)*40+"px",l.style.top=n-13+(Math.random()-.5)*30+"px",document.body.appendChild(l),setTimeout(()=>{l.style.transform=`translate(${a.left+13-parseFloat(l.style.left)}px, ${a.top+13-parseFloat(l.style.top)}px) scale(0.6)`,l.style.opacity="0.4"},30+o*45),setTimeout(()=>l.remove(),800+o*45)}}modal(t,e=!1){const n=ye("#modal");n.innerHTML=`${e?'<div class="rays"></div>':""}<div class="box">${t}</div>`,n.classList.remove("hidden"),this.app.platform.gameplayStop()}closeModal(){ye("#modal").classList.add("hidden"),ye("#modal").innerHTML="",this.over||this.app.platform.gameplayStart()}levelUp(t,e,n=null){const s=[...Xn.filter(r=>gt[r].unlock===t).map(r=>gt[r].name),...Wc.filter(r=>oe[r].unlock===t).map(r=>oe[r].name)];this.modal(`<div class="ox sub" style="letter-spacing:.2em">COMMANDER LEVEL</div><div class="big">${t}</div><h1>Level up!</h1><div class="rewards">${xh(e)}</div>${n?`<div class="sub" style="margin:0">Milestone bonus</div>${this.daily.giftLine(n)}`:""}${s.length?`<p class="desc">Unlocked: <b>${s.map(Ut).join(", ")}</b></p>`:""}${Ts.indexOf(t)>1?`<p class="desc">You can now upgrade the Command Center to level ${Ts.indexOf(t)}.</p>`:""}<button class="btn gold" data-a="closeModal" style="margin-top:8px;min-width:160px">Awesome!</button>`,!0)}newBot(t){const e=gt[t.sp],n=Date.now()-(this.s.dex[t.sp]||0)<4e3&&Object.keys(this.s.dex).length>1,s=Qt[e.rarity].color,r=on.indexOf(e.rarity);this.modal(`<div class="ox sub" style="letter-spacing:.2em;color:${s}">${n?"★ NEW SPECIES DISCOVERED ★":"NEW CREWMATE"}</div>${r>=2?`<div style="position:absolute;inset:0;border-radius:22px;box-shadow:inset 0 0 60px ${s}66;pointer-events:none"></div>`:""}<img src="${this.app.studio.bot(t.sp)}" style="width:180px;height:180px;margin:-6px auto -10px;display:block"><h1>${Ut(e.name)}</h1><div>${ma(e.el)} <span class="rar" style="color:${Qt[e.rarity].color}">${Qt[e.rarity].name}</span></div><p class="desc">${Ut(e.desc)}</p><p class="sub">Earns ${me.credits} ${yt(li(t))} per minute. Feed it Power Cells to level it up.</p><button class="btn gold" data-a="closeModal" style="min-width:160px">Welcome aboard!</button>`,!0)}act(t,e){const n=this.app,s=this.s;if(n.audio.unlock(),this.crew.act(t,e)||this.daily.act(t,e)||this.arena.act(t,e))return;const r=e.dataset.id||"",a=r?Me(s,r):void 0;switch(t){case"shop":this.openOver("shop",e.dataset.tab||this.tab),n.audio.play("tap");break;case"bots":this.openOver("bots"),n.audio.play("tap");break;case"dex":this.openOver("dex"),n.audio.play("tap");break;case"custom":this.openOver("custom"),n.audio.play("tap");break;case"settings":this.openOver("settings"),n.audio.play("tap");break;case"close":this.closeOver(),n.audio.play("tap");break;case"tab":this.tab=e.dataset.tab,this.renderOver(),n.audio.play("tap");break;case"zoomout":this.world.focus(0,1,this.world.cam.tdist>45?30:58),n.audio.play("whoosh");break;case"deselect":this.select(null),this.selBot=null,this.renderPanel();break;case"select":r&&(this.select(r),n.audio.play("tap"));break;case"collect":a&&n.collect(a);break;case"harvest":a&&n.harvest(a);break;case"craft":if(a){const o=Gh(s,a,+e.dataset.r);o.ok?(n.audio.play("buy"),n.changed(),this.renderPanel()):this.deny(o.why)}break;case"upgrade":if(a){const o=Dh(s,a);o.ok?(n.audio.play("build"),n.changed(),this.renderPanel()):this.deny(o.why)}break;case"finish":{const o=s.jobs.find(l=>l.id===e.dataset.job);o&&Oh(s,o)?(n.audio.play("done"),n.changed(),this.renderPanel()):this.deny("Not enough Dark Matter");break}case"feed":{const o=s.bots.find(c=>c.id===e.dataset.bot);if(!o)break;const l=Xl(s,o);if(l.ok){n.audio.play(l.lvlUp?"done":"feed");const c=e.getBoundingClientRect();this.popText(c.left+c.width/2,c.top,l.lvlUp?`Level ${o.lvl}!`:"+XP",l.lvlUp?"#ffd36a":"#9dff5a"),n.changed(),this.over==="bots"?this.renderOver():this.renderPanel()}else this.deny(l.why);break}case"recruit":{const o=Bh(s,e.dataset.sp);if(o.ok&&o.core){n.audio.play("buy"),this.closeOver(),n.changed();const l=Zt(s,"assembly")[0];if(l){const c=this.world.centerOf(l);this.world.focus(c.x,c.z),this.select(l.id)}this.toast("The core is booting in the Assembly Bay","good");break}if(o.ok&&o.bot){n.audio.play("buy"),this.closeOver(),n.changed(),this.newBot(o.bot);const l=Me(s,o.bot.bay);if(l){const c=this.world.centerOf(l);this.world.focus(c.x,c.z)}}else this.deny(o.why);break}case"buyB":{const o=e.dataset.t,l=e.dataset.el,c=Ti(s,o,l);if(!c.ok){this.deny(c.why);break}this.closeOver(),n.startPlacing({t:o,el:l,r:0,x:0,z:0,ok:!1});break}case"move":a&&(this.select(null),n.startPlacing({t:a.t,el:a.el,r:a.r,x:a.x,z:a.z,move:a.id,ok:!0}));break;case"sell":a&&Fh(s,a)&&(n.audio.play("buy"),this.select(null),n.changed());break;case"placeRot":this.world.rotateGhost(),n.audio.play("tap");break;case"placeCancel":n.endPlacing(),n.audio.play("tap");break;case"placeOk":n.confirmPlacing();break;case"plot":n.askPlot(r);break;case"buyPlot":{const o=Vh(s,e.dataset.k);this.closeModal(),o.ok?(n.audio.play("levelup"),n.changed(),this.toast("The island grows!","gold")):this.deny(o.why);break}case"claim":{const o=$h(s);if(o){n.audio.play("claim");const l=e.getBoundingClientRect();for(const c of Object.keys(o.reward))this.flyTo(c,l.left+l.width/2,l.top);n.changed(),this.renderObj()}break}case"closeModal":this.closeModal(),n.audio.play("tap");break;case"paint":{const[o,l]=_h[+e.dataset.i];s.paint={primary:o,accent:l},n.changed(),this.renderOver(),n.audio.play("tap");break}case"bannerBg":s.banner={...s.banner,bg:e.dataset.c},n.changed(),this.renderOver(),n.audio.play("tap");break;case"bannerFg":s.banner={...s.banner,fg:e.dataset.c},n.changed(),this.renderOver(),n.audio.play("tap");break;case"emblem":s.banner={...s.banner,emblem:e.dataset.e},n.changed(),this.renderOver(),n.audio.play("tap");break;case"reset":e.dataset.sure?n.reset():(e.dataset.sure="1",e.textContent="Tap again to erase your colony");break}}deny(t){this.toast(t||"Not possible","bad"),this.app.audio.play("deny")}}class X_{constructor(){this.ctx=null,this.out=null,this.vol=.8,this.mvol=.45,this.muted=!1,this.music=null,this.timer=0}unlock(){if(this.ctx){this.ctx.state==="suspended"&&this.ctx.resume();return}try{this.ctx=new(window.AudioContext||window.webkitAudioContext),this.out=this.ctx.createGain(),this.out.gain.value=this.muted?0:this.vol,this.out.connect(this.ctx.destination)}catch{this.ctx=null}}setVolume(t){this.vol=t,this.out&&(this.out.gain.value=this.muted?0:t)}setMuted(t){this.muted=t,this.out&&(this.out.gain.value=t?0:this.vol),this.music&&(this.music.bus.gain.value=t?0:this.mvol*.4)}tone(t,e,n,s="sine",r=.2,a=0){const o=this.ctx,l=o.createOscillator(),c=o.createGain();l.type=s,l.frequency.setValueAtTime(t,e),a&&l.frequency.exponentialRampToValueAtTime(Math.max(30,t*a),e+n),c.gain.setValueAtTime(0,e),c.gain.linearRampToValueAtTime(r,e+.008),c.gain.exponentialRampToValueAtTime(1e-4,e+n),l.connect(c),c.connect(this.out),l.start(e),l.stop(e+n+.05)}noise(t,e,n=.2,s=800){const r=this.ctx,a=r.createBuffer(1,Math.floor(r.sampleRate*e),r.sampleRate),o=a.getChannelData(0);for(let h=0;h<o.length;h++)o[h]=(Math.random()*2-1)*(1-h/o.length);const l=r.createBufferSource();l.buffer=a;const c=r.createBiquadFilter();c.type="lowpass",c.frequency.value=s;const d=r.createGain();d.gain.value=n,l.connect(c),c.connect(d),d.connect(this.out),l.start(t)}play(t,e=1){if(!this.ctx||!this.out||this.muted)return;const n=this.ctx.currentTime;switch(t){case"tap":this.tone(880,n,.06,"triangle",.08);break;case"collect":{const s=Math.min(6,2+Math.floor(Math.log10(Math.max(1,e))));[0,4,7,12,16,19].slice(0,s).forEach((r,a)=>this.tone(988*Math.pow(2,r/12),n+a*.055,.22,"triangle",.12));break}case"harvest":[0,5,9].forEach((s,r)=>this.tone(660*Math.pow(2,s/12),n+r*.06,.2,"square",.05)),this.tone(1320,n+.2,.3,"sine",.08);break;case"build":this.noise(n,.12,.25,500),this.tone(120,n,.18,"sine",.3,.5);break;case"place":this.tone(220,n,.12,"sine",.25,.6),this.noise(n,.08,.15,1200);break;case"done":[0,4,7,12].forEach((s,r)=>this.tone(523*Math.pow(2,s/12),n+r*.08,.3,"triangle",.12));break;case"feed":this.tone(300,n,.15,"sawtooth",.06,2.2),this.tone(600,n+.05,.12,"square",.04,1.6);break;case"levelup":[0,4,7,12,16,19,24].forEach((s,r)=>this.tone(392*Math.pow(2,s/12),n+r*.07,.5,"triangle",.13)),[0,4,7].forEach(s=>this.tone(784*Math.pow(2,s/12),n+.55,.9,"sine",.09));break;case"deny":this.tone(180,n,.16,"square",.07,.7);break;case"buy":this.tone(660,n,.1,"triangle",.1),this.tone(990,n+.08,.18,"triangle",.1);break;case"claim":[0,7,12].forEach((s,r)=>this.tone(659*Math.pow(2,s/12),n+r*.07,.35,"triangle",.12));break;case"whoosh":this.noise(n,.35,.18,2400);break}}setMusic(t){this.mvol=t,this.music?this.music.bus.gain.setTargetAtTime(this.muted?0:t*.4,this.ctx.currentTime,.4):t>0&&this.startMusic()}startMusic(){if(!this.ctx||this.music||this.mvol<=0)return;const t=this.ctx,e=t.createGain();e.gain.value=0,e.gain.setTargetAtTime(this.muted?0:this.mvol*.4,t.currentTime,2),e.connect(t.destination);const n=t.createBiquadFilter();n.type="lowpass",n.frequency.value=1200,n.connect(e),this.music={bus:e,next:t.currentTime+.5,chord:0,lp:n},this.timer=window.setInterval(()=>this.tick(),300)}tick(){const t=this.ctx,e=this.music;if(!t||!e||t.state!=="running")return;const n=t.currentTime;if(n<e.next)return;const s=[[261.63,329.63,392,493.88],[220,261.63,329.63,392],[174.61,220,261.63,329.63],[196,246.94,293.66,392],[233.08,293.66,349.23,440]],r=s[e.chord%s.length];e.chord+=1+(Math.random()<.25?1:0);const a=9;for(const o of r)for(const l of[-6,5]){const c=t.createOscillator();c.type="sawtooth",c.frequency.value=o/2,c.detune.value=l;const d=t.createGain();d.gain.setValueAtTime(0,n),d.gain.linearRampToValueAtTime(.011,n+3),d.gain.setValueAtTime(.011,n+a-2.5),d.gain.linearRampToValueAtTime(0,n+a+1),c.connect(d),d.connect(e.lp),c.start(n),c.stop(n+a+1.5)}for(let o=0;o<3;o++){const l=r[Math.floor(Math.random()*r.length)]*2,c=t.createOscillator();c.type="sine",c.frequency.value=l;const d=t.createGain(),h=n+1+o*2.4+Math.random();d.gain.setValueAtTime(0,h),d.gain.linearRampToValueAtTime(.03,h+.01),d.gain.exponentialRampToValueAtTime(1e-4,h+2.5),c.connect(d),d.connect(e.bus),c.start(h),c.stop(h+2.6)}e.lp.frequency.setTargetAtTime(800+Math.random()*900,n,3),e.next=n+a-1.5}}const ga="starward3d_v1";class q_{constructor(){this.version="0.2",this.platform=ef,this.audio=new X_,this.last=performance.now(),this.saveAt=0,this.queue=[],this.dayCheck=0}async boot(){await this.platform.init(),this.platform.loadingStart();const t=this.platform.load(ga);let e;try{e=t?af(JSON.parse(t)):ko()}catch(c){console.warn("save unreadable, starting fresh",c),e=ko()}this.s=e;const n=Date.now()-(e.last||Date.now());or(e,Date.now());const s=Yn.filter(c=>c.kind==="built").length;Yn.length=0,oh(e),Ha(e);const r=Zt(e,"bay").map(c=>Math.floor(e.bay[c.id]||0)).filter(c=>c>=1),a={credits:r.reduce((c,d)=>c+d,0),bays:r.length,ready:Object.keys(e.ready).length,cores:e.cores.filter(c=>c.state==="ready").length,built:s};this.world=new U_(ye("#gl"),e.settings.quality),this.studio=new F_(this.world.renderer),this.ui=new W_(this),this.audio.setVolume(e.settings.sfx),this.audio.mvol=e.settings.music,this.platform.onMute=c=>this.audio.setMuted(c),this.platform.muted()&&this.audio.setMuted(!0),this.world.onTap=c=>this.tapped(c),this.world.onGhostMove=()=>this.validatePlacing(),this.world.sync(e);const o=Zt(e,"command")[0];if(o){const c=this.world.centerOf(o);this.world.cam.x=this.world.cam.tx=c.x-1,this.world.cam.z=this.world.cam.tz=c.z+1}document.addEventListener("pointerdown",()=>{this.audio.unlock(),this.audio.setMusic(this.s.settings.music)},{once:!0}),document.addEventListener("visibilitychange",()=>{document.hidden?this.save():or(this.s,Date.now())}),window.addEventListener("pagehide",()=>this.save()),requestAnimationFrame(c=>this.loop(c)),this.platform.loadingStop();const l=ye("#load");l.style.opacity="0",setTimeout(()=>l.remove(),500),this.platform.gameplayStart(),t&&n>10*6e4&&setTimeout(()=>this.enqueue(()=>this.ui.daily.offlineReport(n,a)),600),t||setTimeout(()=>this.ui.modal(`<div class="ox sub" style="letter-spacing:.2em">WELCOME, COMMANDER</div><h1>${Ut(e.name)}</h1><p class="desc">An asteroid in low Earth orbit, a Command Center, a fabricator and one small, cheerful robot named Helio. Everything else is up to you.</p><p class="desc">Your bots earn credits in their bays. Tap a bay to collect, print Power Cells, feed your crew and grow the colony.</p><button class="btn gold" data-a="closeModal" style="min-width:180px">Let's go!</button>`,!0),400),window.__app=this,window.__G=yf}loop(t){const e=Math.min(.05,(t-this.last)/1e3);this.last=t;const n=Date.now();if(or(this.s,n),oh(this.s,n),n>this.dayCheck){this.dayCheck=n+5e3,Ha(this.s,n),this.placeDrop(),Xu(this.s,n);const s=Yu(this.s,n);s&&this.enqueue(()=>this.ui.modal(`<div class="ox sub" style="letter-spacing:.2em">ARENA SEASON ENDED</div><div class="big">🏆</div><h1>${Ii[s.league][0]}</h1><p class="desc">Your best league this season. Here are your rewards:</p><div class="rewards">${Object.entries(s.reward).map(([r,a])=>`<span class="cost">${r==="dm"?"◆":r==="cells"?"⚡":"C"} ${yt(a)}</span>`).join(" ")}</div><button class="btn gold" data-a="closeModal">Collect</button>`,!0))}this.drain(),this.world.frame(e,this.s),this.ui.frame(),n>this.saveAt&&(this.saveAt=n+1e4,this.save()),requestAnimationFrame(s=>this.loop(s))}drain(){for(;Yn.length;){const t=Yn.shift();if(t.kind==="levelup"){this.audio.play("levelup"),this.platform.happytime();const e=t.lvl%5===0?Er(this.s,t.lvl%10===0?"advanced":"standard",t.lvl*7919+(this.s.created>>>0)):null;this.enqueue(()=>this.ui.levelUp(t.lvl,t.reward,e)),this.ui.renderHud()}else if(t.kind==="built"){this.audio.play("done"),this.world.topOf(t.item),this.changed();const e=Me(this.s,t.item);if(e){const n=this.world.topOf(e.id);n&&this.world.burst(n,"#ffd36a",30),this.ui.toast(`${e.t==="bay"?"Bay":oe[e.t].name} ${t.first?"is ready":`reached level ${t.lvl}`}!`,"good")}}else t.kind==="crafted"?this.changed():t.kind==="discover"?this.ui.toast(`New species in the Botdex: +${t.dm} Dark Matter`,"gold"):t.kind==="fused"?(this.audio.play("done"),this.changed(),this.ui.toast(`Fusion complete: a ${Qt[gt[t.sp].rarity].name} core is in the Assembly Bay`,"gold")):t.kind==="booted"?(this.audio.play("claim"),this.changed(),this.ui.toast(`A ${Qt[gt[t.sp].rarity].name} core has booted: activate it in the Assembly Bay`,"good")):t.kind==="core"?this.changed():t.kind==="land"&&this.changed()}this.queue.length&&ye("#modal").classList.contains("hidden")&&this.queue.shift()()}enqueue(t){this.queue.push(t)}placeDrop(){const t=ue(this.s);if(t.drops<=0){t.dropAt&&(t.dropAt=null,this.world.sync(this.s));return}if(t.dropAt&&Xi(this.s,t.dropAt[0],t.dropAt[1],1,1)){this.world.podTop()||this.world.sync(this.s);return}const e=Zt(this.s,"command")[0],n=e?e.x+2:15,s=e?e.z+2:15;let r=null,a=1e9;for(let o=0;o<30;o++)for(let l=0;l<30;l++){if(!Xi(this.s,o,l,1,1))continue;const c=Math.abs(Math.hypot(o-n,l-s)-4.5);c<a&&(a=c,r=[o,l])}t.dropAt=r,this.world.sync(this.s)}changed(){this.world.sync(this.s),this.ui.renderObjIfChanged(),this.saveAt=Math.min(this.saveAt,Date.now()+1500)}save(){try{this.platform.save(ga,JSON.stringify(this.s))}catch{}this.notifications()}notifications(){if(this.platform.name!=="mobile")return;const t=this.s,e=Date.now();let n=1/0;for(const o of Zt(t,"bay")){const l=Ya(t,o.id);l>0&&(n=Math.min(n,e+(Ri(o)-(t.bay[o.id]||0))/l*1e3))}isFinite(n)&&this.platform.notify("bays",n,"Your bays are full","Your crew has filled their bays with credits. Come and collect!");const s=t.jobs.filter(o=>o.kind==="craft").map(o=>o.end).sort()[0];s&&this.platform.notify("fab",s,"Power Cells ready","Your Fabricator has finished printing.");const r=ue(t);this.platform.notify("drop",r.drops?e+36e5:r.drop,"A supply drop has landed","Open it before the next one arrives.");const a=new Date;a.setDate(a.getDate()+1),a.setHours(19,0,0,0),this.platform.notify("daily",a.getTime(),"Your daily reward is waiting",`Day ${r.day+1} of your calendar is ready. Keep the streak going!`)}tapped(t){this.audio.unlock();const e=this.s;if(t.drop){const n=this.world.podTop();this.ui.daily.act("drop",document.body),n&&this.world.burst(n,"#7cf29a",40),this.placeDrop();return}if(t.bot){this.ui.selectBot(t.bot),this.audio.play("tap");return}if(t.item){const n=Me(e,t.item);if(!n)return;if(n.t==="bay"&&(e.bay[n.id]||0)>=1&&!Fe(e,n.id,"build")){this.collect(n),this.ui.sel!==n.id&&this.ui.select(n.id);return}if(n.t==="fab"&&e.ready[n.id]){this.harvest(n),this.ui.select(n.id);return}this.ui.select(this.ui.sel===n.id?null:n.id),this.audio.play("tap");return}if(t.plot){this.askPlot(t.plot);return}this.ui.select(null)}collect(t){const e=Yl(this.s,t);if(!e)return;this.audio.play("collect",e);const n=this.world.topOf(t.id);if(n){this.world.burst(n,"#ffd36a",18+Math.min(30,Math.floor(Math.log10(e)*6)));const s=this.world.project(n);this.ui.popText(s.x,s.y-10,`+${yt(e)}`,"#ffd36a"),this.ui.flyTo("credits",s.x,s.y,Math.min(9,3+Math.floor(Math.log10(e)*2)))}this.changed(),this.ui.renderPanel()}harvest(t){const e=Kl(this.s,t);if(!e)return;this.audio.play("harvest");const n=this.world.topOf(t.id);if(n){this.world.burst(n,"#9dff5a",26);const s=this.world.project(n);this.ui.popText(s.x,s.y-10,`+${yt(e)} ⚡`,"#9dff5a"),this.ui.flyTo("cells",s.x,s.y,6)}this.changed(),this.ui.renderPanel()}askPlot(t){const e=this.s,n=Zl(e,t),s=kl(e.landBought),r=zl(e.landBought);this.ui.modal(`<div class="ox sub" style="letter-spacing:.2em">EXPAND THE ISLAND</div><h1>New land</h1><p class="desc">Tow in another 6×6 slab of asteroid and bolt it to your island: room for more bays, fabricators and decorations.</p><div class="rewards"><span class="cost ${e.res.credits<s?"short":""}"><span class="ic cr">C</span>${yt(s)}</span></div>${n.ok?"":`<p class="why">${Ut(n.why||"")}</p>`}<div class="row" style="justify-content:center"><button class="btn" data-a="closeModal">Not now</button><button class="btn gold" data-a="buyPlot" data-k="${t}" ${n.ok?"":"disabled"}>Expand</button></div>${e.lvl<r?`<p class="sub">Reach Commander level ${r} to expand.</p>`:""}`)}startPlacing(t){const e=this.s;if(!t.move){const[n,s]=Qe({t:t.t,r:t.r}),r=Math.round(this.world.cam.tx+15-n/2),a=Math.round(this.world.cam.tz+15-s/2);let o=null,l=1e9;for(let c=0;c<30;c++)for(let d=0;d<30;d++)if(Xi(e,c,d,n,s)){const h=(c-r)**2+(d-a)**2;h<l&&(l=h,o=[c,d])}if(!o){this.ui.deny("No free space: expand the island or move things around");return}[t.x,t.z]=o}this.world.startGhost(t),this.world.sync(e),this.validatePlacing(),this.ui.select(null),this.audio.play("tap")}validatePlacing(){const t=this.world.ghost;if(!t)return;const[e,n]=Qe({t:t.t,r:t.r});this.world.setGhostOk(Xi(this.s,t.x,t.z,e,n,t.move)),this.ui.renderPlace()}confirmPlacing(){const t=this.world.ghost;if(!t||!t.ok)return;const e=this.s;if(t.move){const r=Me(e,t.move);r&&Uh(e,r,t.x,t.z,t.r)&&(this.audio.play("place"),this.endPlacing(),this.changed(),this.ui.select(r.id));return}const n=Ph(e,t.t,t.x,t.z,t.r,t.el);if(!n.ok){this.ui.deny(n.why);return}this.audio.play(oe[t.t].cat==="decor"?"place":"build"),this.changed();const s=n.item?this.world.topOf(n.item.id):null;if(s&&this.world.burst(s,"#6ee7ff",16),oe[t.t].cat==="decor"&&Ti(e,t.t).ok){this.validatePlacing(),this.ui.renderPlace();return}this.endPlacing(),n.item&&oe[t.t].cat!=="decor"&&this.ui.select(n.item.id)}endPlacing(){this.world.endGhost(),this.world.sync(this.s),this.ui.renderPlace()}setSetting(t,e){this.s.settings[t]=e,t==="sfx"&&this.audio.setVolume(e),t==="music"&&this.audio.setMusic(e),t==="quality"&&(this.save(),this.ui.toast("Graphics change applies after a reload","gold")),this.save()}reset(){this.platform.save(ga,"");try{localStorage.removeItem(ga)}catch{}location.reload()}}new q_().boot().catch(i=>{console.error(i);const t=document.getElementById("load");t&&(t.innerHTML='<div style="text-align:center;padding:20px"><div class="logo">STARWARD</div><p>Your device could not start WebGL. Try another browser.</p></div>')});
