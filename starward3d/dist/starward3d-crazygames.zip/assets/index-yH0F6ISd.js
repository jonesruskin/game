(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const r of document.querySelectorAll('link[rel="modulepreload"]'))n(r);new MutationObserver(r=>{for(const s of r)if(s.type==="childList")for(const a of s.addedNodes)a.tagName==="LINK"&&a.rel==="modulepreload"&&n(a)}).observe(document,{childList:!0,subtree:!0});function t(r){const s={};return r.integrity&&(s.integrity=r.integrity),r.referrerPolicy&&(s.referrerPolicy=r.referrerPolicy),r.crossOrigin==="use-credentials"?s.credentials="include":r.crossOrigin==="anonymous"?s.credentials="omit":s.credentials="same-origin",s}function n(r){if(r.ep)return;r.ep=!0;const s=t(r);fetch(r.href,s)}})();const Kl={save(i,e){try{localStorage.setItem(i,e)}catch{}},load(i){try{return localStorage.getItem(i)}catch{return null}}};let on=null,Jr=!1;const zn=()=>!!on,od={name:"crazygames",adsAvailable:!1,onMute:null,async init(){const i=window.CrazyGames&&window.CrazyGames.SDK;if(i)try{if(await i.init(),i.environment&&i.environment!=="disabled"){on=i,this.adsAvailable=!0;try{i.game.addSettingsChangeListener(e=>this.onMute&&this.onMute(!!(e&&e.muteAudio)))}catch{}}}catch(e){console.warn("CrazyGames SDK init failed; running standalone",e),on=null}},loadingStart(){try{zn()&&on.game.loadingStart()}catch{}},loadingStop(){try{zn()&&on.game.loadingStop()}catch{}},gameplayStart(){if(!Jr){Jr=!0;try{zn()&&on.game.gameplayStart()}catch{}}},gameplayStop(){if(Jr){Jr=!1;try{zn()&&on.game.gameplayStop()}catch{}}},happytime(){try{zn()&&on.game.happytime()}catch{}},midgame(i){return Zl("midgame",i)},rewarded(i){return Zl("rewarded",i)},save(i,e){Kl.save(i,e);try{zn()&&on.data.setItem(i,e)}catch{}},load(i){let e=null;try{zn()&&(e=on.data.getItem(i))}catch{e=null}return e||Kl.load(i)},muted(){try{return zn()&&!!on.game.settings.muteAudio}catch{return!1}},notify(){},cancelNotify(){}};function Zl(i,e){return new Promise(t=>{if(!zn())return t(!1);try{on.ad.requestAd(i,{adStarted:()=>e&&e(),adFinished:()=>t(!0),adError:()=>t(!1)})}catch{t(!1)}})}const vi=["moon","mars","ceres","titan"],rt={hq:{name:"Mission Control",fp:[5,5],bases:["earth"],unique:!0,command:!0,max:20,cat:"core",cost:{credits:[400,2.1],metal:[500,2.1]},time:[-6,13,"ln"],prod:{credits:[500,1.2],science:[30,1.2]},cap:{credits:[8e3,1.55],metal:[6e3,1.55],fuel:[3e3,1.55],science:[2500,1.55]},gen:[12,1.2],desc:"The heart of the programme. Raising it expands the spaceport, allows higher building levels and adds construction drones at levels 5, 10 and 15."},research:{name:"Research Center",fp:[4,4],bases:["earth"],unique:!0,max:25,cat:"science",cost:{credits:[250,1.84],metal:[300,1.84]},time:[2,2],prod:{science:[150,1.24]},cap:{science:[2e3,1.5]},draw:[4,1.14],desc:"Laboratories, wind tunnels and clean rooms. Produces science and runs research projects."},university:{name:"University Campus",fp:[4,4],bases:["earth"],unique:!0,max:20,cat:"science",req:{hq:3},cost:{credits:[1200,1.84],metal:[1400,1.84]},time:[5,2],prod:{science:[90,1.24]},draw:[3,1.14],speed:.04,desc:"Trains the next generation of engineers. Each level speeds up all research by 4% and adds science."},mine:{name:"Metal Mine",fp:[3,3],bases:["earth"],max:25,cat:"production",count:[1,2,3,3,4,4,5,5,6,6],collect:!0,cost:{credits:[120,1.74],metal:[80,1.74]},time:[1,2],prod:{metal:[900,1.24]},draw:[2,1.14],desc:"Open-pit mining and smelting. Metal piles up at the mine until you collect it."},refinery:{name:"Fuel Refinery",fp:[3,3],bases:["earth"],max:25,cat:"production",count:[1,1,2,2,3,3,4,4,5,5],req:{hq:2},collect:!0,cost:{credits:[160,1.74],metal:[220,1.74]},time:[1.5,2],prod:{fuel:[450,1.24]},draw:[3,1.14],desc:"Cracks hydrocarbons and liquefies hydrogen and oxygen into rocket propellant."},office:{name:"Agency Office",fp:[3,3],bases:["earth"],max:25,cat:"production",count:[1,1,2,2,2,3,3,3,4,4],collect:!0,cost:{credits:[80,1.72],metal:[150,1.72]},time:[1,2],prod:{credits:[1100,1.24]},draw:[2,1.14],desc:"Public relations, contracts and grants: the money that keeps rockets flying."},solar:{name:"Solar Farm",fp:[3,3],bases:["earth"],max:25,cat:"power",count:[2,2,3,3,4,4,5,5,6,6],cost:{credits:[90,1.72],metal:[140,1.72]},time:[.5,1.95],gen:[12,1.24],desc:"Fields of photovoltaic panels. Clean, quiet power."},fission:{name:"Fission Plant",fp:[4,4],bases:["earth"],max:20,cat:"power",count:[0,0,1,1,1,2,2,2,3,3],req:{tech:"fission"},cost:{credits:[2500,1.82],metal:[3500,1.82]},time:[6,1.95],gen:[70,1.27],desc:"A pressurised-water reactor. Dense, reliable power for a growing programme."},depot:{name:"Logistics Depot",fp:[3,3],bases:["earth"],max:25,cat:"storage",count:[1,1,1,2,2,2,3,3,3,4],cost:{credits:[180,1.78],metal:[280,1.78]},time:[1.5,2],cap:{credits:[5e3,1.48],metal:[6e3,1.48],fuel:[3500,1.48],science:[1500,1.48],rare:[800,1.48],he3:[300,1.48]},draw:[1,1.1],desc:"Warehouses, tank farms and secure data vaults. Raises storage for every basic resource."},launch:{name:"Launch Complex",fp:[6,6],bases:["earth"],unique:!0,max:20,cat:"spaceflight",req:{tech:"rocketry"},cost:{credits:[1100,1.97],metal:[1600,1.97],fuel:[300,1.97]},time:[5,2.1],draw:[5,1.18],desc:"Pad, service tower and flame trench. Its level sets the largest rocket you can fly."},vab:{name:"Vehicle Assembly",fp:[4,5],bases:["earth"],unique:!0,max:20,cat:"spaceflight",req:{tech:"multistage"},cost:{credits:[1800,1.92],metal:[3e3,1.92]},time:[6,2.1],draw:[6,1.16],desc:"A cathedral of a hangar where rockets are stacked. Higher levels build bigger rockets faster."},tracking:{name:"Tracking Station",fp:[4,4],bases:["earth"],unique:!0,max:20,cat:"spaceflight",req:{tech:"guidance"},cost:{credits:[900,1.87],metal:[1100,1.87]},time:[5.5,2],prod:{science:[60,1.224]},draw:[4,1.15],desc:"Giant dish antennas that talk to spacecraft. Raises mission success and earns science from telemetry."},academy:{name:"Astronaut Academy",fp:[4,4],bases:["earth"],unique:!0,max:20,cat:"spaceflight",req:{tech:"lifeSupport"},cost:{credits:[3e3,1.87],metal:[3500,1.87]},time:[6.5,2],prod:{science:[40,1.224]},draw:[4,1.15],desc:"Centrifuges, pools and simulators. Crewed missions need graduates; each level makes them 1% safer."},hub:{name:"Colony Hub",fp:[5,5],bases:vi,unique:!0,command:!0,max:20,cat:"core",cost:{credits:[6e4,2.05],metal:[8e4,2.05],fuel:[2e4,2.05]},time:[7.5,9.3,"ln"],prod:{science:[200,1.2]},cap:{he3:[600,1.55],metal:[2e4,1.5],fuel:[15e3,1.5],rare:[500,1.5]},gen:[40,1.2],house:[20,1.22],desc:"Command, life support and the airlock everyone passes through. Raising it expands the colony and allows higher building levels."},regolith:{name:"Regolith Mine",fp:[3,3],bases:["moon","mars","ceres"],jobs:[6,1.08],max:25,cat:"production",count:[2,2,3,3,4,4,5,5,6,6],collect:!0,cost:{credits:[18e3,1.74],metal:[12e3,1.74]},time:[8,1.95],prod:{metal:[3200,1.24]},draw:[6,1.14],desc:"Robotic excavators scrape the soil; furnaces pull out iron, aluminium and titanium."},ice:{name:"Ice Mine",fp:[3,3],bases:vi,jobs:[6,1.08],max:25,cat:"production",count:[1,1,2,2,2,3,3,3,4,4],collect:!0,cost:{credits:[22e3,1.74],metal:[16e3,1.74]},time:[8.5,1.95],prod:{fuel:[2200,1.24]},draw:[7,1.14],desc:"Buried ice, melted and split into hydrogen and oxygen. Water for the colonists, fuel made outside Earth's deep gravity well."},he3x:{name:"He-3 Extractor",fp:[3,3],bases:["moon"],jobs:[8,1.08],max:25,cat:"production",count:[1,1,1,2,2,2,3,3,3,4],req:{tech:"he3Mining"},cost:{credits:[6e4,1.77],metal:[5e4,1.77],fuel:[1e4,1.72]},time:[10,1.95],prod:{he3:[24,1.24]},draw:[12,1.15],desc:"Roasts regolith to release helium-3, a fusion fuel almost absent on Earth."},lsolar:{name:"Solar Array",fp:[3,3],bases:["moon","mars","ceres"],jobs:[2,1.05],max:25,cat:"power",count:[2,2,3,3,4,4,5,5,6,6],cost:{credits:[12e3,1.72],metal:[14e3,1.72]},time:[7.5,1.95],gen:[45,1.24],desc:"Ridge-top photovoltaic arrays. Superb on the Moon; weaker on Mars (43% of Earth's sunlight) and Ceres (13%)."},dome:{name:"Habitat Dome",fp:[4,4],bases:vi,house:[40,1.22],max:20,cat:"core",count:[1,1,1,2,2,2,3,3,3,4],req:{tech:"lunarHabitats"},cost:{credits:[4e4,1.77],metal:[45e3,1.77]},time:[11,1.95],prod:{credits:[2600,1.24]},cap:{he3:[300,1.45]},draw:[6,1.14],desc:"Homes under glass for colonists, and a garden the tourists pay well to see. Houses colonists."},llab:{name:"Colony Laboratory",fp:[4,4],bases:vi,jobs:[10,1.08],unique:!0,max:20,cat:"science",req:{tech:"lunarHabitats"},cost:{credits:[5e4,1.82],metal:[4e4,1.82]},time:[11.5,1.95],prod:{science:[900,1.24]},draw:[8,1.14],speed:.03,desc:"Field science where the samples are: vacuum labs, radio telescopes, geology. Science, plus 3% faster research per level."},massDriver:{name:"Mass Driver",fp:[2,7],bases:["moon"],jobs:[8,1.08],unique:!0,max:15,cat:"spaceflight",req:{tech:"massDrivers"},cost:{credits:[12e4,1.87],metal:[15e4,1.87]},time:[13,1.95],prod:{credits:[4e3,1.24]},draw:[25,1.16],fuelCut:.03,desc:"A kilometre of magnetic rail. Sells lunar metal to orbit and cuts mission fuel by 3% per level."},greenhouse:{name:"Greenhouse",fp:[4,3],bases:vi,max:20,cat:"core",count:[1,1,2,2,2,3,3,3,4,4],req:{tech:"spaceAgriculture"},jobs:[4,1.06],cost:{credits:[9e4,1.77],metal:[7e4,1.77]},time:[11,1.95],grow:[1.5,1.2],draw:[8,1.14],desc:"Hydroponic racks under LED light. A colony that feeds itself grows: more colonists every hour."},reactor:{name:"Colony Reactor",fp:[3,3],bases:vi,max:25,cat:"power",count:[1,1,2,2,3,3,4,4,5,5],req:{tech:"marsDirect"},jobs:[3,1.05],cost:{credits:[8e4,1.74],metal:[9e4,1.74]},time:[10,1.95],gen:[90,1.24],desc:"A compact fission reactor buried in the regolith. Steady power through dust storms, long nights and Titan's gloom."},terraformer:{name:"Atmosphere Processor",fp:[4,4],bases:["mars"],unique:!0,max:20,cat:"science",req:{tech:"planetaryEngineering"},jobs:[12,1.08],cost:{credits:[4e5,1.8],metal:[35e4,1.8]},time:[13,1.95],prod:{science:[3e3,1.24]},draw:[30,1.16],terra:.04,desc:"Cracks carbonates and vents greenhouse gases into the sky. Terraforming stages run 4% faster per level."},beltControl:{name:"Mining Control",fp:[4,4],bases:["ceres"],unique:!0,max:20,cat:"production",req:{tech:"beltSettlement"},jobs:[10,1.08],cost:{credits:[5e5,1.8],metal:[3e5,1.8]},time:[12,1.95],prod:{rare:[10,1.24]},cap:{rare:[2e3,1.5]},draw:[20,1.15],claims:.05,desc:"Traffic control for a thousand mining tugs. Every asteroid claim produces 5% more per level; refines rare elements."},methane:{name:"Hydrocarbon Refinery",fp:[3,3],bases:["titan"],max:25,cat:"production",count:[1,2,2,3,3,4,4,5,5,6],req:{tech:"cryoHabitats"},jobs:[8,1.08],collect:!0,cost:{credits:[3e5,1.74],metal:[25e4,1.74]},time:[11,1.95],prod:{fuel:[6e3,1.24]},draw:[18,1.15],desc:"Pumps liquid methane straight out of Kraken Mare. Titan sits on more hydrocarbons than all of Earth's oil and gas."},fusion:{name:"Fusion Plant",fp:[4,4],bases:["earth",...vi],max:25,cat:"power",count:[1,1,1,2,2,2,2,3,3,3,3,3,3,4,4,4],req:{tech:"fusionPower"},jobs:[6,1.06],cost:{credits:[6e5,1.74],metal:[5e5,1.74],he3:[150,1.6]},time:[12,1.95],gen:[700,1.24],desc:"A tokamak burning deuterium and helium-3. Enormous, clean power, if you can keep it fuelled with He-3."},elevator:{name:"Space Elevator",fp:[4,4],bases:["earth"],unique:!0,max:15,cat:"spaceflight",req:{tech:"spaceElevator"},cost:{credits:[5e6,1.8],metal:[4e6,1.8],rare:[3e3,1.6]},time:[16,1.95],prod:{credits:[2e4,1.24]},draw:[60,1.16],liftCut:.03,desc:"A ribbon from the equator to geostationary orbit. Climbers carry cargo up for the price of electricity: rockets and missions cost 3% less per level."},casimir:{name:"Casimir Foundry",fp:[4,4],bases:["earth"],unique:!0,max:20,cat:"science",req:{tech:"casimirEffect"},cost:{credits:[3e7,1.7],metal:[2e7,1.7],rare:[5e3,1.6]},time:[17,1.8],prod:{exotic:[3,1.24]},cap:{exotic:[300,1.5]},draw:[80,1.16],desc:"Stacks of nanometre-gap plates in a vacuum chamber, squeezing out exotic matter a microgram at a time."},xenolab:{name:"Xenology Institute",fp:[4,4],bases:["earth"],unique:!0,max:20,cat:"science",req:{tech:"xenolinguistics"},cost:{credits:[4e7,1.7],metal:[25e6,1.7]},time:[17,1.8],prod:{xeno:[25,1.24],influence:[8,1.22]},cap:{xeno:[1e4,1.5],influence:[4e3,1.5]},draw:[60,1.15],desc:"Linguists, xenobiologists and diplomats under one roof. Makes xenodata and influence; each level deciphers languages 5% faster."},antimatter:{name:"Antimatter Factory",fp:[4,4],bases:["earth","mars","ceres","titan"],max:20,cat:"production",count:[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,2,2,3],req:{tech:"antimatterProduction"},cost:{credits:[6e9,1.6],metal:[5e9,1.6],exotic:[2e3,1.5]},time:[18,1.7],prod:{antimatter:[6,1.24]},cap:{antimatter:[1500,1.5]},draw:[400,1.15],jobs:[20,1.06],desc:"A ring accelerator that smashes protons into antiprotons and traps them in magnetic bottles. Fuel for intergalactic drives."}},bh=i=>3+.35*(i-1),Sh=(i,e)=>Math.min(i.max,i.command?i.max:e*2),wh=(i,e)=>i.unique?1:i.count?i.count[Math.min(i.count.length-1,e-1)]:1,ma=(i,e,t)=>i.cap&&i.cap[e]?i.cap[e][0]*Math.pow(i.cap[e][1],Math.min(i.max,Math.max(1,t))-1):0;function ld(i,e){return ma(rt.hq,e,i)+ma(rt.depot,e,2*i-4)+(e==="science"?ma(rt.research,e,2*i-4):0)}const Ka=(i,e,t)=>{const n=ld(e,t);return n>0?Math.min(i,Math.floor(n*.85/100)*100):i},cd=(i,e)=>{const t=rt[i];return i==="hq"?Math.max(1,e-1):i==="hub"?e+7:!t.bases.includes("earth")&&!t.bases.includes("moon")?Math.ceil(e/2)+10:t.bases.includes("earth")?Math.max(1,Math.ceil(e/2)):Math.ceil(e/2)+7};function hd(i,e,t){const n=[],r=2*e-4;if(i==="hq"&&(e>=3&&n.push(["research",r],["depot",r]),e>=4&&n.push(["mine",r],["office",r]),e>=5&&n.push(["launch",r-2],["refinery",r-2]),e>=6&&n.push(["vab",r-4],["solar",r]),e>=7&&n.push(["tracking",r-4]),e>=8&&n.push(["academy",r-6])),i==="hub"&&(!t||t==="moon"))e>=2&&n.push(["regolith",2*e-2],["lsolar",2*e-2]),e>=3&&n.push(["ice",2*e-3],["he3x",2*e-4]),e>=4&&n.push(["dome",2*e-6],["llab",2*e-6]);else if(i==="hub"){const s={mars:"regolith",ceres:"ice",titan:"ice"}[t||"mars"]||"regolith";e>=2&&n.push([s,2*e-2],["dome",2*e-2]),e>=3&&n.push(["reactor",2*e-3],["greenhouse",2*e-4]),e>=4&&n.push(["llab",2*e-6])}return n.filter(([,s])=>s>0).map(([s,a])=>[s,Math.min(a,rt[s].max)])}const ud=i=>2+(i>=5?1:0)+(i>=10?1:0)+(i>=15?1:0),Jl={core:"Command",production:"Production",power:"Power",storage:"Storage",science:"Science",spaceflight:"Spaceflight",defense:"Defence",robots:"Robots",decor:"Decor"},ar=52,dd=(i,e)=>i==="earth"?Math.min(ar,24+2*(e-1)):Math.min(40,18+2*(e-1)),Ql="starward3d_v2",Eh=2,En=ar/2;function Za(i=Date.now()){let e=0;const t=(n,r,s,a=1,o=0)=>({id:"i"+(e++).toString(36),b:n,x:r,z:s,r:0,lvl:a,held:o});return{v:Eh,created:i,last:i,seq:100,name:"Cape Horizon",res:{credits:1500,metal:1800,fuel:300,science:60,dm:30},bases:{earth:{body:"earth",name:"Cape Horizon",items:[t("hq",En-2,En-2),t("mine",En-9,En-6,1,400),t("solar",En-9,En-1),t("office",En+5,En-6,1,600),t("depot",En+5,En-1)]}},at:"earth",jobs:[],tech:{},flags:{},obj:{i:0,claimed:{}},stats:{built:0,upgrades:0,researched:0,dmSpent:0,collected:0,playS:0,sessions:0},settings:{sfx:.8,music:.45,quality:"auto"},tut:0,kMax:0}}function fd(i){const e=Za(i.created||Date.now()),t=i;for(const n in e)t[n]===void 0&&(t[n]=e[n]);for(const n in e.stats)i.stats[n]===void 0&&(i.stats[n]=e.stats[n]);for(const n in e.settings)i.settings[n]===void 0&&(i.settings[n]=e.settings[n]);return i.v=Eh,i}const qs=(i,e="j")=>e+(i.seq++).toString(36),ln=(i,e=0,t=1)=>i<e?e:i>t?t:i,jl=["","K","M","B","T","Qa","Qi","Sx","Sp","Oc","No","Dc"];function Je(i,e=1){if(i===1/0)return"∞";if(!isFinite(i))return"–";const t=Math.abs(i),n=i<0?"-":"";if(t<1e3)return n+(t<10&&t%1?t.toFixed(1).replace(/\.0$/,""):Math.floor(t).toString());const r=Math.min(jl.length-1,Math.floor(Math.log10(t)/3)),s=t/Math.pow(1e3,r);return n+(s>=100?s.toFixed(0):s>=10?s.toFixed(e).replace(/\.0$/,""):s.toFixed(e+1).replace(/\.?0+$/,""))+jl[r]}function ti(i){if(i=Math.max(0,Math.ceil(i)),i<60)return i+"s";const e=Math.floor(i/86400),t=Math.floor(i%86400/3600),n=Math.floor(i%3600/60),r=i%60;return e?`${e}d ${t}h`:t?`${t}h ${n}m`:r&&n<10?`${n}m ${r}s`:`${n}m`}const Th=(i,e,t)=>i*Math.pow(e,t-1),Di=[5,15,30,60,120,300,600,1200,1800,2700,3600,5400,7200,10800,14400,21600,28800,36e3,43200,57600,72e3,86400,108e3,129600,172800,216e3,259200,302400,345600,432e3,518400,604800,691200,777600,864e3,1036800,1209600];function Ah(i){const e=Di.length-1;if(i<=0)return Di[0];if(i>=e)return Di[e];const t=Math.floor(i),n=i-t;return Di[t]*Math.pow(Di[t+1]/Di[t],n)}const pd=(i,e)=>Ah(i[2]==="ln"?i[0]+i[1]*Math.log(e):i[0]+i[1]*Math.pow(e-1,.85)),md=i=>{if(i<100)return Math.round(i);const e=Math.pow(10,Math.floor(Math.log10(i))-1);return Math.round(i/e)*e};function Qo(i){let e=i>>>0;return()=>{e=e+1831565813|0;let t=Math.imul(e^e>>>15,1|e);return t=t+Math.imul(t^t>>>7,61|t)^t,((t^t>>>14)>>>0)/4294967296}}const Ke=i=>String(i).replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),st=(i,e=document)=>e.querySelector(i),Qr=(i,e=document)=>Array.from(e.querySelectorAll(i)),ga={rocketry:{name:"Rocketry",color:"#ff8a5b"},engineering:{name:"Engineering",color:"#b8c4d6"},energy:{name:"Energy",color:"#ffd166"},computing:{name:"Computing",color:"#6ee7ff"},economy:{name:"Economy",color:"#7cf29a"},life:{name:"Life Sciences",color:"#ff9bd2"},astro:{name:"Astronomy",color:"#b892ff"},planetary:{name:"Planetary",color:"#ff7a59"},interstellar:{name:"Interstellar",color:"#ff6bd6"}},pt={rocketry:{name:"Rocketry Fundamentals",branch:"rocketry",tier:1,req:[],effect:{},unlocks:"Launch Complex",desc:"Newton's third law, thrust, specific impulse. The first step off the planet."},liquidProp:{name:"Liquid Propellants",branch:"rocketry",tier:1,req:["rocketry"],effect:{mult:{fuel:.15}},desc:"Kerosene and liquid oxygen: throttleable, restartable, powerful. Fuel output +15%."},multistage:{name:"Multistage Rockets",branch:"rocketry",tier:2,req:["liquidProp"],effect:{},unlocks:"Vehicle Assembly",desc:"Drop the empty tanks on the way up. The trick that makes orbit possible."},guidance:{name:"Inertial Guidance",branch:"rocketry",tier:2,req:["rocketry","computing"],effect:{},unlocks:"Tracking Station",desc:"Gyroscopes and accelerometers that know where the rocket is going."},orbital:{name:"Orbital Mechanics",branch:"rocketry",tier:3,req:["multistage","guidance"],effect:{flag:"orbit"},unlocks:"Satellite launches",desc:"Kepler, Hohmann and the art of falling around the Earth."},cryo:{name:"Cryogenic Engines",branch:"rocketry",tier:3,req:["multistage"],effect:{mult:{fuel:.1},flag:"cryo"},desc:"Liquid hydrogen at −253 °C: the highest-efficiency chemical rocket. Fuel output +10%."},crewed:{name:"Human Spaceflight",branch:"rocketry",tier:4,req:["orbital","lifeSupport"],effect:{flag:"crewed"},unlocks:"Crewed missions",desc:"Capsules, launch-escape towers and splashdowns. People in space."},reusable:{name:"Reusable Boosters",branch:"rocketry",tier:5,req:["crewed","simulation"],effect:{flag:"reusable"},desc:"Land the first stage and fly it again. Launch costs collapse."},heavy:{name:"Heavy Lift Vehicles",branch:"rocketry",tier:5,req:["crewed","alloys"],effect:{flag:"heavy"},desc:"Super-heavy rockets for the Moon and beyond."},automation:{name:"Industrial Automation",branch:"engineering",tier:1,req:[],effect:{mult:{metal:.15}},desc:"Conveyor belts, robots and process control. Metal output +15%."},alloys:{name:"Aerospace Alloys",branch:"engineering",tier:2,req:["automation"],effect:{mult:{metal:.15}},desc:"Aluminium-lithium and titanium alloys: light and strong. Metal output +15%."},modular:{name:"Modular Construction",branch:"engineering",tier:2,req:["automation"],effect:{buildTime:.08},desc:"Prefabricated sections assembled on site. Construction 8% faster."},robotics:{name:"Construction Robotics",branch:"engineering",tier:3,req:["modular","microchips"],effect:{crews:1},desc:"Tireless robotic builders join your crews. +1 engineering crew."},composites:{name:"Carbon Composites",branch:"engineering",tier:3,req:["alloys"],effect:{costs:.06},desc:"Carbon fibre everything. Build costs −6%."},additive:{name:"Additive Manufacturing",branch:"engineering",tier:4,req:["composites","simulation"],effect:{buildTime:.1,costs:.05},desc:"3D-printed engines and structures. Construction 10% faster, costs −5%."},photovoltaics:{name:"Advanced Photovoltaics",branch:"energy",tier:1,req:[],effect:{gen:.15},desc:"Multi-junction solar cells. Energy generation +15%."},batteries:{name:"Grid Storage",branch:"energy",tier:2,req:["photovoltaics"],effect:{cap:.12},desc:"Lithium battery farms smooth the grid and let you stockpile more. Storage +12%."},grid:{name:"Smart Grid",branch:"energy",tier:2,req:["photovoltaics","computing"],effect:{gen:.12},desc:"Software-balanced power distribution. Energy generation +12%."},fission:{name:"Nuclear Fission",branch:"energy",tier:3,req:["grid"],effect:{},unlocks:"Fission Plant",desc:"Split the atom, boil the water, spin the turbine."},breeder:{name:"Breeder Reactors",branch:"energy",tier:4,req:["fission"],effect:{gen:.2},desc:"Reactors that make more fuel than they burn. Energy generation +20%."},computing:{name:"Computer Science",branch:"computing",tier:1,req:[],effect:{researchTime:.05,mult:{science:.1}},desc:"Algorithms, compilers, numerical methods. Research 5% faster, science +10%."},microchips:{name:"Microprocessors",branch:"computing",tier:2,req:["computing"],effect:{mult:{science:.15}},desc:"A computer on a chip. Science +15%."},networks:{name:"Global Networks",branch:"computing",tier:3,req:["microchips"],effect:{slots:1},desc:"Laboratories worldwide share data in real time. +1 parallel research project."},simulation:{name:"Simulation & Modelling",branch:"computing",tier:3,req:["microchips"],effect:{buildTime:.05,mult:{science:.1}},desc:"Test it in silicon before steel. Construction 5% faster, science +10%."},ai:{name:"Artificial Intelligence",branch:"computing",tier:5,req:["simulation","networks"],effect:{crews:1,researchTime:.1},desc:"Machine minds plan, design and supervise. +1 crew, research 10% faster."},outreach:{name:"Public Outreach",branch:"economy",tier:1,req:[],effect:{mult:{credits:.15}},desc:"Launch broadcasts and school visits win hearts and budgets. Credits +15%."},contracts:{name:"Commercial Contracts",branch:"economy",tier:2,req:["outreach"],effect:{mult:{credits:.2}},desc:"Sell launches, data and patents. Credits +20%."},logistics:{name:"Supply Chains",branch:"economy",tier:2,req:["outreach"],effect:{cap:.15},desc:"Just-in-time logistics. Storage +15%."},investors:{name:"Private Investment",branch:"economy",tier:3,req:["contracts"],effect:{mult:{credits:.25}},desc:"Venture capital discovers space. Credits +25%."},medicine:{name:"Space Medicine",branch:"life",tier:2,req:["computing"],effect:{},desc:"What weightlessness does to bone, muscle and mind."},lifeSupport:{name:"Life Support Systems",branch:"life",tier:3,req:["medicine"],effect:{},desc:"Scrubbers, water recycling and oxygen generation for crewed vehicles."},radioAstro:{name:"Radio Astronomy",branch:"astro",tier:1,req:[],effect:{mult:{science:.1}},desc:"Listen to the universe in radio waves. Science +10%."},telescopes:{name:"Space Telescopes",branch:"astro",tier:4,req:["orbital","radioAstro"],effect:{flag:"telescopes"},unlocks:"Telescope satellites",desc:"Above the atmosphere the sky is perfectly sharp."},satComms:{name:"Communication Satellites",branch:"astro",tier:3,req:["orbital"],effect:{},unlocks:"Comms satellites",desc:"Arthur C. Clarke's geostationary relays: a satellite that hangs over one spot of the Earth."},remoteSensing:{name:"Remote Sensing",branch:"astro",tier:3,req:["orbital"],effect:{},unlocks:"Observation & weather satellites",desc:"Multispectral cameras and radar that read the planet from above."},orbitalOps:{name:"Orbital Operations",branch:"rocketry",tier:4,req:["orbital","networks"],effect:{flag:"orbitalOps"},desc:"Traffic control for crowded orbits. +1 low-orbit and +1 geostationary slot."},gps:{name:"Satellite Navigation",branch:"astro",tier:4,req:["satComms","networks"],effect:{},unlocks:"Navigation satellites",desc:"Atomic clocks in orbit. Know where everything is, to the centimetre."},deepSpace:{name:"Deep Space Navigation",branch:"rocketry",tier:4,req:["orbital","guidance"],effect:{},unlocks:"Lunar probes, deep space relays",desc:"Trajectory design and the Deep Space Network: reaching beyond Earth orbit."},spaceStation:{name:"Orbital Assembly",branch:"engineering",tier:5,req:["crewed","additive"],effect:{},unlocks:"Space station",desc:"Dock modules in orbit and bolt them together: a permanent home in space."},closedLoop:{name:"Closed-Loop Ecology",branch:"life",tier:5,req:["lifeSupport","spaceStation"],effect:{},unlocks:"Habitat modules",desc:"Recycle every drop of water and breath of air. Long stays become possible."},constellations:{name:"Satellite Constellations",branch:"astro",tier:5,req:["orbitalOps","reusable"],effect:{flag:"constellations"},desc:"Cheap mass-produced satellites in swarms. +2 low-orbit slots."},lunarLanders:{name:"Lunar Landers",branch:"rocketry",tier:6,req:["deepSpace","heavy"],effect:{},unlocks:"Crewed lunar landing",desc:"Descent engines, landing legs and the nerve to fly them."},spacePower:{name:"Space-Based Solar Power",branch:"energy",tier:6,req:["spaceStation","breeder"],effect:{},unlocks:"Solar power satellites",desc:"Collect sunlight where it never sets and beam it home."},isru:{name:"In-Situ Resource Utilisation",branch:"engineering",tier:6,req:["lunarLanders","closedLoop"],effect:{},unlocks:"Lunar outpost",desc:"Live off the land: oxygen from rock, water from ice, metal from regolith."},he3Mining:{name:"Helium-3 Extraction",branch:"energy",tier:7,req:["isru"],effect:{flag:"he3"},unlocks:"He-3 Extractor",desc:"Heat tonnes of regolith to release a few grams of the perfect fusion fuel."},lunarHabitats:{name:"Lunar Habitats",branch:"life",tier:7,req:["isru"],effect:{},unlocks:"Habitat Dome, Lunar Lab",desc:"Regolith-shielded domes where people can live for years."},massDrivers:{name:"Mass Drivers",branch:"engineering",tier:7,req:["isru","spacePower"],effect:{},unlocks:"Mass Driver",desc:"Electromagnetic rails that fling cargo off the Moon without a drop of fuel."},lowGravity:{name:"Low-Gravity Industry",branch:"engineering",tier:7,req:["isru"],effect:{mult:{metal:.15}},desc:"Smelt, cast and print in one-sixth gravity. Metal output +15%."},planetaryProbes:{name:"Planetary Probes",branch:"planetary",tier:7,req:["deepSpace","telescopes"],effect:{},unlocks:"Survey probes to any world",desc:"Radioisotope power, autonomous navigation and patience: robotic eyes on every planet."},nuclearThermal:{name:"Nuclear Thermal Propulsion",branch:"rocketry",tier:7,req:["heavy","fission"],effect:{},unlocks:"Hermes transfer ships",desc:"A reactor heats hydrogen to 2,500 °C. Twice the efficiency of chemistry: the inner Solar System opens up."},orbitalShipyard:{name:"Orbital Shipyards",branch:"engineering",tier:7,req:["spaceStation","robotics"],effect:{},unlocks:"Shipyard station module",desc:"Build ships too big to launch, in orbit where they will fly."},marsDirect:{name:"Mars Direct",branch:"planetary",tier:8,req:["nuclearThermal","isru"],effect:{},unlocks:"Mars colony, colony reactors, Phobos Depot",desc:"Make the return fuel on Mars from its own air. Robert Zubrin's plan, finally flown."},asteroidMining:{name:"Asteroid Mining",branch:"planetary",tier:8,req:["nuclearThermal","robotics"],effect:{},unlocks:"Mining claims in the belt",desc:"Grapple, bag and digest a mountain. One metal asteroid outweighs every mine on Earth."},spaceAgriculture:{name:"Space Agriculture",branch:"life",tier:8,req:["closedLoop","lunarHabitats"],effect:{},unlocks:"Greenhouses (colonists grow)",desc:"Hydroponics, LED light and Martian soil washed of perchlorates. Colonies that feed themselves can grow."},fusionPower:{name:"Fusion Power",branch:"energy",tier:8,req:["he3Mining","breeder"],effect:{gen:.1},unlocks:"Fusion Plant",desc:"Deuterium–helium-3 fusion: almost no neutrons, almost no waste, power without end. Energy +10%."},aerostats:{name:"Aerostat Habitats",branch:"planetary",tier:8,req:["planetaryProbes","composites"],effect:{},unlocks:"Venus cloud city",desc:"Breathable air is a lifting gas in Venus's heavy CO₂. A city can simply float."},colonyShips:{name:"Colony Ships",branch:"life",tier:9,req:["marsDirect","spaceAgriculture"],effect:{},unlocks:"Ares colony transports",desc:"Spin gravity, radiation shelters and room for families: mass emigration begins."},beltSettlement:{name:"Belt Settlement",branch:"planetary",tier:10,req:["asteroidMining","colonyShips"],effect:{},unlocks:"Ceres colony, Mining Control",desc:"Ceres has water, gravity enough to stand in, and every asteroid within reach. The belt gets a capital."},planetaryEngineering:{name:"Planetary Engineering",branch:"planetary",tier:9,req:["marsDirect","spacePower"],effect:{},unlocks:"Terraforming stages 1-2, Atmosphere Processor",desc:"Change a whole world's climate on purpose. Start with mirrors and greenhouse gases."},solarFurnace:{name:"Helios Concentrators",branch:"energy",tier:9,req:["spacePower","planetaryProbes"],effect:{gen:.05},unlocks:"Mercury Helios Array",desc:"Mercury gets seven times Earth's sunlight. Build where the light is. Energy +5%."},radiationShielding:{name:"Radiation Shielding",branch:"life",tier:10,req:["colonyShips","medicine"],effect:{},unlocks:"Jovian moon outposts",desc:"Water walls, magnetic bubbles and radiation-hardened medicine for Jupiter's killing belts."},fusionDrive:{name:"Fusion Drive",branch:"rocketry",tier:10,req:["fusionPower","nuclearThermal"],effect:{},unlocks:"Daedalus torch ships",desc:"Fusion exhaust at thousands of kilometres per second: thrust the whole way, Jupiter in hours."},gasGiantScoops:{name:"Atmospheric Scoops",branch:"energy",tier:11,req:["fusionDrive","he3Mining"],effect:{},unlocks:"He-3 scoops on Jupiter and Saturn, Enceladus",desc:"Dive into a gas giant at 60 km/s, gulp helium-3, climb back out. Repeat forever."},cometCapture:{name:"Comet Capture",branch:"planetary",tier:10,req:["planetaryEngineering","asteroidMining"],effect:{},unlocks:"Terraforming stage 3",desc:"Tiny pushes, applied decades early, steer an ice comet onto a chosen spot on Mars."},magnetosphere:{name:"Planetary Magnetic Shield",branch:"planetary",tier:10,req:["planetaryEngineering","fusionPower"],effect:{},unlocks:"Terraforming stage 4",desc:"A 1-2 tesla dipole at Mars–Sun L1 shades the planet from the solar wind (NASA, 2017)."},xenobiology:{name:"Xenobiology",branch:"life",tier:11,req:["radiationShielding","ai"],effect:{},unlocks:"Europa Deep Probe",desc:"How to recognise life that isn't ours, and how not to kill it by accident."},cryoHabitats:{name:"Cryogenic Habitats",branch:"planetary",tier:11,req:["fusionDrive","beltSettlement"],effect:{},unlocks:"Titan colony, Hydrocarbon Refinery",desc:"Insulated settlements for −180 °C, heated by fusion, under an orange sky."},hydrosphere:{name:"Ocean Engineering",branch:"planetary",tier:11,req:["cometCapture","magnetosphere"],effect:{},unlocks:"Terraforming stage 5",desc:"Melt the permafrost, fill the northern basin: an ocean for Mars."},spaceElevator:{name:"Space Elevator",branch:"engineering",tier:11,req:["alloys","orbitalShipyard","fusionPower"],effect:{},unlocks:"Space Elevator",desc:"A carbon-nanotube ribbon from the equator to geostationary orbit. Climb to space by train."},extremophiles:{name:"Engineered Extremophiles",branch:"life",tier:12,req:["xenobiology","hydrosphere"],effect:{},unlocks:"Terraforming stage 6",desc:"Lichens and algae rewritten to thrive in cold, thin, radiation-soaked air."},advancedFusion:{name:"Antimatter-Catalysed Fusion",branch:"rocketry",tier:12,req:["fusionDrive","cryoHabitats"],effect:{},unlocks:"Odyssey cruisers, the outer planets",desc:"A few micrograms of antiprotons ignite fusion hotter than any magnet can hold."},ecopoiesis:{name:"Ecopoiesis",branch:"life",tier:13,req:["extremophiles"],effect:{},unlocks:"Terraforming stage 7",desc:"Not engineering a planet: gardening one. Forests, soil and a breathable sky."},laserSails:{name:"Laser Light Sails",branch:"interstellar",tier:13,req:["solarFurnace","spaceElevator"],effect:{},unlocks:"Starshot Laser Array (megastructure)",desc:"Gram-scale probes on sails thinner than a soap bubble, pushed by lasers to a fifth of light speed."},exoplanetology:{name:"Exoplanetology",branch:"interstellar",tier:13,req:["planetaryProbes","xenobiology"],effect:{mult:{science:.1}},desc:"Read a world's atmosphere from its starlight. Science +10%."},sleeperShips:{name:"Sleeper Ships",branch:"interstellar",tier:14,req:["advancedFusion","cryoHabitats"],effect:{},unlocks:"Exodus Ark",desc:"Cryogenic suspension for ten thousand. Decades pass in a dreamless night."},starColonies:{name:"Star Colonies",branch:"interstellar",tier:14,req:["exoplanetology","colonyShips"],effect:{},unlocks:"Settling exoplanets (capacity 2)",desc:"Governance, supply and culture across light-years: how to found a world you will never visit."},dysonSwarm:{name:"Dyson Swarm",branch:"energy",tier:14,req:["solarFurnace","spaceElevator"],effect:{},unlocks:"Dyson Swarm (megastructure)",desc:"Disassemble Mercury into a cloud of mirrors and collectors around the Sun."},casimirEffect:{name:"Casimir Engineering",branch:"interstellar",tier:15,req:["laserSails","fusionDrive"],effect:{},unlocks:"Casimir Foundry (exotic matter)",desc:"Plates a few atoms apart squeeze the vacuum itself: negative energy density, bottled."},ramjets:{name:"Bussard Ramjets",branch:"rocketry",tier:15,req:["sleeperShips","gasGiantScoops"],effect:{},unlocks:"Pathfinder ramjets",desc:"Scoop interstellar hydrogen with magnetic fields a thousand kilometres wide and burn it on the fly."},domeWorlds:{name:"Dome Worlds",branch:"interstellar",tier:15,req:["starColonies","extremophiles"],effect:{},unlocks:"Settle hostile worlds, giants and belts (+2 capacity)",desc:"Domes, orbital habitats and mining stations: no world is too hostile to settle."},xenoarchaeology:{name:"Xenoarchaeology",branch:"life",tier:15,req:["exoplanetology","xenobiology"],effect:{mult:{science:.1}},desc:"The study of minds that are not human, from what they leave behind. Science +10%."},interstellarTrade:{name:"Interstellar Commerce",branch:"economy",tier:16,req:["starColonies","domeWorlds"],effect:{mult:{credits:.15}},unlocks:"Star colonies +15% (+2 capacity)",desc:"Light-lag contracts, tachyon-free banking and the first interstellar brands. Credits +15%."},warpTheory:{name:"Warp Field Theory",branch:"interstellar",tier:16,req:["casimirEffect","ramjets"],effect:{},desc:"Alcubierre's metric, made practical: the energy budget falls from a galaxy's worth to a few tonnes of exotic matter."},warpDrive:{name:"Warp Drive",branch:"rocketry",tier:17,req:["warpTheory"],effect:{},unlocks:"Herald warp ships",desc:"Space folds ahead and unfolds behind. Light-years in an afternoon."},wormholeGates:{name:"Wormhole Gates",branch:"interstellar",tier:17,req:["warpTheory","dysonSwarm"],effect:{},unlocks:"Sol Gate and colony gates",desc:"Two throats of a wormhole, held open with exotic matter and towed apart. Step through, arrive light-years away."},contactProtocols:{name:"First Contact Protocols",branch:"life",tier:16,req:["exoplanetology","xenoarchaeology"],effect:{},unlocks:"Meeting alien civilisations",desc:"What to say, what never to say, and who gets to speak for humanity. Written in a hurry."},xenolinguistics:{name:"Xenolinguistics",branch:"computing",tier:17,req:["contactProtocols"],effect:{},unlocks:"Deciphering alien languages, Xenology Institute",desc:"Grammar without grammar, meaning without shared senses. AI linguists and a lot of patience."},xenodiplomacy:{name:"Xenodiplomacy",branch:"economy",tier:18,req:["xenolinguistics","interstellarTrade"],effect:{},unlocks:"Embassies and agreements",desc:"Treaties with minds that do not share our instincts, our senses or our idea of a promise."},upliftEthics:{name:"Uplift Ethics",branch:"life",tier:18,req:["xenolinguistics","extremophiles"],effect:{},unlocks:"Uplifting minor species",desc:"When, if ever, may an elder species accelerate a younger one? The debate ends with a protocol."},navalWarfare:{name:"Naval Warfare",branch:"engineering",tier:18,req:["fusionDrive","ai"],effect:{},unlocks:"Corvettes, frigates, fleet operations",desc:"We never wanted warships. The Swarm did not ask what we wanted."},planetaryDefence:{name:"Planetary Defence",branch:"engineering",tier:19,req:["navalWarfare"],effect:{},unlocks:"Defences and shields for every base and colony",desc:"Laser batteries, missile silos and plasma shields over every world we hold."},guidedOrdnance:{name:"Guided Ordnance",branch:"rocketry",tier:19,req:["navalWarfare"],effect:{},unlocks:"Destroyers",desc:"Missiles that think, swarm and pick out the biggest target."},capitalShips:{name:"Capital Ships",branch:"engineering",tier:20,req:["guidedOrdnance","planetaryDefence"],effect:{},unlocks:"Cruisers and battleships",desc:"Kilometre-long hulls with layered armour and spinal weapons."},swarmTactics:{name:"Swarm Tactics",branch:"computing",tier:20,req:["planetaryDefence","xenolinguistics"],effect:{},unlocks:"+25% damage against the Kr'thul",desc:"We studied how the Swarm thinks. Now we can think one move ahead of it."},carrierWarfare:{name:"Carrier Warfare",branch:"rocketry",tier:21,req:["capitalShips"],effect:{},unlocks:"Carriers",desc:"Motherships launching clouds of autonomous missile drones."},antimatterProduction:{name:"Antimatter Production",branch:"energy",tier:21,req:["casimirEffect","dysonSwarm"],effect:{},unlocks:"Antimatter Factory",desc:"Particle accelerators fed by the Dyson Swarm, minting antiprotons by the gram."},relayNetwork:{name:"The Relay Network",branch:"interstellar",tier:21,req:["xenolinguistics","wormholeGates"],effect:{},unlocks:"Rebuilding the Hollow relays",desc:"The Hollow left relays on the paths between galaxies. We have learned how to wake them."},matrioshkaBrains:{name:"Matrioshka Brains",branch:"computing",tier:22,req:["antimatterProduction","swarmTactics"],effect:{},unlocks:"Matrioshka Brain (megastructure)",desc:"Nested shells of computers around a star: a mind the size of a solar system."},intergalacticDrive:{name:"Intergalactic Drive",branch:"rocketry",tier:22,req:["relayNetwork","antimatterProduction"],effect:{},unlocks:"Expeditions to other galaxies",desc:"Antimatter, exotic matter and the relays: two and a half million light-years in ten days."},ringworlds:{name:"Ringworld Engineering",branch:"engineering",tier:23,req:["matrioshkaBrains","domeWorlds"],effect:{},unlocks:"Ringworld (megastructure)",desc:"A band of land around a star, spun for gravity, walled to hold the air."},transcendence:{name:"Transcendence Studies",branch:"life",tier:24,req:["intergalacticDrive","ringworlds"],effect:{mult:{science:.2,credits:.1}},desc:"What the Ascendants became, and how. Science +20%, credits +10%."}},ec={orbital:4,satComms:4,lifeSupport:4,crewed:5,cryo:5,deepSpace:6,spaceStation:6,heavy:7,reusable:7,closedLoop:7,constellations:7,lunarLanders:8,spacePower:8,isru:9,he3Mining:9,lowGravity:9,lunarHabitats:10,massDrivers:10,planetaryProbes:10,nuclearThermal:10,orbitalShipyard:10,marsDirect:10,spaceAgriculture:10,asteroidMining:11,fusionPower:11,aerostats:11,colonyShips:11,planetaryEngineering:11,beltSettlement:12,solarFurnace:12,radiationShielding:12,fusionDrive:12,gasGiantScoops:12,cometCapture:12,magnetosphere:12,xenobiology:13,cryoHabitats:13,hydrosphere:13,spaceElevator:13,extremophiles:13,advancedFusion:13,ecopoiesis:14,laserSails:13,exoplanetology:13,sleeperShips:14,starColonies:14,dysonSwarm:14,casimirEffect:15,ramjets:15,domeWorlds:15,xenoarchaeology:15,interstellarTrade:16,warpTheory:16,warpDrive:17,wormholeGates:17,contactProtocols:16,xenolinguistics:16,xenodiplomacy:17,upliftEthics:17,navalWarfare:17,planetaryDefence:18,guidedOrdnance:18,capitalShips:18,swarmTactics:19,carrierWarfare:19,antimatterProduction:18,relayNetwork:18,matrioshkaBrains:19,intergalacticDrive:19,ringworlds:20,transcendence:20};for(const i in ec)pt[i]&&(pt[i].hq=ec[i]);const tc=(i,e,t,n)=>i*Math.pow(e,Math.min(n,8)-1)*Math.pow(t,Math.max(0,n-8)),jo=i=>{if(i.cost)return i.cost;const e=i.tier,t=i.hq||Math.max(1,e);return{science:Ka(Math.round(tc(60,3.6,2,e)/10)*10,t,"science"),credits:Ka(Math.round(tc(200,3.2,1.9,e)/10)*10,t,"credits")}},gd=i=>i.time||Math.round(Ah(3+3.6*(i.tier-1))),Ns=[{id:"ch1",name:"Chapter 1 · Humble Beginnings",intro:"A patch of coastal scrubland, a borrowed budget and a dream. Build the programme that will carry humanity to the stars.",steps:[{id:"o1",text:"Upgrade Mission Control to level 2",kind:"hq",lvl:2,reward:{credits:500,metal:900}},{id:"o2",text:"Build a Research Center",kind:"build",b:"research",lvl:1,reward:{credits:600,metal:500,dm:5}},{id:"o3",text:"Research Rocketry Fundamentals",kind:"tech",id2:"rocketry",reward:{science:120,credits:600,metal:600}},{id:"o7",text:"Build the Launch Complex",kind:"build",b:"launch",lvl:1,reward:{fuel:600,dm:10}},{id:"p1",text:"Assemble a Kestrel sounding rocket",kind:"rockets",n:1,reward:{credits:2e3,fuel:800}},{id:"p2",text:"Fly a suborbital test flight",kind:"flag",flag:"suborbital",reward:{science:600,dm:10}},{id:"o4",text:"Build a Fuel Refinery",kind:"build",b:"refinery",lvl:1,reward:{fuel:400,metal:800}},{id:"o5",text:"Upgrade the Metal Mine to level 3",kind:"build",b:"mine",lvl:3,reward:{credits:800,dm:5}},{id:"o6",text:"Keep the grid powered: +10 spare energy",kind:"energy",n:10,reward:{metal:600,credits:600}},{id:"o8",text:"Research Multistage Rockets",kind:"tech",id2:"multistage",reward:{science:300,credits:1200}},{id:"o8b",text:"Upgrade Mission Control to level 3",kind:"hq",lvl:3,reward:{credits:1500,metal:1500}},{id:"o9",text:"Build the Vehicle Assembly building",kind:"build",b:"vab",lvl:1,reward:{metal:2e3,dm:10}},{id:"o10",text:"Upgrade Mission Control to level 4",kind:"hq",lvl:4,reward:{credits:3e3,metal:2e3,dm:10}},{id:"o11",text:"Research Orbital Mechanics",kind:"tech",id2:"orbital",reward:{science:800,dm:15}}]},{id:"ch2",name:"Chapter 2 · Reaching Orbit",intro:"The world is watching. Rockets that fall are lessons; rockets that rise are history.",steps:[{id:"p3",text:"Research Communication Satellites",kind:"tech",id2:"satComms",reward:{credits:4e3,dm:10}},{id:"p4",text:"Put the first satellite in orbit",kind:"flag",flag:"firstOrbit",reward:{metal:6e3,dm:15}},{id:"p5",text:"Operate a Comms Satellite",kind:"sat",sat:"comms",reward:{credits:8e3,dm:10}},{id:"p6",text:"Build the Tracking Station",kind:"build",b:"tracking",lvl:1,reward:{science:2e3}},{id:"p7",text:"Build the Astronaut Academy",kind:"build",b:"academy",lvl:1,reward:{credits:1e4,dm:10}},{id:"p8",text:"Send a crew into orbit",kind:"flag",flag:"crewOrbit",reward:{dm:30,credits:2e4}}]},{id:"ch3",name:"Chapter 3 · Destination Moon",intro:"Three days away, a quarter of a million miles. The Moon has waited four billion years for visitors.",steps:[{id:"q1",text:"Launch the station Core Module",kind:"module",mod:"core",lvl:1,reward:{science:1e4,dm:15}},{id:"q2",text:"Dock a Laboratory module",kind:"module",mod:"lab",lvl:1,reward:{credits:3e4}},{id:"q3",text:"Launch the Lunar Survey Probe",kind:"flag",flag:"lunarProbe",reward:{science:15e3,dm:15}},{id:"q4",text:"Land astronauts on the Moon",kind:"flag",flag:"lunarLanding",reward:{dm:50,credits:8e4}},{id:"q5",text:"Establish the Lunar Outpost",kind:"flag",flag:"moonBase",reward:{dm:50,metal:1e5}},{id:"q6",text:"Build a He-3 Extractor on the Moon",kind:"build",b:"he3x",lvl:1,reward:{he3:400,dm:20}},{id:"q7",text:"Upgrade the Colony Hub to level 3",kind:"hubLvl",lvl:3,reward:{dm:40,credits:3e5}}]},{id:"ch4",name:"Chapter 4 · The Red Planet",intro:"Six months away by chemical rocket, weeks by nuclear. Mars is waiting, cold and red and almost habitable.",steps:[{id:"r1",text:"Research Planetary Probes",kind:"tech",id2:"planetaryProbes",reward:{science:15e4,dm:20}},{id:"r2",text:"Survey Mars with a probe (open the Star Map)",kind:"survey",body:"mars",reward:{credits:4e5,dm:15}},{id:"r3",text:"Research Nuclear Thermal Propulsion",kind:"tech",id2:"nuclearThermal",reward:{fuel:3e5,dm:15}},{id:"r4",text:"Research Orbital Shipyards",kind:"tech",id2:"orbitalShipyard",reward:{metal:4e5,dm:15}},{id:"r5",text:"Launch the Orbital Shipyard station module",kind:"module",mod:"yard",lvl:1,reward:{credits:6e5,dm:20}},{id:"r6",text:"Build a Hermes transfer ship (Launch Control → Fleet)",kind:"ship",ship:"hermes",reward:{fuel:5e5,dm:20}},{id:"r7",text:"Research Mars Direct",kind:"tech",id2:"marsDirect",reward:{science:4e5,dm:20}},{id:"r8",text:"Found Bradbury Landing on Mars",kind:"colony",body:"mars",reward:{dm:80,metal:15e5}},{id:"r9",text:"Build a Greenhouse on Mars",kind:"buildOn",base:"mars",b:"greenhouse",reward:{credits:1e6,dm:20}},{id:"r10",text:"Reach 60 colonists on Mars",kind:"pop",body:"mars",n:60,reward:{dm:40,science:8e5}}]},{id:"ch5",name:"Chapter 5 · The Belt",intro:"Between Mars and Jupiter drift a million worlds of metal and ice. Whoever learns to mine them owns the future.",steps:[{id:"s1",text:"Build the Phobos Depot above Mars",kind:"site",body:"phobos",reward:{fuel:1e6,dm:20}},{id:"s2",text:"Research Asteroid Mining",kind:"tech",id2:"asteroidMining",reward:{credits:15e5,dm:20}},{id:"s3",text:"Open a mining claim on the metal asteroid Psyche",kind:"site",body:"psyche",reward:{rare:1500,dm:30}},{id:"s4",text:"Float the Cytherea Aerostat over Venus",kind:"site",body:"venus",reward:{science:15e5,dm:30}},{id:"s5",text:"Build an Ares colony transport",kind:"ship",ship:"ares",reward:{credits:2e6,dm:25}},{id:"s6",text:"Found Occator Station on Ceres",kind:"colony",body:"ceres",reward:{dm:80,rare:3e3}},{id:"s7",text:"Complete the first terraforming stage on Mars",kind:"terra",body:"mars",n:1,reward:{dm:50,credits:4e6}},{id:"s8",text:"Run five outposts or claims across the Solar System",kind:"sites",n:5,reward:{dm:40,metal:5e6}},{id:"s9",text:"Upgrade the Mars Colony Hub to level 4",kind:"hubLvl",base:"mars",lvl:4,reward:{dm:60,credits:6e6}}]},{id:"ch6",name:"Chapter 6 · Giants and Ice",intro:"Fusion fire opens the outer system: gas giants full of helium-3, moons hiding oceans, and something at the very edge.",steps:[{id:"u1",text:"Research the Fusion Drive",kind:"tech",id2:"fusionDrive",reward:{he3:2e3,dm:30}},{id:"u2",text:"Build a Daedalus torch ship",kind:"ship",ship:"daedalus",reward:{credits:8e6,dm:30}},{id:"u3",text:"Build the Jovian He-3 Scoop",kind:"site",body:"jupiter",reward:{he3:4e3,dm:40}},{id:"u4",text:"Send the Europa Deep Probe under the ice",kind:"site",body:"europa",reward:{science:6e6,dm:60}},{id:"u5",text:"Found Kraken Shore on Titan",kind:"colony",body:"titan",reward:{dm:80,fuel:6e6}},{id:"u6",text:"Bombard Mars with comets (terraforming stage 3)",kind:"terra",body:"mars",n:3,reward:{dm:80,credits:15e6}},{id:"u7",text:"Build an Odyssey cruiser",kind:"ship",ship:"odyssey",reward:{dm:60,rare:1e4}},{id:"u8",text:"Raise Tombaugh Station on Pluto",kind:"site",body:"pluto",reward:{dm:100,science:2e7}}]},{id:"ch7",name:"Chapter 7 · First Light",intro:"The nearest star is 4.2 light-years away: 40 trillion kilometres. Light itself takes four years. We are going anyway.",steps:[{id:"v1",text:"Research Laser Light Sails",kind:"tech",id2:"laserSails",reward:{science:2e7,dm:40}},{id:"v2",text:"Build the Starshot Laser Array (tap the Sun on the Star Map)",kind:"mega",mega:"laser",n:1,reward:{rare:2e4,dm:40}},{id:"v3",text:"Survey Proxima Centauri with a light sail",kind:"starSurvey",star:"proxima",reward:{credits:6e7,dm:40}},{id:"v8",text:"Survey Epsilon Eridani, the source of the signal",kind:"starSurvey",star:"epseri",reward:{dm:100,science:6e7}},{id:"u9",text:"Give Mars liquid oceans (terraforming stage 5)",kind:"terra",body:"mars",n:5,reward:{dm:200,credits:5e7}},{id:"v4",text:"Research Star Colonies",kind:"tech",id2:"starColonies",reward:{science:3e7,dm:40}},{id:"v5",text:"Build an Exodus Ark",kind:"drive",ship:"ark",reward:{he3:2e4,dm:50}},{id:"v6",text:"Found humanity's first star colony",kind:"starCol",n:1,reward:{dm:150,credits:1e8}},{id:"v7",text:"Begin the Dyson Swarm",kind:"mega",mega:"dyson",n:1,reward:{dm:60,metal:1e8}}]},{id:"ch8",name:"Chapter 8 · Between the Stars",intro:"A lighthouse at Epsilon Eridani, older than our species. Whoever built it wanted to be found. Spread out, grow strong, and be ready.",steps:[{id:"w6",text:"Survey ten star systems",kind:"starSurvey",n:10,reward:{dm:100,credits:4e8}},{id:"w1",text:"Run three star colonies",kind:"starCol",n:3,reward:{dm:80,credits:2e8}},{id:"w2",text:"Develop a star colony to level 5",kind:"starLvl",lvl:5,reward:{dm:80,rare:6e4}},{id:"w3",text:"Build the Casimir Foundry on Earth",kind:"build",b:"casimir",lvl:1,reward:{exotic:200,dm:60}},{id:"w4",text:"Build a Pathfinder ramjet",kind:"drive",ship:"ramjet",reward:{dm:80,he3:4e4}},{id:"w5",text:"Raise the Dyson Swarm to stage 4",kind:"mega",mega:"dyson",n:4,reward:{dm:100,science:15e7}}]},{id:"ch9",name:"Chapter 9 · Contact",intro:"For all of history we wondered if we were alone. The answer is arriving, and it is complicated.",steps:[{id:"x1",text:"Research First Contact Protocols",kind:"tech",id2:"contactProtocols",reward:{science:8e7,dm:60}},{id:"x2",text:"Make first contact with an alien civilisation",kind:"met",n:1,reward:{xeno:2e3,dm:100}},{id:"x3",text:"Research Xenolinguistics",kind:"tech",id2:"xenolinguistics",reward:{xeno:2e3,dm:60}},{id:"x4",text:"Build the Xenology Institute on Earth",kind:"build",b:"xenolab",lvl:1,reward:{influence:1500,dm:60}},{id:"x5",text:"Decipher an alien language to 50%",kind:"und",n:50,reward:{xeno:4e3,dm:80}},{id:"x6",text:"Fulfil a request from another civilisation",kind:"requests",n:1,reward:{influence:2e3,dm:80}},{id:"x7",text:"Learn a piece of alien knowledge",kind:"xenotech",n:1,reward:{dm:120,credits:1e9}}]},{id:"ch10",name:"Chapter 10 · The Wider Galaxy",intro:"Gardeners from another galaxy, merchants of light, a machine Synod, a fungal mind, a young ocean people, and a Swarm that eats worlds. Choose your friends well.",steps:[{id:"y1",text:"Meet four civilisations",kind:"met",n:4,reward:{xeno:8e3,dm:100}},{id:"y2",text:"Research Xenodiplomacy and open an embassy",kind:"embassy",reward:{influence:4e3,dm:100}},{id:"y3",text:"Sign a trade agreement",kind:"deal",deal:"trade",reward:{dm:100,exotic:1e3}},{id:"y4",text:"Excavate the Hollow ruins to level 3",kind:"ruins",n:3,reward:{xeno:15e3,dm:120}},{id:"y5",text:"Decide the fate of a young species: protect or uplift it",kind:"minorChoice",reward:{dm:120,influence:6e3}},{id:"y7",text:"Answer the Kr'thul: pay tribute or refuse (Contact screen)",kind:"flag",flag:"krthulAnswered",reward:{dm:150,metal:2e9}},{id:"w7",text:"Open the Sol Wormhole Gate",kind:"mega",mega:"gate",n:1,reward:{dm:200,exotic:1e3}},{id:"w8",text:"Gate a star colony into the network",kind:"gates",n:1,reward:{dm:200,credits:8e8}},{id:"y6",text:"Sign a research pact",kind:"deal",deal:"pact",reward:{dm:150,science:3e8}},{id:"y8",text:"Form an alliance",kind:"deal",deal:"alliance",reward:{dm:300,credits:3e9}}]},{id:"ch11",name:"Chapter 11 · The Swarm",intro:"Humanity built ships to explore. Now it must build ships to survive. The Kr'thul do not negotiate twice.",steps:[{id:"z1",text:"Research Naval Warfare",kind:"tech",id2:"navalWarfare",reward:{metal:2e9,dm:100}},{id:"z2",text:"Build a fleet of 20 warships (Fleet screen)",kind:"warships",n:20,reward:{credits:2e9,dm:100}},{id:"z3",text:"Research Planetary Defence",kind:"tech",id2:"planetaryDefence",reward:{science:4e8,dm:100}},{id:"z4",text:"Fortify a colony to defence level 2",kind:"defence",lvl:2,reward:{dm:120,metal:3e9}},{id:"z5",text:"Destroy the Kr'thul hive at Ross 154",kind:"hive",hive:"ross154",reward:{dm:200,xeno:2e4}},{id:"z6",text:"Research Capital Ships",kind:"tech",id2:"capitalShips",reward:{dm:150,rare:2e5}}]},{id:"ch12",name:"Chapter 12 · The Brood Queen",intro:"Three hives stand between us and Kapteyn's Star. Beyond them waits the mind of the Swarm.",steps:[{id:"za1",text:"Destroy the hive at Luyten 726-8",kind:"hive",hive:"uvceti",reward:{dm:250,credits:8e9}},{id:"za2",text:"Build a fleet of 150 warships",kind:"warships",n:150,reward:{dm:200,metal:8e9}},{id:"za3",text:"Destroy the hive at Lacaille 9352",kind:"hive",hive:"lacaille",reward:{dm:300,exotic:5e3}},{id:"za4",text:"Research Carrier Warfare",kind:"tech",id2:"carrierWarfare",reward:{dm:200,science:1e9}},{id:"za5",text:"Kill the Brood Queen at Kapteyn's Star",kind:"hive",hive:"kapteyn",reward:{dm:1e3,credits:3e10}}]},{id:"ch13",name:"Chapter 13 · The Dark Between Galaxies",intro:"The Milky Way is ours to explore for a million years. The Hollow relays point further.",steps:[{id:"b1",text:"Research Antimatter Production",kind:"tech",id2:"antimatterProduction",reward:{exotic:2e4,dm:200}},{id:"b2",text:"Build an Antimatter Factory",kind:"build",b:"antimatter",lvl:1,reward:{antimatter:500,dm:150}},{id:"b3",text:"Research the Relay Network",kind:"tech",id2:"relayNetwork",reward:{xeno:5e4,dm:150}},{id:"b4",text:"Wake the first relay (Beyond screen)",kind:"relay",n:1,reward:{dm:200,credits:2e10}},{id:"b5",text:"Research the Intergalactic Drive",kind:"tech",id2:"intergalacticDrive",reward:{dm:200,antimatter:1e3}},{id:"b6",text:"Send an expedition to the Sagittarius Dwarf galaxy",kind:"galaxy",gal:"sagdeg",reward:{dm:300,exotic:5e4}},{id:"b7",text:"Visit the Veyari home in the Large Magellanic Cloud",kind:"galaxy",gal:"lmc",reward:{dm:400,science:5e9}}]},{id:"ch14",name:"Chapter 14 · The Ascendants",intro:"Every civilisation in Andromeda is listening to the same voice. It is time to answer it.",steps:[{id:"c1",text:"Build the first shell of a Matrioshka Brain",kind:"mega",mega:"matrioshka",n:1,reward:{dm:300,science:1e10}},{id:"c2",text:"Reach the Small Magellanic Cloud",kind:"galaxy",gal:"smc",reward:{dm:400,xeno:2e5}},{id:"c3",text:"Cross to Andromeda",kind:"galaxy",gal:"andromeda",reward:{dm:600,credits:1e11}},{id:"c4",text:"Raise a Ringworld",kind:"mega",mega:"ringworld",n:1,reward:{dm:500,metal:2e11}},{id:"c5",text:"Survey the Triangulum galaxy",kind:"galaxy",gal:"triangulum",reward:{dm:600,rare:1e8}},{id:"c6",text:"Find the Far Shore",kind:"galaxy",gal:"farshore",reward:{dm:2e3}}]}],vd=()=>Ns.flatMap(i=>i.steps.map(e=>({...e,ch:i.id}))),at={credits:{name:"Credits",short:"CR",color:"#ffd166",cap:!0,start:!0,icon:"¢",desc:"Funding from governments, sponsors and commerce. Spent on nearly everything."},metal:{name:"Metal",short:"MT",color:"#b8c4d6",cap:!0,start:!0,icon:"▣",desc:"Steel, aluminium and titanium for structures, rockets and ships."},fuel:{name:"Fuel",short:"FU",color:"#ff8a5b",cap:!0,start:!0,icon:"▲",desc:"Rocket propellant: kerosene, liquid hydrogen and oxygen, later methane and more."},science:{name:"Science",short:"SC",color:"#6ee7ff",cap:!0,start:!0,icon:"✦",desc:"Research data. Spent to unlock technologies."},cells:{name:"Power Cells",short:"PC",color:"#7cf29a",cap:!0,icon:"⚡",desc:"Charged cells that keep robots running and level them up."},he3:{name:"Helium-3",short:"He3",color:"#b892ff",cap:!0,icon:"◉",desc:"A rare isotope found in lunar regolith and gas giants. Fusion fuel."},rare:{name:"Rare Elements",short:"RE",color:"#7cf29a",cap:!0,icon:"◆",desc:"Platinum-group metals and rare earths from asteroids."},exotic:{name:"Exotic Matter",short:"EX",color:"#ff5cf0",cap:!0,icon:"✺",desc:"Negative-energy matter. It holds warp bubbles and wormholes open."},antimatter:{name:"Antimatter",short:"AM",color:"#ff4d6d",cap:!0,icon:"⊛",desc:"The densest energy source known. Handle with care."},influence:{name:"Influence",short:"IN",color:"#ffb3c7",cap:!0,icon:"❖",desc:"Diplomatic standing among the civilisations of the galaxy."},xeno:{name:"Xenodata",short:"XD",color:"#9dff5c",cap:!0,icon:"⌬",desc:"Knowledge gathered from alien life, ruins and artifacts."},dm:{name:"Dark Matter",short:"DM",color:"#c9b6ff",cap:!1,start:!0,icon:"◈",desc:"A precious, mysterious resource. It completes any timer instantly. Earned, never bought."}},xd=["credits","metal","fuel"],_d=[],yd=[],jr={mult:()=>1,solar:()=>1,house:()=>0,grow:()=>0};function hi(i){const e={mult:{},gen:0,buildTime:0,researchTime:0,cap:0,crews:0,slots:0,costs:0,flags:new Set};for(const t in i.tech){const n=pt[t];if(!n)continue;const r=n.effect||{};for(const s in r.mult||{})e.mult[s]=(e.mult[s]||0)+r.mult[s];for(const s of["gen","buildTime","researchTime","cap","crews","slots","costs"])r[s]&&(e[s]+=r[s]);r.flag&&e.flags.add(r.flag)}for(const t in i.flags)i.flags[t]&&e.flags.add(t);for(const t of _d)t(i,e);return e}const xi=(i,e)=>i?Th(i[0],i[1],e):0;function Ja(i,e,t){const n=rt[i],r={prod:{},cap:{},gen:0,draw:0,speed:0,house:0,jobs:0,grow:0};if(!n||e<=0)return r;r.house=xi(n.house,e),r.jobs=Math.round(xi(n.jobs,e)),r.grow=xi(n.grow,e);for(const s in n.prod||{})r.prod[s]=xi(n.prod[s],e)*(1+(t.mult[s]||0));for(const s in n.cap||{})r.cap[s]=xi(n.cap[s],e)*(1+t.cap);return r.gen=xi(n.gen,e)*(1+t.gen),r.draw=xi(n.draw,e),r.speed=n.speed?n.speed*e:0,r}const Rh=(i,e,t)=>{const n=i.bases[e];if(!n)return 0;let r=0;for(const s of n.items)s.b===t&&(r=Math.max(r,s.lvl));return r},Sn=(i,e="earth")=>Rh(i,e,e==="earth"?"hq":"hub"),Ch=i=>{const e=rt[i];return!e||!e.collect?null:Object.keys(e.prod||{}).find(t=>xd.includes(t))||null};function si(i,e=hi(i)){const t={prod:{},cap:{},gen:0,draw:0,eff:1,speed:0,m:e,col:{},item:{},collect:{}};for(const s in at)t.prod[s]=0,t.cap[s]=at[s].cap?0:1/0;const n=[];for(const s in i.bases){const a=i.bases[s],o=s!=="earth",l=[];let c=0,h=0,u=0;for(const g of a.items){if(g.lvl<=0)continue;const v=Ja(g.b,g.lvl,e);l.push([g,v]),c+=v.house,h+=v.jobs,u+=v.grow}let d=1;if(o){c*=1+jr.house(),u+=jr.grow();const g=a.pop||0;d=h>0?Math.min(1,g/h):1,t.col[s]={house:Math.round(c),jobs:h,grow:u,staff:d,pop:g}}const p=.3+.7*d;for(const[g,v]of l){const m=g.b==="hub"?1:p;n.push([g,s,v,m]);for(const f in v.cap)t.cap[f]+=v.cap[f];t.gen+=g.b==="lsolar"?v.gen*jr.solar():v.gen,t.draw+=v.draw,t.speed+=v.speed*m}}for(const s of yd)s(i,t);t.eff=t.draw<=0?1:Math.min(1,t.gen/t.draw);const r=.25+.75*t.eff;for(const s in t.prod)t.prod[s]*=r;for(const[s,a,o,l]of n){const c=Ch(s.b);for(const h in o.prod){const u=o.prod[h]*l*jr.mult()*r;h===c?(t.item[s.id]={r:h,rate:u,hold:u*bh(s.lvl)},t.collect[h]=(t.collect[h]||0)+u):t.prod[h]+=u}}return t}function Md(i,e,t){if(!(t<=0)){for(const n in e.col){const r=e.col[n],s=i.bases[n];if(!s)continue;const a=s.pop||0;a<r.house&&(s.pop=Math.min(r.house,a+r.grow*t/3600))}for(const n in e.prod){const r=e.prod[n]*t/3600;if(!r)continue;const s=i.res[n]||0,a=e.cap[n];if(r>0&&s>=a)continue;const o=Math.max(a,s);i.res[n]=Math.max(0,Math.min(o,s+r))}for(const n in i.bases)for(const r of i.bases[n].items){const s=e.item[r.id];s&&(r.held=Math.min(s.hold,(r.held||0)+s.rate*t/3600))}}}const el=(i,e)=>Object.entries(e).every(([t,n])=>(i.res[t]||0)>=n),tl=(i,e)=>{for(const[t,n]of Object.entries(e))i.res[t]=(i.res[t]||0)-n},Qa=(i,e)=>{for(const[t,n]of Object.entries(e))i.res[t]=(i.res[t]||0)+n},bd=[];function Sd(i,e){let t=18e12*Math.pow(1+e.gen/25,.8);for(const n of bd)t+=n(i,e);return t}const Us=(i,e)=>(Math.log10(Sd(i,e))-6)/10,Fs=[.75,.8,.85,.9,.95,1,1.1,1.2,1.3,1.4,1.5,1.6,1.7,1.8,1.9,2,2.2,2.4,2.6,2.8,3],wd=i=>i>=3?"Type III: a galactic civilisation":i>=2?"Type II: master of a star":i>=1?"Type I: master of a planet":"Type 0: a planet-bound species",Ph={},Lh={},Ed=[],er=(i,e,t)=>{const n=rt[i],r={},s=cd(i,e);for(const a in n.cost)r[a]=Ka(md(Th(n.cost[a][0],n.cost[a][1],e)*(1-t.costs)),s,a);return r},Nr=(i,e,t)=>Math.max(2,Math.round(pd(rt[i].time,e)*(1-t.buildTime))),nl=(i,e)=>Math.max(5,Math.round(gd(pt[i])*(1-e.m.researchTime)/(1+e.speed))),Ur=(i,e=hi(i))=>ud(Sn(i))+e.crews,Ji=i=>i.jobs.filter(e=>e.kind==="build").length,il=(i,e=hi(i))=>1+e.slots,rl=i=>i.jobs.filter(e=>e.kind==="research").length,wi=(i,e)=>i.jobs.find(t=>t.kind==="build"&&t.item===e),Vt=(i,e,t)=>i.bases[e]?.items.find(n=>n.id===t),sl=(i,e,t)=>i.bases[e].items.filter(n=>n.b===t).length,vn=(i,e=0)=>{const[t,n]=rt[i].fp;return e%2?[n,t]:[t,n]};function Xr(i,e){const t=dd(e,Sn(i,e)||1),n=Math.floor((ar-t)/2);return{lo:n,hi:n+t,side:t}}function $r(i,e,t,n,r,s,a){const[o,l]=vn(t,s),c=Xr(i,e);if(n<c.lo||r<c.lo||n+o>c.hi||r+l>c.hi)return{ok:!1,why:"Outside the base (raise the command level to expand it)"};for(const h of i.bases[e].items){if(h.id===a)continue;const[u,d]=vn(h.b,h.r);if(n<h.x+u&&n+o>h.x&&r<h.z+d&&r+l>h.z)return{ok:!1,why:"Something is in the way"}}return{ok:!0}}function Dh(i,e,t,n=0){const r=Xr(i,e),[s,a]=vn(t,n),o=ar/2;let l=null,c=1e9;for(let h=r.lo;h+a<=r.hi;h++)for(let u=r.lo;u+s<=r.hi;u++){const d=Math.hypot(u+s/2-o,h+a/2-o);d<c&&$r(i,e,t,u,h,n).ok&&(c=d,l=[u,h])}return l}function Xs(i,e,t){const n=rt[t],r=hi(i),s=Sn(i,e);if(!n||!i.bases[e])return{ok:!1,why:"Unknown"};if(!n.bases.includes(e))return{ok:!1,why:"Cannot be built on this world"};if(n.req&&n.req.tech&&!i.tech[n.req.tech])return{ok:!1,why:`Research ${pt[n.req.tech].name}`,tech:n.req.tech};if(n.req&&n.req.hq&&s<n.req.hq)return{ok:!1,why:`Mission Control level ${n.req.hq}`,hq:!0};const a=wh(n,s);if(sl(i,e,t)>=a)return{ok:!1,why:a?"Limit reached for this command level":`Command level ${(n.count||[]).findIndex(l=>l>0)+1}`,hq:!0};if(Ji(i)>=Ur(i,r))return{ok:!1,why:"All construction drones are busy",crews:!0};const o=er(t,1,r);return el(i,o)?{ok:!0,cost:o,time:Nr(t,1,r)}:{ok:!1,why:"Not enough resources",cost:o}}function Ih(i,e,t,n,r,s,a=Date.now()){const o=Xs(i,e,t);if(!o.ok)return o;const l=$r(i,e,t,n,r,s);if(!l.ok)return l;tl(i,o.cost);const c={id:qs(i,"i"),b:t,x:n,z:r,r:s,lvl:0,held:0};return i.bases[e].items.push(c),i.jobs.push({id:qs(i),kind:"build",base:e,item:c.id,b:t,from:0,to:1,start:a,end:a+o.time*1e3}),{...o,item:c}}const Nh=(i,e,t,n)=>hd(t,n,e).filter(([r,s])=>!i.bases[e].items.some(a=>a.b===r&&a.lvl>=s)),al=(i,e,t)=>{const n=rt[t];return n.command&&e!=="earth"?Math.max(1,Math.min(n.max,Sn(i,"earth")-7)):Sh(n,Sn(i,e))};function $s(i,e,t){const n=Vt(i,e,t);if(!n)return{ok:!1,why:"Gone"};const r=rt[n.b],s=hi(i),a=Sn(i,e);if(wi(i,t))return{ok:!1,why:"Under construction"};if(n.lvl>=r.max)return{ok:!1,why:"Maximum level",max:!0};if(r.command&&e!=="earth"&&n.lvl>=al(i,e,n.b))return{ok:!1,why:`Mission Control level ${n.lvl+8} on Earth`,hq:!0};const o=Nh(i,e,n.b,n.lvl+1);if(o.length)return{ok:!1,why:`First upgrade ${o.map(([c,h])=>rt[c].name+" to level "+h).join(", ")}`,reqs:o,hq:!0};if(n.lvl>=Sh(r,a))return{ok:!1,why:`Upgrade ${e==="earth"?"Mission Control":"the Colony Hub"} first`,hq:!0};if(Ji(i)>=Ur(i,s))return{ok:!1,why:"All construction drones are busy",crews:!0};const l=er(n.b,n.lvl+1,s);return el(i,l)?{ok:!0,cost:l,time:Nr(n.b,n.lvl+1,s)}:{ok:!1,why:"Not enough resources",cost:l}}function Uh(i,e,t,n=Date.now()){const r=$s(i,e,t);if(!r.ok)return r;tl(i,r.cost);const s=Vt(i,e,t);return i.jobs.push({id:qs(i),kind:"build",base:e,item:t,b:s.b,from:s.lvl,to:s.lvl+1,start:n,end:n+r.time*1e3}),i.stats.upgradesStarted=(i.stats.upgradesStarted||0)+1,r}function Fh(i,e,t,n,r,s){const a=Vt(i,e,t);if(!a)return{ok:!1};const o=$r(i,e,a.b,n,r,s,t);return o.ok?(a.x=n,a.z=r,a.r=s,{ok:!0}):o}const ol=(i,e,t)=>{const n=Vt(i,e,t);return!!n&&!rt[n.b].command&&n.b!=="launch"&&!wi(i,t)};function Oh(i,e,t){return ol(i,e,t)?(i.bases[e].items=i.bases[e].items.filter(n=>n.id!==t),!0):!1}function Bh(i,e,t,n=si(i)){const r=Vt(i,e,t);if(!r)return null;const s=Ch(r.b);if(!s)return null;const a=Math.floor(r.held||0);if(a<1)return null;const o=Math.max(0,Math.floor(n.cap[s]-(i.res[s]||0))),l=Math.min(a,o);return l<=0?{r:s,n:0,full:!0}:(r.held=(r.held||0)-l,i.res[s]=(i.res[s]||0)+l,i.stats.collected+=l,i.stats.collects=(i.stats.collects||0)+1,{r:s,n:l,full:l<a})}const Td=(i,e)=>Object.values(i.bases).some(t=>t.items.some(n=>n.b===e&&n.lvl>0));function Ys(i,e){const t=pt[e];if(!t)return{ok:!1,why:"Unknown"};if(i.tech[e])return{ok:!1,why:"Researched",done:!0};if(i.jobs.some(a=>a.kind==="research"&&a.tech===e))return{ok:!1,why:"In progress",busy:!0};const n=t.req.filter(a=>!i.tech[a]);if(n.length)return{ok:!1,why:"Requires "+n.map(a=>pt[a].name).join(", "),locked:!0};if(t.hq&&Sn(i)<t.hq)return{ok:!1,why:`Mission Control ${t.hq}`,locked:!0,hq:!0};if(!Td(i,"research"))return{ok:!1,why:"Build a Research Center",locked:!0};const r=hi(i);if(rl(i)>=il(i,r))return{ok:!1,why:"Research slot busy",slots:!0};const s=jo(t);return el(i,s)?{ok:!0,cost:s,time:nl(e,si(i,r))}:{ok:!1,why:"Not enough resources",cost:s}}function kh(i,e,t=Date.now()){const n=Ys(i,e);return n.ok&&(tl(i,n.cost),i.jobs.push({id:qs(i),kind:"research",tech:e,start:t,end:t+n.time*1e3})),n}function Ad(i,e){if(i.jobs=i.jobs.filter(n=>n!==e),e.kind==="build"){const n=Vt(i,e.base,e.item);return n?(n.lvl=e.to,e.from===0?i.stats.built++:i.stats.upgrades++,{kind:"build",b:e.b,lvl:e.to,base:e.base,item:e.item,first:e.from===0}):null}if(e.kind==="research")return i.tech[e.tech]=1,i.stats.researched++,{kind:"research",tech:e.tech};const t=Ph[e.kind];return t?t(i,e):null}function ja(i,e=Date.now()){const t=[];let n=0;for(;n++<1e4;){const r=i.jobs.reduce((h,u)=>u.end<=e&&(!h||u.end<h.end)?u:h,null),s=si(i);let a=r?Math.max(i.last,r.end):e;const l=Object.values(s.col).some(h=>h.pop<h.house&&h.grow>0)&&a-i.last>36e5;if(l&&(a=i.last+36e5),Md(i,s,(a-i.last)/1e3),i.last=a,l)continue;if(!r)break;const c=Ad(i,r);c&&(c.t=r.end,t.push(c))}return i.last=e,t}const Er=i=>i<=60?0:Math.ceil(1.2*Math.pow(i/60,.72));function zh(i,e,t=Date.now()){const n=i.jobs.find(s=>s.id===e);if(!n)return{ok:!1,why:"Gone"};const r=Er((n.end-t)/1e3);return(i.res.dm||0)<r?{ok:!1,why:"Not enough dark matter",need:r}:(i.res.dm-=r,i.stats.dmSpent+=r,n.end=t,{ok:!0,spent:r})}function Rd(i,e,t,n=Date.now()){const r=i.jobs.find(s=>s.id===e);return r?(r.end=Math.max(n,r.end-t*1e3),!0):!1}function Gh(i,e){const t=i.jobs.find(r=>r.id===e);if(!t)return!1;const n=hi(i);if(t.kind==="build"){const r=er(t.b,t.to,n);Qa(i,Object.fromEntries(Object.entries(r).map(([s,a])=>[s,Math.floor(a*.5)]))),t.from===0&&(i.bases[t.base].items=i.bases[t.base].items.filter(s=>s.id!==t.item))}else if(t.kind==="research"){const r=jo(pt[t.tech]);Qa(i,Object.fromEntries(Object.entries(r).map(([s,a])=>[s,Math.floor(a*.5)])))}else return!1;return i.jobs=i.jobs.filter(r=>r!==t),!0}const Hh=vd(),Tr=i=>Hh[i.obj.i]||null,Vh=i=>i.obj.i,Wh=()=>Hh.length;function ll(i,e,t=si(i)){if(!e)return!1;switch(e.kind){case"hq":return Sn(i)>=e.lvl;case"build":return Object.values(i.bases).some(r=>r.items.some(s=>s.b===e.b&&s.lvl>=e.lvl));case"buildOn":return!!i.bases[e.base]&&i.bases[e.base].items.some(r=>r.b===e.b&&r.lvl>=(e.lvl||1));case"tech":return!!i.tech[e.id2];case"rate":return t.prod[e.res]+(t.collect[e.res]||0)>=e.n;case"energy":return t.gen-t.draw>=e.n;case"flag":return!!i.flags[e.flag];case"hubLvl":return!!i.bases[e.base||"moon"]&&Sn(i,e.base||"moon")>=e.lvl;case"colony":return!!i.bases[e.body];case"pop":return!!i.bases[e.body]&&(i.bases[e.body].pop||0)>=e.n}const n=Lh[e.kind];return n?n(i,e,t):!1}function qh(i){const e=Tr(i);return!e||!ll(i,e)?null:(Qa(i,e.reward),i.obj.claimed[e.id]=Date.now(),i.obj.i++,e)}const Cd=Object.freeze(Object.defineProperty({__proto__:null,advance:ja,area:Xr,canBuild:Xs,canDemolish:ol,canResearch:Ys,canUpgrade:$s,cancel:Gh,claimStep:qh,collect:Bh,completers:Ph,costOf:er,countOf:sl,crewsBusy:Ji,crewsTotal:Ur,currentStep:Tr,demolish:Oh,dims:vn,dmCost:Er,events:Ed,fits:$r,freeSpot:Dh,hqLevel:Sn,itemOf:Vt,jobOf:wi,levelCap:al,lvlOf:Rh,mods:hi,moveItem:Fh,rates:si,reqsMissing:Nh,researchTimeOf:nl,skip:Rd,slotsBusy:rl,slotsTotal:il,speedup:zh,startBuild:Ih,startResearch:kh,startUpgrade:Uh,stepChecks:Lh,stepCount:Wh,stepDone:ll,stepIndex:Vh,timeOf:Nr},Symbol.toStringTag,{value:"Module"}));const cl="187",Pd=0,nc=1,Ld=2,Os=1,Xh=2,br=3,Ei=0,qt=1,xn=2,Qi=0,Ar=1,ic=2,rc=3,sc=4,Dd=5,Zi=100,Id=101,Nd=102,Ud=103,Fd=104,Od=200,Bd=201,kd=202,zd=203,$h=204,Yh=205,Gd=206,Hd=207,Vd=208,Wd=209,qd=210,Xd=211,$d=212,Yd=213,Kd=214,eo=0,to=1,no=2,Fr=3,io=4,ro=5,so=6,ao=7,Kh=0,Zd=1,Jd=2,Wn=0,Zh=1,Jh=2,Qh=3,hl=4,jh=5,eu=6,tu=7,nu=300,tr=301,Or=302,va=303,xa=304,oo=1e3,Vn=1001,lo=1002,Dt=1003,Qd=1004,es=1005,Yt=1006,_a=1007,ii=1008,Qt=1009,iu=1010,ru=1011,Br=1012,ul=1013,Pn=1014,_n=1015,Ln=1016,dl=1017,fl=1018,nr=1020,su=35902,au=35899,ou=1021,lu=1022,Cn=1023,oi=1026,ri=1027,pl=1028,ml=1029,Ti=1030,gl=1031,vl=1033,Bs=33776,ks=33777,zs=33778,Gs=33779,co=35840,ho=35841,uo=35842,fo=35843,po=36196,mo=37492,go=37496,vo=37488,xo=37489,Ks=37490,_o=37491,yo=37808,Mo=37809,bo=37810,So=37811,wo=37812,Eo=37813,To=37814,Ao=37815,Ro=37816,Co=37817,Po=37818,Lo=37819,Do=37820,Io=37821,No=36492,Uo=36494,Fo=36495,Oo=36283,Bo=36284,Zs=36285,ko=36286,jd=3200,zo=0,ef=1,ni="",Ot="srgb",Js="srgb-linear",Qs="linear",et="srgb",ya=7680,tf=519,nf=512,rf=513,sf=514,cu=515,af=516,of=517,hu=518,uu=519,du=35044,ac="300 es",yn=2e3,kr=2001;function lf(i){for(let e=i.length-1;e>=0;--e)if(i[e]>=65535)return!0;return!1}function js(i){return document.createElementNS("http://www.w3.org/1999/xhtml",i)}function cf(){const i=js("canvas");return i.style.display="block",i}const oc={};function ea(...i){const e="THREE."+i.shift();console.log(e,...i)}function fu(i){const e=i[0];if(typeof e=="string"&&e.startsWith("TSL:")){const t=i[1];t&&t.isStackTrace?i[0]+=" "+t.getLocation():i[1]='Stack trace not available. Enable "THREE.Node.captureStackTrace" to capture stack traces.'}return i}function Pe(...i){i=fu(i);const e="THREE."+i.shift();{const t=i[0];t&&t.isStackTrace?console.warn(t.getError(e)):console.warn(e,...i)}}function $e(...i){i=fu(i);const e="THREE."+i.shift();{const t=i[0];t&&t.isStackTrace?console.error(t.getError(e)):console.error(e,...i)}}function Hs(...i){const e=i.join(" ");e in oc||(oc[e]=!0,Pe(...i))}function hf(i,e,t){return new Promise(function(n,r){function s(){switch(i.clientWaitSync(e,i.SYNC_FLUSH_COMMANDS_BIT,0)){case i.WAIT_FAILED:r();break;case i.TIMEOUT_EXPIRED:setTimeout(s,t);break;default:n()}}setTimeout(s,t)})}const uf={[eo]:eo,[no]:so,[io]:io,[Fr]:ro,[to]:to,[so]:no,[ao]:ao,[ro]:Fr};class Ci{addEventListener(e,t){this._listeners===void 0&&(this._listeners={});const n=this._listeners;n[e]===void 0&&(n[e]=[]),n[e].indexOf(t)===-1&&n[e].push(t)}hasEventListener(e,t){const n=this._listeners;return n===void 0?!1:n[e]!==void 0&&n[e].indexOf(t)!==-1}removeEventListener(e,t){const n=this._listeners;if(n===void 0)return;const r=n[e];if(r!==void 0){const s=r.indexOf(t);s!==-1&&r.splice(s,1)}}dispatchEvent(e){const t=this._listeners;if(t===void 0)return;const n=t[e.type];if(n!==void 0){e.target=this;const r=n.slice(0);for(let s=0,a=r.length;s<a;s++)r[s].call(this,e);e.target=null}}}const Ut=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"];let lc=1234567;const Rr=Math.PI/180,zr=180/Math.PI;function $n(){const i=Math.random()*4294967295|0,e=Math.random()*4294967295|0,t=Math.random()*4294967295|0,n=Math.random()*4294967295|0;return(Ut[i&255]+Ut[i>>8&255]+Ut[i>>16&255]+Ut[i>>24&255]+"-"+Ut[e&255]+Ut[e>>8&255]+"-"+Ut[e>>16&15|64]+Ut[e>>24&255]+"-"+Ut[t&63|128]+Ut[t>>8&255]+"-"+Ut[t>>16&255]+Ut[t>>24&255]+Ut[n&255]+Ut[n>>8&255]+Ut[n>>16&255]+Ut[n>>24&255]).toLowerCase()}function ze(i,e,t){return Math.max(e,Math.min(t,i))}function xl(i,e){return(i%e+e)%e}function df(i,e,t,n,r){return n+(i-e)*(r-n)/(t-e)}function ff(i,e,t){return i!==e?(t-i)/(e-i):0}function Cr(i,e,t){return(1-t)*i+t*e}function pf(i,e,t,n){return Cr(i,e,1-Math.exp(-t*n))}function mf(i,e=1){return e-Math.abs(xl(i,e*2)-e)}function gf(i,e,t){return i<=e?0:i>=t?1:(i=(i-e)/(t-e),i*i*(3-2*i))}function vf(i,e,t){return i<=e?0:i>=t?1:(i=(i-e)/(t-e),i*i*i*(i*(i*6-15)+10))}function xf(i,e){return i+Math.floor(Math.random()*(e-i+1))}function _f(i,e){return i+Math.random()*(e-i)}function yf(i){return i*(.5-Math.random())}function Mf(i){i!==void 0&&(lc=i);let e=lc+=1831565813;return e=Math.imul(e^e>>>15,e|1),e^=e+Math.imul(e^e>>>7,e|61),((e^e>>>14)>>>0)/4294967296}function bf(i){return i*Rr}function Sf(i){return i*zr}function wf(i){return i>0&&Number.isInteger(i)&&2**Math.round(Math.log2(i))===i}function Ef(i){return Math.pow(2,Math.ceil(Math.log(i)/Math.LN2))}function pu(i){return Math.pow(2,Math.floor(Math.log(i)/Math.LN2))}function Tf(i,e,t,n,r){const s=Math.cos,a=Math.sin,o=s(t/2),l=a(t/2),c=s((e+n)/2),h=a((e+n)/2),u=s((e-n)/2),d=a((e-n)/2),p=s((n-e)/2),g=a((n-e)/2);switch(r){case"XYX":i.set(o*h,l*u,l*d,o*c);break;case"YZY":i.set(l*d,o*h,l*u,o*c);break;case"ZXZ":i.set(l*u,l*d,o*h,o*c);break;case"XZX":i.set(o*h,l*g,l*p,o*c);break;case"YXY":i.set(l*p,o*h,l*g,o*c);break;case"ZYZ":i.set(l*g,l*p,o*h,o*c);break;default:Pe("MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+r)}}function oa(i){switch(i.constructor){case Uint32Array:return 4294967295;case Uint16Array:return 65535;case Uint8Array:case Uint8ClampedArray:return 255;case Int32Array:return 2147483647;case Int16Array:return 32767;case Int8Array:return 127;default:return}}function _l(i,e){if(e.constructor===Float32Array)return i;const t=oa(e);if(t===void 0)throw new Error("THREE.MathUtils: Invalid component type.");return Math.max(i/t,-1)}function yl(i,e){if(e.constructor===Float32Array)return i;const t=oa(e);if(t===void 0)throw new Error("THREE.MathUtils: Invalid component type.");return Math.round(i*t)}const Si={DEG2RAD:Rr,RAD2DEG:zr,generateUUID:$n,clamp:ze,euclideanModulo:xl,mapLinear:df,inverseLerp:ff,lerp:Cr,damp:pf,pingpong:mf,smoothstep:gf,smootherstep:vf,randInt:xf,randFloat:_f,randFloatSpread:yf,seededRandom:Mf,degToRad:bf,radToDeg:Sf,isPowerOfTwo:wf,ceilPowerOfTwo:Ef,floorPowerOfTwo:pu,setQuaternionFromProperEuler:Tf,normalize:yl,denormalize:_l},Nl=class Nl{constructor(e=0,t=0){this.x=e,this.y=t}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,t){return this.x=e,this.y=t,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;default:throw new Error("THREE.Vector2: index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw new Error("THREE.Vector2: index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){const t=this.x,n=this.y,r=e.elements;return this.x=r[0]*t+r[3]*n+r[6],this.y=r[1]*t+r[4]*n+r[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,t){return this.x=ze(this.x,e.x,t.x),this.y=ze(this.y,e.y,t.y),this}clampScalar(e,t){return this.x=ze(this.x,e,t),this.y=ze(this.y,e,t),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(ze(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const n=this.dot(e)/t;return Math.acos(ze(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,n=this.y-e.y;return t*t+n*n}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this}rotateAround(e,t){const n=Math.cos(t),r=Math.sin(t),s=this.x-e.x,a=this.y-e.y;return this.x=s*n-a*r+e.x,this.y=s*r+a*n+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}};Nl.prototype.isVector2=!0;let de=Nl;class ui{constructor(e=0,t=0,n=0,r=1){this.isQuaternion=!0,this._x=e,this._y=t,this._z=n,this._w=r}static slerpFlat(e,t,n,r,s,a,o){let l=n[r+0],c=n[r+1],h=n[r+2],u=n[r+3],d=s[a+0],p=s[a+1],g=s[a+2],v=s[a+3];if(u!==v||l!==d||c!==p||h!==g){let m=l*d+c*p+h*g+u*v;m<0&&(d=-d,p=-p,g=-g,v=-v,m=-m);let f=1-o;if(m<.9995){const _=Math.acos(m),S=Math.sin(_);f=Math.sin(f*_)/S,o=Math.sin(o*_)/S,l=l*f+d*o,c=c*f+p*o,h=h*f+g*o,u=u*f+v*o}else{l=l*f+d*o,c=c*f+p*o,h=h*f+g*o,u=u*f+v*o;const _=1/Math.sqrt(l*l+c*c+h*h+u*u);l*=_,c*=_,h*=_,u*=_}}e[t]=l,e[t+1]=c,e[t+2]=h,e[t+3]=u}static multiplyQuaternionsFlat(e,t,n,r,s,a){const o=n[r],l=n[r+1],c=n[r+2],h=n[r+3],u=s[a],d=s[a+1],p=s[a+2],g=s[a+3];return e[t]=o*g+h*u+l*p-c*d,e[t+1]=l*g+h*d+c*u-o*p,e[t+2]=c*g+h*p+o*d-l*u,e[t+3]=h*g-o*u-l*d-c*p,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,t,n,r){return this._x=e,this._y=t,this._z=n,this._w=r,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,t=!0){const n=e._x,r=e._y,s=e._z,a=e._order,o=Math.cos,l=Math.sin,c=o(n/2),h=o(r/2),u=o(s/2),d=l(n/2),p=l(r/2),g=l(s/2);switch(a){case"XYZ":this._x=d*h*u+c*p*g,this._y=c*p*u-d*h*g,this._z=c*h*g+d*p*u,this._w=c*h*u-d*p*g;break;case"YXZ":this._x=d*h*u+c*p*g,this._y=c*p*u-d*h*g,this._z=c*h*g-d*p*u,this._w=c*h*u+d*p*g;break;case"ZXY":this._x=d*h*u-c*p*g,this._y=c*p*u+d*h*g,this._z=c*h*g+d*p*u,this._w=c*h*u-d*p*g;break;case"ZYX":this._x=d*h*u-c*p*g,this._y=c*p*u+d*h*g,this._z=c*h*g-d*p*u,this._w=c*h*u+d*p*g;break;case"YZX":this._x=d*h*u+c*p*g,this._y=c*p*u+d*h*g,this._z=c*h*g-d*p*u,this._w=c*h*u-d*p*g;break;case"XZY":this._x=d*h*u-c*p*g,this._y=c*p*u-d*h*g,this._z=c*h*g+d*p*u,this._w=c*h*u+d*p*g;break;default:Pe("Quaternion: .setFromEuler() encountered an unknown order: "+a)}return t===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,t){const n=t/2,r=Math.sin(n);return this._x=e.x*r,this._y=e.y*r,this._z=e.z*r,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(e){const t=e.elements,n=t[0],r=t[4],s=t[8],a=t[1],o=t[5],l=t[9],c=t[2],h=t[6],u=t[10],d=n+o+u;if(d>0){const p=.5/Math.sqrt(d+1);this._w=.25/p,this._x=(h-l)*p,this._y=(s-c)*p,this._z=(a-r)*p}else if(n>o&&n>u){const p=2*Math.sqrt(1+n-o-u);this._w=(h-l)/p,this._x=.25*p,this._y=(r+a)/p,this._z=(s+c)/p}else if(o>u){const p=2*Math.sqrt(1+o-n-u);this._w=(s-c)/p,this._x=(r+a)/p,this._y=.25*p,this._z=(l+h)/p}else{const p=2*Math.sqrt(1+u-n-o);this._w=(a-r)/p,this._x=(s+c)/p,this._y=(l+h)/p,this._z=.25*p}return this._onChangeCallback(),this}setFromUnitVectors(e,t){let n=e.dot(t)+1;return n<1e-8?(n=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=n):(this._x=0,this._y=-e.z,this._z=e.y,this._w=n)):(this._x=e.y*t.z-e.z*t.y,this._y=e.z*t.x-e.x*t.z,this._z=e.x*t.y-e.y*t.x,this._w=n),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(ze(this.dot(e),-1,1)))}rotateTowards(e,t){const n=this.angleTo(e);if(n===0)return this;const r=Math.min(1,t/n);return this.slerp(e,r),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,t){const n=e._x,r=e._y,s=e._z,a=e._w,o=t._x,l=t._y,c=t._z,h=t._w;return this._x=n*h+a*o+r*c-s*l,this._y=r*h+a*l+s*o-n*c,this._z=s*h+a*c+n*l-r*o,this._w=a*h-n*o-r*l-s*c,this._onChangeCallback(),this}slerp(e,t){let n=e._x,r=e._y,s=e._z,a=e._w,o=this.dot(e);o<0&&(n=-n,r=-r,s=-s,a=-a,o=-o);let l=1-t;if(o<.9995){const c=Math.acos(o),h=Math.sin(c);l=Math.sin(l*c)/h,t=Math.sin(t*c)/h,this._x=this._x*l+n*t,this._y=this._y*l+r*t,this._z=this._z*l+s*t,this._w=this._w*l+a*t,this._onChangeCallback()}else this._x=this._x*l+n*t,this._y=this._y*l+r*t,this._z=this._z*l+s*t,this._w=this._w*l+a*t,this.normalize();return this}slerpQuaternions(e,t,n){return this.copy(e).slerp(t,n)}random(){const e=2*Math.PI*Math.random(),t=2*Math.PI*Math.random(),n=Math.random(),r=Math.sqrt(1-n),s=Math.sqrt(n);return this.set(r*Math.sin(e),r*Math.cos(e),s*Math.sin(t),s*Math.cos(t))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,t=0){return this._x=e[t],this._y=e[t+1],this._z=e[t+2],this._w=e[t+3],this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._w,e}fromBufferAttribute(e,t){return this._x=e.getX(t),this._y=e.getY(t),this._z=e.getZ(t),this._w=e.getW(t),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}const Ul=class Ul{constructor(e=0,t=0,n=0){this.x=e,this.y=t,this.z=n}set(e,t,n){return n===void 0&&(n=this.z),this.x=e,this.y=t,this.z=n,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;default:throw new Error("THREE.Vector3: index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("THREE.Vector3: index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,t){return this.x=e.x*t.x,this.y=e.y*t.y,this.z=e.z*t.z,this}applyEuler(e){return this.applyQuaternion(cc.setFromEuler(e))}applyAxisAngle(e,t){return this.applyQuaternion(cc.setFromAxisAngle(e,t))}applyMatrix3(e){const t=this.x,n=this.y,r=this.z,s=e.elements;return this.x=s[0]*t+s[3]*n+s[6]*r,this.y=s[1]*t+s[4]*n+s[7]*r,this.z=s[2]*t+s[5]*n+s[8]*r,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){const t=this.x,n=this.y,r=this.z,s=e.elements,a=1/(s[3]*t+s[7]*n+s[11]*r+s[15]);return this.x=(s[0]*t+s[4]*n+s[8]*r+s[12])*a,this.y=(s[1]*t+s[5]*n+s[9]*r+s[13])*a,this.z=(s[2]*t+s[6]*n+s[10]*r+s[14])*a,this}applyQuaternion(e){const t=this.x,n=this.y,r=this.z,s=e.x,a=e.y,o=e.z,l=e.w,c=2*(a*r-o*n),h=2*(o*t-s*r),u=2*(s*n-a*t);return this.x=t+l*c+a*u-o*h,this.y=n+l*h+o*c-s*u,this.z=r+l*u+s*h-a*c,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){const t=this.x,n=this.y,r=this.z,s=e.elements;return this.x=s[0]*t+s[4]*n+s[8]*r,this.y=s[1]*t+s[5]*n+s[9]*r,this.z=s[2]*t+s[6]*n+s[10]*r,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,t){return this.x=ze(this.x,e.x,t.x),this.y=ze(this.y,e.y,t.y),this.z=ze(this.z,e.z,t.z),this}clampScalar(e,t){return this.x=ze(this.x,e,t),this.y=ze(this.y,e,t),this.z=ze(this.z,e,t),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(ze(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,t){const n=e.x,r=e.y,s=e.z,a=t.x,o=t.y,l=t.z;return this.x=r*l-s*o,this.y=s*a-n*l,this.z=n*o-r*a,this}projectOnVector(e){const t=e.lengthSq();if(t===0)return this.set(0,0,0);const n=e.dot(this)/t;return this.copy(e).multiplyScalar(n)}projectOnPlane(e){return Ma.copy(this).projectOnVector(e),this.sub(Ma)}reflect(e){return this.sub(Ma.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const n=this.dot(e)/t;return Math.acos(ze(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,n=this.y-e.y,r=this.z-e.z;return t*t+n*n+r*r}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,t,n){const r=Math.sin(t)*e;return this.x=r*Math.sin(n),this.y=Math.cos(t)*e,this.z=r*Math.cos(n),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,t,n){return this.x=e*Math.sin(t),this.y=n,this.z=e*Math.cos(t),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this}setFromMatrixScale(e){const t=this.setFromMatrixColumn(e,0).length(),n=this.setFromMatrixColumn(e,1).length(),r=this.setFromMatrixColumn(e,2).length();return this.x=t,this.y=n,this.z=r,this}setFromMatrixColumn(e,t){return this.fromArray(e.elements,t*4)}setFromMatrix3Column(e,t){return this.fromArray(e.elements,t*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const e=Math.random()*Math.PI*2,t=Math.random()*2-1,n=Math.sqrt(1-t*t);return this.x=n*Math.cos(e),this.y=t,this.z=n*Math.sin(e),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}};Ul.prototype.isVector3=!0;let P=Ul;const Ma=new P,cc=new ui,Fl=class Fl{constructor(e,t,n,r,s,a,o,l,c){this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,t,n,r,s,a,o,l,c)}set(e,t,n,r,s,a,o,l,c){const h=this.elements;return h[0]=e,h[1]=r,h[2]=o,h[3]=t,h[4]=s,h[5]=l,h[6]=n,h[7]=a,h[8]=c,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){const t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],this}extractBasis(e,t,n){return e.setFromMatrix3Column(this,0),t.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(e){const t=e.elements;return this.set(t[0],t[4],t[8],t[1],t[5],t[9],t[2],t[6],t[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const n=e.elements,r=t.elements,s=this.elements,a=n[0],o=n[3],l=n[6],c=n[1],h=n[4],u=n[7],d=n[2],p=n[5],g=n[8],v=r[0],m=r[3],f=r[6],_=r[1],S=r[4],y=r[7],A=r[2],E=r[5],x=r[8];return s[0]=a*v+o*_+l*A,s[3]=a*m+o*S+l*E,s[6]=a*f+o*y+l*x,s[1]=c*v+h*_+u*A,s[4]=c*m+h*S+u*E,s[7]=c*f+h*y+u*x,s[2]=d*v+p*_+g*A,s[5]=d*m+p*S+g*E,s[8]=d*f+p*y+g*x,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[3]*=e,t[6]*=e,t[1]*=e,t[4]*=e,t[7]*=e,t[2]*=e,t[5]*=e,t[8]*=e,this}determinant(){const e=this.elements,t=e[0],n=e[1],r=e[2],s=e[3],a=e[4],o=e[5],l=e[6],c=e[7],h=e[8];return t*a*h-t*o*c-n*s*h+n*o*l+r*s*c-r*a*l}invert(){const e=this.elements,t=e[0],n=e[1],r=e[2],s=e[3],a=e[4],o=e[5],l=e[6],c=e[7],h=e[8],u=h*a-o*c,d=o*l-h*s,p=c*s-a*l,g=t*u+n*d+r*p;if(g===0)return this.set(0,0,0,0,0,0,0,0,0);const v=1/g;return e[0]=u*v,e[1]=(r*c-h*n)*v,e[2]=(o*n-r*a)*v,e[3]=d*v,e[4]=(h*t-r*l)*v,e[5]=(r*s-o*t)*v,e[6]=p*v,e[7]=(n*l-c*t)*v,e[8]=(a*t-n*s)*v,this}transpose(){let e;const t=this.elements;return e=t[1],t[1]=t[3],t[3]=e,e=t[2],t[2]=t[6],t[6]=e,e=t[5],t[5]=t[7],t[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){const t=this.elements;return e[0]=t[0],e[1]=t[3],e[2]=t[6],e[3]=t[1],e[4]=t[4],e[5]=t[7],e[6]=t[2],e[7]=t[5],e[8]=t[8],this}setUvTransform(e,t,n,r,s,a,o){const l=Math.cos(s),c=Math.sin(s);return this.set(n*l,n*c,-n*(l*a+c*o)+a+e,-r*c,r*l,-r*(-c*a+l*o)+o+t,0,0,1),this}scale(e,t){return Hs("Matrix3: .scale() is deprecated. Use .makeScale() instead."),this.premultiply(ba.makeScale(e,t)),this}rotate(e){return Hs("Matrix3: .rotate() is deprecated. Use .makeRotation() instead."),this.premultiply(ba.makeRotation(-e)),this}translate(e,t){return Hs("Matrix3: .translate() is deprecated. Use .makeTranslation() instead."),this.premultiply(ba.makeTranslation(e,t)),this}makeTranslation(e,t){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,t,0,0,1),this}makeRotation(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,n,t,0,0,0,1),this}makeScale(e,t){return this.set(e,0,0,0,t,0,0,0,1),this}equals(e){const t=this.elements,n=e.elements;for(let r=0;r<9;r++)if(t[r]!==n[r])return!1;return!0}fromArray(e,t=0){for(let n=0;n<9;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){const n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e}clone(){return new this.constructor().fromArray(this.elements)}};Fl.prototype.isMatrix3=!0;let Ie=Fl;const ba=new Ie,hc=new Ie().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),uc=new Ie().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function Af(){const i={enabled:!0,workingColorSpace:Js,spaces:{},convert:function(r,s,a){return this.enabled===!1||s===a||!s||!a||(this.spaces[s].transfer===et&&(r.r=qn(r.r),r.g=qn(r.g),r.b=qn(r.b)),this.spaces[s].primaries!==this.spaces[a].primaries&&(r.applyMatrix3(this.spaces[s].toXYZ),r.applyMatrix3(this.spaces[a].fromXYZ)),this.spaces[a].transfer===et&&(r.r=ji(r.r),r.g=ji(r.g),r.b=ji(r.b))),r},workingToColorSpace:function(r,s){return this.convert(r,this.workingColorSpace,s)},colorSpaceToWorking:function(r,s){return this.convert(r,s,this.workingColorSpace)},getPrimaries:function(r){return this.spaces[r].primaries},getTransfer:function(r){return r===ni?Qs:this.spaces[r].transfer},getToneMappingMode:function(r){return this.spaces[r].outputColorSpaceConfig.toneMappingMode||"standard"},getLuminanceCoefficients:function(r,s=this.workingColorSpace){return r.fromArray(this.spaces[s].luminanceCoefficients)},define:function(r){Object.assign(this.spaces,r)},_getMatrix:function(r,s,a){return r.copy(this.spaces[a].fromXYZ).multiply(this.spaces[s].toXYZ)},_getDrawingBufferColorSpace:function(r){return this.spaces[r].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(r=this.workingColorSpace){return this.spaces[r].workingColorSpaceConfig.unpackColorSpace}},e=[.64,.33,.3,.6,.15,.06],t=[.2126,.7152,.0722],n=[.3127,.329];return i.define({[Js]:{primaries:e,whitePoint:n,transfer:Qs,toXYZ:hc,fromXYZ:uc,luminanceCoefficients:t,workingColorSpaceConfig:{unpackColorSpace:Ot},outputColorSpaceConfig:{drawingBufferColorSpace:Ot}},[Ot]:{primaries:e,whitePoint:n,transfer:et,toXYZ:hc,fromXYZ:uc,luminanceCoefficients:t,outputColorSpaceConfig:{drawingBufferColorSpace:Ot}}}),i}const qe=Af();function qn(i){return i<.04045?i*.0773993808:Math.pow(i*.9478672986+.0521327014,2.4)}function ji(i){return i<.0031308?i*12.92:1.055*Math.pow(i,.41666)-.055}let Ii;class Rf{static getDataURL(e,t="image/png"){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>"u")return e.src;let n;if(e instanceof HTMLCanvasElement)n=e;else{Ii===void 0&&(Ii=js("canvas")),Ii.width=e.width,Ii.height=e.height;const r=Ii.getContext("2d");e instanceof ImageData?r.putImageData(e,0,0):r.drawImage(e,0,0,e.width,e.height),n=Ii}return n.toDataURL(t)}static sRGBToLinear(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){const t=js("canvas");t.width=e.width,t.height=e.height;const n=t.getContext("2d");n.drawImage(e,0,0,e.width,e.height);const r=n.getImageData(0,0,e.width,e.height),s=r.data;for(let a=0;a<s.length;a++)s[a]=qn(s[a]/255)*255;return n.putImageData(r,0,0),t}else if(e.data){const t=e.data.slice(0);for(let n=0;n<t.length;n++)t instanceof Uint8Array||t instanceof Uint8ClampedArray?t[n]=Math.floor(qn(t[n]/255)*255):t[n]=qn(t[n]);return{data:t,width:e.width,height:e.height}}else return Pe("ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}}let Cf=0;class Ml{constructor(e=null){this.isTextureSource=!0,Object.defineProperty(this,"id",{value:Cf++}),this.uuid=$n(),this.data=e,this.dataReady=!0,this.version=0}getSize(e){const t=this.data;return typeof HTMLVideoElement<"u"&&t instanceof HTMLVideoElement?e.set(t.videoWidth,t.videoHeight,0):typeof VideoFrame<"u"&&t instanceof VideoFrame?e.set(t.displayWidth,t.displayHeight,0):t!==null?e.set(t.width||0,t.height||0,t.depth||0):e.set(0,0,0),e}set needsUpdate(e){e===!0&&this.version++}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.images[this.uuid]!==void 0)return e.images[this.uuid];const n={uuid:this.uuid,url:""},r=this.data;if(r!==null){let s;if(Array.isArray(r)){s=[];for(let a=0,o=r.length;a<o;a++)r[a].isDataTexture?s.push(Sa(r[a].image)):s.push(Sa(r[a]))}else s=Sa(r);n.url=s}return t||(e.images[this.uuid]=n),n}}function Sa(i){return typeof HTMLImageElement<"u"&&i instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&i instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&i instanceof ImageBitmap?Rf.getDataURL(i):i.data?{data:Array.from(i.data),width:i.width,height:i.height,type:i.data.constructor.name}:(Pe("Texture: Unable to serialize Texture."),{})}let Pf=0;const wa=new P;class kt extends Ci{constructor(e=kt.DEFAULT_IMAGE,t=kt.DEFAULT_MAPPING,n=Vn,r=Vn,s=Yt,a=ii,o=Cn,l=Qt,c=kt.DEFAULT_ANISOTROPY,h=ni){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:Pf++}),this.uuid=$n(),this.name="",this.source=new Ml(e),this.mipmaps=[],this.mapping=t,this.channel=0,this.wrapS=n,this.wrapT=r,this.magFilter=s,this.minFilter=a,this.anisotropy=c,this.format=o,this.internalFormat=null,this.type=l,this.offset=new de(0,0),this.repeat=new de(1,1),this.center=new de(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new Ie,this.generateMipmaps=!0,this.mipmapsAutoUpdate=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=h,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(e&&e.depth&&e.depth>1),this.pmremVersion=0,this.isPMREMTexture=!1,this.normalized=!1}get width(){return this.source.getSize(wa).x}get height(){return this.source.getSize(wa).y}get depth(){return this.source.getSize(wa).z}get image(){return this.source.data}set image(e){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.normalized=e.normalized,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.mipmapsAutoUpdate=e.mipmapsAutoUpdate,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.renderTarget=e.renderTarget,this.isRenderTargetTexture=e.isRenderTargetTexture,this.isPMREMTexture=e.isPMREMTexture,this.isArrayTexture=e.isArrayTexture,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}setValues(e){for(const t in e){const n=e[t];if(n===void 0){Pe(`Texture.setValues(): parameter '${t}' has value of undefined.`);continue}const r=this[t];if(r===void 0){Pe(`Texture.setValues(): property '${t}' does not exist.`);continue}r&&n&&r.isVector2&&n.isVector2||r&&n&&r.isVector3&&n.isVector3||r&&n&&r.isMatrix3&&n.isMatrix3?r.copy(n):this[t]=n}}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];const n={metadata:{version:4.7,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,normalized:this.normalized,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,mipmapsAutoUpdate:this.mipmapsAutoUpdate,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),t||(e.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(e){if(this.mapping!==nu)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case oo:e.x=e.x-Math.floor(e.x);break;case Vn:e.x=e.x<0?0:1;break;case lo:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x=e.x-Math.floor(e.x);break}if(e.y<0||e.y>1)switch(this.wrapT){case oo:e.y=e.y-Math.floor(e.y);break;case Vn:e.y=e.y<0?0:1;break;case lo:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y=e.y-Math.floor(e.y);break}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(e){e===!0&&this.pmremVersion++}}kt.DEFAULT_IMAGE=null;kt.DEFAULT_MAPPING=nu;kt.DEFAULT_ANISOTROPY=1;const Ol=class Ol{constructor(e=0,t=0,n=0,r=1){this.x=e,this.y=t,this.z=n,this.w=r}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,t,n,r){return this.x=e,this.y=t,this.z=n,this.w=r,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;case 3:this.w=t;break;default:throw new Error("THREE.Vector4: index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("THREE.Vector4: index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w!==void 0?e.w:1,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this.w=e.w+t.w,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this.w+=e.w*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this.w=e.w-t.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){const t=this.x,n=this.y,r=this.z,s=this.w,a=e.elements;return this.x=a[0]*t+a[4]*n+a[8]*r+a[12]*s,this.y=a[1]*t+a[5]*n+a[9]*r+a[13]*s,this.z=a[2]*t+a[6]*n+a[10]*r+a[14]*s,this.w=a[3]*t+a[7]*n+a[11]*r+a[15]*s,this}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this.w/=e.w,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);const t=Math.sqrt(1-e.w*e.w);return t<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/t,this.y=e.y/t,this.z=e.z/t),this}setAxisAngleFromRotationMatrix(e){let t,n,r,s;const l=e.elements,c=l[0],h=l[4],u=l[8],d=l[1],p=l[5],g=l[9],v=l[2],m=l[6],f=l[10];if(Math.abs(h-d)<.01&&Math.abs(u-v)<.01&&Math.abs(g-m)<.01){if(Math.abs(h+d)<.1&&Math.abs(u+v)<.1&&Math.abs(g+m)<.1&&Math.abs(c+p+f-3)<.1)return this.set(1,0,0,0),this;t=Math.PI;const S=(c+1)/2,y=(p+1)/2,A=(f+1)/2,E=(h+d)/4,x=(u+v)/4,w=(g+m)/4;return S>y&&S>A?S<.01?(n=0,r=.707106781,s=.707106781):(n=Math.sqrt(S),r=E/n,s=x/n):y>A?y<.01?(n=.707106781,r=0,s=.707106781):(r=Math.sqrt(y),n=E/r,s=w/r):A<.01?(n=.707106781,r=.707106781,s=0):(s=Math.sqrt(A),n=x/s,r=w/s),this.set(n,r,s,t),this}let _=Math.sqrt((m-g)*(m-g)+(u-v)*(u-v)+(d-h)*(d-h));return Math.abs(_)<.001&&(_=1),this.x=(m-g)/_,this.y=(u-v)/_,this.z=(d-h)/_,this.w=Math.acos((c+p+f-1)/2),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this.w=t[15],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,t){return this.x=ze(this.x,e.x,t.x),this.y=ze(this.y,e.y,t.y),this.z=ze(this.z,e.z,t.z),this.w=ze(this.w,e.w,t.w),this}clampScalar(e,t){return this.x=ze(this.x,e,t),this.y=ze(this.y,e,t),this.z=ze(this.z,e,t),this.w=ze(this.w,e,t),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(ze(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this.w+=(e.w-this.w)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this.w=e.w+(t.w-e.w)*n,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this.w=e[t+3],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e[t+3]=this.w,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this.w=e.getW(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}};Ol.prototype.isVector4=!0;let dt=Ol;class Lf extends Ci{constructor(e=1,t=1,n={}){super(),n=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:Yt,depthBuffer:!0,stencilBuffer:!1,resolveColorBuffer:!0,resolveDepthBuffer:!0,resolveStencilBuffer:!0,storeMultisampledColorBuffer:!0,storeMultisampledDepthBuffer:!0,storeMultisampledStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1,useArrayDepthTexture:!1},n),this.isRenderTarget=!0,this.width=e,this.height=t,this.depth=n.depth,this.scissor=new dt(0,0,e,t),this.scissorTest=!1,this.viewport=new dt(0,0,e,t),this.textures=[];const r=n.count;for(let s=0;s<r;s++)this.textures[s]=new kt({width:e,height:t,depth:n.depth}),this.textures[s].isRenderTargetTexture=!0,this.textures[s].renderTarget=this;this._setTextureOptions(n),this.depthBuffer=n.depthBuffer,this.stencilBuffer=n.stencilBuffer,this.resolveColorBuffer=n.resolveColorBuffer,this.resolveDepthBuffer=n.resolveDepthBuffer,this.resolveStencilBuffer=n.resolveStencilBuffer,this.storeMultisampledColorBuffer=n.storeMultisampledColorBuffer,this.storeMultisampledDepthBuffer=n.storeMultisampledDepthBuffer,this.storeMultisampledStencilBuffer=n.storeMultisampledStencilBuffer,this._depthTexture=null,this.depthTexture=n.depthTexture,this.samples=n.samples,this.multiview=n.multiview,this.useArrayDepthTexture=n.useArrayDepthTexture}_setTextureOptions(e={}){const t={minFilter:Yt,generateMipmaps:!1,flipY:!1,internalFormat:null};e.mapping!==void 0&&(t.mapping=e.mapping),e.wrapS!==void 0&&(t.wrapS=e.wrapS),e.wrapT!==void 0&&(t.wrapT=e.wrapT),e.wrapR!==void 0&&(t.wrapR=e.wrapR),e.magFilter!==void 0&&(t.magFilter=e.magFilter),e.minFilter!==void 0&&(t.minFilter=e.minFilter),e.format!==void 0&&(t.format=e.format),e.type!==void 0&&(t.type=e.type),e.anisotropy!==void 0&&(t.anisotropy=e.anisotropy),e.colorSpace!==void 0&&(t.colorSpace=e.colorSpace),e.flipY!==void 0&&(t.flipY=e.flipY),e.generateMipmaps!==void 0&&(t.generateMipmaps=e.generateMipmaps),e.mipmapsAutoUpdate!==void 0&&(t.mipmapsAutoUpdate=e.mipmapsAutoUpdate),e.internalFormat!==void 0&&(t.internalFormat=e.internalFormat);for(let n=0;n<this.textures.length;n++)this.textures[n].setValues(t)}get texture(){return this.textures[0]}set texture(e){this.textures[0]=e}set depthTexture(e){this._depthTexture!==null&&this._depthTexture.renderTarget===this&&(this._depthTexture.renderTarget=null),e!==null&&e.renderTarget===null&&(e.renderTarget=this),this._depthTexture=e}get depthTexture(){return this._depthTexture}setSize(e,t,n=1){if(this.width!==e||this.height!==t||this.depth!==n){this.width=e,this.height=t,this.depth=n;for(let r=0,s=this.textures.length;r<s;r++)this.textures[r].image.width=e,this.textures[r].image.height=t,this.textures[r].image.depth=n,this.textures[r].isData3DTexture!==!0&&(this.textures[r].isArrayTexture=this.textures[r].image.depth>1);this.dispose()}this.viewport.set(0,0,e,t),this.scissor.set(0,0,e,t)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.textures.length=0;for(let t=0,n=e.textures.length;t<n;t++){this.textures[t]=e.textures[t].clone(),this.textures[t].isRenderTargetTexture=!0,this.textures[t].renderTarget=this;const r=Object.assign({},e.textures[t].image);this.textures[t].source=new Ml(r)}if(this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,this.resolveColorBuffer=e.resolveColorBuffer,this.resolveDepthBuffer=e.resolveDepthBuffer,this.resolveStencilBuffer=e.resolveStencilBuffer,this.storeMultisampledColorBuffer=e.storeMultisampledColorBuffer,this.storeMultisampledDepthBuffer=e.storeMultisampledDepthBuffer,this.storeMultisampledStencilBuffer=e.storeMultisampledStencilBuffer,e.depthTexture!==null)if(e.depthTexture.renderTarget===e){const t=e.depthTexture.clone();t.renderTarget=null,this.depthTexture=t}else this.depthTexture=e.depthTexture;else this.depthTexture=null;return this.samples=e.samples,this.multiview=e.multiview,this.useArrayDepthTexture=e.useArrayDepthTexture,this}dispose(){this.dispatchEvent({type:"dispose"})}}class Mn extends Lf{constructor(e=1,t=1,n={}){super(e,t,n),this.isWebGLRenderTarget=!0}}class mu extends kt{constructor(e=null,t=1,n=1,r=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:t,height:n,depth:r},this.magFilter=Dt,this.minFilter=Dt,this.wrapR=Vn,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}copy(e){return super.copy(e),this.wrapR=e.wrapR,this}addLayerUpdate(e){this.layerUpdates.add(e)}clearLayerUpdates(){this.layerUpdates.clear()}}class Df extends kt{constructor(e=null,t=1,n=1,r=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:t,height:n,depth:r},this.magFilter=Dt,this.minFilter=Dt,this.wrapR=Vn,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}copy(e){return super.copy(e),this.wrapR=e.wrapR,this}}const aa=class aa{constructor(e,t,n,r,s,a,o,l,c,h,u,d,p,g,v,m){this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,t,n,r,s,a,o,l,c,h,u,d,p,g,v,m)}set(e,t,n,r,s,a,o,l,c,h,u,d,p,g,v,m){const f=this.elements;return f[0]=e,f[4]=t,f[8]=n,f[12]=r,f[1]=s,f[5]=a,f[9]=o,f[13]=l,f[2]=c,f[6]=h,f[10]=u,f[14]=d,f[3]=p,f[7]=g,f[11]=v,f[15]=m,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new aa().fromArray(this.elements)}copy(e){const t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],t[9]=n[9],t[10]=n[10],t[11]=n[11],t[12]=n[12],t[13]=n[13],t[14]=n[14],t[15]=n[15],this}copyPosition(e){const t=this.elements,n=e.elements;return t[12]=n[12],t[13]=n[13],t[14]=n[14],this}setFromMatrix3(e){const t=e.elements;return this.set(t[0],t[3],t[6],0,t[1],t[4],t[7],0,t[2],t[5],t[8],0,0,0,0,1),this}extractBasis(e,t,n){return this.determinantAffine()===0?(e.set(1,0,0),t.set(0,1,0),n.set(0,0,1),this):(e.setFromMatrixColumn(this,0),t.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this)}makeBasis(e,t,n){return this.set(e.x,t.x,n.x,0,e.y,t.y,n.y,0,e.z,t.z,n.z,0,0,0,0,1),this}extractRotation(e){if(e.determinantAffine()===0)return this.identity();const t=this.elements,n=e.elements,r=1/Ni.setFromMatrixColumn(e,0).length(),s=1/Ni.setFromMatrixColumn(e,1).length(),a=1/Ni.setFromMatrixColumn(e,2).length();return t[0]=n[0]*r,t[1]=n[1]*r,t[2]=n[2]*r,t[3]=0,t[4]=n[4]*s,t[5]=n[5]*s,t[6]=n[6]*s,t[7]=0,t[8]=n[8]*a,t[9]=n[9]*a,t[10]=n[10]*a,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromEuler(e){const t=this.elements,n=e.x,r=e.y,s=e.z,a=Math.cos(n),o=Math.sin(n),l=Math.cos(r),c=Math.sin(r),h=Math.cos(s),u=Math.sin(s);if(e.order==="XYZ"){const d=a*h,p=a*u,g=o*h,v=o*u;t[0]=l*h,t[4]=-l*u,t[8]=c,t[1]=p+g*c,t[5]=d-v*c,t[9]=-o*l,t[2]=v-d*c,t[6]=g+p*c,t[10]=a*l}else if(e.order==="YXZ"){const d=l*h,p=l*u,g=c*h,v=c*u;t[0]=d+v*o,t[4]=g*o-p,t[8]=a*c,t[1]=a*u,t[5]=a*h,t[9]=-o,t[2]=p*o-g,t[6]=v+d*o,t[10]=a*l}else if(e.order==="ZXY"){const d=l*h,p=l*u,g=c*h,v=c*u;t[0]=d-v*o,t[4]=-a*u,t[8]=g+p*o,t[1]=p+g*o,t[5]=a*h,t[9]=v-d*o,t[2]=-a*c,t[6]=o,t[10]=a*l}else if(e.order==="ZYX"){const d=a*h,p=a*u,g=o*h,v=o*u;t[0]=l*h,t[4]=g*c-p,t[8]=d*c+v,t[1]=l*u,t[5]=v*c+d,t[9]=p*c-g,t[2]=-c,t[6]=o*l,t[10]=a*l}else if(e.order==="YZX"){const d=a*l,p=a*c,g=o*l,v=o*c;t[0]=l*h,t[4]=v-d*u,t[8]=g*u+p,t[1]=u,t[5]=a*h,t[9]=-o*h,t[2]=-c*h,t[6]=p*u+g,t[10]=d-v*u}else if(e.order==="XZY"){const d=a*l,p=a*c,g=o*l,v=o*c;t[0]=l*h,t[4]=-u,t[8]=c*h,t[1]=d*u+v,t[5]=a*h,t[9]=p*u-g,t[2]=g*u-p,t[6]=o*h,t[10]=v*u+d}return t[3]=0,t[7]=0,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromQuaternion(e){return this.compose(If,e,Nf)}lookAt(e,t,n){const r=this.elements;return Zt.subVectors(e,t),Zt.lengthSq()===0&&(Zt.z=1),Zt.normalize(),Zn.crossVectors(n,Zt),Zn.lengthSq()===0&&(Math.abs(n.z)===1?Zt.x+=1e-4:Zt.z+=1e-4,Zt.normalize(),Zn.crossVectors(n,Zt)),Zn.normalize(),ts.crossVectors(Zt,Zn),r[0]=Zn.x,r[4]=ts.x,r[8]=Zt.x,r[1]=Zn.y,r[5]=ts.y,r[9]=Zt.y,r[2]=Zn.z,r[6]=ts.z,r[10]=Zt.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const n=e.elements,r=t.elements,s=this.elements,a=n[0],o=n[4],l=n[8],c=n[12],h=n[1],u=n[5],d=n[9],p=n[13],g=n[2],v=n[6],m=n[10],f=n[14],_=n[3],S=n[7],y=n[11],A=n[15],E=r[0],x=r[4],w=r[8],I=r[12],C=r[1],N=r[5],F=r[9],V=r[13],D=r[2],H=r[6],Z=r[10],z=r[14],ne=r[3],q=r[7],j=r[11],ee=r[15];return s[0]=a*E+o*C+l*D+c*ne,s[4]=a*x+o*N+l*H+c*q,s[8]=a*w+o*F+l*Z+c*j,s[12]=a*I+o*V+l*z+c*ee,s[1]=h*E+u*C+d*D+p*ne,s[5]=h*x+u*N+d*H+p*q,s[9]=h*w+u*F+d*Z+p*j,s[13]=h*I+u*V+d*z+p*ee,s[2]=g*E+v*C+m*D+f*ne,s[6]=g*x+v*N+m*H+f*q,s[10]=g*w+v*F+m*Z+f*j,s[14]=g*I+v*V+m*z+f*ee,s[3]=_*E+S*C+y*D+A*ne,s[7]=_*x+S*N+y*H+A*q,s[11]=_*w+S*F+y*Z+A*j,s[15]=_*I+S*V+y*z+A*ee,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[4]*=e,t[8]*=e,t[12]*=e,t[1]*=e,t[5]*=e,t[9]*=e,t[13]*=e,t[2]*=e,t[6]*=e,t[10]*=e,t[14]*=e,t[3]*=e,t[7]*=e,t[11]*=e,t[15]*=e,this}determinant(){const e=this.elements,t=e[0],n=e[4],r=e[8],s=e[12],a=e[1],o=e[5],l=e[9],c=e[13],h=e[2],u=e[6],d=e[10],p=e[14],g=e[3],v=e[7],m=e[11],f=e[15],_=l*p-c*d,S=o*p-c*u,y=o*d-l*u,A=a*p-c*h,E=a*d-l*h,x=a*u-o*h;return t*(v*_-m*S+f*y)-n*(g*_-m*A+f*E)+r*(g*S-v*A+f*x)-s*(g*y-v*E+m*x)}determinantAffine(){const e=this.elements,t=e[0],n=e[4],r=e[8],s=e[1],a=e[5],o=e[9],l=e[2],c=e[6],h=e[10];return t*(a*h-o*c)-n*(s*h-o*l)+r*(s*c-a*l)}transpose(){const e=this.elements;let t;return t=e[1],e[1]=e[4],e[4]=t,t=e[2],e[2]=e[8],e[8]=t,t=e[6],e[6]=e[9],e[9]=t,t=e[3],e[3]=e[12],e[12]=t,t=e[7],e[7]=e[13],e[13]=t,t=e[11],e[11]=e[14],e[14]=t,this}setPosition(e,t,n){const r=this.elements;return e.isVector3?(r[12]=e.x,r[13]=e.y,r[14]=e.z):(r[12]=e,r[13]=t,r[14]=n),this}invert(){const e=this.elements,t=e[0],n=e[1],r=e[2],s=e[3],a=e[4],o=e[5],l=e[6],c=e[7],h=e[8],u=e[9],d=e[10],p=e[11],g=e[12],v=e[13],m=e[14],f=e[15],_=t*o-n*a,S=t*l-r*a,y=t*c-s*a,A=n*l-r*o,E=n*c-s*o,x=r*c-s*l,w=h*v-u*g,I=h*m-d*g,C=h*f-p*g,N=u*m-d*v,F=u*f-p*v,V=d*f-p*m,D=_*V-S*F+y*N+A*C-E*I+x*w;if(D===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const H=1/D;return e[0]=(o*V-l*F+c*N)*H,e[1]=(r*F-n*V-s*N)*H,e[2]=(v*x-m*E+f*A)*H,e[3]=(d*E-u*x-p*A)*H,e[4]=(l*C-a*V-c*I)*H,e[5]=(t*V-r*C+s*I)*H,e[6]=(m*y-g*x-f*S)*H,e[7]=(h*x-d*y+p*S)*H,e[8]=(a*F-o*C+c*w)*H,e[9]=(n*C-t*F-s*w)*H,e[10]=(g*E-v*y+f*_)*H,e[11]=(u*y-h*E-p*_)*H,e[12]=(o*I-a*N-l*w)*H,e[13]=(t*N-n*I+r*w)*H,e[14]=(v*S-g*A-m*_)*H,e[15]=(h*A-u*S+d*_)*H,this}scale(e){const t=this.elements,n=e.x,r=e.y,s=e.z;return t[0]*=n,t[4]*=r,t[8]*=s,t[1]*=n,t[5]*=r,t[9]*=s,t[2]*=n,t[6]*=r,t[10]*=s,t[3]*=n,t[7]*=r,t[11]*=s,this}getMaxScaleOnAxis(){const e=this.elements,t=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],n=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],r=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(t,n,r))}makeTranslation(e,t,n){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,t,0,0,1,n,0,0,0,1),this}makeRotationX(e){const t=Math.cos(e),n=Math.sin(e);return this.set(1,0,0,0,0,t,-n,0,0,n,t,0,0,0,0,1),this}makeRotationY(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,0,n,0,0,1,0,0,-n,0,t,0,0,0,0,1),this}makeRotationZ(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,0,n,t,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,t){const n=Math.cos(t),r=Math.sin(t),s=1-n,a=e.x,o=e.y,l=e.z,c=s*a,h=s*o;return this.set(c*a+n,c*o-r*l,c*l+r*o,0,c*o+r*l,h*o+n,h*l-r*a,0,c*l-r*o,h*l+r*a,s*l*l+n,0,0,0,0,1),this}makeScale(e,t,n){return this.set(e,0,0,0,0,t,0,0,0,0,n,0,0,0,0,1),this}makeShear(e,t,n,r,s,a){return this.set(1,n,s,0,e,1,a,0,t,r,1,0,0,0,0,1),this}compose(e,t,n){const r=this.elements,s=t._x,a=t._y,o=t._z,l=t._w,c=s+s,h=a+a,u=o+o,d=s*c,p=s*h,g=s*u,v=a*h,m=a*u,f=o*u,_=l*c,S=l*h,y=l*u,A=n.x,E=n.y,x=n.z;return r[0]=(1-(v+f))*A,r[1]=(p+y)*A,r[2]=(g-S)*A,r[3]=0,r[4]=(p-y)*E,r[5]=(1-(d+f))*E,r[6]=(m+_)*E,r[7]=0,r[8]=(g+S)*x,r[9]=(m-_)*x,r[10]=(1-(d+v))*x,r[11]=0,r[12]=e.x,r[13]=e.y,r[14]=e.z,r[15]=1,this}decompose(e,t,n){const r=this.elements;e.x=r[12],e.y=r[13],e.z=r[14];const s=this.determinantAffine();if(s===0)return n.set(1,1,1),t.identity(),this;let a=Ni.set(r[0],r[1],r[2]).length();const o=Ni.set(r[4],r[5],r[6]).length(),l=Ni.set(r[8],r[9],r[10]).length();s<0&&(a=-a),dn.copy(this);const c=1/a,h=1/o,u=1/l;return dn.elements[0]*=c,dn.elements[1]*=c,dn.elements[2]*=c,dn.elements[4]*=h,dn.elements[5]*=h,dn.elements[6]*=h,dn.elements[8]*=u,dn.elements[9]*=u,dn.elements[10]*=u,t.setFromRotationMatrix(dn),n.x=a,n.y=o,n.z=l,this}makePerspective(e,t,n,r,s,a,o=yn,l=!1){const c=this.elements,h=2*s/(t-e),u=2*s/(n-r),d=(t+e)/(t-e),p=(n+r)/(n-r);let g,v;if(l)g=s/(a-s),v=a*s/(a-s);else if(o===yn)g=-(a+s)/(a-s),v=-2*a*s/(a-s);else if(o===kr)g=-a/(a-s),v=-a*s/(a-s);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+o);return c[0]=h,c[4]=0,c[8]=d,c[12]=0,c[1]=0,c[5]=u,c[9]=p,c[13]=0,c[2]=0,c[6]=0,c[10]=g,c[14]=v,c[3]=0,c[7]=0,c[11]=-1,c[15]=0,this}makeOrthographic(e,t,n,r,s,a,o=yn,l=!1){const c=this.elements,h=2/(t-e),u=2/(n-r),d=-(t+e)/(t-e),p=-(n+r)/(n-r);let g,v;if(l)g=1/(a-s),v=a/(a-s);else if(o===yn)g=-2/(a-s),v=-(a+s)/(a-s);else if(o===kr)g=-1/(a-s),v=-s/(a-s);else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+o);return c[0]=h,c[4]=0,c[8]=0,c[12]=d,c[1]=0,c[5]=u,c[9]=0,c[13]=p,c[2]=0,c[6]=0,c[10]=g,c[14]=v,c[3]=0,c[7]=0,c[11]=0,c[15]=1,this}equals(e){const t=this.elements,n=e.elements;for(let r=0;r<16;r++)if(t[r]!==n[r])return!1;return!0}fromArray(e,t=0){for(let n=0;n<16;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){const n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e[t+9]=n[9],e[t+10]=n[10],e[t+11]=n[11],e[t+12]=n[12],e[t+13]=n[13],e[t+14]=n[14],e[t+15]=n[15],e}};aa.prototype.isMatrix4=!0;let Ye=aa;const Ni=new P,dn=new Ye,If=new P(0,0,0),Nf=new P(1,1,1),Zn=new P,ts=new P,Zt=new P,dc=new Ye,fc=new ui;class Dn{constructor(e=0,t=0,n=0,r=Dn.DEFAULT_ORDER){this.isEuler=!0,this._x=e,this._y=t,this._z=n,this._order=r}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,t,n,r=this._order){return this._x=e,this._y=t,this._z=n,this._order=r,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,t=this._order,n=!0){const r=e.elements,s=r[0],a=r[4],o=r[8],l=r[1],c=r[5],h=r[9],u=r[2],d=r[6],p=r[10];switch(t){case"XYZ":this._y=Math.asin(ze(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(-h,p),this._z=Math.atan2(-a,s)):(this._x=Math.atan2(d,c),this._z=0);break;case"YXZ":this._x=Math.asin(-ze(h,-1,1)),Math.abs(h)<.9999999?(this._y=Math.atan2(o,p),this._z=Math.atan2(l,c)):(this._y=Math.atan2(-u,s),this._z=0);break;case"ZXY":this._x=Math.asin(ze(d,-1,1)),Math.abs(d)<.9999999?(this._y=Math.atan2(-u,p),this._z=Math.atan2(-a,c)):(this._y=0,this._z=Math.atan2(l,s));break;case"ZYX":this._y=Math.asin(-ze(u,-1,1)),Math.abs(u)<.9999999?(this._x=Math.atan2(d,p),this._z=Math.atan2(l,s)):(this._x=0,this._z=Math.atan2(-a,c));break;case"YZX":this._z=Math.asin(ze(l,-1,1)),Math.abs(l)<.9999999?(this._x=Math.atan2(-h,c),this._y=Math.atan2(-u,s)):(this._x=0,this._y=Math.atan2(o,p));break;case"XZY":this._z=Math.asin(-ze(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(d,c),this._y=Math.atan2(o,s)):(this._x=Math.atan2(-h,p),this._y=0);break;default:Pe("Euler: .setFromRotationMatrix() encountered an unknown order: "+t)}return this._order=t,n===!0&&this._onChangeCallback(),this}setFromQuaternion(e,t,n){return dc.makeRotationFromQuaternion(e),this.setFromRotationMatrix(dc,t,n)}setFromVector3(e,t=this._order){return this.set(e.x,e.y,e.z,t)}reorder(e){return fc.setFromEuler(this),this.setFromQuaternion(fc,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}Dn.DEFAULT_ORDER="XYZ";class bl{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return(this.mask&(1<<e|0))!==0}}let Uf=0;const pc=new P,Ui=new ui,Un=new Ye,ns=new P,hr=new P,Ff=new P,Of=new ui,mc=new P(1,0,0),gc=new P(0,1,0),vc=new P(0,0,1),xc={type:"added"},Bf={type:"removed"},Fi={type:"childadded",child:null},Ea={type:"childremoved",child:null};class yt extends Ci{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:Uf++}),this.uuid=$n(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=yt.DEFAULT_UP.clone();const e=new P,t=new Dn,n=new ui,r=new P(1,1,1);function s(){n.setFromEuler(t,!1)}function a(){t.setFromQuaternion(n,void 0,!1)}t._onChange(s),n._onChange(a),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:e},rotation:{configurable:!0,enumerable:!0,value:t},quaternion:{configurable:!0,enumerable:!0,value:n},scale:{configurable:!0,enumerable:!0,value:r},modelViewMatrix:{value:new Ye},normalMatrix:{value:new Ie}}),this.matrix=new Ye,this.matrixWorld=new Ye,this.matrixAutoUpdate=yt.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=yt.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new bl,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.static=!1,this.userData={},this.pivot=null}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale),this.pivot!==null&&this.position.copy(this.pivot).applyMatrix4(this.matrix).sub(this.pivot)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,t){this.quaternion.setFromAxisAngle(e,t)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,t){return Ui.setFromAxisAngle(e,t),this.quaternion.multiply(Ui),this}rotateOnWorldAxis(e,t){return Ui.setFromAxisAngle(e,t),this.quaternion.premultiply(Ui),this}rotateX(e){return this.rotateOnAxis(mc,e)}rotateY(e){return this.rotateOnAxis(gc,e)}rotateZ(e){return this.rotateOnAxis(vc,e)}translateOnAxis(e,t){return pc.copy(e).applyQuaternion(this.quaternion),this.position.add(pc.multiplyScalar(t)),this}translateX(e){return this.translateOnAxis(mc,e)}translateY(e){return this.translateOnAxis(gc,e)}translateZ(e){return this.translateOnAxis(vc,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(Un.copy(this.matrixWorld).invert())}lookAt(e,t,n){e.isVector3?ns.copy(e):ns.set(e,t,n);const r=this.parent;this.updateWorldMatrix(!0,!1),hr.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?Un.lookAt(hr,ns,this.up):Un.lookAt(ns,hr,this.up),this.quaternion.setFromRotationMatrix(Un),r&&(Un.extractRotation(r.matrixWorld),Ui.setFromRotationMatrix(Un),this.quaternion.premultiply(Ui.invert()))}add(e){if(arguments.length>1){for(let t=0;t<arguments.length;t++)this.add(arguments[t]);return this}return e===this?($e("Object3D.add: object can't be added as a child of itself.",e),this):(e&&e.isObject3D?(e.removeFromParent(),e.parent=this,this.children.push(e),e.dispatchEvent(xc),Fi.child=e,this.dispatchEvent(Fi),Fi.child=null):$e("Object3D.add: object not an instance of THREE.Object3D.",e),this)}remove(e){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.remove(arguments[n]);return this}const t=this.children.indexOf(e);return t!==-1&&(e.parent=null,this.children.splice(t,1),e.dispatchEvent(Bf),Ea.child=e,this.dispatchEvent(Ea),Ea.child=null),this}removeFromParent(){const e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),Un.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),Un.multiply(e.parent.matrixWorld)),e.applyMatrix4(Un),e.removeFromParent(),e.parent=this,this.children.push(e),e.updateWorldMatrix(!1,!0),e.dispatchEvent(xc),Fi.child=e,this.dispatchEvent(Fi),Fi.child=null,this}getObjectById(e){return this.getObjectByProperty("id",e)}getObjectByName(e){return this.getObjectByProperty("name",e)}getObjectByProperty(e,t){if(this[e]===t)return this;for(let n=0,r=this.children.length;n<r;n++){const a=this.children[n].getObjectByProperty(e,t);if(a!==void 0)return a}}getObjectsByProperty(e,t,n=[]){this[e]===t&&n.push(this);const r=this.children;for(let s=0,a=r.length;s<a;s++)r[s].getObjectsByProperty(e,t,n);return n}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(hr,e,Ff),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(hr,Of,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);const t=this.matrixWorld.elements;return e.set(t[8],t[9],t[10]).normalize()}raycast(){}intersectsFrustum(){return!0}traverse(e){e(this);const t=this.children;for(let n=0,r=t.length;n<r;n++)t[n].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);const t=this.children;for(let n=0,r=t.length;n<r;n++)t[n].traverseVisible(e)}traverseAncestors(e){const t=this.parent;t!==null&&(e(t),t.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale);const e=this.pivot;if(e!==null){const t=e.x,n=e.y,r=e.z,s=this.matrix.elements;s[12]+=t-s[0]*t-s[4]*n-s[8]*r,s[13]+=n-s[1]*t-s[5]*n-s[9]*r,s[14]+=r-s[2]*t-s[6]*n-s[10]*r}this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,e=!0);const t=this.children;for(let n=0,r=t.length;n<r;n++)t[n].updateMatrixWorld(e)}updateWorldMatrix(e,t,n=!1){const r=this.parent;if(e===!0&&r!==null&&r.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||n)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,n=!0),t===!0){const s=this.children;for(let a=0,o=s.length;a<o;a++)s[a].updateWorldMatrix(!1,!0,n)}}toJSON(e){const t=e===void 0||typeof e=="string",n={};t&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.7,type:"Object",generator:"Object3D.toJSON"});const r={};r.uuid=this.uuid,r.type=this.type,r.name=this.name,r.castShadow=this.castShadow,r.receiveShadow=this.receiveShadow,r.visible=this.visible,r.frustumCulled=this.frustumCulled,r.renderOrder=this.renderOrder,r.static=this.static,r.matrixAutoUpdate=this.matrixAutoUpdate,Object.keys(this.userData).length>0&&(r.userData=this.userData),r.layers=this.layers.mask,r.matrix=this.matrix.toArray(),r.up=this.up.toArray(),this.pivot!==null&&(r.pivot=this.pivot.toArray()),this.morphTargetDictionary!==void 0&&(r.morphTargetDictionary=Object.assign({},this.morphTargetDictionary)),this.morphTargetInfluences!==void 0&&(r.morphTargetInfluences=this.morphTargetInfluences.slice()),this.isInstancedMesh&&(r.type="InstancedMesh",r.count=this.count,r.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(r.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(r.type="BatchedMesh",r.perObjectFrustumCulled=this.perObjectFrustumCulled,r.sortObjects=this.sortObjects,r.drawRanges=this._drawRanges,r.reservedRanges=this._reservedRanges,r.geometryInfo=this._geometryInfo.map(o=>({...o,boundingBox:o.boundingBox?o.boundingBox.toJSON():void 0,boundingSphere:o.boundingSphere?o.boundingSphere.toJSON():void 0})),r.instanceInfo=this._instanceInfo.map(o=>({...o})),r.availableInstanceIds=this._availableInstanceIds.slice(),r.availableGeometryIds=this._availableGeometryIds.slice(),r.nextIndexStart=this._nextIndexStart,r.nextVertexStart=this._nextVertexStart,r.geometryCount=this._geometryCount,r.maxInstanceCount=this._maxInstanceCount,r.maxVertexCount=this._maxVertexCount,r.maxIndexCount=this._maxIndexCount,r.geometryInitialized=this._geometryInitialized,r.matricesTexture=this._matricesTexture.toJSON(e),r.indirectTexture=this._indirectTexture.toJSON(e),this._colorsTexture!==null&&(r.colorsTexture=this._colorsTexture.toJSON(e)),this.boundingSphere!==null&&(r.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(r.boundingBox=this.boundingBox.toJSON()));function s(o,l){return o[l.uuid]===void 0&&(o[l.uuid]=l.toJSON(e)),l.uuid}if(this.isScene)this.background&&(this.background.isColor?r.background=this.background.toJSON():this.background.isTexture&&(r.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(r.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){r.geometry=s(e.geometries,this.geometry);const o=this.geometry.parameters;if(o!==void 0&&o.shapes!==void 0){const l=o.shapes;if(Array.isArray(l))for(let c=0,h=l.length;c<h;c++){const u=l[c];s(e.shapes,u)}else s(e.shapes,l)}}if(this.isSkinnedMesh&&(r.bindMode=this.bindMode,r.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(s(e.skeletons,this.skeleton),r.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const o=[];for(let l=0,c=this.material.length;l<c;l++)o.push(s(e.materials,this.material[l]));r.material=o}else r.material=s(e.materials,this.material);if(this.children.length>0){r.children=[];for(let o=0;o<this.children.length;o++)r.children.push(this.children[o].toJSON(e).object)}if(this.animations.length>0){r.animations=[];for(let o=0;o<this.animations.length;o++){const l=this.animations[o];r.animations.push(s(e.animations,l))}}if(t){const o=a(e.geometries),l=a(e.materials),c=a(e.textures),h=a(e.images),u=a(e.shapes),d=a(e.skeletons),p=a(e.animations),g=a(e.nodes);o.length>0&&(n.geometries=o),l.length>0&&(n.materials=l),c.length>0&&(n.textures=c),h.length>0&&(n.images=h),u.length>0&&(n.shapes=u),d.length>0&&(n.skeletons=d),p.length>0&&(n.animations=p),g.length>0&&(n.nodes=g)}return n.object=r,n;function a(o){const l=[];for(const c in o){const h=o[c];delete h.metadata,l.push(h)}return l}}clone(e){return new this.constructor().copy(this,e)}copy(e,t=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.pivot=e.pivot!==null?e.pivot.clone():null,this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.static=e.static,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),t===!0)for(let n=0;n<e.children.length;n++){const r=e.children[n];this.add(r.clone())}return this}dispose(){this.dispatchEvent({type:"dispose"})}}yt.DEFAULT_UP=new P(0,1,0);yt.DEFAULT_MATRIX_AUTO_UPDATE=!0;yt.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;class Wt extends yt{constructor(){super(),this.isGroup=!0,this.type="Group"}}const kf={type:"move"};class Ta{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new Wt,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new Wt,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new P,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new P),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new Wt,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new P,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new P,this._grip.eventsEnabled=!1),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){const t=this._hand;if(t)for(const n of e.hand.values())this._getHandJoint(t,n)}return this.dispatchEvent({type:"connected",data:e}),this}disconnect(e){return this.dispatchEvent({type:"disconnected",data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,t,n){let r=null,s=null,a=null;const o=this._targetRay,l=this._grip,c=this._hand;if(e&&t.session.visibilityState!=="visible-blurred"){if(c&&e.hand){a=!0;for(const v of e.hand.values()){const m=t.getJointPose(v,n),f=this._getHandJoint(c,v);m!==null&&(f.matrix.fromArray(m.transform.matrix),f.matrix.decompose(f.position,f.quaternion,f.scale),f.matrixWorldNeedsUpdate=!0,f.jointRadius=m.radius),f.visible=m!==null}const h=c.joints["index-finger-tip"],u=c.joints["thumb-tip"],d=h.position.distanceTo(u.position),p=.02,g=.005;c.inputState.pinching&&d>p+g?(c.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:e.handedness,target:this})):!c.inputState.pinching&&d<=p-g&&(c.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:e.handedness,target:this}))}else l!==null&&e.gripSpace&&(s=t.getPose(e.gripSpace,n),s!==null&&(l.matrix.fromArray(s.transform.matrix),l.matrix.decompose(l.position,l.quaternion,l.scale),l.matrixWorldNeedsUpdate=!0,s.linearVelocity?(l.hasLinearVelocity=!0,l.linearVelocity.copy(s.linearVelocity)):l.hasLinearVelocity=!1,s.angularVelocity?(l.hasAngularVelocity=!0,l.angularVelocity.copy(s.angularVelocity)):l.hasAngularVelocity=!1,l.eventsEnabled&&l.dispatchEvent({type:"gripUpdated",data:e,target:this})));o!==null&&(r=t.getPose(e.targetRaySpace,n),r===null&&s!==null&&(r=s),r!==null&&(o.matrix.fromArray(r.transform.matrix),o.matrix.decompose(o.position,o.quaternion,o.scale),o.matrixWorldNeedsUpdate=!0,r.linearVelocity?(o.hasLinearVelocity=!0,o.linearVelocity.copy(r.linearVelocity)):o.hasLinearVelocity=!1,r.angularVelocity?(o.hasAngularVelocity=!0,o.angularVelocity.copy(r.angularVelocity)):o.hasAngularVelocity=!1,this.dispatchEvent(kf)))}return o!==null&&(o.visible=r!==null),l!==null&&(l.visible=s!==null),c!==null&&(c.visible=a!==null),this}_getHandJoint(e,t){if(e.joints[t.jointName]===void 0){const n=new Wt;n.matrixAutoUpdate=!1,n.visible=!1,e.joints[t.jointName]=n,e.add(n)}return e.joints[t.jointName]}}const gu={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},Jn={h:0,s:0,l:0},is={h:0,s:0,l:0};function Aa(i,e,t){return t<0&&(t+=1),t>1&&(t-=1),t<1/6?i+(e-i)*6*t:t<1/2?e:t<2/3?i+(e-i)*6*(2/3-t):i}class Te{constructor(e,t,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,t,n)}set(e,t,n){if(t===void 0&&n===void 0){const r=e;r&&r.isColor?this.copy(r):typeof r=="number"?this.setHex(r):typeof r=="string"&&this.setStyle(r)}else this.setRGB(e,t,n);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,t=Ot){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,qe.colorSpaceToWorking(this,t),this}setRGB(e,t,n,r=qe.workingColorSpace){return this.r=e,this.g=t,this.b=n,qe.colorSpaceToWorking(this,r),this}setHSL(e,t,n,r=qe.workingColorSpace){if(e=xl(e,1),t=ze(t,0,1),n=ze(n,0,1),t===0)this.r=this.g=this.b=n;else{const s=n<=.5?n*(1+t):n+t-n*t,a=2*n-s;this.r=Aa(a,s,e+1/3),this.g=Aa(a,s,e),this.b=Aa(a,s,e-1/3)}return qe.colorSpaceToWorking(this,r),this}setStyle(e,t=Ot){function n(s){s!==void 0&&parseFloat(s)<1&&Pe("Color: Alpha component of "+e+" will be ignored.")}let r;if(r=/^(\w+)\(([^\)]*)\)/.exec(e)){let s;const a=r[1],o=r[2];switch(a){case"rgb":case"rgba":if(s=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d+(?:\.\d+)?|\.\d+)\s*)?$/.exec(o))return n(s[4]),this.setRGB(Math.min(255,parseInt(s[1],10))/255,Math.min(255,parseInt(s[2],10))/255,Math.min(255,parseInt(s[3],10))/255,t);if(s=/^\s*(\d+(?:\.\d+)?|\.\d+)\%\s*,\s*(\d+(?:\.\d+)?|\.\d+)\%\s*,\s*(\d+(?:\.\d+)?|\.\d+)\%\s*(?:,\s*(\d+(?:\.\d+)?|\.\d+)\s*)?$/.exec(o))return n(s[4]),this.setRGB(Math.min(100,parseFloat(s[1]))/100,Math.min(100,parseFloat(s[2]))/100,Math.min(100,parseFloat(s[3]))/100,t);break;case"hsl":case"hsla":if(s=/^\s*([+-]?(?:\d+(?:\.\d+)?|\.\d+))\s*,\s*(\d+(?:\.\d+)?|\.\d+)\%\s*,\s*(\d+(?:\.\d+)?|\.\d+)\%\s*(?:,\s*(\d+(?:\.\d+)?|\.\d+)\s*)?$/.exec(o))return n(s[4]),this.setHSL(parseFloat(s[1])/360,parseFloat(s[2])/100,parseFloat(s[3])/100,t);break;default:Pe("Color: Unknown color model "+e)}}else if(r=/^\#([A-Fa-f\d]+)$/.exec(e)){const s=r[1],a=s.length;if(a===3)return this.setRGB(parseInt(s.charAt(0),16)/15,parseInt(s.charAt(1),16)/15,parseInt(s.charAt(2),16)/15,t);if(a===6)return this.setHex(parseInt(s,16),t);Pe("Color: Invalid hex color "+e)}else if(e&&e.length>0)return this.setColorName(e,t);return this}setColorName(e,t=Ot){const n=gu[e.toLowerCase()];return n!==void 0?this.setHex(n,t):Pe("Color: Unknown color "+e),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=qn(e.r),this.g=qn(e.g),this.b=qn(e.b),this}copyLinearToSRGB(e){return this.r=ji(e.r),this.g=ji(e.g),this.b=ji(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=Ot){return qe.workingToColorSpace(Ft.copy(this),e),Math.round(ze(Ft.r*255,0,255))*65536+Math.round(ze(Ft.g*255,0,255))*256+Math.round(ze(Ft.b*255,0,255))}getHexString(e=Ot){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,t=qe.workingColorSpace){qe.workingToColorSpace(Ft.copy(this),t);const n=Ft.r,r=Ft.g,s=Ft.b,a=Math.max(n,r,s),o=Math.min(n,r,s);let l,c;const h=(o+a)/2;if(o===a)l=0,c=0;else{const u=a-o;switch(c=h<=.5?u/(a+o):u/(2-a-o),a){case n:l=(r-s)/u+(r<s?6:0);break;case r:l=(s-n)/u+2;break;case s:l=(n-r)/u+4;break}l/=6}return e.h=l,e.s=c,e.l=h,e}getRGB(e,t=qe.workingColorSpace){return qe.workingToColorSpace(Ft.copy(this),t),e.r=Ft.r,e.g=Ft.g,e.b=Ft.b,e}getStyle(e=Ot){qe.workingToColorSpace(Ft.copy(this),e);const t=Ft.r,n=Ft.g,r=Ft.b;return e!==Ot?`color(${e} ${t.toFixed(3)} ${n.toFixed(3)} ${r.toFixed(3)})`:`rgb(${Math.round(t*255)},${Math.round(n*255)},${Math.round(r*255)})`}offsetHSL(e,t,n){return this.getHSL(Jn),this.setHSL(Jn.h+e,Jn.s+t,Jn.l+n)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,t){return this.r=e.r+t.r,this.g=e.g+t.g,this.b=e.b+t.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,t){return this.r+=(e.r-this.r)*t,this.g+=(e.g-this.g)*t,this.b+=(e.b-this.b)*t,this}lerpColors(e,t,n){return this.r=e.r+(t.r-e.r)*n,this.g=e.g+(t.g-e.g)*n,this.b=e.b+(t.b-e.b)*n,this}lerpHSL(e,t){this.getHSL(Jn),e.getHSL(is);const n=Cr(Jn.h,is.h,t),r=Cr(Jn.s,is.s,t),s=Cr(Jn.l,is.l,t);return this.setHSL(n,r,s),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){const t=this.r,n=this.g,r=this.b,s=e.elements;return this.r=s[0]*t+s[3]*n+s[6]*r,this.g=s[1]*t+s[4]*n+s[7]*r,this.b=s[2]*t+s[5]*n+s[8]*r,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,t=0){return this.r=e[t],this.g=e[t+1],this.b=e[t+2],this}toArray(e=[],t=0){return e[t]=this.r,e[t+1]=this.g,e[t+2]=this.b,e}fromBufferAttribute(e,t){return this.r=e.getX(t),this.g=e.getY(t),this.b=e.getZ(t),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const Ft=new Te;Te.NAMES=gu;class Sl{constructor(e,t=1,n=1e3){this.isFog=!0,this.name="",this.color=new Te(e),this.near=t,this.far=n}clone(){return new Sl(this.color,this.near,this.far)}toJSON(){return{type:"Fog",name:this.name,color:this.color.getHex(),near:this.near,far:this.far}}}class vu extends yt{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new Dn,this.environmentIntensity=1,this.environmentRotation=new Dn,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(e,t){return super.copy(e,t),this.background=e.background!==null?e.background.clone():null,this.environment=e.environment!==null?e.environment.clone():null,this.fog=e.fog!==null?e.fog.clone():null,this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,this.backgroundRotation.copy(e.backgroundRotation),this.environmentIntensity=e.environmentIntensity,this.environmentRotation.copy(e.environmentRotation),this.overrideMaterial=e.overrideMaterial!==null?e.overrideMaterial.clone():null,this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){const t=super.toJSON(e);return this.fog!==null&&(t.object.fog=this.fog.toJSON()),t.object.backgroundBlurriness=this.backgroundBlurriness,t.object.backgroundIntensity=this.backgroundIntensity,t.object.backgroundRotation=this.backgroundRotation.toArray(),t.object.environmentIntensity=this.environmentIntensity,t.object.environmentRotation=this.environmentRotation.toArray(),t}}const fn=new P,Fn=new P,Ra=new P,On=new P,Oi=new P,Bi=new P,_c=new P,Ca=new P,Pa=new P,La=new P,Da=new dt,Ia=new dt,Na=new dt;class hn{constructor(e=new P,t=new P,n=new P){this.a=e,this.b=t,this.c=n}static getNormal(e,t,n,r){r.subVectors(n,t),fn.subVectors(e,t),r.cross(fn);const s=r.lengthSq();return s>0?r.multiplyScalar(1/Math.sqrt(s)):r.set(0,0,0)}static getBarycoord(e,t,n,r,s){fn.subVectors(r,t),Fn.subVectors(n,t),Ra.subVectors(e,t);const a=fn.dot(fn),o=fn.dot(Fn),l=fn.dot(Ra),c=Fn.dot(Fn),h=Fn.dot(Ra),u=a*c-o*o;if(u===0)return s.set(0,0,0),null;const d=1/u,p=(c*l-o*h)*d,g=(a*h-o*l)*d;return s.set(1-p-g,g,p)}static containsPoint(e,t,n,r){return this.getBarycoord(e,t,n,r,On)===null?!1:On.x>=0&&On.y>=0&&On.x+On.y<=1}static getInterpolation(e,t,n,r,s,a,o,l){return this.getBarycoord(e,t,n,r,On)===null?(l.x=0,l.y=0,"z"in l&&(l.z=0),"w"in l&&(l.w=0),null):(l.setScalar(0),l.addScaledVector(s,On.x),l.addScaledVector(a,On.y),l.addScaledVector(o,On.z),l)}static getInterpolatedAttribute(e,t,n,r,s,a){return Da.setScalar(0),Ia.setScalar(0),Na.setScalar(0),Da.fromBufferAttribute(e,t),Ia.fromBufferAttribute(e,n),Na.fromBufferAttribute(e,r),a.setScalar(0),a.addScaledVector(Da,s.x),a.addScaledVector(Ia,s.y),a.addScaledVector(Na,s.z),a}static isFrontFacing(e,t,n,r){return fn.subVectors(n,t),Fn.subVectors(e,t),fn.cross(Fn).dot(r)<0}set(e,t,n){return this.a.copy(e),this.b.copy(t),this.c.copy(n),this}setFromPointsAndIndices(e,t,n,r){return this.a.copy(e[t]),this.b.copy(e[n]),this.c.copy(e[r]),this}setFromAttributeAndIndices(e,t,n,r){return this.a.fromBufferAttribute(e,t),this.b.fromBufferAttribute(e,n),this.c.fromBufferAttribute(e,r),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return fn.subVectors(this.c,this.b),Fn.subVectors(this.a,this.b),fn.cross(Fn).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(e){return hn.getNormal(this.a,this.b,this.c,e)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(e,t){return hn.getBarycoord(e,this.a,this.b,this.c,t)}getInterpolation(e,t,n,r,s){return hn.getInterpolation(e,this.a,this.b,this.c,t,n,r,s)}containsPoint(e){return hn.containsPoint(e,this.a,this.b,this.c)}isFrontFacing(e){return hn.isFrontFacing(this.a,this.b,this.c,e)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,t){const n=this.a,r=this.b,s=this.c;let a,o;Oi.subVectors(r,n),Bi.subVectors(s,n),Ca.subVectors(e,n);const l=Oi.dot(Ca),c=Bi.dot(Ca);if(l<=0&&c<=0)return t.copy(n);Pa.subVectors(e,r);const h=Oi.dot(Pa),u=Bi.dot(Pa);if(h>=0&&u<=h)return t.copy(r);const d=l*u-h*c;if(d<=0&&l>=0&&h<=0&&l-h>0)return a=l/(l-h),t.copy(n).addScaledVector(Oi,a);La.subVectors(e,s);const p=Oi.dot(La),g=Bi.dot(La);if(g>=0&&p<=g)return t.copy(s);const v=p*c-l*g;if(v<=0&&c>=0&&g<=0)return o=c/(c-g),t.copy(n).addScaledVector(Bi,o);const m=h*g-p*u;if(m<=0&&u-h>=0&&p-g>=0)return _c.subVectors(s,r),o=(u-h)/(u-h+(p-g)),t.copy(r).addScaledVector(_c,o);const f=1/(m+v+d);return a=v*f,o=d*f,t.copy(n).addScaledVector(Oi,a).addScaledVector(Bi,o)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}}class di{constructor(e=new P(1/0,1/0,1/0),t=new P(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromArray(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t+=3)this.expandByPoint(pn.fromArray(e,t));return this}setFromBufferAttribute(e){this.makeEmpty();for(let t=0,n=e.count;t<n;t++)this.expandByPoint(pn.fromBufferAttribute(e,t));return this}setFromPoints(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){const n=pn.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(n),this.max.copy(e).add(n),this}setFromObject(e,t=!1){return this.makeEmpty(),this.expandByObject(e,t)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,t=!1){e.updateWorldMatrix(!1,!1);const n=e.geometry;if(n!==void 0){const s=n.getAttribute("position");if(t===!0&&s!==void 0&&e.isInstancedMesh!==!0&&e.isBatchedMesh!==!0)for(let a=0,o=s.count;a<o;a++)e.isMesh===!0?e.getVertexPosition(a,pn):pn.fromBufferAttribute(s,a),pn.applyMatrix4(e.matrixWorld),this.expandByPoint(pn);else e.boundingBox!==void 0?(e.boundingBox===null&&e.computeBoundingBox(),rs.copy(e.boundingBox)):(n.boundingBox===null&&n.computeBoundingBox(),rs.copy(n.boundingBox)),rs.applyMatrix4(e.matrixWorld),this.union(rs)}const r=e.children;for(let s=0,a=r.length;s<a;s++)this.expandByObject(r[s],t);return this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y&&e.z>=this.min.z&&e.z<=this.max.z}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y&&e.max.z>=this.min.z&&e.min.z<=this.max.z}intersectsSphere(e){return this.clampPoint(e.center,pn),pn.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let t,n;return e.normal.x>0?(t=e.normal.x*this.min.x,n=e.normal.x*this.max.x):(t=e.normal.x*this.max.x,n=e.normal.x*this.min.x),e.normal.y>0?(t+=e.normal.y*this.min.y,n+=e.normal.y*this.max.y):(t+=e.normal.y*this.max.y,n+=e.normal.y*this.min.y),e.normal.z>0?(t+=e.normal.z*this.min.z,n+=e.normal.z*this.max.z):(t+=e.normal.z*this.max.z,n+=e.normal.z*this.min.z),t<=-e.constant&&n>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(ur),ss.subVectors(this.max,ur),ki.subVectors(e.a,ur),zi.subVectors(e.b,ur),Gi.subVectors(e.c,ur),Qn.subVectors(zi,ki),jn.subVectors(Gi,zi),_i.subVectors(ki,Gi);let t=[0,-Qn.z,Qn.y,0,-jn.z,jn.y,0,-_i.z,_i.y,Qn.z,0,-Qn.x,jn.z,0,-jn.x,_i.z,0,-_i.x,-Qn.y,Qn.x,0,-jn.y,jn.x,0,-_i.y,_i.x,0];return!Ua(t,ki,zi,Gi,ss)||(t=[1,0,0,0,1,0,0,0,1],!Ua(t,ki,zi,Gi,ss))?!1:(as.crossVectors(Qn,jn),t=[as.x,as.y,as.z],Ua(t,ki,zi,Gi,ss))}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,pn).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize(pn).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()?this:(Bn[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),Bn[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),Bn[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),Bn[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),Bn[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),Bn[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),Bn[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),Bn[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(Bn),this)}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(e){return this.min.fromArray(e.min),this.max.fromArray(e.max),this}}const Bn=[new P,new P,new P,new P,new P,new P,new P,new P],pn=new P,rs=new di,ki=new P,zi=new P,Gi=new P,Qn=new P,jn=new P,_i=new P,ur=new P,ss=new P,as=new P,yi=new P;function Ua(i,e,t,n,r){for(let s=0,a=i.length-3;s<=a;s+=3){yi.fromArray(i,s);const o=r.x*Math.abs(yi.x)+r.y*Math.abs(yi.y)+r.z*Math.abs(yi.z),l=e.dot(yi),c=t.dot(yi),h=n.dot(yi);if(Math.max(-Math.max(l,c,h),Math.min(l,c,h))>o)return!1}return!0}const _t=new P,os=new de;let zf=0;class jt extends Ci{constructor(e,t,n=!1){if(super(),Array.isArray(e))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:zf++}),this.name="",this.array=e,this.itemSize=t,this.count=e!==void 0?e.length/t:0,this.normalized=n,this.usage=du,this.updateRanges=[],this.gpuType=_n,this.version=0,this._normalizationScale=e!==void 0?oa(e):void 0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this._normalizationScale=e._normalizationScale,this}copyAt(e,t,n){e*=this.itemSize,n*=t.itemSize;for(let r=0,s=this.itemSize;r<s;r++)this.array[e+r]=t.array[n+r];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let t=0,n=this.count;t<n;t++)os.fromBufferAttribute(this,t),os.applyMatrix3(e),this.setXY(t,os.x,os.y);else if(this.itemSize===3)for(let t=0,n=this.count;t<n;t++)_t.fromBufferAttribute(this,t),_t.applyMatrix3(e),this.setXYZ(t,_t.x,_t.y,_t.z);return this}applyMatrix4(e){for(let t=0,n=this.count;t<n;t++)_t.fromBufferAttribute(this,t),_t.applyMatrix4(e),this.setXYZ(t,_t.x,_t.y,_t.z);return this}applyNormalMatrix(e){for(let t=0,n=this.count;t<n;t++)_t.fromBufferAttribute(this,t),_t.applyNormalMatrix(e),this.setXYZ(t,_t.x,_t.y,_t.z);return this}transformDirection(e){for(let t=0,n=this.count;t<n;t++)_t.fromBufferAttribute(this,t),_t.transformDirection(e),this.setXYZ(t,_t.x,_t.y,_t.z);return this}set(e,t=0){return this.array.set(e,t),this}getComponent(e,t){let n=this.array[e*this.itemSize+t];return this.normalized&&(n=this._denormalize(n)),n}setComponent(e,t,n){return this.normalized&&(n=this._normalize(n)),this.array[e*this.itemSize+t]=n,this}getX(e){let t=this.array[e*this.itemSize];return this.normalized&&(t=this._denormalize(t)),t}setX(e,t){return this.normalized&&(t=this._normalize(t)),this.array[e*this.itemSize]=t,this}getY(e){let t=this.array[e*this.itemSize+1];return this.normalized&&(t=this._denormalize(t)),t}setY(e,t){return this.normalized&&(t=this._normalize(t)),this.array[e*this.itemSize+1]=t,this}getZ(e){let t=this.array[e*this.itemSize+2];return this.normalized&&(t=this._denormalize(t)),t}setZ(e,t){return this.normalized&&(t=this._normalize(t)),this.array[e*this.itemSize+2]=t,this}getW(e){let t=this.array[e*this.itemSize+3];return this.normalized&&(t=this._denormalize(t)),t}setW(e,t){return this.normalized&&(t=this._normalize(t)),this.array[e*this.itemSize+3]=t,this}setXY(e,t,n){return e*=this.itemSize,this.normalized&&(t=this._normalize(t),n=this._normalize(n)),this.array[e+0]=t,this.array[e+1]=n,this}setXYZ(e,t,n,r){return e*=this.itemSize,this.normalized&&(t=this._normalize(t),n=this._normalize(n),r=this._normalize(r)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=r,this}setXYZW(e,t,n,r,s){return e*=this.itemSize,this.normalized&&(t=this._normalize(t),n=this._normalize(n),r=this._normalize(r),s=this._normalize(s)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=r,this.array[e+3]=s,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return e.name=this.name,e.usage=this.usage,e.gpuType=this.gpuType,e}dispose(){this.dispatchEvent({type:"dispose"})}_denormalize(e){const t=this._normalizationScale;return t!==void 0?Math.max(e/t,-1):_l(e,this.array)}_normalize(e){const t=this._normalizationScale;return t!==void 0?Math.round(e*t):yl(e,this.array)}}class xu extends jt{constructor(e,t,n){super(new Uint16Array(e),t,n)}}class _u extends jt{constructor(e,t,n){super(new Uint32Array(e),t,n)}}class We extends jt{constructor(e,t,n){super(new Float32Array(e),t,n)}}const Gf=new di,dr=new P,Fa=new P;class Pi{constructor(e=new P,t=-1){this.isSphere=!0,this.center=e,this.radius=t}set(e,t){return this.center.copy(e),this.radius=t,this}setFromPoints(e,t){const n=this.center;t!==void 0?n.copy(t):Gf.setFromPoints(e).getCenter(n);let r=0;for(let s=0,a=e.length;s<a;s++)r=Math.max(r,n.distanceToSquared(e[s]));return this.radius=Math.sqrt(r),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){const t=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=t*t}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,t){const n=this.center.distanceToSquared(e);return t.copy(e),n>this.radius*this.radius&&(t.sub(this.center).normalize(),t.multiplyScalar(this.radius).add(this.center)),t}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;dr.subVectors(e,this.center);const t=dr.lengthSq();if(t>this.radius*this.radius){const n=Math.sqrt(t),r=(n-this.radius)*.5;this.center.addScaledVector(dr,r/n),this.radius+=r}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(Fa.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(dr.copy(e.center).add(Fa)),this.expandByPoint(dr.copy(e.center).sub(Fa))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(e){return this.radius=e.radius,this.center.fromArray(e.center),this}}let Hf=0;const an=new Ye,Oa=new yt,Hi=new P,Jt=new di,fr=new di,Ct=new P;class gt extends Ci{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:Hf++}),this.uuid=$n(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.indirectOffset=0,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={},this._transformed=!1}getIndex(){return this.index}setIndex(e){return Array.isArray(e)?this.index=new(lf(e)?_u:xu)(e,1):this.index=e,this}setIndirect(e,t=0){return this.indirect=e,this.indirectOffset=t,this}getIndirect(){return this.indirect}getAttribute(e){return this.attributes[e]}setAttribute(e,t){return this.attributes[e]=t,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,t,n=0){this.groups.push({start:e,count:t,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(e,t){this.drawRange.start=e,this.drawRange.count=t}applyMatrix4(e){const t=this.attributes.position;t!==void 0&&(t.applyMatrix4(e),t.needsUpdate=!0);const n=this.attributes.normal;if(n!==void 0){const s=new Ie().getNormalMatrix(e);n.applyNormalMatrix(s),n.needsUpdate=!0}const r=this.attributes.tangent;return r!==void 0&&(r.transformDirection(e),r.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this._transformed=!0,this}applyQuaternion(e){return an.makeRotationFromQuaternion(e),this.applyMatrix4(an),this}rotateX(e){return an.makeRotationX(e),this.applyMatrix4(an),this}rotateY(e){return an.makeRotationY(e),this.applyMatrix4(an),this}rotateZ(e){return an.makeRotationZ(e),this.applyMatrix4(an),this}translate(e,t,n){return an.makeTranslation(e,t,n),this.applyMatrix4(an),this}scale(e,t,n){return an.makeScale(e,t,n),this.applyMatrix4(an),this}lookAt(e){return Oa.lookAt(e),Oa.updateMatrix(),this.applyMatrix4(Oa.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Hi).negate(),this.translate(Hi.x,Hi.y,Hi.z),this}setFromPoints(e){const t=this.getAttribute("position");if(t===void 0){const n=[];for(let r=0,s=e.length;r<s;r++){const a=e[r];n.push(a.x,a.y,a.z||0)}this.setAttribute("position",new We(n,3))}else{const n=Math.min(e.length,t.count);for(let r=0;r<n;r++){const s=e[r];t.setXYZ(r,s.x,s.y,s.z||0)}e.length>t.count&&Pe("BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),t.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new di);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){$e("BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new P(-1/0,-1/0,-1/0),new P(1/0,1/0,1/0));return}if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),t)for(let n=0,r=t.length;n<r;n++){const s=t[n];Jt.setFromBufferAttribute(s),this.morphTargetsRelative?(Ct.addVectors(this.boundingBox.min,Jt.min),this.boundingBox.expandByPoint(Ct),Ct.addVectors(this.boundingBox.max,Jt.max),this.boundingBox.expandByPoint(Ct)):(this.boundingBox.expandByPoint(Jt.min),this.boundingBox.expandByPoint(Jt.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&$e('BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new Pi);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){$e("BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new P,1/0);return}if(e){const n=this.boundingSphere.center;if(Jt.setFromBufferAttribute(e),t)for(let s=0,a=t.length;s<a;s++){const o=t[s];fr.setFromBufferAttribute(o),this.morphTargetsRelative?(Ct.addVectors(Jt.min,fr.min),Jt.expandByPoint(Ct),Ct.addVectors(Jt.max,fr.max),Jt.expandByPoint(Ct)):(Jt.expandByPoint(fr.min),Jt.expandByPoint(fr.max))}Jt.getCenter(n);let r=0;for(let s=0,a=e.count;s<a;s++)Ct.fromBufferAttribute(e,s),r=Math.max(r,n.distanceToSquared(Ct));if(t)for(let s=0,a=t.length;s<a;s++){const o=t[s],l=this.morphTargetsRelative;for(let c=0,h=o.count;c<h;c++)Ct.fromBufferAttribute(o,c),l&&(Hi.fromBufferAttribute(e,c),Ct.add(Hi)),r=Math.max(r,n.distanceToSquared(Ct))}this.boundingSphere.radius=Math.sqrt(r),isNaN(this.boundingSphere.radius)&&$e('BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const e=this.index,t=this.attributes;if(e===null||t.position===void 0||t.normal===void 0||t.uv===void 0){$e("BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const n=t.position,r=t.normal,s=t.uv;let a=this.getAttribute("tangent");(a===void 0||a.count!==n.count)&&(a=new jt(new Float32Array(4*n.count),4),this.setAttribute("tangent",a));const o=[],l=[],c=new Uint8Array(n.count);for(let I=0;I<n.count;I++)o[I]=new P,l[I]=new P;const h=new P,u=new P,d=new P,p=new de,g=new de,v=new de,m=new P,f=new P;function _(I,C,N){c[I]=c[C]=c[N]=1,h.fromBufferAttribute(n,I),u.fromBufferAttribute(n,C),d.fromBufferAttribute(n,N),p.fromBufferAttribute(s,I),g.fromBufferAttribute(s,C),v.fromBufferAttribute(s,N),u.sub(h),d.sub(h),g.sub(p),v.sub(p);const F=1/(g.x*v.y-v.x*g.y);isFinite(F)&&(m.copy(u).multiplyScalar(v.y).addScaledVector(d,-g.y).multiplyScalar(F),f.copy(d).multiplyScalar(g.x).addScaledVector(u,-v.x).multiplyScalar(F),o[I].add(m),o[C].add(m),o[N].add(m),l[I].add(f),l[C].add(f),l[N].add(f))}let S=this.groups;S.length===0&&(S=[{start:0,count:e.count}]);for(let I=0,C=S.length;I<C;++I){const N=S[I],F=N.start,V=N.count;for(let D=F,H=F+V;D<H;D+=3)_(e.getX(D+0),e.getX(D+1),e.getX(D+2))}const y=new P,A=new P,E=new P,x=new P;function w(I){E.fromBufferAttribute(r,I),x.copy(E);const C=o[I];y.copy(C),y.sub(E.multiplyScalar(E.dot(C))).normalize(),A.crossVectors(x,C);const F=A.dot(l[I])<0?-1:1;a.setXYZW(I,y.x,y.y,y.z,F)}for(let I=0,C=n.count;I<C;++I)c[I]&&w(I);this._transformed=!0}computeVertexNormals(){const e=this.index,t=this.getAttribute("position");if(t!==void 0){let n=this.getAttribute("normal");if(n===void 0||n.count!==t.count)n=new jt(new Float32Array(t.count*3),3),this.setAttribute("normal",n);else for(let d=0,p=n.count;d<p;d++)n.setXYZ(d,0,0,0);const r=new P,s=new P,a=new P,o=new P,l=new P,c=new P,h=new P,u=new P;if(e)for(let d=0,p=e.count;d<p;d+=3){const g=e.getX(d+0),v=e.getX(d+1),m=e.getX(d+2);r.fromBufferAttribute(t,g),s.fromBufferAttribute(t,v),a.fromBufferAttribute(t,m),h.subVectors(a,s),u.subVectors(r,s),h.cross(u),o.fromBufferAttribute(n,g),l.fromBufferAttribute(n,v),c.fromBufferAttribute(n,m),o.add(h),l.add(h),c.add(h),n.setXYZ(g,o.x,o.y,o.z),n.setXYZ(v,l.x,l.y,l.z),n.setXYZ(m,c.x,c.y,c.z)}else for(let d=0,p=t.count;d<p;d+=3)r.fromBufferAttribute(t,d+0),s.fromBufferAttribute(t,d+1),a.fromBufferAttribute(t,d+2),h.subVectors(a,s),u.subVectors(r,s),h.cross(u),n.setXYZ(d+0,h.x,h.y,h.z),n.setXYZ(d+1,h.x,h.y,h.z),n.setXYZ(d+2,h.x,h.y,h.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){const e=this.attributes.normal;for(let t=0,n=e.count;t<n;t++)Ct.fromBufferAttribute(e,t),Ct.normalize(),e.setXYZ(t,Ct.x,Ct.y,Ct.z)}toNonIndexed(){function e(o,l){const c=o.array,h=o.itemSize,u=o.normalized,d=new c.constructor(l.length*h);let p=0,g=0;for(let v=0,m=l.length;v<m;v++){o.isInterleavedBufferAttribute?p=l[v]*o.data.stride+o.offset:p=l[v]*h;for(let f=0;f<h;f++)d[g++]=c[p++]}return new jt(d,h,u)}if(this.index===null)return Pe("BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const t=new gt,n=this.index.array,r=this.attributes;for(const o in r){const l=r[o],c=e(l,n);t.setAttribute(o,c)}const s=this.morphAttributes;for(const o in s){const l=[],c=s[o];for(let h=0,u=c.length;h<u;h++){const d=c[h],p=e(d,n);l.push(p)}t.morphAttributes[o]=l}t.morphTargetsRelative=this.morphTargetsRelative;const a=this.groups;for(let o=0,l=a.length;o<l;o++){const c=a[o];t.addGroup(c.start,c.count,c.materialIndex)}return t}toJSON(){const e={metadata:{version:4.7,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(e.uuid=this.uuid,e.type=this.parameters!==void 0&&this._transformed===!0?"BufferGeometry":this.type,e.name=this.name,Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0&&this._transformed!==!0){const l=this.parameters;for(const c in l)l[c]!==void 0&&(e[c]=l[c]);return e}e.data={attributes:{}};const t=this.index;t!==null&&(e.data.index={type:t.array.constructor.name,array:Array.prototype.slice.call(t.array)});const n=this.attributes;for(const l in n){const c=n[l];e.data.attributes[l]=c.toJSON(e.data)}const r={};let s=!1;for(const l in this.morphAttributes){const c=this.morphAttributes[l],h=[];for(let u=0,d=c.length;u<d;u++){const p=c[u];h.push(p.toJSON(e.data))}h.length>0&&(r[l]=h,s=!0)}s&&(e.data.morphAttributes=r,e.data.morphTargetsRelative=this.morphTargetsRelative);const a=this.groups;a.length>0&&(e.data.groups=JSON.parse(JSON.stringify(a)));const o=this.boundingSphere;return o!==null&&(e.data.boundingSphere=o.toJSON()),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const t={};this.name=e.name;const n=e.index;n!==null&&this.setIndex(n.clone());const r=e.attributes;for(const c in r){const h=r[c];this.setAttribute(c,h.clone(t))}const s=e.morphAttributes;for(const c in s){const h=[],u=s[c];for(let d=0,p=u.length;d<p;d++)h.push(u[d].clone(t));this.morphAttributes[c]=h}this.morphTargetsRelative=e.morphTargetsRelative;const a=e.groups;for(let c=0,h=a.length;c<h;c++){const u=a[c];this.addGroup(u.start,u.count,u.materialIndex)}const o=e.boundingBox;o!==null&&(this.boundingBox=o.clone());const l=e.boundingSphere;return l!==null&&(this.boundingSphere=l.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this._transformed=e._transformed,this}dispose(){this.dispatchEvent({type:"dispose"})}}class Vf{constructor(e,t){this.isInterleavedBuffer=!0,this.array=e,this.stride=t,this.count=e!==void 0?e.length/t:0,this.usage=du,this.updateRanges=[],this.version=0,this.uuid=$n()}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.array=new e.array.constructor(e.array),this.count=e.count,this.stride=e.stride,this.usage=e.usage,this}copyAt(e,t,n){e*=this.stride,n*=t.stride;for(let r=0,s=this.stride;r<s;r++)this.array[e+r]=t.array[n+r];return this}set(e,t=0){return this.array.set(e,t),this}clone(e){e.arrayBuffers===void 0&&(e.arrayBuffers={});const t=yc(this.array);e.arrayBuffers[t]===void 0&&(e.arrayBuffers[t]=this.array.slice(0).buffer);const n=new this.array.constructor(e.arrayBuffers[t]),r=new this.constructor(n,this.stride);return r.setUsage(this.usage),r}onUpload(e){return this.onUploadCallback=e,this}toJSON(e){e.arrayBuffers===void 0&&(e.arrayBuffers={});const t=yc(this.array);e.arrayBuffers[t]===void 0&&(e.arrayBuffers[t]=Array.from(new Uint32Array(this.array.slice(0).buffer)));const n={uuid:this.uuid,buffer:t,type:this.array.constructor.name,stride:this.stride};return n.usage=this.usage,n}}function yc(i){return i.buffer._uuid===void 0&&(i.buffer._uuid=$n()),i.byteOffset===0&&i.byteLength===i.buffer.byteLength?i.buffer._uuid:i.buffer._uuid+":"+i.byteOffset+":"+i.byteLength}const Gt=new P;class ta{constructor(e,t,n,r=!1){this.isInterleavedBufferAttribute=!0,this.name="",this.data=e,this.itemSize=t,this.offset=n,this.normalized=r,this._normalizationScale=e!==void 0?oa(e.array):void 0}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(e){this.data.needsUpdate=e}applyMatrix4(e){for(let t=0,n=this.data.count;t<n;t++)Gt.fromBufferAttribute(this,t),Gt.applyMatrix4(e),this.setXYZ(t,Gt.x,Gt.y,Gt.z);return this}applyNormalMatrix(e){for(let t=0,n=this.count;t<n;t++)Gt.fromBufferAttribute(this,t),Gt.applyNormalMatrix(e),this.setXYZ(t,Gt.x,Gt.y,Gt.z);return this}transformDirection(e){for(let t=0,n=this.count;t<n;t++)Gt.fromBufferAttribute(this,t),Gt.transformDirection(e),this.setXYZ(t,Gt.x,Gt.y,Gt.z);return this}getComponent(e,t){let n=this.array[e*this.data.stride+this.offset+t];return this.normalized&&(n=this._denormalize(n)),n}setComponent(e,t,n){return this.normalized&&(n=this._normalize(n)),this.data.array[e*this.data.stride+this.offset+t]=n,this}setX(e,t){return this.normalized&&(t=this._normalize(t)),this.data.array[e*this.data.stride+this.offset]=t,this}setY(e,t){return this.normalized&&(t=this._normalize(t)),this.data.array[e*this.data.stride+this.offset+1]=t,this}setZ(e,t){return this.normalized&&(t=this._normalize(t)),this.data.array[e*this.data.stride+this.offset+2]=t,this}setW(e,t){return this.normalized&&(t=this._normalize(t)),this.data.array[e*this.data.stride+this.offset+3]=t,this}getX(e){let t=this.data.array[e*this.data.stride+this.offset];return this.normalized&&(t=this._denormalize(t)),t}getY(e){let t=this.data.array[e*this.data.stride+this.offset+1];return this.normalized&&(t=this._denormalize(t)),t}getZ(e){let t=this.data.array[e*this.data.stride+this.offset+2];return this.normalized&&(t=this._denormalize(t)),t}getW(e){let t=this.data.array[e*this.data.stride+this.offset+3];return this.normalized&&(t=this._denormalize(t)),t}setXY(e,t,n){return e=e*this.data.stride+this.offset,this.normalized&&(t=this._normalize(t),n=this._normalize(n)),this.data.array[e+0]=t,this.data.array[e+1]=n,this}setXYZ(e,t,n,r){return e=e*this.data.stride+this.offset,this.normalized&&(t=this._normalize(t),n=this._normalize(n),r=this._normalize(r)),this.data.array[e+0]=t,this.data.array[e+1]=n,this.data.array[e+2]=r,this}setXYZW(e,t,n,r,s){return e=e*this.data.stride+this.offset,this.normalized&&(t=this._normalize(t),n=this._normalize(n),r=this._normalize(r),s=this._normalize(s)),this.data.array[e+0]=t,this.data.array[e+1]=n,this.data.array[e+2]=r,this.data.array[e+3]=s,this}clone(e){if(e===void 0){ea("InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");const t=[];for(let n=0;n<this.count;n++){const r=n*this.data.stride+this.offset;for(let s=0;s<this.itemSize;s++)t.push(this.data.array[r+s])}return new jt(new this.array.constructor(t),this.itemSize,this.normalized)}else return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.clone(e)),new ta(e.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(e){if(e===void 0){ea("InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");const t=[];for(let n=0;n<this.count;n++){const r=n*this.data.stride+this.offset;for(let s=0;s<this.itemSize;s++)t.push(this.data.array[r+s])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:t,normalized:this.normalized}}else return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.toJSON(e)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}_denormalize(e){const t=this._normalizationScale;return t!==void 0?Math.max(e/t,-1):_l(e,this.data.array)}_normalize(e){const t=this._normalizationScale;return t!==void 0?Math.round(e*t):yl(e,this.data.array)}}const Ba=new P,Wf=new P,qf=new Ie;class Hn{constructor(e=new P(1,0,0),t=0){this.isPlane=!0,this.normal=e,this.constant=t}set(e,t){return this.normal.copy(e),this.constant=t,this}setComponents(e,t,n,r){return this.normal.set(e,t,n),this.constant=r,this}setFromNormalAndCoplanarPoint(e,t){return this.normal.copy(e),this.constant=-t.dot(this.normal),this}setFromCoplanarPoints(e,t,n){const r=Ba.subVectors(n,t).cross(Wf.subVectors(e,t)).normalize();return this.setFromNormalAndCoplanarPoint(r,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){const e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,t){return t.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,t,n=!0){const r=e.delta(Ba),s=this.normal.dot(r);if(s===0)return this.distanceToPoint(e.start)===0?t.copy(e.start):null;const a=-(e.start.dot(this.normal)+this.constant)/s;return n===!0&&(a<0||a>1)?null:t.copy(e.start).addScaledVector(r,a)}intersectsLine(e){const t=this.distanceToPoint(e.start),n=this.distanceToPoint(e.end);return t<0&&n>0||n<0&&t>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,t){const n=t||qf.getNormalMatrix(e),r=this.coplanarPoint(Ba).applyMatrix4(e),s=this.normal.applyMatrix3(n).normalize();return this.constant=-r.dot(s),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}toJSON(){return{normal:this.normal.toArray(),constant:this.constant}}fromJSON(e){return this.normal.fromArray(e.normal),this.constant=e.constant,this}}let Xf=0;class fi extends Ci{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:Xf++}),this.uuid=$n(),this.name="",this.type="Material",this.blending=Ar,this.side=Ei,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=$h,this.blendDst=Yh,this.blendEquation=Zi,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new Te(0,0,0),this.blendAlpha=0,this.depthFunc=Fr,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=tf,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=ya,this.stencilZFail=ya,this.stencilZPass=ya,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(const t in e){const n=e[t];if(n===void 0){Pe(`Material: parameter '${t}' has value of undefined.`);continue}const r=this[t];if(r===void 0){Pe(`Material: '${t}' is not a property of THREE.${this.type}.`);continue}r&&r.isColor?r.set(n):r&&r.isVector2&&n&&n.isVector2||r&&r.isEuler&&n&&n.isEuler||r&&r.isVector3&&n&&n.isVector3?r.copy(n):this[t]=n}}toJSON(e){const t=e===void 0||typeof e=="string";t&&(e={textures:{},images:{}});const n={metadata:{version:4.7,type:"Material",generator:"Material.toJSON"}};n.uuid=this.uuid,n.type=this.type,n.blending=this.blending,n.side=this.side,n.shadowSide=this.shadowSide,n.vertexColors=this.vertexColors,n.opacity=this.opacity,n.transparent=this.transparent,n.blendSrc=this.blendSrc,n.blendDst=this.blendDst,n.blendEquation=this.blendEquation,n.blendSrcAlpha=this.blendSrcAlpha,n.blendDstAlpha=this.blendDstAlpha,n.blendEquationAlpha=this.blendEquationAlpha,n.blendColor=this.blendColor.getHex(),n.blendAlpha=this.blendAlpha,n.depthFunc=this.depthFunc,n.depthTest=this.depthTest,n.depthWrite=this.depthWrite,n.colorWrite=this.colorWrite,n.clipIntersection=this.clipIntersection,n.clipShadows=this.clipShadows,n.stencilWriteMask=this.stencilWriteMask,n.stencilFunc=this.stencilFunc,n.stencilRef=this.stencilRef,n.stencilFuncMask=this.stencilFuncMask,n.stencilFail=this.stencilFail,n.stencilZFail=this.stencilZFail,n.stencilZPass=this.stencilZPass,n.stencilWrite=this.stencilWrite,n.polygonOffset=this.polygonOffset,n.polygonOffsetFactor=this.polygonOffsetFactor,n.polygonOffsetUnits=this.polygonOffsetUnits,n.dithering=this.dithering,n.alphaTest=this.alphaTest,n.alphaHash=this.alphaHash,n.alphaToCoverage=this.alphaToCoverage,n.premultipliedAlpha=this.premultipliedAlpha,n.forceSinglePass=this.forceSinglePass,n.allowOverride=this.allowOverride,n.visible=this.visible,n.toneMapped=this.toneMapped,n.name=this.name,this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.diffuseRoughness!==void 0&&(n.diffuseRoughness=this.diffuseRoughness),this.diffuseRoughnessMap&&this.diffuseRoughnessMap.isTexture&&(n.diffuseRoughnessMap=this.diffuseRoughnessMap.toJSON(e).uuid),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.sheenColorMap&&this.sheenColorMap.isTexture&&(n.sheenColorMap=this.sheenColorMap.toJSON(e).uuid),this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture&&(n.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(e).uuid),this.dispersion!==void 0&&(n.dispersion=this.dispersion),this.retroreflectivity!==void 0&&(n.retroreflectivity=this.retroreflectivity),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessMinimum!==void 0&&(n.iridescenceThicknessMinimum=this.iridescenceThicknessMinimum),this.iridescenceThicknessMaximum!==void 0&&(n.iridescenceThicknessMaximum=this.iridescenceThicknessMaximum),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(e).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(e).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(e).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(e).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(e).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapRotation!==void 0&&(n.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),Array.isArray(this.clippingPlanes)&&this.clippingPlanes.length>0&&(n.clippingPlanes=this.clippingPlanes.map(s=>s.toJSON())),this.rotation!==void 0&&(n.rotation=this.rotation),this.depthPacking!==void 0&&(n.depthPacking=this.depthPacking),this.linewidth!==void 0&&(n.linewidth=this.linewidth),this.linecap!==void 0&&(n.linecap=this.linecap),this.linejoin!==void 0&&(n.linejoin=this.linejoin),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.wireframe!==void 0&&(n.wireframe=this.wireframe),this.wireframeLinewidth!==void 0&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!==void 0&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!==void 0&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading!==void 0&&(n.flatShading=this.flatShading),this.fog!==void 0&&(n.fog=this.fog),Object.keys(this.userData).length>0&&(n.userData=this.userData);function r(s){const a=[];for(const o in s){const l=s[o];delete l.metadata,a.push(l)}return a}if(t){const s=r(e.textures),a=r(e.images);s.length>0&&(n.textures=s),a.length>0&&(n.images=a)}return n}fromJSON(e,t){if(e.uuid!==void 0&&(this.uuid=e.uuid),e.name!==void 0&&(this.name=e.name),e.color!==void 0&&this.color!==void 0&&this.color.setHex(e.color),e.roughness!==void 0&&(this.roughness=e.roughness),e.metalness!==void 0&&(this.metalness=e.metalness),e.sheen!==void 0&&(this.sheen=e.sheen),e.sheenColor!==void 0&&(this.sheenColor=new Te().setHex(e.sheenColor)),e.sheenRoughness!==void 0&&(this.sheenRoughness=e.sheenRoughness),e.emissive!==void 0&&this.emissive!==void 0&&this.emissive.setHex(e.emissive),e.specular!==void 0&&this.specular!==void 0&&this.specular.setHex(e.specular),e.specularIntensity!==void 0&&(this.specularIntensity=e.specularIntensity),e.specularColor!==void 0&&this.specularColor!==void 0&&this.specularColor.setHex(e.specularColor),e.shininess!==void 0&&(this.shininess=e.shininess),e.clearcoat!==void 0&&(this.clearcoat=e.clearcoat),e.clearcoatRoughness!==void 0&&(this.clearcoatRoughness=e.clearcoatRoughness),e.diffuseRoughness!==void 0&&(this.diffuseRoughness=e.diffuseRoughness),e.dispersion!==void 0&&(this.dispersion=e.dispersion),e.retroreflectivity!==void 0&&(this.retroreflectivity=e.retroreflectivity),e.iridescence!==void 0&&(this.iridescence=e.iridescence),e.iridescenceIOR!==void 0&&(this.iridescenceIOR=e.iridescenceIOR),e.iridescenceThicknessMinimum!==void 0&&(this.iridescenceThicknessMinimum=e.iridescenceThicknessMinimum),e.iridescenceThicknessMaximum!==void 0&&(this.iridescenceThicknessMaximum=e.iridescenceThicknessMaximum),e.iridescenceThicknessRange!==void 0&&(this.iridescenceThicknessMinimum=e.iridescenceThicknessRange[0],this.iridescenceThicknessMaximum=e.iridescenceThicknessRange[1]),e.transmission!==void 0&&(this.transmission=e.transmission),e.thickness!==void 0&&(this.thickness=e.thickness),e.attenuationDistance!==void 0&&(this.attenuationDistance=e.attenuationDistance),e.attenuationColor!==void 0&&this.attenuationColor!==void 0&&this.attenuationColor.setHex(e.attenuationColor),e.anisotropy!==void 0&&(this.anisotropy=e.anisotropy),e.anisotropyRotation!==void 0&&(this.anisotropyRotation=e.anisotropyRotation),e.fog!==void 0&&(this.fog=e.fog),e.flatShading!==void 0&&(this.flatShading=e.flatShading),e.blending!==void 0&&(this.blending=e.blending),e.combine!==void 0&&(this.combine=e.combine),e.side!==void 0&&(this.side=e.side),e.shadowSide!==void 0&&(this.shadowSide=e.shadowSide),e.opacity!==void 0&&(this.opacity=e.opacity),e.transparent!==void 0&&(this.transparent=e.transparent),e.alphaTest!==void 0&&(this.alphaTest=e.alphaTest),e.alphaHash!==void 0&&(this.alphaHash=e.alphaHash),e.depthFunc!==void 0&&(this.depthFunc=e.depthFunc),e.depthTest!==void 0&&(this.depthTest=e.depthTest),e.depthWrite!==void 0&&(this.depthWrite=e.depthWrite),e.colorWrite!==void 0&&(this.colorWrite=e.colorWrite),e.clippingPlanes!==void 0&&(this.clippingPlanes=e.clippingPlanes.map(n=>new Hn().fromJSON(n))),e.clipIntersection!==void 0&&(this.clipIntersection=e.clipIntersection),e.clipShadows!==void 0&&(this.clipShadows=e.clipShadows),e.depthPacking!==void 0&&(this.depthPacking=e.depthPacking),e.blendSrc!==void 0&&(this.blendSrc=e.blendSrc),e.blendDst!==void 0&&(this.blendDst=e.blendDst),e.blendEquation!==void 0&&(this.blendEquation=e.blendEquation),e.blendSrcAlpha!==void 0&&(this.blendSrcAlpha=e.blendSrcAlpha),e.blendDstAlpha!==void 0&&(this.blendDstAlpha=e.blendDstAlpha),e.blendEquationAlpha!==void 0&&(this.blendEquationAlpha=e.blendEquationAlpha),e.blendColor!==void 0&&this.blendColor!==void 0&&this.blendColor.setHex(e.blendColor),e.blendAlpha!==void 0&&(this.blendAlpha=e.blendAlpha),e.stencilWriteMask!==void 0&&(this.stencilWriteMask=e.stencilWriteMask),e.stencilFunc!==void 0&&(this.stencilFunc=e.stencilFunc),e.stencilRef!==void 0&&(this.stencilRef=e.stencilRef),e.stencilFuncMask!==void 0&&(this.stencilFuncMask=e.stencilFuncMask),e.stencilFail!==void 0&&(this.stencilFail=e.stencilFail),e.stencilZFail!==void 0&&(this.stencilZFail=e.stencilZFail),e.stencilZPass!==void 0&&(this.stencilZPass=e.stencilZPass),e.stencilWrite!==void 0&&(this.stencilWrite=e.stencilWrite),e.wireframe!==void 0&&(this.wireframe=e.wireframe),e.wireframeLinewidth!==void 0&&(this.wireframeLinewidth=e.wireframeLinewidth),e.wireframeLinecap!==void 0&&(this.wireframeLinecap=e.wireframeLinecap),e.wireframeLinejoin!==void 0&&(this.wireframeLinejoin=e.wireframeLinejoin),e.rotation!==void 0&&(this.rotation=e.rotation),e.linewidth!==void 0&&(this.linewidth=e.linewidth),e.linecap!==void 0&&(this.linecap=e.linecap),e.linejoin!==void 0&&(this.linejoin=e.linejoin),e.dashSize!==void 0&&(this.dashSize=e.dashSize),e.gapSize!==void 0&&(this.gapSize=e.gapSize),e.scale!==void 0&&(this.scale=e.scale),e.polygonOffset!==void 0&&(this.polygonOffset=e.polygonOffset),e.polygonOffsetFactor!==void 0&&(this.polygonOffsetFactor=e.polygonOffsetFactor),e.polygonOffsetUnits!==void 0&&(this.polygonOffsetUnits=e.polygonOffsetUnits),e.dithering!==void 0&&(this.dithering=e.dithering),e.alphaToCoverage!==void 0&&(this.alphaToCoverage=e.alphaToCoverage),e.premultipliedAlpha!==void 0&&(this.premultipliedAlpha=e.premultipliedAlpha),e.forceSinglePass!==void 0&&(this.forceSinglePass=e.forceSinglePass),e.allowOverride!==void 0&&(this.allowOverride=e.allowOverride),e.visible!==void 0&&(this.visible=e.visible),e.toneMapped!==void 0&&(this.toneMapped=e.toneMapped),e.userData!==void 0&&(this.userData=e.userData),e.vertexColors!==void 0&&(typeof e.vertexColors=="number"?this.vertexColors=e.vertexColors>0:this.vertexColors=e.vertexColors),e.size!==void 0&&(this.size=e.size),e.sizeAttenuation!==void 0&&(this.sizeAttenuation=e.sizeAttenuation),e.map!==void 0&&(this.map=t[e.map]||null),e.matcap!==void 0&&(this.matcap=t[e.matcap]||null),e.alphaMap!==void 0&&(this.alphaMap=t[e.alphaMap]||null),e.bumpMap!==void 0&&(this.bumpMap=t[e.bumpMap]||null),e.bumpScale!==void 0&&(this.bumpScale=e.bumpScale),e.normalMap!==void 0&&(this.normalMap=t[e.normalMap]||null),e.normalMapType!==void 0&&(this.normalMapType=e.normalMapType),e.normalScale!==void 0){let n=e.normalScale;Array.isArray(n)===!1&&(n=[n,n]),this.normalScale=new de().fromArray(n)}return e.displacementMap!==void 0&&(this.displacementMap=t[e.displacementMap]||null),e.displacementScale!==void 0&&(this.displacementScale=e.displacementScale),e.displacementBias!==void 0&&(this.displacementBias=e.displacementBias),e.roughnessMap!==void 0&&(this.roughnessMap=t[e.roughnessMap]||null),e.metalnessMap!==void 0&&(this.metalnessMap=t[e.metalnessMap]||null),e.emissiveMap!==void 0&&(this.emissiveMap=t[e.emissiveMap]||null),e.emissiveIntensity!==void 0&&(this.emissiveIntensity=e.emissiveIntensity),e.specularMap!==void 0&&(this.specularMap=t[e.specularMap]||null),e.specularIntensityMap!==void 0&&(this.specularIntensityMap=t[e.specularIntensityMap]||null),e.specularColorMap!==void 0&&(this.specularColorMap=t[e.specularColorMap]||null),e.envMap!==void 0&&(this.envMap=t[e.envMap]||null),e.envMapRotation!==void 0&&this.envMapRotation.fromArray(e.envMapRotation),e.envMapIntensity!==void 0&&(this.envMapIntensity=e.envMapIntensity),e.reflectivity!==void 0&&(this.reflectivity=e.reflectivity),e.refractionRatio!==void 0&&(this.refractionRatio=e.refractionRatio),e.lightMap!==void 0&&(this.lightMap=t[e.lightMap]||null),e.lightMapIntensity!==void 0&&(this.lightMapIntensity=e.lightMapIntensity),e.aoMap!==void 0&&(this.aoMap=t[e.aoMap]||null),e.aoMapIntensity!==void 0&&(this.aoMapIntensity=e.aoMapIntensity),e.gradientMap!==void 0&&(this.gradientMap=t[e.gradientMap]||null),e.clearcoatMap!==void 0&&(this.clearcoatMap=t[e.clearcoatMap]||null),e.clearcoatRoughnessMap!==void 0&&(this.clearcoatRoughnessMap=t[e.clearcoatRoughnessMap]||null),e.clearcoatNormalMap!==void 0&&(this.clearcoatNormalMap=t[e.clearcoatNormalMap]||null),e.clearcoatNormalScale!==void 0&&(this.clearcoatNormalScale=new de().fromArray(e.clearcoatNormalScale)),e.diffuseRoughnessMap!==void 0&&(this.diffuseRoughnessMap=t[e.diffuseRoughnessMap]||null),e.iridescenceMap!==void 0&&(this.iridescenceMap=t[e.iridescenceMap]||null),e.iridescenceThicknessMap!==void 0&&(this.iridescenceThicknessMap=t[e.iridescenceThicknessMap]||null),e.transmissionMap!==void 0&&(this.transmissionMap=t[e.transmissionMap]||null),e.thicknessMap!==void 0&&(this.thicknessMap=t[e.thicknessMap]||null),e.anisotropyMap!==void 0&&(this.anisotropyMap=t[e.anisotropyMap]||null),e.sheenColorMap!==void 0&&(this.sheenColorMap=t[e.sheenColorMap]||null),e.sheenRoughnessMap!==void 0&&(this.sheenRoughnessMap=t[e.sheenRoughnessMap]||null),this}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;const t=e.clippingPlanes;let n=null;if(t!==null){const r=t.length;n=new Array(r);for(let s=0;s!==r;++s)n[s]=t[s].clone()}return this.clippingPlanes=n,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.allowOverride=e.allowOverride,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){e===!0&&this.version++}}class yu extends fi{constructor(e){super(),this.isSpriteMaterial=!0,this.type="SpriteMaterial",this.color=new Te(16777215),this.map=null,this.alphaMap=null,this.rotation=0,this.sizeAttenuation=!0,this.transparent=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.rotation=e.rotation,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}}let Vi;const pr=new P,Wi=new P,qi=new P,Xi=new de,mr=new de,Mu=new Ye,ls=new P,gr=new P,cs=new P,Mc=new de,ka=new de,bc=new de;class $f extends yt{constructor(e=new yu){if(super(),this.isSprite=!0,this.type="Sprite",Vi===void 0){Vi=new gt;const t=new Float32Array([-.5,-.5,0,0,0,.5,-.5,0,1,0,.5,.5,0,1,1,-.5,.5,0,0,1]),n=new Vf(t,5);Vi.setIndex([0,1,2,0,2,3]),Vi.setAttribute("position",new ta(n,3,0,!1)),Vi.setAttribute("uv",new ta(n,2,3,!1))}this.geometry=Vi,this.material=e,this.center=new de(.5,.5),this.count=1}intersectsFrustum(e){return e.intersectsSprite(this)}raycast(e,t){e.camera===null&&$e('Sprite: "Raycaster.camera" needs to be set in order to raycast against sprites.'),Wi.setFromMatrixScale(this.matrixWorld),Mu.copy(e.camera.matrixWorld),this.modelViewMatrix.multiplyMatrices(e.camera.matrixWorldInverse,this.matrixWorld),qi.setFromMatrixPosition(this.modelViewMatrix),e.camera.isPerspectiveCamera&&this.material.sizeAttenuation===!1&&Wi.multiplyScalar(-qi.z);const n=this.material.rotation;let r,s;n!==0&&(s=Math.cos(n),r=Math.sin(n));const a=this.center;hs(ls.set(-.5,-.5,0),qi,a,Wi,r,s),hs(gr.set(.5,-.5,0),qi,a,Wi,r,s),hs(cs.set(.5,.5,0),qi,a,Wi,r,s),Mc.set(0,0),ka.set(1,0),bc.set(1,1);let o=e.ray.intersectTriangle(ls,gr,cs,!1,pr);if(o===null&&(hs(gr.set(-.5,.5,0),qi,a,Wi,r,s),ka.set(0,1),o=e.ray.intersectTriangle(ls,cs,gr,!1,pr),o===null))return;const l=e.ray.origin.distanceTo(pr);l<e.near||l>e.far||t.push({distance:l,point:pr.clone(),uv:hn.getInterpolation(pr,ls,gr,cs,Mc,ka,bc,new de),face:null,object:this})}copy(e,t){return super.copy(e,t),e.center!==void 0&&this.center.copy(e.center),this.material=e.material,this}toJSON(e){const t=super.toJSON(e);return t.object.center=this.center.toArray(),t}}function hs(i,e,t,n,r,s){Xi.subVectors(i,t).addScalar(.5).multiply(n),r!==void 0?(mr.x=s*Xi.x-r*Xi.y,mr.y=r*Xi.x+s*Xi.y):mr.copy(Xi),i.copy(e),i.x+=mr.x,i.y+=mr.y,i.applyMatrix4(Mu)}const kn=new P,za=new P,us=new P,ds=new P;class la{constructor(e=new P,t=new P(0,0,-1)){this.origin=e,this.direction=t}set(e,t){return this.origin.copy(e),this.direction.copy(t),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,t){return t.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,kn)),this}closestPointToPoint(e,t){t.subVectors(e,this.origin);const n=t.dot(this.direction);return n<0?t.copy(this.origin):t.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){const t=kn.subVectors(e,this.origin).dot(this.direction);return t<0?this.origin.distanceToSquared(e):(kn.copy(this.origin).addScaledVector(this.direction,t),kn.distanceToSquared(e))}distanceSqToSegment(e,t,n,r){za.copy(e).add(t).multiplyScalar(.5),us.copy(t).sub(e).normalize(),ds.copy(this.origin).sub(za);const s=e.distanceTo(t)*.5,a=-this.direction.dot(us),o=ds.dot(this.direction),l=-ds.dot(us),c=ds.lengthSq(),h=Math.abs(1-a*a);let u,d,p,g;if(h>0)if(u=a*l-o,d=a*o-l,g=s*h,u>=0)if(d>=-g)if(d<=g){const v=1/h;u*=v,d*=v,p=u*(u+a*d+2*o)+d*(a*u+d+2*l)+c}else d=s,u=Math.max(0,-(a*d+o)),p=-u*u+d*(d+2*l)+c;else d=-s,u=Math.max(0,-(a*d+o)),p=-u*u+d*(d+2*l)+c;else d<=-g?(u=Math.max(0,-(-a*s+o)),d=u>0?-s:Math.min(Math.max(-s,-l),s),p=-u*u+d*(d+2*l)+c):d<=g?(u=0,d=Math.min(Math.max(-s,-l),s),p=d*(d+2*l)+c):(u=Math.max(0,-(a*s+o)),d=u>0?s:Math.min(Math.max(-s,-l),s),p=-u*u+d*(d+2*l)+c);else d=a>0?-s:s,u=Math.max(0,-(a*d+o)),p=-u*u+d*(d+2*l)+c;return n&&n.copy(this.origin).addScaledVector(this.direction,u),r&&r.copy(za).addScaledVector(us,d),p}intersectSphere(e,t){if(e.radius<0)return null;kn.subVectors(e.center,this.origin);const n=kn.dot(this.direction),r=kn.dot(kn)-n*n,s=e.radius*e.radius;if(r>s)return null;const a=Math.sqrt(s-r),o=n-a,l=n+a;return l<0?null:o<0?this.at(l,t):this.at(o,t)}intersectsSphere(e){return e.radius<0?!1:this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){const t=e.normal.dot(this.direction);if(t===0)return e.distanceToPoint(this.origin)===0?0:null;const n=-(this.origin.dot(e.normal)+e.constant)/t;return n>=0?n:null}intersectPlane(e,t){const n=this.distanceToPlane(e);return n===null?null:this.at(n,t)}intersectsPlane(e){const t=e.distanceToPoint(this.origin);return t===0||e.normal.dot(this.direction)*t<0}intersectBox(e,t){let n,r,s,a,o,l;const c=1/this.direction.x,h=1/this.direction.y,u=1/this.direction.z,d=this.origin;return c>=0?(n=(e.min.x-d.x)*c,r=(e.max.x-d.x)*c):(n=(e.max.x-d.x)*c,r=(e.min.x-d.x)*c),h>=0?(s=(e.min.y-d.y)*h,a=(e.max.y-d.y)*h):(s=(e.max.y-d.y)*h,a=(e.min.y-d.y)*h),n>a||s>r||((s>n||isNaN(n))&&(n=s),(a<r||isNaN(r))&&(r=a),u>=0?(o=(e.min.z-d.z)*u,l=(e.max.z-d.z)*u):(o=(e.max.z-d.z)*u,l=(e.min.z-d.z)*u),n>l||o>r)||((o>n||n!==n)&&(n=o),(l<r||r!==r)&&(r=l),r<0)?null:this.at(n>=0?n:r,t)}intersectsBox(e){return this.intersectBox(e,kn)!==null}intersectTriangle(e,t,n,r,s){const a=this.origin,o=this.direction,l=o.x,c=o.y,h=o.z,u=e.x-a.x,d=e.y-a.y,p=e.z-a.z,g=t.x-a.x,v=t.y-a.y,m=t.z-a.z,f=n.x-a.x,_=n.y-a.y,S=n.z-a.z,y=Math.abs(l),A=Math.abs(c),E=Math.abs(h);let x,w,I,C,N,F,V,D,H,Z,z,ne;if(y>=A&&y>=E?(I=l,F=u,H=g,ne=f,l>=0?(x=c,w=h,C=d,N=p,V=v,D=m,Z=_,z=S):(x=h,w=c,C=p,N=d,V=m,D=v,Z=S,z=_)):A>=E?(I=c,F=d,H=v,ne=_,c>=0?(x=h,w=l,C=p,N=u,V=m,D=g,Z=S,z=f):(x=l,w=h,C=u,N=p,V=g,D=m,Z=f,z=S)):(I=h,F=p,H=m,ne=S,h>=0?(x=l,w=c,C=u,N=d,V=g,D=v,Z=f,z=_):(x=c,w=l,C=d,N=u,V=v,D=g,Z=_,z=f)),I===0)return null;const q=x/I,j=w/I,ee=1/I,Se=C-q*F,Ne=N-j*F,Y=V-q*H,ge=D-j*H,ye=Z-q*ne,Re=z-j*ne,ve=ye*ge-Re*Y,Fe=Se*Re-Ne*ye,vt=Y*Ne-ge*Se;if(r){if(ve<0||Fe<0||vt<0)return null}else if((ve<0||Fe<0||vt<0)&&(ve>0||Fe>0||vt>0))return null;const Le=ve+Fe+vt;if(Le===0)return null;const Qe=ee*(ve*F+Fe*H+vt*ne);return(Le>0?Qe<0:Qe>0)?null:this.at(Qe/Le,s)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class bn extends fi{constructor(e){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new Te(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Dn,this.combine=Kh,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}}const Sc=new Ye,Mi=new la,fs=new Pi,wc=new P,ps=new P,ms=new P,gs=new P,Ga=new P,vs=new P,Ec=new P,xs=new P;class mt extends yt{constructor(e=new gt,t=new bn){super(),this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0?this.morphTargetInfluences=e.morphTargetInfluences.slice():this.morphTargetInfluences=void 0,e.morphTargetDictionary!==void 0?this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary):this.morphTargetDictionary=void 0,this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){const t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){const r=t[n[0]];if(r!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let s=0,a=r.length;s<a;s++){const o=r[s].name||String(s);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=s}}}}getVertexPosition(e,t){const n=this.geometry,r=n.attributes.position,s=n.morphAttributes.position,a=n.morphTargetsRelative;t.fromBufferAttribute(r,e);const o=this.morphTargetInfluences;if(s&&o){vs.set(0,0,0);for(let l=0,c=s.length;l<c;l++){const h=o[l],u=s[l];h!==0&&(Ga.fromBufferAttribute(u,e),a?vs.addScaledVector(Ga,h):vs.addScaledVector(Ga.sub(t),h))}t.add(vs)}return t}intersectsFrustum(e){return e.intersectsObject(this)}raycast(e,t){const n=this.geometry,r=this.material,s=this.matrixWorld;r!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),fs.copy(n.boundingSphere),fs.applyMatrix4(s),Mi.copy(e.ray).recast(e.near),!(fs.containsPoint(Mi.origin)===!1&&(Mi.intersectSphere(fs,wc)===null||Mi.origin.distanceToSquared(wc)>(e.far-e.near)**2))&&(Sc.copy(s).invert(),Mi.copy(e.ray).applyMatrix4(Sc),!(n.boundingBox!==null&&Mi.intersectsBox(n.boundingBox)===!1)&&this._computeIntersections(e,t,Mi)))}_computeIntersections(e,t,n){let r;const s=this.geometry,a=this.material,o=s.index,l=s.attributes.position,c=s.attributes.uv,h=s.attributes.uv1,u=s.attributes.normal,d=s.groups,p=s.drawRange;if(o!==null)if(Array.isArray(a))for(let g=0,v=d.length;g<v;g++){const m=d[g],f=a[m.materialIndex],_=Math.max(m.start,p.start),S=Math.min(o.count,Math.min(m.start+m.count,p.start+p.count));for(let y=_,A=S;y<A;y+=3){const E=o.getX(y),x=o.getX(y+1),w=o.getX(y+2);r=_s(this,f,e,n,c,h,u,E,x,w),r&&(r.faceIndex=Math.floor(y/3),r.face.materialIndex=m.materialIndex,t.push(r))}}else{const g=Math.max(0,p.start),v=Math.min(o.count,p.start+p.count);for(let m=g,f=v;m<f;m+=3){const _=o.getX(m),S=o.getX(m+1),y=o.getX(m+2);r=_s(this,a,e,n,c,h,u,_,S,y),r&&(r.faceIndex=Math.floor(m/3),t.push(r))}}else if(l!==void 0)if(Array.isArray(a))for(let g=0,v=d.length;g<v;g++){const m=d[g],f=a[m.materialIndex],_=Math.max(m.start,p.start),S=Math.min(l.count,Math.min(m.start+m.count,p.start+p.count));for(let y=_,A=S;y<A;y+=3){const E=y,x=y+1,w=y+2;r=_s(this,f,e,n,c,h,u,E,x,w),r&&(r.faceIndex=Math.floor(y/3),r.face.materialIndex=m.materialIndex,t.push(r))}}else{const g=Math.max(0,p.start),v=Math.min(l.count,p.start+p.count);for(let m=g,f=v;m<f;m+=3){const _=m,S=m+1,y=m+2;r=_s(this,a,e,n,c,h,u,_,S,y),r&&(r.faceIndex=Math.floor(m/3),t.push(r))}}}}function Yf(i,e,t,n,r,s,a,o){let l;if(e.side===qt?l=n.intersectTriangle(a,s,r,!0,o):l=n.intersectTriangle(r,s,a,e.side===Ei,o),l===null)return null;xs.copy(o),xs.applyMatrix4(i.matrixWorld);const c=t.ray.origin.distanceTo(xs);return c<t.near||c>t.far?null:{distance:c,point:xs.clone(),object:i}}function _s(i,e,t,n,r,s,a,o,l,c){i.getVertexPosition(o,ps),i.getVertexPosition(l,ms),i.getVertexPosition(c,gs);const h=Yf(i,e,t,n,ps,ms,gs,Ec);if(h){const u=new P;hn.getBarycoord(Ec,ps,ms,gs,u),r&&(h.uv=hn.getInterpolatedAttribute(r,o,l,c,u,new de)),s&&(h.uv1=hn.getInterpolatedAttribute(s,o,l,c,u,new de)),a&&(h.normal=hn.getInterpolatedAttribute(a,o,l,c,u,new P),h.normal.dot(n.direction)>0&&h.normal.multiplyScalar(-1));const d={a:o,b:l,c,normal:new P,materialIndex:0};hn.getNormal(ps,ms,gs,d.normal),h.face=d,h.barycoord=u}return h}class bu extends kt{constructor(e=null,t=1,n=1,r,s,a,o,l,c=Dt,h=Dt,u,d){super(null,a,o,l,c,h,r,s,u,d),this.isDataTexture=!0,this.image={data:e,width:t,height:n},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class Tc extends jt{constructor(e,t,n,r=1){super(e,t,n),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=r}copy(e){return super.copy(e),this.meshPerAttribute=e.meshPerAttribute,this}toJSON(){const e=super.toJSON();return e.meshPerAttribute=this.meshPerAttribute,e.isInstancedBufferAttribute=!0,e}}const $i=new Ye,Ac=new Ye,ys=[],Rc=new di,Kf=new Ye,vr=new mt,xr=new Pi;class Zf extends mt{constructor(e,t,n){super(e,t),this.isInstancedMesh=!0,this.instanceMatrix=new Tc(new Float32Array(n*16),16),this.instanceColor=null,this.morphTexture=null,this.count=n,this.boundingBox=null,this.boundingSphere=null;for(let r=0;r<n;r++)this.setMatrixAt(r,Kf)}computeBoundingBox(){const e=this.geometry,t=this.count;this.boundingBox===null&&(this.boundingBox=new di),e.boundingBox===null&&e.computeBoundingBox(),this.boundingBox.makeEmpty();for(let n=0;n<t;n++)this.getMatrixAt(n,$i),Rc.copy(e.boundingBox).applyMatrix4($i),this.boundingBox.union(Rc)}computeBoundingSphere(){const e=this.geometry,t=this.count;this.boundingSphere===null&&(this.boundingSphere=new Pi),e.boundingSphere===null&&e.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let n=0;n<t;n++)this.getMatrixAt(n,$i),xr.copy(e.boundingSphere).applyMatrix4($i),this.boundingSphere.union(xr)}copy(e,t){return super.copy(e,t),this.instanceMatrix.copy(e.instanceMatrix),this.morphTexture=e.morphTexture!==null?e.morphTexture.clone():null,this.instanceColor=e.instanceColor!==null?e.instanceColor.clone():null,this.count=e.count,this.boundingBox=e.boundingBox!==null?e.boundingBox.clone():null,this.boundingSphere=e.boundingSphere!==null?e.boundingSphere.clone():null,this}getColorAt(e,t){return this.instanceColor===null?t.setRGB(1,1,1):t.fromArray(this.instanceColor.array,e*3)}getMatrixAt(e,t){return t.fromArray(this.instanceMatrix.array,e*16)}getMorphAt(e,t){const n=t.morphTargetInfluences,r=this.morphTexture.source.data.data,s=n.length+1,a=e*s+1;for(let o=0;o<n.length;o++)n[o]=r[a+o]}raycast(e,t){const n=this.matrixWorld,r=this.count;if(vr.geometry=this.geometry,vr.material=this.material,vr.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),xr.copy(this.boundingSphere),xr.applyMatrix4(n),e.ray.intersectsSphere(xr)!==!1))for(let s=0;s<r;s++){this.getMatrixAt(s,$i),Ac.multiplyMatrices(n,$i),vr.matrixWorld=Ac,vr.raycast(e,ys);for(let a=0,o=ys.length;a<o;a++){const l=ys[a];l.instanceId=s,l.object=this,t.push(l)}ys.length=0}}setColorAt(e,t){return this.instanceColor===null&&(this.instanceColor=new Tc(new Float32Array(this.instanceMatrix.count*3).fill(1),3)),t.toArray(this.instanceColor.array,e*3),this}setMatrixAt(e,t){return t.toArray(this.instanceMatrix.array,e*16),this}setMorphAt(e,t){const n=t.morphTargetInfluences,r=n.length+1;this.morphTexture===null&&(this.morphTexture=new bu(new Float32Array(r*this.count),r,this.count,pl,_n));const s=this.morphTexture.source.data.data;let a=0;for(let c=0;c<n.length;c++)a+=n[c];const o=this.geometry.morphTargetsRelative?1:1-a,l=r*e;return s[l]=o,s.set(n,l+1),this}updateMorphTargets(){}dispose(){super.dispose(),this.instanceMatrix.dispose(),this.instanceColor!==null&&this.instanceColor.dispose(),this.morphTexture!==null&&(this.morphTexture.dispose(),this.morphTexture=null)}}const bi=new Pi,Jf=new de(.5,.5),Ms=new P;class Gr{constructor(e=new Hn,t=new Hn,n=new Hn,r=new Hn,s=new Hn,a=new Hn){this.planes=[e,t,n,r,s,a]}set(e,t,n,r,s,a){const o=this.planes;return o[0].copy(e),o[1].copy(t),o[2].copy(n),o[3].copy(r),o[4].copy(s),o[5].copy(a),this}copy(e){const t=this.planes;for(let n=0;n<6;n++)t[n].copy(e.planes[n]);return this}setFromProjectionMatrix(e,t=yn,n=!1){const r=this.planes,s=e.elements,a=s[0],o=s[1],l=s[2],c=s[3],h=s[4],u=s[5],d=s[6],p=s[7],g=s[8],v=s[9],m=s[10],f=s[11],_=s[12],S=s[13],y=s[14],A=s[15];if(r[0].setComponents(c-a,p-h,f-g,A-_).normalize(),r[1].setComponents(c+a,p+h,f+g,A+_).normalize(),r[2].setComponents(c+o,p+u,f+v,A+S).normalize(),r[3].setComponents(c-o,p-u,f-v,A-S).normalize(),n)r[4].setComponents(l,d,m,y).normalize(),r[5].setComponents(c-l,p-d,f-m,A-y).normalize();else if(r[4].setComponents(c-l,p-d,f-m,A-y).normalize(),t===yn)r[5].setComponents(c+l,p+d,f+m,A+y).normalize();else if(t===kr)r[5].setComponents(l,d,m,y).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+t);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),bi.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{const t=e.geometry;t.boundingSphere===null&&t.computeBoundingSphere(),bi.copy(t.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(bi)}intersectsSprite(e){bi.center.set(0,0,0);const t=Jf.distanceTo(e.center);return bi.radius=.7071067811865476+t,bi.applyMatrix4(e.matrixWorld),this.intersectsSphere(bi)}intersectsSphere(e){const t=this.planes,n=e.center,r=-e.radius;for(let s=0;s<6;s++)if(t[s].distanceToPoint(n)<r)return!1;return!0}intersectsBox(e){const t=this.planes;for(let n=0;n<6;n++){const r=t[n];if(Ms.x=r.normal.x>0?e.max.x:e.min.x,Ms.y=r.normal.y>0?e.max.y:e.min.y,Ms.z=r.normal.z>0?e.max.z:e.min.z,r.distanceToPoint(Ms)<0)return!1}return!0}containsPoint(e){const t=this.planes;for(let n=0;n<6;n++)if(t[n].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}const Cc=new Ye;class wl{constructor(){this.coordinateSystem=yn,this._frustums=[],this._count=0}setFromArrayCamera(e){const t=e.cameras,n=this._frustums;for(let r=0;r<t.length;r++){const s=t[r];Cc.multiplyMatrices(s.projectionMatrix,s.matrixWorldInverse),n[r]===void 0&&(n[r]=new Gr),n[r].setFromProjectionMatrix(Cc,s.coordinateSystem,s.reversedDepth)}return this._count=t.length,this}getFrustum(e){return this._frustums[e]}intersectsObject(e){const t=this._frustums;for(let n=0;n<this._count;n++)if(t[n].intersectsObject(e))return!0;return!1}intersectsSprite(e){const t=this._frustums;for(let n=0;n<this._count;n++)if(t[n].intersectsSprite(e))return!0;return!1}intersectsSphere(e){const t=this._frustums;for(let n=0;n<this._count;n++)if(t[n].intersectsSphere(e))return!0;return!1}intersectsBox(e){const t=this._frustums;for(let n=0;n<this._count;n++)if(t[n].intersectsBox(e))return!0;return!1}containsPoint(e){const t=this._frustums;for(let n=0;n<this._count;n++)if(t[n].containsPoint(e))return!0;return!1}copy(e){this.coordinateSystem=e.coordinateSystem;const t=this._frustums,n=e._frustums;for(let r=0;r<e._count;r++)t[r]===void 0&&(t[r]=new Gr),t[r].copy(n[r]);return this._count=e._count,this}clone(){return new wl().copy(this)}}class Su extends fi{constructor(e){super(),this.isLineBasicMaterial=!0,this.type="LineBasicMaterial",this.color=new Te(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.linewidth=e.linewidth,this.linecap=e.linecap,this.linejoin=e.linejoin,this.fog=e.fog,this}}const na=new P,ia=new P,Pc=new Ye,_r=new la,bs=new Pi,Ha=new P,Lc=new P;class Qf extends yt{constructor(e=new gt,t=new Su){super(),this.isLine=!0,this.type="Line",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0?this.morphTargetInfluences=e.morphTargetInfluences.slice():this.morphTargetInfluences=void 0,e.morphTargetDictionary!==void 0?this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary):this.morphTargetDictionary=void 0,this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}computeLineDistances(){const e=this.geometry;if(e.index===null){const t=e.attributes.position,n=[0];for(let r=1,s=t.count;r<s;r++)na.fromBufferAttribute(t,r-1),ia.fromBufferAttribute(t,r),n[r]=n[r-1],n[r]+=na.distanceTo(ia);e.setAttribute("lineDistance",new We(n,1))}else Pe("Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}intersectsFrustum(e){return e.intersectsObject(this)}raycast(e,t){const n=this.geometry,r=this.matrixWorld,s=e.params.Line.threshold,a=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),bs.copy(n.boundingSphere),bs.applyMatrix4(r),bs.radius+=s,e.ray.intersectsSphere(bs)===!1)return;Pc.copy(r).invert(),_r.copy(e.ray).applyMatrix4(Pc);const o=s/((this.scale.x+this.scale.y+this.scale.z)/3),l=o*o,c=this.isLineSegments?2:1,h=n.index,d=n.attributes.position;if(h!==null){const p=Math.max(0,a.start),g=Math.min(h.count,a.start+a.count);for(let v=p,m=g-1;v<m;v+=c){const f=h.getX(v),_=h.getX(v+1),S=Ss(this,e,_r,l,f,_,v);S&&t.push(S)}if(this.isLineLoop){const v=h.getX(g-1),m=h.getX(p),f=Ss(this,e,_r,l,v,m,g-1);f&&t.push(f)}}else{const p=Math.max(0,a.start),g=Math.min(d.count,a.start+a.count);for(let v=p,m=g-1;v<m;v+=c){const f=Ss(this,e,_r,l,v,v+1,v);f&&t.push(f)}if(this.isLineLoop){const v=Ss(this,e,_r,l,g-1,p,g-1);v&&t.push(v)}}}updateMorphTargets(){const t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){const r=t[n[0]];if(r!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let s=0,a=r.length;s<a;s++){const o=r[s].name||String(s);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=s}}}}}function Ss(i,e,t,n,r,s,a){const o=i.geometry.attributes.position;if(na.fromBufferAttribute(o,r),ia.fromBufferAttribute(o,s),t.distanceSqToSegment(na,ia,Ha,Lc)>n)return;Ha.applyMatrix4(i.matrixWorld);const c=e.ray.origin.distanceTo(Ha);if(!(c<e.near||c>e.far))return{distance:c,point:Lc.clone().applyMatrix4(i.matrixWorld),index:a,face:null,faceIndex:null,barycoord:null,object:i}}const Dc=new P,Ic=new P;class jf extends Qf{constructor(e,t){super(e,t),this.isLineSegments=!0,this.type="LineSegments"}computeLineDistances(){const e=this.geometry;if(e.index===null){const t=e.attributes.position,n=[];for(let r=0,s=t.count;r<s;r+=2)Dc.fromBufferAttribute(t,r),Ic.fromBufferAttribute(t,r+1),n[r]=r===0?0:n[r-1],n[r+1]=n[r]+Dc.distanceTo(Ic);e.setAttribute("lineDistance",new We(n,1))}else Pe("LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}}class wu extends fi{constructor(e){super(),this.isPointsMaterial=!0,this.type="PointsMaterial",this.color=new Te(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.size=e.size,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}}const Nc=new Ye,Go=new la,ws=new Pi,Es=new P;class ep extends yt{constructor(e=new gt,t=new wu){super(),this.isPoints=!0,this.type="Points",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0?this.morphTargetInfluences=e.morphTargetInfluences.slice():this.morphTargetInfluences=void 0,e.morphTargetDictionary!==void 0?this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary):this.morphTargetDictionary=void 0,this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}intersectsFrustum(e){return e.intersectsObject(this)}raycast(e,t){const n=this.geometry,r=this.matrixWorld,s=e.params.Points.threshold,a=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),ws.copy(n.boundingSphere),ws.applyMatrix4(r),ws.radius+=s,e.ray.intersectsSphere(ws)===!1)return;Nc.copy(r).invert(),Go.copy(e.ray).applyMatrix4(Nc);const o=s/((this.scale.x+this.scale.y+this.scale.z)/3),l=o*o,c=n.index,u=n.attributes.position;if(c!==null){const d=Math.max(0,a.start),p=Math.min(c.count,a.start+a.count);for(let g=d,v=p;g<v;g++){const m=c.getX(g);Es.fromBufferAttribute(u,m),Uc(Es,m,l,r,e,t,this)}}else{const d=Math.max(0,a.start),p=Math.min(u.count,a.start+a.count);for(let g=d,v=p;g<v;g++)Es.fromBufferAttribute(u,g),Uc(Es,g,l,r,e,t,this)}}updateMorphTargets(){const t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){const r=t[n[0]];if(r!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let s=0,a=r.length;s<a;s++){const o=r[s].name||String(s);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=s}}}}}function Uc(i,e,t,n,r,s,a){const o=Go.distanceSqToPoint(i);if(o<t){const l=new P;Go.closestPointToPoint(i,l),l.applyMatrix4(n);const c=r.ray.origin.distanceTo(l);if(c<r.near||c>r.far)return;s.push({distance:c,distanceToRay:Math.sqrt(o),point:l,index:e,face:null,faceIndex:null,barycoord:null,object:a})}}class Eu extends kt{constructor(e=[],t=tr,n,r,s,a,o,l,c,h){super(e,t,n,r,s,a,o,l,c,h),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}}class Tu extends kt{constructor(e,t,n,r,s,a,o,l,c){super(e,t,n,r,s,a,o,l,c),this.isCanvasTexture=!0,this.needsUpdate=!0}}class ir extends kt{constructor(e,t,n=Pn,r,s,a,o=Dt,l=Dt,c,h=oi,u=1){if(h!==oi&&h!==ri)throw new Error("THREE.DepthTexture: format must be either THREE.DepthFormat or THREE.DepthStencilFormat");const d={width:e,height:t,depth:u};super(d,r,s,a,o,l,h,n,c),this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.source=new Ml(Object.assign({},e.image)),this.compareFunction=e.compareFunction,this}toJSON(e){const t=super.toJSON(e);return t.compareFunction=this.compareFunction,t}}class Au extends ir{constructor(e,t=Pn,n=tr,r,s,a=Dt,o=Dt,l,c=oi){const h={width:e,height:e,depth:1},u=[h,h,h,h,h,h];super(e,e,t,n,r,s,a,o,l,c),this.image=u,this.isCubeDepthTexture=!0,this.isCubeTexture=!0}get images(){return this.image}set images(e){this.image=e}}class Ru extends kt{constructor(e=null){super(),this.sourceTexture=e,this.isExternalTexture=!0}copy(e){return super.copy(e),this.sourceTexture=e.sourceTexture,this}}class Li extends gt{constructor(e=1,t=1,n=1,r=1,s=1,a=1){super(),this.type="BoxGeometry",this.parameters={width:e,height:t,depth:n,widthSegments:r,heightSegments:s,depthSegments:a};const o=this;r=Math.floor(r),s=Math.floor(s),a=Math.floor(a);const l=[],c=[],h=[],u=[];let d=0,p=0;g("z","y","x",-1,-1,n,t,e,a,s,0),g("z","y","x",1,-1,n,t,-e,a,s,1),g("x","z","y",1,1,e,n,t,r,a,2),g("x","z","y",1,-1,e,n,-t,r,a,3),g("x","y","z",1,-1,e,t,n,r,s,4),g("x","y","z",-1,-1,e,t,-n,r,s,5),this.setIndex(l),this.setAttribute("position",new We(c,3)),this.setAttribute("normal",new We(h,3)),this.setAttribute("uv",new We(u,2));function g(v,m,f,_,S,y,A,E,x,w,I){const C=y/x,N=A/w,F=y/2,V=A/2,D=E/2,H=x+1,Z=w+1;let z=0,ne=0;const q=new P;for(let j=0;j<Z;j++){const ee=j*N-V;for(let Se=0;Se<H;Se++){const Ne=Se*C-F;q[v]=Ne*_,q[m]=ee*S,q[f]=D,c.push(q.x,q.y,q.z),q[v]=0,q[m]=0,q[f]=E>0?1:-1,h.push(q.x,q.y,q.z),u.push(Se/x),u.push(1-j/w),z+=1}}for(let j=0;j<w;j++)for(let ee=0;ee<x;ee++){const Se=d+ee+H*j,Ne=d+ee+H*(j+1),Y=d+(ee+1)+H*(j+1),ge=d+(ee+1)+H*j;l.push(Se,Ne,ge),l.push(Ne,Y,ge),ne+=6}o.addGroup(p,ne,I),p+=ne,d+=z}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Li(e.width,e.height,e.depth,e.widthSegments,e.heightSegments,e.depthSegments)}}class El extends gt{constructor(e=1,t=32,n=0,r=Math.PI*2){super(),this.type="CircleGeometry",this.parameters={radius:e,segments:t,thetaStart:n,thetaLength:r},t=Math.max(3,t);const s=[],a=[],o=[],l=[],c=new P,h=new de;a.push(0,0,0),o.push(0,0,1),l.push(.5,.5);for(let u=0,d=3;u<=t;u++,d+=3){const p=n+u/t*r;c.x=e*Math.cos(p),c.y=e*Math.sin(p),a.push(c.x,c.y,c.z),o.push(0,0,1),h.x=(a[d]/e+1)/2,h.y=(a[d+1]/e+1)/2,l.push(h.x,h.y)}for(let u=1;u<=t;u++)s.push(u,u+1,0);this.setIndex(s),this.setAttribute("position",new We(a,3)),this.setAttribute("normal",new We(o,3)),this.setAttribute("uv",new We(l,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new El(e.radius,e.segments,e.thetaStart,e.thetaLength)}}class or extends gt{constructor(e=1,t=1,n=1,r=32,s=1,a=!1,o=0,l=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:e,radiusBottom:t,height:n,radialSegments:r,heightSegments:s,openEnded:a,thetaStart:o,thetaLength:l};const c=this;r=Math.floor(r),s=Math.floor(s);const h=[],u=[],d=[],p=[];let g=0;const v=[],m=n/2;let f=0;_(),a===!1&&(e>0&&S(!0),t>0&&S(!1)),this.setIndex(h),this.setAttribute("position",new We(u,3)),this.setAttribute("normal",new We(d,3)),this.setAttribute("uv",new We(p,2));function _(){const y=new P,A=new P;let E=0;const x=(t-e)/n;for(let w=0;w<=s;w++){const I=[],C=w/s,N=C*(t-e)+e;for(let F=0;F<=r;F++){const V=F/r,D=V*l+o,H=Math.sin(D),Z=Math.cos(D);A.x=N*H,A.y=-C*n+m,A.z=N*Z,u.push(A.x,A.y,A.z),y.set(H,x,Z).normalize(),d.push(y.x,y.y,y.z),p.push(V,1-C),I.push(g++)}v.push(I)}for(let w=0;w<r;w++)for(let I=0;I<s;I++){const C=v[I][w],N=v[I+1][w],F=v[I+1][w+1],V=v[I][w+1];(e>0||I!==0)&&(h.push(C,N,V),E+=3),(t>0||I!==s-1)&&(h.push(N,F,V),E+=3)}c.addGroup(f,E,0),f+=E}function S(y){const A=g,E=new de,x=new P;let w=0;const I=y===!0?e:t,C=y===!0?1:-1;for(let F=1;F<=r;F++)u.push(0,m*C,0),d.push(0,C,0),p.push(.5,.5),g++;const N=g;for(let F=0;F<=r;F++){const D=F/r*l+o,H=Math.cos(D),Z=Math.sin(D);x.x=I*Z,x.y=m*C,x.z=I*H,u.push(x.x,x.y,x.z),d.push(0,C,0),E.x=H*.5+.5,E.y=Z*.5*C+.5,p.push(E.x,E.y),g++}for(let F=0;F<r;F++){const V=A+F,D=N+F;y===!0?h.push(D,D+1,V):h.push(D+1,D,V),w+=3}c.addGroup(f,w,y===!0?1:2),f+=w}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new or(e.radiusTop,e.radiusBottom,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}}class Ai extends or{constructor(e=1,t=1,n=32,r=1,s=!1,a=0,o=Math.PI*2){super(0,e,t,n,r,s,a,o),this.type="ConeGeometry",this.parameters={radius:e,height:t,radialSegments:n,heightSegments:r,openEnded:s,thetaStart:a,thetaLength:o}}static fromJSON(e){return new Ai(e.radius,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}}class Tl extends gt{constructor(e=[],t=[],n=1,r=0){super(),this.type="PolyhedronGeometry",this.parameters={vertices:e,indices:t,radius:n,detail:r};const s=[],a=[];o(r),c(n),h(),this.setAttribute("position",new We(s,3)),this.setAttribute("normal",new We(s.slice(),3)),this.setAttribute("uv",new We(a,2)),r===0?this.computeVertexNormals():this.normalizeNormals();function o(_){const S=new P,y=new P,A=new P;for(let E=0;E<t.length;E+=3)p(t[E+0],S),p(t[E+1],y),p(t[E+2],A),l(S,y,A,_)}function l(_,S,y,A){const E=A+1,x=[];for(let w=0;w<=E;w++){x[w]=[];const I=_.clone().lerp(y,w/E),C=S.clone().lerp(y,w/E),N=E-w;for(let F=0;F<=N;F++)F===0&&w===E?x[w][F]=I:x[w][F]=I.clone().lerp(C,F/N)}for(let w=0;w<E;w++)for(let I=0;I<2*(E-w)-1;I++){const C=Math.floor(I/2);I%2===0?(d(x[w][C+1]),d(x[w+1][C]),d(x[w][C])):(d(x[w][C+1]),d(x[w+1][C+1]),d(x[w+1][C]))}}function c(_){const S=new P;for(let y=0;y<s.length;y+=3)S.x=s[y+0],S.y=s[y+1],S.z=s[y+2],S.normalize().multiplyScalar(_),s[y+0]=S.x,s[y+1]=S.y,s[y+2]=S.z}function h(){const _=new P;for(let S=0;S<s.length;S+=3){_.x=s[S+0],_.y=s[S+1],_.z=s[S+2];const y=m(_)/2/Math.PI+.5,A=f(_)/Math.PI+.5;a.push(y,1-A)}g(),u()}function u(){for(let _=0;_<a.length;_+=6){const S=a[_+0],y=a[_+2],A=a[_+4],E=Math.max(S,y,A),x=Math.min(S,y,A);E>.9&&x<.1&&(S<.2&&(a[_+0]+=1),y<.2&&(a[_+2]+=1),A<.2&&(a[_+4]+=1))}}function d(_){s.push(_.x,_.y,_.z)}function p(_,S){const y=_*3;S.x=e[y+0],S.y=e[y+1],S.z=e[y+2]}function g(){const _=new P,S=new P,y=new P,A=new P,E=new de,x=new de,w=new de;for(let I=0,C=0;I<s.length;I+=9,C+=6){_.set(s[I+0],s[I+1],s[I+2]),S.set(s[I+3],s[I+4],s[I+5]),y.set(s[I+6],s[I+7],s[I+8]),E.set(a[C+0],a[C+1]),x.set(a[C+2],a[C+3]),w.set(a[C+4],a[C+5]),A.copy(_).add(S).add(y).divideScalar(3);const N=m(A);v(E,C+0,_,N),v(x,C+2,S,N),v(w,C+4,y,N)}}function v(_,S,y,A){A<0&&_.x===1&&(a[S]=_.x-1),y.x===0&&y.z===0&&(a[S]=A/2/Math.PI+.5)}function m(_){return Math.atan2(_.z,-_.x)}function f(_){return Math.atan2(-_.y,Math.sqrt(_.x*_.x+_.z*_.z))}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Tl(e.vertices,e.indices,e.radius,e.detail)}}class In{constructor(){this.type="Curve",this.arcLengthDivisions=200,this.needsUpdate=!1,this.cacheArcLengths=null}getPoint(){Pe("Curve: .getPoint() not implemented.")}getPointAt(e,t){const n=this.getUtoTmapping(e);return this.getPoint(n,t)}getPoints(e=5){const t=[];for(let n=0;n<=e;n++)t.push(this.getPoint(n/e));return t}getSpacedPoints(e=5){const t=[];for(let n=0;n<=e;n++)t.push(this.getPointAt(n/e));return t}getLength(){const e=this.getLengths();return e[e.length-1]}getLengths(e=this.arcLengthDivisions){if(this.cacheArcLengths&&this.cacheArcLengths.length===e+1&&!this.needsUpdate)return this.cacheArcLengths;this.needsUpdate=!1;const t=[];let n,r=this.getPoint(0),s=0;t.push(0);for(let a=1;a<=e;a++)n=this.getPoint(a/e),s+=n.distanceTo(r),t.push(s),r=n;return this.cacheArcLengths=t,t}updateArcLengths(){this.needsUpdate=!0,this.getLengths()}getUtoTmapping(e,t=null){const n=this.getLengths();let r=0;const s=n.length;let a;t?a=t:a=e*n[s-1];let o=0,l=s-1,c;for(;o<=l;)if(r=Math.floor(o+(l-o)/2),c=n[r]-a,c<0)o=r+1;else if(c>0)l=r-1;else{l=r;break}if(r=l,n[r]===a)return r/(s-1);const h=n[r],d=n[r+1]-h,p=(a-h)/d;return(r+p)/(s-1)}getTangent(e,t){let r=e-1e-4,s=e+1e-4;r<0&&(r=0),s>1&&(s=1);const a=this.getPoint(r),o=this.getPoint(s),l=t||(a.isVector2?new de:new P);return l.copy(o).sub(a).normalize(),l}getTangentAt(e,t){const n=this.getUtoTmapping(e);return this.getTangent(n,t)}computeFrenetFrames(e,t=!1){const n=new P,r=[],s=[],a=[],o=new P,l=new Ye;for(let p=0;p<=e;p++){const g=p/e;r[p]=this.getTangentAt(g,new P)}s[0]=new P,a[0]=new P;let c=Number.MAX_VALUE;const h=Math.abs(r[0].x),u=Math.abs(r[0].y),d=Math.abs(r[0].z);h<=c&&(c=h,n.set(1,0,0)),u<=c&&(c=u,n.set(0,1,0)),d<=c&&n.set(0,0,1),o.crossVectors(r[0],n).normalize(),s[0].crossVectors(r[0],o),a[0].crossVectors(r[0],s[0]);for(let p=1;p<=e;p++){if(s[p]=s[p-1].clone(),a[p]=a[p-1].clone(),o.crossVectors(r[p-1],r[p]),o.length()>Number.EPSILON){o.normalize();const g=Math.acos(ze(r[p-1].dot(r[p]),-1,1));s[p].applyMatrix4(l.makeRotationAxis(o,g))}a[p].crossVectors(r[p],s[p])}if(t===!0){let p=Math.acos(ze(s[0].dot(s[e]),-1,1));p/=e,r[0].dot(o.crossVectors(s[0],s[e]))>0&&(p=-p);for(let g=1;g<=e;g++)s[g].applyMatrix4(l.makeRotationAxis(r[g],p*g)),a[g].crossVectors(r[g],s[g])}return{tangents:r,normals:s,binormals:a}}clone(){return new this.constructor().copy(this)}copy(e){return this.arcLengthDivisions=e.arcLengthDivisions,this.cacheArcLengths=null,this}toJSON(){const e={metadata:{version:4.7,type:"Curve",generator:"Curve.toJSON"}};return e.arcLengthDivisions=this.arcLengthDivisions,e.type=this.type,e}fromJSON(e){return this.arcLengthDivisions=e.arcLengthDivisions,this.cacheArcLengths=null,this}}class Al extends In{constructor(e=0,t=0,n=1,r=1,s=0,a=Math.PI*2,o=!1,l=0){super(),this.isEllipseCurve=!0,this.type="EllipseCurve",this.aX=e,this.aY=t,this.xRadius=n,this.yRadius=r,this.aStartAngle=s,this.aEndAngle=a,this.aClockwise=o,this.aRotation=l}getPoint(e,t=new de){const n=t,r=Math.PI*2;let s=this.aEndAngle-this.aStartAngle;const a=Math.abs(s)<Number.EPSILON;for(;s<0;)s+=r;for(;s>r;)s-=r;s<Number.EPSILON&&(a?s=0:s=r),this.aClockwise===!0&&!a&&(s===r?s=-r:s=s-r);const o=this.aStartAngle+e*s;let l=this.aX+this.xRadius*Math.cos(o),c=this.aY+this.yRadius*Math.sin(o);if(this.aRotation!==0){const h=Math.cos(this.aRotation),u=Math.sin(this.aRotation),d=l-this.aX,p=c-this.aY;l=d*h-p*u+this.aX,c=d*u+p*h+this.aY}return n.set(l,c)}copy(e){return super.copy(e),this.aX=e.aX,this.aY=e.aY,this.xRadius=e.xRadius,this.yRadius=e.yRadius,this.aStartAngle=e.aStartAngle,this.aEndAngle=e.aEndAngle,this.aClockwise=e.aClockwise,this.aRotation=e.aRotation,this}toJSON(){const e=super.toJSON();return e.aX=this.aX,e.aY=this.aY,e.xRadius=this.xRadius,e.yRadius=this.yRadius,e.aStartAngle=this.aStartAngle,e.aEndAngle=this.aEndAngle,e.aClockwise=this.aClockwise,e.aRotation=this.aRotation,e}fromJSON(e){return super.fromJSON(e),this.aX=e.aX,this.aY=e.aY,this.xRadius=e.xRadius,this.yRadius=e.yRadius,this.aStartAngle=e.aStartAngle,this.aEndAngle=e.aEndAngle,this.aClockwise=e.aClockwise,this.aRotation=e.aRotation,this}}class tp extends Al{constructor(e,t,n,r,s,a){super(e,t,n,n,r,s,a),this.isArcCurve=!0,this.type="ArcCurve"}}function Rl(){let i=0,e=0,t=0,n=0;function r(s,a,o,l){i=s,e=o,t=-3*s+3*a-2*o-l,n=2*s-2*a+o+l}return{initCatmullRom:function(s,a,o,l,c){r(a,o,c*(o-s),c*(l-a))},initNonuniformCatmullRom:function(s,a,o,l,c,h,u){let d=(a-s)/c-(o-s)/(c+h)+(o-a)/h,p=(o-a)/h-(l-a)/(h+u)+(l-o)/u;d*=h,p*=h,r(a,o,d,p)},calc:function(s){const a=s*s,o=a*s;return i+e*s+t*a+n*o}}}const Fc=new P,Oc=new P,Va=new Rl,Wa=new Rl,qa=new Rl;class np extends In{constructor(e=[],t=!1,n="centripetal",r=.5){super(),this.isCatmullRomCurve3=!0,this.type="CatmullRomCurve3",this.points=e,this.closed=t,this.curveType=n,this.tension=r}getPoint(e,t=new P){const n=t,r=this.points,s=r.length,a=(s-(this.closed?0:1))*e;let o=Math.floor(a),l=a-o;this.closed?o+=o>0?0:(Math.floor(Math.abs(o)/s)+1)*s:l===0&&o===s-1&&(o=s-2,l=1);let c,h;this.closed||o>0?c=r[(o-1)%s]:(Oc.subVectors(r[0],r[1]).add(r[0]),c=Oc);const u=r[o%s],d=r[(o+1)%s];if(this.closed||o+2<s?h=r[(o+2)%s]:(Fc.subVectors(r[s-1],r[s-2]).add(r[s-1]),h=Fc),this.curveType==="centripetal"||this.curveType==="chordal"){const p=this.curveType==="chordal"?.5:.25;let g=Math.pow(c.distanceToSquared(u),p),v=Math.pow(u.distanceToSquared(d),p),m=Math.pow(d.distanceToSquared(h),p);v<1e-4&&(v=1),g<1e-4&&(g=v),m<1e-4&&(m=v),Va.initNonuniformCatmullRom(c.x,u.x,d.x,h.x,g,v,m),Wa.initNonuniformCatmullRom(c.y,u.y,d.y,h.y,g,v,m),qa.initNonuniformCatmullRom(c.z,u.z,d.z,h.z,g,v,m)}else this.curveType==="catmullrom"&&(Va.initCatmullRom(c.x,u.x,d.x,h.x,this.tension),Wa.initCatmullRom(c.y,u.y,d.y,h.y,this.tension),qa.initCatmullRom(c.z,u.z,d.z,h.z,this.tension));return n.set(Va.calc(l),Wa.calc(l),qa.calc(l)),n}copy(e){super.copy(e),this.points=[];for(let t=0,n=e.points.length;t<n;t++){const r=e.points[t];this.points.push(r.clone())}return this.closed=e.closed,this.curveType=e.curveType,this.tension=e.tension,this}toJSON(){const e=super.toJSON();e.points=[];for(let t=0,n=this.points.length;t<n;t++){const r=this.points[t];e.points.push(r.toArray())}return e.closed=this.closed,e.curveType=this.curveType,e.tension=this.tension,e}fromJSON(e){super.fromJSON(e),this.points=[];for(let t=0,n=e.points.length;t<n;t++){const r=e.points[t];this.points.push(new P().fromArray(r))}return this.closed=e.closed,this.curveType=e.curveType,this.tension=e.tension,this}}function Bc(i,e,t,n,r){const s=(n-e)*.5,a=(r-t)*.5,o=i*i,l=i*o;return(2*t-2*n+s+a)*l+(-3*t+3*n-2*s-a)*o+s*i+t}function ip(i,e){const t=1-i;return t*t*e}function rp(i,e){return 2*(1-i)*i*e}function sp(i,e){return i*i*e}function Pr(i,e,t,n){return ip(i,e)+rp(i,t)+sp(i,n)}function ap(i,e){const t=1-i;return t*t*t*e}function op(i,e){const t=1-i;return 3*t*t*i*e}function lp(i,e){return 3*(1-i)*i*i*e}function cp(i,e){return i*i*i*e}function Lr(i,e,t,n,r){return ap(i,e)+op(i,t)+lp(i,n)+cp(i,r)}class Cu extends In{constructor(e=new de,t=new de,n=new de,r=new de){super(),this.isCubicBezierCurve=!0,this.type="CubicBezierCurve",this.v0=e,this.v1=t,this.v2=n,this.v3=r}getPoint(e,t=new de){const n=t,r=this.v0,s=this.v1,a=this.v2,o=this.v3;return n.set(Lr(e,r.x,s.x,a.x,o.x),Lr(e,r.y,s.y,a.y,o.y)),n}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this.v3.copy(e.v3),this}toJSON(){const e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e.v3=this.v3.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this.v3.fromArray(e.v3),this}}class hp extends In{constructor(e=new P,t=new P,n=new P,r=new P){super(),this.isCubicBezierCurve3=!0,this.type="CubicBezierCurve3",this.v0=e,this.v1=t,this.v2=n,this.v3=r}getPoint(e,t=new P){const n=t,r=this.v0,s=this.v1,a=this.v2,o=this.v3;return n.set(Lr(e,r.x,s.x,a.x,o.x),Lr(e,r.y,s.y,a.y,o.y),Lr(e,r.z,s.z,a.z,o.z)),n}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this.v3.copy(e.v3),this}toJSON(){const e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e.v3=this.v3.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this.v3.fromArray(e.v3),this}}class Pu extends In{constructor(e=new de,t=new de){super(),this.isLineCurve=!0,this.type="LineCurve",this.v1=e,this.v2=t}getPoint(e,t=new de){const n=t;return e===1?n.copy(this.v2):(n.copy(this.v2).sub(this.v1),n.multiplyScalar(e).add(this.v1)),n}getPointAt(e,t){return this.getPoint(e,t)}getTangent(e,t=new de){return t.subVectors(this.v2,this.v1).normalize()}getTangentAt(e,t){return this.getTangent(e,t)}copy(e){return super.copy(e),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){const e=super.toJSON();return e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}}class up extends In{constructor(e=new P,t=new P){super(),this.isLineCurve3=!0,this.type="LineCurve3",this.v1=e,this.v2=t}getPoint(e,t=new P){const n=t;return e===1?n.copy(this.v2):(n.copy(this.v2).sub(this.v1),n.multiplyScalar(e).add(this.v1)),n}getPointAt(e,t){return this.getPoint(e,t)}getTangent(e,t=new P){return t.subVectors(this.v2,this.v1).normalize()}getTangentAt(e,t){return this.getTangent(e,t)}copy(e){return super.copy(e),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){const e=super.toJSON();return e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}}class Lu extends In{constructor(e=new de,t=new de,n=new de){super(),this.isQuadraticBezierCurve=!0,this.type="QuadraticBezierCurve",this.v0=e,this.v1=t,this.v2=n}getPoint(e,t=new de){const n=t,r=this.v0,s=this.v1,a=this.v2;return n.set(Pr(e,r.x,s.x,a.x),Pr(e,r.y,s.y,a.y)),n}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){const e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}}class dp extends In{constructor(e=new P,t=new P,n=new P){super(),this.isQuadraticBezierCurve3=!0,this.type="QuadraticBezierCurve3",this.v0=e,this.v1=t,this.v2=n}getPoint(e,t=new P){const n=t,r=this.v0,s=this.v1,a=this.v2;return n.set(Pr(e,r.x,s.x,a.x),Pr(e,r.y,s.y,a.y),Pr(e,r.z,s.z,a.z)),n}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){const e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}}class Du extends In{constructor(e=[]){super(),this.isSplineCurve=!0,this.type="SplineCurve",this.points=e}getPoint(e,t=new de){const n=t,r=this.points,s=(r.length-1)*e,a=Math.floor(s),o=s-a,l=r[a===0?a:a-1],c=r[a],h=r[a>r.length-2?r.length-1:a+1],u=r[a>r.length-3?r.length-1:a+2];return n.set(Bc(o,l.x,c.x,h.x,u.x),Bc(o,l.y,c.y,h.y,u.y)),n}copy(e){super.copy(e),this.points=[];for(let t=0,n=e.points.length;t<n;t++){const r=e.points[t];this.points.push(r.clone())}return this}toJSON(){const e=super.toJSON();e.points=[];for(let t=0,n=this.points.length;t<n;t++){const r=this.points[t];e.points.push(r.toArray())}return e}fromJSON(e){super.fromJSON(e),this.points=[];for(let t=0,n=e.points.length;t<n;t++){const r=e.points[t];this.points.push(new de().fromArray(r))}return this}}var kc=Object.freeze({__proto__:null,ArcCurve:tp,CatmullRomCurve3:np,CubicBezierCurve:Cu,CubicBezierCurve3:hp,EllipseCurve:Al,LineCurve:Pu,LineCurve3:up,QuadraticBezierCurve:Lu,QuadraticBezierCurve3:dp,SplineCurve:Du});class fp extends In{constructor(){super(),this.type="CurvePath",this.curves=[],this.autoClose=!1,this.cacheLengths=null}add(e){this.curves.push(e)}closePath(){const e=this.curves[0].getPoint(0),t=this.curves[this.curves.length-1].getPoint(1);if(!e.equals(t)){const n=e.isVector2===!0?"LineCurve":"LineCurve3";this.curves.push(new kc[n](t,e))}return this}getPoint(e,t){const n=e*this.getLength(),r=this.getCurveLengths();let s=0;for(;s<r.length;){if(r[s]>=n){const a=r[s]-n,o=this.curves[s],l=o.getLength(),c=l===0?0:1-a/l;return o.getPointAt(c,t)}s++}return null}getLength(){const e=this.getCurveLengths();return e[e.length-1]}updateArcLengths(){this.needsUpdate=!0,this.cacheLengths=null,this.getCurveLengths()}getCurveLengths(){if(this.cacheLengths&&this.cacheLengths.length===this.curves.length)return this.cacheLengths;const e=[];let t=0;for(let n=0,r=this.curves.length;n<r;n++)t+=this.curves[n].getLength(),e.push(t);return this.cacheLengths=e,e}getSpacedPoints(e=40){const t=[];for(let n=0;n<=e;n++)t.push(this.getPoint(n/e));return this.autoClose&&t.push(t[0]),t}getPoints(e=12){const t=[];let n;for(let r=0,s=this.curves;r<s.length;r++){const a=s[r],o=a.isEllipseCurve?e*2:a.isLineCurve||a.isLineCurve3?1:a.isSplineCurve?e*a.points.length:e,l=a.getPoints(o);for(let c=0;c<l.length;c++){const h=l[c];n&&n.equals(h)||(t.push(h),n=h)}}return this.autoClose&&t.length>1&&!t[t.length-1].equals(t[0])&&t.push(t[0]),t}copy(e){super.copy(e),this.curves=[];for(let t=0,n=e.curves.length;t<n;t++){const r=e.curves[t];this.curves.push(r.clone())}return this.autoClose=e.autoClose,this.cacheLengths=null,this}toJSON(){const e=super.toJSON();e.autoClose=this.autoClose,e.curves=[];for(let t=0,n=this.curves.length;t<n;t++){const r=this.curves[t];e.curves.push(r.toJSON())}return e}fromJSON(e){super.fromJSON(e),this.autoClose=e.autoClose,this.curves=[];for(let t=0,n=e.curves.length;t<n;t++){const r=e.curves[t];this.curves.push(new kc[r.type]().fromJSON(r))}return this.cacheLengths=null,this}}class Ho extends fp{constructor(e){super(),this.type="Path",this.currentPoint=new de,e&&this.setFromPoints(e)}setFromPoints(e){this.moveTo(e[0].x,e[0].y);for(let t=1,n=e.length;t<n;t++)this.lineTo(e[t].x,e[t].y);return this}moveTo(e,t){return this.currentPoint.set(e,t),this}lineTo(e,t){const n=new Pu(this.currentPoint.clone(),new de(e,t));return this.curves.push(n),this.currentPoint.set(e,t),this}quadraticCurveTo(e,t,n,r){const s=new Lu(this.currentPoint.clone(),new de(e,t),new de(n,r));return this.curves.push(s),this.currentPoint.set(n,r),this}bezierCurveTo(e,t,n,r,s,a){const o=new Cu(this.currentPoint.clone(),new de(e,t),new de(n,r),new de(s,a));return this.curves.push(o),this.currentPoint.set(s,a),this}splineThru(e){const t=[this.currentPoint.clone()].concat(e),n=new Du(t);return this.curves.push(n),this.currentPoint.copy(e[e.length-1]),this}arc(e,t,n,r,s,a){const o=this.currentPoint.x,l=this.currentPoint.y;return this.absarc(e+o,t+l,n,r,s,a),this}absarc(e,t,n,r,s,a){return this.absellipse(e,t,n,n,r,s,a),this}ellipse(e,t,n,r,s,a,o,l){const c=this.currentPoint.x,h=this.currentPoint.y;return this.absellipse(e+c,t+h,n,r,s,a,o,l),this}absellipse(e,t,n,r,s,a,o,l){const c=new Al(e,t,n,r,s,a,o,l);if(this.curves.length>0){const u=c.getPoint(0);u.equals(this.currentPoint)||this.lineTo(u.x,u.y)}this.curves.push(c);const h=c.getPoint(1);return this.currentPoint.copy(h),this}copy(e){return super.copy(e),this.currentPoint.copy(e.currentPoint),this}toJSON(){const e=super.toJSON();return e.currentPoint=this.currentPoint.toArray(),e}fromJSON(e){return super.fromJSON(e),this.currentPoint.fromArray(e.currentPoint),this}}class Iu extends Ho{constructor(e){super(e),this.uuid=$n(),this.type="Shape",this.holes=[]}getPointsHoles(e){const t=[];for(let n=0,r=this.holes.length;n<r;n++)t[n]=this.holes[n].getPoints(e);return t}extractPoints(e){return{shape:this.getPoints(e),holes:this.getPointsHoles(e)}}copy(e){super.copy(e),this.holes=[];for(let t=0,n=e.holes.length;t<n;t++){const r=e.holes[t];this.holes.push(r.clone())}return this}toJSON(){const e=super.toJSON();e.uuid=this.uuid,e.holes=[];for(let t=0,n=this.holes.length;t<n;t++){const r=this.holes[t];e.holes.push(r.toJSON())}return e}fromJSON(e){super.fromJSON(e),this.uuid=e.uuid,this.holes=[];for(let t=0,n=e.holes.length;t<n;t++){const r=e.holes[t];this.holes.push(new Ho().fromJSON(r))}return this}}function pp(i,e,t=2){const n=e&&e.length,r=n?e[0]*t:i.length;let s=Nu(i,0,r,t,!0);const a=[];if(!s||s.next===s.prev)return a;let o,l,c;if(n&&(s=_p(i,e,s,t)),i.length>80*t){o=i[0],l=i[1];let h=o,u=l;for(let d=t;d<r;d+=t){const p=i[d],g=i[d+1];p<o&&(o=p),g<l&&(l=g),p>h&&(h=p),g>u&&(u=g)}c=Math.max(h-o,u-l),c=c!==0?32767/c:0}return Hr(s,a,t,o,l,c,0),a}function Nu(i,e,t,n,r){let s;if(r===Pp(i,e,t,n)>0)for(let a=e;a<t;a+=n)s=zc(a/n|0,i[a],i[a+1],s);else for(let a=t-n;a>=e;a-=n)s=zc(a/n|0,i[a],i[a+1],s);return s&&rr(s,s.next)&&(Wr(s),s=s.next),s}function Ri(i,e){if(!i)return i;e||(e=i);let t=i,n;do if(n=!1,!t.steiner&&(rr(t,t.next)||ft(t.prev,t,t.next)===0)){if(Wr(t),t=e=t.prev,t===t.next)break;n=!0}else t=t.next;while(n||t!==e);return e}function Hr(i,e,t,n,r,s,a){if(!i)return;!a&&s&&wp(i,n,r,s);let o=i;for(;i.prev!==i.next;){const l=i.prev,c=i.next;if(s?gp(i,n,r,s):mp(i)){e.push(l.i,i.i,c.i),Wr(i),i=c.next,o=c.next;continue}if(i=c,i===o){a?a===1?(i=vp(Ri(i),e),Hr(i,e,t,n,r,s,2)):a===2&&xp(i,e,t,n,r,s):Hr(Ri(i),e,t,n,r,s,1);break}}}function mp(i){const e=i.prev,t=i,n=i.next;if(ft(e,t,n)>=0)return!1;const r=e.x,s=t.x,a=n.x,o=e.y,l=t.y,c=n.y,h=Math.min(r,s,a),u=Math.min(o,l,c),d=Math.max(r,s,a),p=Math.max(o,l,c);let g=n.next;for(;g!==e;){if(g.x>=h&&g.x<=d&&g.y>=u&&g.y<=p&&Sr(r,o,s,l,a,c,g.x,g.y)&&ft(g.prev,g,g.next)>=0)return!1;g=g.next}return!0}function gp(i,e,t,n){const r=i.prev,s=i,a=i.next;if(ft(r,s,a)>=0)return!1;const o=r.x,l=s.x,c=a.x,h=r.y,u=s.y,d=a.y,p=Math.min(o,l,c),g=Math.min(h,u,d),v=Math.max(o,l,c),m=Math.max(h,u,d),f=Vo(p,g,e,t,n),_=Vo(v,m,e,t,n);let S=i.prevZ,y=i.nextZ;for(;S&&S.z>=f&&y&&y.z<=_;){if(S.x>=p&&S.x<=v&&S.y>=g&&S.y<=m&&S!==r&&S!==a&&Sr(o,h,l,u,c,d,S.x,S.y)&&ft(S.prev,S,S.next)>=0||(S=S.prevZ,y.x>=p&&y.x<=v&&y.y>=g&&y.y<=m&&y!==r&&y!==a&&Sr(o,h,l,u,c,d,y.x,y.y)&&ft(y.prev,y,y.next)>=0))return!1;y=y.nextZ}for(;S&&S.z>=f;){if(S.x>=p&&S.x<=v&&S.y>=g&&S.y<=m&&S!==r&&S!==a&&Sr(o,h,l,u,c,d,S.x,S.y)&&ft(S.prev,S,S.next)>=0)return!1;S=S.prevZ}for(;y&&y.z<=_;){if(y.x>=p&&y.x<=v&&y.y>=g&&y.y<=m&&y!==r&&y!==a&&Sr(o,h,l,u,c,d,y.x,y.y)&&ft(y.prev,y,y.next)>=0)return!1;y=y.nextZ}return!0}function vp(i,e){let t=i;do{const n=t.prev,r=t.next.next;!rr(n,r)&&Fu(n,t,t.next,r)&&Vr(n,r)&&Vr(r,n)&&(e.push(n.i,t.i,r.i),Wr(t),Wr(t.next),t=i=r),t=t.next}while(t!==i);return Ri(t)}function xp(i,e,t,n,r,s){let a=i;do{let o=a.next.next;for(;o!==a.prev;){if(a.i!==o.i&&Ap(a,o)){let l=Ou(a,o);a=Ri(a,a.next),l=Ri(l,l.next),Hr(a,e,t,n,r,s,0),Hr(l,e,t,n,r,s,0);return}o=o.next}a=a.next}while(a!==i)}function _p(i,e,t,n){const r=[];for(let s=0,a=e.length;s<a;s++){const o=e[s]*n,l=s<a-1?e[s+1]*n:i.length,c=Nu(i,o,l,n,!1);c===c.next&&(c.steiner=!0),r.push(Tp(c))}r.sort(yp);for(let s=0;s<r.length;s++)t=Mp(r[s],t);return t}function yp(i,e){let t=i.x-e.x;if(t===0&&(t=i.y-e.y,t===0)){const n=(i.next.y-i.y)/(i.next.x-i.x),r=(e.next.y-e.y)/(e.next.x-e.x);t=n-r}return t}function Mp(i,e){const t=bp(i,e);if(!t)return e;const n=Ou(t,i);return Ri(n,n.next),Ri(t,t.next)}function bp(i,e){let t=e;const n=i.x,r=i.y;let s=-1/0,a;if(rr(i,t))return t;do{if(rr(i,t.next))return t.next;if(r<=t.y&&r>=t.next.y&&t.next.y!==t.y){const u=t.x+(r-t.y)*(t.next.x-t.x)/(t.next.y-t.y);if(u<=n&&u>s&&(s=u,a=t.x<t.next.x?t:t.next,u===n))return a}t=t.next}while(t!==e);if(!a)return null;const o=a,l=a.x,c=a.y;let h=1/0;t=a;do{if(n>=t.x&&t.x>=l&&n!==t.x&&Uu(r<c?n:s,r,l,c,r<c?s:n,r,t.x,t.y)){const u=Math.abs(r-t.y)/(n-t.x);Vr(t,i)&&(u<h||u===h&&(t.x>a.x||t.x===a.x&&Sp(a,t)))&&(a=t,h=u)}t=t.next}while(t!==o);return a}function Sp(i,e){return ft(i.prev,i,e.prev)<0&&ft(e.next,i,i.next)<0}function wp(i,e,t,n){let r=i;do r.z===0&&(r.z=Vo(r.x,r.y,e,t,n)),r.prevZ=r.prev,r.nextZ=r.next,r=r.next;while(r!==i);r.prevZ.nextZ=null,r.prevZ=null,Ep(r)}function Ep(i){let e,t=1;do{let n=i,r;i=null;let s=null;for(e=0;n;){e++;let a=n,o=0;for(let c=0;c<t&&(o++,a=a.nextZ,!!a);c++);let l=t;for(;o>0||l>0&&a;)o!==0&&(l===0||!a||n.z<=a.z)?(r=n,n=n.nextZ,o--):(r=a,a=a.nextZ,l--),s?s.nextZ=r:i=r,r.prevZ=s,s=r;n=a}s.nextZ=null,t*=2}while(e>1);return i}function Vo(i,e,t,n,r){return i=(i-t)*r|0,e=(e-n)*r|0,i=(i|i<<8)&16711935,i=(i|i<<4)&252645135,i=(i|i<<2)&858993459,i=(i|i<<1)&1431655765,e=(e|e<<8)&16711935,e=(e|e<<4)&252645135,e=(e|e<<2)&858993459,e=(e|e<<1)&1431655765,i|e<<1}function Tp(i){let e=i,t=i;do(e.x<t.x||e.x===t.x&&e.y<t.y)&&(t=e),e=e.next;while(e!==i);return t}function Uu(i,e,t,n,r,s,a,o){return(r-a)*(e-o)>=(i-a)*(s-o)&&(i-a)*(n-o)>=(t-a)*(e-o)&&(t-a)*(s-o)>=(r-a)*(n-o)}function Sr(i,e,t,n,r,s,a,o){return!(i===a&&e===o)&&Uu(i,e,t,n,r,s,a,o)}function Ap(i,e){return i.next.i!==e.i&&i.prev.i!==e.i&&!Rp(i,e)&&(Vr(i,e)&&Vr(e,i)&&Cp(i,e)&&(ft(i.prev,i,e.prev)||ft(i,e.prev,e))||rr(i,e)&&ft(i.prev,i,i.next)>0&&ft(e.prev,e,e.next)>0)}function ft(i,e,t){return(e.y-i.y)*(t.x-e.x)-(e.x-i.x)*(t.y-e.y)}function rr(i,e){return i.x===e.x&&i.y===e.y}function Fu(i,e,t,n){const r=As(ft(i,e,t)),s=As(ft(i,e,n)),a=As(ft(t,n,i)),o=As(ft(t,n,e));return!!(r!==s&&a!==o||r===0&&Ts(i,t,e)||s===0&&Ts(i,n,e)||a===0&&Ts(t,i,n)||o===0&&Ts(t,e,n))}function Ts(i,e,t){return e.x<=Math.max(i.x,t.x)&&e.x>=Math.min(i.x,t.x)&&e.y<=Math.max(i.y,t.y)&&e.y>=Math.min(i.y,t.y)}function As(i){return i>0?1:i<0?-1:0}function Rp(i,e){let t=i;do{if(t.i!==i.i&&t.next.i!==i.i&&t.i!==e.i&&t.next.i!==e.i&&Fu(t,t.next,i,e))return!0;t=t.next}while(t!==i);return!1}function Vr(i,e){return ft(i.prev,i,i.next)<0?ft(i,e,i.next)>=0&&ft(i,i.prev,e)>=0:ft(i,e,i.prev)<0||ft(i,i.next,e)<0}function Cp(i,e){let t=i,n=!1;const r=(i.x+e.x)/2,s=(i.y+e.y)/2;do t.y>s!=t.next.y>s&&t.next.y!==t.y&&r<(t.next.x-t.x)*(s-t.y)/(t.next.y-t.y)+t.x&&(n=!n),t=t.next;while(t!==i);return n}function Ou(i,e){const t=Wo(i.i,i.x,i.y),n=Wo(e.i,e.x,e.y),r=i.next,s=e.prev;return i.next=e,e.prev=i,t.next=r,r.prev=t,n.next=t,t.prev=n,s.next=n,n.prev=s,n}function zc(i,e,t,n){const r=Wo(i,e,t);return n?(r.next=n.next,r.prev=n,n.next.prev=r,n.next=r):(r.prev=r,r.next=r),r}function Wr(i){i.next.prev=i.prev,i.prev.next=i.next,i.prevZ&&(i.prevZ.nextZ=i.nextZ),i.nextZ&&(i.nextZ.prevZ=i.prevZ)}function Wo(i,e,t){return{i,x:e,y:t,prev:null,next:null,z:0,prevZ:null,nextZ:null,steiner:!1}}function Pp(i,e,t,n){let r=0;for(let s=e,a=t-n;s<t;s+=n)r+=(i[a]-i[s])*(i[s+1]+i[a+1]),a=s;return r}class Lp{static triangulate(e,t,n=2){return pp(e,t,n)}}class Dr{static area(e){const t=e.length;let n=0;for(let r=t-1,s=0;s<t;r=s++)n+=e[r].x*e[s].y-e[s].x*e[r].y;return n*.5}static isClockWise(e){return Dr.area(e)<0}static triangulateShape(e,t){const n=[],r=[],s=[];Gc(e),Hc(n,e);let a=e.length;t.forEach(Gc);for(let l=0;l<t.length;l++)r.push(a),a+=t[l].length,Hc(n,t[l]);const o=Lp.triangulate(n,r);for(let l=0;l<o.length;l+=3)s.push(o.slice(l,l+3));return s}}function Gc(i){const e=i.length;e>2&&i[e-1].equals(i[0])&&i.pop()}function Hc(i,e){for(let t=0;t<e.length;t++)i.push(e[t].x),i.push(e[t].y)}class ca extends Tl{constructor(e=1,t=0){const n=(1+Math.sqrt(5))/2,r=[-1,n,0,1,n,0,-1,-n,0,1,-n,0,0,-1,n,0,1,n,0,-1,-n,0,1,-n,n,0,-1,n,0,1,-n,0,-1,-n,0,1],s=[0,11,5,0,5,1,0,1,7,0,7,10,0,10,11,1,5,9,5,11,4,11,10,2,10,7,6,7,1,8,3,9,4,3,4,2,3,2,6,3,6,8,3,8,9,4,9,5,2,4,11,6,2,10,8,6,7,9,8,1];super(r,s,e,t),this.type="IcosahedronGeometry",this.parameters={radius:e,detail:t}}static fromJSON(e){return new ca(e.radius,e.detail)}}class Cl extends gt{constructor(e=[new de(0,-.5),new de(.5,0),new de(0,.5)],t=12,n=0,r=Math.PI*2){super(),this.type="LatheGeometry",this.parameters={points:e,segments:t,phiStart:n,phiLength:r},t=Math.floor(t),r=ze(r,0,Math.PI*2);const s=[],a=[],o=[],l=[],c=[],h=1/t,u=new P,d=new de,p=new P,g=new P,v=new P;let m=0,f=0;for(let _=0;_<=e.length-1;_++)switch(_){case 0:m=e[_+1].x-e[_].x,f=e[_+1].y-e[_].y,p.x=f*1,p.y=-m,p.z=f*0,v.copy(p),p.normalize(),l.push(p.x,p.y,p.z);break;case e.length-1:v.normalize(),l.push(v.x,v.y,v.z);break;default:m=e[_+1].x-e[_].x,f=e[_+1].y-e[_].y,p.x=f*1,p.y=-m,p.z=f*0,g.copy(p),p.x+=v.x,p.y+=v.y,p.z+=v.z,p.normalize(),l.push(p.x,p.y,p.z),v.copy(g)}for(let _=0;_<=t;_++){const S=n+_*h*r,y=Math.sin(S),A=Math.cos(S);for(let E=0;E<=e.length-1;E++){u.x=e[E].x*y,u.y=e[E].y,u.z=e[E].x*A,a.push(u.x,u.y,u.z),d.x=_/t,d.y=E/(e.length-1),o.push(d.x,d.y);const x=l[3*E+0]*y,w=l[3*E+1],I=l[3*E+0]*A;c.push(x,w,I)}}for(let _=0;_<t;_++)for(let S=0;S<e.length-1;S++){const y=S+_*e.length,A=y,E=y+e.length,x=y+e.length+1,w=y+1;s.push(A,E,w),s.push(x,w,E)}this.setIndex(s),this.setAttribute("position",new We(a,3)),this.setAttribute("uv",new We(o,2)),this.setAttribute("normal",new We(c,3))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Cl(e.points,e.segments,e.phiStart,e.phiLength)}}class li extends gt{constructor(e=1,t=1,n=1,r=1){super(),this.type="PlaneGeometry",this.parameters={width:e,height:t,widthSegments:n,heightSegments:r};const s=e/2,a=t/2,o=Math.floor(n),l=Math.floor(r),c=o+1,h=l+1,u=e/o,d=t/l,p=[],g=[],v=[],m=[];for(let f=0;f<h;f++){const _=f*d-a;for(let S=0;S<c;S++){const y=S*u-s;g.push(y,-_,0),v.push(0,0,1),m.push(S/o),m.push(1-f/l)}}for(let f=0;f<l;f++)for(let _=0;_<o;_++){const S=_+c*f,y=_+c*(f+1),A=_+1+c*(f+1),E=_+1+c*f;p.push(S,y,E),p.push(y,A,E)}this.setIndex(p),this.setAttribute("position",new We(g,3)),this.setAttribute("normal",new We(v,3)),this.setAttribute("uv",new We(m,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new li(e.width,e.height,e.widthSegments,e.heightSegments)}}class ha extends gt{constructor(e=.5,t=1,n=32,r=1,s=0,a=Math.PI*2){super(),this.type="RingGeometry",this.parameters={innerRadius:e,outerRadius:t,thetaSegments:n,phiSegments:r,thetaStart:s,thetaLength:a},n=Math.max(3,n),r=Math.max(1,r);const o=[],l=[],c=[],h=[];let u=e;const d=(t-e)/r,p=new P,g=new de;for(let v=0;v<=r;v++){for(let m=0;m<=n;m++){const f=s+m/n*a;p.x=u*Math.cos(f),p.y=u*Math.sin(f),l.push(p.x,p.y,p.z),c.push(0,0,1),g.x=(p.x/t+1)/2,g.y=(p.y/t+1)/2,h.push(g.x,g.y)}u+=d}for(let v=0;v<r;v++){const m=v*(n+1);for(let f=0;f<n;f++){const _=f+m,S=_,y=_+n+1,A=_+n+2,E=_+1;o.push(S,y,E),o.push(y,A,E)}}this.setIndex(o),this.setAttribute("position",new We(l,3)),this.setAttribute("normal",new We(c,3)),this.setAttribute("uv",new We(h,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new ha(e.innerRadius,e.outerRadius,e.thetaSegments,e.phiSegments,e.thetaStart,e.thetaLength)}}class Pl extends gt{constructor(e=new Iu([new de(0,.5),new de(-.5,-.5),new de(.5,-.5)]),t=12){super(),this.type="ShapeGeometry",this.parameters={shapes:e,curveSegments:t};const n=[],r=[],s=[],a=[];let o=0,l=0;if(Array.isArray(e)===!1)c(e);else for(let h=0;h<e.length;h++)c(e[h]),this.addGroup(o,l,h),o+=l,l=0;this.setIndex(n),this.setAttribute("position",new We(r,3)),this.setAttribute("normal",new We(s,3)),this.setAttribute("uv",new We(a,2));function c(h){const u=r.length/3,d=h.extractPoints(t);let p=d.shape;const g=d.holes;Dr.isClockWise(p)===!1&&(p=p.reverse());for(let m=0,f=g.length;m<f;m++){const _=g[m];Dr.isClockWise(_)===!0&&(g[m]=_.reverse())}const v=Dr.triangulateShape(p,g);for(let m=0,f=g.length;m<f;m++){const _=g[m];p=p.concat(_)}for(let m=0,f=p.length;m<f;m++){const _=p[m];r.push(_.x,_.y,0),s.push(0,0,1),a.push(_.x,_.y)}for(let m=0,f=v.length;m<f;m++){const _=v[m],S=_[0]+u,y=_[1]+u,A=_[2]+u;n.push(S,y,A),l+=3}}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}toJSON(){const e=super.toJSON(),t=this.parameters.shapes;return Dp(t,e)}static fromJSON(e,t){const n=[];for(let r=0,s=e.shapes.length;r<s;r++){const a=t[e.shapes[r]];n.push(a)}return new Pl(n,e.curveSegments)}}function Dp(i,e){if(e.shapes=[],Array.isArray(i))for(let t=0,n=i.length;t<n;t++){const r=i[t];e.shapes.push(r.uuid)}else e.shapes.push(i.uuid);return e}class ci extends gt{constructor(e=1,t=32,n=16,r=0,s=Math.PI*2,a=0,o=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:e,widthSegments:t,heightSegments:n,phiStart:r,phiLength:s,thetaStart:a,thetaLength:o},t=Math.max(3,Math.floor(t)),n=Math.max(2,Math.floor(n));const l=Math.min(a+o,Math.PI);let c=0;const h=[],u=new P,d=new P,p=[],g=[],v=[],m=[];for(let f=0;f<=n;f++){const _=[],S=f/n,y=a+S*o,A=e*Math.cos(y),E=Math.sqrt(e*e-A*A);let x=0;f===0&&a===0?x=.5/t:f===n&&l===Math.PI&&(x=-.5/t);for(let w=0;w<=t;w++){const I=w/t,C=r+I*s;u.x=-E*Math.cos(C),u.y=A,u.z=E*Math.sin(C),g.push(u.x,u.y,u.z),d.copy(u).normalize(),v.push(d.x,d.y,d.z),m.push(I+x,1-S),_.push(c++)}h.push(_)}for(let f=0;f<n;f++)for(let _=0;_<t;_++){const S=h[f][_+1],y=h[f][_],A=h[f+1][_],E=h[f+1][_+1];(f!==0||a>0)&&p.push(S,y,E),(f!==n-1||l<Math.PI)&&p.push(y,A,E)}this.setIndex(p),this.setAttribute("position",new We(g,3)),this.setAttribute("normal",new We(v,3)),this.setAttribute("uv",new We(m,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new ci(e.radius,e.widthSegments,e.heightSegments,e.phiStart,e.phiLength,e.thetaStart,e.thetaLength)}}class Ll extends gt{constructor(e=1,t=.4,n=12,r=48,s=Math.PI*2,a=0,o=Math.PI*2){super(),this.type="TorusGeometry",this.parameters={radius:e,tube:t,radialSegments:n,tubularSegments:r,arc:s,thetaStart:a,thetaLength:o},n=Math.floor(n),r=Math.floor(r);const l=[],c=[],h=[],u=[],d=new P,p=new P,g=new P;for(let v=0;v<=n;v++){const m=a+v/n*o;for(let f=0;f<=r;f++){const _=f/r*s;p.x=(e+t*Math.cos(m))*Math.cos(_),p.y=(e+t*Math.cos(m))*Math.sin(_),p.z=t*Math.sin(m),c.push(p.x,p.y,p.z),d.x=e*Math.cos(_),d.y=e*Math.sin(_),g.subVectors(p,d).normalize(),h.push(g.x,g.y,g.z),u.push(f/r),u.push(v/n)}}for(let v=1;v<=n;v++)for(let m=1;m<=r;m++){const f=(r+1)*v+m-1,_=(r+1)*(v-1)+m-1,S=(r+1)*(v-1)+m,y=(r+1)*v+m;l.push(f,_,y),l.push(_,S,y)}this.setIndex(l),this.setAttribute("position",new We(c,3)),this.setAttribute("normal",new We(h,3)),this.setAttribute("uv",new We(u,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Ll(e.radius,e.tube,e.radialSegments,e.tubularSegments,e.arc,e.thetaStart,e.thetaLength)}}function sr(i){const e={};for(const t in i){e[t]={};for(const n in i[t]){const r=i[t][n];if(Vc(r))r.isRenderTargetTexture?(Pe("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),e[t][n]=null):e[t][n]=r.clone();else if(Array.isArray(r))if(Vc(r[0])){const s=[];for(let a=0,o=r.length;a<o;a++)s[a]=r[a].clone();e[t][n]=s}else e[t][n]=r.slice();else e[t][n]=r}}return e}function Ht(i){const e={};for(let t=0;t<i.length;t++){const n=sr(i[t]);for(const r in n)e[r]=n[r]}return e}function Vc(i){return i&&(i.isColor||i.isMatrix3||i.isMatrix4||i.isVector2||i.isVector3||i.isVector4||i.isTexture||i.isQuaternion)}function Ip(i){const e=[];for(let t=0;t<i.length;t++)e.push(i[t].clone());return e}function Bu(i){const e=i.getRenderTarget();return e===null?i.outputColorSpace:e.isXRRenderTarget===!0?e.texture.colorSpace:qe.workingColorSpace}const Np={clone:sr,merge:Ht};var Up=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,Fp=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class Xn extends fi{constructor(e){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=Up,this.fragmentShader=Fp,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=sr(e.uniforms),this.uniformsGroups=Ip(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this.defaultAttributeValues=Object.assign({},e.defaultAttributeValues),this.index0AttributeName=e.index0AttributeName,this.uniformsNeedUpdate=e.uniformsNeedUpdate,this}toJSON(e){const t=super.toJSON(e);t.glslVersion=this.glslVersion,t.uniforms={};for(const r in this.uniforms){const a=this.uniforms[r].value;a&&a.isTexture?t.uniforms[r]={type:"t",value:a.toJSON(e).uuid}:a&&a.isColor?t.uniforms[r]={type:"c",value:a.getHex()}:a&&a.isVector2?t.uniforms[r]={type:"v2",value:a.toArray()}:a&&a.isVector3?t.uniforms[r]={type:"v3",value:a.toArray()}:a&&a.isVector4?t.uniforms[r]={type:"v4",value:a.toArray()}:a&&a.isMatrix3?t.uniforms[r]={type:"m3",value:a.toArray()}:a&&a.isMatrix4?t.uniforms[r]={type:"m4",value:a.toArray()}:t.uniforms[r]={value:a}}Object.keys(this.defines).length>0&&(t.defines=this.defines),t.vertexShader=this.vertexShader,t.fragmentShader=this.fragmentShader,t.lights=this.lights,t.clipping=this.clipping;const n={};for(const r in this.extensions)this.extensions[r]===!0&&(n[r]=!0);return Object.keys(n).length>0&&(t.extensions=n),t}fromJSON(e,t){if(super.fromJSON(e,t),e.uniforms!==void 0)for(const n in e.uniforms){const r=e.uniforms[n];switch(this.uniforms[n]={},r.type){case"t":this.uniforms[n].value=t[r.value]||null;break;case"c":this.uniforms[n].value=new Te().setHex(r.value);break;case"v2":this.uniforms[n].value=new de().fromArray(r.value);break;case"v3":this.uniforms[n].value=new P().fromArray(r.value);break;case"v4":this.uniforms[n].value=new dt().fromArray(r.value);break;case"m3":this.uniforms[n].value=new Ie().fromArray(r.value);break;case"m4":this.uniforms[n].value=new Ye().fromArray(r.value);break;default:this.uniforms[n].value=r.value}}if(e.defines!==void 0&&(this.defines=e.defines),e.vertexShader!==void 0&&(this.vertexShader=e.vertexShader),e.fragmentShader!==void 0&&(this.fragmentShader=e.fragmentShader),e.glslVersion!==void 0&&(this.glslVersion=e.glslVersion),e.extensions!==void 0)for(const n in e.extensions)this.extensions[n]=e.extensions[n];return e.lights!==void 0&&(this.lights=e.lights),e.clipping!==void 0&&(this.clipping=e.clipping),this}}class Op extends Xn{constructor(e){super(e),this.isRawShaderMaterial=!0,this.type="RawShaderMaterial"}}class qr extends fi{constructor(e){super(),this.isMeshStandardMaterial=!0,this.type="MeshStandardMaterial",this.defines={STANDARD:""},this.color=new Te(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new Te(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=zo,this.normalScale=new de(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Dn,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.defines={STANDARD:""},this.color.copy(e.color),this.roughness=e.roughness,this.metalness=e.metalness,this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.roughnessMap=e.roughnessMap,this.metalnessMap=e.metalnessMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.envMapIntensity=e.envMapIntensity,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}}class Bp extends fi{constructor(e){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=jd,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}}class kp extends fi{constructor(e){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}}class Dl extends yt{static registerNode(e){this.prototype._lightNode=e}constructor(e,t=1){super(),this.isLight=!0,this.type="Light",this.color=new Te(e),this.intensity=t}copy(e,t){return super.copy(e,t),this.color.copy(e.color),this.intensity=e.intensity,this}toJSON(e){const t=super.toJSON(e);return t.object.color=this.color.getHex(),t.object.intensity=this.intensity,t}}class ku extends Dl{constructor(e,t,n){super(e,n),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(yt.DEFAULT_UP),this.updateMatrix(),this.groundColor=new Te(t)}copy(e,t){return super.copy(e,t),this.groundColor.copy(e.groundColor),this}toJSON(e){const t=super.toJSON(e);return t.object.groundColor=this.groundColor.getHex(),t}}const Xa=new Ye,Wc=new P,qc=new P;class zp{constructor(e){this.camera=e,this.intensity=1,this.bias=0,this.biasNode=null,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new de(512,512),this.mapType=Qt,this.map=null,this.mapPass=null,this.matrix=new Ye,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new Gr,this._frameExtents=new de(1,1),this._viewportCount=1,this._viewports=[new dt(0,0,1,1)]}getViewportCount(){return this._viewportCount}getCamera(){return this.camera}getFrustum(){return this._frustum}updateMatrices(e){const t=this.camera;Wc.setFromMatrixPosition(e.matrixWorld),t.position.copy(Wc),qc.setFromMatrixPosition(e.target.matrixWorld),t.lookAt(qc),t.updateMatrixWorld(),this._updateMatrix(t,this.matrix,this._frustum)}_updateMatrix(e,t,n,r){Xa.multiplyMatrices(e.projectionMatrix,e.matrixWorldInverse),n.setFromProjectionMatrix(Xa,e.coordinateSystem,e.reversedDepth);const s=this._frameExtents,a=r?r.z/s.x:1,o=r?r.w/s.y:1,l=r?r.x/s.x:0,c=r?r.y/s.y:0;e.coordinateSystem===kr||e.reversedDepth?t.set(.5*a,0,0,.5*a+l,0,.5*o,0,.5*o+c,0,0,1,0,0,0,0,1):t.set(.5*a,0,0,.5*a+l,0,.5*o,0,.5*o+c,0,0,.5,.5,0,0,0,1),t.multiply(Xa)}getViewport(e){return this._viewports[e]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(e){return this.camera=e.camera.clone(),this.intensity=e.intensity,this.bias=e.bias,this.radius=e.radius,this.autoUpdate=e.autoUpdate,this.needsUpdate=e.needsUpdate,this.normalBias=e.normalBias,this.blurSamples=e.blurSamples,this.mapSize.copy(e.mapSize),this.mapType=e.mapType,this.biasNode=e.biasNode,this}clone(){return new this.constructor().copy(this)}toJSON(){const e={};return e.intensity=this.intensity,e.bias=this.bias,e.normalBias=this.normalBias,e.radius=this.radius,e.blurSamples=this.blurSamples,e.mapSize=this.mapSize.toArray(),e.mapType=this.mapType,e.camera=this.camera.toJSON(!1).object,delete e.camera.matrix,e}}const Rs=new P,Cs=new ui,Tn=new P;class zu extends yt{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new Ye,this.projectionMatrix=new Ye,this.projectionMatrixInverse=new Ye,this.coordinateSystem=yn,this._reversedDepth=!1}get reversedDepth(){return this._reversedDepth}copy(e,t){return super.copy(e,t),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorld.decompose(Rs,Cs,Tn),Tn.x===1&&Tn.y===1&&Tn.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(Rs,Cs,Tn.set(1,1,1)).invert()}updateWorldMatrix(e,t,n=!1){super.updateWorldMatrix(e,t,n),this.matrixWorld.decompose(Rs,Cs,Tn),Tn.x===1&&Tn.y===1&&Tn.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(Rs,Cs,Tn.set(1,1,1)).invert()}clone(){return new this.constructor().copy(this)}}const ei=new P,Xc=new de,$c=new de;class cn extends zu{constructor(e=50,t=1,n=.1,r=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=n,this.far=r,this.focus=10,this.aspect=t,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){const t=.5*this.getFilmHeight()/e;this.fov=zr*2*Math.atan(t),this.updateProjectionMatrix()}getFocalLength(){const e=Math.tan(Rr*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return zr*2*Math.atan(Math.tan(Rr*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(e,t,n){ei.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),t.set(ei.x,ei.y).multiplyScalar(-e/ei.z),ei.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),n.set(ei.x,ei.y).multiplyScalar(-e/ei.z)}getViewSize(e,t){return this.getViewBounds(e,Xc,$c),t.subVectors($c,Xc)}setViewOffset(e,t,n,r,s,a){this.aspect=e/t,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=r,this.view.width=s,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=this.near;let t=e*Math.tan(Rr*.5*this.fov)/this.zoom,n=2*t,r=this.aspect*n,s=-.5*r;const a=this.view;if(this.view!==null&&this.view.enabled){const l=a.fullWidth,c=a.fullHeight;s+=a.offsetX*r/l,t-=a.offsetY*n/c,r*=a.width/l,n*=a.height/c}const o=this.filmOffset;o!==0&&(s+=e*o/this.getFilmWidth()),this.projectionMatrix.makePerspective(s,s+r,t,t-n,e,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.fov=this.fov,t.object.zoom=this.zoom,t.object.near=this.near,t.object.far=this.far,t.object.focus=this.focus,t.object.aspect=this.aspect,this.view!==null&&(t.object.view=Object.assign({},this.view)),t.object.filmGauge=this.filmGauge,t.object.filmOffset=this.filmOffset,t}}class Gu extends zu{constructor(e=-1,t=1,n=1,r=-1,s=.1,a=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=t,this.top=n,this.bottom=r,this.near=s,this.far=a,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,t,n,r,s,a){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=r,this.view.width=s,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=(this.right-this.left)/(2*this.zoom),t=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,r=(this.top+this.bottom)/2;let s=n-e,a=n+e,o=r+t,l=r-t;if(this.view!==null&&this.view.enabled){const c=(this.right-this.left)/this.view.fullWidth/this.zoom,h=(this.top-this.bottom)/this.view.fullHeight/this.zoom;s+=c*this.view.offsetX,a=s+c*this.view.width,o-=h*this.view.offsetY,l=o-h*this.view.height}this.projectionMatrix.makeOrthographic(s,a,o,l,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.zoom=this.zoom,t.object.left=this.left,t.object.right=this.right,t.object.top=this.top,t.object.bottom=this.bottom,t.object.near=this.near,t.object.far=this.far,this.view!==null&&(t.object.view=Object.assign({},this.view)),t}}class Gp extends zp{constructor(){super(new Gu(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}}class qo extends Dl{constructor(e,t){super(e,t),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(yt.DEFAULT_UP),this.updateMatrix(),this.target=new yt,this.shadow=new Gp}dispose(){super.dispose(),this.shadow.dispose()}copy(e){return super.copy(e),this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}toJSON(e){const t=super.toJSON(e);return t.object.shadow=this.shadow.toJSON(),t.object.target=this.target.uuid,t}}class Hp extends Dl{constructor(e,t){super(e,t),this.isAmbientLight=!0,this.type="AmbientLight"}}const Yi=-90,Ki=1;class Xo extends yt{constructor(e,t,n){super(),this.type="CubeCamera",this.renderTarget=n,this.coordinateSystem=null,this.activeMipmapLevel=0;const r=new cn(Yi,Ki,e,t);r.layers=this.layers,this.add(r);const s=new cn(Yi,Ki,e,t);s.layers=this.layers,this.add(s);const a=new cn(Yi,Ki,e,t);a.layers=this.layers,this.add(a);const o=new cn(Yi,Ki,e,t);o.layers=this.layers,this.add(o);const l=new cn(Yi,Ki,e,t);l.layers=this.layers,this.add(l);const c=new cn(Yi,Ki,e,t);c.layers=this.layers,this.add(c)}updateCoordinateSystem(){const e=this.coordinateSystem,t=this.children.concat(),[n,r,s,a,o,l]=t;for(const c of t)this.remove(c);if(e===yn)n.up.set(0,1,0),n.lookAt(1,0,0),r.up.set(0,1,0),r.lookAt(-1,0,0),s.up.set(0,0,-1),s.lookAt(0,1,0),a.up.set(0,0,1),a.lookAt(0,-1,0),o.up.set(0,1,0),o.lookAt(0,0,1),l.up.set(0,1,0),l.lookAt(0,0,-1);else if(e===kr)n.up.set(0,-1,0),n.lookAt(-1,0,0),r.up.set(0,-1,0),r.lookAt(1,0,0),s.up.set(0,0,1),s.lookAt(0,1,0),a.up.set(0,0,-1),a.lookAt(0,-1,0),o.up.set(0,-1,0),o.lookAt(0,0,1),l.up.set(0,-1,0),l.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+e);for(const c of t)this.add(c),c.updateMatrixWorld()}update(e,t){this.parent===null&&this.updateMatrixWorld();const{renderTarget:n,activeMipmapLevel:r}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());const[s,a,o,l,c,h]=this.children,u=e.getRenderTarget(),d=e.getActiveCubeFace(),p=e.getActiveMipmapLevel(),g=e.xr.enabled;e.xr.enabled=!1;const v=n.texture.mipmapsAutoUpdate;n.texture.mipmapsAutoUpdate=!1;let m=!1;e.isWebGLRenderer===!0?m=e.state.buffers.depth.getReversed():m=e.reversedDepthBuffer,e.setRenderTarget(n,0,r),m&&e.autoClear===!1&&e.clearDepth(),e.render(t,s),e.setRenderTarget(n,1,r),m&&e.autoClear===!1&&e.clearDepth(),e.render(t,a),e.setRenderTarget(n,2,r),m&&e.autoClear===!1&&e.clearDepth(),e.render(t,o),e.setRenderTarget(n,3,r),m&&e.autoClear===!1&&e.clearDepth(),e.render(t,l),e.setRenderTarget(n,4,r),m&&e.autoClear===!1&&e.clearDepth(),e.render(t,c),n.texture.mipmapsAutoUpdate=v,e.setRenderTarget(n,5,r),m&&e.autoClear===!1&&e.clearDepth(),e.render(t,h),e.setRenderTarget(u,d,p),e.xr.enabled=g,n.texture.needsPMREMUpdate=!0}}class Vp extends cn{constructor(e=[]){super(),this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=e,this.perCameraFrustumCulled=!1}}const Yc=new Ye;class Wp{constructor(e,t,n=0,r=1/0){this.ray=new la(e,t),this.near=n,this.far=r,this.camera=null,this.layers=new bl,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(e,t){this.ray.set(e,t)}setFromCamera(e,t){t.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(t.matrixWorld),this.ray.direction.set(e.x,e.y,.5).unproject(t).sub(this.ray.origin).normalize(),this.camera=t):t.isOrthographicCamera?(this.ray.origin.set(e.x,e.y,t.projectionMatrix.elements[14]).unproject(t),this.ray.direction.set(0,0,-1).transformDirection(t.matrixWorld),this.camera=t):$e("Raycaster: Unsupported camera type: "+t.type)}setFromXRController(e){return Yc.identity().extractRotation(e.matrixWorld),this.ray.origin.setFromMatrixPosition(e.matrixWorld),this.ray.direction.set(0,0,-1).applyMatrix4(Yc),this}intersectObject(e,t=!0,n=[]){return $o(e,this,n,t),n.sort(Kc),n}intersectObjects(e,t=!0,n=[]){for(let r=0,s=e.length;r<s;r++)$o(e[r],this,n,t);return n.sort(Kc),n}}function Kc(i,e){return i.distance-e.distance}function $o(i,e,t,n){let r=!0;if(i.layers.test(e.layers)&&i.raycast(e,t)===!1&&(r=!1),r===!0&&n===!0){const s=i.children;for(let a=0,o=s.length;a<o;a++)$o(s[a],e,t,!0)}}function Zc(i,e,t,n){const r=qp(n);switch(t){case ou:return i*e;case pl:return i*e/r.components*r.byteLength;case ml:return i*e/r.components*r.byteLength;case Ti:return i*e*2/r.components*r.byteLength;case gl:return i*e*2/r.components*r.byteLength;case lu:return i*e*3/r.components*r.byteLength;case Cn:return i*e*4/r.components*r.byteLength;case vl:return i*e*4/r.components*r.byteLength;case Bs:case ks:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*8;case zs:case Gs:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case ho:case fo:return Math.max(i,16)*Math.max(e,8)/4;case co:case uo:return Math.max(i,8)*Math.max(e,8)/2;case po:case mo:case vo:case xo:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*8;case go:case Ks:case _o:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case yo:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case Mo:return Math.floor((i+4)/5)*Math.floor((e+3)/4)*16;case bo:return Math.floor((i+4)/5)*Math.floor((e+4)/5)*16;case So:return Math.floor((i+5)/6)*Math.floor((e+4)/5)*16;case wo:return Math.floor((i+5)/6)*Math.floor((e+5)/6)*16;case Eo:return Math.floor((i+7)/8)*Math.floor((e+4)/5)*16;case To:return Math.floor((i+7)/8)*Math.floor((e+5)/6)*16;case Ao:return Math.floor((i+7)/8)*Math.floor((e+7)/8)*16;case Ro:return Math.floor((i+9)/10)*Math.floor((e+4)/5)*16;case Co:return Math.floor((i+9)/10)*Math.floor((e+5)/6)*16;case Po:return Math.floor((i+9)/10)*Math.floor((e+7)/8)*16;case Lo:return Math.floor((i+9)/10)*Math.floor((e+9)/10)*16;case Do:return Math.floor((i+11)/12)*Math.floor((e+9)/10)*16;case Io:return Math.floor((i+11)/12)*Math.floor((e+11)/12)*16;case No:case Uo:case Fo:return Math.ceil(i/4)*Math.ceil(e/4)*16;case Oo:case Bo:return Math.ceil(i/4)*Math.ceil(e/4)*8;case Zs:case ko:return Math.ceil(i/4)*Math.ceil(e/4)*16}throw new Error(`Unable to determine texture byte length for ${t} format.`)}function qp(i){switch(i){case Qt:case iu:return{byteLength:1,components:1};case Br:case ru:case Ln:return{byteLength:2,components:1};case dl:case fl:return{byteLength:2,components:4};case Pn:case ul:case _n:return{byteLength:4,components:1};case su:case au:return{byteLength:4,components:3}}throw new Error(`THREE.TextureUtils: Unknown texture type ${i}.`)}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:cl}}));typeof window<"u"&&(window.__THREE__?Pe("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=cl);function Hu(){let i=null,e=!1,t=null,n=null;function r(s,a){n=i.requestAnimationFrame(r),t(s,a)}return{start:function(){e!==!0&&t!==null&&i!==null&&(n=i.requestAnimationFrame(r),e=!0)},stop:function(){i!==null&&i.cancelAnimationFrame(n),e=!1},setAnimationLoop:function(s){t=s},setContext:function(s){i=s}}}function Xp(i){const e=new WeakMap;function t(o,l){const c=o.array,h=o.usage,u=c.byteLength,d=i.createBuffer();i.bindBuffer(l,d),i.bufferData(l,c,h),o.onUploadCallback();let p;if(c instanceof Float32Array)p=i.FLOAT;else if(typeof Float16Array<"u"&&c instanceof Float16Array)p=i.HALF_FLOAT;else if(c instanceof Uint16Array)o.isFloat16BufferAttribute?p=i.HALF_FLOAT:p=i.UNSIGNED_SHORT;else if(c instanceof Int16Array)p=i.SHORT;else if(c instanceof Uint32Array)p=i.UNSIGNED_INT;else if(c instanceof Int32Array)p=i.INT;else if(c instanceof Int8Array)p=i.BYTE;else if(c instanceof Uint8Array)p=i.UNSIGNED_BYTE;else if(c instanceof Uint8ClampedArray)p=i.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+c);return{buffer:d,type:p,bytesPerElement:c.BYTES_PER_ELEMENT,version:o.version,size:u}}function n(o,l,c){const h=l.array,u=l.updateRanges;if(i.bindBuffer(c,o),u.length===0)i.bufferSubData(c,0,h);else{u.sort((p,g)=>p.start-g.start);let d=0;for(let p=1;p<u.length;p++){const g=u[d],v=u[p];v.start<=g.start+g.count+1?g.count=Math.max(g.count,v.start+v.count-g.start):(++d,u[d]=v)}u.length=d+1;for(let p=0,g=u.length;p<g;p++){const v=u[p];i.bufferSubData(c,v.start*h.BYTES_PER_ELEMENT,h,v.start,v.count)}l.clearUpdateRanges()}l.onUploadCallback()}function r(o){return o.isInterleavedBufferAttribute&&(o=o.data),e.get(o)}function s(o){o.isInterleavedBufferAttribute&&(o=o.data);const l=e.get(o);l&&(i.deleteBuffer(l.buffer),e.delete(o))}function a(o,l){if(o.isInterleavedBufferAttribute&&(o=o.data),o.isGLBufferAttribute){const h=e.get(o);(!h||h.version<o.version)&&e.set(o,{buffer:o.buffer,type:o.type,bytesPerElement:o.elementSize,version:o.version});return}const c=e.get(o);if(c===void 0)e.set(o,t(o,l));else if(c.version<o.version){if(c.size!==o.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");n(c.buffer,o,l),c.version=o.version}}return{get:r,remove:s,update:a}}var $p=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,Yp=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,Kp=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,Zp=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Jp=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,Qp=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,jp=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,em=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,tm=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec4 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 );
	}
#endif`,nm=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,im=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,rm=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,sm=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,am=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,om=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,lm=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,cm=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,hm=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,um=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,dm=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#endif`,fm=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#endif`,pm=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec4 vColor;
#endif`,mm=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec4( 1.0 );
#endif
#ifdef USE_COLOR_ALPHA
	vColor *= color;
#elif defined( USE_COLOR )
	vColor.rgb *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.rgb *= instanceColor.rgb;
#endif
#ifdef USE_BATCHING_COLOR
	vColor *= getBatchingColor( getIndirectIndex( gl_DrawID ) );
#endif`,gm=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
#define inverseTransformDirection transformDirectionByInverseViewMatrix
vec3 transformNormalByInverseViewMatrix( in vec3 normal, in mat4 viewMatrix ) {
	return normalize( ( vec4( normal, 0.0 ) * viewMatrix ).xyz );
}
vec3 transformDirectionByInverseViewMatrix( in vec3 dir, in mat4 viewMatrix ) {
	return normalize( ( vec4( dir, 0.0 ) * viewMatrix ).xyz );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,vm=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
#endif`,xm=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,_m=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,ym=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,Mm=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,bm="gl_FragColor = linearToOutputTexel( gl_FragColor );",Sm=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,wm=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * reflectVec );
		#ifdef ENVMAP_BLENDING_MULTIPLY
			outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_MIX )
			outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_ADD )
			outgoingLight += envColor.xyz * specularStrength * reflectivity;
		#endif
	#endif
#endif`,Em=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform mat3 envMapRotation;
	uniform samplerCube envMap;
	#ifdef ENVMAP_TYPE_PMREM
		float roughnessToMip( const in float roughness ) {
			float r = clamp( roughness, 0.0, 1.0 );
			return ENVMAP_MAX_LOD * r * ( 2.0 - r );
		}
	#endif
#endif`,Tm=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,Am=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,Rm=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,Cm=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,Pm=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,Lm=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,Dm=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,Im=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,Nm=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,Um=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,Fm=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,Om=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_SUN_LIGHTS > 0
	struct SunLight {
		vec3 direction;
		vec3 color;
	};
	uniform SunLight sunLights[ NUM_SUN_LIGHTS ];
	void getSunLightInfo( const in SunLight sunLight, out IncidentLight light ) {
		light.color = sunLight.color;
		light.direction = sunLight.direction;
		light.visible = true;
	}
#endif
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif
#include <lightprobes_pars_fragment>`,Bm=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_PMREM
			vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
			vec4 envMapColor = textureLod( envMap, envMapRotation * worldNormal, ENVMAP_MAX_LOD );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_PMREM
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, pow4( roughness ) ) );
			reflectVec = transformDirectionByInverseViewMatrix( reflectVec, viewMatrix );
			vec4 envMapColor = textureLod( envMap, envMapRotation * reflectVec, roughnessToMip( roughness ) );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_RETROREFLECTION
		vec3 getIBLRetroRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
			#ifdef ENVMAP_TYPE_PMREM
				vec3 retroVec = normalize( mix( viewDir, normal, pow4( roughness ) ) );
				retroVec = transformDirectionByInverseViewMatrix( retroVec, viewMatrix );
				vec4 envMapColor = textureLod( envMap, envMapRotation * retroVec, roughnessToMip( roughness ) );
				return envMapColor.rgb * envMapIntensity;
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_PMREM
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
		#ifdef USE_RETROREFLECTION
			vec3 getIBLAnisotropyRetroRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
				#ifdef ENVMAP_TYPE_PMREM
					vec3 bentNormal = cross( bitangent, viewDir );
					bentNormal = normalize( cross( bentNormal, bitangent ) );
					bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
					return getIBLRetroRadiance( viewDir, bentNormal, roughness );
				#else
					return vec3( 0.0 );
				#endif
			}
		#endif
	#endif
#endif`,km=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,zm=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,Gm=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,Hm=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,Vm=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.diffuseContribution = diffuseColor.rgb * ( 1.0 - metalnessFactor );
material.metalness = metalnessFactor;
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.045 );
material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef USE_DIFFUSE_ROUGHNESS
	float diffuseRoughnessFactor = diffuseRoughness;
	#ifdef USE_DIFFUSE_ROUGHNESSMAP
		diffuseRoughnessFactor *= texture2D( diffuseRoughnessMap, vDiffuseRoughnessMapUv ).r;
	#endif
	material.diffuseRoughness = saturate( diffuseRoughnessFactor );
#endif
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor;
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = vec3( 0.04 );
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.045 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_RETROREFLECTION
	material.retroreflectivity = retroreflectivity;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.0001, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,Wm=`uniform sampler2D dfgLUT;
struct PhysicalMaterial {
	vec3 diffuseColor;
	vec3 diffuseContribution;
	vec3 specularColor;
	vec3 specularColorBlended;
	float roughness;
	float metalness;
	float specularF90;
	float dispersion;
	vec2 dfg;
	vec3 multiScatteringCompensation;
	#ifdef USE_DIFFUSE_ROUGHNESS
		float diffuseRoughness;
	#endif
	#ifdef USE_RETROREFLECTION
		float retroreflectivity;
	#endif
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0Dielectric;
		vec3 iridescenceF0Metallic;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
#ifdef USE_DIFFUSE_ROUGHNESS
	const float EON_EPSILON = 1e-7;
	float FON_DirectionalAlbedo( const in float mu, const in float roughness, const in float A ) {
		float muComp = 1.0 - mu;
		float gOverPi = muComp * ( 0.0571085289 + muComp * ( 0.491881867 + muComp * ( - 0.332181442 + muComp * 0.0714429953 ) ) );
		return A * ( 1.0 + roughness * gOverPi );
	}
	vec3 BRDF_EON( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 diffuseColor, const in float roughness ) {
		vec3 rho = saturate( diffuseColor );
		if ( roughness <= EON_EPSILON ) return BRDF_Lambert( rho );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float s = dot( lightDir, viewDir ) - dotNL * dotNV;
		float sOverT = ( s > 0.0 ) ? s / max( max( dotNL, dotNV ), EON_EPSILON ) : s;
		float A = 1.0 / ( 1.0 + ( 0.5 - 2.0 / ( 3.0 * PI ) ) * roughness );
		vec3 singleScatter = rho * RECIPROCAL_PI * A * ( 1.0 + roughness * sOverT );
		float averageAlbedo = A * ( 1.0 + ( 2.0 / 3.0 - 28.0 / ( 15.0 * PI ) ) * roughness );
		float albedoV = FON_DirectionalAlbedo( dotNV, roughness, A );
		float albedoL = FON_DirectionalAlbedo( dotNL, roughness, A );
		vec3 rhoMultiScatter = rho * rho * averageAlbedo / max( vec3( EON_EPSILON ), vec3( 1.0 ) - rho * ( 1.0 - averageAlbedo ) );
		vec3 multiScatter = rhoMultiScatter * RECIPROCAL_PI
			* max( EON_EPSILON, 1.0 - albedoV )
			* max( EON_EPSILON, 1.0 - albedoL )
			/ max( EON_EPSILON, 1.0 - averageAlbedo );
		return singleScatter + multiScatter;
	}
	vec3 EON_DirectionalAlbedo( const in vec3 diffuseColor, const in float roughness, const in float dotNV ) {
		vec3 rho = saturate( diffuseColor );
		if ( roughness <= EON_EPSILON ) return rho;
		float A = 1.0 / ( 1.0 + ( 0.5 - 2.0 / ( 3.0 * PI ) ) * roughness );
		float directionalAlbedo = FON_DirectionalAlbedo( dotNV, roughness, A );
		float averageAlbedo = A * ( 1.0 + ( 2.0 / 3.0 - 28.0 / ( 15.0 * PI ) ) * roughness );
		vec3 rhoMultiScatter = rho * rho * averageAlbedo / max( vec3( EON_EPSILON ), vec3( 1.0 ) - rho * ( 1.0 - averageAlbedo ) );
		return rho * directionalAlbedo + rhoMultiScatter * ( 1.0 - directionalAlbedo );
	}
#endif
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		return 0.5 / max( gv + gl, EPSILON );
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = max( material.clearcoatRoughness, 0.045 );
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColorBlended;
	float f90 = material.specularF90;
	float roughness = max( material.roughness, 0.045 );
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float alphaT = max( material.alphaT, alpha );
		float V = V_GGX_SmithCorrelated_Anisotropic( alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transpose( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float rInv = 1.0 / ( roughness + 0.1 );
	float a = -1.9362 + 1.0678 * roughness + 0.4573 * r2 - 0.8469 * rInv;
	float b = -0.6014 + 0.5538 * roughness - 0.4670 * r2 - 0.1255 * rInv;
	float DG = exp( a * dotNV + b );
	return saturate( DG );
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec2 fab, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec2 fab, const in vec3 specularColor, const in float specularF90, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColorBlended * t2.x + ( material.specularF90 - material.specularColorBlended ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseContribution * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
		#ifdef USE_CLEARCOAT
			vec3 Ncc = geometryClearcoatNormal;
			vec2 uvClearcoat = LTC_Uv( Ncc, viewDir, material.clearcoatRoughness );
			vec4 t1Clearcoat = texture2D( ltc_1, uvClearcoat );
			vec4 t2Clearcoat = texture2D( ltc_2, uvClearcoat );
			mat3 mInvClearcoat = mat3(
				vec3( t1Clearcoat.x, 0, t1Clearcoat.y ),
				vec3(             0, 1,             0 ),
				vec3( t1Clearcoat.z, 0, t1Clearcoat.w )
			);
			vec3 fresnelClearcoat = material.clearcoatF0 * t2Clearcoat.x + ( material.clearcoatF90 - material.clearcoatF0 ) * t2Clearcoat.y;
			clearcoatSpecularDirect += lightColor * fresnelClearcoat * LTC_Evaluate( Ncc, viewDir, position, mInvClearcoat, rectCoords );
		#endif
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
 
 		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
 
 		float sheenAlbedoV = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
 		float sheenAlbedoL = IBLSheenBRDF( geometryNormal, directLight.direction, material.sheenRoughness );
 
 		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * max( sheenAlbedoV, sheenAlbedoL );
 
 		irradiance *= sheenEnergyComp;
 
 	#endif
	vec3 specularBRDF = BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	#ifdef USE_RETROREFLECTION
		vec3 retroViewDir = reflect( - geometryViewDir, geometryNormal );
		vec3 retroSpecularBRDF = BRDF_GGX( directLight.direction, retroViewDir, geometryNormal, material );
		specularBRDF = mix( specularBRDF, retroSpecularBRDF, saturate( material.retroreflectivity ) );
	#endif
	reflectedLight.directSpecular += irradiance * specularBRDF * material.multiScatteringCompensation;
	vec3 halfDir = normalize( directLight.direction + geometryViewDir );
	float dotVH = saturate( dot( geometryViewDir, halfDir ) );
	vec3 F = F_Schlick( material.specularColor, material.specularF90, dotVH );
	#ifdef USE_RETROREFLECTION
		vec3 retroHalfDir = normalize( directLight.direction + retroViewDir );
		float dotRetroVH = saturate( dot( retroViewDir, retroHalfDir ) );
		vec3 retroF = F_Schlick( material.specularColor, material.specularF90, dotRetroVH );
		F = mix( F, retroF, saturate( material.retroreflectivity ) );
	#endif
	#ifdef USE_DIFFUSE_ROUGHNESS
		vec3 diffuseBRDF = BRDF_EON( directLight.direction, geometryViewDir, geometryNormal, material.diffuseColor, material.diffuseRoughness ) * ( 1.0 - material.metalness );
	#else
		vec3 diffuseBRDF = BRDF_Lambert( material.diffuseContribution );
	#endif
	reflectedLight.directDiffuse += irradiance * diffuseBRDF * ( 1.0 - F );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( material.dfg, material.specularColor, material.specularF90, material.iridescence, material.iridescenceF0Dielectric, singleScattering, multiScattering );
	#else
		computeMultiscattering( material.dfg, material.specularColor, material.specularF90, singleScattering, multiScattering );
	#endif
	#ifdef USE_DIFFUSE_ROUGHNESS
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		vec3 diffuseAlbedo = EON_DirectionalAlbedo( material.diffuseColor, material.diffuseRoughness, dotNV ) * ( 1.0 - material.metalness );
		vec3 diffuse = irradiance * RECIPROCAL_PI * diffuseAlbedo * ( 1.0 - singleScattering - multiScattering );
	#else
		vec3 diffuse = irradiance * BRDF_Lambert( material.diffuseContribution ) * ( 1.0 - singleScattering - multiScattering );
	#endif
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		sheenSpecularIndirect += irradiance * material.sheenColor * sheenAlbedo * RECIPROCAL_PI;
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		diffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectDiffuse += diffuse;
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness ) * RECIPROCAL_PI;
 	#endif
	vec3 singleScatteringDielectric = vec3( 0.0 );
	vec3 multiScatteringDielectric = vec3( 0.0 );
	vec3 singleScatteringMetallic = vec3( 0.0 );
	vec3 multiScatteringMetallic = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( material.dfg, material.specularColor, material.specularF90, material.iridescence, material.iridescenceF0Dielectric, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscatteringIridescence( material.dfg, material.diffuseColor, material.specularF90, material.iridescence, material.iridescenceF0Metallic, singleScatteringMetallic, multiScatteringMetallic );
	#else
		computeMultiscattering( material.dfg, material.specularColor, material.specularF90, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscattering( material.dfg, material.diffuseColor, material.specularF90, singleScatteringMetallic, multiScatteringMetallic );
	#endif
	vec3 singleScattering = mix( singleScatteringDielectric, singleScatteringMetallic, material.metalness );
	vec3 multiScattering = mix( multiScatteringDielectric, multiScatteringMetallic, material.metalness );
	vec3 totalScatteringDielectric = singleScatteringDielectric + multiScatteringDielectric;
	#ifdef USE_DIFFUSE_ROUGHNESS
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		vec3 diffuse = EON_DirectionalAlbedo( material.diffuseColor, material.diffuseRoughness, dotNV ) * ( 1.0 - material.metalness ) * ( 1.0 - totalScatteringDielectric );
	#else
		vec3 diffuse = material.diffuseContribution * ( 1.0 - totalScatteringDielectric );
	#endif
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	vec3 indirectSpecular = radiance * singleScattering;
	indirectSpecular += multiScattering * cosineWeightedIrradiance;
	vec3 indirectDiffuse = diffuse * cosineWeightedIrradiance;
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		indirectSpecular *= sheenEnergyComp;
		indirectDiffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectSpecular += indirectSpecular;
	reflectedLight.indirectDiffuse += indirectDiffuse;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,qm=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		vec3 iridescenceFresnelDielectric = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		vec3 iridescenceFresnelMetallic = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.diffuseColor );
		material.iridescenceFresnel = mix( iridescenceFresnelDielectric, iridescenceFresnelMetallic, material.metalness );
		material.iridescenceF0Dielectric = Schlick_to_F0( iridescenceFresnelDielectric, 1.0, dotNVi );
		material.iridescenceF0Metallic = Schlick_to_F0( iridescenceFresnelMetallic, 1.0, dotNVi );
	}
#endif
#ifdef STANDARD
	float dotNVms = saturate( dot( geometryNormal, geometryViewDir ) );
	material.dfg = texture2D( dfgLUT, vec2( material.roughness, dotNVms ) ).rg;
	#if ( NUM_SUN_LIGHTS > 0 || NUM_DIR_LIGHTS > 0 || NUM_POINT_LIGHTS > 0 || NUM_SPOT_LIGHTS > 0 )
		float EssMs = material.dfg.x + material.dfg.y;
		material.multiScatteringCompensation = 1.0 + material.specularColorBlended * ( 1.0 / EssMs - 1.0 );
	#endif
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS ) && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SUN_LIGHTS > 0 ) && defined( RE_Direct )
	SunLight sunLight;
	#if defined( USE_SHADOWMAP ) && NUM_SUN_LIGHT_SHADOWS > 0
	SunLightShadow sunLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SUN_LIGHTS; i ++ ) {
		sunLight = sunLights[ i ];
		getSunLightInfo( sunLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SUN_LIGHT_SHADOWS )
		sunLightShadow = sunLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getSunShadow( sunShadowMap[ i ], sunLightShadow, UNROLLED_LOOP_INDEX ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_LIGHT_PROBE_GRIDS > 0
		vec3 probeWorldPos = ( ( vec4( geometryPosition, 1.0 ) - viewMatrix[ 3 ] ) * viewMatrix ).xyz;
		vec3 probeWorldNormal = transformNormalByInverseViewMatrix( geometryNormal, viewMatrix );
		int probeGrid = - 1;
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_LIGHT_PROBE_GRIDS; i ++ ) {
			if ( isInsideLightProbeGrid( probeWorldPos, probeWorldNormal, probesMin[ i ], probesMax[ i ], probesResolution[ i ] ) ) probeGrid = UNROLLED_LOOP_INDEX;
		}
		#pragma unroll_loop_end
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_LIGHT_PROBE_GRIDS; i ++ ) {
			if ( probeGrid == UNROLLED_LOOP_INDEX ) irradiance += getLightProbeGridIrradiance( probesSH[ i ], probesMin[ i ], probesMax[ i ], probesResolution[ i ], probeWorldPos, probeWorldNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,Xm=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( ENVMAP_TYPE_PMREM )
		#if defined( STANDARD ) || defined( LAMBERT ) || defined( PHONG )
			iblIrradiance += getIBLIrradiance( geometryNormal );
		#endif
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		vec3 iblRadiance = getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		vec3 iblRadiance = getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_RETROREFLECTION
		#ifdef USE_ANISOTROPY
			vec3 retroIBLRadiance = getIBLAnisotropyRetroRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
		#else
			vec3 retroIBLRadiance = getIBLRetroRadiance( geometryViewDir, geometryNormal, material.roughness );
		#endif
		iblRadiance = mix( iblRadiance, retroIBLRadiance, saturate( material.retroreflectivity ) );
	#endif
	radiance += iblRadiance;
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,$m=`#if defined( RE_IndirectDiffuse )
	#if defined( LAMBERT ) || defined( PHONG )
		irradiance += iblIrradiance;
	#endif
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,Ym=`#if NUM_LIGHT_PROBE_GRIDS > 0
uniform highp sampler3D probesSH[ NUM_LIGHT_PROBE_GRIDS ];
uniform vec3 probesMin[ NUM_LIGHT_PROBE_GRIDS ];
uniform vec3 probesMax[ NUM_LIGHT_PROBE_GRIDS ];
uniform vec3 probesResolution[ NUM_LIGHT_PROBE_GRIDS ];
bool isInsideLightProbeGrid( vec3 worldPos, vec3 worldNormal, vec3 probesMin, vec3 probesMax, vec3 probesResolution ) {
	vec3 spacing = ( probesMax - probesMin ) / probesResolution;
	vec3 samplePos = worldPos + worldNormal * spacing * 0.5;
	vec3 margin = spacing * 0.01;
	return all( greaterThanEqual( samplePos, probesMin - margin ) ) && all( lessThanEqual( samplePos, probesMax + margin ) );
}
vec3 getLightProbeGridIrradiance( highp sampler3D probesSH, vec3 probesMin, vec3 probesMax, vec3 probesResolution, vec3 worldPos, vec3 worldNormal ) {
	vec3 res = probesResolution;
	vec3 gridRange = probesMax - probesMin;
	vec3 probeSpacing = gridRange / res;
	vec3 samplePos = worldPos + worldNormal * probeSpacing * 0.5;
	vec3 uvw = clamp( ( samplePos - probesMin ) / gridRange, 0.5 / res, 1.0 - 0.5 / res );
	float nz          = res.z;
	float paddedSlices = nz + 2.0;
	float atlasDepth  = 7.0 * paddedSlices;
	float uvZBase     = uvw.z * nz + 1.0;
	vec4 s0 = texture( probesSH, vec3( uvw.xy, ( uvZBase                       ) / atlasDepth ) );
	vec4 s1 = texture( probesSH, vec3( uvw.xy, ( uvZBase +       paddedSlices   ) / atlasDepth ) );
	vec4 s2 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 2.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s3 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 3.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s4 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 4.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s5 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 5.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s6 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 6.0 * paddedSlices   ) / atlasDepth ) );
	vec3 c0 = s0.xyz;
	vec3 c1 = vec3( s0.w, s1.xy );
	vec3 c2 = vec3( s1.zw, s2.x );
	vec3 c3 = s2.yzw;
	vec3 c4 = s3.xyz;
	vec3 c5 = vec3( s3.w, s4.xy );
	vec3 c6 = vec3( s4.zw, s5.x );
	vec3 c7 = s5.yzw;
	vec3 c8 = s6.xyz;
	float x = worldNormal.x, y = worldNormal.y, z = worldNormal.z;
	vec3 result = c0 * 0.886227;
	result += c1 * 2.0 * 0.511664 * y;
	result += c2 * 2.0 * 0.511664 * z;
	result += c3 * 2.0 * 0.511664 * x;
	result += c4 * 2.0 * 0.429043 * x * y;
	result += c5 * 2.0 * 0.429043 * y * z;
	result += c6 * ( 0.743125 * z * z - 0.247708 );
	result += c7 * 2.0 * 0.429043 * x * z;
	result += c8 * 0.429043 * ( x * x - y * y );
	return max( result, vec3( 0.0 ) );
}
#endif`,Km=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,Zm=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,Jm=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,Qm=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,jm=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,e0=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,t0=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,n0=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,i0=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,r0=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,s0=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,a0=`#if defined( USE_MORPHCOLORS )
	#if defined( USE_COLOR_ALPHA )
		vColor *= morphTargetBaseInfluence;
	#elif defined( USE_COLOR )
		vColor.rgb *= morphTargetBaseInfluence;
	#endif
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor.rgb += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,o0=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,l0=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,c0=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,h0=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#ifdef DOUBLE_SIDED
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#ifdef DOUBLE_SIDED
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,u0=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#if defined( USE_PACKED_NORMALMAP )
		mapN = vec3( mapN.xy, sqrt( saturate( 1.0 - dot( mapN.xy, mapN.xy ) ) ) );
	#endif
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,d0=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,f0=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,p0=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
		#ifdef FLIP_SIDED
			vBitangent = - vBitangent;
		#endif
	#endif
#endif`,m0=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,g0=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,v0=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,x0=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,_0=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,y0=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,M0=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	#ifdef USE_REVERSED_DEPTH_BUFFER
	
		return depth * ( far - near ) - far;
	#else
		return depth * ( near - far ) - near;
	#endif
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	
	#ifdef USE_REVERSED_DEPTH_BUFFER
		return ( near * far ) / ( ( near - far ) * depth - near );
	#else
		return ( near * far ) / ( ( far - near ) * depth - far );
	#endif
}`,b0=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,S0=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,w0=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,E0=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,T0=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,A0=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,R0=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
		#define SUN_LIGHT_CASCADES 2
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow sunShadowMap[ NUM_SUN_LIGHT_SHADOWS ];
		#else
			uniform sampler2D sunShadowMap[ NUM_SUN_LIGHT_SHADOWS ];
		#endif
		uniform mat4 sunShadowMatrix[ NUM_SUN_LIGHT_SHADOWS * SUN_LIGHT_CASCADES ];
		uniform vec4 sunShadowCascade[ NUM_SUN_LIGHT_SHADOWS * SUN_LIGHT_CASCADES ];
		varying vec4 vSunShadowWorldPosition;
		varying vec3 vSunShadowWorldNormal;
		struct SunLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SunLightShadow sunLightShadows[ NUM_SUN_LIGHT_SHADOWS ];
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#else
			uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#endif
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#else
			uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#endif
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform samplerCubeShadow pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#elif defined( SHADOWMAP_TYPE_BASIC )
			uniform samplerCube pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#endif
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float interleavedGradientNoise( vec2 position ) {
			return fract( 52.9829189 * fract( dot( position, vec2( 0.06711056, 0.00583715 ) ) ) );
		}
		vec2 vogelDiskSample( int sampleIndex, int samplesCount, float phi ) {
			const float goldenAngle = 2.399963229728653;
			float r = sqrt( ( float( sampleIndex ) + 0.5 ) / float( samplesCount ) );
			float theta = float( sampleIndex ) * goldenAngle + phi;
			return vec2( cos( theta ), sin( theta ) ) * r;
		}
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float getShadow( sampler2DShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
				vec2 radius = shadowRadius * texelSize;
				float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
				shadow = (
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 0, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 1, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 2, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 3, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 4, 5, phi ) * radius, shadowCoord.z ) )
				) * 0.2;
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#elif defined( SHADOWMAP_TYPE_VSM )
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 distribution = texture2D( shadowMap, shadowCoord.xy ).rg;
				float mean = distribution.x;
				float variance = distribution.y * distribution.y;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					float hard_shadow = step( mean, shadowCoord.z );
				#else
					float hard_shadow = step( shadowCoord.z, mean );
				#endif
				
				if ( hard_shadow == 1.0 ) {
					shadow = 1.0;
				} else {
					variance = max( variance, 0.0000001 );
					float d = shadowCoord.z - mean;
					float p_max = variance / ( variance + d * d );
					p_max = clamp( ( p_max - 0.3 ) / 0.65, 0.0, 1.0 );
					shadow = max( hard_shadow, p_max );
				}
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#else
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				float depth = texture2D( shadowMap, shadowCoord.xy ).r;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					shadow = step( depth, shadowCoord.z );
				#else
					shadow = step( shadowCoord.z, depth );
				#endif
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#endif
	#if NUM_SUN_LIGHT_SHADOWS > 0
		float getSunShadow(
			#if defined( SHADOWMAP_TYPE_PCF )
				sampler2DShadow shadowMap,
			#else
				sampler2D shadowMap,
			#endif
			SunLightShadow sunLightShadow,
			int shadowIndex
		) {
			vec4 shadowWorldPosition = vec4( vSunShadowWorldPosition.xyz + vSunShadowWorldNormal * sunLightShadow.shadowNormalBias, 1.0 );
			float viewDepth = vSunShadowWorldPosition.w;
			int cascadeOffset = shadowIndex * SUN_LIGHT_CASCADES;
			float shadow = 1.0;
			for ( int i = SUN_LIGHT_CASCADES - 1; i >= 0; i -- ) {
				vec4 cascade = sunShadowCascade[ cascadeOffset + i ];
				if ( viewDepth >= cascade.x && viewDepth < cascade.y ) {
					float cascadeShadow = getShadow(
						shadowMap,
						sunLightShadow.shadowMapSize,
						sunLightShadow.shadowIntensity,
						sunLightShadow.shadowBias,
						sunLightShadow.shadowRadius,
						sunShadowMatrix[ cascadeOffset + i ] * shadowWorldPosition
					);
					shadow = mix( cascadeShadow, shadow, smoothstep( cascade.z, cascade.y, viewDepth ) );
				}
			}
			return shadow;
		}
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	#if defined( SHADOWMAP_TYPE_PCF )
	float getPointShadow( samplerCubeShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 bd3D = normalize( lightToPosition );
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			float lightDistance = length( lightToPosition );
			float depthRange = shadowCameraFar - shadowCameraNear;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				float depthA = - shadowCameraNear / depthRange - shadowBias;
				float depthB = shadowCameraNear * shadowCameraFar / ( depthRange * lightDistance );
			#else
				float depthA = shadowCameraFar / depthRange + shadowBias;
				float depthB = - shadowCameraNear * shadowCameraFar / ( depthRange * lightDistance );
			#endif
			float texelSize = shadowRadius / shadowMapSize.x;
			vec3 absDir = abs( bd3D );
			vec3 tangent = absDir.x > absDir.z ? vec3( 0.0, 1.0, 0.0 ) : vec3( 1.0, 0.0, 0.0 );
			tangent = normalize( cross( bd3D, tangent ) );
			vec3 bitangent = cross( bd3D, tangent );
			float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
			shadow = 0.0;
			for ( int i = 0; i < 5; i ++ ) {
				vec2 offset = vogelDiskSample( i, 5, phi );
				vec3 direction = bd3D + ( tangent * offset.x + bitangent * offset.y ) * texelSize;
				vec3 absDirection = abs( direction );
				float dp = depthA + depthB / max( max( absDirection.x, absDirection.y ), absDirection.z );
				shadow += texture( shadowMap, vec4( direction, dp ) );
			}
			shadow *= 0.2;
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#elif defined( SHADOWMAP_TYPE_BASIC )
	float getPointShadow( samplerCube shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			float depth = textureCube( shadowMap, bd3D ).r;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				depth = 1.0 - depth;
			#endif
			shadow = step( dp, depth );
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#endif
	#endif
#endif`,C0=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
		varying vec4 vSunShadowWorldPosition;
		varying vec3 vSunShadowWorldNormal;
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,P0=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_SUN_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	#ifdef HAS_NORMAL
		vec3 shadowWorldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
	#else
		vec3 shadowWorldNormal = vec3( 0.0 );
	#endif
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_SUN_LIGHT_SHADOWS > 0
		vSunShadowWorldPosition = vec4( worldPosition.xyz, - mvPosition.z );
		vSunShadowWorldNormal = shadowWorldNormal;
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,L0=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
	SunLightShadow sunLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SUN_LIGHT_SHADOWS; i ++ ) {
		sunLight = sunLightShadows[ i ];
		shadow *= receiveShadow ? getSunShadow( sunShadowMap[ i ], sunLight, UNROLLED_LOOP_INDEX ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0 && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,D0=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,I0=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,N0=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,U0=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,F0=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,O0=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,B0=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,k0=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,z0=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseContribution, material.specularColorBlended, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,G0=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,H0=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_DIFFUSE_ROUGHNESSMAP
	varying vec2 vDiffuseRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,V0=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_DIFFUSE_ROUGHNESSMAP
	uniform mat3 diffuseRoughnessMapTransform;
	varying vec2 vDiffuseRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,W0=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DIFFUSE_ROUGHNESSMAP
	vDiffuseRoughnessMapUv = ( diffuseRoughnessMapTransform * vec3( DIFFUSE_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,q0=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const X0=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,$0=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Y0=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,K0=`uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <envmap_common_pars_fragment>
void main() {
	#ifdef ENVMAP_TYPE_PMREM
		vec4 texColor = textureLod( envMap, backgroundRotation * vWorldDirection, roughnessToMip( backgroundBlurriness ) );
	#else
		vec4 texColor = textureCube( envMap, backgroundRotation * vWorldDirection );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Z0=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,J0=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Q0=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,j0=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,eg=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,tg=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = vec4( dist, 0.0, 0.0, 1.0 );
}`,ng=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,ig=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,rg=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,sg=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,ag=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,og=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,lg=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,cg=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,hg=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,ug=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,dg=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,fg=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( normalize( normal ) * 0.5 + 0.5, diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,pg=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,mg=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,gg=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,vg=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DIFFUSE_ROUGHNESS
	uniform float diffuseRoughness;
	#ifdef USE_DIFFUSE_ROUGHNESSMAP
		uniform sampler2D diffuseRoughnessMap;
	#endif
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_RETROREFLECTION
	uniform float retroreflectivity;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
 
		outgoingLight = outgoingLight + sheenSpecularDirect + sheenSpecularIndirect;
 
 	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,xg=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,_g=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,yg=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,Mg=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,bg=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Sg=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,wg=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Eg=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,ke={alphahash_fragment:$p,alphahash_pars_fragment:Yp,alphamap_fragment:Kp,alphamap_pars_fragment:Zp,alphatest_fragment:Jp,alphatest_pars_fragment:Qp,aomap_fragment:jp,aomap_pars_fragment:em,batching_pars_vertex:tm,batching_vertex:nm,begin_vertex:im,beginnormal_vertex:rm,bsdfs:sm,iridescence_fragment:am,bumpmap_pars_fragment:om,clipping_planes_fragment:lm,clipping_planes_pars_fragment:cm,clipping_planes_pars_vertex:hm,clipping_planes_vertex:um,color_fragment:dm,color_pars_fragment:fm,color_pars_vertex:pm,color_vertex:mm,common:gm,defaultnormal_vertex:vm,displacementmap_pars_vertex:xm,displacementmap_vertex:_m,emissivemap_fragment:ym,emissivemap_pars_fragment:Mm,colorspace_fragment:bm,colorspace_pars_fragment:Sm,envmap_fragment:wm,envmap_common_pars_fragment:Em,envmap_pars_fragment:Tm,envmap_pars_vertex:Am,envmap_physical_pars_fragment:Bm,envmap_vertex:Rm,fog_vertex:Cm,fog_pars_vertex:Pm,fog_fragment:Lm,fog_pars_fragment:Dm,gradientmap_pars_fragment:Im,lightmap_pars_fragment:Nm,lights_lambert_fragment:Um,lights_lambert_pars_fragment:Fm,lights_pars_begin:Om,lights_toon_fragment:km,lights_toon_pars_fragment:zm,lights_phong_fragment:Gm,lights_phong_pars_fragment:Hm,lights_physical_fragment:Vm,lights_physical_pars_fragment:Wm,lights_fragment_begin:qm,lights_fragment_maps:Xm,lights_fragment_end:$m,lightprobes_pars_fragment:Ym,logdepthbuf_fragment:Km,logdepthbuf_pars_fragment:Zm,logdepthbuf_pars_vertex:Jm,logdepthbuf_vertex:Qm,map_fragment:jm,map_pars_fragment:e0,map_particle_fragment:t0,map_particle_pars_fragment:n0,metalnessmap_fragment:i0,metalnessmap_pars_fragment:r0,morphinstance_vertex:s0,morphcolor_vertex:a0,morphnormal_vertex:o0,morphtarget_pars_vertex:l0,morphtarget_vertex:c0,normal_fragment_begin:h0,normal_fragment_maps:u0,normal_pars_fragment:d0,normal_pars_vertex:f0,normal_vertex:p0,normalmap_pars_fragment:m0,clearcoat_normal_fragment_begin:g0,clearcoat_normal_fragment_maps:v0,clearcoat_pars_fragment:x0,iridescence_pars_fragment:_0,opaque_fragment:y0,packing:M0,premultiplied_alpha_fragment:b0,project_vertex:S0,dithering_fragment:w0,dithering_pars_fragment:E0,roughnessmap_fragment:T0,roughnessmap_pars_fragment:A0,shadowmap_pars_fragment:R0,shadowmap_pars_vertex:C0,shadowmap_vertex:P0,shadowmask_pars_fragment:L0,skinbase_vertex:D0,skinning_pars_vertex:I0,skinning_vertex:N0,skinnormal_vertex:U0,specularmap_fragment:F0,specularmap_pars_fragment:O0,tonemapping_fragment:B0,tonemapping_pars_fragment:k0,transmission_fragment:z0,transmission_pars_fragment:G0,uv_pars_fragment:H0,uv_pars_vertex:V0,uv_vertex:W0,worldpos_vertex:q0,background_vert:X0,background_frag:$0,backgroundCube_vert:Y0,backgroundCube_frag:K0,cube_vert:Z0,cube_frag:J0,depth_vert:Q0,depth_frag:j0,distance_vert:eg,distance_frag:tg,equirect_vert:ng,equirect_frag:ig,linedashed_vert:rg,linedashed_frag:sg,meshbasic_vert:ag,meshbasic_frag:og,meshlambert_vert:lg,meshlambert_frag:cg,meshmatcap_vert:hg,meshmatcap_frag:ug,meshnormal_vert:dg,meshnormal_frag:fg,meshphong_vert:pg,meshphong_frag:mg,meshphysical_vert:gg,meshphysical_frag:vg,meshtoon_vert:xg,meshtoon_frag:_g,points_vert:yg,points_frag:Mg,shadow_vert:bg,shadow_frag:Sg,sprite_vert:wg,sprite_frag:Eg},pe={common:{diffuse:{value:new Te(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new Ie},alphaMap:{value:null},alphaMapTransform:{value:new Ie},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new Ie}},envmap:{envMap:{value:null},envMapRotation:{value:new Ie},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98},dfgLUT:{value:null}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new Ie}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new Ie}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new Ie},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new Ie},normalScale:{value:new de(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new Ie},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new Ie}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new Ie}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new Ie}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new Te(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},sunLights:{value:[],properties:{direction:{},color:{}}},sunLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},sunShadowMatrix:{value:[]},sunShadowCascade:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null},probesSH:{value:[]},probesMin:{value:[]},probesMax:{value:[]},probesResolution:{value:[]}},points:{diffuse:{value:new Te(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new Ie},alphaTest:{value:0},uvTransform:{value:new Ie}},sprite:{diffuse:{value:new Te(16777215)},opacity:{value:1},center:{value:new de(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new Ie},alphaMap:{value:null},alphaMapTransform:{value:new Ie},alphaTest:{value:0}}},Rn={basic:{uniforms:Ht([pe.common,pe.specularmap,pe.envmap,pe.aomap,pe.lightmap,pe.fog]),vertexShader:ke.meshbasic_vert,fragmentShader:ke.meshbasic_frag},lambert:{uniforms:Ht([pe.common,pe.specularmap,pe.envmap,pe.aomap,pe.lightmap,pe.emissivemap,pe.bumpmap,pe.normalmap,pe.displacementmap,pe.fog,pe.lights,{emissive:{value:new Te(0)},envMapIntensity:{value:1}}]),vertexShader:ke.meshlambert_vert,fragmentShader:ke.meshlambert_frag},phong:{uniforms:Ht([pe.common,pe.specularmap,pe.envmap,pe.aomap,pe.lightmap,pe.emissivemap,pe.bumpmap,pe.normalmap,pe.displacementmap,pe.fog,pe.lights,{emissive:{value:new Te(0)},specular:{value:new Te(1118481)},shininess:{value:30},envMapIntensity:{value:1}}]),vertexShader:ke.meshphong_vert,fragmentShader:ke.meshphong_frag},standard:{uniforms:Ht([pe.common,pe.envmap,pe.aomap,pe.lightmap,pe.emissivemap,pe.bumpmap,pe.normalmap,pe.displacementmap,pe.roughnessmap,pe.metalnessmap,pe.fog,pe.lights,{emissive:{value:new Te(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:ke.meshphysical_vert,fragmentShader:ke.meshphysical_frag},toon:{uniforms:Ht([pe.common,pe.aomap,pe.lightmap,pe.emissivemap,pe.bumpmap,pe.normalmap,pe.displacementmap,pe.gradientmap,pe.fog,pe.lights,{emissive:{value:new Te(0)}}]),vertexShader:ke.meshtoon_vert,fragmentShader:ke.meshtoon_frag},matcap:{uniforms:Ht([pe.common,pe.bumpmap,pe.normalmap,pe.displacementmap,pe.fog,{matcap:{value:null}}]),vertexShader:ke.meshmatcap_vert,fragmentShader:ke.meshmatcap_frag},points:{uniforms:Ht([pe.points,pe.fog]),vertexShader:ke.points_vert,fragmentShader:ke.points_frag},dashed:{uniforms:Ht([pe.common,pe.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:ke.linedashed_vert,fragmentShader:ke.linedashed_frag},depth:{uniforms:Ht([pe.common,pe.displacementmap]),vertexShader:ke.depth_vert,fragmentShader:ke.depth_frag},normal:{uniforms:Ht([pe.common,pe.bumpmap,pe.normalmap,pe.displacementmap,{opacity:{value:1}}]),vertexShader:ke.meshnormal_vert,fragmentShader:ke.meshnormal_frag},sprite:{uniforms:Ht([pe.sprite,pe.fog]),vertexShader:ke.sprite_vert,fragmentShader:ke.sprite_frag},background:{uniforms:{uvTransform:{value:new Ie},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:ke.background_vert,fragmentShader:ke.background_frag},backgroundCube:{uniforms:{envMap:{value:null},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new Ie}},vertexShader:ke.backgroundCube_vert,fragmentShader:ke.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:ke.cube_vert,fragmentShader:ke.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:ke.equirect_vert,fragmentShader:ke.equirect_frag},distance:{uniforms:Ht([pe.common,pe.displacementmap,{referencePosition:{value:new P},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:ke.distance_vert,fragmentShader:ke.distance_frag},shadow:{uniforms:Ht([pe.lights,pe.fog,{color:{value:new Te(0)},opacity:{value:1}}]),vertexShader:ke.shadow_vert,fragmentShader:ke.shadow_frag}};Rn.physical={uniforms:Ht([Rn.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new Ie},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new Ie},clearcoatNormalScale:{value:new de(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new Ie},diffuseRoughness:{value:0},diffuseRoughnessMap:{value:null},diffuseRoughnessMapTransform:{value:new Ie},dispersion:{value:0},retroreflectivity:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new Ie},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new Ie},sheen:{value:0},sheenColor:{value:new Te(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new Ie},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new Ie},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new Ie},transmissionSamplerSize:{value:new de},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new Ie},attenuationDistance:{value:0},attenuationColor:{value:new Te(0)},specularColor:{value:new Te(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new Ie},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new Ie},anisotropyVector:{value:new de},anisotropyMap:{value:null},anisotropyMapTransform:{value:new Ie}}]),vertexShader:ke.meshphysical_vert,fragmentShader:ke.meshphysical_frag};const Ps={r:0,b:0,g:0},Tg=new Ye,Vu=new Ie;Vu.set(-1,0,0,0,1,0,0,0,1);function Ag(i,e,t,n,r,s){const a=new Te(0);let o=r===!0?0:1,l,c,h=null,u=0,d=null;function p(_){let S=_.isScene===!0?_.background:null;if(S&&S.isTexture){const y=_.backgroundBlurriness>0;S=e.get(S,y)}return S}function g(_){let S=!1;const y=p(_);y===null?m(a,o):y&&y.isColor&&(m(y,1),S=!0);const A=i.xr.getEnvironmentBlendMode();A==="additive"?t.buffers.color.setClear(0,0,0,1,s):A==="alpha-blend"&&t.buffers.color.setClear(0,0,0,0,s),(i.autoClear||S)&&(t.buffers.depth.setTest(!0),t.buffers.depth.setMask(!0),t.buffers.color.setMask(!0),i.clear(i.autoClearColor,i.autoClearDepth,i.autoClearStencil))}function v(_,S){const y=p(S);y&&y.isCubeTexture?(c===void 0&&(c=new mt(new Li(1,1,1),new Xn({name:"BackgroundCubeMaterial",uniforms:sr(Rn.backgroundCube.uniforms),vertexShader:Rn.backgroundCube.vertexShader,fragmentShader:Rn.backgroundCube.fragmentShader,side:qt,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),c.geometry.deleteAttribute("normal"),c.geometry.deleteAttribute("uv"),c.onBeforeRender=function(A,E,x){this.matrixWorld.copyPosition(x.matrixWorld)},Object.defineProperty(c.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),n.update(c)),c.material.uniforms.envMap.value=y,c.material.uniforms.backgroundBlurriness.value=S.backgroundBlurriness,c.material.uniforms.backgroundIntensity.value=S.backgroundIntensity,c.material.uniforms.backgroundRotation.value.setFromMatrix4(Tg.makeRotationFromEuler(S.backgroundRotation)).transpose(),y.isRenderTargetTexture===!1&&c.material.uniforms.backgroundRotation.value.premultiply(Vu),c.material.toneMapped=qe.getTransfer(y.colorSpace)!==et,(h!==y||u!==y.version||d!==i.toneMapping)&&(c.material.needsUpdate=!0,h=y,u=y.version,d=i.toneMapping),c.layers.enableAll(),_.unshift(c,c.geometry,c.material,0,0,null)):y&&y.isTexture&&(l===void 0&&(l=new mt(new li(2,2),new Xn({name:"BackgroundMaterial",uniforms:sr(Rn.background.uniforms),vertexShader:Rn.background.vertexShader,fragmentShader:Rn.background.fragmentShader,side:Ei,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),l.geometry.deleteAttribute("normal"),Object.defineProperty(l.material,"map",{get:function(){return this.uniforms.t2D.value}}),n.update(l)),l.material.uniforms.t2D.value=y,l.material.uniforms.backgroundIntensity.value=S.backgroundIntensity,l.material.toneMapped=qe.getTransfer(y.colorSpace)!==et,y.matrixAutoUpdate===!0&&y.updateMatrix(),l.material.uniforms.uvTransform.value.copy(y.matrix),(h!==y||u!==y.version||d!==i.toneMapping)&&(l.material.needsUpdate=!0,h=y,u=y.version,d=i.toneMapping),l.layers.enableAll(),_.unshift(l,l.geometry,l.material,0,0,null))}function m(_,S){_.getRGB(Ps,Bu(i)),t.buffers.color.setClear(Ps.r,Ps.g,Ps.b,S,s)}function f(){c!==void 0&&(c.geometry.dispose(),c.material.dispose(),c=void 0),l!==void 0&&(l.geometry.dispose(),l.material.dispose(),l=void 0)}return{getClearColor:function(){return a},setClearColor:function(_,S=1){a.set(_),o=S,m(a,o)},getClearAlpha:function(){return o},setClearAlpha:function(_){o=_,m(a,o)},render:g,addToRenderList:v,dispose:f}}function Rg(i,e){const t=i.getParameter(i.MAX_VERTEX_ATTRIBS),n={},r=d(null);let s=r,a=!1;function o(N,F,V,D,H){let Z=!1;const z=u(N,D,V,F);s!==z&&(s=z,c(s.object)),Z=p(N,D,V,H),Z&&g(N,D,V,H),H!==null&&e.update(H,i.ELEMENT_ARRAY_BUFFER),(Z||a)&&(a=!1,y(N,F,V,D),H!==null&&i.bindBuffer(i.ELEMENT_ARRAY_BUFFER,e.get(H).buffer))}function l(){return i.createVertexArray()}function c(N){return i.bindVertexArray(N)}function h(N){return i.deleteVertexArray(N)}function u(N,F,V,D){const H=D.wireframe===!0;let Z=n[F.id];Z===void 0&&(Z={},n[F.id]=Z);const z=N.isInstancedMesh===!0?N.id:0;let ne=Z[z];ne===void 0&&(ne={},Z[z]=ne);let q=ne[V.id];q===void 0&&(q={},ne[V.id]=q);let j=q[H];return j===void 0&&(j=d(l()),q[H]=j),j}function d(N){const F=[],V=[],D=[];for(let H=0;H<t;H++)F[H]=0,V[H]=0,D[H]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:F,enabledAttributes:V,attributeDivisors:D,object:N,attributes:{},index:null}}function p(N,F,V,D){const H=s.attributes,Z=F.attributes;let z=0;const ne=V.getAttributes();for(const q in ne)if(ne[q].location>=0){const ee=H[q];let Se=Z[q];if(Se===void 0&&(q==="instanceMatrix"&&N.instanceMatrix&&(Se=N.instanceMatrix),q==="instanceColor"&&N.instanceColor&&(Se=N.instanceColor)),ee===void 0||ee.attribute!==Se||Se&&ee.data!==Se.data)return!0;z++}return s.attributesNum!==z||s.index!==D}function g(N,F,V,D){const H={},Z=F.attributes;let z=0;const ne=V.getAttributes();for(const q in ne)if(ne[q].location>=0){let ee=Z[q];ee===void 0&&(q==="instanceMatrix"&&N.instanceMatrix&&(ee=N.instanceMatrix),q==="instanceColor"&&N.instanceColor&&(ee=N.instanceColor));const Se={};Se.attribute=ee,ee&&ee.data&&(Se.data=ee.data),H[q]=Se,z++}s.attributes=H,s.attributesNum=z,s.index=D}function v(){const N=s.newAttributes;for(let F=0,V=N.length;F<V;F++)N[F]=0}function m(N){f(N,0)}function f(N,F){const V=s.newAttributes,D=s.enabledAttributes,H=s.attributeDivisors;V[N]=1,D[N]===0&&(i.enableVertexAttribArray(N),D[N]=1),H[N]!==F&&(i.vertexAttribDivisor(N,F),H[N]=F)}function _(){const N=s.newAttributes,F=s.enabledAttributes;for(let V=0,D=F.length;V<D;V++)F[V]!==N[V]&&(i.disableVertexAttribArray(V),F[V]=0)}function S(N,F,V,D,H,Z,z){z===!0?i.vertexAttribIPointer(N,F,V,H,Z):i.vertexAttribPointer(N,F,V,D,H,Z)}function y(N,F,V,D){v();const H=D.attributes,Z=V.getAttributes(),z=F.defaultAttributeValues;for(const ne in Z){const q=Z[ne];if(q.location>=0){let j=H[ne];if(j===void 0&&(ne==="instanceMatrix"&&N.instanceMatrix&&(j=N.instanceMatrix),ne==="instanceColor"&&N.instanceColor&&(j=N.instanceColor)),j!==void 0){const ee=j.normalized,Se=j.itemSize,Ne=e.get(j);if(Ne===void 0)continue;const Y=Ne.buffer,ge=Ne.type,ye=Ne.bytesPerElement,Re=ge===i.INT||ge===i.UNSIGNED_INT||j.gpuType===ul;if(j.isInterleavedBufferAttribute){const ve=j.data,Fe=ve.isInterleavedBuffer===!0?ve.stride:ve.itemSize,vt=j.offset;if(ve.isInstancedInterleavedBuffer||ve.isInstancedBufferAttribute){for(let Le=0;Le<q.locationSize;Le++)f(q.location+Le,ve.meshPerAttribute);N.isInstancedMesh!==!0&&D._maxInstanceCount===void 0&&(D._maxInstanceCount=ve.meshPerAttribute*ve.count)}else for(let Le=0;Le<q.locationSize;Le++)m(q.location+Le);i.bindBuffer(i.ARRAY_BUFFER,Y);for(let Le=0;Le<q.locationSize;Le++)S(q.location+Le,Se/q.locationSize,ge,ee,Fe*ye,(vt+Se/q.locationSize*Le)*ye,Re)}else{if(j.isInstancedBufferAttribute){for(let ve=0;ve<q.locationSize;ve++)f(q.location+ve,j.meshPerAttribute);N.isInstancedMesh!==!0&&D._maxInstanceCount===void 0&&(D._maxInstanceCount=j.meshPerAttribute*j.count)}else for(let ve=0;ve<q.locationSize;ve++)m(q.location+ve);i.bindBuffer(i.ARRAY_BUFFER,Y);for(let ve=0;ve<q.locationSize;ve++)S(q.location+ve,Se/q.locationSize,ge,ee,Se*ye,Se/q.locationSize*ve*ye,Re)}}else if(z!==void 0){const ee=z[ne];if(ee!==void 0)switch(ee.length){case 2:i.vertexAttrib2fv(q.location,ee);break;case 3:i.vertexAttrib3fv(q.location,ee);break;case 4:i.vertexAttrib4fv(q.location,ee);break;default:i.vertexAttrib1fv(q.location,ee)}}}}_()}function A(){I();for(const N in n){const F=n[N];for(const V in F){const D=F[V];for(const H in D){const Z=D[H];for(const z in Z)h(Z[z].object),delete Z[z];delete D[H]}}delete n[N]}}function E(N){if(n[N.id]===void 0)return;const F=n[N.id];for(const V in F){const D=F[V];for(const H in D){const Z=D[H];for(const z in Z)h(Z[z].object),delete Z[z];delete D[H]}}delete n[N.id]}function x(N){for(const F in n){const V=n[F];for(const D in V){const H=V[D];if(H[N.id]===void 0)continue;const Z=H[N.id];for(const z in Z)h(Z[z].object),delete Z[z];delete H[N.id]}}}function w(N){for(const F in n){const V=n[F],D=N.isInstancedMesh===!0?N.id:0,H=V[D];if(H!==void 0){for(const Z in H){const z=H[Z];for(const ne in z)h(z[ne].object),delete z[ne];delete H[Z]}delete V[D],Object.keys(V).length===0&&delete n[F]}}}function I(){C(),a=!0,s!==r&&(s=r,c(s.object))}function C(){r.geometry=null,r.program=null,r.wireframe=!1}return{setup:o,reset:I,resetDefaultState:C,dispose:A,releaseStatesOfGeometry:E,releaseStatesOfObject:w,releaseStatesOfProgram:x,initAttributes:v,enableAttribute:m,disableUnusedAttributes:_}}function Cg(i,e,t){let n;function r(l){n=l}function s(l,c){i.drawArrays(n,l,c),t.update(c,n,1)}function a(l,c,h){h!==0&&(i.drawArraysInstanced(n,l,c,h),t.update(c,n,h))}function o(l,c,h){if(h===0)return;e.get("WEBGL_multi_draw").multiDrawArraysWEBGL(n,l,0,c,0,h);let d=0;for(let p=0;p<h;p++)d+=c[p];t.update(d,n,1)}this.setMode=r,this.render=s,this.renderInstances=a,this.renderMultiDraw=o}function Pg(i,e,t,n){let r;function s(){if(r!==void 0)return r;if(e.has("EXT_texture_filter_anisotropic")===!0){const x=e.get("EXT_texture_filter_anisotropic");r=i.getParameter(x.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else r=0;return r}function a(x){return!(x!==Cn&&n.convert(x)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_FORMAT))}function o(x){const w=x===Ln&&(e.has("EXT_color_buffer_half_float")||e.has("EXT_color_buffer_float"));return!(x!==Qt&&x!==_n&&!w&&n.convert(x)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_TYPE))}function l(x){if(x==="highp"){if(i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.HIGH_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.HIGH_FLOAT).precision>0)return"highp";x="mediump"}return x==="mediump"&&i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.MEDIUM_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let c=t.precision!==void 0?t.precision:"highp";const h=l(c);h!==c&&(Pe("WebGLRenderer:",c,"not supported, using",h,"instead."),c=h);const u=t.reversedDepthBuffer===!0&&e.has("EXT_clip_control"),d=t.logarithmicDepthBuffer===!0&&u===!1;t.reversedDepthBuffer===!0&&u===!1&&Pe("WebGLRenderer: Unable to use reversed depth buffer due to missing EXT_clip_control extension. Fallback to default depth buffer."),t.logarithmicDepthBuffer===!0&&u===!0&&Pe("WebGLRenderer: Logarithmic depth buffer is ignored when reversed depth buffer is enabled.");const p=i.getParameter(i.MAX_TEXTURE_IMAGE_UNITS),g=i.getParameter(i.MAX_VERTEX_TEXTURE_IMAGE_UNITS),v=i.getParameter(i.MAX_TEXTURE_SIZE),m=i.getParameter(i.MAX_CUBE_MAP_TEXTURE_SIZE),f=i.getParameter(i.MAX_VERTEX_ATTRIBS),_=i.getParameter(i.MAX_VERTEX_UNIFORM_VECTORS),S=i.getParameter(i.MAX_VARYING_VECTORS),y=i.getParameter(i.MAX_FRAGMENT_UNIFORM_VECTORS),A=i.getParameter(i.MAX_SAMPLES),E=i.getParameter(i.SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:s,getMaxPrecision:l,textureFormatReadable:a,textureTypeReadable:o,precision:c,logarithmicDepthBuffer:d,reversedDepthBuffer:u,maxTextures:p,maxVertexTextures:g,maxTextureSize:v,maxCubemapSize:m,maxAttributes:f,maxVertexUniforms:_,maxVaryings:S,maxFragmentUniforms:y,maxSamples:A,samples:E}}function Lg(i){const e=this;let t=null,n=0,r=!1,s=!1;const a=new Hn,o=new Ie,l={value:null,needsUpdate:!1};this.uniform=l,this.numPlanes=0,this.numIntersection=0,this.init=function(u,d){const p=u.length!==0||d||n!==0||r;return r=d,n=u.length,p},this.beginShadows=function(){s=!0,h(null)},this.endShadows=function(){s=!1},this.setGlobalState=function(u,d){t=h(u,d,0)},this.setState=function(u,d,p){const g=u.clippingPlanes,v=u.clipIntersection,m=u.clipShadows,f=i.get(u);if(!r||g===null||g.length===0||s&&!m)s?h(null):c();else{const _=s?0:n,S=_*4;let y=f.clippingState||null;l.value=y,y=h(g,d,S,p);for(let A=0;A!==S;++A)y[A]=t[A];f.clippingState=y,this.numIntersection=v?this.numPlanes:0,this.numPlanes+=_}};function c(){l.value!==t&&(l.value=t,l.needsUpdate=n>0),e.numPlanes=n,e.numIntersection=0}function h(u,d,p,g){const v=u!==null?u.length:0;let m=null;if(v!==0){if(m=l.value,g!==!0||m===null){const f=p+v*4,_=d.matrixWorldInverse;o.getNormalMatrix(_),(m===null||m.length<f)&&(m=new Float32Array(f));for(let S=0,y=p;S!==v;++S,y+=4)a.copy(u[S]).applyMatrix4(_,o),a.normal.toArray(m,y),m[y+3]=a.constant}l.value=m,l.needsUpdate=!0}return e.numPlanes=v,e.numIntersection=0,m}}class Il extends Mn{constructor(e=1,t={}){super(e,e,t),this.isWebGLCubeRenderTarget=!0;const n={width:e,height:e,depth:1},r=[n,n,n,n,n,n];this.texture=new Eu(r),this._setTextureOptions(t),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(e,t){this.texture.type=t.type,this.texture.colorSpace=t.colorSpace,this.texture.generateMipmaps=t.generateMipmaps,this.texture.minFilter=t.minFilter,this.texture.magFilter=t.magFilter;const n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},r=new Li(5,5,5),s=new Xn({name:"CubemapFromEquirect",uniforms:sr(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:qt,blending:Qi});s.uniforms.tEquirect.value=t;const a=new mt(r,s),o=t.minFilter;return t.minFilter===ii&&(t.minFilter=Yt),new Xo(1,10,this).update(e,a),t.minFilter=o,a.geometry.dispose(),a.material.dispose(),this}clear(e,t=!0,n=!0,r=!0){const s=e.getRenderTarget();for(let a=0;a<6;a++)e.setRenderTarget(this,a),e.clear(t,n,r);e.setRenderTarget(s)}}const Jc=256,Dg=3,Ig=20,Wu=256,qu=16,Ng=3,Ug=new P,Fg=new Te;class ra{constructor(e){this._renderer=e,this._cubeSize=0,this._sourceTarget=null,this._cubeCamera=new Xo(1,10,null),this._boxMesh=new mt(new Li(5,5,5),null),this._cubemapMaterial=null,this._equirectMaterial=null,this._blurMaterial=null,this._ggxMaterial=null,this._integrationMaterial=null}fromScene(e,t=0,n=.1,r=100,s={}){const{size:a=256,position:o=Ug}=s,l=this._renderer;this._setSize(a);const c=this._allocateTarget(),h=this._getSourceTarget(!0);t>0&&(h.texture.mipmapsAutoUpdate=!1);const u=l.autoClear,d=l.autoClearColor,p=l.autoClearDepth,g=l.autoClearStencil,v=e.background;l.autoClear=!0,l.autoClearColor=!0,l.autoClearDepth=!0,l.autoClearStencil=!0,v===null&&(e.background=l.getClearColor(Fg));const m=new Xo(n,r,h);return m.position.copy(o),m.update(l,e),l.autoClear=u,l.autoClearColor=d,l.autoClearDepth=p,l.autoClearStencil=g,e.background=v,t>0&&(h.texture.mipmapsAutoUpdate=!0,this._blur(c,t)),this._applyPMREM(c),c}fromEquirectangular(e,t=null){return this._fromTexture(e,t)}fromCubemap(e,t=null){return this._fromTexture(e,t)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=eh(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=jc(),this._compileMaterial(this._equirectMaterial))}dispose(){this._sourceTarget!==null&&this._sourceTarget.dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose(),this._blurMaterial!==null&&this._blurMaterial.dispose(),this._ggxMaterial!==null&&this._ggxMaterial.dispose(),this._integrationMaterial!==null&&this._integrationMaterial.dispose(),this._boxMesh.geometry.dispose()}static lodToRoughness(e,t){return t>0?1-Math.sqrt(1-e/t):0}_setSize(e){this._cubeSize=Math.max(Jc,pu(e))}_fromTexture(e,t){e.mapping===tr||e.mapping===Or?this._setSize(e.image.length===0?Jc:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4);const n=t||this._allocateTarget();return this._textureToCubemap(e),this._applyPMREM(n),n}_allocateTarget(){const e=this._cubeSize,t=Qc(e,!1,!1),n=Math.log2(e)-Dg;for(let r=0;r<=n;r++)t.texture.mipmaps.push({width:e>>r,height:e>>r});return t.texture.name="PMREM",t.texture.isPMREMTexture=!0,t}_getSourceTarget(e=!1){const t=this._cubeSize,n=this._sourceTarget;return(n===null||n.width!==t||e&&n.depthBuffer===!1)&&(n!==null&&n.dispose(),this._sourceTarget=Qc(t,!0,e)),this._sourceTarget}_compileMaterial(e){this._boxMesh.material=e,this._renderer.compile(this._boxMesh,this._cubeCamera.children[0])}_renderCube(e,t,n){const r=this._boxMesh,s=this._cubeCamera;r.material=n,s.renderTarget=e,s.activeMipmapLevel=t;const a=e.width>>t;e.viewport.set(0,0,a,a),s.update(this._renderer,r),e.viewport.set(0,0,e.width,e.height)}_textureToCubemap(e){let t;e.mapping===tr||e.mapping===Or?(this._cubemapMaterial===null&&(this._cubemapMaterial=eh()),t=this._cubemapMaterial,t.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):(this._equirectMaterial===null&&(this._equirectMaterial=jc()),t=this._equirectMaterial),t.uniforms.envMap.value=e,this._renderCube(this._getSourceTarget(),0,t)}_applyPMREM(e){this._ggxMaterial===null&&(this._ggxMaterial=Og(),this._integrationMaterial=Bg());const t=this._cubeSize,n=e.texture.mipmaps.length-1,r=this._ggxMaterial.uniforms;r.envMap.value=this._sourceTarget.texture;const s=this._integrationMaterial.uniforms;s.envMap.value=this._sourceTarget.texture,s.sourceLod.value=Math.log2(t/qu);for(let a=0;a<=n;a++){const o=ra.lodToRoughness(a,n);if(a>n-Ng)s.roughness.value=o,this._renderCube(e,a,this._integrationMaterial);else{const l=o>0?Math.log2(t)+.5*Math.log2(6/(Wu*Math.pow(o,4)))+.5:0;r.roughness.value=o,r.lodBias.value=l,this._renderCube(e,a,this._ggxMaterial)}}}_blur(e,t){this._blurMaterial===null&&(this._blurMaterial=kg());const n=this._blurMaterial,r=n.uniforms,s=this._sourceTarget;r.sigma.value=Math.min(t,Math.PI)/Math.SQRT2,r.envMap.value=s.texture,this._renderCube(e,0,n),r.envMap.value=e.texture,this._renderCube(s,0,n)}}function Qc(i,e,t){return new Il(i,{minFilter:ii,generateMipmaps:e,type:Ln,colorSpace:Js,depthBuffer:t})}function Yr(i,e,t){return new Xn({name:i,uniforms:e,vertexShader:ke.cube_vert,fragmentShader:t,side:qt,blending:Qi,depthTest:!1,depthWrite:!1})}function Og(){return Yr("PMREMGGXConvolution",{envMap:{value:null},roughness:{value:0},lodBias:{value:0}},`

		#define GGX_SAMPLES ${Wu}u

		varying vec3 vWorldDirection;

		uniform samplerCube envMap;
		uniform float roughness;
		uniform float lodBias;

		#include <common>

		// Van der Corput radical inverse
		float radicalInverse_VdC( uint bits ) {

			bits = ( bits << 16u ) | ( bits >> 16u );
			bits = ( ( bits & 0x55555555u ) << 1u ) | ( ( bits & 0xAAAAAAAAu ) >> 1u );
			bits = ( ( bits & 0x33333333u ) << 2u ) | ( ( bits & 0xCCCCCCCCu ) >> 2u );
			bits = ( ( bits & 0x0F0F0F0Fu ) << 4u ) | ( ( bits & 0xF0F0F0F0u ) >> 4u );
			bits = ( ( bits & 0x00FF00FFu ) << 8u ) | ( ( bits & 0xFF00FF00u ) >> 8u );
			return float( bits ) * 2.3283064365386963e-10; // / 0x100000000

		}

		// Hammersley sequence
		vec2 hammersley( uint i, uint N ) {

			return vec2( float( i ) / float( N ), radicalInverse_VdC( i ) );

		}

		void main() {

			vec3 N = normalize( vWorldDirection );

			// For very low roughness, just sample the environment directly
			if ( roughness < 0.001 ) {

				gl_FragColor = vec4( textureLod( envMap, N, 0.0 ).rgb, 1.0 );
				return;

			}

			float alpha = roughness * roughness;
			float alpha2 = alpha * alpha;

			// Tangent space basis for VNDF sampling
			vec3 up = abs( N.z ) < 0.999 ? vec3( 0.0, 0.0, 1.0 ) : vec3( 1.0, 0.0, 0.0 );
			vec3 tangent = normalize( cross( up, N ) );
			vec3 bitangent = cross( N, tangent );

			vec3 prefilteredColor = vec3( 0.0 );
			float totalWeight = 0.0;

			for ( uint i = 0u; i < GGX_SAMPLES; i ++ ) {

				vec2 Xi = hammersley( i, GGX_SAMPLES );

				// With V = N, sample the reflected direction directly.
				float invQ = 1.0 / ( 1.0 - Xi.x + alpha2 * Xi.x );
				float NdotL = ( 1.0 - Xi.x - alpha2 * Xi.x ) * invQ;

				if ( NdotL > 0.0 ) {

					float phi = 2.0 * PI * Xi.y;
					float sinTheta = 2.0 * alpha * sqrt( Xi.x * ( 1.0 - Xi.x ) ) * invQ;
					vec3 L = N * NdotL + ( tangent * cos( phi ) + bitangent * sin( phi ) ) * sinTheta;

					// Match the source mip to the sample's solid angle. The terms
					// independent of the sample are precomputed in lodBias.
					float d = alpha2 * invQ;
					float lod = max( log2( d ) + lodBias, 0.0 );

					// Weight by NdotL for the split-sum approximation
					prefilteredColor += textureLod( envMap, L, lod ).rgb * NdotL;
					totalWeight += NdotL;

				}

			}

			gl_FragColor = vec4( prefilteredColor / totalWeight, 1.0 );

		}
	`)}function Bg(){return Yr("PMREMGGXIntegration",{envMap:{value:null},roughness:{value:0},sourceLod:{value:0},sourceSize:{value:qu}},`

		varying vec3 vWorldDirection;

		uniform samplerCube envMap;
		uniform float roughness;
		uniform float sourceLod;
		uniform int sourceSize;

		void main() {

			vec3 N = normalize( vWorldDirection );

			float alpha = roughness * roughness;
			float alpha2 = alpha * alpha;

			float texelSize = 2.0 / float( sourceSize );

			vec3 prefilteredColor = vec3( 0.0 );
			float totalWeight = 0.0;

			// Pair opposite texels: only the one in N's hemisphere contributes.
			for ( int face = 0; face < 3; face ++ ) {

				for ( int y = 0; y < sourceSize; y ++ ) {

					for ( int x = 0; x < sourceSize; x ++ ) {

						vec2 uv = ( vec2( x, y ) + 0.5 ) * texelSize - 1.0;
						vec3 texelDirection = face == 0 ? vec3( 1.0, uv ) : ( face == 1 ? vec3( uv.x, 1.0, uv.y ) : vec3( uv, 1.0 ) );

						float invDistance = inversesqrt( 1.0 + dot( uv, uv ) );
						float NdotL = dot( N, texelDirection );
						texelDirection *= NdotL < 0.0 ? - 1.0 : 1.0;
						NdotL = abs( NdotL ) * invDistance;

						// With V = N, NdotH squared is ( 1 + NdotL ) / 2. Common factors
						// in the GGX distribution and texel solid angle cancel when normalized.
						float d = 1.0 + alpha2 + ( alpha2 - 1.0 ) * NdotL;
						float weight = NdotL * invDistance * invDistance * invDistance / ( d * d );

						prefilteredColor += textureLod( envMap, texelDirection, sourceLod ).rgb * weight;
						totalWeight += weight;

					}

				}

			}

			gl_FragColor = vec4( prefilteredColor / totalWeight, 1.0 );

		}
	`)}function kg(){return Yr("PMREMSphericalGaussianBlur",{envMap:{value:null},sigma:{value:0}},`

		#define SAMPLES ${Ig}
		#define GOLDEN_ANGLE 2.39996322973

		varying vec3 vWorldDirection;

		uniform samplerCube envMap;
		uniform float sigma;

		#include <common>

		void main() {

			vec3 outputDirection = normalize( vWorldDirection );

			vec3 up = abs( outputDirection.z ) < 0.999 ? vec3( 0.0, 0.0, 1.0 ) : vec3( 1.0, 0.0, 0.0 );
			vec3 tangent = normalize( cross( up, outputDirection ) );
			vec3 bitangent = cross( outputDirection, tangent );

			// Truncate the kernel at three standard deviations or at the antipode.
			float thetaMax = min( 3.0 * sigma, PI );
			float truncation = 1.0 - exp( - 0.5 * thetaMax * thetaMax / ( sigma * sigma ) );

			vec3 accumColor = vec3( 0.0 );
			float accumWeight = 0.0;

			for ( int i = 0; i < SAMPLES; i ++ ) {

				// Stratified inverse-CDF sampling of the Gaussian, placed on a golden-angle spiral.
				float stratum = ( float( i ) + 0.5 ) / float( SAMPLES );
				float theta = sigma * sqrt( - 2.0 * log( 1.0 - stratum * truncation ) );
				float phi = float( i ) * GOLDEN_ANGLE;

				vec3 offset = cos( phi ) * tangent + sin( phi ) * bitangent;
				vec3 sampleDirection = cos( theta ) * outputDirection + sin( theta ) * offset;

				// Correct the planar sample density to solid angle.
				float weight = sin( theta ) / theta;

				accumColor += weight * textureLod( envMap, sampleDirection, 0.0 ).rgb;
				accumWeight += weight;

			}

			gl_FragColor = vec4( accumColor / accumWeight, 1.0 );

		}
	`)}function jc(){return Yr("PMREMEquirectangularToCubemap",{envMap:{value:null}},`

		varying vec3 vWorldDirection;

		uniform sampler2D envMap;

		#include <common>

		void main() {

			// Average four subpixel samples to preserve small, bright features.
			vec3 direction = normalize( vWorldDirection );
			vec3 dx = dFdx( direction ) * 0.25;
			vec3 dy = dFdy( direction ) * 0.25;

			vec3 color = textureLod( envMap, equirectUv( normalize( direction - dx - dy ) ), 0.0 ).rgb;
			color += textureLod( envMap, equirectUv( normalize( direction + dx - dy ) ), 0.0 ).rgb;
			color += textureLod( envMap, equirectUv( normalize( direction - dx + dy ) ), 0.0 ).rgb;
			color += textureLod( envMap, equirectUv( normalize( direction + dx + dy ) ), 0.0 ).rgb;
			gl_FragColor = vec4( color * 0.25, 1.0 );

		}
	`)}function eh(){return Yr("PMREMCubemapToCubemap",{envMap:{value:null},flipEnvMap:{value:-1}},`

		varying vec3 vWorldDirection;

		uniform samplerCube envMap;
		uniform float flipEnvMap;

		void main() {

			gl_FragColor = vec4( textureCube( envMap, vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) ).rgb, 1.0 );

		}
	`)}function zg(i){let e=new WeakMap,t=new WeakMap,n=null;function r(d,p=!1){return d==null?null:p?a(d):s(d)}function s(d){if(d&&d.isTexture){const p=d.mapping;if(p===va||p===xa)if(e.has(d)){const g=e.get(d).texture;return o(g,d.mapping)}else{const g=d.image;if(g&&g.height>0){const v=new Il(g.height);return v.fromEquirectangularTexture(i,d),e.set(d,v),d.addEventListener("dispose",c),o(v.texture,d.mapping)}else return null}}return d}function a(d){if(d&&d.isTexture&&d.isPMREMTexture!==!0){const p=d.mapping,g=p===va||p===xa,v=p===tr||p===Or;if(g||v){let m=t.get(d);const f=m!==void 0?m.texture.pmremVersion:0;if(d.isRenderTargetTexture&&d.pmremVersion!==f)return n===null&&(n=new ra(i)),m=g?n.fromEquirectangular(d,m):n.fromCubemap(d,m),m.texture.pmremVersion=d.pmremVersion,t.set(d,m),m.texture;if(m!==void 0)return m.texture;{const _=d.image;return g&&_&&_.height>0||v&&_&&l(_)?(n===null&&(n=new ra(i)),m=g?n.fromEquirectangular(d):n.fromCubemap(d),m.texture.pmremVersion=d.pmremVersion,t.set(d,m),d.addEventListener("dispose",h),m.texture):null}}}return d}function o(d,p){return p===va?d.mapping=tr:p===xa&&(d.mapping=Or),d}function l(d){let p=0;const g=6;for(let v=0;v<g;v++)d[v]!==void 0&&p++;return p===g}function c(d){const p=d.target;p.removeEventListener("dispose",c);const g=e.get(p);g!==void 0&&(e.delete(p),g.dispose())}function h(d){const p=d.target;p.removeEventListener("dispose",h);const g=t.get(p);g!==void 0&&(t.delete(p),g.dispose())}function u(){e=new WeakMap,t=new WeakMap,n!==null&&(n.dispose(),n=null)}return{get:r,dispose:u}}function Gg(i){const e={};function t(n){if(e[n]!==void 0)return e[n];const r=i.getExtension(n);return e[n]=r,r}return{has:function(n){return t(n)!==null},init:function(){t("EXT_color_buffer_float"),t("WEBGL_clip_cull_distance"),t("OES_texture_float_linear"),t("EXT_color_buffer_half_float"),t("WEBGL_multisampled_render_to_texture"),t("WEBGL_render_shared_exponent")},get:function(n){const r=t(n);return r===null&&Hs("WebGLRenderer: "+n+" extension not supported."),r}}}function Hg(i,e,t,n){const r={},s=new WeakMap,a=new FinalizationRegistry(g=>delete r[g]);function o(g){l(g.target)}function l(g){g.index!==null&&e.remove(g.index);for(const m in g.attributes)e.remove(g.attributes[m]);g.removeEventListener("dispose",o),delete r[g.id],a.unregister(g);const v=s.get(g);v&&(e.remove(v),s.delete(g)),n.releaseStatesOfGeometry(g),g.isInstancedBufferGeometry===!0&&delete g._maxInstanceCount,t.memory.geometries--}function c(g,v){return r[v.id]!==void 0||(v.addEventListener("dispose",o),r[v.id]=new WeakRef(v),a.register(v,v.id,v),t.memory.geometries++),v}function h(g){const v=g.attributes;for(const m in v)e.update(v[m],i.ARRAY_BUFFER)}function u(g){const v=g.index,m=g.attributes.position;let f=0;if(m===void 0)return;const _=v!==null?v.array.length:m.array.length/3-1,S=m.count>=65535?_u:xu,y=new S(Math.ceil(_/3)*6,1),A=y.array;if(v!==null){const x=v.array;f=v.version;for(let w=0,I=0;w<_;w+=3){const C=x[w+0],N=x[w+1],F=x[w+2];A[I++]=C,A[I++]=N,A[I++]=N,A[I++]=F,A[I++]=F,A[I++]=C}}else{f=m.version;for(let x=0,w=0;x<_;x+=3){const I=x+0,C=x+1,N=x+2;A[w++]=I,A[w++]=C,A[w++]=C,A[w++]=N,A[w++]=N,A[w++]=I}}y.version=f;const E=s.get(g);E&&e.remove(E),s.set(g,y)}function d(g){const v=s.get(g);if(v){const m=g.index;m!==null&&v.version<m.version&&u(g)}else u(g);return s.get(g)}function p(){for(const g in r){const v=r[g].deref();v!==void 0&&l(v)}}return{get:c,update:h,getWireframeAttribute:d,dispose:p}}function Vg(i,e,t){let n;function r(u){n=u}let s,a;function o(u){s=u.type,a=u.bytesPerElement}function l(u,d){i.drawElements(n,d,s,u*a),t.update(d,n,1)}function c(u,d,p){p!==0&&(i.drawElementsInstanced(n,d,s,u*a,p),t.update(d,n,p))}function h(u,d,p){if(p===0)return;e.get("WEBGL_multi_draw").multiDrawElementsWEBGL(n,d,0,s,u,0,p);let v=0;for(let m=0;m<p;m++)v+=d[m];t.update(v,n,1)}this.setMode=r,this.setIndex=o,this.render=l,this.renderInstances=c,this.renderMultiDraw=h}function Wg(i){const e={geometries:0,textures:0},t={frame:0,calls:0,triangles:0,points:0,lines:0};function n(s,a,o){switch(t.calls++,a){case i.TRIANGLES:t.triangles+=o*(s/3);break;case i.LINES:t.lines+=o*(s/2);break;case i.LINE_STRIP:t.lines+=o*(s-1);break;case i.LINE_LOOP:t.lines+=o*s;break;case i.POINTS:t.points+=o*s;break;default:$e("WebGLInfo: Unknown draw mode:",a);break}}function r(){t.calls=0,t.triangles=0,t.points=0,t.lines=0}return{memory:e,render:t,programs:null,autoReset:!0,reset:r,update:n}}function qg(i,e,t){const n=new WeakMap,r=new dt;function s(a,o,l){const c=a.morphTargetInfluences,h=o.morphAttributes.position||o.morphAttributes.normal||o.morphAttributes.color,u=h!==void 0?h.length:0;let d=n.get(o);if(d===void 0||d.count!==u){let C=function(){w.dispose(),n.delete(o),o.removeEventListener("dispose",C)};var p=C;d!==void 0&&d.texture.dispose();const g=o.morphAttributes.position!==void 0,v=o.morphAttributes.normal!==void 0,m=o.morphAttributes.color!==void 0,f=o.morphAttributes.position||[],_=o.morphAttributes.normal||[],S=o.morphAttributes.color||[];let y=0;g===!0&&(y=1),v===!0&&(y=2),m===!0&&(y=3);let A=o.attributes.position.count*y,E=1;A>e.maxTextureSize&&(E=Math.ceil(A/e.maxTextureSize),A=e.maxTextureSize);const x=new Float32Array(A*E*4*u),w=new mu(x,A,E,u);w.type=_n,w.needsUpdate=!0;const I=y*4;for(let N=0;N<u;N++){const F=f[N],V=_[N],D=S[N],H=A*E*4*N;for(let Z=0;Z<F.count;Z++){const z=Z*I;g===!0&&(r.fromBufferAttribute(F,Z),x[H+z+0]=r.x,x[H+z+1]=r.y,x[H+z+2]=r.z,x[H+z+3]=0),v===!0&&(r.fromBufferAttribute(V,Z),x[H+z+4]=r.x,x[H+z+5]=r.y,x[H+z+6]=r.z,x[H+z+7]=0),m===!0&&(r.fromBufferAttribute(D,Z),x[H+z+8]=r.x,x[H+z+9]=r.y,x[H+z+10]=r.z,x[H+z+11]=D.itemSize===4?r.w:1)}}d={count:u,texture:w,size:new de(A,E)},n.set(o,d),o.addEventListener("dispose",C)}if(a.isInstancedMesh===!0&&a.morphTexture!==null)l.getUniforms().setValue(i,"morphTexture",a.morphTexture,t);else{let g=0;for(let m=0;m<c.length;m++)g+=c[m];const v=o.morphTargetsRelative?1:1-g;l.getUniforms().setValue(i,"morphTargetBaseInfluence",v),l.getUniforms().setValue(i,"morphTargetInfluences",c)}l.getUniforms().setValue(i,"morphTargetsTexture",d.texture,t),l.getUniforms().setValue(i,"morphTargetsTextureSize",d.size)}return{update:s}}function Xg(i,e,t,n,r){let s=new WeakMap;function a(c){const h=r.render.frame,u=c.geometry,d=e.get(c,u);if(s.get(d)!==h&&(e.update(d),s.set(d,h)),c.isInstancedMesh&&(c.hasEventListener("dispose",l)===!1&&c.addEventListener("dispose",l),s.get(c)!==h&&(t.update(c.instanceMatrix,i.ARRAY_BUFFER),c.instanceColor!==null&&t.update(c.instanceColor,i.ARRAY_BUFFER),s.set(c,h))),c.isSkinnedMesh){const p=c.skeleton;s.get(p)!==h&&(p.update(),s.set(p,h))}return d}function o(){s=new WeakMap}function l(c){const h=c.target;h.removeEventListener("dispose",l),n.releaseStatesOfObject(h),t.remove(h.instanceMatrix),h.instanceColor!==null&&t.remove(h.instanceColor)}return{update:a,dispose:o}}const $g={[Zh]:"LINEAR_TONE_MAPPING",[Jh]:"REINHARD_TONE_MAPPING",[Qh]:"CINEON_TONE_MAPPING",[hl]:"ACES_FILMIC_TONE_MAPPING",[eu]:"AGX_TONE_MAPPING",[tu]:"NEUTRAL_TONE_MAPPING",[jh]:"CUSTOM_TONE_MAPPING"};function Yg(i,e,t,n,r,s){const a=new Mn(e,t,{type:i,depthBuffer:r,stencilBuffer:s,samples:n?4:0,storeMultisampledDepthBuffer:!1,storeMultisampledStencilBuffer:!1,resolveDepthBuffer:!1,resolveStencilBuffer:!1});let o=null,l=null,c=null;const h=new gt;h.setAttribute("position",new We([-1,3,0,-1,-1,0,3,-1,0],3)),h.setAttribute("uv",new We([0,2,0,0,2,0],2));const u=new Op({uniforms:{tDiffuse:{value:null}},vertexShader:`
			precision highp float;

			uniform mat4 modelViewMatrix;
			uniform mat4 projectionMatrix;

			attribute vec3 position;
			attribute vec2 uv;

			varying vec2 vUv;

			void main() {
				vUv = uv;
				gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
			}`,fragmentShader:`
			precision highp float;

			uniform sampler2D tDiffuse;

			varying vec2 vUv;

			#include <tonemapping_pars_fragment>
			#include <colorspace_pars_fragment>

			void main() {
				gl_FragColor = texture2D( tDiffuse, vUv );

				#ifdef LINEAR_TONE_MAPPING
					gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );
				#elif defined( REINHARD_TONE_MAPPING )
					gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );
				#elif defined( CINEON_TONE_MAPPING )
					gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );
				#elif defined( ACES_FILMIC_TONE_MAPPING )
					gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );
				#elif defined( AGX_TONE_MAPPING )
					gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );
				#elif defined( NEUTRAL_TONE_MAPPING )
					gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );
				#elif defined( CUSTOM_TONE_MAPPING )
					gl_FragColor.rgb = CustomToneMapping( gl_FragColor.rgb );
				#endif

				#ifdef SRGB_TRANSFER
					gl_FragColor = sRGBTransferOETF( gl_FragColor );
				#endif
			}`,depthTest:!1,depthWrite:!1}),d=new mt(h,u),p=new Gu(-1,1,1,-1,0,1);let g=null,v=null,m=!1,f,_=null,S=[],y=!1;this.setSize=function(A,E){a.setSize(A,E),o!==null&&o.setSize(A,E),l!==null&&l.setSize(A,E);for(let x=0;x<S.length;x++){const w=S[x];w.setSize&&w.setSize(A,E)}},this.setEffects=function(A){S=A,y=S.length>0&&S[0].isRenderPass===!0;const E=a.width,x=a.height;S.length>0&&o===null&&(o=new Mn(E,x,{type:Ln,depthBuffer:!1,stencilBuffer:!1}),l=new Mn(E,x,{type:Ln,depthBuffer:!1,stencilBuffer:!1}));const w=r===!0&&S.some(I=>I.needsDepthTexture===!0);w!==(a.depthTexture!==null)&&(w===!0&&c===null&&(c=new ir(E,x),s===!0&&(c.format=ri,c.type=nr)),a.dispose(),a.depthTexture=w?c:null,a.resolveDepthBuffer=w,a.storeMultisampledDepthBuffer=w);for(let I=0;I<S.length;I++){const C=S[I];C.setSize&&C.setSize(E,x),w&&C.needsDepthTexture===!0&&C.setDepthTexture&&C.setDepthTexture(c)}},this.begin=function(A,E){if(m||A.toneMapping===Wn&&S.length===0)return!1;if(_=E,E!==null){const x=E.width,w=E.height;(a.width!==x||a.height!==w)&&this.setSize(x,w)}return y===!1&&A.setRenderTarget(a),f=A.toneMapping,A.toneMapping=Wn,!0},this.hasRenderPass=function(){return y},this.end=function(A,E){A.toneMapping=f,m=!0;let x=a,w=o;for(let I=0;I<S.length;I++){const C=S[I];C.enabled!==!1&&(C.render(A,w,x,E),C.needsSwap!==!1&&(x=w,w=w===o?l:o))}if(g!==A.outputColorSpace||v!==A.toneMapping){g=A.outputColorSpace,v=A.toneMapping,u.defines={},qe.getTransfer(g)===et&&(u.defines.SRGB_TRANSFER="");const I=$g[v];I&&(u.defines[I]=""),u.needsUpdate=!0}u.uniforms.tDiffuse.value=x.texture,A.setRenderTarget(_),A.render(d,p),_=null,m=!1},this.isCompositing=function(){return m},this.dispose=function(){a.dispose(),o!==null&&o.dispose(),l!==null&&l.dispose(),h.dispose(),u.dispose()}}const Xu=new kt,$u=new ir(1,1),Yu=new Au(1),Ku=new mu,Zu=new Df,Ju=new Eu,th=[],nh=[],ih=new Float32Array(16),rh=new Float32Array(9),sh=new Float32Array(4);function lr(i,e,t){const n=i[0];if(n<=0||n>0)return i;const r=e*t;let s=th[r];if(s===void 0&&(s=new Float32Array(r),th[r]=s),e!==0){n.toArray(s,0);for(let a=1,o=0;a!==e;++a)o+=t,i[a].toArray(s,o)}return s}function wt(i,e){if(i.length!==e.length)return!1;for(let t=0,n=i.length;t<n;t++)if(i[t]!==e[t])return!1;return!0}function Et(i,e){for(let t=0,n=e.length;t<n;t++)i[t]=e[t]}function ua(i,e){let t=nh[e];t===void 0&&(t=new Int32Array(e),nh[e]=t);for(let n=0;n!==e;++n)t[n]=i.allocateTextureUnit();return t}function Kg(i,e){const t=this.cache;t[0]!==e&&(i.uniform1f(this.addr,e),t[0]=e)}function Zg(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2f(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(wt(t,e))return;i.uniform2fv(this.addr,e),Et(t,e)}}function Jg(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3f(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else if(e.r!==void 0)(t[0]!==e.r||t[1]!==e.g||t[2]!==e.b)&&(i.uniform3f(this.addr,e.r,e.g,e.b),t[0]=e.r,t[1]=e.g,t[2]=e.b);else{if(wt(t,e))return;i.uniform3fv(this.addr,e),Et(t,e)}}function Qg(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4f(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(wt(t,e))return;i.uniform4fv(this.addr,e),Et(t,e)}}function jg(i,e){const t=this.cache,n=e.elements;if(n===void 0){if(wt(t,e))return;i.uniformMatrix2fv(this.addr,!1,e),Et(t,e)}else{if(wt(t,n))return;sh.set(n),i.uniformMatrix2fv(this.addr,!1,sh),Et(t,n)}}function ev(i,e){const t=this.cache,n=e.elements;if(n===void 0){if(wt(t,e))return;i.uniformMatrix3fv(this.addr,!1,e),Et(t,e)}else{if(wt(t,n))return;rh.set(n),i.uniformMatrix3fv(this.addr,!1,rh),Et(t,n)}}function tv(i,e){const t=this.cache,n=e.elements;if(n===void 0){if(wt(t,e))return;i.uniformMatrix4fv(this.addr,!1,e),Et(t,e)}else{if(wt(t,n))return;ih.set(n),i.uniformMatrix4fv(this.addr,!1,ih),Et(t,n)}}function nv(i,e){const t=this.cache;t[0]!==e&&(i.uniform1i(this.addr,e),t[0]=e)}function iv(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2i(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(wt(t,e))return;i.uniform2iv(this.addr,e),Et(t,e)}}function rv(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3i(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(wt(t,e))return;i.uniform3iv(this.addr,e),Et(t,e)}}function sv(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4i(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(wt(t,e))return;i.uniform4iv(this.addr,e),Et(t,e)}}function av(i,e){const t=this.cache;t[0]!==e&&(i.uniform1ui(this.addr,e),t[0]=e)}function ov(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2ui(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(wt(t,e))return;i.uniform2uiv(this.addr,e),Et(t,e)}}function lv(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3ui(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(wt(t,e))return;i.uniform3uiv(this.addr,e),Et(t,e)}}function cv(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4ui(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(wt(t,e))return;i.uniform4uiv(this.addr,e),Et(t,e)}}function da(i){return i.version===0&&(i.compareFunction=uu,i.needsUpdate=!0),i}function hv(i,e,t){const n=this.cache,r=t.allocateTextureUnit();n[0]!==r&&(i.uniform1i(this.addr,r),n[0]=r);let s;this.type===i.SAMPLER_2D_SHADOW?s=da($u):s=Xu,t.setTexture2D(e||s,r)}function uv(i,e,t){const n=this.cache,r=t.allocateTextureUnit();n[0]!==r&&(i.uniform1i(this.addr,r),n[0]=r),t.setTexture3D(e||Zu,r)}function dv(i,e,t){const n=this.cache,r=t.allocateTextureUnit();n[0]!==r&&(i.uniform1i(this.addr,r),n[0]=r);let s;this.type===i.SAMPLER_CUBE_SHADOW?s=da(Yu):s=Ju,t.setTextureCube(e||s,r)}function fv(i,e,t){const n=this.cache,r=t.allocateTextureUnit();n[0]!==r&&(i.uniform1i(this.addr,r),n[0]=r),t.setTexture2DArray(e||Ku,r)}function pv(i){switch(i){case 5126:return Kg;case 35664:return Zg;case 35665:return Jg;case 35666:return Qg;case 35674:return jg;case 35675:return ev;case 35676:return tv;case 5124:case 35670:return nv;case 35667:case 35671:return iv;case 35668:case 35672:return rv;case 35669:case 35673:return sv;case 5125:return av;case 36294:return ov;case 36295:return lv;case 36296:return cv;case 35678:case 36198:case 36298:case 36306:case 35682:return hv;case 35679:case 36299:case 36307:return uv;case 35680:case 36300:case 36308:case 36293:return dv;case 36289:case 36303:case 36311:case 36292:return fv}}function mv(i,e){i.uniform1fv(this.addr,e)}function gv(i,e){const t=lr(e,this.size,2);i.uniform2fv(this.addr,t)}function vv(i,e){const t=lr(e,this.size,3);i.uniform3fv(this.addr,t)}function xv(i,e){const t=lr(e,this.size,4);i.uniform4fv(this.addr,t)}function _v(i,e){const t=lr(e,this.size,4);i.uniformMatrix2fv(this.addr,!1,t)}function yv(i,e){const t=lr(e,this.size,9);i.uniformMatrix3fv(this.addr,!1,t)}function Mv(i,e){const t=lr(e,this.size,16);i.uniformMatrix4fv(this.addr,!1,t)}function bv(i,e){i.uniform1iv(this.addr,e)}function Sv(i,e){i.uniform2iv(this.addr,e)}function wv(i,e){i.uniform3iv(this.addr,e)}function Ev(i,e){i.uniform4iv(this.addr,e)}function Tv(i,e){i.uniform1uiv(this.addr,e)}function Av(i,e){i.uniform2uiv(this.addr,e)}function Rv(i,e){i.uniform3uiv(this.addr,e)}function Cv(i,e){i.uniform4uiv(this.addr,e)}function Pv(i,e,t){const n=this.cache,r=e.length,s=ua(t,r);wt(n,s)||(i.uniform1iv(this.addr,s),Et(n,s));let a;this.type===i.SAMPLER_2D_SHADOW?a=da($u):a=Xu;for(let o=0;o!==r;++o)t.setTexture2D(e[o]||a,s[o])}function Lv(i,e,t){const n=this.cache,r=e.length,s=ua(t,r);wt(n,s)||(i.uniform1iv(this.addr,s),Et(n,s));for(let a=0;a!==r;++a)t.setTexture3D(e[a]||Zu,s[a])}function Dv(i,e,t){const n=this.cache,r=e.length,s=ua(t,r);wt(n,s)||(i.uniform1iv(this.addr,s),Et(n,s));let a;this.type===i.SAMPLER_CUBE_SHADOW?a=da(Yu):a=Ju;for(let o=0;o!==r;++o)t.setTextureCube(e[o]||a,s[o])}function Iv(i,e,t){const n=this.cache,r=e.length,s=ua(t,r);wt(n,s)||(i.uniform1iv(this.addr,s),Et(n,s));for(let a=0;a!==r;++a)t.setTexture2DArray(e[a]||Ku,s[a])}function Nv(i){switch(i){case 5126:return mv;case 35664:return gv;case 35665:return vv;case 35666:return xv;case 35674:return _v;case 35675:return yv;case 35676:return Mv;case 5124:case 35670:return bv;case 35667:case 35671:return Sv;case 35668:case 35672:return wv;case 35669:case 35673:return Ev;case 5125:return Tv;case 36294:return Av;case 36295:return Rv;case 36296:return Cv;case 35678:case 36198:case 36298:case 36306:case 35682:return Pv;case 35679:case 36299:case 36307:return Lv;case 35680:case 36300:case 36308:case 36293:return Dv;case 36289:case 36303:case 36311:case 36292:return Iv}}class Uv{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.setValue=pv(t.type)}}class Fv{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.size=t.size,this.setValue=Nv(t.type)}}class Ov{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,t,n){const r=this.seq;for(let s=0,a=r.length;s!==a;++s){const o=r[s];o.setValue(e,t[o.id],n)}}}const $a=/(\w+)(\])?(\[|\.)?/g;function ah(i,e){i.seq.push(e),i.map[e.id]=e}function Bv(i,e,t){const n=i.name,r=n.length;for($a.lastIndex=0;;){const s=$a.exec(n),a=$a.lastIndex;let o=s[1];const l=s[2]==="]",c=s[3];if(l&&(o=o|0),c===void 0||c==="["&&a+2===r){ah(t,c===void 0?new Uv(o,i,e):new Fv(o,i,e));break}else{let u=t.map[o];u===void 0&&(u=new Ov(o),ah(t,u)),t=u}}}class Vs{constructor(e,t){this.seq=[],this.map={};const n=e.getProgramParameter(t,e.ACTIVE_UNIFORMS);for(let a=0;a<n;++a){const o=e.getActiveUniform(t,a),l=e.getUniformLocation(t,o.name);Bv(o,l,this)}const r=[],s=[];for(const a of this.seq)a.type===e.SAMPLER_2D_SHADOW||a.type===e.SAMPLER_CUBE_SHADOW||a.type===e.SAMPLER_2D_ARRAY_SHADOW?r.push(a):s.push(a);r.length>0&&(this.seq=r.concat(s))}setValue(e,t,n,r){const s=this.map[t];s!==void 0&&s.setValue(e,n,r)}setOptional(e,t,n){const r=t[n];r!==void 0&&this.setValue(e,n,r)}static upload(e,t,n,r){for(let s=0,a=t.length;s!==a;++s){const o=t[s],l=n[o.id];l.needsUpdate!==!1&&o.setValue(e,l.value,r)}}static seqWithValue(e,t){const n=[];for(let r=0,s=e.length;r!==s;++r){const a=e[r];a.id in t&&n.push(a)}return n}}function oh(i,e,t){const n=i.createShader(e);return i.shaderSource(n,t),i.compileShader(n),n}const kv=37297;let zv=0;function Gv(i,e){const t=i.split(`
`),n=[],r=Math.max(e-6,0),s=Math.min(e+6,t.length);for(let a=r;a<s;a++){const o=a+1;n.push(`${o===e?">":" "} ${o}: ${t[a]}`)}return n.join(`
`)}const lh=new Ie;function Hv(i){qe._getMatrix(lh,qe.workingColorSpace,i);const e=`mat3( ${lh.elements.map(t=>t.toFixed(4))} )`;switch(qe.getTransfer(i)){case Qs:return[e,"LinearTransferOETF"];case et:return[e,"sRGBTransferOETF"];default:return Pe("WebGLProgram: Unsupported color space: ",i),[e,"LinearTransferOETF"]}}function ch(i,e,t){const n=i.getShaderParameter(e,i.COMPILE_STATUS),s=(i.getShaderInfoLog(e)||"").trim();if(n&&s==="")return"";const a=/ERROR: 0:(\d+)/.exec(s);if(a){const o=parseInt(a[1]);return t.toUpperCase()+`

`+s+`

`+Gv(i.getShaderSource(e),o)}else return s}function Vv(i,e){const t=Hv(e);return[`vec4 ${i}( vec4 value ) {`,`	return ${t[1]}( vec4( ${t[0]} * value.rgb, value.a ) );`,"}"].join(`
`)}const Wv={[Zh]:"Linear",[Jh]:"Reinhard",[Qh]:"Cineon",[hl]:"ACESFilmic",[eu]:"AgX",[tu]:"Neutral",[jh]:"Custom"};function qv(i,e){const t=Wv[e];return t===void 0?(Pe("WebGLProgram: Unsupported toneMapping:",e),"vec3 "+i+"( vec3 color ) { return LinearToneMapping( color ); }"):"vec3 "+i+"( vec3 color ) { return "+t+"ToneMapping( color ); }"}const Ls=new P;function Xv(){qe.getLuminanceCoefficients(Ls);const i=Ls.x.toFixed(4),e=Ls.y.toFixed(4),t=Ls.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${i}, ${e}, ${t} );`,"	return dot( weights, rgb );","}"].join(`
`)}function $v(i){return[i.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",i.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(wr).join(`
`)}function Yv(i){const e=[];for(const t in i){const n=i[t];n!==!1&&e.push("#define "+t+" "+n)}return e.join(`
`)}function Kv(i,e){const t={},n=i.getProgramParameter(e,i.ACTIVE_ATTRIBUTES);for(let r=0;r<n;r++){const s=i.getActiveAttrib(e,r),a=s.name;let o=1;s.type===i.FLOAT_MAT2&&(o=2),s.type===i.FLOAT_MAT3&&(o=3),s.type===i.FLOAT_MAT4&&(o=4),t[a]={type:s.type,location:i.getAttribLocation(e,a),locationSize:o}}return t}function wr(i){return i!==""}function hh(i,e){const t=e.numSpotLightShadows+e.numSpotLightMaps-e.numSpotLightShadowsWithMaps;return i.replace(/NUM_SUN_LIGHTS/g,e.numSunLights).replace(/NUM_DIR_LIGHTS/g,e.numDirLights).replace(/NUM_SPOT_LIGHTS/g,e.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,e.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,t).replace(/NUM_RECT_AREA_LIGHTS/g,e.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,e.numPointLights).replace(/NUM_HEMI_LIGHTS/g,e.numHemiLights).replace(/NUM_SUN_LIGHT_SHADOWS/g,e.numSunLightShadows).replace(/NUM_DIR_LIGHT_SHADOWS/g,e.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,e.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,e.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,e.numPointLightShadows).replace(/NUM_LIGHT_PROBE_GRIDS/g,e.numLightProbeGrids)}function uh(i,e){return i.replace(/NUM_CLIPPING_PLANES/g,e.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,e.numClippingPlanes-e.numClipIntersection)}const Zv=/^[ \t]*#include +<([\w\d./]+)>/gm;function Yo(i){return i.replace(Zv,Jv)}function Jv(i,e){const t=ke[e];if(t===void 0)throw new Error("THREE.WebGLProgram: Can not resolve #include <"+e+">");return Yo(t)}const Qv=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function dh(i){return i.replace(Qv,jv)}function jv(i,e,t,n){let r="";for(let s=parseInt(e);s<parseInt(t);s++)r+=n.replace(/\[\s*i\s*\]/g,"[ "+s+" ]").replace(/UNROLLED_LOOP_INDEX/g,s);return r}function fh(i){let e=`precision ${i.precision} float;
	precision ${i.precision} int;
	precision ${i.precision} sampler2D;
	precision ${i.precision} samplerCube;
	precision ${i.precision} sampler3D;
	precision ${i.precision} sampler2DArray;
	precision ${i.precision} sampler2DShadow;
	precision ${i.precision} samplerCubeShadow;
	precision ${i.precision} sampler2DArrayShadow;
	precision ${i.precision} isampler2D;
	precision ${i.precision} isampler3D;
	precision ${i.precision} isamplerCube;
	precision ${i.precision} isampler2DArray;
	precision ${i.precision} usampler2D;
	precision ${i.precision} usampler3D;
	precision ${i.precision} usamplerCube;
	precision ${i.precision} usampler2DArray;
	`;return i.precision==="highp"?e+=`
#define HIGH_PRECISION`:i.precision==="mediump"?e+=`
#define MEDIUM_PRECISION`:i.precision==="lowp"&&(e+=`
#define LOW_PRECISION`),e}const ex={[Os]:"SHADOWMAP_TYPE_PCF",[br]:"SHADOWMAP_TYPE_VSM"};function tx(i){return ex[i.shadowMapType]||"SHADOWMAP_TYPE_BASIC"}const nx={[Or]:"ENVMAP_MODE_REFRACTION"};function ix(i){return i.envMap===!1?"ENVMAP_MODE_REFLECTION":nx[i.envMapMode]||"ENVMAP_MODE_REFLECTION"}const rx={[Kh]:"ENVMAP_BLENDING_MULTIPLY",[Zd]:"ENVMAP_BLENDING_MIX",[Jd]:"ENVMAP_BLENDING_ADD"};function sx(i){return i.envMap===!1?"ENVMAP_BLENDING_NONE":rx[i.combine]||"ENVMAP_BLENDING_NONE"}function ax(i,e,t,n){const r=i.getContext(),s=t.defines;let a=t.vertexShader,o=t.fragmentShader;const l=tx(t),c=t.envMapPMREM===!0?"ENVMAP_TYPE_PMREM":"ENVMAP_TYPE_CUBE",h=ix(t),u=sx(t),d=$v(t),p=Yv(s),g=r.createProgram();let v,m,f=t.glslVersion?"#version "+t.glslVersion+`
`:"";t.isRawShaderMaterial?(v=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,p].filter(wr).join(`
`),v.length>0&&(v+=`
`),m=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,p].filter(wr).join(`
`),m.length>0&&(m+=`
`)):(v=[fh(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,p,t.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",t.batching?"#define USE_BATCHING":"",t.batchingColor?"#define USE_BATCHING_COLOR":"",t.instancing?"#define USE_INSTANCING":"",t.instancingColor?"#define USE_INSTANCING_COLOR":"",t.instancingMorph?"#define USE_INSTANCING_MORPH":"",t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+h:"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.displacementMap?"#define USE_DISPLACEMENTMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.diffuseRoughnessMap?"#define USE_DIFFUSE_ROUGHNESSMAP":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.mapUv?"#define MAP_UV "+t.mapUv:"",t.alphaMapUv?"#define ALPHAMAP_UV "+t.alphaMapUv:"",t.lightMapUv?"#define LIGHTMAP_UV "+t.lightMapUv:"",t.aoMapUv?"#define AOMAP_UV "+t.aoMapUv:"",t.emissiveMapUv?"#define EMISSIVEMAP_UV "+t.emissiveMapUv:"",t.bumpMapUv?"#define BUMPMAP_UV "+t.bumpMapUv:"",t.normalMapUv?"#define NORMALMAP_UV "+t.normalMapUv:"",t.displacementMapUv?"#define DISPLACEMENTMAP_UV "+t.displacementMapUv:"",t.metalnessMapUv?"#define METALNESSMAP_UV "+t.metalnessMapUv:"",t.roughnessMapUv?"#define ROUGHNESSMAP_UV "+t.roughnessMapUv:"",t.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+t.anisotropyMapUv:"",t.clearcoatMapUv?"#define CLEARCOATMAP_UV "+t.clearcoatMapUv:"",t.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+t.clearcoatNormalMapUv:"",t.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+t.clearcoatRoughnessMapUv:"",t.diffuseRoughnessMapUv?"#define DIFFUSE_ROUGHNESSMAP_UV "+t.diffuseRoughnessMapUv:"",t.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+t.iridescenceMapUv:"",t.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+t.iridescenceThicknessMapUv:"",t.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+t.sheenColorMapUv:"",t.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+t.sheenRoughnessMapUv:"",t.specularMapUv?"#define SPECULARMAP_UV "+t.specularMapUv:"",t.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+t.specularColorMapUv:"",t.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+t.specularIntensityMapUv:"",t.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+t.transmissionMapUv:"",t.thicknessMapUv?"#define THICKNESSMAP_UV "+t.thicknessMapUv:"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexNormals?"#define HAS_NORMAL":"",t.vertexColors?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.flatShading?"#define FLAT_SHADED":"",t.skinning?"#define USE_SKINNING":"",t.morphTargets?"#define USE_MORPHTARGETS":"",t.morphNormals&&t.flatShading===!1?"#define USE_MORPHNORMALS":"",t.morphColors?"#define USE_MORPHCOLORS":"",t.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+t.morphTextureStride:"",t.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+t.morphTargetsCount:"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+l:"",t.sizeAttenuation?"#define USE_SIZEATTENUATION":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",t.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(wr).join(`
`),m=[fh(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,p,t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",t.map?"#define USE_MAP":"",t.matcap?"#define USE_MATCAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+c:"",t.envMap?"#define "+h:"",t.envMap?"#define "+u:"",t.envMapPMREM?"#define ENVMAP_MAX_LOD "+t.envMapMaxLod+".0":"",t.envMapPMREM?"#define ENVMAP_SIZE "+t.envMapSize+".0":"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.packedNormalMap?"#define USE_PACKED_NORMALMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoat?"#define USE_CLEARCOAT":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.diffuseRoughness?"#define USE_DIFFUSE_ROUGHNESS":"",t.diffuseRoughnessMap?"#define USE_DIFFUSE_ROUGHNESSMAP":"",t.dispersion?"#define USE_DISPERSION":"",t.retroreflection?"#define USE_RETROREFLECTION":"",t.iridescence?"#define USE_IRIDESCENCE":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaTest?"#define USE_ALPHATEST":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.sheen?"#define USE_SHEEN":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors||t.instancingColor?"#define USE_COLOR":"",t.vertexAlphas||t.batchingColor?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.gradientMap?"#define USE_GRADIENTMAP":"",t.flatShading?"#define FLAT_SHADED":"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+l:"",t.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",t.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",t.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",t.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",t.toneMapping!==Wn?"#define TONE_MAPPING":"",t.toneMapping!==Wn?ke.tonemapping_pars_fragment:"",t.toneMapping!==Wn?qv("toneMapping",t.toneMapping):"",t.dithering?"#define DITHERING":"",t.opaque?"#define OPAQUE":"",ke.colorspace_pars_fragment,Vv("linearToOutputTexel",t.outputColorSpace),Xv(),t.useDepthPacking?"#define DEPTH_PACKING "+t.depthPacking:"",`
`].filter(wr).join(`
`)),a=Yo(a),a=hh(a,t),a=uh(a,t),o=Yo(o),o=hh(o,t),o=uh(o,t),a=dh(a),o=dh(o),t.isRawShaderMaterial!==!0&&(f=`#version 300 es
`,v=[d,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+v,m=["#define varying in",t.glslVersion===ac?"":"layout(location = 0) out highp vec4 pc_fragColor;",t.glslVersion===ac?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+m);const _=f+v+a,S=f+m+o,y=oh(r,r.VERTEX_SHADER,_),A=oh(r,r.FRAGMENT_SHADER,S);r.attachShader(g,y),r.attachShader(g,A),t.index0AttributeName!==void 0?r.bindAttribLocation(g,0,t.index0AttributeName):t.hasPositionAttribute===!0&&r.bindAttribLocation(g,0,"position"),r.linkProgram(g);function E(C){if(i.debug.checkShaderErrors){const N=r.getProgramInfoLog(g)||"",F=r.getShaderInfoLog(y)||"",V=r.getShaderInfoLog(A)||"",D=N.trim(),H=F.trim(),Z=V.trim();let z=!0,ne=!0;if(r.getProgramParameter(g,r.LINK_STATUS)===!1)if(z=!1,typeof i.debug.onShaderError=="function")i.debug.onShaderError(r,g,y,A);else{const q=ch(r,y,"vertex"),j=ch(r,A,"fragment");$e("WebGLProgram: Shader Error "+r.getError()+" - VALIDATE_STATUS "+r.getProgramParameter(g,r.VALIDATE_STATUS)+`

Material Name: `+C.name+`
Material Type: `+C.type+`

Program Info Log: `+D+`
`+q+`
`+j)}else D!==""?Pe("WebGLProgram: Program Info Log:",D):(H===""||Z==="")&&(ne=!1);ne&&(C.diagnostics={runnable:z,programLog:D,vertexShader:{log:H,prefix:v},fragmentShader:{log:Z,prefix:m}})}r.deleteShader(y),r.deleteShader(A),x=new Vs(r,g),w=Kv(r,g)}let x;this.getUniforms=function(){return x===void 0&&E(this),x};let w;this.getAttributes=function(){return w===void 0&&E(this),w};let I=t.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return I===!1&&(I=r.getProgramParameter(g,kv)),I},this.destroy=function(){n.releaseStatesOfProgram(this),r.deleteProgram(g),this.program=void 0},this.type=t.shaderType,this.name=t.shaderName,this.id=zv++,this.cacheKey=e,this.usedTimes=1,this.program=g,this.vertexShader=y,this.fragmentShader=A,this}let ox=0;class lx{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e,t,n){const r=this._getShaderCacheForMaterial(e);return r.has(t)===!1&&(r.add(t),t.usedTimes++),r.has(n)===!1&&(r.add(n),n.usedTimes++),this}remove(e){const t=this.materialCache.get(e);for(const n of t)n.usedTimes--,n.usedTimes===0&&this.shaderCache.delete(n.code);return this.materialCache.delete(e),this}getVertexShaderStage(e){return this._getShaderStage(e.vertexShader)}getFragmentShaderStage(e){return this._getShaderStage(e.fragmentShader)}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){const t=this.materialCache;let n=t.get(e);return n===void 0&&(n=new Set,t.set(e,n)),n}_getShaderStage(e){const t=this.shaderCache;let n=t.get(e);return n===void 0&&(n=new cx(e),t.set(e,n)),n}}class cx{constructor(e){this.id=ox++,this.code=e,this.usedTimes=0}}function hx(i){return i===Ti||i===Ks||i===Zs}function ux(i,e,t,n,r,s){const a=new bl,o=new lx,l=new Set,c=[],h=new Map,u=n.logarithmicDepthBuffer,d={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distance",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function p(x){return l.add(x),x===0?"uv":`uv${x}`}function g(x,w,I,C,N,F){const V=C.fog,D=N.geometry,H=x.isMeshStandardMaterial||x.isMeshLambertMaterial||x.isMeshPhongMaterial?C.environment:null,Z=x.isMeshStandardMaterial||x.isMeshLambertMaterial&&!x.envMap||x.isMeshPhongMaterial&&!x.envMap,z=e.get(x.envMap||H,Z),ne=d[x.type];let q=n.precision;x.precision!==null&&(q=n.getMaxPrecision(x.precision),q!==x.precision&&Pe("WebGLProgram.getParameters:",x.precision,"not supported, using",q,"instead."));const j=D.morphAttributes.position||D.morphAttributes.normal||D.morphAttributes.color,ee=j!==void 0?j.length:0;let Se=0;D.morphAttributes.position!==void 0&&(Se=1),D.morphAttributes.normal!==void 0&&(Se=2),D.morphAttributes.color!==void 0&&(Se=3);let Ne,Y,ge,ye;if(ne){const me=Rn[ne];Ne=me.vertexShader,Y=me.fragmentShader}else{Ne=x.vertexShader,Y=x.fragmentShader;const me=o.getVertexShaderStage(x),je=o.getFragmentShaderStage(x);o.update(x,me,je),ge=me.id,ye=je.id}const Re=i.getRenderTarget(),ve=i.state.buffers.depth.getReversed(),Fe=N.isInstancedMesh===!0,vt=N.isBatchedMesh===!0,Le=!!x.map,Qe=!!x.matcap,tt=!!z,Ge=tt&&z.isPMREMTexture===!0,Pt=!!x.aoMap,Mt=!!x.lightMap,$t=!!x.bumpMap&&x.wireframe===!1,ht=!!x.normalMap,wn=!!x.displacementMap,Tt=!!x.emissiveMap,tn=!!x.metalnessMap,nn=!!x.roughnessMap,rn=x.anisotropy>0,U=x.clearcoat>0,sn=x.diffuseRoughness>0,ot=x.dispersion>0,lt=x.retroreflectivity>0,fe=x.iridescence>0,bt=x.sheen>0,Ce=x.transmission>0,De=rn&&!!x.anisotropyMap,T=U&&!!x.clearcoatMap,M=U&&!!x.clearcoatNormalMap,B=U&&!!x.clearcoatRoughnessMap,te=sn&&!!x.diffuseRoughnessMap,J=fe&&!!x.iridescenceMap,se=fe&&!!x.iridescenceThicknessMap,he=bt&&!!x.sheenColorMap,X=bt&&!!x.sheenRoughnessMap,$=!!x.specularMap,oe=!!x.specularColorMap,R=!!x.specularIntensityMap,K=Ce&&!!x.transmissionMap,W=Ce&&!!x.thicknessMap,le=!!x.gradientMap,re=!!x.alphaMap,ae=x.alphaTest>0,Ee=!!x.alphaHash,Be=!!x.extensions;let ie=Wn;x.toneMapped&&(Re===null||Re.isXRRenderTarget===!0)&&(ie=i.toneMapping);const Ae=Ge?z.isCompressedCubeTexture?z.image[0].mipmaps:z.mipmaps:null,Oe={shaderID:ne,shaderType:x.type,shaderName:x.name,vertexShader:Ne,fragmentShader:Y,defines:x.defines,customVertexShaderID:ge,customFragmentShaderID:ye,isRawShaderMaterial:x.isRawShaderMaterial===!0,glslVersion:x.glslVersion,precision:q,batching:vt,batchingColor:vt&&N._colorsTexture!==null,instancing:Fe,instancingColor:Fe&&N.instanceColor!==null,instancingMorph:Fe&&N.morphTexture!==null,outputColorSpace:Re===null?i.outputColorSpace:Re.isXRRenderTarget===!0?Re.texture.colorSpace:qe.workingColorSpace,alphaToCoverage:!!x.alphaToCoverage,map:Le,matcap:Qe,envMap:tt,envMapMode:tt&&z.mapping,envMapPMREM:Ge,envMapMaxLod:Ge?Ae.length-1:null,envMapSize:Ge?Ae[0].width:null,aoMap:Pt,lightMap:Mt,bumpMap:$t,normalMap:ht,displacementMap:wn,emissiveMap:Tt,normalMapObjectSpace:ht&&x.normalMapType===ef,normalMapTangentSpace:ht&&x.normalMapType===zo,packedNormalMap:ht&&x.normalMapType===zo&&hx(x.normalMap.format),metalnessMap:tn,roughnessMap:nn,anisotropy:rn,anisotropyMap:De,clearcoat:U,clearcoatMap:T,clearcoatNormalMap:M,clearcoatRoughnessMap:B,diffuseRoughness:sn,diffuseRoughnessMap:te,dispersion:ot,retroreflection:lt,iridescence:fe,iridescenceMap:J,iridescenceThicknessMap:se,sheen:bt,sheenColorMap:he,sheenRoughnessMap:X,specularMap:$,specularColorMap:oe,specularIntensityMap:R,transmission:Ce,transmissionMap:K,thicknessMap:W,gradientMap:le,opaque:x.transparent===!1&&x.blending===Ar&&x.alphaToCoverage===!1,alphaMap:re,alphaTest:ae,alphaHash:Ee,combine:x.combine,mapUv:Le&&p(x.map.channel),aoMapUv:Pt&&p(x.aoMap.channel),lightMapUv:Mt&&p(x.lightMap.channel),bumpMapUv:$t&&p(x.bumpMap.channel),normalMapUv:ht&&p(x.normalMap.channel),displacementMapUv:wn&&p(x.displacementMap.channel),emissiveMapUv:Tt&&p(x.emissiveMap.channel),metalnessMapUv:tn&&p(x.metalnessMap.channel),roughnessMapUv:nn&&p(x.roughnessMap.channel),anisotropyMapUv:De&&p(x.anisotropyMap.channel),clearcoatMapUv:T&&p(x.clearcoatMap.channel),clearcoatNormalMapUv:M&&p(x.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:B&&p(x.clearcoatRoughnessMap.channel),diffuseRoughnessMapUv:te&&p(x.diffuseRoughnessMap.channel),iridescenceMapUv:J&&p(x.iridescenceMap.channel),iridescenceThicknessMapUv:se&&p(x.iridescenceThicknessMap.channel),sheenColorMapUv:he&&p(x.sheenColorMap.channel),sheenRoughnessMapUv:X&&p(x.sheenRoughnessMap.channel),specularMapUv:$&&p(x.specularMap.channel),specularColorMapUv:oe&&p(x.specularColorMap.channel),specularIntensityMapUv:R&&p(x.specularIntensityMap.channel),transmissionMapUv:K&&p(x.transmissionMap.channel),thicknessMapUv:W&&p(x.thicknessMap.channel),alphaMapUv:re&&p(x.alphaMap.channel),vertexTangents:!!D.attributes.tangent&&(ht||rn),vertexNormals:!!D.attributes.normal,vertexColors:x.vertexColors,vertexAlphas:x.vertexColors===!0&&!!D.attributes.color&&D.attributes.color.itemSize===4,pointsUvs:N.isPoints===!0&&!!D.attributes.uv&&(Le||re),fog:!!V,useFog:x.fog===!0,fogExp2:!!V&&V.isFogExp2,flatShading:x.wireframe===!1&&(x.flatShading===!0||D.attributes.normal===void 0&&ht===!1&&(x.isMeshLambertMaterial||x.isMeshPhongMaterial||x.isMeshStandardMaterial||x.isMeshPhysicalMaterial)),sizeAttenuation:x.sizeAttenuation===!0,logarithmicDepthBuffer:u,reversedDepthBuffer:ve,skinning:N.isSkinnedMesh===!0,hasPositionAttribute:D.attributes.position!==void 0,morphTargets:D.morphAttributes.position!==void 0,morphNormals:D.morphAttributes.normal!==void 0,morphColors:D.morphAttributes.color!==void 0,morphTargetsCount:ee,morphTextureStride:Se,numSunLights:w.sun.length,numDirLights:w.directional.length,numPointLights:w.point.length,numSpotLights:w.spot.length,numSpotLightMaps:w.spotLightMap.length,numRectAreaLights:w.rectArea.length,numHemiLights:w.hemi.length,numSunLightShadows:w.sunShadowMap.length,numDirLightShadows:w.directionalShadowMap.length,numPointLightShadows:w.pointShadowMap.length,numSpotLightShadows:w.spotShadowMap.length,numSpotLightShadowsWithMaps:w.numSpotLightShadowsWithMaps,numLightProbes:w.numLightProbes,numLightProbeGrids:F.filter(me=>me.texture!==null).length,numClippingPlanes:s.numPlanes,numClipIntersection:s.numIntersection,dithering:x.dithering,shadowMapEnabled:i.shadowMap.enabled&&I.length>0,shadowMapType:i.shadowMap.type,toneMapping:ie,decodeVideoTexture:Le&&x.map.isVideoTexture===!0&&qe.getTransfer(x.map.colorSpace)===et,decodeVideoTextureEmissive:Tt&&x.emissiveMap.isVideoTexture===!0&&qe.getTransfer(x.emissiveMap.colorSpace)===et,premultipliedAlpha:x.premultipliedAlpha,doubleSided:x.side===xn,flipSided:x.side===qt,useDepthPacking:x.depthPacking>=0,depthPacking:x.depthPacking||0,index0AttributeName:x.index0AttributeName,extensionClipCullDistance:Be&&x.extensions.clipCullDistance===!0&&t.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(Be&&x.extensions.multiDraw===!0||vt)&&t.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:t.has("KHR_parallel_shader_compile"),customProgramCacheKey:x.customProgramCacheKey()};return Oe.vertexUv1s=l.has(1),Oe.vertexUv2s=l.has(2),Oe.vertexUv3s=l.has(3),l.clear(),Oe}function v(x){const w=[];if(x.shaderID?w.push(x.shaderID):(w.push(x.customVertexShaderID),w.push(x.customFragmentShaderID)),x.defines!==void 0)for(const I in x.defines)w.push(I),w.push(x.defines[I]);return x.isRawShaderMaterial===!1&&(m(w,x),f(w,x),w.push(i.outputColorSpace)),w.push(x.customProgramCacheKey),w.join()}function m(x,w){x.push(w.precision),x.push(w.outputColorSpace),x.push(w.envMapMode),x.push(w.envMapPMREM),x.push(w.envMapMaxLod),x.push(w.envMapSize),x.push(w.mapUv),x.push(w.alphaMapUv),x.push(w.lightMapUv),x.push(w.aoMapUv),x.push(w.bumpMapUv),x.push(w.normalMapUv),x.push(w.displacementMapUv),x.push(w.emissiveMapUv),x.push(w.metalnessMapUv),x.push(w.roughnessMapUv),x.push(w.anisotropyMapUv),x.push(w.clearcoatMapUv),x.push(w.clearcoatNormalMapUv),x.push(w.clearcoatRoughnessMapUv),x.push(w.diffuseRoughnessMapUv),x.push(w.iridescenceMapUv),x.push(w.iridescenceThicknessMapUv),x.push(w.sheenColorMapUv),x.push(w.sheenRoughnessMapUv),x.push(w.specularMapUv),x.push(w.specularColorMapUv),x.push(w.specularIntensityMapUv),x.push(w.transmissionMapUv),x.push(w.thicknessMapUv),x.push(w.combine),x.push(w.fogExp2),x.push(w.sizeAttenuation),x.push(w.morphTargetsCount),x.push(w.numSunLights),x.push(w.numDirLights),x.push(w.numPointLights),x.push(w.numSpotLights),x.push(w.numSpotLightMaps),x.push(w.numHemiLights),x.push(w.numRectAreaLights),x.push(w.numSunLightShadows),x.push(w.numDirLightShadows),x.push(w.numPointLightShadows),x.push(w.numSpotLightShadows),x.push(w.numSpotLightShadowsWithMaps),x.push(w.numLightProbes),x.push(w.numLightProbeGrids),x.push(w.shadowMapType),x.push(w.toneMapping),x.push(w.numClippingPlanes),x.push(w.numClipIntersection),x.push(w.depthPacking)}function f(x,w){a.disableAll(),w.instancing&&a.enable(0),w.instancingColor&&a.enable(1),w.instancingMorph&&a.enable(2),w.matcap&&a.enable(3),w.envMap&&a.enable(4),w.normalMapObjectSpace&&a.enable(5),w.normalMapTangentSpace&&a.enable(6),w.clearcoat&&a.enable(7),w.iridescence&&a.enable(8),w.alphaTest&&a.enable(9),w.vertexColors&&a.enable(10),w.vertexAlphas&&a.enable(11),w.vertexUv1s&&a.enable(12),w.vertexUv2s&&a.enable(13),w.vertexUv3s&&a.enable(14),w.vertexTangents&&a.enable(15),w.anisotropy&&a.enable(16),w.alphaHash&&a.enable(17),w.batching&&a.enable(18),w.dispersion&&a.enable(19),w.retroreflection&&a.enable(24),w.diffuseRoughness&&a.enable(25),w.batchingColor&&a.enable(20),w.gradientMap&&a.enable(21),w.packedNormalMap&&a.enable(22),w.vertexNormals&&a.enable(23),x.push(a.mask),a.disableAll(),w.fog&&a.enable(0),w.useFog&&a.enable(1),w.flatShading&&a.enable(2),w.logarithmicDepthBuffer&&a.enable(3),w.reversedDepthBuffer&&a.enable(4),w.skinning&&a.enable(5),w.morphTargets&&a.enable(6),w.morphNormals&&a.enable(7),w.morphColors&&a.enable(8),w.premultipliedAlpha&&a.enable(9),w.shadowMapEnabled&&a.enable(10),w.doubleSided&&a.enable(11),w.flipSided&&a.enable(12),w.useDepthPacking&&a.enable(13),w.dithering&&a.enable(14),w.transmission&&a.enable(15),w.sheen&&a.enable(16),w.opaque&&a.enable(17),w.pointsUvs&&a.enable(18),w.decodeVideoTexture&&a.enable(19),w.decodeVideoTextureEmissive&&a.enable(20),w.alphaToCoverage&&a.enable(21),w.numLightProbeGrids>0&&a.enable(22),w.hasPositionAttribute&&a.enable(23),x.push(a.mask)}function _(x){const w=d[x.type];let I;if(w){const C=Rn[w];I=Np.clone(C.uniforms)}else I=x.uniforms;return I}function S(x,w){let I=h.get(w);return I!==void 0?++I.usedTimes:(I=new ax(i,w,x,r),c.push(I),h.set(w,I)),I}function y(x){if(--x.usedTimes===0){const w=c.indexOf(x);c[w]=c[c.length-1],c.pop(),h.delete(x.cacheKey),x.destroy()}}function A(x){o.remove(x)}function E(){o.dispose()}return{getParameters:g,getProgramCacheKey:v,getUniforms:_,acquireProgram:S,releaseProgram:y,releaseShaderCache:A,programs:c,dispose:E}}function dx(){let i=new WeakMap;function e(a){return i.has(a)}function t(a){let o=i.get(a);return o===void 0&&(o={},i.set(a,o)),o}function n(a){i.delete(a)}function r(a,o,l){i.get(a)[o]=l}function s(){i=new WeakMap}return{has:e,get:t,remove:n,update:r,dispose:s}}function fx(i,e){return i.groupOrder!==e.groupOrder?i.groupOrder-e.groupOrder:i.renderOrder!==e.renderOrder?i.renderOrder-e.renderOrder:i.material.id!==e.material.id?i.material.id-e.material.id:i.materialVariant!==e.materialVariant?i.materialVariant-e.materialVariant:i.z!==e.z?i.z-e.z:i.id-e.id}function ph(i,e){return i.groupOrder!==e.groupOrder?i.groupOrder-e.groupOrder:i.renderOrder!==e.renderOrder?i.renderOrder-e.renderOrder:i.z!==e.z?e.z-i.z:i.id-e.id}function mh(){const i=[];let e=0;const t=[],n=[],r=[];function s(){e=0,t.length=0,n.length=0,r.length=0}function a(d){let p=0;return d.isInstancedMesh&&(p+=2),d.isSkinnedMesh&&(p+=1),p}function o(d,p,g,v,m,f){let _=i[e];return _===void 0?(_={id:d.id,object:d,geometry:p,material:g,materialVariant:a(d),groupOrder:v,renderOrder:d.renderOrder,z:m,group:f},i[e]=_):(_.id=d.id,_.object=d,_.geometry=p,_.material=g,_.materialVariant=a(d),_.groupOrder=v,_.renderOrder=d.renderOrder,_.z=m,_.group=f),e++,_}function l(d,p,g,v,m,f,_){_.reversedDepth===!0&&(m=-m);const S=o(d,p,g,v,m,f);g.transmission>0?n.push(S):g.transparent===!0?r.push(S):t.push(S)}function c(d,p,g,v,m,f){const _=o(d,p,g,v,m,f);g.transmission>0?n.unshift(_):g.transparent===!0?r.unshift(_):t.unshift(_)}function h(d,p){t.length>1&&t.sort(d||fx),n.length>1&&n.sort(p||ph),r.length>1&&r.sort(p||ph)}function u(){for(let d=e,p=i.length;d<p;d++){const g=i[d];if(g.id===null)break;g.id=null,g.object=null,g.geometry=null,g.material=null,g.group=null}}return{opaque:t,transmissive:n,transparent:r,init:s,push:l,unshift:c,finish:u,sort:h}}function px(){let i=new WeakMap;function e(n,r){const s=i.get(n);let a;return s===void 0?(a=new mh,i.set(n,[a])):r>=s.length?(a=new mh,s.push(a)):a=s[r],a}function t(){i=new WeakMap}return{get:e,dispose:t}}function mx(){const i={};return{get:function(e){if(i[e.id]!==void 0)return i[e.id];let t;switch(e.type){case"SunLight":case"DirectionalLight":t={direction:new P,color:new Te};break;case"SpotLight":t={position:new P,direction:new P,color:new Te,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":t={position:new P,color:new Te,distance:0,decay:0};break;case"HemisphereLight":t={direction:new P,skyColor:new Te,groundColor:new Te};break;case"RectAreaLight":t={color:new Te,position:new P,halfWidth:new P,halfHeight:new P};break}return i[e.id]=t,t}}}function gx(){const i={};return{get:function(e){if(i[e.id]!==void 0)return i[e.id];let t;switch(e.type){case"SunLight":case"DirectionalLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new de};break;case"SpotLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new de};break;case"PointLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new de,shadowCameraNear:1,shadowCameraFar:1e3};break}return i[e.id]=t,t}}}let vx=0;function xx(i,e){return(e.castShadow?2:0)-(i.castShadow?2:0)+(e.map?1:0)-(i.map?1:0)}function _x(i){const e=new mx,t=gx(),n={version:0,hash:{sunLength:-1,directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numSunShadows:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],sun:[],sunShadow:[],sunShadowMap:[],sunShadowMatrix:[],sunShadowCascade:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let c=0;c<9;c++)n.probe.push(new P);const r=new P,s=new Ye,a=new Ye;function o(c){let h=0,u=0,d=0;for(let F=0;F<9;F++)n.probe[F].set(0,0,0);let p=0,g=0,v=0,m=0,f=0,_=0,S=0,y=0,A=0,E=0,x=0,w=0,I=0,C=0;c.sort(xx);for(let F=0,V=c.length;F<V;F++){const D=c[F],H=D.color,Z=D.intensity,z=D.distance;let ne=null;if(D.shadow&&D.shadow.map&&(D.shadow.map.texture.format===Ti?ne=D.shadow.map.texture:ne=D.shadow.map.depthTexture||D.shadow.map.texture),D.isAmbientLight)h+=H.r*Z,u+=H.g*Z,d+=H.b*Z;else if(D.isLightProbe){for(let q=0;q<9;q++)n.probe[q].addScaledVector(D.sh.coefficients[q],Z);C++}else if(D.isSunLight){const q=e.get(D);if(q.color.copy(D.color).multiplyScalar(D.intensity),D.castShadow){const j=D.shadow,ee=t.get(D);ee.shadowIntensity=j.intensity,ee.shadowBias=j.bias,ee.shadowNormalBias=j.normalBias,ee.shadowRadius=j.radius,ee.shadowMapSize.copy(j.mapSize).multiply(j.getFrameExtents()),n.sunShadow[g]=ee,n.sunShadowMap[g]=ne;const Se=j.getViewportCount();for(let Ne=0;Ne<Se;Ne++)n.sunShadowMatrix[v+Ne]=j.getMatrix(Ne),n.sunShadowCascade[v+Ne]=j._cascadeData[Ne];v+=Se,g++}n.sun[p]=q,p++}else if(D.isDirectionalLight){const q=e.get(D);if(q.color.copy(D.color).multiplyScalar(D.intensity),D.castShadow){const j=D.shadow,ee=t.get(D);ee.shadowIntensity=j.intensity,ee.shadowBias=j.bias,ee.shadowNormalBias=j.normalBias,ee.shadowRadius=j.radius,ee.shadowMapSize=j.mapSize,n.directionalShadow[m]=ee,n.directionalShadowMap[m]=ne,n.directionalShadowMatrix[m]=D.shadow.matrix,A++}n.directional[m]=q,m++}else if(D.isSpotLight){const q=e.get(D);q.position.setFromMatrixPosition(D.matrixWorld),q.color.copy(H).multiplyScalar(Z),q.distance=z,q.coneCos=Math.cos(D.angle),q.penumbraCos=Math.cos(D.angle*(1-D.penumbra)),q.decay=D.decay,n.spot[_]=q;const j=D.shadow;if(D.map&&(n.spotLightMap[w]=D.map,w++,j.updateMatrices(D),D.castShadow&&I++),n.spotLightMatrix[_]=j.matrix,D.castShadow){const ee=t.get(D);ee.shadowIntensity=j.intensity,ee.shadowBias=j.bias,ee.shadowNormalBias=j.normalBias,ee.shadowRadius=j.radius,ee.shadowMapSize=j.mapSize,n.spotShadow[_]=ee,n.spotShadowMap[_]=ne,x++}_++}else if(D.isRectAreaLight){const q=e.get(D);q.color.copy(H).multiplyScalar(Z),q.halfWidth.set(D.width*.5,0,0),q.halfHeight.set(0,D.height*.5,0),n.rectArea[S]=q,S++}else if(D.isPointLight){const q=e.get(D);if(q.color.copy(D.color).multiplyScalar(D.intensity),q.distance=D.distance,q.decay=D.decay,D.castShadow){const j=D.shadow,ee=t.get(D);ee.shadowIntensity=j.intensity,ee.shadowBias=j.bias,ee.shadowNormalBias=j.normalBias,ee.shadowRadius=j.radius,ee.shadowMapSize=j.mapSize,ee.shadowCameraNear=j.camera.near,ee.shadowCameraFar=j.camera.far,n.pointShadow[f]=ee,n.pointShadowMap[f]=ne,n.pointShadowMatrix[f]=D.shadow.matrix,E++}n.point[f]=q,f++}else if(D.isHemisphereLight){const q=e.get(D);q.skyColor.copy(D.color).multiplyScalar(Z),q.groundColor.copy(D.groundColor).multiplyScalar(Z),n.hemi[y]=q,y++}}S>0&&(i.has("OES_texture_float_linear")===!0?(n.rectAreaLTC1=pe.LTC_FLOAT_1,n.rectAreaLTC2=pe.LTC_FLOAT_2):(n.rectAreaLTC1=pe.LTC_HALF_1,n.rectAreaLTC2=pe.LTC_HALF_2)),n.ambient[0]=h,n.ambient[1]=u,n.ambient[2]=d;const N=n.hash;(N.sunLength!==p||N.directionalLength!==m||N.pointLength!==f||N.spotLength!==_||N.rectAreaLength!==S||N.hemiLength!==y||N.numSunShadows!==g||N.numDirectionalShadows!==A||N.numPointShadows!==E||N.numSpotShadows!==x||N.numSpotMaps!==w||N.numLightProbes!==C)&&(n.sun.length=p,n.directional.length=m,n.spot.length=_,n.rectArea.length=S,n.point.length=f,n.hemi.length=y,n.sunShadow.length=g,n.sunShadowMap.length=g,n.sunShadowMatrix.length=v,n.sunShadowCascade.length=v,n.directionalShadow.length=A,n.directionalShadowMap.length=A,n.directionalShadowMatrix.length=A,n.pointShadow.length=E,n.pointShadowMap.length=E,n.pointShadowMatrix.length=E,n.spotShadow.length=x,n.spotShadowMap.length=x,n.spotLightMatrix.length=x+w-I,n.spotLightMap.length=w,n.numSpotLightShadowsWithMaps=I,n.numLightProbes=C,N.sunLength=p,N.directionalLength=m,N.pointLength=f,N.spotLength=_,N.rectAreaLength=S,N.hemiLength=y,N.numSunShadows=g,N.numDirectionalShadows=A,N.numPointShadows=E,N.numSpotShadows=x,N.numSpotMaps=w,N.numLightProbes=C,n.version=vx++)}function l(c,h){let u=0,d=0,p=0,g=0,v=0,m=0;const f=h.matrixWorldInverse;for(let _=0,S=c.length;_<S;_++){const y=c[_];if(y.isSunLight){const A=n.sun[u];A.direction.setFromMatrixPosition(y.matrixWorld),A.direction.transformDirection(f),u++}else if(y.isDirectionalLight){const A=n.directional[d];A.direction.setFromMatrixPosition(y.matrixWorld),r.setFromMatrixPosition(y.target.matrixWorld),A.direction.sub(r),A.direction.transformDirection(f),d++}else if(y.isSpotLight){const A=n.spot[g];A.position.setFromMatrixPosition(y.matrixWorld),A.position.applyMatrix4(f),A.direction.setFromMatrixPosition(y.matrixWorld),r.setFromMatrixPosition(y.target.matrixWorld),A.direction.sub(r),A.direction.transformDirection(f),g++}else if(y.isRectAreaLight){const A=n.rectArea[v];A.position.setFromMatrixPosition(y.matrixWorld),A.position.applyMatrix4(f),a.identity(),s.copy(y.matrixWorld),s.premultiply(f),a.extractRotation(s),A.halfWidth.set(y.width*.5,0,0),A.halfHeight.set(0,y.height*.5,0),A.halfWidth.applyMatrix4(a),A.halfHeight.applyMatrix4(a),v++}else if(y.isPointLight){const A=n.point[p];A.position.setFromMatrixPosition(y.matrixWorld),A.position.applyMatrix4(f),p++}else if(y.isHemisphereLight){const A=n.hemi[m];A.direction.setFromMatrixPosition(y.matrixWorld),A.direction.transformDirection(f),m++}}}return{setup:o,setupView:l,state:n}}function gh(i){const e=new _x(i),t=[],n=[],r=[];function s(u){h.camera=u,t.length=0,n.length=0,r.length=0}function a(u){u.isLightProbeGrid?r.push(u):t.push(u)}function o(u){n.push(u)}function l(){e.setup(t),r.sort((u,d)=>u.priority-d.priority||u.id-d.id)}function c(u){e.setupView(t,u)}const h={lightsArray:t,shadowsArray:n,lightProbeGridArray:r,camera:null,lights:e,transmissionRenderTarget:{},textureUnits:0};return{init:s,state:h,setupLights:l,setupLightsView:c,pushLight:a,pushShadow:o}}function yx(i){let e=new WeakMap;function t(r,s=0){const a=e.get(r);let o;return a===void 0?(o=new gh(i),e.set(r,[o])):s>=a.length?(o=new gh(i),a.push(o)):o=a[s],o}function n(){e=new WeakMap}return{get:t,dispose:n}}const Mx=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,bx=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ).rg;
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ).r;
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( max( 0.0, squared_mean - mean * mean ) );
	gl_FragColor = vec4( mean, std_dev, 0.0, 1.0 );
}`,Sx=[new P(1,0,0),new P(-1,0,0),new P(0,1,0),new P(0,-1,0),new P(0,0,1),new P(0,0,-1)],wx=[new P(0,-1,0),new P(0,-1,0),new P(0,0,1),new P(0,0,-1),new P(0,-1,0),new P(0,-1,0)],vh=new Ye,yr=new P,Ya=new P;function Ex(i,e,t){let n=new Gr;const r=new de,s=new de,a=new dt,o=new Bp,l=new kp,c={},h=t.maxTextureSize,u={[Ei]:qt,[qt]:Ei,[xn]:xn},d=new Xn({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new de},radius:{value:4}},vertexShader:Mx,fragmentShader:bx}),p=d.clone();p.defines.HORIZONTAL_PASS=1;const g=new gt;g.setAttribute("position",new jt(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const v=new mt(g,d),m=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=Os;let f=this.type;this.render=function(E,x,w){if(m.enabled===!1||m.autoUpdate===!1&&m.needsUpdate===!1||E.length===0)return;this.type===Xh&&(Pe("WebGLShadowMap: PCFSoftShadowMap has been removed. Using PCFShadowMap instead."),this.type=Os);const I=i.getRenderTarget(),C=i.getActiveCubeFace(),N=i.getActiveMipmapLevel(),F=i.state;F.setBlending(Qi),F.buffers.depth.getReversed()===!0?F.buffers.color.setClear(0,0,0,0):F.buffers.color.setClear(1,1,1,1),F.buffers.depth.setTest(!0),F.setScissorTest(!1);const V=f!==this.type;V&&x.traverse(function(D){D.material&&(Array.isArray(D.material)?D.material.forEach(H=>H.needsUpdate=!0):D.material.needsUpdate=!0)});for(let D=0,H=E.length;D<H;D++){const Z=E[D],z=Z.shadow;if(z===void 0){Pe("WebGLShadowMap:",Z,"has no shadow.");continue}if(z.autoUpdate===!1&&z.needsUpdate===!1)continue;r.copy(z.mapSize);const ne=z.getFrameExtents();r.multiply(ne),s.copy(z.mapSize),(r.x>h||r.y>h)&&(r.x>h&&(s.x=Math.floor(h/ne.x),r.x=s.x*ne.x,z.mapSize.x=s.x),r.y>h&&(s.y=Math.floor(h/ne.y),r.y=s.y*ne.y,z.mapSize.y=s.y));const q=i.state.buffers.depth.getReversed();if(z.camera._reversedDepth=q,z.map===null||V===!0){if(z.map!==null&&(z.map.depthTexture!==null&&(z.map.depthTexture.dispose(),z.map.depthTexture=null),z.map.dispose()),this.type===br){if(Z.isPointLight){Pe("WebGLShadowMap: VSM shadow maps are not supported for PointLights. Use PCF or BasicShadowMap instead.");continue}z.map=new Mn(r.x,r.y,{format:Ti,type:Ln,minFilter:Yt,magFilter:Yt,generateMipmaps:!1}),z.map.texture.name=Z.name+".shadowMap",z.map.depthTexture=new ir(r.x,r.y,_n),z.map.depthTexture.name=Z.name+".shadowMapDepth",z.map.depthTexture.format=oi,z.map.depthTexture.compareFunction=null,z.map.depthTexture.minFilter=Dt,z.map.depthTexture.magFilter=Dt}else Z.isPointLight?(z.map=new Il(r.x),z.map.depthTexture=new Au(r.x,Pn)):(z.map=new Mn(r.x,r.y),z.map.depthTexture=new ir(r.x,r.y,Pn)),z.map.depthTexture.name=Z.name+".shadowMap",z.map.depthTexture.format=oi,this.type===Os?(z.map.depthTexture.compareFunction=q?hu:cu,z.map.depthTexture.minFilter=Yt,z.map.depthTexture.magFilter=Yt):(z.map.depthTexture.compareFunction=null,z.map.depthTexture.minFilter=Dt,z.map.depthTexture.magFilter=Dt);z.camera.updateProjectionMatrix()}z.map.isWebGLCubeRenderTarget!==!0&&(z.map.width!==r.x||z.map.height!==r.y)&&z.map.setSize(r.x,r.y);const j=z.map.isWebGLCubeRenderTarget?6:z.getViewportCount();Z.isPointLight!==!0&&z.updateMatrices(Z,w);const ee=(z.camera.layers.mask&4294967294)!==0?z.camera.layers:w.layers;for(let Se=0;Se<j;Se++){const Ne=z.getCamera(Se);if(Z.isPointLight){const Y=z.camera,ge=z.matrix,ye=Z.distance||Y.far;ye!==Y.far&&(Y.far=ye,Y.updateProjectionMatrix()),yr.setFromMatrixPosition(Z.matrixWorld),Y.position.copy(yr),Ya.copy(Y.position),Ya.add(Sx[Se]),Y.up.copy(wx[Se]),Y.lookAt(Ya),Y.updateMatrixWorld(),ge.makeTranslation(-yr.x,-yr.y,-yr.z),vh.multiplyMatrices(Y.projectionMatrix,Y.matrixWorldInverse),z._frustum.setFromProjectionMatrix(vh,Y.coordinateSystem,Y.reversedDepth)}if(z.map.isWebGLCubeRenderTarget)i.setRenderTarget(z.map,Se),i.clear();else{Se===0&&(i.setRenderTarget(z.map),i.clear());const Y=z.getViewport(Se);a.set(s.x*Y.x,s.y*Y.y,s.x*Y.z,s.y*Y.w),F.viewport(a)}n=z.getFrustum(Se),y(x,w,Ne,Z,ee,this.type)}z.isPointLightShadow!==!0&&this.type===br&&_(z,w),z.needsUpdate=!1}f=this.type,m.needsUpdate=!1,i.setRenderTarget(I,C,N)};function _(E,x){const w=e.update(v);d.defines.VSM_SAMPLES!==E.blurSamples&&(d.defines.VSM_SAMPLES=E.blurSamples,p.defines.VSM_SAMPLES=E.blurSamples,d.needsUpdate=!0,p.needsUpdate=!0),E.mapPass===null?E.mapPass=new Mn(r.x,r.y,{format:Ti,type:Ln}):(E.mapPass.width!==E.map.width||E.mapPass.height!==E.map.height)&&E.mapPass.setSize(E.map.width,E.map.height),d.uniforms.shadow_pass.value=E.map.depthTexture,d.uniforms.resolution.value.set(E.map.width,E.map.height),d.uniforms.radius.value=E.radius,i.setRenderTarget(E.mapPass),i.clear(),i.renderBufferDirect(x,null,w,d,v,null),p.uniforms.shadow_pass.value=E.mapPass.texture,p.uniforms.resolution.value.set(E.map.width,E.map.height),p.uniforms.radius.value=E.radius,i.setRenderTarget(E.map),i.clear(),i.renderBufferDirect(x,null,w,p,v,null)}function S(E,x,w,I){let C=null;const N=w.isPointLight===!0?E.customDistanceMaterial:E.customDepthMaterial;if(N!==void 0)C=N;else if(C=w.isPointLight===!0?l:o,i.localClippingEnabled&&x.clipShadows===!0&&Array.isArray(x.clippingPlanes)&&x.clippingPlanes.length!==0||x.displacementMap&&x.displacementScale!==0||x.alphaMap&&x.alphaTest>0||x.map&&x.alphaTest>0||x.alphaToCoverage===!0){const F=C.uuid,V=x.uuid;let D=c[F];D===void 0&&(D={},c[F]=D);let H=D[V];H===void 0&&(H=C.clone(),D[V]=H,x.addEventListener("dispose",A)),C=H}if(C.visible=x.visible,C.wireframe=x.wireframe,I===br?C.side=x.shadowSide!==null?x.shadowSide:x.side:C.side=x.shadowSide!==null?x.shadowSide:u[x.side],C.alphaMap=x.alphaMap,C.alphaTest=x.alphaToCoverage===!0?.5:x.alphaTest,C.map=x.map,C.clipShadows=x.clipShadows,C.clippingPlanes=x.clippingPlanes,C.clipIntersection=x.clipIntersection,C.displacementMap=x.displacementMap,C.displacementScale=x.displacementScale,C.displacementBias=x.displacementBias,C.wireframeLinewidth=x.wireframeLinewidth,C.linewidth=x.linewidth,w.isPointLight===!0&&C.isMeshDistanceMaterial===!0){const F=i.properties.get(C);F.light=w}return C}function y(E,x,w,I,C,N){if(E.visible===!1)return;if(E.layers.test(C)&&(E.isMesh||E.isLine||E.isPoints)&&(E.castShadow||E.receiveShadow&&N===br)&&(!E.frustumCulled||E.intersectsFrustum(n))){E.modelViewMatrix.multiplyMatrices(w.matrixWorldInverse,E.matrixWorld);const D=e.update(E),H=E.material;if(Array.isArray(H)){const Z=D.groups;for(let z=0,ne=Z.length;z<ne;z++){const q=Z[z],j=H[q.materialIndex];if(j&&j.visible){const ee=S(E,j,I,N);E.onBeforeShadow(i,E,x,w,D,ee,q),i.renderBufferDirect(w,null,D,ee,E,q),E.onAfterShadow(i,E,x,w,D,ee,q)}}}else if(H.visible){const Z=S(E,H,I,N);E.onBeforeShadow(i,E,x,w,D,Z,null),i.renderBufferDirect(w,null,D,Z,E,null),E.onAfterShadow(i,E,x,w,D,Z,null)}}const V=E.children;for(let D=0,H=V.length;D<H;D++)y(V[D],x,w,I,C,N)}function A(E){E.target.removeEventListener("dispose",A);for(const w in c){const I=c[w],C=E.target.uuid;C in I&&(I[C].dispose(),delete I[C])}}}function Tx(i,e){function t(){let R=!1;const K=new dt;let W=null;const le=new dt(0,0,0,0);return{setMask:function(re){W!==re&&!R&&(i.colorMask(re,re,re,re),W=re)},setLocked:function(re){R=re},setClear:function(re,ae,Ee,Be,ie){ie===!0&&(re*=Be,ae*=Be,Ee*=Be),K.set(re,ae,Ee,Be),le.equals(K)===!1&&(i.clearColor(re,ae,Ee,Be),le.copy(K))},reset:function(){R=!1,W=null,le.set(-1,0,0,0)}}}function n(){let R=!1,K=!1,W=null,le=null,re=null;return{setReversed:function(ae){if(K!==ae){const Ee=e.get("EXT_clip_control");ae?Ee.clipControlEXT(Ee.LOWER_LEFT_EXT,Ee.ZERO_TO_ONE_EXT):Ee.clipControlEXT(Ee.LOWER_LEFT_EXT,Ee.NEGATIVE_ONE_TO_ONE_EXT),K=ae;const Be=re;re=null,this.setClear(Be)}},getReversed:function(){return K},setTest:function(ae){ae?ve(i.DEPTH_TEST):Fe(i.DEPTH_TEST)},setMask:function(ae){W!==ae&&!R&&(i.depthMask(ae),W=ae)},setFunc:function(ae){if(K&&(ae=uf[ae]),le!==ae){switch(ae){case eo:i.depthFunc(i.NEVER);break;case to:i.depthFunc(i.ALWAYS);break;case no:i.depthFunc(i.LESS);break;case Fr:i.depthFunc(i.LEQUAL);break;case io:i.depthFunc(i.EQUAL);break;case ro:i.depthFunc(i.GEQUAL);break;case so:i.depthFunc(i.GREATER);break;case ao:i.depthFunc(i.NOTEQUAL);break;default:i.depthFunc(i.LEQUAL)}le=ae}},setLocked:function(ae){R=ae},setClear:function(ae){re!==ae&&(re=ae,K&&(ae=1-ae),i.clearDepth(ae))},reset:function(){R=!1,W=null,le=null,re=null,K=!1}}}function r(){let R=!1,K=null,W=null,le=null,re=null,ae=null,Ee=null,Be=null,ie=null;return{setTest:function(Ae){R||(Ae?ve(i.STENCIL_TEST):Fe(i.STENCIL_TEST))},setMask:function(Ae){K!==Ae&&!R&&(i.stencilMask(Ae),K=Ae)},setFunc:function(Ae,Oe,me){(W!==Ae||le!==Oe||re!==me)&&(i.stencilFunc(Ae,Oe,me),W=Ae,le=Oe,re=me)},setOp:function(Ae,Oe,me){(ae!==Ae||Ee!==Oe||Be!==me)&&(i.stencilOp(Ae,Oe,me),ae=Ae,Ee=Oe,Be=me)},setLocked:function(Ae){R=Ae},setClear:function(Ae){ie!==Ae&&(i.clearStencil(Ae),ie=Ae)},reset:function(){R=!1,K=null,W=null,le=null,re=null,ae=null,Ee=null,Be=null,ie=null}}}const s=new t,a=new n,o=new r;let l={};const c=new WeakMap;let h={},u={},d={},p=new WeakMap,g=[],v=null,m=!1,f=null,_=null,S=null,y=null,A=null,E=null,x=null,w=new Te(0,0,0),I=0,C=!1,N=null,F=null,V=null,D=null,H=null;const Z=i.getParameter(i.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let z=!1,ne=0;const q=i.getParameter(i.VERSION);q.indexOf("WebGL")!==-1?(ne=parseFloat(/^WebGL (\d)/.exec(q)[1]),z=ne>=1):q.indexOf("OpenGL ES")!==-1&&(ne=parseFloat(/^OpenGL ES (\d)/.exec(q)[1]),z=ne>=2);let j=null,ee={};const Se=i.getParameter(i.SCISSOR_BOX),Ne=i.getParameter(i.VIEWPORT),Y=new dt().fromArray(Se),ge=new dt().fromArray(Ne);function ye(R,K,W,le){const re=new Uint8Array(4),ae=i.createTexture();i.bindTexture(R,ae),i.texParameteri(R,i.TEXTURE_MIN_FILTER,i.NEAREST),i.texParameteri(R,i.TEXTURE_MAG_FILTER,i.NEAREST);for(let Ee=0;Ee<W;Ee++)R===i.TEXTURE_3D||R===i.TEXTURE_2D_ARRAY?i.texImage3D(K,0,i.RGBA,1,1,le,0,i.RGBA,i.UNSIGNED_BYTE,re):i.texImage2D(K+Ee,0,i.RGBA,1,1,0,i.RGBA,i.UNSIGNED_BYTE,re);return ae}const Re={};Re[i.TEXTURE_2D]=ye(i.TEXTURE_2D,i.TEXTURE_2D,1),Re[i.TEXTURE_CUBE_MAP]=ye(i.TEXTURE_CUBE_MAP,i.TEXTURE_CUBE_MAP_POSITIVE_X,6),Re[i.TEXTURE_2D_ARRAY]=ye(i.TEXTURE_2D_ARRAY,i.TEXTURE_2D_ARRAY,1,1),Re[i.TEXTURE_3D]=ye(i.TEXTURE_3D,i.TEXTURE_3D,1,1),s.setClear(0,0,0,1),a.setClear(1),o.setClear(0),ve(i.DEPTH_TEST),a.setFunc(Fr),$t(!1),ht(nc),ve(i.CULL_FACE),Pt(Qi);function ve(R){h[R]!==!0&&(i.enable(R),h[R]=!0)}function Fe(R){h[R]!==!1&&(i.disable(R),h[R]=!1)}function vt(R,K){return d[R]!==K?(i.bindFramebuffer(R,K),d[R]=K,R===i.DRAW_FRAMEBUFFER&&(d[i.FRAMEBUFFER]=K),R===i.FRAMEBUFFER&&(d[i.DRAW_FRAMEBUFFER]=K),!0):!1}function Le(R,K){let W=g,le=!1;if(R){W=p.get(K),W===void 0&&(W=[],p.set(K,W));const re=R.textures;if(W.length!==re.length||W[0]!==i.COLOR_ATTACHMENT0){for(let ae=0,Ee=re.length;ae<Ee;ae++)W[ae]=i.COLOR_ATTACHMENT0+ae;W.length=re.length,le=!0}}else W[0]!==i.BACK&&(W[0]=i.BACK,le=!0);le&&i.drawBuffers(W)}function Qe(R){return v!==R?(i.useProgram(R),v=R,!0):!1}const tt={[Zi]:i.FUNC_ADD,[Id]:i.FUNC_SUBTRACT,[Nd]:i.FUNC_REVERSE_SUBTRACT};tt[Ud]=i.MIN,tt[Fd]=i.MAX;const Ge={[Od]:i.ZERO,[Bd]:i.ONE,[kd]:i.SRC_COLOR,[$h]:i.SRC_ALPHA,[qd]:i.SRC_ALPHA_SATURATE,[Vd]:i.DST_COLOR,[Gd]:i.DST_ALPHA,[zd]:i.ONE_MINUS_SRC_COLOR,[Yh]:i.ONE_MINUS_SRC_ALPHA,[Wd]:i.ONE_MINUS_DST_COLOR,[Hd]:i.ONE_MINUS_DST_ALPHA,[Xd]:i.CONSTANT_COLOR,[$d]:i.ONE_MINUS_CONSTANT_COLOR,[Yd]:i.CONSTANT_ALPHA,[Kd]:i.ONE_MINUS_CONSTANT_ALPHA};function Pt(R,K,W,le,re,ae,Ee,Be,ie,Ae){if(R===Qi){m===!0&&(Fe(i.BLEND),m=!1);return}if(m===!1&&(ve(i.BLEND),m=!0),R!==Dd){if(R!==f||Ae!==C){if((_!==Zi||A!==Zi)&&(i.blendEquation(i.FUNC_ADD),_=Zi,A=Zi),Ae)switch(R){case Ar:i.blendFuncSeparate(i.ONE,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case ic:i.blendFunc(i.ONE,i.ONE);break;case rc:i.blendFuncSeparate(i.ZERO,i.ONE_MINUS_SRC_COLOR,i.ZERO,i.ONE);break;case sc:i.blendFuncSeparate(i.DST_COLOR,i.ONE_MINUS_SRC_ALPHA,i.ZERO,i.ONE);break;default:$e("WebGLState: Invalid blending: ",R);break}else switch(R){case Ar:i.blendFuncSeparate(i.SRC_ALPHA,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case ic:i.blendFuncSeparate(i.SRC_ALPHA,i.ONE,i.ONE,i.ONE);break;case rc:$e("WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true");break;case sc:$e("WebGLState: MultiplyBlending requires material.premultipliedAlpha = true");break;default:$e("WebGLState: Invalid blending: ",R);break}S=null,y=null,E=null,x=null,w.set(0,0,0),I=0,f=R,C=Ae}return}re=re||K,ae=ae||W,Ee=Ee||le,(K!==_||re!==A)&&(i.blendEquationSeparate(tt[K],tt[re]),_=K,A=re),(W!==S||le!==y||ae!==E||Ee!==x)&&(i.blendFuncSeparate(Ge[W],Ge[le],Ge[ae],Ge[Ee]),S=W,y=le,E=ae,x=Ee),(Be.equals(w)===!1||ie!==I)&&(i.blendColor(Be.r,Be.g,Be.b,ie),w.copy(Be),I=ie),f=R,C=!1}function Mt(R,K){R.side===xn?Fe(i.CULL_FACE):ve(i.CULL_FACE);let W=R.side===qt;K&&(W=!W),$t(W),R.blending===Ar&&R.transparent===!1?Pt(Qi):Pt(R.blending,R.blendEquation,R.blendSrc,R.blendDst,R.blendEquationAlpha,R.blendSrcAlpha,R.blendDstAlpha,R.blendColor,R.blendAlpha,R.premultipliedAlpha),a.setFunc(R.depthFunc),a.setTest(R.depthTest),a.setMask(R.depthWrite),s.setMask(R.colorWrite);const le=R.stencilWrite;o.setTest(le),le&&(o.setMask(R.stencilWriteMask),o.setFunc(R.stencilFunc,R.stencilRef,R.stencilFuncMask),o.setOp(R.stencilFail,R.stencilZFail,R.stencilZPass)),Tt(R.polygonOffset,R.polygonOffsetFactor,R.polygonOffsetUnits),R.alphaToCoverage===!0?ve(i.SAMPLE_ALPHA_TO_COVERAGE):Fe(i.SAMPLE_ALPHA_TO_COVERAGE)}function $t(R){N!==R&&(R?i.frontFace(i.CW):i.frontFace(i.CCW),N=R)}function ht(R){R!==Pd?(ve(i.CULL_FACE),R!==F&&(R===nc?i.cullFace(i.BACK):R===Ld?i.cullFace(i.FRONT):i.cullFace(i.FRONT_AND_BACK))):Fe(i.CULL_FACE),F=R}function wn(R){R!==V&&(z&&i.lineWidth(R),V=R)}function Tt(R,K,W){R?(ve(i.POLYGON_OFFSET_FILL),(D!==K||H!==W)&&(D=K,H=W,a.getReversed()&&(K=-K,W=-W),i.polygonOffset(K,W))):Fe(i.POLYGON_OFFSET_FILL)}function tn(R){R?ve(i.SCISSOR_TEST):Fe(i.SCISSOR_TEST)}function nn(R){R===void 0&&(R=i.TEXTURE0+Z-1),j!==R&&(i.activeTexture(R),j=R)}function rn(R,K,W){W===void 0&&(j===null?W=i.TEXTURE0+Z-1:W=j);let le=ee[W];le===void 0&&(le={type:void 0,texture:void 0},ee[W]=le),(le.type!==R||le.texture!==K)&&(j!==W&&(i.activeTexture(W),j=W),i.bindTexture(R,K||Re[R]),le.type=R,le.texture=K)}function U(){const R=ee[j];R!==void 0&&R.type!==void 0&&(i.bindTexture(R.type,null),R.type=void 0,R.texture=void 0)}function sn(){try{i.compressedTexImage2D(...arguments)}catch(R){$e("WebGLState:",R)}}function ot(){try{i.compressedTexImage3D(...arguments)}catch(R){$e("WebGLState:",R)}}function lt(){try{i.texSubImage2D(...arguments)}catch(R){$e("WebGLState:",R)}}function fe(){try{i.texSubImage3D(...arguments)}catch(R){$e("WebGLState:",R)}}function bt(){try{i.compressedTexSubImage2D(...arguments)}catch(R){$e("WebGLState:",R)}}function Ce(){try{i.compressedTexSubImage3D(...arguments)}catch(R){$e("WebGLState:",R)}}function De(){try{i.texStorage2D(...arguments)}catch(R){$e("WebGLState:",R)}}function T(){try{i.texStorage3D(...arguments)}catch(R){$e("WebGLState:",R)}}function M(){try{i.texImage2D(...arguments)}catch(R){$e("WebGLState:",R)}}function B(){try{i.texImage3D(...arguments)}catch(R){$e("WebGLState:",R)}}function te(R){return u[R]!==void 0?u[R]:i.getParameter(R)}function J(R,K){u[R]!==K&&(i.pixelStorei(R,K),u[R]=K)}function se(R){Y.equals(R)===!1&&(i.scissor(R.x,R.y,R.z,R.w),Y.copy(R))}function he(R){ge.equals(R)===!1&&(i.viewport(R.x,R.y,R.z,R.w),ge.copy(R))}function X(R,K){let W=c.get(K);W===void 0&&(W=new WeakMap,c.set(K,W));let le=W.get(R);le===void 0&&(le=i.getUniformBlockIndex(K,R.name),i.uniformBlockBinding(K,le,le),W.set(R,le))}function $(R,K,W){const re=c.get(K).get(R);l[re]!==W&&(i.bindBufferBase(i.UNIFORM_BUFFER,re,W),l[re]=W)}function oe(){i.disable(i.BLEND),i.disable(i.CULL_FACE),i.disable(i.DEPTH_TEST),i.disable(i.POLYGON_OFFSET_FILL),i.disable(i.SCISSOR_TEST),i.disable(i.STENCIL_TEST),i.disable(i.SAMPLE_ALPHA_TO_COVERAGE),i.blendEquation(i.FUNC_ADD),i.blendFunc(i.ONE,i.ZERO),i.blendFuncSeparate(i.ONE,i.ZERO,i.ONE,i.ZERO),i.blendColor(0,0,0,0),i.colorMask(!0,!0,!0,!0),i.clearColor(0,0,0,0),i.depthMask(!0),i.depthFunc(i.LESS),a.setReversed(!1),i.clearDepth(1),i.stencilMask(4294967295),i.stencilFunc(i.ALWAYS,0,4294967295),i.stencilOp(i.KEEP,i.KEEP,i.KEEP),i.clearStencil(0),i.cullFace(i.BACK),i.frontFace(i.CCW),i.polygonOffset(0,0),i.activeTexture(i.TEXTURE0),i.bindFramebuffer(i.FRAMEBUFFER,null),i.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),i.bindFramebuffer(i.READ_FRAMEBUFFER,null),i.useProgram(null),i.lineWidth(1),i.scissor(0,0,i.canvas.width,i.canvas.height),i.viewport(0,0,i.canvas.width,i.canvas.height),i.pixelStorei(i.PACK_ALIGNMENT,4),i.pixelStorei(i.UNPACK_ALIGNMENT,4),i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,!1),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,!1),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,i.BROWSER_DEFAULT_WEBGL),i.pixelStorei(i.PACK_ROW_LENGTH,0),i.pixelStorei(i.PACK_SKIP_PIXELS,0),i.pixelStorei(i.PACK_SKIP_ROWS,0),i.pixelStorei(i.UNPACK_ROW_LENGTH,0),i.pixelStorei(i.UNPACK_IMAGE_HEIGHT,0),i.pixelStorei(i.UNPACK_SKIP_PIXELS,0),i.pixelStorei(i.UNPACK_SKIP_ROWS,0),i.pixelStorei(i.UNPACK_SKIP_IMAGES,0),h={},u={},j=null,ee={},d={},l={},p=new WeakMap,g=[],v=null,m=!1,f=null,_=null,S=null,y=null,A=null,E=null,x=null,w=new Te(0,0,0),I=0,C=!1,N=null,F=null,V=null,D=null,H=null,Y.set(0,0,i.canvas.width,i.canvas.height),ge.set(0,0,i.canvas.width,i.canvas.height),s.reset(),a.reset(),o.reset()}return{buffers:{color:s,depth:a,stencil:o},enable:ve,disable:Fe,bindFramebuffer:vt,drawBuffers:Le,useProgram:Qe,setBlending:Pt,setMaterial:Mt,setFlipSided:$t,setCullFace:ht,setLineWidth:wn,setPolygonOffset:Tt,setScissorTest:tn,activeTexture:nn,bindTexture:rn,unbindTexture:U,compressedTexImage2D:sn,compressedTexImage3D:ot,texImage2D:M,texImage3D:B,pixelStorei:J,getParameter:te,updateUBOMapping:X,uniformBlockBinding:$,texStorage2D:De,texStorage3D:T,texSubImage2D:lt,texSubImage3D:fe,compressedTexSubImage2D:bt,compressedTexSubImage3D:Ce,scissor:se,viewport:he,reset:oe}}function Ax(i,e,t,n,r,s,a){const o=e.has("WEBGL_multisampled_render_to_texture")?e.get("WEBGL_multisampled_render_to_texture"):null,l=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),c=new de,h=new WeakMap,u=new Set;let d;const p=new WeakMap,g=new Set,v=new FinalizationRegistry(T=>g.delete(T));let m=!1;try{m=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function f(T,M){return m?new OffscreenCanvas(T,M):js("canvas")}function _(T,M,B){let te=1;const J=De(T);if((J.width>B||J.height>B)&&(te=B/Math.max(J.width,J.height)),te<1)if(typeof HTMLImageElement<"u"&&T instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&T instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&T instanceof ImageBitmap||typeof VideoFrame<"u"&&T instanceof VideoFrame){const se=Math.floor(te*J.width),he=Math.floor(te*J.height);d===void 0&&(d=f(se,he));const X=M?f(se,he):d;return X.width=se,X.height=he,X.getContext("2d").drawImage(T,0,0,se,he),Pe("WebGLRenderer: Texture has been resized from ("+J.width+"x"+J.height+") to ("+se+"x"+he+")."),X}else return"data"in T&&Pe("WebGLRenderer: Image in DataTexture is too big ("+J.width+"x"+J.height+")."),T;return T}function S(T){return T.generateMipmaps}function y(T){i.generateMipmap(T)}function A(T){return T.isWebGLCubeRenderTarget?i.TEXTURE_CUBE_MAP:T.isWebGL3DRenderTarget?i.TEXTURE_3D:T.isWebGLArrayRenderTarget||T.isCompressedArrayTexture?i.TEXTURE_2D_ARRAY:i.TEXTURE_2D}function E(T,M,B,te,J,se=!1){if(T!==null){if(i[T]!==void 0)return i[T];Pe("WebGLRenderer: Attempt to use non-existing WebGL internal format '"+T+"'")}let he;te&&(he=e.get("EXT_texture_norm16"),he||Pe("WebGLRenderer: Unable to use normalized textures without EXT_texture_norm16 extension"));let X=M;if(M===i.RED&&(B===i.FLOAT&&(X=i.R32F),B===i.HALF_FLOAT&&(X=i.R16F),B===i.UNSIGNED_BYTE&&(X=i.R8),B===i.UNSIGNED_SHORT&&he&&(X=he.R16_EXT),B===i.SHORT&&he&&(X=he.R16_SNORM_EXT)),M===i.RED_INTEGER&&(B===i.UNSIGNED_BYTE&&(X=i.R8UI),B===i.UNSIGNED_SHORT&&(X=i.R16UI),B===i.UNSIGNED_INT&&(X=i.R32UI),B===i.BYTE&&(X=i.R8I),B===i.SHORT&&(X=i.R16I),B===i.INT&&(X=i.R32I)),M===i.RG&&(B===i.FLOAT&&(X=i.RG32F),B===i.HALF_FLOAT&&(X=i.RG16F),B===i.UNSIGNED_BYTE&&(X=i.RG8),B===i.UNSIGNED_SHORT&&he&&(X=he.RG16_EXT),B===i.SHORT&&he&&(X=he.RG16_SNORM_EXT)),M===i.RG_INTEGER&&(B===i.UNSIGNED_BYTE&&(X=i.RG8UI),B===i.UNSIGNED_SHORT&&(X=i.RG16UI),B===i.UNSIGNED_INT&&(X=i.RG32UI),B===i.BYTE&&(X=i.RG8I),B===i.SHORT&&(X=i.RG16I),B===i.INT&&(X=i.RG32I)),M===i.RGB_INTEGER&&(B===i.UNSIGNED_BYTE&&(X=i.RGB8UI),B===i.UNSIGNED_SHORT&&(X=i.RGB16UI),B===i.UNSIGNED_INT&&(X=i.RGB32UI),B===i.BYTE&&(X=i.RGB8I),B===i.SHORT&&(X=i.RGB16I),B===i.INT&&(X=i.RGB32I)),M===i.RGBA_INTEGER&&(B===i.UNSIGNED_BYTE&&(X=i.RGBA8UI),B===i.UNSIGNED_SHORT&&(X=i.RGBA16UI),B===i.UNSIGNED_INT&&(X=i.RGBA32UI),B===i.BYTE&&(X=i.RGBA8I),B===i.SHORT&&(X=i.RGBA16I),B===i.INT&&(X=i.RGBA32I)),M===i.RGB&&(B===i.UNSIGNED_SHORT&&he&&(X=he.RGB16_EXT),B===i.SHORT&&he&&(X=he.RGB16_SNORM_EXT),B===i.UNSIGNED_INT_5_9_9_9_REV&&(X=i.RGB9_E5),B===i.UNSIGNED_INT_10F_11F_11F_REV&&(X=i.R11F_G11F_B10F)),M===i.RGBA){const $=se?Qs:qe.getTransfer(J);B===i.FLOAT&&(X=i.RGBA32F),B===i.HALF_FLOAT&&(X=i.RGBA16F),B===i.UNSIGNED_BYTE&&(X=$===et?i.SRGB8_ALPHA8:i.RGBA8),B===i.UNSIGNED_SHORT&&he&&(X=he.RGBA16_EXT),B===i.SHORT&&he&&(X=he.RGBA16_SNORM_EXT),B===i.UNSIGNED_SHORT_4_4_4_4&&(X=i.RGBA4),B===i.UNSIGNED_SHORT_5_5_5_1&&(X=i.RGB5_A1)}return(X===i.R16F||X===i.R32F||X===i.RG16F||X===i.RG32F||X===i.RGBA16F||X===i.RGBA32F)&&e.get("EXT_color_buffer_float"),X}function x(T,M){let B;return T?M===null||M===Pn||M===nr?B=i.DEPTH24_STENCIL8:M===_n?B=i.DEPTH32F_STENCIL8:M===Br&&(B=i.DEPTH24_STENCIL8,Pe("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):M===null||M===Pn||M===nr?B=i.DEPTH_COMPONENT24:M===_n?B=i.DEPTH_COMPONENT32F:M===Br&&(B=i.DEPTH_COMPONENT16),B}function w(T,M){return S(T)===!0||T.isFramebufferTexture&&T.minFilter!==Dt&&T.minFilter!==Yt?Math.log2(Math.max(M.width,M.height))+1:T.mipmaps.length>0?T.mipmaps.length:T.isCompressedTexture&&Array.isArray(T.image)?M.mipmaps.length:1}function I(T){const M=new WeakRef(T);n.get(T).__ref=M,g.add(M),v.register(T,M,M)}function C(T){const M=n.get(T).__ref;M!==void 0&&(g.delete(M),v.unregister(M))}function N(T){V(T.target)}function F(T){D(T.target)}function V(T){T.removeEventListener("dispose",N),C(T),Z(T),T.isVideoTexture&&h.delete(T),T.isHTMLTexture&&u.delete(T)}function D(T){T.removeEventListener("dispose",F),C(T),ne(T)}function H(){for(const T of g){const M=T.deref();M!==void 0&&(M.isRenderTarget===!0?D(M):V(M))}g.clear(),u.clear()}function Z(T){const M=n.get(T);if(M.__webglInit===void 0)return;const B=T.source,te=p.get(B);if(te){const J=te[M.__cacheKey];J.usedTimes--,J.usedTimes===0&&z(T),Object.keys(te).length===0&&p.delete(B)}n.remove(T)}function z(T){const M=n.get(T);i.deleteTexture(M.__webglTexture);const B=T.source,te=p.get(B);delete te[M.__cacheKey],a.memory.textures--}function ne(T){const M=n.get(T);M.__depthDisposeCallback&&M.__depthDisposeCallback();const B=T.depthTexture;if(B&&B.renderTarget===T&&V(B),T.isWebGLCubeRenderTarget)for(let J=0;J<6;J++){if(Array.isArray(M.__webglFramebuffer[J]))for(let se=0;se<M.__webglFramebuffer[J].length;se++)i.deleteFramebuffer(M.__webglFramebuffer[J][se]);else i.deleteFramebuffer(M.__webglFramebuffer[J]);M.__webglDepthbuffer&&i.deleteRenderbuffer(M.__webglDepthbuffer[J])}else{if(Array.isArray(M.__webglFramebuffer))for(let J=0;J<M.__webglFramebuffer.length;J++)i.deleteFramebuffer(M.__webglFramebuffer[J]);else i.deleteFramebuffer(M.__webglFramebuffer);if(M.__webglDepthbuffer&&i.deleteRenderbuffer(M.__webglDepthbuffer),M.__webglMultisampledFramebuffer&&i.deleteFramebuffer(M.__webglMultisampledFramebuffer),M.__webglColorRenderbuffer)for(let J=0;J<M.__webglColorRenderbuffer.length;J++)M.__webglColorRenderbuffer[J]&&i.deleteRenderbuffer(M.__webglColorRenderbuffer[J]);M.__webglDepthRenderbuffer&&i.deleteRenderbuffer(M.__webglDepthRenderbuffer)}const te=T.textures;for(let J=0,se=te.length;J<se;J++){const he=n.get(te[J]);he.__webglTexture&&(i.deleteTexture(he.__webglTexture),a.memory.textures--),n.remove(te[J])}n.remove(T)}let q=0;function j(){q=0}function ee(){return q}function Se(T){q=T}function Ne(){const T=q;return T>=r.maxTextures&&Pe("WebGLTextures: Trying to use "+(T+1)+" texture units while this GPU supports only "+r.maxTextures),q+=1,T}function Y(T){const M=[];return M.push(T.wrapS),M.push(T.wrapT),M.push(T.wrapR||0),M.push(T.magFilter),M.push(T.minFilter),M.push(T.anisotropy),M.push(T.internalFormat),M.push(T.format),M.push(T.type),M.push(T.generateMipmaps),M.push(T.mipmapsAutoUpdate),M.push(T.premultiplyAlpha),M.push(T.flipY),M.push(T.unpackAlignment),M.push(T.colorSpace),M.join()}function ge(T,M){const B=n.get(T);if(T.isVideoTexture&&bt(T),T.isRenderTargetTexture===!1&&T.isExternalTexture!==!0&&T.version>0&&B.__version!==T.version){const te=T.image;if(te===null)Pe("WebGLRenderer: Texture marked for update but no image data found.");else if(te.complete===!1)Pe("WebGLRenderer: Texture marked for update but image is incomplete");else{Mt(B,T,M);return}}else T.isExternalTexture&&(B.__webglTexture=T.sourceTexture?T.sourceTexture:null);t.bindTexture(i.TEXTURE_2D,B.__webglTexture,i.TEXTURE0+M)}function ye(T,M){const B=n.get(T);if(T.isRenderTargetTexture===!1&&T.version>0&&B.__version!==T.version){Mt(B,T,M);return}else T.isExternalTexture&&(B.__webglTexture=T.sourceTexture?T.sourceTexture:null);t.bindTexture(i.TEXTURE_2D_ARRAY,B.__webglTexture,i.TEXTURE0+M)}function Re(T,M){const B=n.get(T);if(T.isRenderTargetTexture===!1&&T.version>0&&B.__version!==T.version){Mt(B,T,M);return}t.bindTexture(i.TEXTURE_3D,B.__webglTexture,i.TEXTURE0+M)}function ve(T,M){const B=n.get(T);if(T.version>0&&B.__version!==T.version){$t(B,T,M);return}t.bindTexture(i.TEXTURE_CUBE_MAP,B.__webglTexture,i.TEXTURE0+M)}const Fe={[oo]:i.REPEAT,[Vn]:i.CLAMP_TO_EDGE,[lo]:i.MIRRORED_REPEAT},vt={[Dt]:i.NEAREST,[Qd]:i.NEAREST_MIPMAP_NEAREST,[es]:i.NEAREST_MIPMAP_LINEAR,[Yt]:i.LINEAR,[_a]:i.LINEAR_MIPMAP_NEAREST,[ii]:i.LINEAR_MIPMAP_LINEAR},Le={[nf]:i.NEVER,[uu]:i.ALWAYS,[rf]:i.LESS,[cu]:i.LEQUAL,[sf]:i.EQUAL,[hu]:i.GEQUAL,[af]:i.GREATER,[of]:i.NOTEQUAL};function Qe(T,M){if(M.type===_n&&e.has("OES_texture_float_linear")===!1&&(M.magFilter===Yt||M.magFilter===_a||M.magFilter===es||M.magFilter===ii||M.minFilter===Yt||M.minFilter===_a||M.minFilter===es||M.minFilter===ii)&&Pe("WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),i.texParameteri(T,i.TEXTURE_WRAP_S,Fe[M.wrapS]),i.texParameteri(T,i.TEXTURE_WRAP_T,Fe[M.wrapT]),(T===i.TEXTURE_3D||T===i.TEXTURE_2D_ARRAY)&&i.texParameteri(T,i.TEXTURE_WRAP_R,Fe[M.wrapR]),i.texParameteri(T,i.TEXTURE_MAG_FILTER,vt[M.magFilter]),i.texParameteri(T,i.TEXTURE_MIN_FILTER,vt[M.minFilter]),M.compareFunction&&(i.texParameteri(T,i.TEXTURE_COMPARE_MODE,i.COMPARE_REF_TO_TEXTURE),i.texParameteri(T,i.TEXTURE_COMPARE_FUNC,Le[M.compareFunction])),e.has("EXT_texture_filter_anisotropic")===!0){if(M.magFilter===Dt||M.minFilter!==es&&M.minFilter!==ii||M.type===_n&&e.has("OES_texture_float_linear")===!1)return;if(M.anisotropy>1||n.get(M).__currentAnisotropy){const B=e.get("EXT_texture_filter_anisotropic");i.texParameterf(T,B.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(M.anisotropy,r.getMaxAnisotropy())),n.get(M).__currentAnisotropy=M.anisotropy}}}function tt(T,M){let B=!1;T.__webglInit===void 0&&(T.__webglInit=!0,M.addEventListener("dispose",N),I(M));const te=M.source;let J=p.get(te);J===void 0&&(J={},p.set(te,J));const se=Y(M);if(se!==T.__cacheKey){J[se]===void 0&&(J[se]={texture:i.createTexture(),usedTimes:0},a.memory.textures++,B=!0),J[se].usedTimes++;const he=J[T.__cacheKey];he!==void 0&&(J[T.__cacheKey].usedTimes--,he.usedTimes===0&&z(M)),T.__cacheKey=se,T.__webglTexture=J[se].texture}return B}function Ge(T,M,B){return Math.floor(Math.floor(T/B)/M)}function Pt(T,M,B,te){const se=T.updateRanges;if(se.length===0)t.texSubImage2D(i.TEXTURE_2D,0,0,0,M.width,M.height,B,te,M.data);else{se.sort((R,K)=>R.start-K.start);let he=0;for(let R=1;R<se.length;R++){const K=se[he],W=se[R],le=K.start+K.count,re=Ge(W.start,M.width,4),ae=Ge(K.start,M.width,4);W.start<=le+1&&re===ae&&Ge(W.start+W.count-1,M.width,4)===re?K.count=Math.max(K.count,W.start+W.count-K.start):(++he,se[he]=W)}se.length=he+1;const X=t.getParameter(i.UNPACK_ROW_LENGTH),$=t.getParameter(i.UNPACK_SKIP_PIXELS),oe=t.getParameter(i.UNPACK_SKIP_ROWS);t.pixelStorei(i.UNPACK_ROW_LENGTH,M.width);for(let R=0,K=se.length;R<K;R++){const W=se[R],le=Math.floor(W.start/4),re=Math.ceil(W.count/4),ae=le%M.width,Ee=Math.floor(le/M.width),Be=re,ie=1;t.pixelStorei(i.UNPACK_SKIP_PIXELS,ae),t.pixelStorei(i.UNPACK_SKIP_ROWS,Ee),t.texSubImage2D(i.TEXTURE_2D,0,ae,Ee,Be,ie,B,te,M.data)}T.clearUpdateRanges(),t.pixelStorei(i.UNPACK_ROW_LENGTH,X),t.pixelStorei(i.UNPACK_SKIP_PIXELS,$),t.pixelStorei(i.UNPACK_SKIP_ROWS,oe)}}function Mt(T,M,B){let te=i.TEXTURE_2D;(M.isDataArrayTexture||M.isCompressedArrayTexture)&&(te=i.TEXTURE_2D_ARRAY),M.isData3DTexture&&(te=i.TEXTURE_3D);const J=tt(T,M),se=M.source;t.bindTexture(te,T.__webglTexture,i.TEXTURE0+B);const he=n.get(se);if(se.version!==he.__version||J===!0){if(t.activeTexture(i.TEXTURE0+B),(typeof ImageBitmap<"u"&&M.image instanceof ImageBitmap)===!1){const ie=qe.getPrimaries(qe.workingColorSpace),Ae=M.colorSpace===ni?null:qe.getPrimaries(M.colorSpace),Oe=M.colorSpace===ni||ie===Ae?i.NONE:i.BROWSER_DEFAULT_WEBGL;t.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,M.flipY),t.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,M.premultiplyAlpha),t.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,Oe)}t.pixelStorei(i.UNPACK_ALIGNMENT,M.unpackAlignment);let $=_(M.image,!1,r.maxTextureSize);$=Ce(M,$);const oe=s.convert(M.format,M.colorSpace),R=s.convert(M.type);let K=E(M.internalFormat,oe,R,M.normalized,M.colorSpace,M.isVideoTexture);Qe(te,M);let W;const le=M.mipmaps,re=M.isVideoTexture!==!0,ae=he.__version===void 0||J===!0,Ee=se.dataReady,Be=w(M,$);if(M.isDepthTexture)K=x(M.format===ri,M.type),ae&&(re?t.texStorage2D(i.TEXTURE_2D,1,K,$.width,$.height):t.texImage2D(i.TEXTURE_2D,0,K,$.width,$.height,0,oe,R,null));else if(M.isDataTexture)if(le.length>0){re&&ae&&t.texStorage2D(i.TEXTURE_2D,Be,K,le[0].width,le[0].height);for(let ie=0,Ae=le.length;ie<Ae;ie++)W=le[ie],re?Ee&&t.texSubImage2D(i.TEXTURE_2D,ie,0,0,W.width,W.height,oe,R,W.data):t.texImage2D(i.TEXTURE_2D,ie,K,W.width,W.height,0,oe,R,W.data);M.generateMipmaps=!1}else re?(ae&&t.texStorage2D(i.TEXTURE_2D,Be,K,$.width,$.height),Ee&&Pt(M,$,oe,R)):t.texImage2D(i.TEXTURE_2D,0,K,$.width,$.height,0,oe,R,$.data);else if(M.isCompressedTexture)if(M.isCompressedArrayTexture){re&&ae&&t.texStorage3D(i.TEXTURE_2D_ARRAY,Be,K,le[0].width,le[0].height,$.depth);for(let ie=0,Ae=le.length;ie<Ae;ie++)if(W=le[ie],M.format!==Cn)if(oe!==null)if(re){if(Ee)if(M.layerUpdates.size>0){const Oe=Zc(W.width,W.height,M.format,M.type);for(const me of M.layerUpdates){const je=W.data.subarray(me*Oe/W.data.BYTES_PER_ELEMENT,(me+1)*Oe/W.data.BYTES_PER_ELEMENT);t.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,ie,0,0,me,W.width,W.height,1,oe,je)}}else t.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,ie,0,0,0,W.width,W.height,$.depth,oe,W.data)}else t.compressedTexImage3D(i.TEXTURE_2D_ARRAY,ie,K,W.width,W.height,$.depth,0,W.data,0,0);else Pe("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else re?Ee&&t.texSubImage3D(i.TEXTURE_2D_ARRAY,ie,0,0,0,W.width,W.height,$.depth,oe,R,W.data):t.texImage3D(i.TEXTURE_2D_ARRAY,ie,K,W.width,W.height,$.depth,0,oe,R,W.data);M.layerUpdates.size>0&&M.clearLayerUpdates()}else{re&&ae&&t.texStorage2D(i.TEXTURE_2D,Be,K,le[0].width,le[0].height);for(let ie=0,Ae=le.length;ie<Ae;ie++)W=le[ie],M.format!==Cn?oe!==null?re?Ee&&t.compressedTexSubImage2D(i.TEXTURE_2D,ie,0,0,W.width,W.height,oe,W.data):t.compressedTexImage2D(i.TEXTURE_2D,ie,K,W.width,W.height,0,W.data):Pe("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):re?Ee&&t.texSubImage2D(i.TEXTURE_2D,ie,0,0,W.width,W.height,oe,R,W.data):t.texImage2D(i.TEXTURE_2D,ie,K,W.width,W.height,0,oe,R,W.data)}else if(M.isDataArrayTexture)if(re){if(ae&&t.texStorage3D(i.TEXTURE_2D_ARRAY,Be,K,$.width,$.height,$.depth),Ee)if(M.layerUpdates.size>0){const ie=Zc($.width,$.height,M.format,M.type);for(const Ae of M.layerUpdates){const Oe=$.data.subarray(Ae*ie/$.data.BYTES_PER_ELEMENT,(Ae+1)*ie/$.data.BYTES_PER_ELEMENT);t.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,Ae,$.width,$.height,1,oe,R,Oe)}M.clearLayerUpdates()}else t.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,0,$.width,$.height,$.depth,oe,R,$.data)}else t.texImage3D(i.TEXTURE_2D_ARRAY,0,K,$.width,$.height,$.depth,0,oe,R,$.data);else if(M.isData3DTexture)re?(ae&&t.texStorage3D(i.TEXTURE_3D,Be,K,$.width,$.height,$.depth),Ee&&t.texSubImage3D(i.TEXTURE_3D,0,0,0,0,$.width,$.height,$.depth,oe,R,$.data)):t.texImage3D(i.TEXTURE_3D,0,K,$.width,$.height,$.depth,0,oe,R,$.data);else if(M.isFramebufferTexture){if(ae)if(re)t.texStorage2D(i.TEXTURE_2D,Be,K,$.width,$.height);else{let ie=$.width,Ae=$.height;for(let Oe=0;Oe<Be;Oe++)t.texImage2D(i.TEXTURE_2D,Oe,K,ie,Ae,0,oe,R,null),ie>>=1,Ae>>=1}}else if(M.isHTMLTexture){if("texElementImage2D"in i){const ie=i.canvas;if(ie.hasAttribute("layoutsubtree")||ie.setAttribute("layoutsubtree","true"),$.parentNode!==ie){ie.appendChild($),u.add(M),ie.onpaint=Ae=>{const Oe=Ae.changedElements;for(const me of u)Oe.includes(me.image)&&(me.needsUpdate=!0)},ie.requestPaint();return}if(i.texElementImage2D.length===3)i.texElementImage2D(i.TEXTURE_2D,i.RGBA8,$);else{const Oe=i.RGBA,me=i.RGBA,je=i.UNSIGNED_BYTE;i.texElementImage2D(i.TEXTURE_2D,0,Oe,me,je,$)}i.texParameteri(i.TEXTURE_2D,i.TEXTURE_MIN_FILTER,i.LINEAR),i.texParameteri(i.TEXTURE_2D,i.TEXTURE_WRAP_S,i.CLAMP_TO_EDGE),i.texParameteri(i.TEXTURE_2D,i.TEXTURE_WRAP_T,i.CLAMP_TO_EDGE)}}else if(le.length>0){if(re&&ae){const ie=De(le[0]);t.texStorage2D(i.TEXTURE_2D,Be,K,ie.width,ie.height)}for(let ie=0,Ae=le.length;ie<Ae;ie++)W=le[ie],re?Ee&&t.texSubImage2D(i.TEXTURE_2D,ie,0,0,oe,R,W):t.texImage2D(i.TEXTURE_2D,ie,K,oe,R,W);M.generateMipmaps=!1}else if(re){if(ae){const ie=De($);t.texStorage2D(i.TEXTURE_2D,Be,K,ie.width,ie.height)}Ee&&t.texSubImage2D(i.TEXTURE_2D,0,0,0,oe,R,$)}else t.texImage2D(i.TEXTURE_2D,0,K,oe,R,$);S(M)&&M.mipmapsAutoUpdate===!0&&y(te),he.__version=se.version,M.onUpdate&&M.onUpdate(M)}T.__version=M.version}function $t(T,M,B){if(M.image.length!==6)return;const te=tt(T,M),J=M.source;t.bindTexture(i.TEXTURE_CUBE_MAP,T.__webglTexture,i.TEXTURE0+B);const se=n.get(J);if(J.version!==se.__version||te===!0){t.activeTexture(i.TEXTURE0+B);const he=qe.getPrimaries(qe.workingColorSpace),X=M.colorSpace===ni?null:qe.getPrimaries(M.colorSpace),$=M.colorSpace===ni||he===X?i.NONE:i.BROWSER_DEFAULT_WEBGL;t.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,M.flipY),t.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,M.premultiplyAlpha),t.pixelStorei(i.UNPACK_ALIGNMENT,M.unpackAlignment),t.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,$);const oe=M.isCompressedTexture||M.image[0].isCompressedTexture,R=M.image[0]&&M.image[0].isDataTexture,K=[];for(let me=0;me<6;me++)!oe&&!R?K[me]=_(M.image[me],!0,r.maxCubemapSize):K[me]=R?M.image[me].image:M.image[me],K[me]=Ce(M,K[me]);const W=K[0],le=s.convert(M.format,M.colorSpace),re=s.convert(M.type);let ae=E(M.internalFormat,le,re,M.normalized,M.colorSpace);const Ee=M.isVideoTexture!==!0,Be=se.__version===void 0||te===!0,ie=J.dataReady;let Ae=w(M,W);Qe(i.TEXTURE_CUBE_MAP,M);let Oe;if(M.isDepthTexture){if(ae=x(M.format===ri,M.type),Be)if(Ee)t.texStorage2D(i.TEXTURE_CUBE_MAP,1,ae,W.width,W.height);else for(let me=0;me<6;me++)t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+me,0,ae,W.width,W.height,0,le,re,null)}else if(oe){Ee&&Be&&t.texStorage2D(i.TEXTURE_CUBE_MAP,Ae,ae,W.width,W.height);for(let me=0;me<6;me++){Oe=K[me].mipmaps;for(let je=0;je<Oe.length;je++){const At=Oe[je];M.format!==Cn?le!==null?Ee?ie&&t.compressedTexSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+me,je,0,0,At.width,At.height,le,At.data):t.compressedTexImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+me,je,ae,At.width,At.height,0,At.data):Pe("WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):Ee?ie&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+me,je,0,0,At.width,At.height,le,re,At.data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+me,je,ae,At.width,At.height,0,le,re,At.data)}}}else{if(Oe=M.mipmaps,Ee&&Be){Oe.length>0&&Ae++;const me=De(K[0]);t.texStorage2D(i.TEXTURE_CUBE_MAP,Ae,ae,me.width,me.height)}for(let me=0;me<6;me++)if(R){Ee?ie&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+me,0,0,0,K[me].width,K[me].height,le,re,K[me].data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+me,0,ae,K[me].width,K[me].height,0,le,re,K[me].data);for(let je=0;je<Oe.length;je++){const Yn=Oe[je].image[me].image;Ee?ie&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+me,je+1,0,0,Yn.width,Yn.height,le,re,Yn.data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+me,je+1,ae,Yn.width,Yn.height,0,le,re,Yn.data)}}else{Ee?ie&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+me,0,0,0,le,re,K[me]):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+me,0,ae,le,re,K[me]);for(let je=0;je<Oe.length;je++){const At=Oe[je];Ee?ie&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+me,je+1,0,0,le,re,At.image[me]):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+me,je+1,ae,le,re,At.image[me])}}}S(M)&&M.mipmapsAutoUpdate===!0&&y(i.TEXTURE_CUBE_MAP),se.__version=J.version,M.onUpdate&&M.onUpdate(M)}T.__version=M.version}function ht(T,M,B,te,J,se){const he=s.convert(B.format,B.colorSpace),X=s.convert(B.type),$=E(B.internalFormat,he,X,B.normalized,B.colorSpace),oe=n.get(M),R=n.get(B);if(R.__renderTarget=M,!oe.__hasExternalTextures){const K=Math.max(1,M.width>>se),W=Math.max(1,M.height>>se);J===i.TEXTURE_3D||J===i.TEXTURE_2D_ARRAY?t.texImage3D(J,se,$,K,W,M.depth,0,he,X,null):t.texImage2D(J,se,$,K,W,0,he,X,null)}t.bindFramebuffer(i.FRAMEBUFFER,T),fe(M)?o.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,te,J,R.__webglTexture,0,lt(M)):(J===i.TEXTURE_2D||J>=i.TEXTURE_CUBE_MAP_POSITIVE_X&&J<=i.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&i.framebufferTexture2D(i.FRAMEBUFFER,te,J,R.__webglTexture,se),t.bindFramebuffer(i.FRAMEBUFFER,null)}function wn(T,M,B){if(i.bindRenderbuffer(i.RENDERBUFFER,T),M.depthBuffer){const te=M.depthTexture,J=te&&te.isDepthTexture?te.type:null,se=x(M.stencilBuffer,J),he=M.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT;fe(M)?o.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,lt(M),se,M.width,M.height):B?i.renderbufferStorageMultisample(i.RENDERBUFFER,lt(M),se,M.width,M.height):i.renderbufferStorage(i.RENDERBUFFER,se,M.width,M.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,he,i.RENDERBUFFER,T)}else{const te=M.textures;for(let J=0;J<te.length;J++){const se=te[J],he=s.convert(se.format,se.colorSpace),X=s.convert(se.type),$=E(se.internalFormat,he,X,se.normalized,se.colorSpace);fe(M)?o.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,lt(M),$,M.width,M.height):B?i.renderbufferStorageMultisample(i.RENDERBUFFER,lt(M),$,M.width,M.height):i.renderbufferStorage(i.RENDERBUFFER,$,M.width,M.height)}}i.bindRenderbuffer(i.RENDERBUFFER,null)}function Tt(T,M,B){const te=M.isWebGLCubeRenderTarget===!0;if(t.bindFramebuffer(i.FRAMEBUFFER,T),!(M.depthTexture&&M.depthTexture.isDepthTexture))throw new Error("THREE.WebGLTextures: renderTarget.depthTexture must be an instance of THREE.DepthTexture.");const J=n.get(M.depthTexture);J.__renderTarget=M;const se=te?M.depthTexture.image[0]:M.depthTexture.image;(!J.__webglTexture||se.width!==M.width||se.height!==M.height)&&(se.width=M.width,se.height=M.height,M.depthTexture.needsUpdate=!0),te?ve(M.depthTexture,0):ge(M.depthTexture,0);const he=J.__webglTexture,X=lt(M),$=te?i.TEXTURE_CUBE_MAP_POSITIVE_X+B:i.TEXTURE_2D,oe=M.depthTexture.format===ri?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT;if(M.depthTexture.format===oi)fe(M)?o.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,oe,$,he,0,X):i.framebufferTexture2D(i.FRAMEBUFFER,oe,$,he,0);else if(M.depthTexture.format===ri)fe(M)?o.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,oe,$,he,0,X):i.framebufferTexture2D(i.FRAMEBUFFER,oe,$,he,0);else throw new Error("THREE.WebGLTextures: Unknown depthTexture format.")}function tn(T){const M=n.get(T),B=T.isWebGLCubeRenderTarget===!0;if(M.__boundDepthTexture!==T.depthTexture){const te=T.depthTexture;if(M.__depthDisposeCallback&&M.__depthDisposeCallback(),te){const J=()=>{delete M.__boundDepthTexture,delete M.__depthDisposeCallback,te.removeEventListener("dispose",J)};te.addEventListener("dispose",J),M.__depthDisposeCallback=J}M.__boundDepthTexture=te}if(T.depthTexture&&!M.__autoAllocateDepthBuffer)if(B)for(let te=0;te<6;te++)Tt(M.__webglFramebuffer[te],T,te);else T.texture.mipmaps.length>0?Tt(M.__webglFramebuffer[0],T,0):Tt(M.__webglFramebuffer,T,0);else if(B){M.__webglDepthbuffer=[];for(let te=0;te<6;te++)if(t.bindFramebuffer(i.FRAMEBUFFER,M.__webglFramebuffer[te]),M.__webglDepthbuffer[te]===void 0)M.__webglDepthbuffer[te]=i.createRenderbuffer(),wn(M.__webglDepthbuffer[te],T,!1);else{const J=T.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,se=M.__webglDepthbuffer[te];i.bindRenderbuffer(i.RENDERBUFFER,se),i.framebufferRenderbuffer(i.FRAMEBUFFER,J,i.RENDERBUFFER,se)}}else if(T.texture.mipmaps.length>0?t.bindFramebuffer(i.FRAMEBUFFER,M.__webglFramebuffer[0]):t.bindFramebuffer(i.FRAMEBUFFER,M.__webglFramebuffer),M.__webglDepthbuffer===void 0)M.__webglDepthbuffer=i.createRenderbuffer(),wn(M.__webglDepthbuffer,T,!1);else{const J=T.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,se=M.__webglDepthbuffer;i.bindRenderbuffer(i.RENDERBUFFER,se),i.framebufferRenderbuffer(i.FRAMEBUFFER,J,i.RENDERBUFFER,se)}t.bindFramebuffer(i.FRAMEBUFFER,null)}function nn(T,M,B){const te=n.get(T);M!==void 0&&ht(te.__webglFramebuffer,T,T.texture,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,0),B!==void 0&&tn(T)}function rn(T){const M=T.texture,B=n.get(T),te=n.get(M);T.addEventListener("dispose",F),I(T);const J=T.textures,se=T.isWebGLCubeRenderTarget===!0,he=J.length>1;if(he||(te.__webglTexture===void 0&&(te.__webglTexture=i.createTexture()),te.__version=M.version,a.memory.textures++),se){B.__webglFramebuffer=[];for(let X=0;X<6;X++)if(M.mipmaps.length>0){B.__webglFramebuffer[X]=[];for(let $=0;$<M.mipmaps.length;$++)B.__webglFramebuffer[X][$]=i.createFramebuffer()}else B.__webglFramebuffer[X]=i.createFramebuffer()}else{if(M.mipmaps.length>0){B.__webglFramebuffer=[];for(let X=0;X<M.mipmaps.length;X++)B.__webglFramebuffer[X]=i.createFramebuffer()}else B.__webglFramebuffer=i.createFramebuffer();if(he)for(let X=0,$=J.length;X<$;X++){const oe=n.get(J[X]);oe.__webglTexture===void 0&&(oe.__webglTexture=i.createTexture(),a.memory.textures++)}if(T.samples>0&&fe(T)===!1){B.__webglMultisampledFramebuffer=i.createFramebuffer(),B.__webglColorRenderbuffer=[],t.bindFramebuffer(i.FRAMEBUFFER,B.__webglMultisampledFramebuffer);for(let X=0;X<J.length;X++){const $=J[X];B.__webglColorRenderbuffer[X]=i.createRenderbuffer(),i.bindRenderbuffer(i.RENDERBUFFER,B.__webglColorRenderbuffer[X]);const oe=s.convert($.format,$.colorSpace),R=s.convert($.type),K=E($.internalFormat,oe,R,$.normalized,$.colorSpace,T.isXRRenderTarget===!0),W=lt(T);i.renderbufferStorageMultisample(i.RENDERBUFFER,W,K,T.width,T.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+X,i.RENDERBUFFER,B.__webglColorRenderbuffer[X])}i.bindRenderbuffer(i.RENDERBUFFER,null),T.depthBuffer&&(B.__webglDepthRenderbuffer=i.createRenderbuffer(),wn(B.__webglDepthRenderbuffer,T,!0)),t.bindFramebuffer(i.FRAMEBUFFER,null)}}if(se){t.bindTexture(i.TEXTURE_CUBE_MAP,te.__webglTexture),Qe(i.TEXTURE_CUBE_MAP,M);for(let X=0;X<6;X++)if(M.mipmaps.length>0)for(let $=0;$<M.mipmaps.length;$++)ht(B.__webglFramebuffer[X][$],T,M,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+X,$);else ht(B.__webglFramebuffer[X],T,M,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+X,0);S(M)?y(i.TEXTURE_CUBE_MAP):M.mipmaps.length>0&&i.texParameteri(i.TEXTURE_CUBE_MAP,i.TEXTURE_MAX_LEVEL,M.mipmaps.length-1),t.unbindTexture()}else if(he){for(let X=0,$=J.length;X<$;X++){const oe=J[X],R=n.get(oe);let K=i.TEXTURE_2D;(T.isWebGL3DRenderTarget||T.isWebGLArrayRenderTarget)&&(K=T.isWebGL3DRenderTarget?i.TEXTURE_3D:i.TEXTURE_2D_ARRAY),t.bindTexture(K,R.__webglTexture),Qe(K,oe),ht(B.__webglFramebuffer,T,oe,i.COLOR_ATTACHMENT0+X,K,0),S(oe)&&y(K)}t.unbindTexture()}else{let X=i.TEXTURE_2D;if((T.isWebGL3DRenderTarget||T.isWebGLArrayRenderTarget)&&(X=T.isWebGL3DRenderTarget?i.TEXTURE_3D:i.TEXTURE_2D_ARRAY),t.bindTexture(X,te.__webglTexture),Qe(X,M),M.mipmaps.length>0)for(let $=0;$<M.mipmaps.length;$++)ht(B.__webglFramebuffer[$],T,M,i.COLOR_ATTACHMENT0,X,$);else ht(B.__webglFramebuffer,T,M,i.COLOR_ATTACHMENT0,X,0);S(M)?y(X):M.mipmaps.length>0&&i.texParameteri(X,i.TEXTURE_MAX_LEVEL,M.mipmaps.length-1),t.unbindTexture()}T.depthBuffer&&tn(T)}function U(T){const M=T.textures;for(let B=0,te=M.length;B<te;B++){const J=M[B];if(S(J)&&J.mipmapsAutoUpdate===!0){const se=A(T),he=n.get(J).__webglTexture;t.bindTexture(se,he),y(se),t.unbindTexture()}}}const sn=[];function ot(T){if(T.samples>0){if(fe(T)===!1){const M=T.textures,B=T.width,te=T.height;let J=i.COLOR_BUFFER_BIT;const se=T.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,he=n.get(T),X=M.length>1;if(X)for(let oe=0;oe<M.length;oe++)t.bindFramebuffer(i.FRAMEBUFFER,he.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+oe,i.RENDERBUFFER,null),t.bindFramebuffer(i.FRAMEBUFFER,he.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+oe,i.TEXTURE_2D,null,0);t.bindFramebuffer(i.READ_FRAMEBUFFER,he.__webglMultisampledFramebuffer),T.texture.mipmaps.length>0?t.bindFramebuffer(i.DRAW_FRAMEBUFFER,he.__webglFramebuffer[0]):t.bindFramebuffer(i.DRAW_FRAMEBUFFER,he.__webglFramebuffer);for(let oe=0;oe<M.length;oe++){if(T.resolveDepthBuffer&&(T.depthBuffer&&(J|=i.DEPTH_BUFFER_BIT),T.stencilBuffer&&T.resolveStencilBuffer&&(J|=i.STENCIL_BUFFER_BIT)),X){i.framebufferRenderbuffer(i.READ_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.RENDERBUFFER,he.__webglColorRenderbuffer[oe]);const R=n.get(M[oe]).__webglTexture;i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,R,0)}i.blitFramebuffer(0,0,B,te,0,0,B,te,J,i.NEAREST),l===!0&&(sn.length=0,sn.push(i.COLOR_ATTACHMENT0+oe),T.depthBuffer&&T.storeMultisampledDepthBuffer===!1&&sn.push(se),i.invalidateFramebuffer(i.READ_FRAMEBUFFER,sn))}if(t.bindFramebuffer(i.READ_FRAMEBUFFER,null),t.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),X)for(let oe=0;oe<M.length;oe++){t.bindFramebuffer(i.FRAMEBUFFER,he.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+oe,i.RENDERBUFFER,he.__webglColorRenderbuffer[oe]);const R=n.get(M[oe]).__webglTexture;t.bindFramebuffer(i.FRAMEBUFFER,he.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+oe,i.TEXTURE_2D,R,0)}t.bindFramebuffer(i.DRAW_FRAMEBUFFER,he.__webglMultisampledFramebuffer)}else if(T.depthBuffer&&T.storeMultisampledDepthBuffer===!1&&l){const M=T.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT;i.invalidateFramebuffer(i.DRAW_FRAMEBUFFER,[M])}}}function lt(T){return Math.min(r.maxSamples,T.samples)}function fe(T){const M=n.get(T);return T.samples>0&&e.has("WEBGL_multisampled_render_to_texture")===!0&&M.__useRenderToTexture!==!1}function bt(T){const M=a.render.frame;h.get(T)!==M&&(h.set(T,M),T.update())}function Ce(T,M){const B=T.colorSpace,te=T.format,J=T.type;return T.isCompressedTexture===!0||T.isVideoTexture===!0||B!==Js&&B!==ni&&(qe.getTransfer(B)===et?(te!==Cn||J!==Qt)&&Pe("WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):$e("WebGLTextures: Unsupported texture color space:",B)),M}function De(T){return typeof HTMLImageElement<"u"&&T instanceof HTMLImageElement?(c.width=T.naturalWidth||T.width,c.height=T.naturalHeight||T.height):typeof VideoFrame<"u"&&T instanceof VideoFrame?(c.width=T.displayWidth,c.height=T.displayHeight):(c.width=T.width,c.height=T.height),c}this.allocateTextureUnit=Ne,this.resetTextureUnits=j,this.getTextureUnits=ee,this.setTextureUnits=Se,this.setTexture2D=ge,this.setTexture2DArray=ye,this.setTexture3D=Re,this.setTextureCube=ve,this.rebindTextures=nn,this.setupRenderTarget=rn,this.updateRenderTargetMipmap=U,this.updateMultisampleRenderTarget=ot,this.setupDepthRenderbuffer=tn,this.setupFrameBufferTexture=ht,this.useMultisampledRTT=fe,this.dispose=H}function Rx(i,e){function t(n,r=ni){let s;const a=qe.getTransfer(r);if(n===Qt)return i.UNSIGNED_BYTE;if(n===dl)return i.UNSIGNED_SHORT_4_4_4_4;if(n===fl)return i.UNSIGNED_SHORT_5_5_5_1;if(n===su)return i.UNSIGNED_INT_5_9_9_9_REV;if(n===au)return i.UNSIGNED_INT_10F_11F_11F_REV;if(n===iu)return i.BYTE;if(n===ru)return i.SHORT;if(n===Br)return i.UNSIGNED_SHORT;if(n===ul)return i.INT;if(n===Pn)return i.UNSIGNED_INT;if(n===_n)return i.FLOAT;if(n===Ln)return i.HALF_FLOAT;if(n===ou)return i.ALPHA;if(n===lu)return i.RGB;if(n===Cn)return i.RGBA;if(n===oi)return i.DEPTH_COMPONENT;if(n===ri)return i.DEPTH_STENCIL;if(n===pl)return i.RED;if(n===ml)return i.RED_INTEGER;if(n===Ti)return i.RG;if(n===gl)return i.RG_INTEGER;if(n===vl)return i.RGBA_INTEGER;if(n===Bs||n===ks||n===zs||n===Gs)if(a===et)if(s=e.get("WEBGL_compressed_texture_s3tc_srgb"),s!==null){if(n===Bs)return s.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(n===ks)return s.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(n===zs)return s.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(n===Gs)return s.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(s=e.get("WEBGL_compressed_texture_s3tc"),s!==null){if(n===Bs)return s.COMPRESSED_RGB_S3TC_DXT1_EXT;if(n===ks)return s.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(n===zs)return s.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(n===Gs)return s.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(n===co||n===ho||n===uo||n===fo)if(s=e.get("WEBGL_compressed_texture_pvrtc"),s!==null){if(n===co)return s.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(n===ho)return s.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(n===uo)return s.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(n===fo)return s.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(n===po||n===mo||n===go||n===vo||n===xo||n===Ks||n===_o)if(s=e.get("WEBGL_compressed_texture_etc"),s!==null){if(n===po||n===mo)return a===et?s.COMPRESSED_SRGB8_ETC2:s.COMPRESSED_RGB8_ETC2;if(n===go)return a===et?s.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:s.COMPRESSED_RGBA8_ETC2_EAC;if(n===vo)return s.COMPRESSED_R11_EAC;if(n===xo)return s.COMPRESSED_SIGNED_R11_EAC;if(n===Ks)return s.COMPRESSED_RG11_EAC;if(n===_o)return s.COMPRESSED_SIGNED_RG11_EAC}else return null;if(n===yo||n===Mo||n===bo||n===So||n===wo||n===Eo||n===To||n===Ao||n===Ro||n===Co||n===Po||n===Lo||n===Do||n===Io)if(s=e.get("WEBGL_compressed_texture_astc"),s!==null){if(n===yo)return a===et?s.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:s.COMPRESSED_RGBA_ASTC_4x4_KHR;if(n===Mo)return a===et?s.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:s.COMPRESSED_RGBA_ASTC_5x4_KHR;if(n===bo)return a===et?s.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:s.COMPRESSED_RGBA_ASTC_5x5_KHR;if(n===So)return a===et?s.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:s.COMPRESSED_RGBA_ASTC_6x5_KHR;if(n===wo)return a===et?s.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:s.COMPRESSED_RGBA_ASTC_6x6_KHR;if(n===Eo)return a===et?s.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:s.COMPRESSED_RGBA_ASTC_8x5_KHR;if(n===To)return a===et?s.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:s.COMPRESSED_RGBA_ASTC_8x6_KHR;if(n===Ao)return a===et?s.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:s.COMPRESSED_RGBA_ASTC_8x8_KHR;if(n===Ro)return a===et?s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:s.COMPRESSED_RGBA_ASTC_10x5_KHR;if(n===Co)return a===et?s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:s.COMPRESSED_RGBA_ASTC_10x6_KHR;if(n===Po)return a===et?s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:s.COMPRESSED_RGBA_ASTC_10x8_KHR;if(n===Lo)return a===et?s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:s.COMPRESSED_RGBA_ASTC_10x10_KHR;if(n===Do)return a===et?s.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:s.COMPRESSED_RGBA_ASTC_12x10_KHR;if(n===Io)return a===et?s.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:s.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(n===No||n===Uo||n===Fo)if(s=e.get("EXT_texture_compression_bptc"),s!==null){if(n===No)return a===et?s.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:s.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(n===Uo)return s.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(n===Fo)return s.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(n===Oo||n===Bo||n===Zs||n===ko)if(s=e.get("EXT_texture_compression_rgtc"),s!==null){if(n===Oo)return s.COMPRESSED_RED_RGTC1_EXT;if(n===Bo)return s.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(n===Zs)return s.COMPRESSED_RED_GREEN_RGTC2_EXT;if(n===ko)return s.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return n===nr?i.UNSIGNED_INT_24_8:i[n]!==void 0?i[n]:null}return{convert:t}}const Cx=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,Px=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class Lx{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(e,t){if(this.texture===null){const n=new Ru(e.texture);(e.depthNear!==t.depthNear||e.depthFar!==t.depthFar)&&(this.depthNear=e.depthNear,this.depthFar=e.depthFar),this.texture=n}}getMesh(e){if(this.texture!==null&&this.mesh===null){const t=e.cameras[0].viewport,n=new Xn({vertexShader:Cx,fragmentShader:Px,uniforms:{depthColor:{value:this.texture},depthWidth:{value:t.z},depthHeight:{value:t.w}}});this.mesh=new mt(new li(20,20),n)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class Dx extends Ci{constructor(e,t){super();const n=this;let r=null,s=1,a=null,o="local-floor",l=1,c=null,h=null,u=null,d=null,p=null,g=null;const v=typeof XRWebGLBinding<"u",m=new Lx,f={},_=t.getContextAttributes();let S=null,y=null;const A=[],E=[],x=new de;let w=null,I=null;const C=new cn;C.viewport=new dt;const N=new cn;N.viewport=new dt;const F=[C,N],V=new Vp;let D=null,H=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(Y){let ge=A[Y];return ge===void 0&&(ge=new Ta,A[Y]=ge),ge.getTargetRaySpace()},this.getControllerGrip=function(Y){let ge=A[Y];return ge===void 0&&(ge=new Ta,A[Y]=ge),ge.getGripSpace()},this.getHand=function(Y){let ge=A[Y];return ge===void 0&&(ge=new Ta,A[Y]=ge),ge.getHandSpace()};function Z(Y){const ge=E.indexOf(Y.inputSource);if(ge===-1)return;const ye=A[ge];ye!==void 0&&(ye.update(Y.inputSource,Y.frame,c||a),ye.dispatchEvent({type:Y.type,data:Y.inputSource}))}function z(){r.removeEventListener("select",Z),r.removeEventListener("selectstart",Z),r.removeEventListener("selectend",Z),r.removeEventListener("squeeze",Z),r.removeEventListener("squeezestart",Z),r.removeEventListener("squeezeend",Z),r.removeEventListener("end",z),r.removeEventListener("inputsourceschange",ne);for(let Y=0;Y<A.length;Y++){const ge=E[Y];ge!==null&&(E[Y]=null,A[Y].disconnect(ge))}D=null,H=null,m.reset();for(const Y in f)delete f[Y];if(e.setRenderTarget(S),p=null,d=null,u=null,r=null,y=null,Ne.stop(),n.isPresenting=!1,e.setPixelRatio(w),e.setSize(x.width,x.height,!1),I!==null){const Y=I.camera;Y.fov=I.fov,Y.zoom=I.zoom,Y.updateProjectionMatrix(),I=null}n.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(Y){s=Y,n.isPresenting===!0&&Pe("WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(Y){o=Y,n.isPresenting===!0&&Pe("WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return c||a},this.setReferenceSpace=function(Y){c=Y},this.getBaseLayer=function(){return d!==null?d:p},this.getBinding=function(){return u===null&&v&&(u=new XRWebGLBinding(r,t)),u},this.getFrame=function(){return g},this.getSession=function(){return r},this.setSession=async function(Y){if(r=Y,r!==null){if(S=e.getRenderTarget(),r.addEventListener("select",Z),r.addEventListener("selectstart",Z),r.addEventListener("selectend",Z),r.addEventListener("squeeze",Z),r.addEventListener("squeezestart",Z),r.addEventListener("squeezeend",Z),r.addEventListener("end",z),r.addEventListener("inputsourceschange",ne),_.xrCompatible!==!0&&await t.makeXRCompatible(),w=e.getPixelRatio(),e.getSize(x),v&&"createProjectionLayer"in XRWebGLBinding.prototype){let ye=null,Re=null,ve=null;_.depth&&(ve=_.stencil?t.DEPTH24_STENCIL8:t.DEPTH_COMPONENT24,ye=_.stencil?ri:oi,Re=_.stencil?nr:Pn);const Fe={colorFormat:t.RGBA8,depthFormat:ve,scaleFactor:s};u=this.getBinding(),d=u.createProjectionLayer(Fe),r.updateRenderState({layers:[d]}),e.setPixelRatio(1),e.setSize(d.textureWidth,d.textureHeight,!1),y=new Mn(d.textureWidth,d.textureHeight,{format:Cn,type:Qt,depthTexture:new ir(d.textureWidth,d.textureHeight,Re,void 0,void 0,void 0,void 0,void 0,void 0,ye),stencilBuffer:_.stencil,colorSpace:e.outputColorSpace,samples:_.antialias?4:0,resolveDepthBuffer:d.ignoreDepthValues===!1,resolveStencilBuffer:d.ignoreDepthValues===!1,storeMultisampledDepthBuffer:d.ignoreDepthValues===!1,storeMultisampledStencilBuffer:d.ignoreDepthValues===!1})}else{const ye={antialias:_.antialias,alpha:!0,depth:_.depth,stencil:_.stencil,framebufferScaleFactor:s};p=new XRWebGLLayer(r,t,ye),r.updateRenderState({baseLayer:p}),e.setPixelRatio(1),e.setSize(p.framebufferWidth,p.framebufferHeight,!1),y=new Mn(p.framebufferWidth,p.framebufferHeight,{format:Cn,type:Qt,colorSpace:e.outputColorSpace,stencilBuffer:_.stencil,resolveDepthBuffer:p.ignoreDepthValues===!1,resolveStencilBuffer:p.ignoreDepthValues===!1,storeMultisampledDepthBuffer:p.ignoreDepthValues===!1,storeMultisampledStencilBuffer:p.ignoreDepthValues===!1})}y.isXRRenderTarget=!0,this.setFoveation(l),c=null,a=await r.requestReferenceSpace(o),Ne.setContext(r),Ne.start(),n.isPresenting=!0,n.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(r!==null)return r.environmentBlendMode},this.getDepthTexture=function(){return m.getDepthTexture()};function ne(Y){for(let ge=0;ge<Y.removed.length;ge++){const ye=Y.removed[ge],Re=E.indexOf(ye);Re>=0&&(E[Re]=null,A[Re].disconnect(ye))}for(let ge=0;ge<Y.added.length;ge++){const ye=Y.added[ge];let Re=E.indexOf(ye);if(Re===-1){for(let Fe=0;Fe<A.length;Fe++)if(Fe>=E.length){E.push(ye),Re=Fe;break}else if(E[Fe]===null){E[Fe]=ye,Re=Fe;break}if(Re===-1)break}const ve=A[Re];ve&&ve.connect(ye)}}function q(Y,ge){ge===null?Y.matrixWorld.copy(Y.matrix):Y.matrixWorld.multiplyMatrices(ge.matrixWorld,Y.matrix),Y.matrixWorldInverse.copy(Y.matrixWorld).invert()}this.updateCamera=function(Y){if(r===null)return;let ge=Y.near,ye=Y.far;m.texture!==null&&(m.depthNear>0&&(ge=m.depthNear),m.depthFar>0&&(ye=m.depthFar)),V.near=N.near=C.near=ge,V.far=N.far=C.far=ye,(D!==V.near||H!==V.far)&&(r.updateRenderState({depthNear:V.near,depthFar:V.far}),D=V.near,H=V.far),V.layers.mask=Y.layers.mask|6,C.layers.mask=V.layers.mask&-5,N.layers.mask=V.layers.mask&-3;const Re=Y.parent,ve=V.cameras;q(V,Re);for(let Fe=0;Fe<ve.length;Fe++)q(ve[Fe],Re);V.projectionMatrix.copy(C.projectionMatrix),V.projectionMatrixInverse.copy(C.projectionMatrixInverse),I===null&&Y.isPerspectiveCamera&&(I={camera:Y,fov:Y.fov,zoom:Y.zoom}),j(Y,V,Re)};function j(Y,ge,ye){ye===null?Y.matrix.copy(ge.matrixWorld):(Y.matrix.copy(ye.matrixWorld),Y.matrix.invert(),Y.matrix.multiply(ge.matrixWorld)),Y.matrix.decompose(Y.position,Y.quaternion,Y.scale),Y.updateMatrixWorld(!0),Y.projectionMatrix.copy(ge.projectionMatrix),Y.projectionMatrixInverse.copy(ge.projectionMatrixInverse),Y.isPerspectiveCamera&&(Y.fov=zr*2*Math.atan(1/Y.projectionMatrix.elements[5]),Y.zoom=1)}this.getCamera=function(){return V},this.getFoveation=function(){if(!(d===null&&p===null))return l},this.setFoveation=function(Y){l=Y,d!==null&&(d.fixedFoveation=Y),p!==null&&p.fixedFoveation!==void 0&&(p.fixedFoveation=Y)},this.hasDepthSensing=function(){return m.texture!==null},this.getDepthSensingMesh=function(){return m.getMesh(V)},this.getCameraTexture=function(Y){return f[Y]};let ee=null;function Se(Y,ge){if(h=ge.getViewerPose(c||a),g=ge,h!==null){const ye=h.views;p!==null&&(e.setRenderTargetFramebuffer(y,p.framebuffer),e.setRenderTarget(y));let Re=!1;ye.length!==V.cameras.length&&(V.cameras.length=0,Re=!0);for(let Le=0;Le<ye.length;Le++){const Qe=ye[Le];let tt=null;if(p!==null)tt=p.getViewport(Qe);else{const Pt=u.getViewSubImage(d,Qe);tt=Pt.viewport,Le===0&&(e.setRenderTargetTextures(y,Pt.colorTexture,Pt.depthStencilTexture),e.setRenderTarget(y))}let Ge=F[Le];Ge===void 0&&(Ge=new cn,Ge.layers.enable(Le),Ge.viewport=new dt,F[Le]=Ge),Ge.matrix.fromArray(Qe.transform.matrix),Ge.matrix.decompose(Ge.position,Ge.quaternion,Ge.scale),Ge.projectionMatrix.fromArray(Qe.projectionMatrix),Ge.projectionMatrixInverse.copy(Ge.projectionMatrix).invert(),Ge.viewport.set(tt.x,tt.y,tt.width,tt.height),Le===0&&(V.matrix.copy(Ge.matrix),V.matrix.decompose(V.position,V.quaternion,V.scale)),Re===!0&&V.cameras.push(Ge)}const ve=r.enabledFeatures;if(ve&&ve.includes("depth-sensing")&&r.depthUsage=="gpu-optimized"&&v){u=n.getBinding();const Le=u.getDepthInformation(ye[0]);Le&&Le.isValid&&Le.texture&&m.init(Le,r.renderState)}if(ve&&ve.includes("camera-access")&&v){e.state.unbindTexture(),u=n.getBinding();for(let Le=0;Le<ye.length;Le++){const Qe=ye[Le].camera;if(Qe){let tt=f[Qe];tt||(tt=new Ru,f[Qe]=tt);const Ge=u.getCameraImage(Qe);tt.sourceTexture=Ge}}}}for(let ye=0;ye<A.length;ye++){const Re=E[ye],ve=A[ye];Re!==null&&ve!==void 0&&ve.update(Re,ge,c||a)}ee&&ee(Y,ge),ge.detectedPlanes&&n.dispatchEvent({type:"planesdetected",data:ge}),g=null}const Ne=new Hu;Ne.setAnimationLoop(Se),this.setAnimationLoop=function(Y){ee=Y},this.dispose=function(){}}}const Ix=new Ye,Qu=new Ie;Qu.set(-1,0,0,0,1,0,0,0,1);function Nx(i,e){function t(m,f){m.matrixAutoUpdate===!0&&m.updateMatrix(),f.value.copy(m.matrix)}function n(m,f){f.color.getRGB(m.fogColor.value,Bu(i)),f.isFog?(m.fogNear.value=f.near,m.fogFar.value=f.far):f.isFogExp2&&(m.fogDensity.value=f.density)}function r(m,f,_,S,y){f.isNodeMaterial?f.uniformsNeedUpdate=!1:f.isMeshBasicMaterial?s(m,f):f.isMeshLambertMaterial?(s(m,f),f.envMap&&(m.envMapIntensity.value=f.envMapIntensity)):f.isMeshToonMaterial?(s(m,f),u(m,f)):f.isMeshPhongMaterial?(s(m,f),h(m,f),f.envMap&&(m.envMapIntensity.value=f.envMapIntensity)):f.isMeshStandardMaterial?(s(m,f),d(m,f),f.isMeshPhysicalMaterial&&p(m,f,y)):f.isMeshMatcapMaterial?(s(m,f),g(m,f)):f.isMeshDepthMaterial?s(m,f):f.isMeshDistanceMaterial?(s(m,f),v(m,f)):f.isMeshNormalMaterial?s(m,f):f.isLineBasicMaterial?(a(m,f),f.isLineDashedMaterial&&o(m,f)):f.isPointsMaterial?l(m,f,_,S):f.isSpriteMaterial?c(m,f):f.isShadowMaterial?(m.color.value.copy(f.color),m.opacity.value=f.opacity):f.isShaderMaterial&&(f.uniformsNeedUpdate=!1)}function s(m,f){m.opacity.value=f.opacity,f.color&&m.diffuse.value.copy(f.color),f.emissive&&m.emissive.value.copy(f.emissive).multiplyScalar(f.emissiveIntensity),f.map&&(m.map.value=f.map,t(f.map,m.mapTransform)),f.alphaMap&&(m.alphaMap.value=f.alphaMap,t(f.alphaMap,m.alphaMapTransform)),f.bumpMap&&(m.bumpMap.value=f.bumpMap,t(f.bumpMap,m.bumpMapTransform),m.bumpScale.value=f.bumpScale,f.side===qt&&(m.bumpScale.value*=-1)),f.normalMap&&(m.normalMap.value=f.normalMap,t(f.normalMap,m.normalMapTransform),m.normalScale.value.copy(f.normalScale),f.side===qt&&m.normalScale.value.negate()),f.displacementMap&&(m.displacementMap.value=f.displacementMap,t(f.displacementMap,m.displacementMapTransform),m.displacementScale.value=f.displacementScale,m.displacementBias.value=f.displacementBias),f.emissiveMap&&(m.emissiveMap.value=f.emissiveMap,t(f.emissiveMap,m.emissiveMapTransform)),f.specularMap&&(m.specularMap.value=f.specularMap,t(f.specularMap,m.specularMapTransform)),f.alphaTest>0&&(m.alphaTest.value=f.alphaTest);const _=e.get(f),S=_.envMap,y=_.envMapRotation;S&&(m.envMap.value=S,m.envMapRotation.value.setFromMatrix4(Ix.makeRotationFromEuler(y)).transpose(),S.isCubeTexture&&S.isRenderTargetTexture===!1&&m.envMapRotation.value.premultiply(Qu),m.reflectivity.value=f.reflectivity,m.ior.value=f.ior,m.refractionRatio.value=f.refractionRatio),f.lightMap&&(m.lightMap.value=f.lightMap,m.lightMapIntensity.value=f.lightMapIntensity,t(f.lightMap,m.lightMapTransform)),f.aoMap&&(m.aoMap.value=f.aoMap,m.aoMapIntensity.value=f.aoMapIntensity,t(f.aoMap,m.aoMapTransform))}function a(m,f){m.diffuse.value.copy(f.color),m.opacity.value=f.opacity,f.map&&(m.map.value=f.map,t(f.map,m.mapTransform))}function o(m,f){m.dashSize.value=f.dashSize,m.totalSize.value=f.dashSize+f.gapSize,m.scale.value=f.scale}function l(m,f,_,S){m.diffuse.value.copy(f.color),m.opacity.value=f.opacity,m.size.value=f.size*_,m.scale.value=S*.5,f.map&&(m.map.value=f.map,t(f.map,m.uvTransform)),f.alphaMap&&(m.alphaMap.value=f.alphaMap,t(f.alphaMap,m.alphaMapTransform)),f.alphaTest>0&&(m.alphaTest.value=f.alphaTest)}function c(m,f){m.diffuse.value.copy(f.color),m.opacity.value=f.opacity,m.rotation.value=f.rotation,f.map&&(m.map.value=f.map,t(f.map,m.mapTransform)),f.alphaMap&&(m.alphaMap.value=f.alphaMap,t(f.alphaMap,m.alphaMapTransform)),f.alphaTest>0&&(m.alphaTest.value=f.alphaTest)}function h(m,f){m.specular.value.copy(f.specular),m.shininess.value=Math.max(f.shininess,1e-4)}function u(m,f){f.gradientMap&&(m.gradientMap.value=f.gradientMap)}function d(m,f){m.metalness.value=f.metalness,f.metalnessMap&&(m.metalnessMap.value=f.metalnessMap,t(f.metalnessMap,m.metalnessMapTransform)),m.roughness.value=f.roughness,f.roughnessMap&&(m.roughnessMap.value=f.roughnessMap,t(f.roughnessMap,m.roughnessMapTransform)),f.envMap&&(m.envMapIntensity.value=f.envMapIntensity)}function p(m,f,_){m.ior.value=f.ior,f.diffuseRoughness>0&&(m.diffuseRoughness.value=f.diffuseRoughness,f.diffuseRoughnessMap&&(m.diffuseRoughnessMap.value=f.diffuseRoughnessMap,t(f.diffuseRoughnessMap,m.diffuseRoughnessMapTransform))),f.sheen>0&&(m.sheenColor.value.copy(f.sheenColor).multiplyScalar(f.sheen),m.sheenRoughness.value=f.sheenRoughness,f.sheenColorMap&&(m.sheenColorMap.value=f.sheenColorMap,t(f.sheenColorMap,m.sheenColorMapTransform)),f.sheenRoughnessMap&&(m.sheenRoughnessMap.value=f.sheenRoughnessMap,t(f.sheenRoughnessMap,m.sheenRoughnessMapTransform))),f.clearcoat>0&&(m.clearcoat.value=f.clearcoat,m.clearcoatRoughness.value=f.clearcoatRoughness,f.clearcoatMap&&(m.clearcoatMap.value=f.clearcoatMap,t(f.clearcoatMap,m.clearcoatMapTransform)),f.clearcoatRoughnessMap&&(m.clearcoatRoughnessMap.value=f.clearcoatRoughnessMap,t(f.clearcoatRoughnessMap,m.clearcoatRoughnessMapTransform)),f.clearcoatNormalMap&&(m.clearcoatNormalMap.value=f.clearcoatNormalMap,t(f.clearcoatNormalMap,m.clearcoatNormalMapTransform),m.clearcoatNormalScale.value.copy(f.clearcoatNormalScale),f.side===qt&&m.clearcoatNormalScale.value.negate())),f.dispersion>0&&(m.dispersion.value=f.dispersion),f.retroreflectivity>0&&(m.retroreflectivity.value=f.retroreflectivity),f.iridescence>0&&(m.iridescence.value=f.iridescence,m.iridescenceIOR.value=f.iridescenceIOR,m.iridescenceThicknessMinimum.value=f.iridescenceThicknessMinimum,m.iridescenceThicknessMaximum.value=f.iridescenceThicknessMaximum,f.iridescenceMap&&(m.iridescenceMap.value=f.iridescenceMap,t(f.iridescenceMap,m.iridescenceMapTransform)),f.iridescenceThicknessMap&&(m.iridescenceThicknessMap.value=f.iridescenceThicknessMap,t(f.iridescenceThicknessMap,m.iridescenceThicknessMapTransform))),f.transmission>0&&(m.transmission.value=f.transmission,m.transmissionSamplerMap.value=_.texture,m.transmissionSamplerSize.value.set(_.width,_.height),f.transmissionMap&&(m.transmissionMap.value=f.transmissionMap,t(f.transmissionMap,m.transmissionMapTransform)),m.thickness.value=f.thickness,f.thicknessMap&&(m.thicknessMap.value=f.thicknessMap,t(f.thicknessMap,m.thicknessMapTransform)),m.attenuationDistance.value=f.attenuationDistance,m.attenuationColor.value.copy(f.attenuationColor)),f.anisotropy>0&&(m.anisotropyVector.value.set(f.anisotropy*Math.cos(f.anisotropyRotation),f.anisotropy*Math.sin(f.anisotropyRotation)),f.anisotropyMap&&(m.anisotropyMap.value=f.anisotropyMap,t(f.anisotropyMap,m.anisotropyMapTransform))),m.specularIntensity.value=f.specularIntensity,m.specularColor.value.copy(f.specularColor),f.specularColorMap&&(m.specularColorMap.value=f.specularColorMap,t(f.specularColorMap,m.specularColorMapTransform)),f.specularIntensityMap&&(m.specularIntensityMap.value=f.specularIntensityMap,t(f.specularIntensityMap,m.specularIntensityMapTransform))}function g(m,f){f.matcap&&(m.matcap.value=f.matcap)}function v(m,f){const _=e.get(f).light;m.referencePosition.value.setFromMatrixPosition(_.matrixWorld),m.nearDistance.value=_.shadow.camera.near,m.farDistance.value=_.shadow.camera.far}return{refreshFogUniforms:n,refreshMaterialUniforms:r}}function Ux(i,e,t,n){let r={},s={};function a(_,S){const y=S.program;n.uniformBlockBinding(_,y,r[_.id])}function o(_,S){let y=r[_.id];y===void 0&&(g(_),y=l(_),r[_.id]=y,_.addEventListener("dispose",m));const A=S.program;n.updateUBOMapping(_,A);const E=e.render.frame;s[_.id]!==E&&(c(_),s[_.id]=E)}function l(_){const S=i.createBuffer(),y=_.__size,A=_.usage;return i.bindBuffer(i.UNIFORM_BUFFER,S),i.bufferData(i.UNIFORM_BUFFER,y,A),i.bindBuffer(i.UNIFORM_BUFFER,null),S}function c(_){const S=r[_.id],y=_.uniforms,A=_.__cache;i.bindBuffer(i.UNIFORM_BUFFER,S);for(let E=0,x=y.length;E<x;E++){const w=y[E];if(Array.isArray(w))for(let I=0,C=w.length;I<C;I++)h(w[I],E,I,A);else h(w,E,0,A)}i.bindBuffer(i.UNIFORM_BUFFER,null)}function h(_,S,y,A){if(d(_,S,y,A)===!0){const E=_.__offset,x=_.value;if(Array.isArray(x)){let w=0;for(let I=0;I<x.length;I++){const C=x[I],N=v(C,!0);u(C,_.__data,w),w+=N.storage/Float32Array.BYTES_PER_ELEMENT}}else u(x,_.__data,0);i.bufferSubData(i.UNIFORM_BUFFER,E,_.__data)}}function u(_,S,y){typeof _=="number"||typeof _=="boolean"?S[y]=_:_.isMatrix3?(S[y]=_.elements[0],S[y+1]=_.elements[1],S[y+2]=_.elements[2],S[y+3]=0,S[y+4]=_.elements[3],S[y+5]=_.elements[4],S[y+6]=_.elements[5],S[y+7]=0,S[y+8]=_.elements[6],S[y+9]=_.elements[7],S[y+10]=_.elements[8],S[y+11]=0):ArrayBuffer.isView(_)?S.set(_.subarray(0,S.length-y),y):_.toArray(S,y)}function d(_,S,y,A){const E=_.value,x=S+"_"+y;if(Array.isArray(E)){A[x]===void 0&&(A[x]=[]);const w=A[x];let I=!1;for(let C=0;C<E.length;C++)p(E[C],w,C)===!0&&(I=!0);return I}return p(E,A,x)}function p(_,S,y){if(S[y]===void 0)return typeof _=="number"||typeof _=="boolean"?S[y]=_:ArrayBuffer.isView(_)?S[y]=_.slice():S[y]=_.clone(),!0;{const A=S[y];if(typeof _=="number"||typeof _=="boolean"){if(A!==_)return S[y]=_,!0}else{if(ArrayBuffer.isView(_))return!0;if(A.equals(_)===!1)return A.copy(_),!0}}return!1}function g(_){const S=_.uniforms;let y=0;const A=16;for(let x=0,w=S.length;x<w;x++){const I=Array.isArray(S[x])?S[x]:[S[x]];for(let C=0,N=I.length;C<N;C++){const F=I[C],V=Array.isArray(F.value)?F.value:[F.value],D=Array.isArray(S[x])||Array.isArray(F.value);let H=y;for(let z=0,ne=V.length;z<ne;z++){const q=V[z],j=v(q,D),ee=y%A,Se=ee%j.boundary,Ne=ee+Se;y+=Se,Ne!==0&&A-Ne<j.storage&&(y+=A-Ne),z===0&&(H=y),y+=j.storage}const Z=F.type==="int"?Int32Array:F.type==="uint"?Uint32Array:Float32Array;F.__data=new Z((y-H)/Float32Array.BYTES_PER_ELEMENT),F.__offset=H}}const E=y%A;return E>0&&(y+=A-E),_.__size=y,_.__cache={},this}function v(_,S){const y={boundary:0,storage:0};return typeof _=="number"||typeof _=="boolean"?(y.boundary=4,y.storage=4):_.isVector2?(y.boundary=8,y.storage=8):_.isVector3||_.isColor?(y.boundary=16,y.storage=12):_.isVector4?(y.boundary=16,y.storage=16):_.isMatrix3?(y.boundary=16,y.storage=48):_.isMatrix4?(y.boundary=16,y.storage=64):_.isTexture?Pe("WebGLRenderer: Texture samplers can not be part of an uniforms group."):ArrayBuffer.isView(_)?(y.boundary=16,y.storage=_.byteLength):Pe("WebGLRenderer: Unsupported uniform value type.",_),S===!0&&(y.boundary=16,y.storage=Math.ceil(y.storage/16)*16),y}function m(_){const S=_.target;S.removeEventListener("dispose",m),i.deleteBuffer(r[S.id]),delete r[S.id],delete s[S.id]}function f(){for(const _ in r)i.deleteBuffer(r[_]);r={},s={}}return{bind:a,update:o,dispose:f}}const Fx=new Uint16Array([12469,15057,12620,14925,13266,14620,13807,14376,14323,13990,14545,13625,14713,13328,14840,12882,14931,12528,14996,12233,15039,11829,15066,11525,15080,11295,15085,10976,15082,10705,15073,10495,13880,14564,13898,14542,13977,14430,14158,14124,14393,13732,14556,13410,14702,12996,14814,12596,14891,12291,14937,11834,14957,11489,14958,11194,14943,10803,14921,10506,14893,10278,14858,9960,14484,14039,14487,14025,14499,13941,14524,13740,14574,13468,14654,13106,14743,12678,14818,12344,14867,11893,14889,11509,14893,11180,14881,10751,14852,10428,14812,10128,14765,9754,14712,9466,14764,13480,14764,13475,14766,13440,14766,13347,14769,13070,14786,12713,14816,12387,14844,11957,14860,11549,14868,11215,14855,10751,14825,10403,14782,10044,14729,9651,14666,9352,14599,9029,14967,12835,14966,12831,14963,12804,14954,12723,14936,12564,14917,12347,14900,11958,14886,11569,14878,11247,14859,10765,14828,10401,14784,10011,14727,9600,14660,9289,14586,8893,14508,8533,15111,12234,15110,12234,15104,12216,15092,12156,15067,12010,15028,11776,14981,11500,14942,11205,14902,10752,14861,10393,14812,9991,14752,9570,14682,9252,14603,8808,14519,8445,14431,8145,15209,11449,15208,11451,15202,11451,15190,11438,15163,11384,15117,11274,15055,10979,14994,10648,14932,10343,14871,9936,14803,9532,14729,9218,14645,8742,14556,8381,14461,8020,14365,7603,15273,10603,15272,10607,15267,10619,15256,10631,15231,10614,15182,10535,15118,10389,15042,10167,14963,9787,14883,9447,14800,9115,14710,8665,14615,8318,14514,7911,14411,7507,14279,7198,15314,9675,15313,9683,15309,9712,15298,9759,15277,9797,15229,9773,15166,9668,15084,9487,14995,9274,14898,8910,14800,8539,14697,8234,14590,7790,14479,7409,14367,7067,14178,6621,15337,8619,15337,8631,15333,8677,15325,8769,15305,8871,15264,8940,15202,8909,15119,8775,15022,8565,14916,8328,14804,8009,14688,7614,14569,7287,14448,6888,14321,6483,14088,6171,15350,7402,15350,7419,15347,7480,15340,7613,15322,7804,15287,7973,15229,8057,15148,8012,15046,7846,14933,7611,14810,7357,14682,7069,14552,6656,14421,6316,14251,5948,14007,5528,15356,5942,15356,5977,15353,6119,15348,6294,15332,6551,15302,6824,15249,7044,15171,7122,15070,7050,14949,6861,14818,6611,14679,6349,14538,6067,14398,5651,14189,5311,13935,4958,15359,4123,15359,4153,15356,4296,15353,4646,15338,5160,15311,5508,15263,5829,15188,6042,15088,6094,14966,6001,14826,5796,14678,5543,14527,5287,14377,4985,14133,4586,13869,4257,15360,1563,15360,1642,15358,2076,15354,2636,15341,3350,15317,4019,15273,4429,15203,4732,15105,4911,14981,4932,14836,4818,14679,4621,14517,4386,14359,4156,14083,3795,13808,3437,15360,122,15360,137,15358,285,15355,636,15344,1274,15322,2177,15281,2765,15215,3223,15120,3451,14995,3569,14846,3567,14681,3466,14511,3305,14344,3121,14037,2800,13753,2467,15360,0,15360,1,15359,21,15355,89,15346,253,15325,479,15287,796,15225,1148,15133,1492,15008,1749,14856,1882,14685,1886,14506,1783,14324,1608,13996,1398,13702,1183]);let An=null;function Ox(){return An===null&&(An=new bu(Fx,16,16,Ti,Ln),An.name="DFG_LUT",An.minFilter=Yt,An.magFilter=Yt,An.wrapS=Vn,An.wrapT=Vn,An.generateMipmaps=!1,An.needsUpdate=!0),An}class Bx{constructor(e={}){const{canvas:t=cf(),context:n=null,depth:r=!0,stencil:s=!1,alpha:a=!1,antialias:o=!1,premultipliedAlpha:l=!0,preserveDrawingBuffer:c=!1,powerPreference:h="default",failIfMajorPerformanceCaveat:u=!1,reversedDepthBuffer:d=!1,outputBufferType:p=Qt}=e;this.isWebGLRenderer=!0;let g;if(n!==null){if(typeof WebGLRenderingContext<"u"&&n instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");g=n.getContextAttributes().alpha}else g=a;const v=p,m=new Set([vl,gl,ml]),f=new Set([Qt,Pn,Br,nr,dl,fl]),_=new Uint32Array(4),S=new Int32Array(4),y={textures:[],min:[],max:[],resolution:[]};let A=null,E=null;const x=[],w=[];let I=null;this.domElement=t,this.debug={checkShaderErrors:!0,diagnostics:{keywords:!1},onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=Wn,this.toneMappingExposure=1,this.transmissionResolutionScale=1;const C=this;let N=!1,F=null,V=null,D=null,H=null;this._outputColorSpace=Ot;let Z=0,z=0,ne=null,q=-1,j=null;const ee=new dt,Se=new dt;let Ne=null;const Y=new Te(0);let ge=0,ye=t.width,Re=t.height,ve=1,Fe=null,vt=null;const Le=new dt(0,0,ye,Re),Qe=new dt(0,0,ye,Re);let tt=!1;const Ge=new Gr,Pt=new wl;let Mt=!1,$t=!1;const ht=new Ye,wn=new P,Tt=new dt,tn={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let nn=!1;function rn(){return ne===null?ve:1}let U=n;function sn(b,L){return t.getContext(b,L)}let ot,lt,fe,bt,Ce,De,T,M,B,te,J,se,he,X,$,oe,R,K,W,le,re,ae,Ee;try{const b={alpha:!0,depth:r,stencil:s,antialias:o,premultipliedAlpha:l,preserveDrawingBuffer:c,powerPreference:h,failIfMajorPerformanceCaveat:u};if("setAttribute"in t&&t.setAttribute("data-engine",`three.js r${cl}`),t.addEventListener("webglcontextlost",Ae,!1),t.addEventListener("webglcontextrestored",Oe,!1),t.addEventListener("webglcontextcreationerror",me,!1),U===null){const L="webgl2";if(U=sn(L,b),U===null)throw sn(L)?new Error("THREE.WebGLRenderer: Error creating WebGL context with your selected attributes."):new Error("THREE.WebGLRenderer: Error creating WebGL context.")}Be()}catch(b){throw t.removeEventListener("webglcontextlost",Ae,!1),t.removeEventListener("webglcontextrestored",Oe,!1),t.removeEventListener("webglcontextcreationerror",me,!1),$e("WebGLRenderer: "+b.message),b}function Be(){ot=new Gg(U),ot.init(),re=new Rx(U,ot),lt=new Pg(U,ot,e,re),fe=new Tx(U,ot),lt.reversedDepthBuffer&&d&&fe.buffers.depth.setReversed(!0),V=U.createFramebuffer(),D=U.createFramebuffer(),H=U.createFramebuffer(),bt=new Wg(U),Ce=new dx,De=new Ax(U,ot,fe,Ce,lt,re,bt),T=new zg(C),M=new Xp(U),ae=new Rg(U,M),B=new Hg(U,M,bt,ae),te=new Xg(U,B,M,ae,bt),K=new qg(U,lt,De),$=new Lg(Ce),J=new ux(C,T,ot,lt,ae,$),se=new Nx(C,Ce),he=new px,X=new yx(ot),R=new Ag(C,T,fe,te,g,l),oe=new Ex(C,te,lt),Ee=new Ux(U,bt,lt,fe),W=new Cg(U,ot,bt),le=new Vg(U,ot,bt),bt.programs=J.programs,C.capabilities=lt,C.extensions=ot,C.properties=Ce,C.renderLists=he,C.shadowMap=oe,C.state=fe,C.info=bt}v!==Qt&&(I=new Yg(v,t.width,t.height,o,r,s));const ie=new Dx(C,U);this.xr=ie,this.getContext=function(){return U},this.getContextAttributes=function(){return U.getContextAttributes()},this.forceContextLoss=function(){const b=ot.get("WEBGL_lose_context");b&&b.loseContext()},this.forceContextRestore=function(){const b=ot.get("WEBGL_lose_context");b&&b.restoreContext()},this.getPixelRatio=function(){return ve},this.setPixelRatio=function(b){b!==void 0&&(ve=b,this.setSize(ye,Re,!1))},this.getSize=function(b){return b.set(ye,Re)},this.setSize=function(b,L,G=!0){if(ie.isPresenting){Pe("WebGLRenderer: Can't change size while VR device is presenting.");return}ye=b,Re=L,t.width=Math.floor(b*ve),t.height=Math.floor(L*ve),G===!0&&(t.style.width=b+"px",t.style.height=L+"px"),I!==null&&I.setSize(t.width,t.height),this.setViewport(0,0,b,L)},this.getDrawingBufferSize=function(b){return b.set(ye*ve,Re*ve).floor()},this.setDrawingBufferSize=function(b,L,G){ye=b,Re=L,ve=G,t.width=Math.floor(b*G),t.height=Math.floor(L*G),this.setViewport(0,0,b,L)},this.setEffects=function(b){if(v===Qt){$e("WebGLRenderer: setEffects() requires outputBufferType set to HalfFloatType or FloatType.");return}if(b){for(let L=0;L<b.length;L++)if(b[L].isOutputPass===!0){Pe("WebGLRenderer: OutputPass is not needed in setEffects(). Tone mapping and color space conversion are applied automatically.");break}}I.setEffects(b||[])},this.getCurrentViewport=function(b){return b.copy(ee)},this.getViewport=function(b){return b.copy(Le)},this.setViewport=function(b,L,G,O){b.isVector4?Le.set(b.x,b.y,b.z,b.w):Le.set(b,L,G,O),fe.viewport(ee.copy(Le).multiplyScalar(rn()).round())},this.getScissor=function(b){return b.copy(Qe)},this.setScissor=function(b,L,G,O){b.isVector4?Qe.set(b.x,b.y,b.z,b.w):Qe.set(b,L,G,O),fe.scissor(Se.copy(Qe).multiplyScalar(rn()).round())},this.getScissorTest=function(){return tt},this.setScissorTest=function(b){fe.setScissorTest(tt=b)},this.setOpaqueSort=function(b){Fe=b},this.setTransparentSort=function(b){vt=b},this.getClearColor=function(b){return b.copy(R.getClearColor())},this.setClearColor=function(){R.setClearColor(...arguments)},this.getClearAlpha=function(){return R.getClearAlpha()},this.setClearAlpha=function(){R.setClearAlpha(...arguments)},this.clear=function(b=!0,L=!0,G=!0){let O=0;if(b){let k=!1;if(ne!==null){const ue=ne.texture.format;k=m.has(ue)}if(k){const ue=ne.texture.type,_e=f.has(ue),ce=R.getClearColor(),xe=R.getClearAlpha(),we=ce.r,Ue=ce.g,He=ce.b;_e?(_[0]=we,_[1]=Ue,_[2]=He,_[3]=xe,U.clearBufferuiv(U.COLOR,0,_)):(S[0]=we,S[1]=Ue,S[2]=He,S[3]=xe,U.clearBufferiv(U.COLOR,0,S))}else O|=U.COLOR_BUFFER_BIT}L&&(O|=U.DEPTH_BUFFER_BIT,this.state.buffers.depth.setMask(!0)),G&&(O|=U.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),O!==0&&U.clear(O)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.setNodesHandler=function(b){b.setRenderer(this),F=b},this.dispose=function(){t.removeEventListener("webglcontextlost",Ae,!1),t.removeEventListener("webglcontextrestored",Oe,!1),t.removeEventListener("webglcontextcreationerror",me,!1),R.dispose(),he.dispose(),X.dispose(),De.dispose(),Ce.dispose(),T.dispose(),te.dispose(),B.dispose(),ae.dispose(),Ee.dispose(),J.dispose(),ie.dispose(),ie.removeEventListener("sessionstart",kl),ie.removeEventListener("sessionend",zl),pi.stop()};function Ae(b){b.preventDefault(),ea("WebGLRenderer: Context Lost."),N=!0}function Oe(){ea("WebGLRenderer: Context Restored."),N=!1;const b=bt.autoReset,L=oe.enabled,G=oe.autoUpdate,O=oe.needsUpdate,k=oe.type;Be(),bt.autoReset=b,oe.enabled=L,oe.autoUpdate=G,oe.needsUpdate=O,oe.type=k}function me(b){$e("WebGLRenderer: A WebGL context could not be created. Reason: ",b.statusMessage)}function je(b){const L=b.target;L.removeEventListener("dispose",je),At(L)}function At(b){Yn(b),Ce.remove(b)}function Yn(b){const L=Ce.get(b).programs;L!==void 0&&(L.forEach(function(G){J.releaseProgram(G)}),b.isShaderMaterial&&J.releaseShaderCache(b))}this.renderBufferDirect=function(b,L,G,O,k,ue){L===null&&(L=tn);const _e=k.isMesh&&k.matrixWorld.determinantAffine()<0,ce=rd(b,L,G,O,k);fe.setMaterial(O,_e);let xe=G.index,we=1;if(O.wireframe===!0){if(xe=B.getWireframeAttribute(G),xe===void 0)return;we=2}const Ue=G.drawRange,He=G.attributes.position;let Me=Ue.start*we,Ve=(Ue.start+Ue.count)*we;ue!==null&&(Me=Math.max(Me,ue.start*we),Ve=Math.min(Ve,(ue.start+ue.count)*we)),xe!==null?(Me=Math.max(Me,0),Ve=Math.min(Ve,xe.count)):He!=null&&(Me=Math.max(Me,0),Ve=Math.min(Ve,He.count));const xt=Ve-Me;if(xt<0||xt===1/0)return;ae.setup(k,O,ce,G,xe);let it,nt=W;if(xe!==null&&(it=M.get(xe),nt=le,nt.setIndex(it)),k.isMesh)O.wireframe===!0?(fe.setLineWidth(O.wireframeLinewidth*rn()),nt.setMode(U.LINES)):nt.setMode(U.TRIANGLES);else if(k.isLine){let It=O.linewidth;It===void 0&&(It=1),fe.setLineWidth(It*rn()),k.isLineSegments?nt.setMode(U.LINES):k.isLineLoop?nt.setMode(U.LINE_LOOP):nt.setMode(U.LINE_STRIP)}else k.isPoints?nt.setMode(U.POINTS):k.isSprite&&nt.setMode(U.TRIANGLES);if(k.isBatchedMesh)if(ot.get("WEBGL_multi_draw"))nt.renderMultiDraw(k._multiDrawStarts,k._multiDrawCounts,k._multiDrawCount);else{const It=k._multiDrawStarts,be=k._multiDrawCounts,zt=k._multiDrawCount,Ze=xe?M.get(xe).bytesPerElement:1,mi=Ce.get(O).currentProgram.getUniforms();for(let Nt=0;Nt<zt;Nt++)mi.setValue(U,"_gl_DrawID",Nt),nt.render(It[Nt]/Ze,be[Nt])}else if(k.isInstancedMesh)nt.renderInstances(Me,xt,k.count);else if(G.isInstancedBufferGeometry){const It=G._maxInstanceCount!==void 0?G._maxInstanceCount:1/0,be=Math.min(G.instanceCount,It);nt.renderInstances(Me,xt,be)}else nt.render(Me,xt)};function Bl(b,L,G,O){F!==null&&b.isNodeMaterial&&F.setObject(O,b),Mt===!0&&$.setState(b,G,!1),b.transparent===!0&&b.side===xn&&b.forceSinglePass===!1?(b.side=qt,b.needsUpdate=!0,cr(b,L,O),b.side=Ei,b.needsUpdate=!0,cr(b,L,O),b.side=xn):cr(b,L,O)}this.compile=function(b,L,G=null){G===null&&(G=b),F!==null&&F.renderStart(b,L,G),E=X.get(G),E.init(L),w.push(E),G.traverseVisible(function(k){k.isLight&&k.layers.test(L.layers)&&(E.pushLight(k),k.castShadow&&E.pushShadow(k))}),b!==G&&b.traverseVisible(function(k){k.isLight&&k.layers.test(L.layers)&&(E.pushLight(k),k.castShadow&&E.pushShadow(k))}),E.setupLights(),F!==null&&F.updateLights(E.state.lightsArray),$t=this.localClippingEnabled,Mt=$.init(this.clippingPlanes,$t),Mt===!0&&$.setGlobalState(this.clippingPlanes,L),F!==null&&oe.render(E.state.shadowsArray,G,L);const O=new Set;return b.traverse(function(k){if(!(k.isMesh||k.isPoints||k.isLine||k.isSprite))return;const ue=k.material;if(ue)if(Array.isArray(ue))for(let _e=0;_e<ue.length;_e++){const ce=ue[_e];Bl(ce,G,L,k),O.add(ce)}else Bl(ue,G,L,k),O.add(ue)}),E=w.pop(),F!==null&&F.renderEnd(),O},this.compileAsync=function(b,L,G=null){const O=this.compile(b,L,G);return new Promise(k=>{function ue(){if(O.forEach(function(_e){const xe=Ce.get(_e).currentProgram;(xe===void 0||xe.isReady())&&O.delete(_e)}),O.size===0){k(b);return}setTimeout(ue,10)}ot.get("KHR_parallel_shader_compile")!==null?ue():setTimeout(ue,10)})};let fa=null;function nd(b){fa&&fa(b)}function kl(){pi.stop()}function zl(){pi.start()}const pi=new Hu;pi.setAnimationLoop(nd),typeof self<"u"&&pi.setContext(self),this.setAnimationLoop=function(b){fa=b,ie.setAnimationLoop(b),b===null?pi.stop():pi.start()},ie.addEventListener("sessionstart",kl),ie.addEventListener("sessionend",zl),this.render=function(b,L){if(L!==void 0&&L.isCamera!==!0){$e("WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(N===!0)return;F!==null&&F.renderStart(b,L);const G=ie.enabled===!0&&ie.isPresenting===!0,O=I!==null&&(ne===null||G)&&I.begin(C,ne);if(b.matrixWorldAutoUpdate===!0&&b.updateMatrixWorld(),L.parent===null&&L.matrixWorldAutoUpdate===!0&&L.updateMatrixWorld(),ie.enabled===!0&&ie.isPresenting===!0&&(I===null||I.isCompositing()===!1)&&(ie.cameraAutoUpdate===!0&&ie.updateCamera(L),L=ie.getCamera()),b.isScene===!0&&b.onBeforeRender(C,b,L,ne),E=X.get(b,w.length),E.init(L),E.state.textureUnits=De.getTextureUnits(),w.push(E),ht.multiplyMatrices(L.projectionMatrix,L.matrixWorldInverse),L.isArrayCamera?Pt.setFromArrayCamera(L):Ge.setFromProjectionMatrix(ht,yn,L.reversedDepth),$t=this.localClippingEnabled,Mt=$.init(this.clippingPlanes,$t),A=he.get(b,x.length),A.init(),x.push(A),this.info.render.frame++,ie.enabled===!0&&ie.isPresenting===!0){const _e=C.xr.getDepthSensingMesh();_e!==null&&pa(_e,L,-1/0,C.sortObjects)}pa(b,L,0,C.sortObjects),A.finish(),F!==null&&F.updateLights(E.state.lightsArray),C.sortObjects===!0&&A.sort(Fe,vt),nn=ie.enabled===!1||ie.isPresenting===!1||ie.hasDepthSensing()===!1,nn&&R.addToRenderList(A,b),this.info.autoReset===!0&&this.info.reset(),Mt===!0&&$.beginShadows();const k=E.state.shadowsArray;if(oe.render(k,b,L),Mt===!0&&$.endShadows(),(O&&I.hasRenderPass())===!1){const _e=A.opaque,ce=A.transmissive;if(E.setupLights(),L.isArrayCamera){const xe=L.cameras;if(ce.length>0)for(let we=0,Ue=xe.length;we<Ue;we++){const He=xe[we];Hl(_e,ce,b,He)}nn&&R.render(b);for(let we=0,Ue=xe.length;we<Ue;we++){const He=xe[we];Gl(A,b,He,He.viewport)}}else ce.length>0&&Hl(_e,ce,b,L),nn&&R.render(b),Gl(A,b,L)}ne!==null&&z===0&&(De.updateMultisampleRenderTarget(ne),De.updateRenderTargetMipmap(ne)),O&&I.end(C),b.isScene===!0&&b.onAfterRender(C,b,L),ae.resetDefaultState(),q=-1,j=null,w.pop(),w.length>0?(E=w[w.length-1],De.setTextureUnits(E.state.textureUnits),Mt===!0&&$.setGlobalState(C.clippingPlanes,E.state.camera)):E=null,x.pop(),x.length>0?A=x[x.length-1]:A=null,F!==null&&F.renderEnd()};function pa(b,L,G,O){if(b.visible===!1)return;if(b.layers.test(L.layers)){if(b.isGroup)G=b.renderOrder;else if(b.isLOD)b.autoUpdate===!0&&b.update(L);else if(b.isLight)E.pushLight(b),b.castShadow&&E.pushShadow(b);else if(b.isSprite){const _e=L.isArrayCamera?Pt:Ge;if(!b.frustumCulled||b.intersectsFrustum(_e)){O&&Tt.setFromMatrixPosition(b.matrixWorld).applyMatrix4(ht);const ce=te.update(b),xe=b.material;xe.visible&&A.push(b,ce,xe,G,Tt.z,null,L)}}else if(b.isMesh||b.isLine||b.isPoints){const _e=L.isArrayCamera?Pt:Ge;if(!b.frustumCulled||b.intersectsFrustum(_e)){const ce=te.update(b),xe=b.material;if(O&&(b.boundingSphere!==void 0?(b.boundingSphere===null&&b.computeBoundingSphere(),Tt.copy(b.boundingSphere.center)):(ce.boundingSphere===null&&ce.computeBoundingSphere(),Tt.copy(ce.boundingSphere.center)),Tt.applyMatrix4(b.matrixWorld).applyMatrix4(ht)),Array.isArray(xe)){const we=ce.groups;for(let Ue=0,He=we.length;Ue<He;Ue++){const Me=we[Ue],Ve=xe[Me.materialIndex];Ve&&Ve.visible&&A.push(b,ce,Ve,G,Tt.z,Me,L)}}else xe.visible&&A.push(b,ce,xe,G,Tt.z,null,L)}}}const ue=b.children;for(let _e=0,ce=ue.length;_e<ce;_e++)pa(ue[_e],L,G,O)}function Gl(b,L,G,O){const{opaque:k,transmissive:ue,transparent:_e}=b;E.setupLightsView(G),Mt===!0&&$.setGlobalState(C.clippingPlanes,G),O&&fe.viewport(ee.copy(O)),k.length>0&&Kr(k,L,G),ue.length>0&&Kr(ue,L,G),_e.length>0&&Kr(_e,L,G),fe.buffers.depth.setTest(!0),fe.buffers.depth.setMask(!0),fe.buffers.color.setMask(!0),fe.setPolygonOffset(!1)}function Hl(b,L,G,O){if((G.isScene===!0?G.overrideMaterial:null)!==null)return;if(E.state.transmissionRenderTarget[O.id]===void 0){const Me=ot.has("EXT_color_buffer_half_float")||ot.has("EXT_color_buffer_float");E.state.transmissionRenderTarget[O.id]=new Mn(1,1,{generateMipmaps:!0,type:Me?Ln:Qt,minFilter:ii,samples:Math.max(4,lt.samples),stencilBuffer:s,resolveDepthBuffer:!1,resolveStencilBuffer:!1,storeMultisampledDepthBuffer:!1,storeMultisampledStencilBuffer:!1,colorSpace:qe.workingColorSpace})}const ue=E.state.transmissionRenderTarget[O.id],_e=O.viewport||ee;ue.setSize(_e.z*C.transmissionResolutionScale,_e.w*C.transmissionResolutionScale);const ce=C.getRenderTarget(),xe=C.getActiveCubeFace(),we=C.getActiveMipmapLevel();C.setRenderTarget(ue),C.getClearColor(Y),ge=C.getClearAlpha(),ge<1&&C.setClearColor(16777215,.5),C.clear(),nn&&R.render(G);const Ue=C.toneMapping;C.toneMapping=Wn;const He=O.viewport;if(O.viewport!==void 0&&(O.viewport=void 0),E.setupLightsView(O),Mt===!0&&$.setGlobalState(C.clippingPlanes,O),Kr(b,G,O),De.updateMultisampleRenderTarget(ue),De.updateRenderTargetMipmap(ue),ot.has("WEBGL_multisampled_render_to_texture")===!1){let Me=!1;for(let Ve=0,xt=L.length;Ve<xt;Ve++){const it=L[Ve],{object:nt,geometry:It,material:be,group:zt}=it;if(be.side===xn&&nt.layers.test(O.layers)){const Ze=be.side;be.side=qt,be.needsUpdate=!0,Vl(nt,G,O,It,be,zt),be.side=Ze,be.needsUpdate=!0,Me=!0}}Me===!0&&(De.updateMultisampleRenderTarget(ue),De.updateRenderTargetMipmap(ue))}C.setRenderTarget(ce,xe,we),C.setClearColor(Y,ge),He!==void 0&&(O.viewport=He),C.toneMapping=Ue}function Kr(b,L,G){const O=L.isScene===!0?L.overrideMaterial:null;for(let k=0,ue=b.length;k<ue;k++){const _e=b[k],{object:ce,geometry:xe,group:we}=_e;let Ue=_e.material;Ue.allowOverride===!0&&O!==null&&(Ue=O),ce.layers.test(G.layers)&&Vl(ce,L,G,xe,Ue,we)}}function Vl(b,L,G,O,k,ue){F!==null&&k.isNodeMaterial&&F.setObject(b,k),b.onBeforeRender(C,L,G,O,k,ue),b.modelViewMatrix.multiplyMatrices(G.matrixWorldInverse,b.matrixWorld),b.normalMatrix.getNormalMatrix(b.modelViewMatrix),k.onBeforeRender(C,L,G,O,b,ue),k.transparent===!0&&k.side===xn&&k.forceSinglePass===!1?(k.side=qt,k.needsUpdate=!0,C.renderBufferDirect(G,L,O,k,b,ue),k.side=Ei,k.needsUpdate=!0,C.renderBufferDirect(G,L,O,k,b,ue),k.side=xn):C.renderBufferDirect(G,L,O,k,b,ue),b.onAfterRender(C,L,G,O,k,ue)}function Wl(b){let L=0;for(const G of b)G.texture!==null&&L++;return L}function cr(b,L,G){L.isScene!==!0&&(L=tn);const O=Ce.get(b),k=E.state.lights,ue=E.state.shadowsArray,_e=k.state.version,ce=J.getParameters(b,k.state,ue,L,G,E.state.lightProbeGridArray),xe=J.getProgramCacheKey(ce);let we=O.programs;O.environment=b.isMeshStandardMaterial||b.isMeshLambertMaterial||b.isMeshPhongMaterial?L.environment:null,O.fog=L.fog;const Ue=b.isMeshStandardMaterial||b.isMeshLambertMaterial&&!b.envMap||b.isMeshPhongMaterial&&!b.envMap;O.envMap=T.get(b.envMap||O.environment,Ue),O.envMapRotation=O.environment!==null&&b.envMap===null?L.environmentRotation:b.envMapRotation,we===void 0&&(b.addEventListener("dispose",je),we=new Map,O.programs=we,O.programVariants=new Map);let He=we.get(xe);if(He!==void 0){if(O.currentProgram===He&&O.lightsStateVersion===_e)return Xl(b,ce),He}else ce.uniforms=J.getUniforms(b),F!==null&&b.isNodeMaterial&&F.build(b,G,ce),b.onBeforeCompile(ce,C),He=J.acquireProgram(ce,xe),we.set(xe,He),O.uniforms=ce.uniforms;const Me=O.uniforms;return(!b.isShaderMaterial&&!b.isRawShaderMaterial||b.clipping===!0)&&(Me.clippingPlanes=$.uniform),Xl(b,ce),O.needsLights=ad(b),O.lightsStateVersion=_e,O.needsLights&&(Me.ambientLightColor.value=k.state.ambient,Me.lightProbe.value=k.state.probe,Me.sunLights.value=k.state.sun,Me.sunLightShadows.value=k.state.sunShadow,Me.directionalLights.value=k.state.directional,Me.directionalLightShadows.value=k.state.directionalShadow,Me.spotLights.value=k.state.spot,Me.spotLightShadows.value=k.state.spotShadow,Me.rectAreaLights.value=k.state.rectArea,Me.ltc_1.value=k.state.rectAreaLTC1,Me.ltc_2.value=k.state.rectAreaLTC2,Me.pointLights.value=k.state.point,Me.pointLightShadows.value=k.state.pointShadow,Me.hemisphereLights.value=k.state.hemi,Me.sunShadowMatrix.value=k.state.sunShadowMatrix,Me.sunShadowCascade.value=k.state.sunShadowCascade,Me.directionalShadowMatrix.value=k.state.directionalShadowMatrix,Me.spotLightMatrix.value=k.state.spotLightMatrix,Me.spotLightMap.value=k.state.spotLightMap,Me.pointShadowMatrix.value=k.state.pointShadowMatrix),O.numLightProbeGrids=Wl(E.state.lightProbeGridArray),O.currentProgram=He,O.uniformsList=null,He}function id(b,L,G,O,k){const ue=Ce.get(b),_e=ue.currentProgram.id+","+O+","+k;let ce=ue.programVariants.get(_e);return ce===void 0?(ce=cr(b,L,G),ue.programVariants.set(_e,ce)):(ue.currentProgram=ce,ue.uniformsList=null,ue.outputColorSpace=O,ue.toneMapping=k),ce}function ql(b){if(b.uniformsList===null){const L=b.currentProgram.getUniforms();b.uniformsList=Vs.seqWithValue(L.seq,b.uniforms)}return b.uniformsList}function Xl(b,L){const G=Ce.get(b);G.outputColorSpace=L.outputColorSpace,G.batching=L.batching,G.batchingColor=L.batchingColor,G.instancing=L.instancing,G.instancingColor=L.instancingColor,G.instancingMorph=L.instancingMorph,G.skinning=L.skinning,G.morphTargets=L.morphTargets,G.morphNormals=L.morphNormals,G.morphColors=L.morphColors,G.morphTargetsCount=L.morphTargetsCount,G.numClippingPlanes=L.numClippingPlanes,G.numIntersection=L.numClipIntersection,G.vertexAlphas=L.vertexAlphas,G.vertexTangents=L.vertexTangents,G.toneMapping=L.toneMapping}function rd(b,L,G,O,k){L.isScene!==!0&&(L=tn),De.resetTextureUnits();const ue=L.fog,_e=O.isMeshStandardMaterial||O.isMeshLambertMaterial||O.isMeshPhongMaterial?L.environment:null,ce=ne===null?C.outputColorSpace:ne.isXRRenderTarget===!0?ne.texture.colorSpace:qe.workingColorSpace,xe=O.isMeshStandardMaterial||O.isMeshLambertMaterial&&!O.envMap||O.isMeshPhongMaterial&&!O.envMap,we=T.get(O.envMap||_e,xe),Ue=O.vertexColors===!0&&!!G.attributes.color&&G.attributes.color.itemSize===4,He=!!G.attributes.tangent&&(!!O.normalMap||O.anisotropy>0),Me=!!G.morphAttributes.position,Ve=!!G.morphAttributes.normal,xt=!!G.morphAttributes.color;let it=Wn;O.toneMapped&&(ne===null||ne.isXRRenderTarget===!0)&&(it=C.toneMapping);const nt=G.morphAttributes.position||G.morphAttributes.normal||G.morphAttributes.color,It=nt!==void 0?nt.length:0,be=Ce.get(O),zt=E.state.lights;if(Mt===!0&&($t===!0||b!==j)){const ut=b===j&&O.id===q;$.setState(O,b,ut)}let Ze=!1,mi=!1;O.version===be.__version?be.needsLights&&be.lightsStateVersion!==zt.state.version||k.isBatchedMesh&&be.batching===!1||!k.isBatchedMesh&&be.batching===!0||k.isBatchedMesh&&be.batchingColor===!0&&k._colorsTexture===null||k.isBatchedMesh&&be.batchingColor===!1&&k._colorsTexture!==null||k.isInstancedMesh&&be.instancing===!1||!k.isInstancedMesh&&be.instancing===!0||k.isSkinnedMesh&&be.skinning===!1||!k.isSkinnedMesh&&be.skinning===!0||k.isInstancedMesh&&be.instancingColor===!0&&k.instanceColor===null||k.isInstancedMesh&&be.instancingColor===!1&&k.instanceColor!==null||k.isInstancedMesh&&be.instancingMorph===!0&&k.morphTexture===null||k.isInstancedMesh&&be.instancingMorph===!1&&k.morphTexture!==null||be.envMap!==we||O.fog===!0&&be.fog!==ue||be.numClippingPlanes!==void 0&&(be.numClippingPlanes!==$.numPlanes||be.numIntersection!==$.numIntersection)||be.vertexAlphas!==Ue||be.vertexTangents!==He||be.morphTargets!==Me||be.morphNormals!==Ve||be.morphColors!==xt||be.morphTargetsCount!==It||be.numLightProbeGrids!==Wl(E.state.lightProbeGridArray)?Ze=!0:(be.outputColorSpace!==ce||be.toneMapping!==it)&&(mi=!0):(Ze=!0,be.__version=O.version);let Nt=be.currentProgram;(Ze===!0||mi===!0)&&(Nt=mi===!0?id(O,L,k,ce,it):cr(O,L,k),F&&O.isNodeMaterial&&F.onUpdateProgram(O,Nt,be));let Zr=!1,Kn=!1,gi=!1;const Xe=Nt.getUniforms(),Lt=be.uniforms;if(fe.useProgram(Nt.program)&&(Zr=!0,Kn=!0,gi=!0),O.id!==q&&(q=O.id,Kn=!0),Zr||j!==b){fe.buffers.depth.getReversed()&&b.reversedDepth!==!0&&(b._reversedDepth=!0,b.updateProjectionMatrix()),Xe.setValue(U,"projectionMatrix",b.projectionMatrix),Xe.setValue(U,"viewMatrix",b.matrixWorldInverse);const Rt=Xe.map.cameraPosition;Rt!==void 0&&Rt.setValue(U,wn.setFromMatrixPosition(b.matrixWorld)),lt.logarithmicDepthBuffer&&Xe.setValue(U,"logDepthBufFC",2/(Math.log(b.far+1)/Math.LN2)),(O.isMeshPhongMaterial||O.isMeshToonMaterial||O.isMeshLambertMaterial||O.isMeshBasicMaterial||O.isMeshStandardMaterial||O.isShaderMaterial)&&Xe.setValue(U,"isOrthographic",b.isOrthographicCamera===!0),j!==b&&(j=b,Kn=!0,gi=!0)}if(be.needsLights&&(zt.state.sunShadowMap.length>0&&Xe.setValue(U,"sunShadowMap",zt.state.sunShadowMap,De),zt.state.directionalShadowMap.length>0&&Xe.setValue(U,"directionalShadowMap",zt.state.directionalShadowMap,De),zt.state.spotShadowMap.length>0&&Xe.setValue(U,"spotShadowMap",zt.state.spotShadowMap,De),zt.state.pointShadowMap.length>0&&Xe.setValue(U,"pointShadowMap",zt.state.pointShadowMap,De)),k.isSkinnedMesh){Xe.setOptional(U,k,"bindMatrix"),Xe.setOptional(U,k,"bindMatrixInverse");const ut=k.skeleton;ut&&(ut.boneTexture===null&&ut.computeBoneTexture(),Xe.setValue(U,"boneTexture",ut.boneTexture,De))}k.isBatchedMesh&&(Xe.setOptional(U,k,"batchingTexture"),Xe.setValue(U,"batchingTexture",k._matricesTexture,De),Xe.setOptional(U,k,"batchingIdTexture"),Xe.setValue(U,"batchingIdTexture",k._indirectTexture,De),Xe.setOptional(U,k,"batchingColorTexture"),k._colorsTexture!==null&&Xe.setValue(U,"batchingColorTexture",k._colorsTexture,De));const un=G.morphAttributes;if((un.position!==void 0||un.normal!==void 0||un.color!==void 0)&&K.update(k,G,Nt),(Kn||be.receiveShadow!==k.receiveShadow)&&(be.receiveShadow=k.receiveShadow,Xe.setValue(U,"receiveShadow",k.receiveShadow)),(O.isMeshStandardMaterial||O.isMeshLambertMaterial||O.isMeshPhongMaterial)&&O.envMap===null&&L.environment!==null&&(Lt.envMapIntensity.value=L.environmentIntensity),Lt.dfgLUT!==void 0&&(Lt.dfgLUT.value=Ox()),Kn){if(Xe.setValue(U,"toneMappingExposure",C.toneMappingExposure),be.needsLights&&sd(Lt,gi),ue&&O.fog===!0&&se.refreshFogUniforms(Lt,ue),se.refreshMaterialUniforms(Lt,O,ve,Re,E.state.transmissionRenderTarget[b.id]),be.needsLights&&be.numLightProbeGrids>0){const ut=y;let Rt=0;for(const Nn of E.state.lightProbeGridArray)Nn.texture!==null&&(ut.textures[Rt]=Nn.texture,ut.min[Rt]=Nn.boundingBox.min,ut.max[Rt]=Nn.boundingBox.max,ut.resolution[Rt]=Nn.resolution,Rt++);for(const Nn in ut)ut[Nn].length=Rt;Lt.probesSH.value=ut.textures,Lt.probesMin.value=ut.min,Lt.probesMax.value=ut.max,Lt.probesResolution.value=ut.resolution}Vs.upload(U,ql(be),Lt,De)}if(O.isShaderMaterial&&O.uniformsNeedUpdate===!0&&(Vs.upload(U,ql(be),Lt,De),O.uniformsNeedUpdate=!1),O.isSpriteMaterial&&Xe.setValue(U,"center",k.center),Xe.setValue(U,"modelViewMatrix",k.modelViewMatrix),Xe.setValue(U,"normalMatrix",k.normalMatrix),Xe.setValue(U,"modelMatrix",k.matrixWorld),O.uniformsGroups!==void 0){const ut=O.uniformsGroups;for(let Rt=0,Nn=ut.length;Rt<Nn;Rt++){const Yl=ut[Rt];Ee.update(Yl,Nt),Ee.bind(Yl,Nt)}}return Nt}function sd(b,L){b.ambientLightColor.needsUpdate=L,b.lightProbe.needsUpdate=L,b.sunLights.needsUpdate=L,b.sunLightShadows.needsUpdate=L,b.directionalLights.needsUpdate=L,b.directionalLightShadows.needsUpdate=L,b.pointLights.needsUpdate=L,b.pointLightShadows.needsUpdate=L,b.spotLights.needsUpdate=L,b.spotLightShadows.needsUpdate=L,b.rectAreaLights.needsUpdate=L,b.hemisphereLights.needsUpdate=L}function ad(b){return b.isMeshLambertMaterial||b.isMeshToonMaterial||b.isMeshPhongMaterial||b.isMeshStandardMaterial||b.isShadowMaterial||b.isShaderMaterial&&b.lights===!0}this.getActiveCubeFace=function(){return Z},this.getActiveMipmapLevel=function(){return z},this.getRenderTarget=function(){return ne},this.setRenderTargetTextures=function(b,L,G){const O=Ce.get(b);O.__autoAllocateDepthBuffer=b.resolveDepthBuffer===!1,O.__autoAllocateDepthBuffer===!1&&(O.__useRenderToTexture=!1),Ce.get(b.texture).__webglTexture=L,Ce.get(b.depthTexture).__webglTexture=O.__autoAllocateDepthBuffer?void 0:G,O.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(b,L){const G=Ce.get(b);G.__webglFramebuffer=L,G.__useDefaultFramebuffer=L===void 0},this.setRenderTarget=function(b,L=0,G=0){ne=b,Z=L,z=G;let O=null,k=!1,ue=!1;if(b){const ce=Ce.get(b);if(ce.__useDefaultFramebuffer!==void 0){fe.bindFramebuffer(U.FRAMEBUFFER,ce.__webglFramebuffer),ee.copy(b.viewport),Se.copy(b.scissor),Ne=b.scissorTest,fe.viewport(ee),fe.scissor(Se),fe.setScissorTest(Ne),q=-1;return}else if(ce.__webglFramebuffer===void 0)De.setupRenderTarget(b);else if(ce.__hasExternalTextures)De.rebindTextures(b,Ce.get(b.texture).__webglTexture,Ce.get(b.depthTexture).__webglTexture);else if(b.depthBuffer){const Ue=b.depthTexture;if(ce.__boundDepthTexture!==Ue){if(Ue!==null&&Ce.has(Ue)&&(b.width!==Ue.image.width||b.height!==Ue.image.height))throw new Error("THREE.WebGLRenderer: Attached DepthTexture is initialized to the incorrect size.");De.setupDepthRenderbuffer(b)}}const xe=b.texture;(xe.isData3DTexture||xe.isDataArrayTexture||xe.isCompressedArrayTexture)&&(ue=!0);const we=Ce.get(b).__webglFramebuffer;b.isWebGLCubeRenderTarget?(Array.isArray(we[L])?O=we[L][G]:O=we[L],k=!0):b.samples>0&&De.useMultisampledRTT(b)===!1?O=Ce.get(b).__webglMultisampledFramebuffer:Array.isArray(we)?O=we[G]:O=we,ee.copy(b.viewport),Se.copy(b.scissor),Ne=b.scissorTest}else ee.copy(Le).multiplyScalar(ve).floor(),Se.copy(Qe).multiplyScalar(ve).floor(),Ne=tt;if(G!==0&&(O=V),fe.bindFramebuffer(U.FRAMEBUFFER,O)&&fe.drawBuffers(b,O),fe.viewport(ee),fe.scissor(Se),fe.setScissorTest(Ne),k){const ce=Ce.get(b.texture);U.framebufferTexture2D(U.FRAMEBUFFER,U.COLOR_ATTACHMENT0,U.TEXTURE_CUBE_MAP_POSITIVE_X+L,ce.__webglTexture,G)}else if(ue){const ce=L;for(let xe=0;xe<b.textures.length;xe++){const we=Ce.get(b.textures[xe]);U.framebufferTextureLayer(U.FRAMEBUFFER,U.COLOR_ATTACHMENT0+xe,we.__webglTexture,G,ce)}}else if(b!==null&&G!==0){const ce=Ce.get(b.texture);U.framebufferTexture2D(U.FRAMEBUFFER,U.COLOR_ATTACHMENT0,U.TEXTURE_2D,ce.__webglTexture,G)}q=-1};function $l(b){const L=Ce.get(b);return(L.__readFormat!==b.format||L.__readType!==b.type)&&(L.__readFormat=b.format,L.__readType=b.type,L.__formatReadable=lt.textureFormatReadable(b.format),L.__typeReadable=lt.textureTypeReadable(b.type)),L}this.readRenderTargetPixels=function(b,L,G,O,k,ue,_e,ce=0){if(!(b&&b.isWebGLRenderTarget)){$e("WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let xe=Ce.get(b).__webglFramebuffer;if(b.isWebGLCubeRenderTarget&&_e!==void 0&&(xe=xe[_e],Array.isArray(xe)&&(xe=xe[0])),xe){fe.bindFramebuffer(U.FRAMEBUFFER,xe);try{const we=b.textures[ce],Ue=we.format,He=we.type;b.textures.length>1&&U.readBuffer(U.COLOR_ATTACHMENT0+ce);const Me=$l(we);if(Me.__formatReadable===!1){$e("WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(Me.__typeReadable===!1){$e("WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}L>=0&&L<=b.width-O&&G>=0&&G<=b.height-k&&U.readPixels(L,G,O,k,re.convert(Ue),re.convert(He),ue)}finally{const we=ne!==null?Ce.get(ne).__webglFramebuffer:null;fe.bindFramebuffer(U.FRAMEBUFFER,we)}}},this.readRenderTargetPixelsAsync=async function(b,L,G,O,k,ue,_e,ce=0){if(!(b&&b.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let xe=Ce.get(b).__webglFramebuffer;if(b.isWebGLCubeRenderTarget&&_e!==void 0&&(xe=xe[_e],Array.isArray(xe)&&(xe=xe[0])),xe)if(L>=0&&L<=b.width-O&&G>=0&&G<=b.height-k){fe.bindFramebuffer(U.FRAMEBUFFER,xe);const we=b.textures[ce],Ue=we.format,He=we.type;b.textures.length>1&&U.readBuffer(U.COLOR_ATTACHMENT0+ce);const Me=$l(we);if(Me.__formatReadable===!1)throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(Me.__typeReadable===!1)throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");const Ve=U.createBuffer();U.bindBuffer(U.PIXEL_PACK_BUFFER,Ve),U.bufferData(U.PIXEL_PACK_BUFFER,ue.byteLength,U.STREAM_READ),U.readPixels(L,G,O,k,re.convert(Ue),re.convert(He),0),U.bindBuffer(U.PIXEL_PACK_BUFFER,null);const xt=ne!==null?Ce.get(ne).__webglFramebuffer:null;fe.bindFramebuffer(U.FRAMEBUFFER,xt);const it=U.fenceSync(U.SYNC_GPU_COMMANDS_COMPLETE,0);return U.flush(),await hf(U,it,4),U.bindBuffer(U.PIXEL_PACK_BUFFER,Ve),U.getBufferSubData(U.PIXEL_PACK_BUFFER,0,ue),U.bindBuffer(U.PIXEL_PACK_BUFFER,null),U.deleteBuffer(Ve),U.deleteSync(it),ue}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")},this.copyFramebufferToTexture=function(b,L=null,G=0){const O=Math.pow(2,-G),k=Math.floor(b.image.width*O),ue=Math.floor(b.image.height*O),_e=L!==null?L.x:0,ce=L!==null?L.y:0;De.setTexture2D(b,0),U.copyTexSubImage2D(U.TEXTURE_2D,G,0,0,_e,ce,k,ue),fe.unbindTexture()},this.copyTextureToTexture=function(b,L,G=null,O=null,k=0,ue=0){let _e,ce,xe,we,Ue,He,Me,Ve,xt;const it=b.isCompressedTexture?b.mipmaps[ue]:b.image;if(G!==null)_e=G.max.x-G.min.x,ce=G.max.y-G.min.y,xe=G.isBox3?G.max.z-G.min.z:1,we=G.min.x,Ue=G.min.y,He=G.isBox3?G.min.z:0;else{const Xe=Math.pow(2,-k);_e=Math.floor(it.width*Xe),ce=Math.floor(it.height*Xe),b.isDataArrayTexture?xe=it.depth:b.isData3DTexture?xe=Math.floor(it.depth*Xe):xe=1,we=0,Ue=0,He=0}O!==null?(Me=O.x,Ve=O.y,xt=O.z):(Me=0,Ve=0,xt=0);const nt=re.convert(L.format),It=re.convert(L.type);let be;L.isData3DTexture?(De.setTexture3D(L,0),be=U.TEXTURE_3D):L.isDataArrayTexture||L.isCompressedArrayTexture?(De.setTexture2DArray(L,0),be=U.TEXTURE_2D_ARRAY):(De.setTexture2D(L,0),be=U.TEXTURE_2D),fe.activeTexture(U.TEXTURE0),fe.pixelStorei(U.UNPACK_FLIP_Y_WEBGL,L.flipY),fe.pixelStorei(U.UNPACK_PREMULTIPLY_ALPHA_WEBGL,L.premultiplyAlpha),fe.pixelStorei(U.UNPACK_ALIGNMENT,L.unpackAlignment);const zt=fe.getParameter(U.UNPACK_ROW_LENGTH),Ze=fe.getParameter(U.UNPACK_IMAGE_HEIGHT),mi=fe.getParameter(U.UNPACK_SKIP_PIXELS),Nt=fe.getParameter(U.UNPACK_SKIP_ROWS),Zr=fe.getParameter(U.UNPACK_SKIP_IMAGES);fe.pixelStorei(U.UNPACK_ROW_LENGTH,it.width),fe.pixelStorei(U.UNPACK_IMAGE_HEIGHT,it.height),fe.pixelStorei(U.UNPACK_SKIP_PIXELS,we),fe.pixelStorei(U.UNPACK_SKIP_ROWS,Ue),fe.pixelStorei(U.UNPACK_SKIP_IMAGES,He);const Kn=b.isDataArrayTexture||b.isData3DTexture,gi=L.isDataArrayTexture||L.isData3DTexture;if(b.isDepthTexture){const Xe=Ce.get(b),Lt=Ce.get(L),un=Ce.get(Xe.__renderTarget),ut=Ce.get(Lt.__renderTarget);fe.bindFramebuffer(U.READ_FRAMEBUFFER,un.__webglFramebuffer),fe.bindFramebuffer(U.DRAW_FRAMEBUFFER,ut.__webglFramebuffer);for(let Rt=0;Rt<xe;Rt++)Kn&&(U.framebufferTextureLayer(U.READ_FRAMEBUFFER,U.COLOR_ATTACHMENT0,Ce.get(b).__webglTexture,k,He+Rt),U.framebufferTextureLayer(U.DRAW_FRAMEBUFFER,U.COLOR_ATTACHMENT0,Ce.get(L).__webglTexture,ue,xt+Rt)),U.blitFramebuffer(we,Ue,we+_e,Ue+ce,Me,Ve,Me+_e,Ve+ce,U.DEPTH_BUFFER_BIT,U.NEAREST);fe.bindFramebuffer(U.READ_FRAMEBUFFER,null),fe.bindFramebuffer(U.DRAW_FRAMEBUFFER,null)}else if(k!==0||b.isRenderTargetTexture||Ce.has(b)){const Xe=Ce.get(b),Lt=Ce.get(L);fe.bindFramebuffer(U.READ_FRAMEBUFFER,D),fe.bindFramebuffer(U.DRAW_FRAMEBUFFER,H);for(let un=0;un<xe;un++)Kn?U.framebufferTextureLayer(U.READ_FRAMEBUFFER,U.COLOR_ATTACHMENT0,Xe.__webglTexture,k,He+un):U.framebufferTexture2D(U.READ_FRAMEBUFFER,U.COLOR_ATTACHMENT0,U.TEXTURE_2D,Xe.__webglTexture,k),gi?U.framebufferTextureLayer(U.DRAW_FRAMEBUFFER,U.COLOR_ATTACHMENT0,Lt.__webglTexture,ue,xt+un):U.framebufferTexture2D(U.DRAW_FRAMEBUFFER,U.COLOR_ATTACHMENT0,U.TEXTURE_2D,Lt.__webglTexture,ue),k!==0?U.blitFramebuffer(we,Ue,we+_e,Ue+ce,Me,Ve,Me+_e,Ve+ce,U.COLOR_BUFFER_BIT,U.NEAREST):gi?U.copyTexSubImage3D(be,ue,Me,Ve,xt+un,we,Ue,_e,ce):U.copyTexSubImage2D(be,ue,Me,Ve,we,Ue,_e,ce);fe.bindFramebuffer(U.READ_FRAMEBUFFER,null),fe.bindFramebuffer(U.DRAW_FRAMEBUFFER,null)}else gi?b.isDataTexture||b.isData3DTexture?U.texSubImage3D(be,ue,Me,Ve,xt,_e,ce,xe,nt,It,it.data):L.isCompressedArrayTexture?U.compressedTexSubImage3D(be,ue,Me,Ve,xt,_e,ce,xe,nt,it.data):U.texSubImage3D(be,ue,Me,Ve,xt,_e,ce,xe,nt,It,it):b.isDataTexture?U.texSubImage2D(U.TEXTURE_2D,ue,Me,Ve,_e,ce,nt,It,it.data):b.isCompressedTexture?U.compressedTexSubImage2D(U.TEXTURE_2D,ue,Me,Ve,it.width,it.height,nt,it.data):U.texSubImage2D(U.TEXTURE_2D,ue,Me,Ve,_e,ce,nt,It,it);fe.pixelStorei(U.UNPACK_ROW_LENGTH,zt),fe.pixelStorei(U.UNPACK_IMAGE_HEIGHT,Ze),fe.pixelStorei(U.UNPACK_SKIP_PIXELS,mi),fe.pixelStorei(U.UNPACK_SKIP_ROWS,Nt),fe.pixelStorei(U.UNPACK_SKIP_IMAGES,Zr),ue===0&&L.generateMipmaps===!0&&L.mipmapsAutoUpdate===!0&&U.generateMipmap(be),fe.unbindTexture()},this.initRenderTarget=function(b){Ce.get(b).__webglFramebuffer===void 0&&De.setupRenderTarget(b)},this.initTexture=function(b){b.isCubeTexture?De.setTextureCube(b,0):b.isData3DTexture?De.setTexture3D(b,0):b.isDataArrayTexture||b.isCompressedArrayTexture?De.setTexture2DArray(b,0):De.setTexture2D(b,0),fe.unbindTexture()},this.resetState=function(){Z=0,z=0,ne=null,fe.reset(),ae.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return yn}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;const t=this.getContext();t.drawingBufferColorSpace=qe._getDrawingBufferColorSpace(e),t.unpackColorSpace=qe._getUnpackColorSpace()}}const xh={earth:{id:"earth",ground:["#4a8f3e","#5ea34a","#3a7a36","#6cad52"],base:"#5aa648",rim:"#c9b98c",rock:"#8a8478",sky:["#2f6fd0","#8fc3f2","#e8f2ff"],fog:"#cfe2f6",fogNear:90,fogFar:420,sun:"#fff1d6",sunI:2.4,amb:["#bcd8ff","#3b5a34",.75],sea:"#2a78b8",seaSide:1,hills:9,flora:"trees",clouds:"#ffffff",cloudN:26,stars:0}},St=ar/2;function kx(i){const e=Qo(i),t=new Float32Array(256*256).map(()=>e()),n=(r,s)=>{const a=Math.floor(r),o=Math.floor(s),l=r-a,c=s-o,h=(p,g)=>t[(p&255)<<8|g&255],u=l*l*(3-2*l),d=c*c*(3-2*c);return(h(a,o)*(1-u)+h(a+1,o)*u)*(1-d)+(h(a,o+1)*(1-u)+h(a+1,o+1)*u)*d};return(r,s)=>n(r,s)*.55+n(r*2.1+7,s*2.1+3)*.3+n(r*4.3+1,s*4.3+9)*.15}class zx{constructor(e,t,n){this.scene=e,this.quality=n,this.group=new Wt,this.clouds=new Wt,this.water=null,this.grid=null,this.bound=null,this.height=()=>0,this.look=xh[t]||xh.earth,this.sky=this.makeSky(),this.build()}makeSky(){const e=this.look,t=new ci(3e3,32,16),n=new Xn({side:qt,depthWrite:!1,fog:!1,uniforms:{top:{value:new Te(e.sky[0])},mid:{value:new Te(e.sky[1])},hor:{value:new Te(e.sky[2])},sunDir:{value:new P(-.55,.62,.42).normalize()},sunCol:{value:new Te(e.sun)},stars:{value:e.stars||0}},vertexShader:"varying vec3 vP; void main(){ vP = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }",fragmentShader:`uniform vec3 top, mid, hor, sunCol, sunDir; uniform float stars; varying vec3 vP;
        float h(vec3 p){ return fract(sin(dot(p, vec3(12.9898,78.233,37.719))) * 43758.5453); }
        void main(){ float y = vP.y; vec3 c = y > 0.18 ? mix(mid, top, smoothstep(0.18, 0.75, y)) : mix(hor, mid, smoothstep(-0.02, 0.18, y));
          float sd = max(dot(vP, sunDir), 0.0); c += sunCol * (pow(sd, 900.0) * 3.0 + pow(sd, 18.0) * 0.18);
          if (stars > 0.0) { vec3 q = floor(vP * 420.0); float s = step(0.9975, h(q)); c += vec3(s) * stars * smoothstep(0.0, 0.2, y); }
          gl_FragColor = vec4(c, 1.0); }`}),r=new mt(t,n);return r.renderOrder=-10,r.frustumCulled=!1,this.scene.add(r),r}build(){const e=this.look,t=kx(77),n=Qo(5),r=520,s=this.quality==="high"?200:140,a=(v,m)=>e.seaSide?(v+m)/Math.SQRT2:99999;this.height=(v,m)=>{const f=Math.max(Math.abs(v),Math.abs(m)),_=Si.smoothstep(f,St+4,St+30);let S=_*(t(v*.018,m*.018)*e.hills*2.2+t(v*.06,m*.06)*2.2-1.2)+_*Math.max(0,f-90)*.06;if(e.seaSide){const y=a(v,m);S=Math.min(S,Si.lerp(-6,S,Si.smoothstep(y,-St-34,-St-12)))}return S};const o=new li(r,r,s,s);o.rotateX(-Math.PI/2);const l=o.attributes.position,c=new Float32Array(l.count*3),h=new Te,u=e.ground.map(v=>new Te(v)),d=new Te(e.base),p=new Te(e.rim);new Te(e.rock);for(let v=0;v<l.count;v++){const m=l.getX(v),f=l.getZ(v),_=this.height(m,f);l.setY(v,_);const S=Math.max(Math.abs(m),Math.abs(f)),y=t(m*.09+3,f*.09);if(h.copy(u[0]).lerp(u[1],y).lerp(u[2],t(m*.03,f*.03+5)*.8),S<St+2){h.lerp(d,.6);const A=Math.floor((m+f+400)/2)%2;h.offsetHSL(0,0,A?.025:-.015)}if(e.seaSide){const A=a(m,f);A<-St-8&&_<1.2&&h.lerp(p,Si.smoothstep(-A,St+8,St+16)*Si.smoothstep(-_,-1.2,.2))}c.set([h.r,h.g,h.b],v*3)}o.setAttribute("color",new jt(c,3)),o.computeVertexNormals();const g=new mt(o,new qr({vertexColors:!0,roughness:.95,metalness:0,flatShading:!0}));if(g.receiveShadow=!0,g.name="ground",this.group.add(g),e.sea){const v=new mt(new li(2400,2400),new Xn({transparent:!0,fog:!0,uniforms:{t:{value:0},col:{value:new Te(e.sea)},deep:{value:new Te(e.sea).multiplyScalar(.5)},sky:{value:new Te(e.sky[2])},sunDir:{value:new P(-.55,.62,.42).normalize()},...pe.fog},vertexShader:`#include <fog_pars_vertex>
varying vec3 vW; void main(){ vec4 w = modelMatrix * vec4(position,1.0); vW = w.xyz; vec4 mvPosition = viewMatrix * w; gl_Position = projectionMatrix * mvPosition;
#include <fog_vertex>
}`,fragmentShader:`#include <fog_pars_fragment>
          uniform float t; uniform vec3 col, deep, sky, sunDir; varying vec3 vW;
          void main(){ vec2 q = vW.xz * 0.15; float w = sin(q.x * 3.1 + t * 1.3) * 0.5 + sin(q.y * 2.3 - t * 1.1 + q.x) * 0.5 + sin((q.x + q.y) * 5.0 + t * 2.0) * 0.25;
            vec3 n = normalize(vec3(cos(q.x * 3.1 + t) * 0.08, 1.0, cos(q.y * 2.3 - t) * 0.08 + w * 0.03)); vec3 v = normalize(cameraPosition - vW);
            float fr = pow(1.0 - max(dot(n, v), 0.0), 3.0); vec3 c = mix(deep, col, 0.6 + 0.2 * w); c = mix(c, sky, fr * 0.7);
            vec3 h = normalize(sunDir + v); c += vec3(1.0, 0.95, 0.85) * pow(max(dot(n, h), 0.0), 220.0) * 1.8;
            gl_FragColor = vec4(c, 0.94);
          #include <fog_fragment>
          }`}));v.rotation.x=-Math.PI/2,v.position.y=-.4,this.water=v,this.group.add(v)}if(e.flora==="trees"){const v=[],m=new ui;for(let y=0;y<(this.quality==="high"?1400:700);y++){const A=(n()-.5)*360,E=(n()-.5)*360;if(Math.max(Math.abs(A),Math.abs(E))<St+5)continue;const w=this.height(A,E);if(w<.5||w>e.hills*2||t(A*.05+9,E*.05)<.42)continue;const I=.7+n()*.9;m.setFromEuler(new Dn(0,n()*6,0)),v.push(new Ye().compose(new P(A,w,E),m,new P(I,I*(.9+n()*.5),I)))}const f=new or(.1,.14,.8,5);f.translate(0,.4,0);const _=new Ai(.75,1.9,7);_.translate(0,1.6,0);const S=new Ai(.55,1.3,7);S.translate(0,2.4,0);for(const[y,A]of[[f,"#6b4a2e"],[_,"#2f6b34"],[S,"#3a7d3c"]]){const E=new Zf(y,new qr({color:A,flatShading:!0,roughness:.9}),v.length);v.forEach((x,w)=>E.setMatrixAt(w,x)),E.castShadow=A!=="#6b4a2e",E.receiveShadow=!0,this.group.add(E)}}if(e.clouds){const v=Gx();for(let m=0;m<(e.cloudN||0);m++){const f=new $f(new yu({map:v,color:e.clouds,transparent:!0,opacity:.75,depthWrite:!1,fog:!1})),_=n()*Math.PI*2,S=120+n()*900;f.position.set(Math.cos(_)*S,60+n()*70,Math.sin(_)*S);const y=60+n()*110;f.scale.set(y,y*.38,1),f.userData.v=.6+n()*1.2,this.clouds.add(f)}this.group.add(this.clouds)}this.scene.add(this.group)}setArea(e,t){this.grid&&(this.group.remove(this.grid),this.grid.geometry.dispose()),this.bound&&(this.group.remove(this.bound),this.bound.geometry.dispose());const n=[];for(let d=e;d<=t;d++)n.push(d-St,.03,e-St,d-St,.03,t-St,e-St,.03,d-St,t-St,.03,d-St);const r=new gt;r.setAttribute("position",new We(n,3)),this.grid=new jf(r,new Su({color:"#ffffff",transparent:!0,opacity:.22})),this.grid.visible=!1,this.group.add(this.grid);const s=t-e;new ha(0,1,4,1).dispose();const o=new Iu,l=s/2+.25,c=s/2;o.moveTo(-l,-l),o.lineTo(l,-l),o.lineTo(l,l),o.lineTo(-l,l),o.lineTo(-l,-l);const h=new Ho;h.moveTo(-c,-c),h.lineTo(-c,c),h.lineTo(c,c),h.lineTo(c,-c),h.lineTo(-c,-c),o.holes.push(h);const u=new Pl(o);u.rotateX(-Math.PI/2),this.bound=new mt(u,new bn({color:"#f4e7b8",transparent:!0,opacity:.55,depthWrite:!1})),this.bound.position.set((e+t)/2-St,.04,(e+t)/2-St),this.group.add(this.bound)}showGrid(e){this.grid&&(this.grid.visible=e)}update(e,t){this.water&&(this.water.material.uniforms.t.value=e);for(const n of this.clouds.children)n.position.x+=n.userData.v*t,n.position.x>1e3&&(n.position.x=-1e3)}dispose(){this.scene.remove(this.group),this.scene.remove(this.sky)}}let Mr=null;function Gx(){if(Mr)return Mr;const i=document.createElement("canvas");i.width=128,i.height=64;const e=i.getContext("2d"),t=Qo(3);for(let n=0;n<14;n++){const r=20+t()*88,s=22+t()*22,a=10+t()*18,o=e.createRadialGradient(r,s,0,r,s,a);o.addColorStop(0,"rgba(255,255,255,0.9)"),o.addColorStop(1,"rgba(255,255,255,0)"),e.fillStyle=o,e.beginPath(),e.arc(r,s,a,0,7),e.fill()}return Mr=new Tu(i),Mr.colorSpace=Ot,Mr}function Hx(i,e=!1){const t=i[0].index!==null,n=new Set(Object.keys(i[0].attributes)),r=new Set(Object.keys(i[0].morphAttributes)),s={},a={},o=i[0].morphTargetsRelative,l=new gt;l.morphTargetsRelative=o;let c=0;for(let h=0;h<i.length;++h){const u=i[h];let d=0,p=0;if(t!==(u.index!==null))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". All geometries must have compatible attributes; make sure index attribute exists among all geometries, or in none of them."),null;for(const g in u.attributes){if(!n.has(g))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+'. All geometries must have compatible attributes; make sure "'+g+'" attribute exists among all geometries, or in none of them.'),null;s[g]===void 0&&(s[g]=[]),s[g].push(u.attributes[g]),d++}if(d!==n.size)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". Make sure all geometries have the same number of attributes."),null;if(o!==u.morphTargetsRelative)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". .morphTargetsRelative must be consistent throughout all geometries."),null;for(const g in u.morphAttributes){if(!r.has(g))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+".  .morphAttributes must be consistent throughout all geometries."),null;if(u.morphAttributes[g].length!==i[0].morphAttributes[g].length)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+'. All geometries must have the same number of morph targets for the "'+g+'" morph attribute.'),null;a[g]===void 0&&(a[g]=[]),a[g].push(u.morphAttributes[g]),p++}if(p!==r.size)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". Make sure all geometries have the same number of morph attributes."),null;if(e){let g;if(t)g=u.index.count;else if(u.attributes.position!==void 0)g=u.attributes.position.count;else return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". The geometry must have either an index or a position attribute"),null;l.addGroup(c,g,h),c+=g}}if(t){let h=0;const u=[];for(let d=0;d<i.length;++d){const p=i[d].index;for(let g=0;g<p.count;++g)u.push(p.getX(g)+h);h+=i[d].attributes.position.count}l.setIndex(u)}for(const h in s){const u=_h(s[h]);if(!u)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+h+" attribute."),null;l.setAttribute(h,u)}for(const h in a){const u=a[h][0].length;if(u!==0){l.morphAttributes=l.morphAttributes||{},l.morphAttributes[h]=[];for(let d=0;d<u;++d){const p=[];for(let v=0;v<a[h].length;++v)p.push(a[h][v][d]);const g=_h(p);if(!g)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+h+" morphAttribute."),null;l.morphAttributes[h].push(g)}}}return l}function _h(i){let e,t,n,r=-1,s=0;for(let c=0;c<i.length;++c){const h=i[c];if(e===void 0&&(e=h.array.constructor),e!==h.array.constructor)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.array must be of consistent array types across matching attributes."),null;if(t===void 0&&(t=h.itemSize),t!==h.itemSize)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.itemSize must be consistent across matching attributes."),null;if(n===void 0&&(n=h.normalized),n!==h.normalized)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.normalized must be consistent across matching attributes."),null;if(r===-1&&(r=h.gpuType),r!==h.gpuType)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.gpuType must be consistent across matching attributes."),null;s+=h.count*t}const a=new e(s),o=new jt(a,t,n);let l=0;for(let c=0;c<i.length;++c){const h=i[c];if(h.isInterleavedBufferAttribute){const u=l/t;for(let d=0,p=h.count;d<p;d++)for(let g=0;g<t;g++){const v=h.getComponent(d,g);o.setComponent(d+u,g,v)}}else a.set(h.array,l);l+=h.count*t}return r!==void 0&&(o.gpuType=r),o}const Ds=new Te,Ws={body:new qr({vertexColors:!0,flatShading:!0,roughness:.62,metalness:.12}),glow:new bn({vertexColors:!0,toneMapped:!1}),glass:new qr({vertexColors:!0,transparent:!0,opacity:.38,roughness:.08,metalness:.2,depthWrite:!1}),ghostOk:new bn({color:6160282,transparent:!0,opacity:.45,depthWrite:!1}),ghostBad:new bn({color:16734826,transparent:!0,opacity:.45,depthWrite:!1})};class ct{constructor(){this.parts={body:[],glow:[],glass:[]}}add(e,t,n=0,r=0,s=0,a={}){let o=e.index?e.toNonIndexed():e.clone();o.attributes.uv&&o.deleteAttribute("uv"),o.attributes.uv1&&o.deleteAttribute("uv1");const l=new Ye().compose(new P(n,r,s),new ui().setFromEuler(new Dn(a.rx||0,a.ry||0,a.rz||0)),new P(a.sx??1,a.sy??1,a.sz??1));o.applyMatrix4(l),Ds.set(t);const c=o.attributes.position.count,h=new Float32Array(c*3);for(let u=0;u<c;u++)h[u*3]=Ds.r,h[u*3+1]=Ds.g,h[u*3+2]=Ds.b;return o.setAttribute("color",new jt(h,3)),this.parts[a.glow?"glow":a.glass?"glass":"body"].push(o),e.dispose(),this}box(e,t,n,r,s=0,a=0,o=0,l={}){return this.add(new Li(e,t,n),r,s,a+t/2,o,l)}cyl(e,t,n,r,s,a=0,o=0,l=0,c={}){return this.add(new or(e,t,n,r),s,a,o+n/2,l,c)}sphere(e,t,n=0,r=0,s=0,a={}){return this.add(new ci(e,a.w||10,a.h||7,0,Math.PI*2,0,a.theta||Math.PI),t,n,r,s,a)}build(e=""){const t=new Wt;t.name=e;for(const n of["body","glow","glass"]){const r=this.parts[n];if(!r.length)continue;const s=Hx(r,!1);if(r.forEach(o=>o.dispose()),!s)continue;const a=new mt(s,Ws[n]);a.castShadow=n==="body",a.receiveShadow=n==="body",a.userData.bucket=n,t.add(a)}return t}}const ai=(i,e)=>{const t=new Te(i);return e<0?t.lerp(new Te(0),-e):t.lerp(new Te(16777215),e),"#"+t.getHexString()},Vx="#cfd3d8",sa="#3b4350",Bt="#aeb8c4",ju="#ffe7a8",Ko="#9fd3ff",en=i=>Math.min(6,1+Math.floor((Math.max(1,i)-1)/4));function Kt(i,e,t,n=Vx){i.box(e-.08,.1,t-.08,n),i.box(e-.08,.03,.06,"#f2d36b",0,.1,t/2-.1)}function Xt(i,e,t,n,r,s=0,a=0){i.box(e+.05,r,t+.05,ju,s,n,a,{glow:!0});for(let o=-e/2+.35;o<e/2-.2;o+=.42)i.box(.07,r+.02,t+.07,"#5b6676",s+o,n-.01,a)}function Wx(i,e){const t=new ct,n=en(i),r=e.primary,s=e.accent;Kt(t,5,5);const a=.95+n*.12;t.box(3.3,a,2.3,r,.55,.1,.55),Xt(t,3.3,2.3,.4,.3,.55,.55),t.box(3.36,.1,2.36,s,.55,.1+a,.55),t.box(3,a-.15,.06,Ko,.55,.15,-.62,{glass:!0});for(let m=-.8;m<=1.9;m+=.45)t.box(.05,a-.15,.08,ai(r,-.3),m,.15,-.62);for(let m=1;m<Math.min(n,4);m++){const f=3-m*.5,_=2-m*.3,S=.2+a+(m-1)*.62;t.box(f,.55,_,m%2?ai(r,-.05):r,.85,S,.75),Xt(t,f,_,S+.18,.2,.85,.75),t.box(f+.05,.06,_+.05,s,.85,S+.55,.75)}t.box(.5,.3,.4,"#9aa3ad",1.6,.2+a,1.2),t.box(.4,.25,.4,"#9aa3ad",1.1,.2+a,1.4);const o=2+n*.45,l=-1.35,c=-1.15;t.cyl(.42,.5,o,8,ai(r,-.04),l,.1,c);for(let m=.6;m<o-.3;m+=.55)t.cyl(.43,.43,.05,8,s,l,.1+m,c);t.cyl(.8,.55,.22,10,r,l,.1+o,c),t.cyl(.78,.78,.42,10,Ko,l,.32+o,c,{glass:!0}),t.cyl(.7,.7,.36,10,ju,l,.35+o,c,{glow:!0}),t.cyl(.86,.86,.1,10,s,l,.74+o,c),t.cyl(.55,.8,.14,10,r,l,.84+o,c),t.cyl(.03,.03,.9,5,Bt,l,.98+o,c),t.sphere(.06,"#ff4f4f",l,1.9+o,c,{glow:!0});const h=t.build("hq"),u=new Wt;{const m=new ct;m.add(new ci(.6+n*.05,16,8,0,Math.PI*2,0,Math.PI/3.2),"#eef2f6",0,0,0,{rx:Math.PI}),m.cyl(.02,.02,.5,4,Bt,0,-.55,0),m.sphere(.05,s,0,-.8,0);const f=m.build();f.rotation.x=-.9,u.add(f)}const d=new ct;d.cyl(.1,.16,.45,8,Bt,0,0,0);const p=d.build();p.position.set(.1,.2+a,.3),h.add(p),u.position.set(.1,.75+a,.3),h.add(u);const g=new ct;g.cyl(.03,.035,2.4,5,Bt,2.15,.1,-2.05),h.add(g.build());const v=new mt(new li(.75,.48),new qr({map:o_(e.banner),side:xn,roughness:.8}));return v.position.set(2.53,2.25,-2.05),h.add(v),{group:h,height:o+1.4,anim:m=>{u.rotation.y=m*.25,v.rotation.y=Math.sin(m*2)*.15}}}function qx(i,e){const t=new ct,n=en(i),r=e.primary,s=e.accent;Kt(t,4,4);const a=.9+n*.18;t.box(2.6,a,2,r,-.5,.1,.5),Xt(t,2.6,2,.4,.26,-.5,.5),t.box(2.65,.08,2.05,s,-.5,.1+a,.5);for(let o=0;o<Math.min(3,1+Math.floor(n/2));o++){const c=-1+o*1;t.cyl(.42,.42,.45,12,"#e9edf2",1.1,.1,c),t.sphere(.42,"#f6f8fb",1.1,.55,c,{theta:Math.PI/2,w:14}),t.box(.12,.3,.5,sa,1.1,.7,c,{ry:.6})}return t.cyl(.32,.32,3,10,Bt,-.6,.45,-1.35,{rz:Math.PI/2}),t.cyl(.36,.36,.2,10,s,-2,.45,-1.35,{rz:Math.PI/2}),n>=3&&(t.box(1.2,.8,1,ai(r,-.08),-.9,.1+a,.6),Xt(t,1.2,1,.25+a,.2,-.9,.6)),{group:t.build("research"),height:a+1.2}}function Xx(i,e){const t=new ct,n=en(i),r="#e8dcc6",s=e.accent;Kt(t,4,4,"#7fae5a"),t.box(3.2,.9,1.3,r,0,.1,-1.1),t.box(3.3,.18,1.4,"#a8452f",0,1,-1.1);for(let o=-3;o<=3;o++)t.cyl(.06,.06,.8,6,"#f6f1e6",o*.45,.1,-.4);t.box(3.4,.08,.3,"#f6f1e6",0,.9,-.42),t.box(1,.9,2.2,r,-1.2,.1,.7),t.box(1.1,.16,2.3,"#a8452f",-1.2,1,.7),Xt(t,1,2.2,.45,.2,-1.2,.7),Xt(t,3.2,1.3,.45,.2,0,-1.1);const a=1.6+n*.25;t.box(.6,a,.6,r,1.2,.1,.9),t.box(.7,.1,.7,s,1.2,.1+a,.9),t.cyl(0,.42,.6,4,"#a8452f",1.2,.2+a,.9,{ry:Math.PI/4}),t.cyl(.18,.18,.05,12,"#fff8dc",1.2,a-.35,1.21,{rx:Math.PI/2,glow:!0});for(let o=0;o<3;o++)t.cyl(.05,.07,.35,5,"#6b4a2e",.1+o*.5,.1,.9),t.sphere(.25,"#3f8a3a",.1+o*.5,.6,.9);return{group:t.build("university"),height:a+.9}}function $x(i,e){const t=new ct,n=en(i),r=e.accent;Kt(t,3,3,"#8e8170");for(let a=0;a<3;a++){const o=2-a*.55;t.box(o,.06,o,a%2?"#6e6152":"#7d6f5e",-.25,.1-a*.05,-.25)}t.box(.7,.04,.7,"#4a4036",-.25,-.02,-.25);const s=1.4+n*.2;for(const[a,o]of[[.75,.55],[1.15,.55],[.75,.95],[1.15,.95]])t.box(.07,s,.07,"#c0392b",a,.1,o);return t.box(.55,.08,.55,"#c0392b",.95,.1+s,.75),t.cyl(.16,.16,.06,10,sa,.95,.15+s,.75,{rx:Math.PI/2}),t.box(.18,.12,1.5,sa,.2,.45,.9,{rx:-.35}),t.add(new Ai(.45,.5,7),"#9aa3ad",-.9,.35,.95),t.box(.6,.35,.4,r,-.95,.1,-1),t.box(.3,.25,.4,"#f5c542",-.55,.1,-1),n>=3&&(t.box(.9,.7,.6,"#d8d2c6",.9,.1,-.9),Xt(t,.9,.6,.35,.16,.9,-.9)),{group:t.build("mine"),height:s+.5}}function Yx(i,e){const t=new ct,n=en(i),r=e.accent;Kt(t,3,3);const s=Math.min(4,1+Math.floor(n/2));for(let c=0;c<s;c++){const h=1.6+n*.2-c*.2,u=-.9+c*.55;t.cyl(.18,.2,h,10,"#e4e7eb",u,.1,-.8);for(let d=1;d<4;d++)t.cyl(.21,.21,.05,10,r,u,.1+h*d/4,-.8)}t.sphere(.45,"#f1f3f5",.6,.6,.6,{w:14,h:9}),t.cyl(.05,.05,.4,5,Bt,.6,.1,.6),n>=2&&t.sphere(.36,"#f1f3f5",-.5,.5,.75,{w:12,h:8}),t.box(2.2,.08,.08,Bt,0,.45,0),t.box(.08,.08,1.5,Bt,.1,.35,0);const a=1.9+n*.25;t.cyl(.05,.07,a,6,sa,1.15,.1,-1.1);const o=t.build("refinery"),l=new mt(new Ai(.1,.4,8),new bn({color:"#ffb347",toneMapped:!1}));return l.position.set(1.15,.1+a+.2,-1.1),o.add(l),{group:o,height:a+.6,anim:(c,h)=>{l.visible=h.working,l.scale.set(1,.8+Math.sin(c*13)*.25+Math.sin(c*7.3)*.15,1)}}}function Kx(i,e){const t=new ct,n=en(i),r=e.primary,s=e.accent;Kt(t,3,3);const a=1.2+n*.55;t.box(1.7,a,1.5,Ko,-.2,.1,-.2,{glass:!0}),t.box(1.6,a-.05,1.4,"#5d7da0",-.2,.1,-.2);for(let o=.4;o<a;o+=.42)t.box(1.72,.05,1.52,s,-.2,.1+o,-.2);return t.box(1.8,.12,1.6,r,-.2,.1+a,-.2),Xt(t,1.62,1.42,.3,a-.5,-.2,-.2),t.box(1,.6,.9,r,.6,.1,.8),Xt(t,1,.9,.25,.18,.6,.8),t.box(.5,.05,.25,"#ffd166",.6,.72,1.26,{glow:!0}),{group:t.build("office"),height:a+.4}}function Zx(i){const e=new ct,t=en(i);Kt(e,3,3,"#a5b07f");const n=Math.min(4,2+Math.floor(t/2)),r=t>=4?3:2;for(let s=0;s<n;s++)for(let a=0;a<r;a++){const o=-.95+a*(1.9/Math.max(1,r-1))*(r>1?1:0),l=-1+s*2/Math.max(1,n-1);e.box(.05,.3,.05,Bt,o,.1,l),e.box(r>2?.8:1.1,.04,.45,"#1d3c78",o,.42,l,{rx:-.5}),e.box(r>2?.82:1.12,.02,.47,"#4f7fd6",o,.445,l+.01,{rx:-.5})}return e.box(.35,.3,.3,"#e8eaee",1.2,.1,1.2),{group:e.build("solar"),height:.9}}function Jx(i,e){const t=new ct,n=en(i),r=e.accent;Kt(t,4,4);const s=[];for(let c=0;c<=12;c++){const h=c/12;s.push(new de(.95-Math.sin(h*Math.PI*.85)*.38+h*.05,h*(2.2+n*.2)))}t.add(new Cl(s,18),"#d9dde2",-.6,.1,-.5),t.cyl(.62,.62,.05,18,r,-.6,1.5+n*.15,-.5),t.cyl(.6,.6,.9,16,"#eef0f3",1,.1,.8),t.sphere(.6,"#eef0f3",1,1,.8,{theta:Math.PI/2,w:16}),t.box(1.2,.6,.8,"#c9cdd3",.9,.1,-.6),Xt(t,1.2,.8,.3,.14,.9,-.6);const a=t.build("fission"),o=new Wt,l=new bn({color:"#ffffff",transparent:!0,opacity:.5,depthWrite:!1});for(let c=0;c<5;c++){const h=new mt(new ca(.4,1),l);h.userData.o=c/5,o.add(h)}return o.position.set(-.6,2.3+n*.2,-.5),a.add(o),{group:a,height:3+n*.2,anim:(c,h)=>{o.visible=h.working,o.children.forEach(u=>{const d=(c*.25+u.userData.o)%1;u.position.set(Math.sin(d*7)*.2,d*2.2,d*.6),u.scale.setScalar(.6+d*1.6)}),l.opacity=.45}}}function Qx(i,e){const t=new ct,n=en(i),r=e.primary,s=e.accent;Kt(t,3,3);const a=Math.min(2,1+Math.floor(n/3));for(let l=0;l<a;l++){const c=-.7+l*.95;t.box(1.7,.55,.8,r,-.4,.1,c),t.add(new or(.4,.4,1.7,12,1,!1,0,Math.PI),ai(r,-.12),-.4,.65,c,{rz:Math.PI/2,sz:1}),t.box(.5,.4,.04,s,-1.26,.1,c)}const o=Math.min(3,1+Math.floor(n/2));for(let l=0;l<o;l++){const c=-.9+l*.8;t.cyl(.32,.32,.8+n*.1,12,"#eceff2",1.05,.1,c),t.cyl(.33,.33,.05,12,s,1.05,.5,c)}for(let l=0;l<3;l++)t.box(.25,.25,.25,["#c98b3a","#5b8bd6","#c94a4a"][l],-.9+l*.32,.1,1.15);return{group:t.build("depot"),height:1.3}}function jx(i,e){const t=new ct,n=en(i),r=e.accent;Kt(t,6,6,"#bfc4ca"),t.box(2.4,.3,2.4,"#9aa1a9",0,.1,0),t.box(.9,.05,2.6,"#2b2f36",0,.38,0),t.box(.95,.12,.6,"#2b2f36",0,.05,2.6);const s=2.6+n*.6;for(const[a,o]of[[-1.7,-.55],[-1.7,.55],[-2.5,-.55],[-2.5,.55]])t.box(.08,s,.08,"#c0392b",a,.1,o);for(let a=.6;a<s;a+=.55)t.box(.9,.05,1.18,"#c0392b",-2.1,.1+a,0);t.box(1,.12,1.2,"#7d838c",-2.1,.1+s,0),t.box(.7,.06,.1,Bt,-1.4,.1+s*.75,0);for(const[a,o]of[[2.5,2.5],[-2.5,2.5],[2.5,-2.5]])t.cyl(.04,.06,s+1.2,5,Bt,a,.1,o),t.sphere(.06,"#ff4f4f",a,s+1.35,o,{glow:!0});return t.cyl(.35,.35,.5,10,"#e9edf2",2.3,1.6,-2.2),t.box(.06,1.5,.06,Bt,2.1,.1,-2),t.box(.06,1.5,.06,Bt,2.5,.1,-2.4),t.box(1.2,.5,.8,r,2,.1,.4),Xt(t,1.2,.8,.25,.12,2,.4),{group:t.build("launch"),height:s+1.6}}function e_(i,e){const t=new ct,n=en(i),r="#e6e9ed",s=e.accent;Kt(t,4,5);const a=2.6+n*.55;t.box(3.4,a,4.2,r,0,.1,0),t.box(3.45,.14,4.25,ai(r,-.15),0,.1+a,0),t.box(1.3,a-.3,.04,"#9aa3ad",0,.1,2.11);for(let o=.5;o<a-.3;o+=.45)t.box(1.32,.03,.05,"#7c858f",0,.1+o,2.12);return t.box(.05,a*.7,1.4,e.banner.bg,1.71,.1+a*.2,-.6),t.box(.06,a*.12,1.4,s,1.72,.1+a*.5,-.6),t.box(1.2,.7,1.6,ai(r,-.05),-2.25,.1,1.2),Xt(t,1.2,1.6,.3,.14,-2.25,1.2),{group:t.build("vab"),height:a+.4}}function t_(i,e){const t=new ct,n=en(i);Kt(t,4,4),t.box(1.1,.6,.9,"#d9dde2",1.2,.1,1.3),Xt(t,1.1,.9,.3,.12,1.2,1.3);const r=1.1+n*.15;t.cyl(.25,.4,1+n*.1,8,"#c9ced5",-.3,.1,-.3);const s=t.build("tracking"),a=new Wt,o=new ct;o.add(new ci(r,20,10,0,Math.PI*2,0,Math.PI/3.4),"#f3f5f8",0,0,0,{rx:Math.PI}),o.cyl(.03,.03,r*.8,4,Bt,0,-r*.85,0),o.sphere(.08,e.accent,0,-r*1.25,0);const l=o.build();l.rotation.x=-.75,a.add(l),a.position.set(-.3,1.3+n*.1+r*.4,-.3),s.add(a);for(let c=0;c<Math.min(3,n-1);c++){const h=new ct;h.cyl(.04,.06,.5,6,Bt,0,0,0),h.add(new ci(.35,12,6,0,Math.PI*2,0,Math.PI/3.2),"#eef2f6",0,.85,0,{rx:Math.PI-.7});const u=h.build();u.position.set(1.3-c*.7,.1,-1.4),s.add(u)}return{group:s,height:2.4+n*.3,anim:c=>{a.rotation.y=Math.sin(c*.12)*1.2}}}function n_(i,e){const t=new ct,n=en(i),r=e.primary,s=e.accent;Kt(t,4,4),t.box(2.4,.9+n*.12,1.4,r,-.6,.1,-1.1),Xt(t,2.4,1.4,.4,.2,-.6,-1.1),t.box(2.45,.08,1.45,s,-.6,1+n*.12,-1.1),t.box(1.4,.06,1,"#4fb3e8",1,.1,1,{glass:!0}),t.box(1.5,.1,1.1,"#e9edf2",1,.08,1),t.cyl(.35,.45,.5,10,"#d9dde2",-.6,.1,.8);const a=t.build("academy"),o=new Wt,l=new ct;return l.box(2.2,.08,.12,Bt,0,0,0),l.sphere(.2,s,1.1,0,0,{w:10,h:7}),l.box(.25,.25,.25,"#eef0f3",-1.1,-.1,0),o.add(l.build()),o.position.set(-.6,.75,.8),a.add(o),{group:a,height:1.6+n*.15,anim:c=>{o.rotation.y=c*1.6}}}function i_(i,e){const t=rt[i],[n,r]=t?t.fp:[3,3],s=new ct;return Kt(s,n,r),s.box(n*.7,1.2,r*.7,e.primary,0,.1,0),Xt(s,n*.7,r*.7,.5,.2),s.box(n*.72,.1,r*.72,e.accent,0,1.3,0),{group:s.build(i),height:1.6}}function Zo(i,e,t){switch(i){case"hq":return Wx(e,t);case"research":return qx(e,t);case"university":return Xx(e,t);case"mine":return $x(e,t);case"refinery":return Yx(e,t);case"office":return Kx(e,t);case"solar":return Zx(e);case"fission":return Jx(e,t);case"depot":return Qx(e,t);case"launch":return jx(e,t);case"vab":return e_(e,t);case"tracking":return t_(e,t);case"academy":return n_(e,t)}return i_(i,t)}function r_(i,e,t){const n=new ct,r="#f5c542";for(const[s,a]of[[-i/2+.15,-e/2+.15],[i/2-.15,-e/2+.15],[-i/2+.15,e/2-.15],[i/2-.15,e/2-.15]])n.box(.06,t,.06,r,s,0,a);for(let s=.5;s<t;s+=.6)n.box(i-.2,.05,.08,r,0,s,-e/2+.15),n.box(i-.2,.05,.08,r,0,s,e/2-.15),n.box(.08,.05,e-.2,r,-i/2+.15,s,0),n.box(.08,.05,e-.2,r,i/2-.15,s,0);return n.box(.08,t+.8,.08,"#e67e22",i/2-.4,0,-e/2+.4),n.build("scaffold")}function s_(){const i=new ct;i.box(.34,.1,.34,"#f2f4f7"),i.box(.36,.03,.36,"#f5c542",0,.1,0);for(const[e,t]of[[.24,.24],[-.24,.24],[.24,-.24],[-.24,-.24]])i.box(.2,.025,.04,"#3b4350",e*.6,.06,t*.6,{ry:Math.atan2(t,e)}),i.cyl(.11,.11,.015,10,"#9aa3ad",e,.09,t);return i.sphere(.05,"#7ff5ff",0,-.04,0,{glow:!0}),i.build("drone")}const yh=new Map;function a_(i,e,t){if(i.beginPath(),e==="star")for(let n=0;n<10;n++){const r=-Math.PI/2+n*Math.PI/5,s=n%2?t*.45:t;i.lineTo(Math.cos(r)*s,Math.sin(r)*s)}else e==="planet"?(i.arc(0,0,t*.6,0,7),i.moveTo(t,0),i.ellipse(0,0,t,t*.28,-.3,0,7)):e==="rocket"?(i.moveTo(0,-t),i.quadraticCurveTo(t*.45,-t*.3,t*.3,t*.5),i.lineTo(t*.6,t),i.lineTo(-t*.6,t),i.lineTo(-t*.3,t*.5),i.quadraticCurveTo(-t*.45,-t*.3,0,-t)):e==="bolt"?(i.moveTo(t*.2,-t),i.lineTo(-t*.5,t*.1),i.lineTo(0,t*.1),i.lineTo(-t*.2,t),i.lineTo(t*.5,-t*.1),i.lineTo(0,-t*.1)):i.arc(0,0,t*.8,0,7);i.closePath()}function o_(i){const e=i.bg+i.fg+i.emblem,t=yh.get(e);if(t)return t;const n=document.createElement("canvas");n.width=128,n.height=80;const r=n.getContext("2d");r.fillStyle=i.bg,r.fillRect(0,0,128,80),r.fillStyle=i.fg,r.translate(64,40),a_(r,i.emblem,24),r.fill();const s=new Tu(n);return s.colorSpace=Ot,yh.set(e,s),s}const mn=ar/2;class l_{constructor(e,t){this.canvas=e,this.scene=new vu,this.views=new Map,this.drones=new Map,this.baseId="",this.look={primary:"#e9eef5",accent:"#22c7e8",banner:{bg:"#1b6fd8",fg:"#ffd23a",emblem:"rocket"}},this.cam={x:0,z:2,dist:44,yaw:Math.PI/4,tx:0,tz:2,tdist:44,tyaw:Math.PI/4},this.ghost=null,this.ghostObj=null,this.selected=null,this.t=0,this.ray=new Wp,this.ptr=new de,this.fx=[],this.area={lo:0,hi:0},this.onTap=()=>{},this.onGhostMove=()=>{},this.shF=0,this.shX=1e9,this.shZ=1e9;const n=/Android|iPhone|iPad|iPod/i.test(navigator.userAgent)||navigator.maxTouchPoints>1&&Math.min(screen.width,screen.height)<820;this.quality=t==="auto"?n?"low":"high":t,this.renderer=new Bx({canvas:e,antialias:this.quality==="high",powerPreference:"high-performance"}),this.renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,this.quality==="high"?2:1.5)),this.renderer.outputColorSpace=Ot,this.renderer.toneMapping=hl,this.renderer.toneMappingExposure=1,this.renderer.shadowMap.enabled=!0,this.renderer.shadowMap.type=Xh,this.camera=new cn(38,1,.5,6e3),this.sun=new qo("#fff1d6",2.8),this.sun.castShadow=!0;const r=this.quality==="high"?2048:1024;this.sun.shadow.mapSize.set(r,r);const s=this.sun.shadow.camera;s.left=-34,s.right=34,s.top=34,s.bottom=-34,s.near=1,s.far=160,this.sun.shadow.bias=-4e-4,this.sun.shadow.normalBias=.03,this.hemi=new ku("#bcd8ff","#5a6a3a",.9),this.scene.add(this.sun,this.sun.target,this.hemi,new Hp("#405070",.25)),this.selRing=new mt(new ha(.92,1,48),new bn({color:"#6ee7ff",transparent:!0,opacity:.9,depthWrite:!1,side:xn})),this.selRing.rotation.x=-Math.PI/2,this.selRing.visible=!1,this.scene.add(this.selRing),this.resize(),window.addEventListener("resize",()=>this.resize()),this.input()}resize(){const e=this.canvas.clientWidth||window.innerWidth,t=this.canvas.clientHeight||window.innerHeight;this.renderer.setSize(e,t,!1),this.camera.aspect=e/t,this.camera.updateProjectionMatrix()}setWorld(e,t){if(this.baseId===e)return;this.baseId=e,this.env&&this.env.dispose(),this.env=new zx(this.scene,t,this.quality);for(const r of this.views.values())this.scene.remove(r.root);this.views.clear();for(const r of this.drones.values())this.scene.remove(r.g);this.drones.clear();const n=this.env.look;this.scene.fog=new Sl(n.fog,n.fogNear,n.fogFar),this.sun.color.set(n.sun),this.sun.intensity=n.sunI,this.hemi.color.set(n.amb[0]),this.hemi.groundColor.set(n.amb[1]),this.hemi.intensity=n.amb[2],this.area={lo:-1,hi:-1}}placeCamera(){const e=this.cam,t=.16;e.x+=(e.tx-e.x)*t,e.z+=(e.tz-e.z)*t,e.dist+=(e.tdist-e.dist)*t,e.yaw+=(e.tyaw-e.yaw)*t;const n=Si.degToRad(Si.lerp(52,17,ln((e.dist-14)/81))),r=this.camera.aspect<.8?1.45:1,s=e.dist*r;this.camera.position.set(e.x+Math.sin(e.yaw)*Math.cos(n)*s,Math.sin(n)*s+1,e.z+Math.cos(e.yaw)*Math.cos(n)*s),this.camera.lookAt(e.x,.5,e.z),this.sun.target.position.set(e.x,0,e.z),this.sun.position.set(e.x-.55*70,.62*70,e.z+.42*70)}focus(e,t,n){this.cam.tx=e,this.cam.tz=t,n&&(this.cam.tdist=n)}clampCam(){const e=this.cam,t=mn+6;e.tx=ln(e.tx,-t,t),e.tz=ln(e.tz,-t,t),e.tdist=ln(e.tdist,12,95)}groundAt(e,t){const n=this.canvas.getBoundingClientRect();this.ptr.set((e-n.left)/n.width*2-1,-((t-n.top)/n.height)*2+1),this.ray.setFromCamera(this.ptr,this.camera);const r=new P;return this.ray.ray.intersectPlane(new Hn(new P(0,1,0),0),r)?r:null}input(){const e=this.canvas,t=new Map;let n=!1,r=0,s=null,a=!1;const o=()=>{const[c,h]=[...t.values()];return{d:Math.hypot(c.x-h.x,c.y-h.y),a:Math.atan2(h.y-c.y,h.x-c.x)}};e.addEventListener("pointerdown",c=>{if(e.setPointerCapture(c.pointerId),t.set(c.pointerId,{x:c.clientX,y:c.clientY,sx:c.clientX,sy:c.clientY}),n=!1,r=performance.now(),t.size===2&&(s=o()),a=!1,this.ghost&&t.size===1){const h=this.groundAt(c.clientX,c.clientY);if(h){const[u,d]=vn(this.ghost.b,this.ghost.r),p=this.ghost.x-mn,g=this.ghost.z-mn;h.x>=p-.6&&h.x<=p+u+.6&&h.z>=g-.6&&h.z<=g+d+.6&&(a=!0)}}}),e.addEventListener("pointermove",c=>{const h=t.get(c.pointerId);if(!h)return;const u=c.clientX-h.x,d=c.clientY-h.y;if(h.x=c.clientX,h.y=c.clientY,Math.hypot(h.x-h.sx,h.y-h.sy)>7&&(n=!0),!!n){if(t.size===1){if(a&&this.ghost){this.ghostTo(c.clientX,c.clientY);return}if(c.buttons===2){this.cam.tyaw-=u*.008;return}const p=this.cam.dist*.0021*(this.camera.aspect<.8?1.45:1),g=Math.cos(this.cam.yaw),v=Math.sin(this.cam.yaw);this.cam.tx-=(u*g+d*v*1.3)*p,this.cam.tz-=(-u*v+d*g*1.3)*p,this.clampCam()}else if(t.size===2&&s){const p=o();this.cam.tdist*=s.d/Math.max(1,p.d),this.cam.tyaw-=p.a-s.a,s=p,this.clampCam()}}});const l=c=>{const h=t.get(c.pointerId);t.delete(c.pointerId),t.size<2&&(s=null),!(!h||n||c.button===2)&&(performance.now()-r>600||this.tap(c.clientX,c.clientY))};e.addEventListener("pointerup",l),e.addEventListener("pointercancel",c=>t.delete(c.pointerId)),e.addEventListener("contextmenu",c=>c.preventDefault()),e.addEventListener("wheel",c=>{c.preventDefault(),this.cam.tdist*=Math.pow(1.0015,c.deltaY),this.clampCam()},{passive:!1}),window.addEventListener("keydown",c=>{c.target.tagName!=="INPUT"&&((c.key==="q"||c.key==="Q")&&(this.cam.tyaw+=Math.PI/4),(c.key==="e"||c.key==="E")&&(this.cam.tyaw-=Math.PI/4))})}tap(e,t){if(this.ghost){this.ghostTo(e,t);return}const n=this.canvas.getBoundingClientRect();this.ptr.set((e-n.left)/n.width*2-1,-((t-n.top)/n.height)*2+1),this.ray.setFromCamera(this.ptr,this.camera);const r=this.ray.intersectObjects([...this.views.values()].map(a=>a.pick),!1)[0];if(r){this.onTap({item:r.object.userData.item});return}const s=this.groundAt(e,t);this.onTap(s?{cell:[Math.floor(s.x+mn),Math.floor(s.z+mn)]}:{})}startGhost(e){this.ghost=e,this.env.showGrid(!0),this.rebuildGhost()}endGhost(){this.ghost=null,this.ghostObj&&this.scene.remove(this.ghostObj),this.ghostObj=null,this.env.showGrid(!1);for(const e of this.views.values())e.root.visible=!0}ghostTo(e,t){const n=this.groundAt(e,t);if(!n||!this.ghost)return;const[r,s]=vn(this.ghost.b,this.ghost.r),a=Math.round(n.x+mn-r/2),o=Math.round(n.z+mn-s/2);(a!==this.ghost.x||o!==this.ghost.z)&&(this.ghost.x=a,this.ghost.z=o,this.onGhostMove())}rotateGhost(){this.ghost&&(this.ghost.r=(this.ghost.r+1)%4,this.rebuildGhost(),this.onGhostMove())}rebuildGhost(){this.ghostObj&&this.scene.remove(this.ghostObj);const e=this.ghost,[t,n]=vn(e.b,e.r),r=new Wt,s=Zo(e.b,1,this.look);s.group.rotation.y=-e.r*Math.PI/2,s.group.traverse(o=>{const l=o;l.isMesh&&(l.castShadow=!1)}),r.add(s.group);const a=new mt(new li(t,n),Ws.ghostOk);a.rotation.x=-Math.PI/2,a.position.y=.06,a.name="foot",r.add(a),this.ghostObj=r,this.scene.add(r),this.syncGhost()}syncGhost(){const e=this.ghost;if(!e||!this.ghostObj)return;const[t,n]=vn(e.b,e.r);this.ghostObj.position.set(e.x+t/2-mn,.05,e.z+n/2-mn),this.ghostObj.getObjectByName("foot").material=e.ok?Ws.ghostOk:Ws.ghostBad}sync(e){const t=e.bases[this.baseId];if(!t)return;const n=Xr(e,this.baseId);(n.lo!==this.area.lo||n.hi!==this.area.hi)&&(this.area={lo:n.lo,hi:n.hi},this.env.setArea(n.lo,n.hi));const r=JSON.stringify(this.look),s=new Set;for(const o of t.items){s.add(o.id);const l=wi(e,o.id),c=`${o.b}|${o.lvl}|${o.r}|${l?1:0}|${r}`;let h=this.views.get(o.id);(!h||h.key!==c)&&(h&&this.scene.remove(h.root),h=this.makeView(o.id,o.b,o.lvl,o.r,!!l,c),this.views.set(o.id,h));const[u,d]=vn(o.b,o.r);h.root.position.set(o.x+u/2-mn,0,o.z+d/2-mn),h.root.visible=!(this.ghost&&this.ghost.move===o.id)}for(const[o,l]of this.views)s.has(o)||(this.scene.remove(l.root),this.views.delete(o));const a=new Set;for(const o of e.jobs)if(o.kind==="build"&&o.base===this.baseId&&(a.add(o.id),!this.drones.has(o.id))){const l=s_(),c=new mt(new ci(.08,6,4),new bn({color:"#bff8ff",toneMapped:!1}));l.add(c),this.scene.add(l),this.drones.set(o.id,{g:l,job:o.item,ph:Math.random()*6,spark:c})}for(const[o,l]of this.drones)a.has(o)||(this.scene.remove(l.g),this.drones.delete(o))}makeView(e,t,n,r,s,a){const o=new Wt,l=Zo(t,Math.max(1,n),this.look);l.group.rotation.y=-r*Math.PI/2,o.add(l.group);const[c,h]=vn(t,r),u=Math.max(.8,l.height),d=new mt(new Li(c*.96,u,h*.96),new bn({visible:!1}));d.position.y=u/2,d.userData.item=e,o.add(d);let p;return s&&(p=r_(c,h,Math.max(1,l.height*.8)),o.add(p),n===0&&(l.group.scale.y=.3)),this.scene.add(o),{key:a,root:o,model:l,pick:d,scaf:p}}centerOf(e){const t=this.views.get(e);return t?t.root.position.clone():null}topOf(e){const t=this.views.get(e);if(!t)return null;const n=t.root.position.clone();return n.y=t.model.height+.4,n}select(e){this.selected=e;const t=e?this.views.get(e):null;if(!t){this.selRing.visible=!1;return}const n=new di().setFromObject(t.pick),r=Math.max(n.max.x-n.min.x,n.max.z-n.min.z)*.62;this.selRing.scale.setScalar(r),this.selRing.position.set(t.root.position.x,.08,t.root.position.z),this.selRing.visible=!0}project(e){const t=new P(e.x,e.y,e.z).project(this.camera),n=this.canvas.getBoundingClientRect();return{x:n.left+(t.x+1)/2*n.width,y:n.top+(1-t.y)/2*n.height,behind:t.z>1}}burst(e,t,n=24){const r=new Float32Array(n*3),s=new Float32Array(n*3);for(let l=0;l<n;l++)r.set([e.x,e.y,e.z],l*3),s.set([(Math.random()-.5)*4,2+Math.random()*4,(Math.random()-.5)*4],l*3);const a=new gt;a.setAttribute("position",new jt(r,3));const o=new ep(a,new wu({color:t,size:.28,transparent:!0,depthWrite:!1}));this.scene.add(o),this.fx.push({pts:o,v:s,life:1})}frame(e,t,n){this.t+=t;const r=this.t;this.placeCamera(),this.env.update(r,t);for(const[s,a]of this.views)if(a.model.anim?.(r,{working:n(s)}),a.scaf){const o=a.scaf.children[0];o&&(o.rotation.y=0)}for(const s of this.drones.values()){const a=this.views.get(s.job);if(!a)continue;const o=a.model.height+.8,l=r*1.3+s.ph;s.g.position.set(a.root.position.x+Math.cos(l)*.9,o+Math.sin(r*3+s.ph)*.15,a.root.position.z+Math.sin(l)*.9),s.g.rotation.y=-l,s.spark.position.set(0,-.25-Math.random()*.1,0),s.spark.visible=Math.sin(r*23+s.ph)>.2}this.selRing.visible&&(this.selRing.material.opacity=.55+Math.sin(r*4)*.3);for(const s of[...this.fx]){s.life-=t*1.2;const a=s.pts.geometry.attributes.position;for(let o=0;o<a.count;o++)s.v[o*3+1]-=t*7,a.setXYZ(o,a.getX(o)+s.v[o*3]*t,a.getY(o)+s.v[o*3+1]*t,a.getZ(o)+s.v[o*3+2]*t);a.needsUpdate=!0,s.pts.material.opacity=Math.max(0,s.life),s.life<=0&&(this.scene.remove(s.pts),s.pts.geometry.dispose(),this.fx.splice(this.fx.indexOf(s),1))}if(this.quality==="low"){const s=this.renderer.shadowMap,a=this.sun.target.position;s.autoUpdate=!1,(++this.shF%3===0||Math.abs(a.x-this.shX)+Math.abs(a.z-this.shZ)>.001)&&(s.needsUpdate=!0,this.shX=a.x,this.shZ=a.z)}this.renderer.render(this.scene,this.camera)}}const Q=(i,e,t,n,r,s,a)=>({name:i,el:e,rarity:t,chassis:n,desc:r,...s?{price:s,unlock:a}:{}}),c_={helio:Q("Helio",["solar"],"standard","orb","A floating solar collector with a sunny disposition. Your first crewmate.",300,1),ember:Q("Ember",["plasma"],"standard","rover","Welds hull plates with a plasma torch it is very proud of.",350,1),tidepool:Q("Tidepool",["hydro"],"standard","crawler","Recycles every drop of water on the island. Twice.",400,2),frostbyte:Q("Frostbyte",["cryo"],"standard","walker","Keeps the servers cold and the jokes colder.",450,3),digger:Q("Digger",["geo"],"standard","rover","Has never met a rock it could not move.",500,3),sprout:Q("Sprout",["bio"],"standard","android","Talks to the greenhouse plants. They grow faster.",550,4),sparky:Q("Sparky",["volt"],"standard","drone","A hyperactive power drone. Do not let it near the coffee.",600,4),bolt:Q("Bolt",["alloy"],"standard","mech","Lifts girders, opens jars, never complains.",700,5),zephyr:Q("Zephyr",["aero"],"standard","drone","Rides the ventilation currents for fun.",800,5),lumen:Q("Lumen",["photon"],"standard","drone","A flying floodlight that loves an audience.",900,6),brawler:Q("Brawler",["kinetic"],"standard","mech","Built for demolition, adores being useful.",1e3,6),anchor:Q("Anchor",["gravity"],"standard","walker","Heavier than it looks, calmer than it sounds.",1200,7),umbra:Q("Umbra",["void"],"standard","orb","Absorbs stray light. Prefers the night shift.",1400,7),tick:Q("Tick",["chrono"],"standard","android","Always exactly on time, sometimes slightly early.",1600,8),cortex:Q("Cortex",["neural"],"standard","orb","A small AI that asks a lot of questions.",1800,8),solarflare:Q("Solarflare",["solar","plasma"],"advanced","drone","Catches sunlight, throws it back as fire.",2600,9),thunderhead:Q("Thunderhead",["volt","hydro"],"advanced","orb","A storm in a sphere. Crackles when it is happy.",3200,10),magmaw:Q("Magmaw",["geo","plasma"],"advanced","crawler","Eats rock, breathes lava, purrs.",3800,11),greenhouse:Q("Greenhouse",["bio","solar"],"advanced","android","A walking garden that photosynthesises on the job.",4400,12),glacier:Q("Glacier",["cryo","alloy"],"advanced","mech","Ice-armoured and unhurried. Nothing gets past.",5e3,13),floe:Q("Floe",["hydro","cryo"],"advanced","crawler","Skates across frozen reservoirs, clearing them.",5600,14),quarry:Q("Quarry",["geo","alloy"],"advanced","mech","Turns asteroids into neatly stacked bricks.",6200,15),mangrove:Q("Mangrove",["bio","hydro"],"advanced","walker","Grows roots into the water pipes. On purpose.",6900,16),dynamo:Q("Dynamo",["volt","alloy"],"advanced","rover","A rolling generator with a lot of torque.",7600,17),eclipse:Q("Eclipse",["void","photon"],"advanced","orb","Half light, half dark, entirely mysterious.",8400,18),rampart:Q("Rampart",["kinetic","alloy"],"advanced","mech","A wall that walks. Very reassuring.",9200,19),stormkite:Q("Stormkite",["aero","volt"],"advanced","drone","Flies into lightning to recharge.",1e4,20),monolith:Q("Monolith",["gravity","geo"],"advanced","walker","Stands perfectly still for days. Then dances.",11e3,21),paradox:Q("Paradox",["chrono","neural"],"advanced","android","Remembers things that have not happened yet.",12e3,22),synapse:Q("Synapse",["neural","volt"],"advanced","orb","Thinks in lightning. Talks in puns.",13e3,23),blizzard:Q("Blizzard",["aero","cryo"],"advanced","drone","Brings its own weather everywhere it goes.",14e3,24),prism:Q("Prism",["photon","solar"],"advanced","orb","Splits starlight into every colour it knows.",15e3,25),undertow:Q("Undertow",["void","gravity"],"advanced","crawler","Pulls things in. Gently. Usually.",16e3,26),blastforge:Q("Blastforge",["plasma","kinetic"],"advanced","mech","Forges hull plates with controlled explosions.",17500,27),rootbound:Q("Rootbound",["bio","geo"],"advanced","walker","Plants a tree with every step.",19e3,28),rainmaker:Q("Rainmaker",["hydro","aero"],"advanced","drone","Seeds clouds over the greenhouses.",20500,29),sundial:Q("Sundial",["chrono","photon"],"advanced","android","Tells time by the shadows it casts.",22e3,30),mycelium:Q("Mycelium",["neural","bio"],"advanced","crawler","A network of thinking fungus in a shell.",24e3,31),orbiter:Q("Orbiter",["gravity","aero"],"advanced","orb","Has its own small moon. It is very attached.",26e3,32),permafrost:Q("Permafrost",["cryo","void"],"advanced","walker","Cold enough to freeze light.",28e3,33),arcjet:Q("Arcjet",["volt","plasma"],"advanced","rover","Rides a cushion of ionised air.",3e4,34),mirrorplate:Q("Mirrorplate",["alloy","photon"],"advanced","mech","Polished so well it reflects your mood.",32e3,35),striker:Q("Striker",["kinetic","aero"],"advanced","drone","Fast, precise, slightly showing off.",34e3,36),pendulum:Q("Pendulum",["chrono","gravity"],"advanced","walker","Swings between moments.",36e3,37),oracle:Q("Oracle",["neural","photon"],"advanced","orb","Answers questions before you ask them.",38e3,38),mudlark:Q("Mudlark",["geo","hydro"],"advanced","rover","Happiest up to its axles in wet regolith.",4e4,39),sunvolt:Q("Sunvolt",["solar","volt"],"advanced","rover","Charges in sunlight, discharges in enthusiasm.",42e3,40),phantom:Q("Phantom",["void","neural"],"advanced","android","Appears on cameras that are switched off.",45e3,41),thermocline:Q("Thermocline",["plasma","cryo"],"advanced","crawler","Hot on one side, frozen on the other.",48e3,42),corona:Q("Corona",["solar","plasma","photon"],"elite","orb","A miniature star on a leash."),tsunami:Q("Tsunami",["hydro","kinetic","aero"],"elite","crawler","Moves like a wave and hits like one too."),tectonic:Q("Tectonic",["geo","gravity","kinetic"],"elite","mech","Rearranges continents for practice."),verdant:Q("Verdant",["bio","solar","hydro"],"elite","android","Terraforms a garden wherever it stands."),tesla:Q("Tesla",["volt","alloy","neural"],"elite","android","An inventor bot with a coil for a heart."),borealis:Q("Borealis",["cryo","photon","aero"],"elite","drone","Paints the polar sky in green fire."),nightshade:Q("Nightshade",["void","bio","neural"],"elite","crawler","Beautiful, clever, best kept at arm's length."),chronoforge:Q("Chronoforge",["chrono","plasma","alloy"],"elite","mech","Forges parts it will need tomorrow."),gravwell:Q("Gravwell",["gravity","void","hydro"],"elite","orb","A floating whirlpool that hums."),overclock:Q("Overclock",["volt","chrono","kinetic"],"elite","rover","Runs every process twice as fast. Including naps."),dreadnought:Q("Dreadnought",["alloy","kinetic","gravity"],"elite","mech","Armour plate all the way down."),lumina:Q("Lumina",["photon","bio","neural"],"elite","android","A gardener that glows in the dark."),supernova:Q("Supernova",["solar","plasma","gravity","photon"],"epic","orb","Contains a star's last breath, politely."),leviathan:Q("Leviathan",["hydro","cryo","gravity","kinetic"],"epic","crawler","The deep-ocean bot of Europa legends."),titanforge:Q("Titanforge",["alloy","geo","plasma","kinetic"],"epic","mech","Builds space stations single-handed. It has four hands."),gaia:Q("Gaia",["bio","geo","hydro","solar"],"epic","android","Turns dead rock into living soil."),tempest:Q("Tempest",["aero","volt","hydro","cryo"],"epic","drone","A hurricane that follows instructions."),eventide:Q("Eventide",["void","chrono","photon"],"epic","orb","Lives in the moment between day and night."),hivemind:Q("Hivemind",["neural","bio","alloy","volt"],"epic","crawler","A thousand tiny minds in one shell."),starweaver:Q("Starweaver",["photon","gravity","aero"],"epic","drone","Spins light sails from starlight."),quasar:Q("Quasar",["volt","void","photon","gravity"],"epic","orb","Brighter than a galaxy, smaller than a fridge."),juggernaut:Q("Juggernaut",["kinetic","alloy","gravity","geo"],"epic","mech","Unstoppable. Literally: nobody has tried."),solaris:Q("Solaris Prime",["solar","photon","plasma","neural"],"legendary","android","The first AI to dream of the Sun, and then build one."),abyssal:Q("Abyssal",["void","hydro","gravity","cryo"],"legendary","crawler","From the dark oceans beneath Enceladus."),chronarch:Q("Chronarch",["chrono","neural","photon","void"],"legendary","android","Keeper of every second the colony has lived."),colossus:Q("Colossus",["alloy","kinetic","geo","gravity"],"legendary","mech","A walking fortress the size of a hab block."),seraph:Q("Seraph",["aero","photon","bio","solar"],"legendary","drone","Six wings of light, one gentle voice."),voltaic:Q("Voltaic Storm",["volt","aero","plasma","kinetic"],"legendary","orb","Lightning that learned to fly."),omega:Q("Omega Protocol",["neural","alloy","chrono","kinetic"],"prototype","mech","The last line of code anyone wrote by hand."),genesis:Q("Genesis Engine",["bio","solar","hydro","geo"],"prototype","android","Makes worlds. Small ones, for now."),horizon:Q("Event Horizon",["gravity","void","chrono","photon"],"prototype","orb","Nothing it looks at can look away."),architect:Q("The Architect",["neural","chrono","gravity","photon"],"singularity","orb","It designed itself. Then it designed the rest."),primemover:Q("Prime Mover",["kinetic","plasma","solar","gravity"],"singularity","mech","The engine at the start of everything."),veyari:{...Q("Veyari Gardener",["bio","photon","void"],"legendary","android","A crystalline gardener from Proxima b, a gift from the Veyari to seal first contact."),alien:"contact"},synod:{...Q("Synod Envoy",["alloy","neural","chrono"],"legendary","mech","A delegate of the machine Synod of Barnard's Star. It votes on everything."),alien:"contact"},mycelar:{...Q("Mycelar Sporeling",["bio","neural","hydro"],"epic","crawler","A fragment of Tau Ceti's singing fungal mind, curious about everything."),alien:"contact"},oshoru:{...Q("Oshoru Swimmer",["hydro","aero","kinetic"],"epic","orb","A young Oshoru from TRAPPIST-1e, sent to see the stars."),alien:"contact"},lumenchoir:{...Q("Lumen Choir",["photon","solar","neural"],"prototype","orb","A being of pure light from Epsilon Eridani. It hums in harmonies."),alien:"contact"},krdrone:{...Q("Kr'thul Drone",["void","kinetic"],"advanced","crawler","A Swarm drone, captured and reprogrammed. Still a little bitey."),alien:"swarm"},krwarrior:{...Q("Kr'thul Warrior",["void","kinetic","plasma"],"elite","crawler","A Swarm warrior that now fights for the colony."),alien:"swarm"},solstice:{...Q("Solstice Seraph",["solar","photon","aero"],"legendary","drone","Born in the light of the Solar Solstice. It never casts a shadow."),alien:"event"},champion:{...Q("Arena Champion",["kinetic","alloy","photon"],"legendary","mech","Forged for the Arena Cup. It bows before every fight."),alien:"event"},voyager:{...Q("Deep Voyager",["gravity","void","aero"],"legendary","orb","A Deep Space Week veteran that has seen the edge of the Solar System."),alien:"event"},chimera:{...Q("Chimera Core",["neural","bio","plasma","chrono"],"legendary","crawler","A happy accident of the Fusion Frenzy. Nobody is quite sure what it is."),alien:"event"},blossom:{...Q("Blossom Sentinel",["bio","hydro","photon"],"legendary","android","Guardian of the Garden Gala. Flowers open as it passes."),alien:"event"},anvil:{...Q("Anvil Titan",["alloy","plasma","geo"],"legendary","mech","Built during Forge Fest by every builder drone at once."),alien:"event"},aurorawisp:{...Q("Aurora Wisp",["aurora","relic","bio"],"epic","orb","A Precursor intelligence of Aurora, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},aurorawarden:{...Q("Aurora Warden",["aurora","relic","photon"],"legendary","android","A Precursor intelligence of Aurora, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},auroraprime:{...Q("Aurora Prime",["aurora","relic","solar"],"prototype","drone","A Precursor intelligence of Aurora, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},arcanaglyph:{...Q("Arcana Glyph",["arcana","relic","neural"],"epic","orb","A Precursor intelligence of Arcana, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},arcanamagus:{...Q("Arcana Magus",["arcana","relic","chrono"],"legendary","android","A Precursor intelligence of Arcana, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},arcanaprime:{...Q("Arcana Prime",["arcana","relic","void"],"prototype","orb","A Precursor intelligence of Arcana, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},entropyspark:{...Q("Entropy Spark",["entropy","relic","plasma"],"epic","crawler","A Precursor intelligence of Entropy, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},entropyreaver:{...Q("Entropy Reaver",["entropy","relic","kinetic"],"legendary","mech","A Precursor intelligence of Entropy, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},entropyprime:{...Q("Entropy Prime",["entropy","relic","gravity"],"prototype","orb","A Precursor intelligence of Entropy, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},joysprite:{...Q("Joy Sprite",["joy","relic","aero"],"epic","drone","A Precursor intelligence of Joy, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},joyjester:{...Q("Joy Jester",["joy","relic","volt"],"legendary","android","A Precursor intelligence of Joy, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},joyprime:{...Q("Joy Prime",["joy","relic","photon"],"prototype","orb","A Precursor intelligence of Joy, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},reveriedrifter:{...Q("Reverie Drifter",["reverie","relic","cryo"],"epic","orb","A Precursor intelligence of Reverie, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},reverieoracle:{...Q("Reverie Oracle",["reverie","relic","neural"],"legendary","android","A Precursor intelligence of Reverie, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},reverieprime:{...Q("Reverie Prime",["reverie","relic","hydro"],"prototype","drone","A Precursor intelligence of Reverie, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},soulember:{...Q("Soul Ember",["soul","relic","solar"],"epic","orb","A Precursor intelligence of Soul, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},soulkeeper:{...Q("Soul Keeper",["soul","relic","geo"],"legendary","mech","A Precursor intelligence of Soul, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},soulprime:{...Q("Soul Prime",["soul","relic","chrono"],"prototype","android","A Precursor intelligence of Soul, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},krbrood:{...Q("Kr'thul Brood",["void","bio","gravity","kinetic"],"epic","crawler","A living Swarm carrier. It keeps trying to adopt the other bots."),alien:"swarm"}},Ir={solar:{name:"Solar",color:"#ffb23e",glow:"#ffe08a",glyph:"☀",strong:["bio","cryo"],blurb:"Runs on starlight. Hums when the Sun is up."},plasma:{name:"Plasma",color:"#ff5a3c",glow:"#ffb08a",glyph:"♨",strong:["alloy","bio"],blurb:"Contained fire at ten thousand degrees."},hydro:{name:"Hydro",color:"#2f8cff",glow:"#9fd0ff",glyph:"≈",strong:["plasma","geo"],blurb:"Pumps, cleans and cools. Every colony needs water."},cryo:{name:"Cryo",color:"#7fe4ff",glow:"#dff8ff",glyph:"❄",strong:["aero","bio"],blurb:"Supercooled circuits, near absolute zero."},geo:{name:"Geo",color:"#b07a4a",glow:"#e2b48c",glyph:"▲",strong:["volt","plasma"],blurb:"Drills, diggers and regolith movers."},bio:{name:"Bio",color:"#4fcf5a",glow:"#b6ffb0",glyph:"❦",strong:["hydro","geo"],blurb:"Gardeners of greenhouses and living hulls."},volt:{name:"Volt",color:"#ffe23a",glow:"#fff6a8",glyph:"ϟ",strong:["hydro","aero"],blurb:"Lightning in a capacitor."},alloy:{name:"Alloy",color:"#9aa7b8",glow:"#e6edf5",glyph:"⚙",strong:["cryo","kinetic"],blurb:"Armour, welders and heavy lifting."},void:{name:"Void",color:"#6b3fd6",glow:"#c2a6ff",glyph:"◐",strong:["photon","neural"],blurb:"Built for the dark between stars."},photon:{name:"Photon",color:"#fff4c2",glow:"#ffffff",glyph:"✦",strong:["void","chrono"],blurb:"Lasers, lenses and light."},kinetic:{name:"Kinetic",color:"#ff7a1a",glow:"#ffc28a",glyph:"✊",strong:["alloy","gravity"],blurb:"Impact, momentum, mass drivers."},aero:{name:"Aero",color:"#b9f0e6",glow:"#ecfffb",glyph:"༄",strong:["geo","kinetic"],blurb:"Flyers and atmosphere shapers."},gravity:{name:"Gravity",color:"#3c4aa8",glow:"#9aa6ff",glyph:"◉",strong:["aero","photon"],blurb:"Bends space a little, on purpose."},chrono:{name:"Chrono",color:"#c9a2ff",glow:"#eedcff",glyph:"⧗",strong:["neural","volt"],blurb:"Clocks running a little sideways."},neural:{name:"Neural",color:"#ff6fd8",glow:"#ffc4f0",glyph:"✺",strong:["kinetic","gravity"],blurb:"Artificial minds. They learn from everything."},relic:{name:"Relic",color:"#d8b46a",glow:"#fff0c4",glyph:"⌬",relic:!0,strong:[],blurb:"Precursor make, older than our species."},aurora:{name:"Aurora",color:"#6fffc8",glow:"#d6fff0",glyph:"❈",relic:!0,strong:[],blurb:"Beauty as a power source."},arcana:{name:"Arcana",color:"#8a5cff",glow:"#d7c6ff",glyph:"✧",relic:!0,strong:[],blurb:"Technology indistinguishable from magic."},entropy:{name:"Entropy",color:"#ff3d6e",glow:"#ffb3c6",glyph:"✹",relic:!0,strong:[],blurb:"Chaos, harnessed."},joy:{name:"Joy",color:"#ffd24a",glow:"#fff2b8",glyph:"☺",relic:!0,strong:[],blurb:"Precursor machines made to be happy."},reverie:{name:"Reverie",color:"#7aa8ff",glow:"#d2e2ff",glyph:"☾",relic:!0,strong:[],blurb:"They dream in mathematics."},soul:{name:"Soul",color:"#f2f2ff",glow:"#ffffff",glyph:"❂",relic:!0,strong:[],blurb:"Something in them is alive."}};Object.keys(Ir).filter(i=>!Ir[i].relic);const ed={standard:{name:"Standard",color:"#b9c3cf",earn:10,power:1,fuseChance:1,assembly:30},advanced:{name:"Advanced",color:"#5fdc7a",earn:15,power:1.2,fuseChance:.6,assembly:600},elite:{name:"Elite",color:"#4aa8ff",earn:22,power:1.45,fuseChance:.35,assembly:3600},epic:{name:"Epic",color:"#b06dff",earn:34,power:1.75,fuseChance:.18,assembly:4*3600},legendary:{name:"Legendary",color:"#ffa53a",earn:52,power:2.1,fuseChance:.08,assembly:12*3600},prototype:{name:"Prototype",color:"#ff4f6a",earn:80,power:2.6,fuseChance:.035,assembly:24*3600},singularity:{name:"Singularity",color:"#7af7ff",earn:125,power:3.2,fuseChance:.015,assembly:48*3600}},h_=Object.keys(ed),gn="#2c3340",Is="#cdd5df";function u_(i,e=1){const t=c_[i],n=Ir[t.el[0]].color,r=t.el[1]?Ir[t.el[1]].color:ai(n,-.35),s=ed[t.rarity].color,a=new Wt,o=new ct;let l=0;const c=v=>(a.add(v),v),h=v=>{const m=new ct;return v(m),m.build()};let u=()=>{};switch(t.chassis){case"orb":{l=.55,o.sphere(.26,n,0,0,0,{w:14,h:10}),o.sphere(.27,r,0,0,0,{w:14,h:4,theta:Math.PI*.18}),o.sphere(.09,s,0,.02,.22,{glow:!0,w:8,h:6}),o.sphere(.05,"#ffffff",.02,.05,.27,{glow:!0,w:6,h:4});const v=c(h(m=>m.add(new Ll(.38,.025,5,28),r)));v.rotation.x=Math.PI/2.4,u=m=>{v.rotation.z=m*1.8};break}case"drone":{l=.6,o.box(.34,.14,.34,n,0,-.07,0),o.sphere(.16,r,0,.05,0,{theta:Math.PI/2,w:10,h:5}),o.box(.12,.05,.02,s,0,-.01,.18,{glow:!0});const v=[];for(const[m,f]of[[.28,.28],[-.28,.28],[.28,-.28],[-.28,-.28]]){o.box(.24,.03,.04,gn,m/2,0,f/2,{ry:Math.atan2(m,f)});const _=c(h(S=>{S.cyl(.13,.13,.012,10,Is,0,0,0,{glass:!0}),S.box(.24,.01,.03,gn)}));_.position.set(m,.02,f),v.push(_)}u=m=>v.forEach((f,_)=>{f.rotation.y=m*30*(_%2?1:-1)});break}case"rover":{o.box(.5,.18,.36,n,0,.12,0),o.box(.3,.1,.3,r,-.05,.3,0),o.cyl(.02,.02,.22,5,Is,.12,.3,0),o.box(.14,.08,.08,gn,.12,.52,0),o.box(.02,.04,.06,s,.19,.53,0,{glow:!0});const v=[];for(const[m,f]of[[.17,.2],[-.17,.2],[.17,-.2],[-.17,-.2]]){const _=c(h(S=>S.cyl(.09,.09,.07,10,gn,0,-.035,0,{rx:Math.PI/2})));_.position.set(m,.09,f),v.push(_)}i==="digger"&&o.add(new Ai(.08,.22,7),Is,.32,.18,0,{rz:-Math.PI/2}),i==="ember"&&o.cyl(.035,.035,.2,5,gn,.25,.28,0,{rz:-.9}),u=(m,f)=>v.forEach(_=>{_.rotation.z=f?-m*8:0});break}case"walker":{const v=c(h(f=>{f.box(.36,.22,.3,n,0,0,0),f.box(.3,.06,.26,r,0,.22,0),f.box(.14,.05,.02,s,.06,.12,.16,{glow:!0}),f.box(.06,.05,.02,s,-.08,.12,.16,{glow:!0})}));v.position.y=.34;const m=[];for(const f of[.11,-.11]){const _=c(h(S=>{S.box(.07,.32,.07,gn,0,-.32,0),S.box(.13,.04,.16,r,0,-.34,.02)}));_.position.set(f,.36,0),m.push(_)}u=(f,_)=>{m.forEach((S,y)=>{S.rotation.x=_?Math.sin(f*9+y*Math.PI)*.5:0}),v.position.y=.34+(_?Math.abs(Math.sin(f*9))*.03:0)};break}case"android":{const v=c(h(f=>{f.box(.24,.3,.16,n,0,0,0),f.box(.26,.06,.18,r,0,.24,0),f.sphere(.12,Is,0,.42,0,{w:10,h:8}),f.box(.18,.05,.05,s,0,.43,.09,{glow:!0}),f.sphere(.035,s,0,.12,.085,{glow:!0,w:6,h:4})}));v.position.y=.3;const m=[];for(const[f,_,S,y]of[[.16,.56,.26,r],[-.16,.56,.26,r],[.07,.3,.3,gn],[-.07,.3,.3,gn]]){const A=c(h(E=>E.box(.07,S,.07,y,0,-S,0)));A.position.set(f,_,0),m.push(A)}i==="sprout"&&o.add(new ca(.08,0),"#5fdc5a",0,.86,0),u=(f,_)=>{m.forEach((S,y)=>{S.rotation.x=_?Math.sin(f*8+y%2*Math.PI+(y>1?Math.PI:0))*.55:Math.sin(f*1.5+y)*.05})};break}case"mech":{const v=c(h(f=>{f.box(.46,.34,.34,n,0,0,0),f.box(.2,.12,.2,r,0,.34,0),f.box(.16,.05,.02,s,0,.4,.105,{glow:!0});for(const _ of[.29,-.29])f.box(.14,.14,.2,r,_,.16,0),f.box(.11,.3,.11,gn,_,-.14,.02)}));v.position.y=.36;const m=[];for(const f of[.13,-.13]){const _=c(h(S=>{S.box(.12,.34,.12,gn,0,-.34,0),S.box(.18,.05,.22,r,0,-.36,.02)}));_.position.set(f,.38,0),m.push(_)}u=(f,_)=>{m.forEach((S,y)=>{S.rotation.x=_?Math.sin(f*5+y*Math.PI)*.35:0}),v.rotation.y=_?Math.sin(f*5)*.06:0};break}case"crawler":{const v=c(h(f=>{f.sphere(.16,n,.18,0,0,{w:10,h:7}),f.sphere(.13,r,0,0,0,{w:10,h:7}),f.sphere(.11,n,-.16,0,0,{w:10,h:7}),f.sphere(.035,s,.31,.04,.06,{glow:!0,w:6,h:4}),f.sphere(.035,s,.31,.04,-.06,{glow:!0,w:6,h:4})}));v.position.y=.2;const m=[];for(let f=0;f<6;f++){const _=.16-(f>>1)*.16,S=f%2?1:-1,y=c(h(A=>A.box(.03,.03,.24,gn,0,0,.1*S)));y.position.set(_,.18,.08*S),y.rotation.x=.5*S,m.push(y)}u=(f,_)=>m.forEach((S,y)=>{S.rotation.y=_?Math.sin(f*14+y)*.35:0});break}}const d=o.build("bot");a.add(d),(t.chassis==="orb"||t.chassis==="drone")&&(d.position.y=0);const p=new Wt;for(;a.children.length;)p.add(a.children[0]);if(p.position.y=l,a.add(p),l){const v=new mt(new El(.22,12),new bn({color:Ir[t.el[0]].glow,transparent:!0,opacity:.35,depthWrite:!1}));v.rotation.x=-Math.PI/2,v.position.y=.02,v.name="hoverGlow",a.add(v)}const g=.95+h_.indexOf(t.rarity)*.08+Math.min(.25,(e-1)*.008);return a.scale.setScalar(g),a.traverse(v=>{v.isMesh&&(v.castShadow=!0)}),{group:a,hover:l,anim:(v,m)=>{u(v,m),l&&(p.position.y=l+Math.sin(v*2.2+e)*.05)}}}class d_{constructor(e){this.renderer=e,this.scene=new vu,this.cam=new cn(30,1,.1,100),this.cache=new Map,this.size=192,this.rt=new Mn(this.size,this.size,{samples:4}),this.rt.texture.colorSpace=Ot;const t=new qo("#fff3df",2.6);t.position.set(-3,5,4),this.scene.add(t,new ku("#cfe4ff","#3a2a22",1.1));const n=new qo("#7ab6ff",.9);n.position.set(4,2,-4),this.scene.add(n)}shoot(e,t,n,r){const s=this.cache.get(t);if(s)return s;this.scene.add(e),this.cam.position.set(n*.7,r+n*.55,n*.85),this.cam.lookAt(0,r*.45,0);const a=this.renderer.getRenderTarget(),o=this.renderer.getClearColor(new Te),l=this.renderer.getClearAlpha(),c=this.renderer.shadowMap.enabled;this.renderer.setClearColor(0,0),this.renderer.setRenderTarget(this.rt),this.renderer.clear(),this.renderer.render(this.scene,this.cam);const h=new Uint8Array(this.size*this.size*4);this.renderer.readRenderTargetPixels(this.rt,0,0,this.size,this.size,h),this.renderer.setRenderTarget(a),this.renderer.setClearColor(o,l),this.renderer.shadowMap.enabled=c,this.scene.remove(e);const u=document.createElement("canvas");u.width=u.height=this.size;const d=u.getContext("2d"),p=d.createImageData(this.size,this.size);for(let v=0;v<this.size;v++)p.data.set(h.subarray((this.size-1-v)*this.size*4,(this.size-v)*this.size*4),v*this.size*4);d.putImageData(p,0,0);const g=u.toDataURL("image/png");return this.cache.set(t,g),g}building(e,t,n){const r=Zo(e,t,n),[s,a]=rt[e].fp,o=Math.max(s,a);return this.shoot(r.group,`b|${e}|${t}|${n.primary}${n.accent}${n.banner.bg}${n.banner.fg}${n.banner.emblem}`,o*1.45+1.2,Math.max(.8,r.height*.55))}bot(e){const t=u_(e,1);t.group.rotation.y=.5;const n=t.group.getObjectByName("hoverGlow");return n&&(n.visible=!1),this.shoot(t.group,`bot|${e}`,1.75,.55)}}const Mh=["credits","metal","fuel","science"],Gn=i=>`<span class="ci" style="color:${at[i]?.color||"#fff"}">${at[i]?.icon||""}</span>`;function Jo(i,e){return`<span class="costs">${Object.entries(i).filter(([,t])=>t>0).map(([t,n])=>`<span class="cost " title="${at[t]?.name||t}">${Gn(t)}${Je(n)}</span>`).join("")}</span>`}class f_{constructor(e){this.app=e,this.sel=null,this.over="",this.tab="production",this.rtab="avail",this.bubbles=new Map,this.lastRes={},this.panelKey="",this.tick=0,document.addEventListener("click",t=>{const n=t.target.closest("[data-a]");n&&(t.stopPropagation(),this.act(n.dataset.a,n))}),document.addEventListener("change",t=>{const n=t.target;if(n.id==="aname"){const r=n.value.trim().slice(0,24);r&&(this.s.name=r,this.s.bases.earth.name=r,this.app.changed(),this.renderHud())}n.dataset.set&&this.app.setSetting(n.dataset.set,n.type==="range"?+n.value:n.value)})}get s(){return this.app.s}get R(){return this.app.R}renderHud(){const e=this.s,t=this.R,n=Us(e,t);st("#hud").innerHTML=`<div class="kchip" data-a="kard" title="Kardashev scale"><div class="ring" id="kring"><b id="kval">${n.toFixed(2)}</b></div><div class="nm"><b>${Ke(e.name)}</b><i id="ktitle">Kardashev ${n.toFixed(3)}</i></div></div>
      ${Mh.map(r=>`<div class="res" id="r-${r}" data-a="resinfo" data-r="${r}" style="--c:${at[r].color}" title="${at[r].name}"><span class="ic" style="color:${at[r].color}">${at[r].icon}</span><span class="v">0</span><span class="cap"><i></i></span></div>`).join("")}
      <div class="res" id="r-dm" data-a="resinfo" data-r="dm" title="Dark Matter"><span class="ic" style="color:${at.dm.color}">${at.dm.icon}</span><span class="v">0</span></div>
      <span class="sp"></span><span class="chip" id="energy" data-a="energy" title="Energy: generation / demand">⚡ <span>0</span></span><span class="chip" id="crews" title="Construction drones">🛸 <span>0/0</span></span><button class="ibtn" data-a="settings" title="Settings">⚙</button>`,this.lastRes={},this.updHud()}updHud(){const e=this.s,t=this.R;for(const o of[...Mh,"dm"]){const l=st(`#r-${o}`);if(!l)continue;const c=Math.floor(e.res[o]||0);c!==this.lastRes[o]&&(l.querySelector(".v").textContent=Je(c),c>(this.lastRes[o]??c)&&(l.classList.remove("bump"),l.offsetWidth,l.classList.add("bump")),this.lastRes[o]=c);const h=t.cap[o],u=l.querySelector(".cap i");if(u&&isFinite(h)){const d=ln(c/Math.max(1,h));u.style.width=d*100+"%",l.classList.toggle("full",d>=.999),l.title=`${at[o].name}: ${Je(c)} / ${Je(h)}`}}const n=st("#energy");n&&(n.querySelector("span").textContent=`${Je(t.gen)} / ${Je(t.draw)}`,n.classList.toggle("low",t.gen<t.draw));const r=st("#crews");r&&(r.querySelector("span").textContent=`${Ji(e)}/${Ur(e,t.m)}`);const s=Us(e,t),a=st("#kval");if(a){a.textContent=s.toFixed(2);const o=Fs.find(c=>c>s)||3,l=[...Fs].reverse().find(c=>c<=s)||.7;st("#kring").style.setProperty("--p",ln((s-l)/(o-l))*100+"%"),st("#ktitle").textContent=`Kardashev ${s.toFixed(3)}`}}renderNav(){const e=this.s.jobs.some(t=>t.kind==="research")?"":Object.keys(pt).some(t=>Ys(this.s,t).ok)?'<span class="rdot"></span>':"";st("#nav").innerHTML=`<button data-a="shop"><span class="g">🏗</span>Build</button><button data-a="research"><span class="g">🔬</span>Research${e}</button><button data-a="goals"><span class="g">🎯</span>Goals</button><button data-a="kard"><span class="g">☀</span>Kardashev</button>`}renderObj(){const e=this.s,t=Tr(e),n=st("#obj");if(!t){n.classList.add("hidden");return}n.classList.remove("hidden");const r=ll(e,t,this.R),s=Ns.find(a=>a.id===t.ch);n.classList.toggle("done",r),n.innerHTML=`<div class="t">${Ke(s?s.name:"Objective")}</div><p>${Ke(t.text)}</p><div class="rw">Reward: ${Jo(t.reward)}</div>${r?'<button class="btn gold claim" data-a="claim">✓ Claim reward</button>':this.hint(t)}`}hint(e){if(e.kind==="build"||e.kind==="hq"){const t=e.kind==="hq"?"hq":e.b,n=this.s.bases.earth.items.find(r=>r.b===t);return n?`<div class="go" data-a="goto" data-id="${n.id}">Show me →</div>`:`<div class="go" data-a="shopFor" data-b="${t}">Open the build menu →</div>`}return e.kind==="tech"?'<div class="go" data-a="research">Open research →</div>':""}frameBubbles(){const e=this.s,t=this.app.world,n=this.R,r=st("#bubbles"),s=new Set,a=e.bases[e.at];if(!a)return;const o=(l,c,h,u,d,p)=>{if(!c)return;const g=t.project(c);if(g.behind)return;s.add(l);let v=this.bubbles.get(l);v||(v=document.createElement("div"),v.className="bub",d&&(v.dataset.a=d,p&&(v.dataset.id=p)),r.appendChild(v),this.bubbles.set(l,v)),v.dataset.h!==h+u&&(v.innerHTML=h,v.className="bub "+u,v.dataset.h=h+u),v.style.left=g.x+"px",v.style.top=g.y+"px"};if(!t.ghost)for(const l of a.items){const c=t.topOf(l.id),h=wi(e,l.id);if(h){const p=ln(1-(h.end-Date.now())/(h.end-h.start));o("t"+l.id,c,`<span>${ti((h.end-Date.now())/1e3)}</span><div class="bar"><i style="width:${p*100}%"></i></div>`,"timer");continue}const u=n.item[l.id],d=l.held||0;if(u&&d>=Math.max(1,u.hold*.03)){const p=d>=u.hold*.98;o("c"+l.id,c,`<span class="bi" style="color:${at[u.r].color}">${at[u.r].icon}</span>${Je(d)}`,p?"full":"","collect",l.id)}}for(const[l,c]of this.bubbles)s.has(l)||(c.remove(),this.bubbles.delete(l))}popText(e,t,n,r="#fff"){const s=document.createElement("div");s.className="pop",s.textContent=n,s.style.left=e+"px",s.style.top=t+"px",s.style.color=r,document.body.appendChild(s),setTimeout(()=>s.remove(),1100)}select(e){this.sel=e,this.app.world.select(e),this.renderPanel()}panelSig(){const e=this.s,t=this.sel?Vt(e,e.at,this.sel):null;if(!t)return"";const n=wi(e,t.id);return[t.id,t.lvl,t.x,t.z,n?n.id:"",$s(e,e.at,t.id).ok,Ji(e),Math.floor((e.res.dm||0)/5)].join("|")}refreshPanel(){if(!this.sel)return;if(this.panelSig()!==this.panelKey){this.renderPanel();return}const t=this.s;Qr("#panel [data-left]").forEach(a=>{const o=t.jobs.find(l=>l.id===a.dataset.left);o&&(a.textContent=ti((o.end-Date.now())/1e3))}),Qr("#panel [data-bar]").forEach(a=>{const o=t.jobs.find(l=>l.id===a.dataset.bar);o&&(a.style.width=ln(1-(o.end-Date.now())/(o.end-o.start))*100+"%")}),Qr("#panel [data-dm]").forEach(a=>{const o=t.jobs.find(l=>l.id===a.dataset.dm);if(o){const l=Er((o.end-Date.now())/1e3);a.innerHTML=l?`${Gn("dm")}${l} Finish now`:"Finish (free)"}});const n=Vt(t,t.at,this.sel),r=n&&this.R.item[n.id],s=st("#panel #held");if(s&&r&&n){s.textContent=`${Je(n.held||0)} / ${Je(r.hold)}`;const a=st("#panel #heldbar");a&&(a.style.width=ln((n.held||0)/r.hold)*100+"%")}Qr("#panel [data-cost]").forEach(a=>{const[o,l]=a.dataset.cost.split(":");a.classList.toggle("short",(t.res[o]||0)<+l)})}renderPanel(){const e=st("#panel"),t=this.s,n=this.sel?Vt(t,t.at,this.sel):null;if(!n){e.classList.add("hidden");return}e.classList.remove("hidden"),this.panelKey=this.panelSig();const r=rt[n.b],s=this.R.m,a=wi(t,n.id),o=al(t,t.at,n.b);let l=`<button class="ibtn x" data-a="deselect">✕</button><h2>${Ke(r.name)}</h2><div class="sub">${n.lvl?`Level ${n.lvl} of ${r.max}`:"Under construction"}${!r.command&&o<r.max?` · up to ${o} at this ${t.at==="earth"?"Mission Control":"Colony Hub"} level`:""} · ${Jl[r.cat]||""}</div><p class="desc">${Ke(r.desc)}</p>`;if(a){const h=Er((a.end-Date.now())/1e3);l+=`<div class="box"><div class="row"><b class="grow ox">${a.from===0?"Building":`Upgrading to level ${a.to}`}</b><b data-left="${a.id}">${ti((a.end-Date.now())/1e3)}</b></div><div class="bar" style="margin:6px 0"><i data-bar="${a.id}" style="width:0%"></i></div><div class="row"><button class="btn gold small grow" data-a="finish" data-job="${a.id}" data-dm="${a.id}">${h?`${Gn("dm")}${h} Finish now`:"Finish (free)"}</button><button class="btn small" data-a="cancel" data-job="${a.id}">Cancel</button></div></div>`}const c=this.R.item[n.id];if(c&&n.lvl>0&&(l+=`<div class="box"><div class="row"><span class="grow">${Gn(c.r)} Stored here <b id="held" class="ox">${Je(n.held||0)} / ${Je(c.hold)}</b></span><button class="btn green small" data-a="collect" data-id="${n.id}" ${(n.held||0)>=1?"":"disabled"}>Collect</button></div><div class="bar green" style="margin-top:6px"><i id="heldbar" style="width:${ln((n.held||0)/c.hold)*100}%"></i></div><div class="muted" style="font-size:11px;margin-top:4px">Fills in ${bh(n.lvl).toFixed(1)} h. Come back and tap the bubble to collect.</div></div>`),l+=this.statsHTML(n.b,Math.max(1,n.lvl),s,!a&&n.lvl<r.max),!a&&n.lvl>0){const h=$s(t,t.at,n.id);if(h.max)l+='<p class="good ox">Maximum level reached.</p>';else{const u=er(n.b,n.lvl+1,s);l+=`<div class="box"><div class="row"><b class="grow ox">Upgrade to level ${n.lvl+1}</b><span class="muted">⏱ ${ti(Nr(n.b,n.lvl+1,s))}</span></div><div style="margin:6px 0">${this.costLive(u)}</div>`,h.reqs&&h.reqs.length&&(l+=`<ul class="reqs">${h.reqs.map(([d,p])=>`<li>${Ke(rt[d].name)} level ${p}</li>`).join("")}</ul>`),l+=`<button class="btn ${h.ok?"gold":""}" style="width:100%" data-a="upgrade" data-id="${n.id}" ${h.ok||h.why==="Not enough resources"?"":"disabled"}>⬆ Upgrade</button>${h.ok?"":`<p class="why">${Ke(h.why||"")}</p>`}</div>`}}n.b==="research"&&(l+='<button class="btn" style="width:100%" data-a="research">🔬 Open research</button>'),l+=`<div class="row" style="margin-top:10px"><button class="btn small" data-a="move" data-id="${n.id}">✥ Move</button>${ol(t,t.at,n.id)?`<button class="btn small red" data-a="demolish" data-id="${n.id}">Demolish</button>`:""}</div>`,e.innerHTML=l,this.refreshPanel()}costLive(e){return`<span class="costs">${Object.entries(e).map(([t,n])=>`<span class="cost ${(this.s.res[t]||0)<n?"short":""}" data-cost="${t}:${n}">${Gn(t)}${Je(n)}</span>`).join("")}</span>`}statsHTML(e,t,n,r){const s=Ja(e,t,n),a=r?Ja(e,t+1,n):null,o=[],l=(c,h)=>h!==void 0&&h>c?`<span class="up">→ ${Je(h)}</span>`:"";for(const c in s.prod)o.push(`<tr><td>${Gn(c)} ${at[c].name} per hour</td><td>${Je(s.prod[c])}${l(s.prod[c],a?.prod[c])}</td></tr>`);for(const c in s.cap)o.push(`<tr><td>${Gn(c)} ${at[c].name} storage</td><td>+${Je(s.cap[c])}${l(s.cap[c],a?.cap[c])}</td></tr>`);return s.gen&&o.push(`<tr><td>⚡ Energy generated</td><td>${Je(s.gen)}${l(s.gen,a?.gen)}</td></tr>`),s.draw&&o.push(`<tr><td>⚡ Energy used</td><td>${Je(s.draw)}${a&&a.draw>s.draw?`<span class="up" style="color:var(--amber)">→ ${Je(a.draw)}</span>`:""}</td></tr>`),s.speed&&o.push(`<tr><td>🔬 Research speed</td><td>+${Math.round(s.speed*100)}%</td></tr>`),o.length?`<table class="stats">${o.join("")}</table>`:""}openOver(e,t){this.over=e,t&&(e==="shop"?this.tab=t:this.rtab=t),this.select(null),this.renderOver(),this.app.platform.gameplayStop()}closeOver(){this.over="",st("#over").classList.add("hidden"),this.app.platform.gameplayStart()}renderOver(){const e=st("#over");if(!this.over){e.classList.add("hidden");return}e.classList.remove("hidden");const t=this.s;if(this.over==="shop"){const n=t.at,r=["core","production","power","storage","science","spaceflight"].filter(o=>Object.values(rt).some(l=>l.cat===o&&l.bases.includes(n)));r.includes(this.tab)||(this.tab=r[0]);const s=o=>!o||!!t.tech[o]||pt[o]&&pt[o].req.every(l=>t.tech[l]),a=Object.entries(rt).filter(([,o])=>o.cat===this.tab&&o.bases.includes(n)&&!o.command&&s(o.req&&o.req.tech));e.innerHTML=`<div class="head"><h1>Build</h1><span class="chip">🛸 ${Ji(t)}/${Ur(t,this.R.m)} drones busy</span><button class="ibtn" data-a="close">✕</button></div><div class="tabs">${r.map(o=>`<button class="tab ${o===this.tab?"on":""}" data-a="tab" data-t="${o}">${Jl[o]}</button>`).join("")}</div>
        <div class="body"><div class="grid">${a.map(([o,l])=>this.shopCard(o,l)).join("")||'<p class="muted">Nothing to build here yet.</p>'}</div></div>`;return}if(this.over==="research"){e.innerHTML=this.researchHTML();return}if(this.over==="goals"){e.innerHTML=this.goalsHTML();return}}shopCard(e,t){const n=this.s,r=Xs(n,n.at,e),s=Sn(n,n.at),a=sl(n,n.at,e),o=wh(t,s),l=er(e,1,this.R.m),c=!r.ok&&r.why!=="Not enough resources"&&!r.crews;return`<div class="card ${c?"locked":""}"><div class="thumb"><img src="${this.app.studio.building(e,1,this.app.world.look)}" alt=""></div><div class="row"><b class="grow">${Ke(t.name)}</b><span class="n">${a}/${o}</span></div><p class="desc">${Ke(t.desc)}</p>
      <div class="row"><span class="grow">${this.costLive(l)}</span><span class="muted" style="font-size:11px">⏱ ${ti(Nr(e,1,this.R.m))}</span></div><button class="btn ${r.ok?"gold":""} small" data-a="buy" data-b="${e}" ${r.ok||r.why==="Not enough resources"?"":"disabled"}>${c?"🔒 "+Ke(r.why||""):"Build"}</button></div>`}researchHTML(){const e=this.s,t=e.jobs.filter(o=>o.kind==="research"),n=Object.keys(pt),r=[["avail","Available"],...Object.entries(ga).map(([o,l])=>[o,l.name]),["done","Done"]];let s=n.filter(o=>this.rtab==="avail"?!e.tech[o]&&pt[o].req.every(l=>e.tech[l]):this.rtab==="done"?!!e.tech[o]:pt[o].branch===this.rtab);s.sort((o,l)=>pt[o].tier-pt[l].tier||(pt[o].hq||0)-(pt[l].hq||0));const a=t.map(o=>{const l=pt[o.tech],c=Er((o.end-Date.now())/1e3);return`<div class="now"><div class="grow"><div class="tier">RESEARCHING</div><b class="ox" style="font-size:16px">${Ke(l.name)}</b><div class="bar gold" style="margin-top:6px"><i style="width:${ln(1-(o.end-Date.now())/(o.end-o.start))*100}%"></i></div></div><div style="text-align:right"><b class="ox">${ti((o.end-Date.now())/1e3)}</b><br><button class="btn gold small" data-a="finish" data-job="${o.id}">${c?`${Gn("dm")}${c}`:"Finish"}</button></div></div>`}).join("");return`<div class="head"><h1>Research</h1><span class="chip">🔬 ${rl(e)}/${il(e,this.R.m)} slots</span><button class="ibtn" data-a="close">✕</button></div><div class="tabs">${r.map(([o,l])=>`<button class="tab ${o===this.rtab?"on":""}" data-a="rtab" data-t="${o}">${Ke(l)}</button>`).join("")}</div>
      <div class="body">${a}<div class="techs">${s.map(o=>this.techCard(o)).join("")||'<p class="muted">Nothing here yet.</p>'}</div></div>`}techCard(e){const t=this.s,n=pt[e],r=Ys(t,e),s=!!t.tech[e],a=t.jobs.some(h=>h.kind==="research"&&h.tech===e),o=jo(n),l=s?"done":a?"busy":r.locked?"locked":r.ok?"ready":"",c=r.time||nl(e,this.R);return`<div class="tech ${l}" style="--bc:${ga[n.branch]?.color}"><div class="row"><span class="tier grow">${Ke(ga[n.branch]?.name||"")} · TIER ${n.tier}${n.hq?` · MC ${n.hq}`:""}</span>${s?'<span class="good">✓</span>':""}</div><b>${Ke(n.name)}</b><p class="desc">${Ke(n.desc)}</p>${n.unlocks?`<div class="unl">Unlocks: ${Ke(n.unlocks)}</div>`:""}
      ${s?"":a?'<div class="warn ox">In progress</div>':`<div class="row"><span class="grow">${this.costLive(o)}</span><span class="muted" style="font-size:11px">⏱ ${ti(c)}</span></div><button class="btn small ${r.ok?"gold":""}" data-a="study" data-t="${e}" ${r.ok||r.why==="Not enough resources"?"":"disabled"}>${r.ok?"Research":Ke(r.why||"")}</button>`}</div>`}goalsHTML(){const e=this.s,t=Tr(e);let n=`<div class="head"><h1>Goals</h1><span class="chip">${Vh(e)}/${Wh()} complete</span><button class="ibtn" data-a="close">✕</button></div><div class="body" style="max-width:760px;margin:0 auto;width:100%">`;for(const r of Ns){if(!r.steps.some(a=>e.obj.claimed[a.id]||t&&t.id===a.id)){n+=`<div class="box muted">🔒 ${Ke(r.name)}</div>`;continue}n+=`<div class="box"><b class="ox">${Ke(r.name)}</b><p class="desc">${Ke(r.intro)}</p><ul class="reqs">${r.steps.map(a=>`<li class="${e.obj.claimed[a.id]?"ok":""}" style="${t&&t.id===a.id?"color:var(--gold)":e.obj.claimed[a.id]?"":"opacity:.55"}">${Ke(a.text)}</li>`).join("")}</ul></div>`}return n+"</div>"}kardHTML(){const e=this.s,t=this.R,n=Us(e,t),r=e.kMax||0,s=a=>ln((a-.7)/2.3)*100;return`<div class="ox muted" style="letter-spacing:.2em">THE KARDASHEV SCALE</div><div class="kbig">${n.toFixed(3)}</div><b class="ox">${Ke(wd(n))}</b>
      <p class="desc">How much energy a civilisation commands. Humanity today runs about 20 terawatts (0.73). Type I harnesses a whole planet, Type II a star, Type III a galaxy. Every watt you generate moves the needle.</p>
      <div class="kscale">${[[.73,"Today"],[1,"Type I"],[2,"Type II"],[3,"Type III"]].map(([a,o])=>`<span class="lb" style="left:${s(+a)}%">${o}</span>`).join("")}<span class="mk" style="left:${s(n)}%"></span></div>
      <div class="mlist">${Fs.map(a=>`<div class="ms ${r>=a?"got":""}">${a.toFixed(2)}<i>${r>=a?"reached":`${Gn("dm")}${td(a)}`}</i></div>`).join("")}</div>
      <p class="muted" style="font-size:12px">Power now: ${Je(t.gen)} generated, ${Je(t.draw)} used.</p><button class="btn" data-a="closeModal">Close</button>`}toast(e,t=""){const n=document.createElement("div");n.className="toast "+t,n.innerHTML=e,st("#toasts").appendChild(n),setTimeout(()=>n.remove(),3200)}modal(e,t={}){const n=st("#modal");n.innerHTML=`${t.rays?'<div class="rays"></div>':""}<div class="box ${t.wide?"wide":""}">${e}</div>`,n.classList.remove("hidden"),this.app.platform.gameplayStop()}closeModal(){st("#modal").classList.add("hidden"),st("#modal").innerHTML="",this.over||this.app.platform.gameplayStart()}deny(e){e&&this.toast(Ke(e),"bad"),this.app.audio.play("deny")}settingsHTML(){const e=this.s.settings;return`<h1>Settings</h1><div class="box" style="text-align:left"><label class="ox">Agency name<input id="aname" value="${Ke(this.s.name)}" maxlength="24" style="width:100%;margin-top:6px;padding:10px;border-radius:10px;border:1px solid var(--line);background:#0d1a2e;color:#fff;font:600 15px Barlow"></label>
      <label class="row" style="margin-top:10px"><span class="grow">Sound effects</span><input type="range" min="0" max="1" step="0.05" value="${e.sfx}" data-set="sfx"></label><label class="row"><span class="grow">Music</span><input type="range" min="0" max="1" step="0.05" value="${e.music}" data-set="music"></label>
      <label class="row"><span class="grow">Graphics</span><select data-set="quality" style="background:#0d1a2e;color:#fff;border:1px solid var(--line);border-radius:8px;padding:6px">${["auto","high","low"].map(t=>`<option ${e.quality===t?"selected":""}>${t}</option>`).join("")}</select></label></div>
      <p class="muted" style="font-size:12px">Graphics changes apply after a reload. Camera: drag to pan, scroll or pinch to zoom, right-drag, two-finger twist or Q/E to rotate.</p><div class="row" style="justify-content:center"><button class="btn red small" data-a="reset">Start over</button><button class="btn" data-a="closeModal">Close</button></div>`}act(e,t){const n=this.app,r=this.s;n.audio.unlock();const s=t.dataset.id,a=s?Vt(r,r.at,s):void 0;switch(e){case"shop":this.openOver("shop"),n.audio.play("tap");break;case"shopFor":{const o=rt[t.dataset.b];this.openOver("shop",o?o.cat:void 0),n.audio.play("tap");break}case"research":this.openOver("research",this.rtab),n.audio.play("tap");break;case"goals":this.openOver("goals"),n.audio.play("tap");break;case"close":this.closeOver(),n.audio.play("tap");break;case"tab":this.tab=t.dataset.t,this.renderOver(),n.audio.play("tap");break;case"rtab":this.rtab=t.dataset.t,this.renderOver(),n.audio.play("tap");break;case"kard":this.modal(this.kardHTML(),{wide:!0}),n.audio.play("tap");break;case"settings":this.modal(this.settingsHTML()),n.audio.play("tap");break;case"closeModal":this.closeModal(),n.audio.play("tap");break;case"claim":{const o=qh(r);if(o){n.audio.play("claim"),this.toast(`Objective complete: ${Jo(o.reward)}`,"gold"),n.changed();const l=Tr(r);if(l&&l.ch!==o.ch){const c=Ns.find(h=>h.id===l.ch);c&&n.enqueue(()=>this.modal(`<div class="ox muted" style="letter-spacing:.2em">NEW CHAPTER</div><h1>${Ke(c.name)}</h1><p class="desc">${Ke(c.intro)}</p><button class="btn gold" data-a="closeModal">Onward</button>`,{rays:!0}))}}break}case"goto":if(s){const o=n.world.centerOf(s);o&&n.world.focus(o.x,o.z),this.select(s),n.audio.play("tap")}break;case"deselect":this.select(null);break;case"collect":a&&n.collect(a.id);break;case"upgrade":if(a){const o=Uh(r,r.at,a.id);o.ok?(n.audio.play("build"),n.changed(),this.renderPanel()):this.deny(o.why)}break;case"finish":{const o=zh(r,t.dataset.job);o.ok?(n.audio.play("done"),n.tickNow(),this.renderOver()):this.deny(o.why);break}case"cancel":Gh(r,t.dataset.job)&&(n.audio.play("tap"),this.toast("Cancelled: half the cost refunded"),n.changed(),this.sel&&!Vt(r,r.at,this.sel)&&this.select(null));break;case"buy":{const o=t.dataset.b,l=Xs(r,r.at,o);if(!l.ok){this.deny(l.why);break}this.closeOver(),n.startPlacing(o);break}case"study":{const o=kh(r,t.dataset.t);o.ok?(n.audio.play("buy"),n.changed(),this.renderOver(),this.renderNav()):this.deny(o.why);break}case"move":a&&n.startPlacing(a.b,a.id);break;case"demolish":a&&this.modal(`<h1>Demolish?</h1><p class="desc">${Ke(rt[a.b].name)} (level ${a.lvl}) will be cleared. Nothing is refunded.</p><div class="row" style="justify-content:center"><button class="btn" data-a="closeModal">Keep it</button><button class="btn red" data-a="demolishYes" data-id="${a.id}">Demolish</button></div>`);break;case"demolishYes":a&&Oh(r,r.at,a.id)&&(this.closeModal(),this.select(null),n.changed(),n.audio.play("build"));break;case"place":n.confirmPlace();break;case"rotate":n.world.rotateGhost(),n.audio.play("tap");break;case"unplace":n.cancelPlace();break;case"resinfo":{const o=t.dataset.r,l=this.R,c=(l.prod[o]||0)+(l.collect[o]||0);this.toast(`${at[o].icon} <b>${at[o].name}</b>: ${Je(r.res[o]||0)}${isFinite(l.cap[o])?` / ${Je(l.cap[o])}`:""}${c?` · +${Je(c)}/h`:""}`);break}case"energy":{const o=this.R;this.toast(o.gen>=o.draw?`⚡ ${Je(o.gen)} generated, ${Je(o.draw)} used. All systems powered.`:`⚡ Power shortage: ${Je(o.gen)} of ${Je(o.draw)}. Production runs at ${Math.round((.25+.75*o.eff)*100)}%. Build or upgrade Solar Farms.`,o.gen>=o.draw?"good":"bad");break}case"reset":this.modal('<h1>Start over?</h1><p class="desc">Your whole programme will be erased. This cannot be undone.</p><div class="row" style="justify-content:center"><button class="btn" data-a="closeModal">Cancel</button><button class="btn red" data-a="resetYes">Erase everything</button></div>');break;case"resetYes":n.reset();break}}}const td=i=>Math.round(10+(i-.7)*60);class p_{constructor(){this.ctx=null,this.out=null,this.vol=.8,this.mvol=.45,this.muted=!1,this.music=null,this.timer=0}unlock(){if(this.ctx){this.ctx.state==="suspended"&&this.ctx.resume();return}try{this.ctx=new(window.AudioContext||window.webkitAudioContext),this.out=this.ctx.createGain(),this.out.gain.value=this.muted?0:this.vol,this.out.connect(this.ctx.destination)}catch{this.ctx=null}}setVolume(e){this.vol=e,this.out&&(this.out.gain.value=this.muted?0:e)}setMuted(e){this.muted=e,this.out&&(this.out.gain.value=e?0:this.vol),this.music&&(this.music.bus.gain.value=e?0:this.mvol*.4)}tone(e,t,n,r="sine",s=.2,a=0){const o=this.ctx,l=o.createOscillator(),c=o.createGain();l.type=r,l.frequency.setValueAtTime(e,t),a&&l.frequency.exponentialRampToValueAtTime(Math.max(30,e*a),t+n),c.gain.setValueAtTime(0,t),c.gain.linearRampToValueAtTime(s,t+.008),c.gain.exponentialRampToValueAtTime(1e-4,t+n),l.connect(c),c.connect(this.out),l.start(t),l.stop(t+n+.05)}noise(e,t,n=.2,r=800){const s=this.ctx,a=s.createBuffer(1,Math.floor(s.sampleRate*t),s.sampleRate),o=a.getChannelData(0);for(let u=0;u<o.length;u++)o[u]=(Math.random()*2-1)*(1-u/o.length);const l=s.createBufferSource();l.buffer=a;const c=s.createBiquadFilter();c.type="lowpass",c.frequency.value=r;const h=s.createGain();h.gain.value=n,l.connect(c),c.connect(h),h.connect(this.out),l.start(e)}play(e,t=1){if(!this.ctx||!this.out||this.muted)return;const n=this.ctx.currentTime;switch(e){case"tap":this.tone(880,n,.06,"triangle",.08);break;case"collect":{const r=Math.min(6,2+Math.floor(Math.log10(Math.max(1,t))));[0,4,7,12,16,19].slice(0,r).forEach((s,a)=>this.tone(988*Math.pow(2,s/12),n+a*.055,.22,"triangle",.12));break}case"harvest":[0,5,9].forEach((r,s)=>this.tone(660*Math.pow(2,r/12),n+s*.06,.2,"square",.05)),this.tone(1320,n+.2,.3,"sine",.08);break;case"build":this.noise(n,.12,.25,500),this.tone(120,n,.18,"sine",.3,.5);break;case"place":this.tone(220,n,.12,"sine",.25,.6),this.noise(n,.08,.15,1200);break;case"done":[0,4,7,12].forEach((r,s)=>this.tone(523*Math.pow(2,r/12),n+s*.08,.3,"triangle",.12));break;case"feed":this.tone(300,n,.15,"sawtooth",.06,2.2),this.tone(600,n+.05,.12,"square",.04,1.6);break;case"levelup":[0,4,7,12,16,19,24].forEach((r,s)=>this.tone(392*Math.pow(2,r/12),n+s*.07,.5,"triangle",.13)),[0,4,7].forEach(r=>this.tone(784*Math.pow(2,r/12),n+.55,.9,"sine",.09));break;case"deny":this.tone(180,n,.16,"square",.07,.7);break;case"buy":this.tone(660,n,.1,"triangle",.1),this.tone(990,n+.08,.18,"triangle",.1);break;case"claim":[0,7,12].forEach((r,s)=>this.tone(659*Math.pow(2,r/12),n+s*.07,.35,"triangle",.12));break;case"whoosh":this.noise(n,.35,.18,2400);break;case"hit":this.noise(n,.09,.22,900),this.tone(170,n,.12,"square",.07,.5);break;case"crit":this.noise(n,.18,.32,1800),this.tone(95,n,.28,"sawtooth",.11,.4),this.tone(1250,n+.02,.16,"triangle",.06,.5);break;case"launch":this.noise(n,1.8,.32,320),this.tone(55,n,1.8,"sawtooth",.1,2.6),this.noise(n+.2,1.4,.12,2600);break;case"crystal":[0,7,12,19].forEach((r,s)=>this.tone(1046*Math.pow(2,r/12),n+s*.05,.45,"sine",.07)),this.tone(2093,n+.22,.6,"triangle",.03);break;case"evolve":[0,4,7,11,14,19,24].forEach((r,s)=>{this.tone(330*Math.pow(2,r/12),n+s*.06,.55,"triangle",.1),this.tone(660*Math.pow(2,r/12),n+s*.06+.02,.4,"sine",.04)}),this.noise(n+.42,.5,.08,5e3);break;case"sparkle":[12,19,24,31].forEach((r,s)=>this.tone(784*Math.pow(2,r/12)/2,n+s*.045,.3,"sine",.06));break}}setMusic(e){this.mvol=e,this.music?this.music.bus.gain.setTargetAtTime(this.muted?0:e*.4,this.ctx.currentTime,.4):e>0&&this.startMusic()}startMusic(){if(!this.ctx||this.music||this.mvol<=0)return;const e=this.ctx,t=e.createGain();t.gain.value=0,t.gain.setTargetAtTime(this.muted?0:this.mvol*.4,e.currentTime,2),t.connect(e.destination);const n=e.createBiquadFilter();n.type="lowpass",n.frequency.value=1200,n.connect(t),this.music={bus:t,next:e.currentTime+.5,chord:0,lp:n},this.timer=window.setInterval(()=>this.tick(),300)}tick(){const e=this.ctx,t=this.music;if(!e||!t||e.state!=="running")return;const n=e.currentTime;if(n<t.next)return;const r=[[261.63,329.63,392,493.88],[220,261.63,329.63,392],[174.61,220,261.63,329.63],[196,246.94,293.66,392],[233.08,293.66,349.23,440]],s=r[t.chord%r.length];t.chord+=1+(Math.random()<.25?1:0);const a=9;for(const o of s)for(const l of[-6,5]){const c=e.createOscillator();c.type="sawtooth",c.frequency.value=o/2,c.detune.value=l;const h=e.createGain();h.gain.setValueAtTime(0,n),h.gain.linearRampToValueAtTime(.011,n+3),h.gain.setValueAtTime(.011,n+a-2.5),h.gain.linearRampToValueAtTime(0,n+a+1),c.connect(h),h.connect(t.lp),c.start(n),c.stop(n+a+1.5)}for(let o=0;o<3;o++){const l=s[Math.floor(Math.random()*s.length)]*2,c=e.createOscillator();c.type="sine",c.frequency.value=l;const h=e.createGain(),u=n+1+o*2.4+Math.random();h.gain.setValueAtTime(0,u),h.gain.linearRampToValueAtTime(.03,u+.01),h.gain.exponentialRampToValueAtTime(1e-4,u+2.5),c.connect(h),h.connect(t.bus),c.start(u),c.stop(u+2.6)}t.lp.frequency.setTargetAtTime(800+Math.random()*900,n,3),t.next=n+a-1.5}}class m_{constructor(){this.version="2.0-dev",this.platform=od,this.audio=new p_,this.last=performance.now(),this.acc=0,this.saveAt=0,this.queue=[],this.placing=null}async boot(){await this.platform.init(),this.platform.loadingStart();let e=null;try{e=this.platform.load(Ql)}catch{e=null}let t=null;try{t=e?JSON.parse(e):null}catch{t=null}this.s=t&&t.v?fd(t):Za();const n=Date.now()-this.s.last,r={...this.s.res},s=ja(this.s,Date.now());this.R=si(this.s),this.s.stats.sessions++,this.world=new l_(st("#gl"),this.s.settings.quality),this.studio=new d_(this.world.renderer),this.ui=new f_(this),this.world.setWorld(this.s.at,this.s.bases[this.s.at].body),this.world.sync(this.s),this.world.onTap=c=>this.tapped(c),this.world.onGhostMove=()=>this.ghostMoved();const a=Xr(this.s,this.s.at),o=(a.lo+a.hi)/2-26;this.world.focus(o,o+2,30+a.side*.55),this.world.cam.dist=30+a.side*.55,this.ui.renderHud(),this.ui.renderNav(),this.ui.renderObj(),this.audio.setVolume(this.s.settings.sfx),this.audio.mvol=this.s.settings.music,this.platform.onMute=c=>this.audio.setMuted(c),this.audio.setMuted(this.platform.muted()),document.addEventListener("pointerdown",()=>{this.audio.unlock(),this.audio.startMusic()},{once:!0}),document.addEventListener("visibilitychange",()=>{document.hidden?this.save():this.tickNow()}),window.addEventListener("pagehide",()=>this.save()),window.__app=this,window.__G=Cd,requestAnimationFrame(c=>this.loop(c)),this.platform.loadingStop();const l=st("#load");l.style.opacity="0",setTimeout(()=>l.remove(),500),this.platform.gameplayStart(),this.s.stats.sessions===1&&this.s.obj.i===0?this.enqueue(()=>this.ui.modal(`<div class="ox muted" style="letter-spacing:.2em">CHAPTER 1</div><h1>Humble Beginnings</h1><p class="desc">A patch of coastal scrubland, a borrowed budget and a dream. Build the programme that will carry humanity from this launch pad to the stars, and one day to a civilisation spanning the galaxy.</p><p class="desc">Tap the bubbles over your Metal Mine and Agency Office to collect, then follow the goals card: every goal pays a reward.</p><button class="btn gold" data-a="closeModal">Let's begin</button>`,{rays:!0})):n>5*6e4&&this.enqueue(()=>this.report(n,r,s))}report(e,t,n){const r=Object.keys(at).filter(o=>(this.s.res[o]||0)-(t[o]||0)>=1).map(o=>`<span class="cost">${at[o].icon} +${Je(this.s.res[o]-t[o])}</span>`).join(" "),s=this.s.bases[this.s.at].items.reduce((o,l)=>o+(l.held||0),0),a=n.filter(o=>o.kind==="build"||o.kind==="research").map(o=>o.kind==="build"?`${Ke(rt[o.b].name)} → level ${o.lvl}`:`Researched ${Ke(pt[o.tech].name)}`);this.ui.modal(`<div class="ox muted" style="letter-spacing:.2em">WELCOME BACK</div><h1>${ti(e/1e3)} away</h1><div class="report"><div>${r||"Your stockpile is full or unchanged."}</div>${s>=1?`<div>Waiting in your collectors: <b>${Je(s)}</b>. Tap the bubbles!</div>`:""}${a.length?`<div>${a.slice(0,6).join("<br>")}</div>`:""}</div><button class="btn gold" data-a="closeModal">Back to work</button>`)}loop(e){const t=Math.min(.1,(e-this.last)/1e3);this.last=e,this.acc+=t,this.s.stats.playS+=t,this.acc>=.25&&(this.acc=0,this.tick()),this.world.frame(this.s,t,n=>{const r=Vt(this.s,this.s.at,n);return!!r&&r.lvl>0&&this.R.eff>.5}),this.ui.frameBubbles(),this.ui.refreshPanel(),this.queue.length&&st("#modal").classList.contains("hidden")&&!this.placing&&this.queue.shift()(),requestAnimationFrame(n=>this.loop(n))}tickNow(){this.tick(),this.changed()}tick(){const e=ja(this.s,Date.now());this.R=si(this.s);for(const r of e)this.note(r);e.length&&this.changed(),this.ui.updHud(),this.ui.tick++,this.ui.tick%4===0&&this.ui.renderObj(),this.ui.tick%12===0&&this.ui.renderNav();const t=Us(this.s,this.R),n=Fs.find(r=>r>(this.s.kMax||0)&&t>=r);if(n){this.s.kMax=n;const r=td(n);this.s.res.dm=(this.s.res.dm||0)+r,this.audio.play("levelup"),this.platform.happytime(),this.enqueue(()=>this.ui.modal(`<div class="ox muted" style="letter-spacing:.2em">KARDASHEV MILESTONE</div><div class="big">${n.toFixed(2)}</div><p class="desc">Your civilisation now commands more power than ever. Reward:</p><div class="rewards">${Jo({dm:r})}</div><button class="btn gold" data-a="closeModal">Onward</button>`,{rays:!0}))}Date.now()>this.saveAt&&(this.saveAt=Date.now()+1e4,this.save())}note(e){if(e.kind==="build"){const t=rt[e.b];this.audio.play("done");const n=this.world.topOf(e.item);n&&this.world.burst(n,"#ffd36a",28),this.ui.toast(`${Ke(t.name)} ${e.first?"is ready":`reached level ${e.lvl}`}`,"good"),e.b==="hq"&&(this.platform.happytime(),this.ui.toast("The spaceport grows: more room to build","gold"))}else e.kind==="research"&&(this.audio.play("levelup"),this.ui.toast(`Research complete: <b>${Ke(pt[e.tech].name)}</b>`,"gold"),this.ui.renderNav(),this.ui.over==="research"&&this.ui.renderOver())}changed(){this.R=si(this.s),this.world.sync(this.s),this.ui.renderObj(),this.ui.renderPanel(),this.ui.updHud(),this.saveAt=Math.min(this.saveAt,Date.now()+1500)}enqueue(e){this.queue.push(e)}tapped(e){if(!this.placing){if(e.item){const t=Vt(this.s,this.s.at,e.item);t&&this.R.item[t.id]&&(t.held||0)>=1&&this.ui.sel!==t.id&&this.collect(t.id),this.ui.select(e.item),this.audio.play("tap");return}this.ui.select(null)}}collect(e){const t=Bh(this.s,this.s.at,e,this.R);if(!t)return;if(t.n<=0){this.ui.toast(`${at[t.r].name} storage is full. Build or upgrade a Logistics Depot.`,"bad"),this.audio.play("deny");return}this.audio.play("collect",t.n);const n=this.world.topOf(e);if(n){this.world.burst(n,at[t.r].color,16+Math.min(24,Math.floor(Math.log10(t.n)*5)));const r=this.world.project(n);this.ui.popText(r.x,r.y-10,`+${Je(t.n)} ${at[t.r].icon}`,at[t.r].color)}t.full&&this.ui.toast(`${at[t.r].name} storage is full: the rest stays in the building.`,"bad"),this.changed()}startPlacing(e,t){const n=this.s;let r=0,s=0,a=0;if(t){const h=Vt(n,n.at,t);r=h.x,s=h.z,a=h.r}else{const h=Dh(n,n.at,e);if(!h){this.ui.deny("No room left: raise Mission Control to expand the spaceport");return}[r,s]=h}this.placing={b:e,move:t},this.ui.select(null),this.world.startGhost({b:e,r:a,x:r,z:s,move:t,ok:!0}),this.ghostMoved();const[o,l]=vn(e,a);this.world.focus(r+o/2-26,s+l/2-26);const c=st("#place");c.classList.remove("hidden"),c.innerHTML=`<span class="lbl">${t?"Move":"Place"} ${Ke(rt[e].name)}</span><button class="btn small" data-a="rotate">⟳ Rotate</button><button class="btn small red" data-a="unplace">✕</button><button class="btn small gold" data-a="place" id="placeOk">✓ ${t?"Move here":"Build here"}</button>`,this.world.sync(n)}ghostMoved(){const e=this.world.ghost;if(!e)return;e.ok=$r(this.s,this.s.at,e.b,e.x,e.z,e.r,e.move).ok,this.world.syncGhost();const t=st("#placeOk");t&&(t.disabled=!e.ok)}confirmPlace(){const e=this.world.ghost,t=this.placing;if(!e||!t)return;const n=this.s,r=t.move?Fh(n,n.at,t.move,e.x,e.z,e.r):Ih(n,n.at,e.b,e.x,e.z,e.r);if(!r.ok){this.ui.deny(r.why);return}this.audio.play(t.move?"place":"build"),this.cancelPlace(),!t.move&&r.item&&this.ui.select(r.item.id),this.changed()}cancelPlace(){this.placing=null,this.world.endGhost(),st("#place").classList.add("hidden"),this.world.sync(this.s)}setSetting(e,t){this.s.settings[e]=t,e==="sfx"&&this.audio.setVolume(t),e==="music"&&this.audio.setMusic(t),this.save()}save(){try{this.s.last=Math.max(this.s.last,Date.now()),this.platform.save(Ql,JSON.stringify(this.s))}catch{}}reset(){this.s=Za(),this.save(),location.reload()}}new m_().boot();
