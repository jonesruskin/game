(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const s of document.querySelectorAll('link[rel="modulepreload"]'))n(s);new MutationObserver(s=>{for(const r of s)if(r.type==="childList")for(const a of r.addedNodes)a.tagName==="LINK"&&a.rel==="modulepreload"&&n(a)}).observe(document,{childList:!0,subtree:!0});function t(s){const r={};return s.integrity&&(r.integrity=s.integrity),s.referrerPolicy&&(r.referrerPolicy=s.referrerPolicy),s.crossOrigin==="use-credentials"?r.credentials="include":s.crossOrigin==="anonymous"?r.credentials="omit":r.credentials="same-origin",r}function n(s){if(s.ep)return;s.ep=!0;const r=t(s);fetch(s.href,r)}})();const rh={save(i,e){try{localStorage.setItem(i,e)}catch{}},load(i){try{return localStorage.getItem(i)}catch{return null}}};let yn=null,Fr=!1;const si=()=>!!yn,Zf={name:"crazygames",adsAvailable:!1,onMute:null,async init(){const i=window.CrazyGames&&window.CrazyGames.SDK;if(i)try{if(await i.init(),i.environment&&i.environment!=="disabled"){yn=i,this.adsAvailable=!0;try{i.game.addSettingsChangeListener(e=>this.onMute&&this.onMute(!!(e&&e.muteAudio)))}catch{}}}catch(e){console.warn("CrazyGames SDK init failed; running standalone",e),yn=null}},loadingStart(){try{si()&&yn.game.loadingStart()}catch{}},loadingStop(){try{si()&&yn.game.loadingStop()}catch{}},gameplayStart(){if(!Fr){Fr=!0;try{si()&&yn.game.gameplayStart()}catch{}}},gameplayStop(){if(Fr){Fr=!1;try{si()&&yn.game.gameplayStop()}catch{}}},happytime(){try{si()&&yn.game.happytime()}catch{}},midgame(i){return ah("midgame",i)},rewarded(i){return ah("rewarded",i)},save(i,e){rh.save(i,e);try{si()&&yn.data.setItem(i,e)}catch{}},load(i){let e=null;try{si()&&(e=yn.data.getItem(i))}catch{e=null}return e||rh.load(i)},muted(){try{return si()&&!!yn.game.settings.muteAudio}catch{return!1}},notify(){},cancelNotify(){}};function ah(i,e){return new Promise(t=>{if(!si())return t(!1);try{yn.ad.requestAd(i,{adStarted:()=>e&&e(),adFinished:()=>t(!0),adError:()=>t(!1)})}catch{t(!1)}})}const zi=["moon","mars","ceres","titan"],at={hq:{name:"Mission Control",fp:[5,5],bases:["earth"],unique:!0,command:!0,max:20,cat:"core",cost:{credits:[400,2.1],metal:[500,2.1]},time:[-6,13,"ln"],prod:{credits:[500,1.2],science:[30,1.2]},cap:{credits:[8e3,1.55],metal:[6e3,1.55],fuel:[3e3,1.55],science:[2500,1.55],cells:[400,1.55]},gen:[12,1.2],desc:"The heart of the programme. Raising it expands the spaceport, allows higher building levels and adds construction drones at levels 5, 10 and 15."},research:{name:"Research Center",fp:[4,4],bases:["earth"],unique:!0,max:25,cat:"science",cost:{credits:[250,1.84],metal:[300,1.84]},time:[2,2],prod:{science:[150,1.24]},cap:{science:[2e3,1.5]},draw:[4,1.14],desc:"Laboratories, wind tunnels and clean rooms. Produces science and runs research projects."},university:{name:"University Campus",fp:[4,4],bases:["earth"],unique:!0,max:20,cat:"science",req:{hq:3},cost:{credits:[1200,1.84],metal:[1400,1.84]},time:[5,2],prod:{science:[90,1.24]},draw:[3,1.14],speed:.04,desc:"Trains the next generation of engineers. Each level speeds up all research by 4% and adds science."},mine:{name:"Metal Mine",fp:[3,3],bases:["earth"],max:25,cat:"production",count:[1,2,3,3,4,4,5,5,6,6],collect:!0,cost:{credits:[120,1.74],metal:[80,1.74]},time:[1,2],prod:{metal:[900,1.24]},draw:[2,1.14],desc:"Open-pit mining and smelting. Metal piles up at the mine until you collect it."},refinery:{name:"Fuel Refinery",fp:[3,3],bases:["earth"],max:25,cat:"production",count:[1,1,2,2,3,3,4,4,5,5],req:{hq:2},collect:!0,cost:{credits:[160,1.74],metal:[220,1.74]},time:[1.5,2],prod:{fuel:[450,1.24]},draw:[3,1.14],desc:"Cracks hydrocarbons and liquefies hydrogen and oxygen into rocket propellant."},office:{name:"Agency Office",fp:[3,3],bases:["earth"],max:25,cat:"production",count:[1,1,2,2,2,3,3,3,4,4],collect:!0,cost:{credits:[80,1.72],metal:[150,1.72]},time:[1,2],prod:{credits:[1100,1.24]},draw:[2,1.14],desc:"Public relations, contracts and grants: the money that keeps rockets flying."},solar:{name:"Solar Farm",fp:[3,3],bases:["earth"],max:25,cat:"power",count:[2,2,3,3,4,4,5,5,6,6],cost:{credits:[90,1.72],metal:[140,1.72]},time:[.5,1.95],gen:[12,1.24],desc:"Fields of photovoltaic panels. Clean, quiet power."},fission:{name:"Fission Plant",fp:[4,4],bases:["earth"],max:20,cat:"power",count:[0,0,1,1,1,2,2,2,3,3],req:{tech:"fission"},cost:{credits:[2500,1.82],metal:[3500,1.82]},time:[6,1.95],gen:[70,1.27],desc:"A pressurised-water reactor. Dense, reliable power for a growing programme."},depot:{name:"Logistics Depot",fp:[3,3],bases:["earth"],max:25,cat:"storage",count:[1,1,1,2,2,2,3,3,3,4],cost:{credits:[180,1.78],metal:[280,1.78]},time:[1.5,2],cap:{credits:[5e3,1.48],metal:[6e3,1.48],fuel:[3500,1.48],science:[1500,1.48],cells:[400,1.48],rare:[800,1.48],he3:[300,1.48]},draw:[1,1.1],desc:"Warehouses, tank farms and secure data vaults. Raises storage for every basic resource."},launch:{name:"Launch Complex",fp:[6,6],bases:["earth"],unique:!0,max:20,cat:"spaceflight",req:{tech:"rocketry"},cost:{credits:[1100,1.97],metal:[1600,1.97],fuel:[300,1.97]},time:[5,2.1],draw:[5,1.18],desc:"Pad, service tower and flame trench. Its level sets the largest rocket you can fly."},vab:{name:"Vehicle Assembly",fp:[4,5],bases:["earth"],unique:!0,max:20,cat:"spaceflight",req:{tech:"multistage"},cost:{credits:[1800,1.92],metal:[3e3,1.92]},time:[6,2.1],draw:[6,1.16],desc:"A cathedral of a hangar where rockets are stacked. Higher levels build bigger rockets faster."},tracking:{name:"Tracking Station",fp:[4,4],bases:["earth"],unique:!0,max:20,cat:"spaceflight",req:{tech:"guidance"},cost:{credits:[900,1.87],metal:[1100,1.87]},time:[5.5,2],prod:{science:[60,1.224]},draw:[4,1.15],desc:"Giant dish antennas that talk to spacecraft. Raises mission success and earns science from telemetry."},academy:{name:"Astronaut Academy",fp:[4,4],bases:["earth"],unique:!0,max:20,cat:"spaceflight",req:{tech:"lifeSupport"},cost:{credits:[3e3,1.87],metal:[3500,1.87]},time:[6.5,2],prod:{science:[40,1.224]},draw:[4,1.15],desc:"Centrifuges, pools and simulators. Crewed missions need graduates; each level makes them 1% safer."},workshop:{name:"Robotics Workshop",fp:[4,4],bases:["earth"],unique:!0,max:20,cat:"robots",req:{tech:"automation"},cost:{credits:[600,1.84],metal:[700,1.84]},time:[2.5,2],draw:[3,1.14],desc:"Assembly cells, welders and a test floor where new robots boot up. Builds robot cores; more assembly bays at levels 5, 10 and 15."},dock:{name:"Robot Dock",fp:[3,3],bases:["earth","moon","mars","ceres","titan"],max:25,cat:"robots",count:[1,1,2,2,2,3,3,3,4,4],req:{tech:"automation"},cost:{credits:[300,1.76],metal:[380,1.76]},time:[1.5,2],draw:[1,1.1],desc:"Charging cradles and maintenance arms. Houses robots: 3 plus one per level."},cellplant:{name:"Cell Plant",fp:[3,3],bases:["earth","moon","mars","ceres","titan"],max:25,cat:"robots",count:[1,1,1,2,2,2,3,3,3,3],req:{tech:"automation"},cost:{credits:[250,1.74],metal:[300,1.74]},time:[1.5,2],prod:{cells:[60,1.23]},cap:{cells:[500,1.45]},draw:[3,1.14],desc:"Charges Power Cells: they level your robots up and power new robot cores."},fusionlab:{name:"Fusion Lab",fp:[4,4],bases:["earth"],unique:!0,max:20,cat:"robots",req:{tech:"robotics",hq:4},cost:{credits:[5e3,1.84],metal:[5500,1.84]},time:[6,2],draw:[6,1.15],desc:"Merges the minds and bodies of two robots into a new hybrid core. Rarer parents make rarer robots; each level fuses 5% faster."},hub:{name:"Colony Hub",fp:[5,5],bases:zi,unique:!0,command:!0,max:20,cat:"core",cost:{credits:[6e4,2.05],metal:[8e4,2.05],fuel:[2e4,2.05]},time:[7.5,9.3,"ln"],prod:{science:[200,1.2]},cap:{he3:[600,1.55],metal:[2e4,1.5],fuel:[15e3,1.5],rare:[500,1.5]},gen:[40,1.2],house:[20,1.22],desc:"Command, life support and the airlock everyone passes through. Raising it expands the colony and allows higher building levels."},regolith:{name:"Regolith Mine",fp:[3,3],bases:["moon","mars","ceres"],jobs:[6,1.08],max:25,cat:"production",count:[2,2,3,3,4,4,5,5,6,6],collect:!0,cost:{credits:[18e3,1.74],metal:[12e3,1.74]},time:[8,1.95],prod:{metal:[3200,1.24]},draw:[6,1.14],desc:"Robotic excavators scrape the soil; furnaces pull out iron, aluminium and titanium."},ice:{name:"Ice Mine",fp:[3,3],bases:zi,jobs:[6,1.08],max:25,cat:"production",count:[1,1,2,2,2,3,3,3,4,4],collect:!0,cost:{credits:[22e3,1.74],metal:[16e3,1.74]},time:[8.5,1.95],prod:{fuel:[2200,1.24]},draw:[7,1.14],desc:"Buried ice, melted and split into hydrogen and oxygen. Water for the colonists, fuel made outside Earth's deep gravity well."},he3x:{name:"He-3 Extractor",fp:[3,3],bases:["moon"],jobs:[8,1.08],max:25,cat:"production",count:[1,1,1,2,2,2,3,3,3,4],req:{tech:"he3Mining"},cost:{credits:[6e4,1.77],metal:[5e4,1.77],fuel:[1e4,1.72]},time:[10,1.95],prod:{he3:[24,1.24]},draw:[12,1.15],desc:"Roasts regolith to release helium-3, a fusion fuel almost absent on Earth."},lsolar:{name:"Solar Array",fp:[3,3],bases:["moon","mars","ceres"],jobs:[2,1.05],max:25,cat:"power",count:[2,2,3,3,4,4,5,5,6,6],cost:{credits:[12e3,1.72],metal:[14e3,1.72]},time:[7.5,1.95],gen:[45,1.24],desc:"Ridge-top photovoltaic arrays. Superb on the Moon; weaker on Mars (43% of Earth's sunlight) and Ceres (13%)."},dome:{name:"Habitat Dome",fp:[4,4],bases:zi,house:[40,1.22],max:20,cat:"core",count:[1,1,1,2,2,2,3,3,3,4],req:{tech:"lunarHabitats"},cost:{credits:[4e4,1.77],metal:[45e3,1.77]},time:[11,1.95],prod:{credits:[2600,1.24]},cap:{he3:[300,1.45]},draw:[6,1.14],desc:"Homes under glass for colonists, and a garden the tourists pay well to see. Houses colonists."},llab:{name:"Colony Laboratory",fp:[4,4],bases:zi,jobs:[10,1.08],unique:!0,max:20,cat:"science",req:{tech:"lunarHabitats"},cost:{credits:[5e4,1.82],metal:[4e4,1.82]},time:[11.5,1.95],prod:{science:[900,1.24]},draw:[8,1.14],speed:.03,desc:"Field science where the samples are: vacuum labs, radio telescopes, geology. Science, plus 3% faster research per level."},massDriver:{name:"Mass Driver",fp:[2,7],bases:["moon"],jobs:[8,1.08],unique:!0,max:15,cat:"spaceflight",req:{tech:"massDrivers"},cost:{credits:[12e4,1.87],metal:[15e4,1.87]},time:[13,1.95],prod:{credits:[4e3,1.24]},draw:[25,1.16],fuelCut:.03,desc:"A kilometre of magnetic rail. Sells lunar metal to orbit and cuts mission fuel by 3% per level."},greenhouse:{name:"Greenhouse",fp:[4,3],bases:zi,max:20,cat:"core",count:[1,1,2,2,2,3,3,3,4,4],req:{tech:"spaceAgriculture"},jobs:[4,1.06],cost:{credits:[9e4,1.77],metal:[7e4,1.77]},time:[11,1.95],grow:[1.5,1.2],draw:[8,1.14],desc:"Hydroponic racks under LED light. A colony that feeds itself grows: more colonists every hour."},reactor:{name:"Colony Reactor",fp:[3,3],bases:zi,max:25,cat:"power",count:[1,1,2,2,3,3,4,4,5,5],req:{tech:"marsDirect"},jobs:[3,1.05],cost:{credits:[8e4,1.74],metal:[9e4,1.74]},time:[10,1.95],gen:[90,1.24],desc:"A compact fission reactor buried in the regolith. Steady power through dust storms, long nights and Titan's gloom."},terraformer:{name:"Atmosphere Processor",fp:[4,4],bases:["mars"],unique:!0,max:20,cat:"science",req:{tech:"planetaryEngineering"},jobs:[12,1.08],cost:{credits:[4e5,1.8],metal:[35e4,1.8]},time:[13,1.95],prod:{science:[3e3,1.24]},draw:[30,1.16],terra:.04,desc:"Cracks carbonates and vents greenhouse gases into the sky. Terraforming stages run 4% faster per level."},beltControl:{name:"Mining Control",fp:[4,4],bases:["ceres"],unique:!0,max:20,cat:"production",req:{tech:"beltSettlement"},jobs:[10,1.08],cost:{credits:[5e5,1.8],metal:[3e5,1.8]},time:[12,1.95],prod:{rare:[10,1.24]},cap:{rare:[2e3,1.5]},draw:[20,1.15],claims:.05,desc:"Traffic control for a thousand mining tugs. Every asteroid claim produces 5% more per level; refines rare elements."},methane:{name:"Hydrocarbon Refinery",fp:[3,3],bases:["titan"],max:25,cat:"production",count:[1,2,2,3,3,4,4,5,5,6],req:{tech:"cryoHabitats"},jobs:[8,1.08],collect:!0,cost:{credits:[3e5,1.74],metal:[25e4,1.74]},time:[11,1.95],prod:{fuel:[6e3,1.24]},draw:[18,1.15],desc:"Pumps liquid methane straight out of Kraken Mare. Titan sits on more hydrocarbons than all of Earth's oil and gas."},fusion:{name:"Fusion Plant",fp:[4,4],bases:["earth",...zi],max:25,cat:"power",count:[1,1,1,2,2,2,2,3,3,3,3,3,3,4,4,4],req:{tech:"fusionPower"},jobs:[6,1.06],cost:{credits:[6e5,1.74],metal:[5e5,1.74],he3:[150,1.6]},time:[12,1.95],gen:[700,1.24],desc:"A tokamak burning deuterium and helium-3. Enormous, clean power, if you can keep it fuelled with He-3."},elevator:{name:"Space Elevator",fp:[4,4],bases:["earth"],unique:!0,max:15,cat:"spaceflight",req:{tech:"spaceElevator"},cost:{credits:[5e6,1.8],metal:[4e6,1.8],rare:[3e3,1.6]},time:[16,1.95],prod:{credits:[2e4,1.24]},draw:[60,1.16],liftCut:.03,desc:"A ribbon from the equator to geostationary orbit. Climbers carry cargo up for the price of electricity: rockets and missions cost 3% less per level."},casimir:{name:"Casimir Foundry",fp:[4,4],bases:["earth"],unique:!0,max:20,cat:"science",req:{tech:"casimirEffect"},cost:{credits:[3e7,1.7],metal:[2e7,1.7],rare:[5e3,1.6]},time:[17,1.8],prod:{exotic:[3,1.24]},cap:{exotic:[300,1.5]},draw:[80,1.16],desc:"Stacks of nanometre-gap plates in a vacuum chamber, squeezing out exotic matter a microgram at a time."},xenolab:{name:"Xenology Institute",fp:[4,4],bases:["earth"],unique:!0,max:20,cat:"science",req:{tech:"xenolinguistics"},cost:{credits:[4e7,1.7],metal:[25e6,1.7]},time:[17,1.8],prod:{xeno:[25,1.24],influence:[8,1.22]},cap:{xeno:[1e4,1.5],influence:[4e3,1.5]},draw:[60,1.15],desc:"Linguists, xenobiologists and diplomats under one roof. Makes xenodata and influence; each level deciphers languages 5% faster."},antimatter:{name:"Antimatter Factory",fp:[4,4],bases:["earth","mars","ceres","titan"],max:20,cat:"production",count:[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,2,2,3],req:{tech:"antimatterProduction"},cost:{credits:[6e9,1.6],metal:[5e9,1.6],exotic:[2e3,1.5]},time:[18,1.7],prod:{antimatter:[6,1.24]},cap:{antimatter:[1500,1.5]},draw:[400,1.15],jobs:[20,1.06],desc:"A ring accelerator that smashes protons into antiprotons and traps them in magnetic bottles. Fuel for intergalactic drives."}},Hd=i=>3+.35*(i-1),Vd=(i,e)=>Math.min(i.max,i.command?i.max:e*2),Wd=(i,e)=>i.unique?1:i.count?i.count[Math.min(i.count.length-1,e-1)]:1,ho=(i,e,t)=>i.cap&&i.cap[e]?i.cap[e][0]*Math.pow(i.cap[e][1],Math.min(i.max,Math.max(1,t))-1):0;function Qf(i,e){return ho(at.hq,e,i)+ho(at.depot,e,2*i-4)+(e==="science"?ho(at.research,e,2*i-4):0)}const Yo=(i,e,t)=>{const n=Qf(e,t);return n>0?Math.min(i,Math.floor(n*.85/100)*100):i},jf=(i,e)=>{const t=at[i];return i==="hq"?Math.max(1,e-1):i==="hub"?e+7:!t.bases.includes("earth")&&!t.bases.includes("moon")?Math.ceil(e/2)+10:t.bases.includes("earth")?Math.max(1,Math.ceil(e/2)):Math.ceil(e/2)+7};function ep(i,e,t){const n=[],s=2*e-4;if(i==="hq"&&(e>=3&&n.push(["research",s],["depot",s]),e>=4&&n.push(["mine",s],["office",s]),e>=5&&n.push(["launch",s-2],["refinery",s-2]),e>=6&&n.push(["vab",s-4],["solar",s]),e>=7&&n.push(["tracking",s-4]),e>=8&&n.push(["academy",s-6])),i==="hub"&&(!t||t==="moon"))e>=2&&n.push(["regolith",2*e-2],["lsolar",2*e-2]),e>=3&&n.push(["ice",2*e-3],["he3x",2*e-4]),e>=4&&n.push(["dome",2*e-6],["llab",2*e-6]);else if(i==="hub"){const r={mars:"regolith",ceres:"ice",titan:"ice"}[t||"mars"]||"regolith";e>=2&&n.push([r,2*e-2],["dome",2*e-2]),e>=3&&n.push(["reactor",2*e-3],["greenhouse",2*e-4]),e>=4&&n.push(["llab",2*e-6])}return n.filter(([,r])=>r>0).map(([r,a])=>[r,Math.min(a,at[r].max)])}const tp=i=>2+(i>=5?1:0)+(i>=10?1:0)+(i>=15?1:0),oh={core:"Command",production:"Production",power:"Power",storage:"Storage",science:"Science",spaceflight:"Spaceflight",defense:"Defence",robots:"Robots",decor:"Decor"},ji=52,np=(i,e)=>i==="earth"?Math.min(ji,24+2*(e-1)):Math.min(40,18+2*(e-1)),lh="starward3d_v2",$d=2,Gn=ji/2;function Ko(i=Date.now()){let e=0;const t=(n,s,r,a=1,o=0)=>({id:"i"+(e++).toString(36),b:n,x:s,z:r,r:0,lvl:a,held:o});return{v:$d,created:i,last:i,seq:100,name:"Cape Horizon",res:{credits:1500,metal:1800,fuel:300,science:60,dm:30},bases:{earth:{body:"earth",name:"Cape Horizon",items:[t("hq",Gn-2,Gn-2),t("mine",Gn-9,Gn-6,1,400),t("solar",Gn-9,Gn-1),t("office",Gn+5,Gn-6,1,600),t("depot",Gn+5,Gn-1)]}},at:"earth",jobs:[],tech:{},flags:{},obj:{i:0,claimed:{}},stats:{built:0,upgrades:0,researched:0,dmSpent:0,collected:0,playS:0,sessions:0},settings:{sfx:.8,music:.45,quality:"auto"},tut:0,kMax:0}}function ip(i){const e=Ko(i.created||Date.now()),t=i;for(const n in e)t[n]===void 0&&(t[n]=e[n]);for(const n in e.stats)i.stats[n]===void 0&&(i.stats[n]=e.stats[n]);for(const n in e.settings)i.settings[n]===void 0&&(i.settings[n]=e.settings[n]);return i.v=$d,i}const Yn=(i,e="j")=>e+(i.seq++).toString(36),bt=(i,e=0,t=1)=>i<e?e:i>t?t:i,ch=["","K","M","B","T","Qa","Qi","Sx","Sp","Oc","No","Dc"];function qe(i,e=1){if(i===1/0)return"∞";if(!isFinite(i))return"–";const t=Math.abs(i),n=i<0?"-":"";if(t<1e3)return n+(t<10&&t%1?t.toFixed(1).replace(/\.0$/,""):Math.floor(t).toString());const s=Math.min(ch.length-1,Math.floor(Math.log10(t)/3)),r=t/Math.pow(1e3,s);return n+(r>=100?r.toFixed(0):r>=10?r.toFixed(e).replace(/\.0$/,""):r.toFixed(e+1).replace(/\.?0+$/,""))+ch[s]}function an(i){if(i=Math.max(0,Math.ceil(i)),i<60)return i+"s";const e=Math.floor(i/86400),t=Math.floor(i%86400/3600),n=Math.floor(i%3600/60),s=i%60;return e?`${e}d ${t}h`:t?`${t}h ${n}m`:s&&n<10?`${n}m ${s}s`:`${n}m`}const Ai=(i,e=0)=>(i*100).toFixed(e)+"%",Pn=(i,e,t)=>i*Math.pow(e,t-1),ss=[5,15,30,60,120,300,600,1200,1800,2700,3600,5400,7200,10800,14400,21600,28800,36e3,43200,57600,72e3,86400,108e3,129600,172800,216e3,259200,302400,345600,432e3,518400,604800,691200,777600,864e3,1036800,1209600];function qd(i){const e=ss.length-1;if(i<=0)return ss[0];if(i>=e)return ss[e];const t=Math.floor(i),n=i-t;return ss[t]*Math.pow(ss[t+1]/ss[t],n)}const sp=(i,e)=>qd(i[2]==="ln"?i[0]+i[1]*Math.log(e):i[0]+i[1]*Math.pow(e-1,.85)),ai=i=>{if(i<100)return Math.round(i);const e=Math.pow(10,Math.floor(Math.log10(i))-1);return Math.round(i/e)*e};function ja(i){let e=i>>>0;return()=>{e=e+1831565813|0;let t=Math.imul(e^e>>>15,1|e);return t=t+Math.imul(t^t>>>7,61|t)^t,((t^t>>>14)>>>0)/4294967296}}function rp(i){let e=2166136261;for(let t=0;t<i.length;t++)e^=i.charCodeAt(t),e=Math.imul(e,16777619);return e>>>0}const re=i=>String(i).replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),ht=(i,e=document)=>e.querySelector(i),Or=(i,e=document)=>Array.from(e.querySelectorAll(i)),uo={rocketry:{name:"Rocketry",color:"#ff8a5b"},engineering:{name:"Engineering",color:"#b8c4d6"},energy:{name:"Energy",color:"#ffd166"},computing:{name:"Computing",color:"#6ee7ff"},economy:{name:"Economy",color:"#7cf29a"},life:{name:"Life Sciences",color:"#ff9bd2"},astro:{name:"Astronomy",color:"#b892ff"},planetary:{name:"Planetary",color:"#ff7a59"},interstellar:{name:"Interstellar",color:"#ff6bd6"}},rt={rocketry:{name:"Rocketry Fundamentals",branch:"rocketry",tier:1,req:[],effect:{},unlocks:"Launch Complex",desc:"Newton's third law, thrust, specific impulse. The first step off the planet."},liquidProp:{name:"Liquid Propellants",branch:"rocketry",tier:1,req:["rocketry"],effect:{mult:{fuel:.15}},desc:"Kerosene and liquid oxygen: throttleable, restartable, powerful. Fuel output +15%."},multistage:{name:"Multistage Rockets",branch:"rocketry",tier:2,req:["liquidProp"],effect:{},unlocks:"Vehicle Assembly",desc:"Drop the empty tanks on the way up. The trick that makes orbit possible."},guidance:{name:"Inertial Guidance",branch:"rocketry",tier:2,req:["rocketry","computing"],effect:{},unlocks:"Tracking Station",desc:"Gyroscopes and accelerometers that know where the rocket is going."},orbital:{name:"Orbital Mechanics",branch:"rocketry",tier:3,req:["multistage","guidance"],effect:{flag:"orbit"},unlocks:"Satellite launches",desc:"Kepler, Hohmann and the art of falling around the Earth."},cryo:{name:"Cryogenic Engines",branch:"rocketry",tier:3,req:["multistage"],effect:{mult:{fuel:.1},flag:"cryo"},desc:"Liquid hydrogen at −253 °C: the highest-efficiency chemical rocket. Fuel output +10%."},crewed:{name:"Human Spaceflight",branch:"rocketry",tier:4,req:["orbital","lifeSupport"],effect:{flag:"crewed"},unlocks:"Crewed missions",desc:"Capsules, launch-escape towers and splashdowns. People in space."},reusable:{name:"Reusable Boosters",branch:"rocketry",tier:5,req:["crewed","simulation"],effect:{flag:"reusable"},desc:"Land the first stage and fly it again. Launch costs collapse."},heavy:{name:"Heavy Lift Vehicles",branch:"rocketry",tier:5,req:["crewed","alloys"],effect:{flag:"heavy"},desc:"Super-heavy rockets for the Moon and beyond."},automation:{name:"Industrial Automation",branch:"engineering",tier:1,req:[],effect:{mult:{metal:.15}},desc:"Conveyor belts, robots and process control. Metal output +15%."},alloys:{name:"Aerospace Alloys",branch:"engineering",tier:2,req:["automation"],effect:{mult:{metal:.15}},desc:"Aluminium-lithium and titanium alloys: light and strong. Metal output +15%."},modular:{name:"Modular Construction",branch:"engineering",tier:2,req:["automation"],effect:{buildTime:.08},desc:"Prefabricated sections assembled on site. Construction 8% faster."},robotics:{name:"Construction Robotics",branch:"engineering",tier:3,req:["modular","microchips"],effect:{crews:1},desc:"Tireless robotic builders join your crews. +1 engineering crew."},composites:{name:"Carbon Composites",branch:"engineering",tier:3,req:["alloys"],effect:{costs:.06},desc:"Carbon fibre everything. Build costs −6%."},additive:{name:"Additive Manufacturing",branch:"engineering",tier:4,req:["composites","simulation"],effect:{buildTime:.1,costs:.05},desc:"3D-printed engines and structures. Construction 10% faster, costs −5%."},photovoltaics:{name:"Advanced Photovoltaics",branch:"energy",tier:1,req:[],effect:{gen:.15},desc:"Multi-junction solar cells. Energy generation +15%."},batteries:{name:"Grid Storage",branch:"energy",tier:2,req:["photovoltaics"],effect:{cap:.12},desc:"Lithium battery farms smooth the grid and let you stockpile more. Storage +12%."},grid:{name:"Smart Grid",branch:"energy",tier:2,req:["photovoltaics","computing"],effect:{gen:.12},desc:"Software-balanced power distribution. Energy generation +12%."},fission:{name:"Nuclear Fission",branch:"energy",tier:3,req:["grid"],effect:{},unlocks:"Fission Plant",desc:"Split the atom, boil the water, spin the turbine."},breeder:{name:"Breeder Reactors",branch:"energy",tier:4,req:["fission"],effect:{gen:.2},desc:"Reactors that make more fuel than they burn. Energy generation +20%."},computing:{name:"Computer Science",branch:"computing",tier:1,req:[],effect:{researchTime:.05,mult:{science:.1}},desc:"Algorithms, compilers, numerical methods. Research 5% faster, science +10%."},microchips:{name:"Microprocessors",branch:"computing",tier:2,req:["computing"],effect:{mult:{science:.15}},desc:"A computer on a chip. Science +15%."},networks:{name:"Global Networks",branch:"computing",tier:3,req:["microchips"],effect:{slots:1},desc:"Laboratories worldwide share data in real time. +1 parallel research project."},simulation:{name:"Simulation & Modelling",branch:"computing",tier:3,req:["microchips"],effect:{buildTime:.05,mult:{science:.1}},desc:"Test it in silicon before steel. Construction 5% faster, science +10%."},ai:{name:"Artificial Intelligence",branch:"computing",tier:5,req:["simulation","networks"],effect:{crews:1,researchTime:.1},desc:"Machine minds plan, design and supervise. +1 crew, research 10% faster."},outreach:{name:"Public Outreach",branch:"economy",tier:1,req:[],effect:{mult:{credits:.15}},desc:"Launch broadcasts and school visits win hearts and budgets. Credits +15%."},contracts:{name:"Commercial Contracts",branch:"economy",tier:2,req:["outreach"],effect:{mult:{credits:.2}},desc:"Sell launches, data and patents. Credits +20%."},logistics:{name:"Supply Chains",branch:"economy",tier:2,req:["outreach"],effect:{cap:.15},desc:"Just-in-time logistics. Storage +15%."},investors:{name:"Private Investment",branch:"economy",tier:3,req:["contracts"],effect:{mult:{credits:.25}},desc:"Venture capital discovers space. Credits +25%."},medicine:{name:"Space Medicine",branch:"life",tier:2,req:["computing"],effect:{},desc:"What weightlessness does to bone, muscle and mind."},lifeSupport:{name:"Life Support Systems",branch:"life",tier:3,req:["medicine"],effect:{},desc:"Scrubbers, water recycling and oxygen generation for crewed vehicles."},radioAstro:{name:"Radio Astronomy",branch:"astro",tier:1,req:[],effect:{mult:{science:.1}},desc:"Listen to the universe in radio waves. Science +10%."},telescopes:{name:"Space Telescopes",branch:"astro",tier:4,req:["orbital","radioAstro"],effect:{flag:"telescopes"},unlocks:"Telescope satellites",desc:"Above the atmosphere the sky is perfectly sharp."},satComms:{name:"Communication Satellites",branch:"astro",tier:3,req:["orbital"],effect:{},unlocks:"Comms satellites",desc:"Arthur C. Clarke's geostationary relays: a satellite that hangs over one spot of the Earth."},remoteSensing:{name:"Remote Sensing",branch:"astro",tier:3,req:["orbital"],effect:{},unlocks:"Observation & weather satellites",desc:"Multispectral cameras and radar that read the planet from above."},orbitalOps:{name:"Orbital Operations",branch:"rocketry",tier:4,req:["orbital","networks"],effect:{flag:"orbitalOps"},desc:"Traffic control for crowded orbits. +1 low-orbit and +1 geostationary slot."},gps:{name:"Satellite Navigation",branch:"astro",tier:4,req:["satComms","networks"],effect:{},unlocks:"Navigation satellites",desc:"Atomic clocks in orbit. Know where everything is, to the centimetre."},deepSpace:{name:"Deep Space Navigation",branch:"rocketry",tier:4,req:["orbital","guidance"],effect:{},unlocks:"Lunar probes, deep space relays",desc:"Trajectory design and the Deep Space Network: reaching beyond Earth orbit."},spaceStation:{name:"Orbital Assembly",branch:"engineering",tier:5,req:["crewed","additive"],effect:{},unlocks:"Space station",desc:"Dock modules in orbit and bolt them together: a permanent home in space."},closedLoop:{name:"Closed-Loop Ecology",branch:"life",tier:5,req:["lifeSupport","spaceStation"],effect:{},unlocks:"Habitat modules",desc:"Recycle every drop of water and breath of air. Long stays become possible."},constellations:{name:"Satellite Constellations",branch:"astro",tier:5,req:["orbitalOps","reusable"],effect:{flag:"constellations"},desc:"Cheap mass-produced satellites in swarms. +2 low-orbit slots."},lunarLanders:{name:"Lunar Landers",branch:"rocketry",tier:6,req:["deepSpace","heavy"],effect:{},unlocks:"Crewed lunar landing",desc:"Descent engines, landing legs and the nerve to fly them."},spacePower:{name:"Space-Based Solar Power",branch:"energy",tier:6,req:["spaceStation","breeder"],effect:{},unlocks:"Solar power satellites",desc:"Collect sunlight where it never sets and beam it home."},isru:{name:"In-Situ Resource Utilisation",branch:"engineering",tier:6,req:["lunarLanders","closedLoop"],effect:{},unlocks:"Lunar outpost",desc:"Live off the land: oxygen from rock, water from ice, metal from regolith."},he3Mining:{name:"Helium-3 Extraction",branch:"energy",tier:7,req:["isru"],effect:{flag:"he3"},unlocks:"He-3 Extractor",desc:"Heat tonnes of regolith to release a few grams of the perfect fusion fuel."},lunarHabitats:{name:"Lunar Habitats",branch:"life",tier:7,req:["isru"],effect:{},unlocks:"Habitat Dome, Lunar Lab",desc:"Regolith-shielded domes where people can live for years."},massDrivers:{name:"Mass Drivers",branch:"engineering",tier:7,req:["isru","spacePower"],effect:{},unlocks:"Mass Driver",desc:"Electromagnetic rails that fling cargo off the Moon without a drop of fuel."},lowGravity:{name:"Low-Gravity Industry",branch:"engineering",tier:7,req:["isru"],effect:{mult:{metal:.15}},desc:"Smelt, cast and print in one-sixth gravity. Metal output +15%."},planetaryProbes:{name:"Planetary Probes",branch:"planetary",tier:7,req:["deepSpace","telescopes"],effect:{},unlocks:"Survey probes to any world",desc:"Radioisotope power, autonomous navigation and patience: robotic eyes on every planet."},nuclearThermal:{name:"Nuclear Thermal Propulsion",branch:"rocketry",tier:7,req:["heavy","fission"],effect:{},unlocks:"Hermes transfer ships",desc:"A reactor heats hydrogen to 2,500 °C. Twice the efficiency of chemistry: the inner Solar System opens up."},orbitalShipyard:{name:"Orbital Shipyards",branch:"engineering",tier:7,req:["spaceStation","robotics"],effect:{},unlocks:"Shipyard station module",desc:"Build ships too big to launch, in orbit where they will fly."},marsDirect:{name:"Mars Direct",branch:"planetary",tier:8,req:["nuclearThermal","isru"],effect:{},unlocks:"Mars colony, colony reactors, Phobos Depot",desc:"Make the return fuel on Mars from its own air. Robert Zubrin's plan, finally flown."},asteroidMining:{name:"Asteroid Mining",branch:"planetary",tier:8,req:["nuclearThermal","robotics"],effect:{},unlocks:"Mining claims in the belt",desc:"Grapple, bag and digest a mountain. One metal asteroid outweighs every mine on Earth."},spaceAgriculture:{name:"Space Agriculture",branch:"life",tier:8,req:["closedLoop","lunarHabitats"],effect:{},unlocks:"Greenhouses (colonists grow)",desc:"Hydroponics, LED light and Martian soil washed of perchlorates. Colonies that feed themselves can grow."},fusionPower:{name:"Fusion Power",branch:"energy",tier:8,req:["he3Mining","breeder"],effect:{gen:.1},unlocks:"Fusion Plant",desc:"Deuterium–helium-3 fusion: almost no neutrons, almost no waste, power without end. Energy +10%."},aerostats:{name:"Aerostat Habitats",branch:"planetary",tier:8,req:["planetaryProbes","composites"],effect:{},unlocks:"Venus cloud city",desc:"Breathable air is a lifting gas in Venus's heavy CO₂. A city can simply float."},colonyShips:{name:"Colony Ships",branch:"life",tier:9,req:["marsDirect","spaceAgriculture"],effect:{},unlocks:"Ares colony transports",desc:"Spin gravity, radiation shelters and room for families: mass emigration begins."},beltSettlement:{name:"Belt Settlement",branch:"planetary",tier:10,req:["asteroidMining","colonyShips"],effect:{},unlocks:"Ceres colony, Mining Control",desc:"Ceres has water, gravity enough to stand in, and every asteroid within reach. The belt gets a capital."},planetaryEngineering:{name:"Planetary Engineering",branch:"planetary",tier:9,req:["marsDirect","spacePower"],effect:{},unlocks:"Terraforming stages 1-2, Atmosphere Processor",desc:"Change a whole world's climate on purpose. Start with mirrors and greenhouse gases."},solarFurnace:{name:"Helios Concentrators",branch:"energy",tier:9,req:["spacePower","planetaryProbes"],effect:{gen:.05},unlocks:"Mercury Helios Array",desc:"Mercury gets seven times Earth's sunlight. Build where the light is. Energy +5%."},radiationShielding:{name:"Radiation Shielding",branch:"life",tier:10,req:["colonyShips","medicine"],effect:{},unlocks:"Jovian moon outposts",desc:"Water walls, magnetic bubbles and radiation-hardened medicine for Jupiter's killing belts."},fusionDrive:{name:"Fusion Drive",branch:"rocketry",tier:10,req:["fusionPower","nuclearThermal"],effect:{},unlocks:"Daedalus torch ships",desc:"Fusion exhaust at thousands of kilometres per second: thrust the whole way, Jupiter in hours."},gasGiantScoops:{name:"Atmospheric Scoops",branch:"energy",tier:11,req:["fusionDrive","he3Mining"],effect:{},unlocks:"He-3 scoops on Jupiter and Saturn, Enceladus",desc:"Dive into a gas giant at 60 km/s, gulp helium-3, climb back out. Repeat forever."},cometCapture:{name:"Comet Capture",branch:"planetary",tier:10,req:["planetaryEngineering","asteroidMining"],effect:{},unlocks:"Terraforming stage 3",desc:"Tiny pushes, applied decades early, steer an ice comet onto a chosen spot on Mars."},magnetosphere:{name:"Planetary Magnetic Shield",branch:"planetary",tier:10,req:["planetaryEngineering","fusionPower"],effect:{},unlocks:"Terraforming stage 4",desc:"A 1-2 tesla dipole at Mars–Sun L1 shades the planet from the solar wind (NASA, 2017)."},xenobiology:{name:"Xenobiology",branch:"life",tier:11,req:["radiationShielding","ai"],effect:{},unlocks:"Europa Deep Probe",desc:"How to recognise life that isn't ours, and how not to kill it by accident."},cryoHabitats:{name:"Cryogenic Habitats",branch:"planetary",tier:11,req:["fusionDrive","beltSettlement"],effect:{},unlocks:"Titan colony, Hydrocarbon Refinery",desc:"Insulated settlements for −180 °C, heated by fusion, under an orange sky."},hydrosphere:{name:"Ocean Engineering",branch:"planetary",tier:11,req:["cometCapture","magnetosphere"],effect:{},unlocks:"Terraforming stage 5",desc:"Melt the permafrost, fill the northern basin: an ocean for Mars."},spaceElevator:{name:"Space Elevator",branch:"engineering",tier:11,req:["alloys","orbitalShipyard","fusionPower"],effect:{},unlocks:"Space Elevator",desc:"A carbon-nanotube ribbon from the equator to geostationary orbit. Climb to space by train."},extremophiles:{name:"Engineered Extremophiles",branch:"life",tier:12,req:["xenobiology","hydrosphere"],effect:{},unlocks:"Terraforming stage 6",desc:"Lichens and algae rewritten to thrive in cold, thin, radiation-soaked air."},advancedFusion:{name:"Antimatter-Catalysed Fusion",branch:"rocketry",tier:12,req:["fusionDrive","cryoHabitats"],effect:{},unlocks:"Odyssey cruisers, the outer planets",desc:"A few micrograms of antiprotons ignite fusion hotter than any magnet can hold."},ecopoiesis:{name:"Ecopoiesis",branch:"life",tier:13,req:["extremophiles"],effect:{},unlocks:"Terraforming stage 7",desc:"Not engineering a planet: gardening one. Forests, soil and a breathable sky."},laserSails:{name:"Laser Light Sails",branch:"interstellar",tier:13,req:["solarFurnace","spaceElevator"],effect:{},unlocks:"Starshot Laser Array (megastructure)",desc:"Gram-scale probes on sails thinner than a soap bubble, pushed by lasers to a fifth of light speed."},exoplanetology:{name:"Exoplanetology",branch:"interstellar",tier:13,req:["planetaryProbes","xenobiology"],effect:{mult:{science:.1}},desc:"Read a world's atmosphere from its starlight. Science +10%."},sleeperShips:{name:"Sleeper Ships",branch:"interstellar",tier:14,req:["advancedFusion","cryoHabitats"],effect:{},unlocks:"Exodus Ark",desc:"Cryogenic suspension for ten thousand. Decades pass in a dreamless night."},starColonies:{name:"Star Colonies",branch:"interstellar",tier:14,req:["exoplanetology","colonyShips"],effect:{},unlocks:"Settling exoplanets (capacity 2)",desc:"Governance, supply and culture across light-years: how to found a world you will never visit."},dysonSwarm:{name:"Dyson Swarm",branch:"energy",tier:14,req:["solarFurnace","spaceElevator"],effect:{},unlocks:"Dyson Swarm (megastructure)",desc:"Disassemble Mercury into a cloud of mirrors and collectors around the Sun."},casimirEffect:{name:"Casimir Engineering",branch:"interstellar",tier:15,req:["laserSails","fusionDrive"],effect:{},unlocks:"Casimir Foundry (exotic matter)",desc:"Plates a few atoms apart squeeze the vacuum itself: negative energy density, bottled."},ramjets:{name:"Bussard Ramjets",branch:"rocketry",tier:15,req:["sleeperShips","gasGiantScoops"],effect:{},unlocks:"Pathfinder ramjets",desc:"Scoop interstellar hydrogen with magnetic fields a thousand kilometres wide and burn it on the fly."},domeWorlds:{name:"Dome Worlds",branch:"interstellar",tier:15,req:["starColonies","extremophiles"],effect:{},unlocks:"Settle hostile worlds, giants and belts (+2 capacity)",desc:"Domes, orbital habitats and mining stations: no world is too hostile to settle."},xenoarchaeology:{name:"Xenoarchaeology",branch:"life",tier:15,req:["exoplanetology","xenobiology"],effect:{mult:{science:.1}},desc:"The study of minds that are not human, from what they leave behind. Science +10%."},interstellarTrade:{name:"Interstellar Commerce",branch:"economy",tier:16,req:["starColonies","domeWorlds"],effect:{mult:{credits:.15}},unlocks:"Star colonies +15% (+2 capacity)",desc:"Light-lag contracts, tachyon-free banking and the first interstellar brands. Credits +15%."},warpTheory:{name:"Warp Field Theory",branch:"interstellar",tier:16,req:["casimirEffect","ramjets"],effect:{},desc:"Alcubierre's metric, made practical: the energy budget falls from a galaxy's worth to a few tonnes of exotic matter."},warpDrive:{name:"Warp Drive",branch:"rocketry",tier:17,req:["warpTheory"],effect:{},unlocks:"Herald warp ships",desc:"Space folds ahead and unfolds behind. Light-years in an afternoon."},wormholeGates:{name:"Wormhole Gates",branch:"interstellar",tier:17,req:["warpTheory","dysonSwarm"],effect:{},unlocks:"Sol Gate and colony gates",desc:"Two throats of a wormhole, held open with exotic matter and towed apart. Step through, arrive light-years away."},contactProtocols:{name:"First Contact Protocols",branch:"life",tier:16,req:["exoplanetology","xenoarchaeology"],effect:{},unlocks:"Meeting alien civilisations",desc:"What to say, what never to say, and who gets to speak for humanity. Written in a hurry."},xenolinguistics:{name:"Xenolinguistics",branch:"computing",tier:17,req:["contactProtocols"],effect:{},unlocks:"Deciphering alien languages, Xenology Institute",desc:"Grammar without grammar, meaning without shared senses. AI linguists and a lot of patience."},xenodiplomacy:{name:"Xenodiplomacy",branch:"economy",tier:18,req:["xenolinguistics","interstellarTrade"],effect:{},unlocks:"Embassies and agreements",desc:"Treaties with minds that do not share our instincts, our senses or our idea of a promise."},upliftEthics:{name:"Uplift Ethics",branch:"life",tier:18,req:["xenolinguistics","extremophiles"],effect:{},unlocks:"Uplifting minor species",desc:"When, if ever, may an elder species accelerate a younger one? The debate ends with a protocol."},navalWarfare:{name:"Naval Warfare",branch:"engineering",tier:18,req:["fusionDrive","ai"],effect:{},unlocks:"Corvettes, frigates, fleet operations",desc:"We never wanted warships. The Swarm did not ask what we wanted."},planetaryDefence:{name:"Planetary Defence",branch:"engineering",tier:19,req:["navalWarfare"],effect:{},unlocks:"Defences and shields for every base and colony",desc:"Laser batteries, missile silos and plasma shields over every world we hold."},guidedOrdnance:{name:"Guided Ordnance",branch:"rocketry",tier:19,req:["navalWarfare"],effect:{},unlocks:"Destroyers",desc:"Missiles that think, swarm and pick out the biggest target."},capitalShips:{name:"Capital Ships",branch:"engineering",tier:20,req:["guidedOrdnance","planetaryDefence"],effect:{},unlocks:"Cruisers and battleships",desc:"Kilometre-long hulls with layered armour and spinal weapons."},swarmTactics:{name:"Swarm Tactics",branch:"computing",tier:20,req:["planetaryDefence","xenolinguistics"],effect:{},unlocks:"+25% damage against the Kr'thul",desc:"We studied how the Swarm thinks. Now we can think one move ahead of it."},carrierWarfare:{name:"Carrier Warfare",branch:"rocketry",tier:21,req:["capitalShips"],effect:{},unlocks:"Carriers",desc:"Motherships launching clouds of autonomous missile drones."},antimatterProduction:{name:"Antimatter Production",branch:"energy",tier:21,req:["casimirEffect","dysonSwarm"],effect:{},unlocks:"Antimatter Factory",desc:"Particle accelerators fed by the Dyson Swarm, minting antiprotons by the gram."},relayNetwork:{name:"The Relay Network",branch:"interstellar",tier:21,req:["xenolinguistics","wormholeGates"],effect:{},unlocks:"Rebuilding the Hollow relays",desc:"The Hollow left relays on the paths between galaxies. We have learned how to wake them."},matrioshkaBrains:{name:"Matrioshka Brains",branch:"computing",tier:22,req:["antimatterProduction","swarmTactics"],effect:{},unlocks:"Matrioshka Brain (megastructure)",desc:"Nested shells of computers around a star: a mind the size of a solar system."},intergalacticDrive:{name:"Intergalactic Drive",branch:"rocketry",tier:22,req:["relayNetwork","antimatterProduction"],effect:{},unlocks:"Expeditions to other galaxies",desc:"Antimatter, exotic matter and the relays: two and a half million light-years in ten days."},ringworlds:{name:"Ringworld Engineering",branch:"engineering",tier:23,req:["matrioshkaBrains","domeWorlds"],effect:{},unlocks:"Ringworld (megastructure)",desc:"A band of land around a star, spun for gravity, walled to hold the air."},transcendence:{name:"Transcendence Studies",branch:"life",tier:24,req:["intergalacticDrive","ringworlds"],effect:{mult:{science:.2,credits:.1}},desc:"What the Ascendants became, and how. Science +20%, credits +10%."}},hh={orbital:4,satComms:4,lifeSupport:4,crewed:5,cryo:5,deepSpace:6,spaceStation:6,heavy:7,reusable:7,closedLoop:7,constellations:7,lunarLanders:8,spacePower:8,isru:9,he3Mining:9,lowGravity:9,lunarHabitats:10,massDrivers:10,planetaryProbes:10,nuclearThermal:10,orbitalShipyard:10,marsDirect:10,spaceAgriculture:10,asteroidMining:11,fusionPower:11,aerostats:11,colonyShips:11,planetaryEngineering:11,beltSettlement:12,solarFurnace:12,radiationShielding:12,fusionDrive:12,gasGiantScoops:12,cometCapture:12,magnetosphere:12,xenobiology:13,cryoHabitats:13,hydrosphere:13,spaceElevator:13,extremophiles:13,advancedFusion:13,ecopoiesis:14,laserSails:13,exoplanetology:13,sleeperShips:14,starColonies:14,dysonSwarm:14,casimirEffect:15,ramjets:15,domeWorlds:15,xenoarchaeology:15,interstellarTrade:16,warpTheory:16,warpDrive:17,wormholeGates:17,contactProtocols:16,xenolinguistics:16,xenodiplomacy:17,upliftEthics:17,navalWarfare:17,planetaryDefence:18,guidedOrdnance:18,capitalShips:18,swarmTactics:19,carrierWarfare:19,antimatterProduction:18,relayNetwork:18,matrioshkaBrains:19,intergalacticDrive:19,ringworlds:20,transcendence:20};for(const i in hh)rt[i]&&(rt[i].hq=hh[i]);const dh=(i,e,t,n)=>i*Math.pow(e,Math.min(n,8)-1)*Math.pow(t,Math.max(0,n-8)),tc=i=>{if(i.cost)return i.cost;const e=i.tier,t=i.hq||Math.max(1,e);return{science:Yo(Math.round(dh(60,3.6,2,e)/10)*10,t,"science"),credits:Yo(Math.round(dh(200,3.2,1.9,e)/10)*10,t,"credits")}},ap=i=>i.time||Math.round(qd(3+3.6*(i.tier-1))),Ma=[{id:"ch1",name:"Chapter 1 · Humble Beginnings",intro:"A patch of coastal scrubland, a borrowed budget and a dream. Build the programme that will carry humanity to the stars.",steps:[{id:"o1",text:"Upgrade Mission Control to level 2",kind:"hq",lvl:2,reward:{credits:500,metal:900}},{id:"o2",text:"Build a Research Center",kind:"build",b:"research",lvl:1,reward:{credits:600,metal:500,dm:5}},{id:"o3",text:"Research Rocketry Fundamentals",kind:"tech",id2:"rocketry",reward:{science:120,credits:600,metal:600}},{id:"o7",text:"Build the Launch Complex",kind:"build",b:"launch",lvl:1,reward:{fuel:600,dm:10}},{id:"p1",text:"Assemble your first rocket (Launch Control → Rockets)",kind:"rockets",n:1,reward:{credits:2e3,fuel:800}},{id:"p2",text:"Fly a suborbital test flight",kind:"flag",flag:"suborbital",reward:{science:600,dm:10}},{id:"rb1",text:"Research Industrial Automation",kind:"tech",id2:"automation",reward:{credits:800,metal:800}},{id:"rb2",text:"Build the Robotics Workshop",kind:"build",b:"workshop",lvl:1,reward:{credits:1e3,metal:1200,dm:5}},{id:"rb3",text:"Build a Robot Dock to house your robots",kind:"build",b:"dock",lvl:1,reward:{metal:1e3}},{id:"rb4",text:"Activate your first two robots (Robots → Workshop)",kind:"robots",n:2,reward:{credits:1500,dm:10}},{id:"rb5",text:"Put a robot to work in a building that suits it",kind:"operators",n:1,reward:{metal:1500,credits:1500}},{id:"o4",text:"Build a Fuel Refinery",kind:"build",b:"refinery",lvl:1,reward:{fuel:400,metal:800}},{id:"o5",text:"Upgrade the Metal Mine to level 3",kind:"build",b:"mine",lvl:3,reward:{credits:800,dm:5}},{id:"o6",text:"Keep the grid powered: +10 spare energy",kind:"energy",n:10,reward:{metal:600,credits:600}},{id:"o8",text:"Research Multistage Rockets",kind:"tech",id2:"multistage",reward:{science:300,credits:1200}},{id:"o8b",text:"Upgrade Mission Control to level 3",kind:"hq",lvl:3,reward:{credits:1500,metal:1500}},{id:"o9",text:"Build the Vehicle Assembly building",kind:"build",b:"vab",lvl:1,reward:{metal:2e3,dm:10}},{id:"o10",text:"Upgrade Mission Control to level 4",kind:"hq",lvl:4,reward:{credits:3e3,metal:2e3,dm:10}},{id:"o11",text:"Research Orbital Mechanics",kind:"tech",id2:"orbital",reward:{science:800,dm:15}}]},{id:"ch2",name:"Chapter 2 · Reaching Orbit",intro:"The world is watching. Rockets that fall are lessons; rockets that rise are history.",steps:[{id:"p3",text:"Research Communication Satellites",kind:"tech",id2:"satComms",reward:{credits:4e3,dm:10}},{id:"p4",text:"Put the first satellite in orbit",kind:"flag",flag:"firstOrbit",reward:{metal:6e3,dm:15}},{id:"p5",text:"Operate a Comms Satellite",kind:"sat",sat:"comms",reward:{credits:8e3,dm:10}},{id:"p6",text:"Build the Tracking Station",kind:"build",b:"tracking",lvl:1,reward:{science:2e3}},{id:"p7",text:"Build the Astronaut Academy",kind:"build",b:"academy",lvl:1,reward:{credits:1e4,dm:10}},{id:"p8",text:"Send a crew into orbit",kind:"flag",flag:"crewOrbit",reward:{dm:30,credits:2e4}}]},{id:"ch3",name:"Chapter 3 · Destination Moon",intro:"Three days away, a quarter of a million miles. The Moon has waited four billion years for visitors.",steps:[{id:"q1",text:"Launch the station Core Module",kind:"module",mod:"core",lvl:1,reward:{science:1e4,dm:15}},{id:"q2",text:"Dock a Laboratory module",kind:"module",mod:"lab",lvl:1,reward:{credits:3e4}},{id:"q3",text:"Launch the Lunar Survey Probe",kind:"flag",flag:"lunarProbe",reward:{science:15e3,dm:15}},{id:"q4",text:"Land astronauts on the Moon",kind:"flag",flag:"lunarLanding",reward:{dm:50,credits:8e4}},{id:"q5",text:"Establish the Lunar Outpost",kind:"flag",flag:"moonBase",reward:{dm:50,metal:1e5}},{id:"q6",text:"Build a He-3 Extractor on the Moon",kind:"build",b:"he3x",lvl:1,reward:{he3:400,dm:20}},{id:"q7",text:"Upgrade the Colony Hub to level 3",kind:"hubLvl",lvl:3,reward:{dm:40,credits:3e5}}]},{id:"ch4",name:"Chapter 4 · The Red Planet",intro:"Six months away by chemical rocket, weeks by nuclear. Mars is waiting, cold and red and almost habitable.",steps:[{id:"r1",text:"Research Planetary Probes",kind:"tech",id2:"planetaryProbes",reward:{science:15e4,dm:20}},{id:"r2",text:"Survey Mars with a probe (open the Star Map)",kind:"survey",body:"mars",reward:{credits:4e5,dm:15}},{id:"r3",text:"Research Nuclear Thermal Propulsion",kind:"tech",id2:"nuclearThermal",reward:{fuel:3e5,dm:15}},{id:"r4",text:"Research Orbital Shipyards",kind:"tech",id2:"orbitalShipyard",reward:{metal:4e5,dm:15}},{id:"r5",text:"Launch the Orbital Shipyard station module",kind:"module",mod:"yard",lvl:1,reward:{credits:6e5,dm:20}},{id:"r6",text:"Build a Hermes transfer ship (Launch Control → Fleet)",kind:"ship",ship:"hermes",reward:{fuel:5e5,dm:20}},{id:"r7",text:"Research Mars Direct",kind:"tech",id2:"marsDirect",reward:{science:4e5,dm:20}},{id:"r8",text:"Found Bradbury Landing on Mars",kind:"colony",body:"mars",reward:{dm:80,metal:15e5}},{id:"r9",text:"Build a Greenhouse on Mars",kind:"buildOn",base:"mars",b:"greenhouse",reward:{credits:1e6,dm:20}},{id:"r10",text:"Reach 60 colonists on Mars",kind:"pop",body:"mars",n:60,reward:{dm:40,science:8e5}}]},{id:"ch5",name:"Chapter 5 · The Belt",intro:"Between Mars and Jupiter drift a million worlds of metal and ice. Whoever learns to mine them owns the future.",steps:[{id:"s1",text:"Build the Phobos Depot above Mars",kind:"site",body:"phobos",reward:{fuel:1e6,dm:20}},{id:"s2",text:"Research Asteroid Mining",kind:"tech",id2:"asteroidMining",reward:{credits:15e5,dm:20}},{id:"s3",text:"Open a mining claim on the metal asteroid Psyche",kind:"site",body:"psyche",reward:{rare:1500,dm:30}},{id:"s4",text:"Float the Cytherea Aerostat over Venus",kind:"site",body:"venus",reward:{science:15e5,dm:30}},{id:"s5",text:"Build an Ares colony transport",kind:"ship",ship:"ares",reward:{credits:2e6,dm:25}},{id:"s6",text:"Found Occator Station on Ceres",kind:"colony",body:"ceres",reward:{dm:80,rare:3e3}},{id:"s7",text:"Complete the first terraforming stage on Mars",kind:"terra",body:"mars",n:1,reward:{dm:50,credits:4e6}},{id:"s8",text:"Run five outposts or claims across the Solar System",kind:"sites",n:5,reward:{dm:40,metal:5e6}},{id:"s9",text:"Upgrade the Mars Colony Hub to level 4",kind:"hubLvl",base:"mars",lvl:4,reward:{dm:60,credits:6e6}}]},{id:"ch6",name:"Chapter 6 · Giants and Ice",intro:"Fusion fire opens the outer system: gas giants full of helium-3, moons hiding oceans, and something at the very edge.",steps:[{id:"u1",text:"Research the Fusion Drive",kind:"tech",id2:"fusionDrive",reward:{he3:2e3,dm:30}},{id:"u2",text:"Build a Daedalus torch ship",kind:"ship",ship:"daedalus",reward:{credits:8e6,dm:30}},{id:"u3",text:"Build the Jovian He-3 Scoop",kind:"site",body:"jupiter",reward:{he3:4e3,dm:40}},{id:"u4",text:"Send the Europa Deep Probe under the ice",kind:"site",body:"europa",reward:{science:6e6,dm:60}},{id:"u5",text:"Found Kraken Shore on Titan",kind:"colony",body:"titan",reward:{dm:80,fuel:6e6}},{id:"u6",text:"Bombard Mars with comets (terraforming stage 3)",kind:"terra",body:"mars",n:3,reward:{dm:80,credits:15e6}},{id:"u7",text:"Build an Odyssey cruiser",kind:"ship",ship:"odyssey",reward:{dm:60,rare:1e4}},{id:"u8",text:"Raise Tombaugh Station on Pluto",kind:"site",body:"pluto",reward:{dm:100,science:2e7}}]},{id:"ch7",name:"Chapter 7 · First Light",intro:"The nearest star is 4.2 light-years away: 40 trillion kilometres. Light itself takes four years. We are going anyway.",steps:[{id:"v1",text:"Research Laser Light Sails",kind:"tech",id2:"laserSails",reward:{science:2e7,dm:40}},{id:"v2",text:"Build the Starshot Laser Array (tap the Sun on the Star Map)",kind:"mega",mega:"laser",n:1,reward:{rare:2e4,dm:40}},{id:"v3",text:"Survey Proxima Centauri with a light sail",kind:"starSurvey",star:"proxima",reward:{credits:6e7,dm:40}},{id:"v8",text:"Survey Epsilon Eridani, the source of the signal",kind:"starSurvey",star:"epseri",reward:{dm:100,science:6e7}},{id:"u9",text:"Give Mars liquid oceans (terraforming stage 5)",kind:"terra",body:"mars",n:5,reward:{dm:200,credits:5e7}},{id:"v4",text:"Research Star Colonies",kind:"tech",id2:"starColonies",reward:{science:3e7,dm:40}},{id:"v5",text:"Build an Exodus Ark",kind:"drive",ship:"ark",reward:{he3:2e4,dm:50}},{id:"v6",text:"Found humanity's first star colony",kind:"starCol",n:1,reward:{dm:150,credits:1e8}},{id:"v7",text:"Begin the Dyson Swarm",kind:"mega",mega:"dyson",n:1,reward:{dm:60,metal:1e8}}]},{id:"ch8",name:"Chapter 8 · Between the Stars",intro:"A lighthouse at Epsilon Eridani, older than our species. Whoever built it wanted to be found. Spread out, grow strong, and be ready.",steps:[{id:"w6",text:"Survey ten star systems",kind:"starSurvey",n:10,reward:{dm:100,credits:4e8}},{id:"w1",text:"Run three star colonies",kind:"starCol",n:3,reward:{dm:80,credits:2e8}},{id:"w2",text:"Develop a star colony to level 5",kind:"starLvl",lvl:5,reward:{dm:80,rare:6e4}},{id:"w3",text:"Build the Casimir Foundry on Earth",kind:"build",b:"casimir",lvl:1,reward:{exotic:200,dm:60}},{id:"w4",text:"Build a Pathfinder ramjet",kind:"drive",ship:"ramjet",reward:{dm:80,he3:4e4}},{id:"w5",text:"Raise the Dyson Swarm to stage 4",kind:"mega",mega:"dyson",n:4,reward:{dm:100,science:15e7}}]},{id:"ch9",name:"Chapter 9 · Contact",intro:"For all of history we wondered if we were alone. The answer is arriving, and it is complicated.",steps:[{id:"x1",text:"Research First Contact Protocols",kind:"tech",id2:"contactProtocols",reward:{science:8e7,dm:60}},{id:"x2",text:"Make first contact with an alien civilisation",kind:"met",n:1,reward:{xeno:2e3,dm:100}},{id:"x3",text:"Research Xenolinguistics",kind:"tech",id2:"xenolinguistics",reward:{xeno:2e3,dm:60}},{id:"x4",text:"Build the Xenology Institute on Earth",kind:"build",b:"xenolab",lvl:1,reward:{influence:1500,dm:60}},{id:"x5",text:"Decipher an alien language to 50%",kind:"und",n:50,reward:{xeno:4e3,dm:80}},{id:"x6",text:"Fulfil a request from another civilisation",kind:"requests",n:1,reward:{influence:2e3,dm:80}},{id:"x7",text:"Learn a piece of alien knowledge",kind:"xenotech",n:1,reward:{dm:120,credits:1e9}}]},{id:"ch10",name:"Chapter 10 · The Wider Galaxy",intro:"Gardeners from another galaxy, merchants of light, a machine Synod, a fungal mind, a young ocean people, and a Swarm that eats worlds. Choose your friends well.",steps:[{id:"y1",text:"Meet four civilisations",kind:"met",n:4,reward:{xeno:8e3,dm:100}},{id:"y2",text:"Research Xenodiplomacy and open an embassy",kind:"embassy",reward:{influence:4e3,dm:100}},{id:"y3",text:"Sign a trade agreement",kind:"deal",deal:"trade",reward:{dm:100,exotic:1e3}},{id:"y4",text:"Excavate the Hollow ruins to level 3",kind:"ruins",n:3,reward:{xeno:15e3,dm:120}},{id:"y5",text:"Decide the fate of a young species: protect or uplift it",kind:"minorChoice",reward:{dm:120,influence:6e3}},{id:"y7",text:"Answer the Kr'thul: pay tribute or refuse (Contact screen)",kind:"flag",flag:"krthulAnswered",reward:{dm:150,metal:2e9}},{id:"w7",text:"Open the Sol Wormhole Gate",kind:"mega",mega:"gate",n:1,reward:{dm:200,exotic:1e3}},{id:"w8",text:"Gate a star colony into the network",kind:"gates",n:1,reward:{dm:200,credits:8e8}},{id:"y6",text:"Sign a research pact",kind:"deal",deal:"pact",reward:{dm:150,science:3e8}},{id:"y8",text:"Form an alliance",kind:"deal",deal:"alliance",reward:{dm:300,credits:3e9}}]},{id:"ch11",name:"Chapter 11 · The Swarm",intro:"Humanity built ships to explore. Now it must build ships to survive. The Kr'thul do not negotiate twice.",steps:[{id:"z1",text:"Research Naval Warfare",kind:"tech",id2:"navalWarfare",reward:{metal:2e9,dm:100}},{id:"z2",text:"Build a fleet of 20 warships (Fleet screen)",kind:"warships",n:20,reward:{credits:2e9,dm:100}},{id:"z3",text:"Research Planetary Defence",kind:"tech",id2:"planetaryDefence",reward:{science:4e8,dm:100}},{id:"z4",text:"Fortify a colony to defence level 2",kind:"defence",lvl:2,reward:{dm:120,metal:3e9}},{id:"z5",text:"Destroy the Kr'thul hive at Ross 154",kind:"hive",hive:"ross154",reward:{dm:200,xeno:2e4}},{id:"z6",text:"Research Capital Ships",kind:"tech",id2:"capitalShips",reward:{dm:150,rare:2e5}}]},{id:"ch12",name:"Chapter 12 · The Brood Queen",intro:"Three hives stand between us and Kapteyn's Star. Beyond them waits the mind of the Swarm.",steps:[{id:"za1",text:"Destroy the hive at Luyten 726-8",kind:"hive",hive:"uvceti",reward:{dm:250,credits:8e9}},{id:"za2",text:"Build a fleet of 150 warships",kind:"warships",n:150,reward:{dm:200,metal:8e9}},{id:"za3",text:"Destroy the hive at Lacaille 9352",kind:"hive",hive:"lacaille",reward:{dm:300,exotic:5e3}},{id:"za4",text:"Research Carrier Warfare",kind:"tech",id2:"carrierWarfare",reward:{dm:200,science:1e9}},{id:"za5",text:"Kill the Brood Queen at Kapteyn's Star",kind:"hive",hive:"kapteyn",reward:{dm:1e3,credits:3e10}}]},{id:"ch13",name:"Chapter 13 · The Dark Between Galaxies",intro:"The Milky Way is ours to explore for a million years. The Hollow relays point further.",steps:[{id:"b1",text:"Research Antimatter Production",kind:"tech",id2:"antimatterProduction",reward:{exotic:2e4,dm:200}},{id:"b2",text:"Build an Antimatter Factory",kind:"build",b:"antimatter",lvl:1,reward:{antimatter:500,dm:150}},{id:"b3",text:"Research the Relay Network",kind:"tech",id2:"relayNetwork",reward:{xeno:5e4,dm:150}},{id:"b4",text:"Wake the first relay (Beyond screen)",kind:"relay",n:1,reward:{dm:200,credits:2e10}},{id:"b5",text:"Research the Intergalactic Drive",kind:"tech",id2:"intergalacticDrive",reward:{dm:200,antimatter:1e3}},{id:"b6",text:"Send an expedition to the Sagittarius Dwarf galaxy",kind:"galaxy",gal:"sagdeg",reward:{dm:300,exotic:5e4}},{id:"b7",text:"Visit the Veyari home in the Large Magellanic Cloud",kind:"galaxy",gal:"lmc",reward:{dm:400,science:5e9}}]},{id:"ch14",name:"Chapter 14 · The Ascendants",intro:"Every civilisation in Andromeda is listening to the same voice. It is time to answer it.",steps:[{id:"c1",text:"Build the first shell of a Matrioshka Brain",kind:"mega",mega:"matrioshka",n:1,reward:{dm:300,science:1e10}},{id:"c2",text:"Reach the Small Magellanic Cloud",kind:"galaxy",gal:"smc",reward:{dm:400,xeno:2e5}},{id:"c3",text:"Cross to Andromeda",kind:"galaxy",gal:"andromeda",reward:{dm:600,credits:1e11}},{id:"c4",text:"Raise a Ringworld",kind:"mega",mega:"ringworld",n:1,reward:{dm:500,metal:2e11}},{id:"c5",text:"Survey the Triangulum galaxy",kind:"galaxy",gal:"triangulum",reward:{dm:600,rare:1e8}},{id:"c6",text:"Find the Far Shore",kind:"galaxy",gal:"farshore",reward:{dm:2e3}}]}],op=()=>Ma.flatMap(i=>i.steps.map(e=>({...e,ch:i.id}))),dt={credits:{name:"Credits",short:"CR",color:"#ffd166",cap:!0,start:!0,icon:"¢",desc:"Funding from governments, sponsors and commerce. Spent on nearly everything."},metal:{name:"Metal",short:"MT",color:"#b8c4d6",cap:!0,start:!0,icon:"▣",desc:"Steel, aluminium and titanium for structures, rockets and ships."},fuel:{name:"Fuel",short:"FU",color:"#ff8a5b",cap:!0,start:!0,icon:"▲",desc:"Rocket propellant: kerosene, liquid hydrogen and oxygen, later methane and more."},science:{name:"Science",short:"SC",color:"#6ee7ff",cap:!0,start:!0,icon:"✦",desc:"Research data. Spent to unlock technologies."},cells:{name:"Power Cells",short:"PC",color:"#7cf29a",cap:!0,icon:"⚡",desc:"Charged cells that level robots up and power new robot cores."},he3:{name:"Helium-3",short:"He3",color:"#b892ff",cap:!0,icon:"◉",desc:"A rare isotope found in lunar regolith and gas giants. Fusion fuel."},rare:{name:"Rare Elements",short:"RE",color:"#7cf29a",cap:!0,icon:"◆",desc:"Platinum-group metals and rare earths from asteroids."},exotic:{name:"Exotic Matter",short:"EX",color:"#ff5cf0",cap:!0,icon:"✺",desc:"Negative-energy matter. It holds warp bubbles and wormholes open."},antimatter:{name:"Antimatter",short:"AM",color:"#ff4d6d",cap:!0,icon:"⊛",desc:"The densest energy source known. Handle with care."},influence:{name:"Influence",short:"IN",color:"#ffb3c7",cap:!0,icon:"❖",desc:"Diplomatic standing among the civilisations of the galaxy."},xeno:{name:"Xenodata",short:"XD",color:"#9dff5c",cap:!0,icon:"⌬",desc:"Knowledge gathered from alien life, ruins and artifacts."},dm:{name:"Dark Matter",short:"DM",color:"#c9b6ff",cap:!1,start:!0,icon:"◈",desc:"A precious, mysterious resource. It completes any timer instantly. Earned, never bought."}},lp=["credits","metal","fuel"],Xd=[],Yd=[],Kd=[],kr={mult:()=>1,solar:()=>1,house:()=>0,grow:()=>0};function mi(i){const e={mult:{},gen:0,buildTime:0,researchTime:0,cap:0,crews:0,slots:0,costs:0,flags:new Set};for(const t in i.tech){const n=rt[t];if(!n)continue;const s=n.effect||{};for(const r in s.mult||{})e.mult[r]=(e.mult[r]||0)+s.mult[r];for(const r of["gen","buildTime","researchTime","cap","crews","slots","costs"])s[r]&&(e[r]+=s[r]);s.flag&&e.flags.add(s.flag)}for(const t in i.flags)i.flags[t]&&e.flags.add(t);for(const t of Xd)t(i,e);return e}const Gi=(i,e)=>i?Pn(i[0],i[1],e):0;function Jo(i,e,t){const n=at[i],s={prod:{},cap:{},gen:0,draw:0,speed:0,house:0,jobs:0,grow:0};if(!n||e<=0)return s;s.house=Gi(n.house,e),s.jobs=Math.round(Gi(n.jobs,e)),s.grow=Gi(n.grow,e);for(const r in n.prod||{})s.prod[r]=Gi(n.prod[r],e)*(1+(t.mult[r]||0));for(const r in n.cap||{})s.cap[r]=Gi(n.cap[r],e)*(1+t.cap);return s.gen=Gi(n.gen,e)*(1+t.gen),s.draw=Gi(n.draw,e),s.speed=n.speed?n.speed*e:0,s}const Sn=(i,e,t)=>{const n=i.bases[e];if(!n)return 0;let s=0;for(const r of n.items)r.b===t&&(s=Math.max(s,r.lvl));return s},Fn=(i,e="earth")=>Sn(i,e,e==="earth"?"hq":"hub"),Jd=i=>{const e=at[i];return!e||!e.collect?null:Object.keys(e.prod||{}).find(t=>lp.includes(t))||null};function Ri(i,e=mi(i)){const t={prod:{},cap:{},gen:0,draw:0,eff:1,speed:0,m:e,col:{},item:{},collect:{}};for(const a in dt)t.prod[a]=0,t.cap[a]=dt[a].cap?0:1/0;const n=[],s={};for(const a of Kd){const o=a(i);for(const c in o)s[c]=(s[c]||0)+o[c]}for(const a in i.bases){const o=i.bases[a],c=a!=="earth",l=[];let h=0,d=0,u=0;for(const v of o.items){if(v.lvl<=0)continue;const p=Jo(v.b,v.lvl,e),m=1+(s[v.id]||0);if(m>1){for(const x in p.prod)p.prod[x]*=m;for(const x in p.cap)p.cap[x]*=m;p.gen*=m,p.speed*=m}l.push([v,p]),h+=p.house,d+=p.jobs,u+=p.grow}let f=1;if(c){h*=1+kr.house(),u+=kr.grow();const v=o.pop||0;f=d>0?Math.min(1,v/d):1,t.col[a]={house:Math.round(h),jobs:d,grow:u,staff:f,pop:v}}const g=.3+.7*f;for(const[v,p]of l){const m=v.b==="hub"?1:g;n.push([v,a,p,m]);for(const x in p.cap)t.cap[x]+=p.cap[x];t.gen+=v.b==="lsolar"?p.gen*kr.solar():p.gen,t.draw+=p.draw,t.speed+=p.speed*m}}for(const a of Yd)a(i,t);t.eff=t.draw<=0?1:Math.min(1,t.gen/t.draw);const r=.25+.75*t.eff;for(const a in t.prod)t.prod[a]*=r;for(const[a,o,c,l]of n){const h=Jd(a.b);for(const d in c.prod){const u=c.prod[d]*l*kr.mult()*r;d===h?(t.item[a.id]={r:d,rate:u,hold:u*Hd(a.lvl)},t.collect[d]=(t.collect[d]||0)+u):t.prod[d]+=u}}return t}function cp(i,e,t){if(!(t<=0)){for(const n in e.col){const s=e.col[n],r=i.bases[n];if(!r)continue;const a=r.pop||0;a<s.house&&(r.pop=Math.min(s.house,a+s.grow*t/3600))}for(const n in e.prod){const s=e.prod[n]*t/3600;if(!s)continue;const r=i.res[n]||0,a=e.cap[n];if(s>0&&r>=a)continue;const o=Math.max(a,r);i.res[n]=Math.max(0,Math.min(o,r+s))}for(const n in i.bases)for(const s of i.bases[n].items){const r=e.item[s.id];r&&(s.held=Math.min(r.hold,(s.held||0)+r.rate*t/3600))}}}const es=(i,e)=>Object.entries(e).every(([t,n])=>(i.res[t]||0)>=n),Ii=(i,e)=>{for(const[t,n]of Object.entries(e))i.res[t]=(i.res[t]||0)-n},ws=(i,e)=>{for(const[t,n]of Object.entries(e))i.res[t]=(i.res[t]||0)+n},hp=[];function dp(i,e){let t=18e12*Math.pow(1+e.gen/25,.8);for(const n of hp)t+=n(i,e);return t}const Sa=(i,e)=>(Math.log10(dp(i,e))-6)/10,wa=[.75,.8,.85,.9,.95,1,1.1,1.2,1.3,1.4,1.5,1.6,1.7,1.8,1.9,2,2.2,2.4,2.6,2.8,3],up=i=>i>=3?"Type III: a galactic civilisation":i>=2?"Type II: master of a star":i>=1?"Type I: master of a planet":"Type 0: a planet-bound species",Fs={},Ni={},nc=[],ic=[],Ps=(i,e,t)=>{const n=at[i],s={},r=jf(i,e);for(const a in n.cost)s[a]=Yo(ai(Pn(n.cost[a][0],n.cost[a][1],e)*(1-t.costs)),r,a);return s},fr=(i,e,t)=>Math.max(2,Math.round(sp(at[i].time,e)*(1-t.buildTime))),sc=(i,e)=>Math.max(5,Math.round(ap(rt[i])*(1-e.m.researchTime)/(1+e.speed))),pr=(i,e=mi(i))=>tp(Fn(i))+e.crews,Es=i=>i.jobs.filter(e=>e.kind==="build").length,rc=(i,e=mi(i))=>1+e.slots,ac=i=>i.jobs.filter(e=>e.kind==="research").length,Ci=(i,e)=>i.jobs.find(t=>t.kind==="build"&&t.item===e),Ct=(i,e,t)=>i.bases[e]?.items.find(n=>n.id===t),oc=(i,e,t)=>i.bases[e].items.filter(n=>n.b===t).length,on=(i,e=0)=>{const[t,n]=at[i].fp;return e%2?[n,t]:[t,n]};function Rr(i,e){const t=np(e,Fn(i,e)||1),n=Math.floor((ji-t)/2);return{lo:n,hi:n+t,side:t}}function Cr(i,e,t,n,s,r,a){const[o,c]=on(t,r),l=Rr(i,e);if(n<l.lo||s<l.lo||n+o>l.hi||s+c>l.hi)return{ok:!1,why:"Outside the base (raise the command level to expand it)"};for(const h of i.bases[e].items){if(h.id===a)continue;const[d,u]=on(h.b,h.r);if(n<h.x+d&&n+o>h.x&&s<h.z+u&&s+c>h.z)return{ok:!1,why:"Something is in the way"}}return{ok:!0}}function Zd(i,e,t,n=0){const s=Rr(i,e),[r,a]=on(t,n),o=ji/2;let c=null,l=1e9;for(let h=s.lo;h+a<=s.hi;h++)for(let d=s.lo;d+r<=s.hi;d++){const u=Math.hypot(d+r/2-o,h+a/2-o);u<l&&Cr(i,e,t,d,h,n).ok&&(l=u,c=[d,h])}return c}function Ia(i,e,t){const n=at[t],s=mi(i),r=Fn(i,e);if(!n||!i.bases[e])return{ok:!1,why:"Unknown"};if(!n.bases.includes(e))return{ok:!1,why:"Cannot be built on this world"};if(n.req&&n.req.tech&&!i.tech[n.req.tech])return{ok:!1,why:`Research ${rt[n.req.tech].name}`,tech:n.req.tech};if(n.req&&n.req.hq&&r<n.req.hq)return{ok:!1,why:`Mission Control level ${n.req.hq}`,hq:!0};const a=Wd(n,r);if(oc(i,e,t)>=a)return{ok:!1,why:a?"Limit reached for this command level":`Command level ${(n.count||[]).findIndex(c=>c>0)+1}`,hq:!0};if(Es(i)>=pr(i,s))return{ok:!1,why:"All construction drones are busy",crews:!0};const o=Ps(t,1,s);return es(i,o)?{ok:!0,cost:o,time:fr(t,1,s)}:{ok:!1,why:"Not enough resources",cost:o}}function Qd(i,e,t,n,s,r,a=Date.now()){const o=Ia(i,e,t);if(!o.ok)return o;const c=Cr(i,e,t,n,s,r);if(!c.ok)return c;Ii(i,o.cost);const l={id:Yn(i,"i"),b:t,x:n,z:s,r,lvl:0,held:0};return i.bases[e].items.push(l),i.jobs.push({id:Yn(i),kind:"build",base:e,item:l.id,b:t,from:0,to:1,start:a,end:a+o.time*1e3}),{...o,item:l}}const jd=(i,e,t,n)=>ep(t,n,e).filter(([s,r])=>!i.bases[e].items.some(a=>a.b===s&&a.lvl>=r)),lc=(i,e,t)=>{const n=at[t];return n.command&&e!=="earth"?Math.max(1,Math.min(n.max,Fn(i,"earth")-7)):Vd(n,Fn(i,e))};function Na(i,e,t){const n=Ct(i,e,t);if(!n)return{ok:!1,why:"Gone"};const s=at[n.b],r=mi(i),a=Fn(i,e);if(Ci(i,t))return{ok:!1,why:"Under construction"};if(n.lvl>=s.max)return{ok:!1,why:"Maximum level",max:!0};if(s.command&&e!=="earth"&&n.lvl>=lc(i,e,n.b))return{ok:!1,why:`Mission Control level ${n.lvl+8} on Earth`,hq:!0};const o=jd(i,e,n.b,n.lvl+1);if(o.length)return{ok:!1,why:`First upgrade ${o.map(([l,h])=>at[l].name+" to level "+h).join(", ")}`,reqs:o,hq:!0};if(n.lvl>=Vd(s,a))return{ok:!1,why:`Upgrade ${e==="earth"?"Mission Control":"the Colony Hub"} first`,hq:!0};if(Es(i)>=pr(i,r))return{ok:!1,why:"All construction drones are busy",crews:!0};const c=Ps(n.b,n.lvl+1,r);return es(i,c)?{ok:!0,cost:c,time:fr(n.b,n.lvl+1,r)}:{ok:!1,why:"Not enough resources",cost:c}}function eu(i,e,t,n=Date.now()){const s=Na(i,e,t);if(!s.ok)return s;Ii(i,s.cost);const r=Ct(i,e,t);return i.jobs.push({id:Yn(i),kind:"build",base:e,item:t,b:r.b,from:r.lvl,to:r.lvl+1,start:n,end:n+s.time*1e3}),i.stats.upgradesStarted=(i.stats.upgradesStarted||0)+1,s}function tu(i,e,t,n,s,r){const a=Ct(i,e,t);if(!a)return{ok:!1};const o=Cr(i,e,a.b,n,s,r,t);return o.ok?(a.x=n,a.z=s,a.r=r,{ok:!0}):o}const cc=(i,e,t)=>{const n=Ct(i,e,t);return!!n&&!at[n.b].command&&n.b!=="launch"&&!Ci(i,t)};function nu(i,e,t){return cc(i,e,t)?(i.bases[e].items=i.bases[e].items.filter(n=>n.id!==t),!0):!1}function iu(i,e,t,n=Ri(i)){const s=Ct(i,e,t);if(!s)return null;const r=Jd(s.b);if(!r)return null;const a=Math.floor(s.held||0);if(a<1)return null;const o=Math.max(0,Math.floor(n.cap[r]-(i.res[r]||0))),c=Math.min(a,o);return c<=0?{r,n:0,full:!0}:(s.held=(s.held||0)-c,i.res[r]=(i.res[r]||0)+c,i.stats.collected+=c,i.stats.collects=(i.stats.collects||0)+1,{r,n:c,full:c<a})}const fp=(i,e)=>Object.values(i.bases).some(t=>t.items.some(n=>n.b===e&&n.lvl>0));function Ua(i,e){const t=rt[e];if(!t)return{ok:!1,why:"Unknown"};if(i.tech[e])return{ok:!1,why:"Researched",done:!0};if(i.jobs.some(a=>a.kind==="research"&&a.tech===e))return{ok:!1,why:"In progress",busy:!0};const n=t.req.filter(a=>!i.tech[a]);if(n.length)return{ok:!1,why:"Requires "+n.map(a=>rt[a].name).join(", "),locked:!0};if(t.hq&&Fn(i)<t.hq)return{ok:!1,why:`Mission Control ${t.hq}`,locked:!0,hq:!0};if(!fp(i,"research"))return{ok:!1,why:"Build a Research Center",locked:!0};const s=mi(i);if(ac(i)>=rc(i,s))return{ok:!1,why:"Research slot busy",slots:!0};const r=tc(t);return es(i,r)?{ok:!0,cost:r,time:sc(e,Ri(i,s))}:{ok:!1,why:"Not enough resources",cost:r}}function su(i,e,t=Date.now()){const n=Ua(i,e);return n.ok&&(Ii(i,n.cost),i.jobs.push({id:Yn(i),kind:"research",tech:e,start:t,end:t+n.time*1e3})),n}function pp(i,e){if(i.jobs=i.jobs.filter(n=>n!==e),e.kind==="build"){const n=Ct(i,e.base,e.item);if(!n)return null;if(n.lvl=e.to,e.from===0){i.stats.built++;for(const s of ic)s(i,e.b)}else i.stats.upgrades++;return{kind:"build",b:e.b,lvl:e.to,base:e.base,item:e.item,first:e.from===0}}if(e.kind==="research")return i.tech[e.tech]=1,i.stats.researched++,{kind:"research",tech:e.tech};const t=Fs[e.kind];return t?t(i,e):null}function Zo(i,e=Date.now()){const t=[];let n=0;for(;n++<1e4;){const s=i.jobs.reduce((h,d)=>d.end<=e&&(!h||d.end<h.end)?d:h,null),r=Ri(i);let a=s?Math.max(i.last,s.end):e;const c=Object.values(r.col).some(h=>h.pop<h.house&&h.grow>0)&&a-i.last>36e5;if(c&&(a=i.last+36e5),cp(i,r,(a-i.last)/1e3),i.last=a,c)continue;if(!s)break;const l=pp(i,s);l&&(l.t=s.end,t.push(l))}return i.last=e,t}const ir=i=>i<=60?0:Math.ceil(1.2*Math.pow(i/60,.72));function ru(i,e,t=Date.now()){const n=i.jobs.find(r=>r.id===e);if(!n)return{ok:!1,why:"Gone"};const s=ir((n.end-t)/1e3);return(i.res.dm||0)<s?{ok:!1,why:"Not enough dark matter",need:s}:(i.res.dm-=s,i.stats.dmSpent+=s,n.end=t,{ok:!0,spent:s})}function mp(i,e,t,n=Date.now()){const s=i.jobs.find(r=>r.id===e);return s?(s.end=Math.max(n,s.end-t*1e3),!0):!1}function au(i,e){const t=i.jobs.find(s=>s.id===e);if(!t)return!1;const n=mi(i);if(t.kind==="build"){const s=Ps(t.b,t.to,n);ws(i,Object.fromEntries(Object.entries(s).map(([r,a])=>[r,Math.floor(a*.5)]))),t.from===0&&(i.bases[t.base].items=i.bases[t.base].items.filter(r=>r.id!==t.item))}else if(t.kind==="research"){const s=tc(rt[t.tech]);ws(i,Object.fromEntries(Object.entries(s).map(([r,a])=>[r,Math.floor(a*.5)])))}else return!1;return i.jobs=i.jobs.filter(s=>s!==t),!0}const ou=op(),sr=i=>ou[i.obj.i]||null,lu=i=>i.obj.i,cu=()=>ou.length;function hc(i,e,t=Ri(i)){if(!e)return!1;switch(e.kind){case"hq":return Fn(i)>=e.lvl;case"build":return Object.values(i.bases).some(s=>s.items.some(r=>r.b===e.b&&r.lvl>=e.lvl));case"buildOn":return!!i.bases[e.base]&&i.bases[e.base].items.some(s=>s.b===e.b&&s.lvl>=(e.lvl||1));case"tech":return!!i.tech[e.id2];case"rate":return t.prod[e.res]+(t.collect[e.res]||0)>=e.n;case"energy":return t.gen-t.draw>=e.n;case"flag":return!!i.flags[e.flag];case"hubLvl":return!!i.bases[e.base||"moon"]&&Fn(i,e.base||"moon")>=e.lvl;case"colony":return!!i.bases[e.body];case"pop":return!!i.bases[e.body]&&(i.bases[e.body].pop||0)>=e.n}const n=Ni[e.kind];return n?n(i,e,t):!1}function hu(i){const e=sr(i);return!e||!hc(i,e)?null:(ws(i,e.reward),i.obj.claimed[e.id]=Date.now(),i.obj.i++,e)}const gp=Object.freeze(Object.defineProperty({__proto__:null,advance:Zo,area:Rr,builtHooks:ic,canBuild:Ia,canDemolish:cc,canResearch:Ua,canUpgrade:Na,cancel:au,claimStep:hu,collect:iu,completers:Fs,costOf:Ps,countOf:oc,crewsBusy:Es,crewsTotal:pr,currentStep:sr,demolish:nu,dims:on,dmCost:ir,events:nc,fits:Cr,freeSpot:Zd,hqLevel:Fn,itemOf:Ct,jobOf:Ci,levelCap:lc,lvlOf:Sn,mods:mi,moveItem:tu,rates:Ri,reqsMissing:jd,researchTimeOf:sc,skip:mp,slotsBusy:ac,slotsTotal:rc,speedup:ru,startBuild:Qd,startResearch:su,startUpgrade:eu,stepChecks:Ni,stepCount:cu,stepDone:hc,stepIndex:lu,timeOf:fr},Symbol.toStringTag,{value:"Module"}));const dc="187",vp=0,uh=1,xp=2,Ea=1,du=2,js=3,Ki=0,Gt=1,bn=2,As=0,rr=1,Fa=2,fh=3,ph=4,yp=5,Ss=100,bp=101,_p=102,Mp=103,Sp=104,wp=200,Ep=201,Ap=202,Tp=203,uu=204,fu=205,Rp=206,Cp=207,Pp=208,Lp=209,Dp=210,Ip=211,Np=212,Up=213,Fp=214,Qo=0,jo=1,el=2,mr=3,tl=4,nl=5,il=6,sl=7,pu=0,Op=1,kp=2,di=0,mu=1,gu=2,vu=3,uc=4,xu=5,yu=6,bu=7,_u=300,Ls=301,gr=302,fo=303,po=304,Oa=1e3,ci=1001,rl=1002,zt=1003,Bp=1004,Br=1005,nn=1006,mo=1007,hi=1008,ln=1009,Mu=1010,Su=1011,vr=1012,fc=1013,Kn=1014,Dn=1015,Jn=1016,pc=1017,mc=1018,Ds=1020,wu=35902,Eu=35899,Au=1021,Tu=1022,qn=1023,Pi=1026,Ti=1027,gc=1028,vc=1029,Ji=1030,xc=1031,yc=1033,Aa=33776,Ta=33777,Ra=33778,Ca=33779,al=35840,ol=35841,ll=35842,cl=35843,hl=36196,dl=37492,ul=37496,fl=37488,pl=37489,ka=37490,ml=37491,gl=37808,vl=37809,xl=37810,yl=37811,bl=37812,_l=37813,Ml=37814,Sl=37815,wl=37816,El=37817,Al=37818,Tl=37819,Rl=37820,Cl=37821,Pl=36492,Ll=36494,Dl=36495,Il=36283,Nl=36284,Ba=36285,Ul=36286,zp=3200,Fl=0,Gp=1,li="",Ft="srgb",za="srgb-linear",Ga="linear",st="srgb",go=7680,Hp=519,Vp=512,Wp=513,$p=514,Ru=515,qp=516,Xp=517,Cu=518,Pu=519,Lu=35044,mh="300 es",In=2e3,xr=2001;function Yp(i){for(let e=i.length-1;e>=0;--e)if(i[e]>=65535)return!0;return!1}function Ha(i){return document.createElementNS("http://www.w3.org/1999/xhtml",i)}function Kp(){const i=Ha("canvas");return i.style.display="block",i}const gh={};function Va(...i){const e="THREE."+i.shift();console.log(e,...i)}function Du(i){const e=i[0];if(typeof e=="string"&&e.startsWith("TSL:")){const t=i[1];t&&t.isStackTrace?i[0]+=" "+t.getLocation():i[1]='Stack trace not available. Enable "THREE.Node.captureStackTrace" to capture stack traces.'}return i}function Le(...i){i=Du(i);const e="THREE."+i.shift();{const t=i[0];t&&t.isStackTrace?console.warn(t.getError(e)):console.warn(e,...i)}}function Ze(...i){i=Du(i);const e="THREE."+i.shift();{const t=i[0];t&&t.isStackTrace?console.error(t.getError(e)):console.error(e,...i)}}function Pa(...i){const e=i.join(" ");e in gh||(gh[e]=!0,Le(...i))}function Jp(i,e,t){return new Promise(function(n,s){function r(){switch(i.clientWaitSync(e,i.SYNC_FLUSH_COMMANDS_BIT,0)){case i.WAIT_FAILED:s();break;case i.TIMEOUT_EXPIRED:setTimeout(r,t);break;default:n()}}setTimeout(r,t)})}const Zp={[Qo]:Qo,[el]:il,[tl]:tl,[mr]:nl,[jo]:jo,[il]:el,[sl]:sl,[nl]:mr};class ts{addEventListener(e,t){this._listeners===void 0&&(this._listeners={});const n=this._listeners;n[e]===void 0&&(n[e]=[]),n[e].indexOf(t)===-1&&n[e].push(t)}hasEventListener(e,t){const n=this._listeners;return n===void 0?!1:n[e]!==void 0&&n[e].indexOf(t)!==-1}removeEventListener(e,t){const n=this._listeners;if(n===void 0)return;const s=n[e];if(s!==void 0){const r=s.indexOf(t);r!==-1&&s.splice(r,1)}}dispatchEvent(e){const t=this._listeners;if(t===void 0)return;const n=t[e.type];if(n!==void 0){e.target=this;const s=n.slice(0);for(let r=0,a=s.length;r<a;r++)s[r].call(this,e);e.target=null}}}const Xt=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"];let vh=1234567;const ar=Math.PI/180,yr=180/Math.PI;function gi(){const i=Math.random()*4294967295|0,e=Math.random()*4294967295|0,t=Math.random()*4294967295|0,n=Math.random()*4294967295|0;return(Xt[i&255]+Xt[i>>8&255]+Xt[i>>16&255]+Xt[i>>24&255]+"-"+Xt[e&255]+Xt[e>>8&255]+"-"+Xt[e>>16&15|64]+Xt[e>>24&255]+"-"+Xt[t&63|128]+Xt[t>>8&255]+"-"+Xt[t>>16&255]+Xt[t>>24&255]+Xt[n&255]+Xt[n>>8&255]+Xt[n>>16&255]+Xt[n>>24&255]).toLowerCase()}function Ge(i,e,t){return Math.max(e,Math.min(t,i))}function bc(i,e){return(i%e+e)%e}function Qp(i,e,t,n,s){return n+(i-e)*(s-n)/(t-e)}function jp(i,e,t){return i!==e?(t-i)/(e-i):0}function or(i,e,t){return(1-t)*i+t*e}function em(i,e,t,n){return or(i,e,1-Math.exp(-t*n))}function tm(i,e=1){return e-Math.abs(bc(i,e*2)-e)}function nm(i,e,t){return i<=e?0:i>=t?1:(i=(i-e)/(t-e),i*i*(3-2*i))}function im(i,e,t){return i<=e?0:i>=t?1:(i=(i-e)/(t-e),i*i*i*(i*(i*6-15)+10))}function sm(i,e){return i+Math.floor(Math.random()*(e-i+1))}function rm(i,e){return i+Math.random()*(e-i)}function am(i){return i*(.5-Math.random())}function om(i){i!==void 0&&(vh=i);let e=vh+=1831565813;return e=Math.imul(e^e>>>15,e|1),e^=e+Math.imul(e^e>>>7,e|61),((e^e>>>14)>>>0)/4294967296}function lm(i){return i*ar}function cm(i){return i*yr}function hm(i){return i>0&&Number.isInteger(i)&&2**Math.round(Math.log2(i))===i}function dm(i){return Math.pow(2,Math.ceil(Math.log(i)/Math.LN2))}function Iu(i){return Math.pow(2,Math.floor(Math.log(i)/Math.LN2))}function um(i,e,t,n,s){const r=Math.cos,a=Math.sin,o=r(t/2),c=a(t/2),l=r((e+n)/2),h=a((e+n)/2),d=r((e-n)/2),u=a((e-n)/2),f=r((n-e)/2),g=a((n-e)/2);switch(s){case"XYX":i.set(o*h,c*d,c*u,o*l);break;case"YZY":i.set(c*u,o*h,c*d,o*l);break;case"ZXZ":i.set(c*d,c*u,o*h,o*l);break;case"XZX":i.set(o*h,c*g,c*f,o*l);break;case"YXY":i.set(c*f,o*h,c*g,o*l);break;case"ZYZ":i.set(c*g,c*f,o*h,o*l);break;default:Le("MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+s)}}function eo(i){switch(i.constructor){case Uint32Array:return 4294967295;case Uint16Array:return 65535;case Uint8Array:case Uint8ClampedArray:return 255;case Int32Array:return 2147483647;case Int16Array:return 32767;case Int8Array:return 127;default:return}}function _c(i,e){if(e.constructor===Float32Array)return i;const t=eo(e);if(t===void 0)throw new Error("THREE.MathUtils: Invalid component type.");return Math.max(i/t,-1)}function Mc(i,e){if(e.constructor===Float32Array)return i;const t=eo(e);if(t===void 0)throw new Error("THREE.MathUtils: Invalid component type.");return Math.round(i*t)}const qi={DEG2RAD:ar,RAD2DEG:yr,generateUUID:gi,clamp:Ge,euclideanModulo:bc,mapLinear:Qp,inverseLerp:jp,lerp:or,damp:em,pingpong:tm,smoothstep:nm,smootherstep:im,randInt:sm,randFloat:rm,randFloatSpread:am,seededRandom:om,degToRad:lm,radToDeg:cm,isPowerOfTwo:hm,ceilPowerOfTwo:dm,floorPowerOfTwo:Iu,setQuaternionFromProperEuler:um,normalize:Mc,denormalize:_c},Wc=class Wc{constructor(e=0,t=0){this.x=e,this.y=t}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,t){return this.x=e,this.y=t,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;default:throw new Error("THREE.Vector2: index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw new Error("THREE.Vector2: index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){const t=this.x,n=this.y,s=e.elements;return this.x=s[0]*t+s[3]*n+s[6],this.y=s[1]*t+s[4]*n+s[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,t){return this.x=Ge(this.x,e.x,t.x),this.y=Ge(this.y,e.y,t.y),this}clampScalar(e,t){return this.x=Ge(this.x,e,t),this.y=Ge(this.y,e,t),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Ge(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const n=this.dot(e)/t;return Math.acos(Ge(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,n=this.y-e.y;return t*t+n*n}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this}rotateAround(e,t){const n=Math.cos(t),s=Math.sin(t),r=this.x-e.x,a=this.y-e.y;return this.x=r*n-a*s+e.x,this.y=r*s+a*n+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}};Wc.prototype.isVector2=!0;let fe=Wc;class vi{constructor(e=0,t=0,n=0,s=1){this.isQuaternion=!0,this._x=e,this._y=t,this._z=n,this._w=s}static slerpFlat(e,t,n,s,r,a,o){let c=n[s+0],l=n[s+1],h=n[s+2],d=n[s+3],u=r[a+0],f=r[a+1],g=r[a+2],v=r[a+3];if(d!==v||c!==u||l!==f||h!==g){let p=c*u+l*f+h*g+d*v;p<0&&(u=-u,f=-f,g=-g,v=-v,p=-p);let m=1-o;if(p<.9995){const x=Math.acos(p),S=Math.sin(x);m=Math.sin(m*x)/S,o=Math.sin(o*x)/S,c=c*m+u*o,l=l*m+f*o,h=h*m+g*o,d=d*m+v*o}else{c=c*m+u*o,l=l*m+f*o,h=h*m+g*o,d=d*m+v*o;const x=1/Math.sqrt(c*c+l*l+h*h+d*d);c*=x,l*=x,h*=x,d*=x}}e[t]=c,e[t+1]=l,e[t+2]=h,e[t+3]=d}static multiplyQuaternionsFlat(e,t,n,s,r,a){const o=n[s],c=n[s+1],l=n[s+2],h=n[s+3],d=r[a],u=r[a+1],f=r[a+2],g=r[a+3];return e[t]=o*g+h*d+c*f-l*u,e[t+1]=c*g+h*u+l*d-o*f,e[t+2]=l*g+h*f+o*u-c*d,e[t+3]=h*g-o*d-c*u-l*f,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,t,n,s){return this._x=e,this._y=t,this._z=n,this._w=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,t=!0){const n=e._x,s=e._y,r=e._z,a=e._order,o=Math.cos,c=Math.sin,l=o(n/2),h=o(s/2),d=o(r/2),u=c(n/2),f=c(s/2),g=c(r/2);switch(a){case"XYZ":this._x=u*h*d+l*f*g,this._y=l*f*d-u*h*g,this._z=l*h*g+u*f*d,this._w=l*h*d-u*f*g;break;case"YXZ":this._x=u*h*d+l*f*g,this._y=l*f*d-u*h*g,this._z=l*h*g-u*f*d,this._w=l*h*d+u*f*g;break;case"ZXY":this._x=u*h*d-l*f*g,this._y=l*f*d+u*h*g,this._z=l*h*g+u*f*d,this._w=l*h*d-u*f*g;break;case"ZYX":this._x=u*h*d-l*f*g,this._y=l*f*d+u*h*g,this._z=l*h*g-u*f*d,this._w=l*h*d+u*f*g;break;case"YZX":this._x=u*h*d+l*f*g,this._y=l*f*d+u*h*g,this._z=l*h*g-u*f*d,this._w=l*h*d-u*f*g;break;case"XZY":this._x=u*h*d-l*f*g,this._y=l*f*d-u*h*g,this._z=l*h*g+u*f*d,this._w=l*h*d+u*f*g;break;default:Le("Quaternion: .setFromEuler() encountered an unknown order: "+a)}return t===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,t){const n=t/2,s=Math.sin(n);return this._x=e.x*s,this._y=e.y*s,this._z=e.z*s,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(e){const t=e.elements,n=t[0],s=t[4],r=t[8],a=t[1],o=t[5],c=t[9],l=t[2],h=t[6],d=t[10],u=n+o+d;if(u>0){const f=.5/Math.sqrt(u+1);this._w=.25/f,this._x=(h-c)*f,this._y=(r-l)*f,this._z=(a-s)*f}else if(n>o&&n>d){const f=2*Math.sqrt(1+n-o-d);this._w=(h-c)/f,this._x=.25*f,this._y=(s+a)/f,this._z=(r+l)/f}else if(o>d){const f=2*Math.sqrt(1+o-n-d);this._w=(r-l)/f,this._x=(s+a)/f,this._y=.25*f,this._z=(c+h)/f}else{const f=2*Math.sqrt(1+d-n-o);this._w=(a-s)/f,this._x=(r+l)/f,this._y=(c+h)/f,this._z=.25*f}return this._onChangeCallback(),this}setFromUnitVectors(e,t){let n=e.dot(t)+1;return n<1e-8?(n=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=n):(this._x=0,this._y=-e.z,this._z=e.y,this._w=n)):(this._x=e.y*t.z-e.z*t.y,this._y=e.z*t.x-e.x*t.z,this._z=e.x*t.y-e.y*t.x,this._w=n),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(Ge(this.dot(e),-1,1)))}rotateTowards(e,t){const n=this.angleTo(e);if(n===0)return this;const s=Math.min(1,t/n);return this.slerp(e,s),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,t){const n=e._x,s=e._y,r=e._z,a=e._w,o=t._x,c=t._y,l=t._z,h=t._w;return this._x=n*h+a*o+s*l-r*c,this._y=s*h+a*c+r*o-n*l,this._z=r*h+a*l+n*c-s*o,this._w=a*h-n*o-s*c-r*l,this._onChangeCallback(),this}slerp(e,t){let n=e._x,s=e._y,r=e._z,a=e._w,o=this.dot(e);o<0&&(n=-n,s=-s,r=-r,a=-a,o=-o);let c=1-t;if(o<.9995){const l=Math.acos(o),h=Math.sin(l);c=Math.sin(c*l)/h,t=Math.sin(t*l)/h,this._x=this._x*c+n*t,this._y=this._y*c+s*t,this._z=this._z*c+r*t,this._w=this._w*c+a*t,this._onChangeCallback()}else this._x=this._x*c+n*t,this._y=this._y*c+s*t,this._z=this._z*c+r*t,this._w=this._w*c+a*t,this.normalize();return this}slerpQuaternions(e,t,n){return this.copy(e).slerp(t,n)}random(){const e=2*Math.PI*Math.random(),t=2*Math.PI*Math.random(),n=Math.random(),s=Math.sqrt(1-n),r=Math.sqrt(n);return this.set(s*Math.sin(e),s*Math.cos(e),r*Math.sin(t),r*Math.cos(t))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,t=0){return this._x=e[t],this._y=e[t+1],this._z=e[t+2],this._w=e[t+3],this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._w,e}fromBufferAttribute(e,t){return this._x=e.getX(t),this._y=e.getY(t),this._z=e.getZ(t),this._w=e.getW(t),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}const $c=class $c{constructor(e=0,t=0,n=0){this.x=e,this.y=t,this.z=n}set(e,t,n){return n===void 0&&(n=this.z),this.x=e,this.y=t,this.z=n,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;default:throw new Error("THREE.Vector3: index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("THREE.Vector3: index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,t){return this.x=e.x*t.x,this.y=e.y*t.y,this.z=e.z*t.z,this}applyEuler(e){return this.applyQuaternion(xh.setFromEuler(e))}applyAxisAngle(e,t){return this.applyQuaternion(xh.setFromAxisAngle(e,t))}applyMatrix3(e){const t=this.x,n=this.y,s=this.z,r=e.elements;return this.x=r[0]*t+r[3]*n+r[6]*s,this.y=r[1]*t+r[4]*n+r[7]*s,this.z=r[2]*t+r[5]*n+r[8]*s,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){const t=this.x,n=this.y,s=this.z,r=e.elements,a=1/(r[3]*t+r[7]*n+r[11]*s+r[15]);return this.x=(r[0]*t+r[4]*n+r[8]*s+r[12])*a,this.y=(r[1]*t+r[5]*n+r[9]*s+r[13])*a,this.z=(r[2]*t+r[6]*n+r[10]*s+r[14])*a,this}applyQuaternion(e){const t=this.x,n=this.y,s=this.z,r=e.x,a=e.y,o=e.z,c=e.w,l=2*(a*s-o*n),h=2*(o*t-r*s),d=2*(r*n-a*t);return this.x=t+c*l+a*d-o*h,this.y=n+c*h+o*l-r*d,this.z=s+c*d+r*h-a*l,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){const t=this.x,n=this.y,s=this.z,r=e.elements;return this.x=r[0]*t+r[4]*n+r[8]*s,this.y=r[1]*t+r[5]*n+r[9]*s,this.z=r[2]*t+r[6]*n+r[10]*s,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,t){return this.x=Ge(this.x,e.x,t.x),this.y=Ge(this.y,e.y,t.y),this.z=Ge(this.z,e.z,t.z),this}clampScalar(e,t){return this.x=Ge(this.x,e,t),this.y=Ge(this.y,e,t),this.z=Ge(this.z,e,t),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Ge(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,t){const n=e.x,s=e.y,r=e.z,a=t.x,o=t.y,c=t.z;return this.x=s*c-r*o,this.y=r*a-n*c,this.z=n*o-s*a,this}projectOnVector(e){const t=e.lengthSq();if(t===0)return this.set(0,0,0);const n=e.dot(this)/t;return this.copy(e).multiplyScalar(n)}projectOnPlane(e){return vo.copy(this).projectOnVector(e),this.sub(vo)}reflect(e){return this.sub(vo.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const n=this.dot(e)/t;return Math.acos(Ge(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,n=this.y-e.y,s=this.z-e.z;return t*t+n*n+s*s}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,t,n){const s=Math.sin(t)*e;return this.x=s*Math.sin(n),this.y=Math.cos(t)*e,this.z=s*Math.cos(n),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,t,n){return this.x=e*Math.sin(t),this.y=n,this.z=e*Math.cos(t),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this}setFromMatrixScale(e){const t=this.setFromMatrixColumn(e,0).length(),n=this.setFromMatrixColumn(e,1).length(),s=this.setFromMatrixColumn(e,2).length();return this.x=t,this.y=n,this.z=s,this}setFromMatrixColumn(e,t){return this.fromArray(e.elements,t*4)}setFromMatrix3Column(e,t){return this.fromArray(e.elements,t*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const e=Math.random()*Math.PI*2,t=Math.random()*2-1,n=Math.sqrt(1-t*t);return this.x=n*Math.cos(e),this.y=t,this.z=n*Math.sin(e),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}};$c.prototype.isVector3=!0;let P=$c;const vo=new P,xh=new vi,qc=class qc{constructor(e,t,n,s,r,a,o,c,l){this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,t,n,s,r,a,o,c,l)}set(e,t,n,s,r,a,o,c,l){const h=this.elements;return h[0]=e,h[1]=s,h[2]=o,h[3]=t,h[4]=r,h[5]=c,h[6]=n,h[7]=a,h[8]=l,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){const t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],this}extractBasis(e,t,n){return e.setFromMatrix3Column(this,0),t.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(e){const t=e.elements;return this.set(t[0],t[4],t[8],t[1],t[5],t[9],t[2],t[6],t[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const n=e.elements,s=t.elements,r=this.elements,a=n[0],o=n[3],c=n[6],l=n[1],h=n[4],d=n[7],u=n[2],f=n[5],g=n[8],v=s[0],p=s[3],m=s[6],x=s[1],S=s[4],b=s[7],A=s[2],E=s[5],y=s[8];return r[0]=a*v+o*x+c*A,r[3]=a*p+o*S+c*E,r[6]=a*m+o*b+c*y,r[1]=l*v+h*x+d*A,r[4]=l*p+h*S+d*E,r[7]=l*m+h*b+d*y,r[2]=u*v+f*x+g*A,r[5]=u*p+f*S+g*E,r[8]=u*m+f*b+g*y,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[3]*=e,t[6]*=e,t[1]*=e,t[4]*=e,t[7]*=e,t[2]*=e,t[5]*=e,t[8]*=e,this}determinant(){const e=this.elements,t=e[0],n=e[1],s=e[2],r=e[3],a=e[4],o=e[5],c=e[6],l=e[7],h=e[8];return t*a*h-t*o*l-n*r*h+n*o*c+s*r*l-s*a*c}invert(){const e=this.elements,t=e[0],n=e[1],s=e[2],r=e[3],a=e[4],o=e[5],c=e[6],l=e[7],h=e[8],d=h*a-o*l,u=o*c-h*r,f=l*r-a*c,g=t*d+n*u+s*f;if(g===0)return this.set(0,0,0,0,0,0,0,0,0);const v=1/g;return e[0]=d*v,e[1]=(s*l-h*n)*v,e[2]=(o*n-s*a)*v,e[3]=u*v,e[4]=(h*t-s*c)*v,e[5]=(s*r-o*t)*v,e[6]=f*v,e[7]=(n*c-l*t)*v,e[8]=(a*t-n*r)*v,this}transpose(){let e;const t=this.elements;return e=t[1],t[1]=t[3],t[3]=e,e=t[2],t[2]=t[6],t[6]=e,e=t[5],t[5]=t[7],t[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){const t=this.elements;return e[0]=t[0],e[1]=t[3],e[2]=t[6],e[3]=t[1],e[4]=t[4],e[5]=t[7],e[6]=t[2],e[7]=t[5],e[8]=t[8],this}setUvTransform(e,t,n,s,r,a,o){const c=Math.cos(r),l=Math.sin(r);return this.set(n*c,n*l,-n*(c*a+l*o)+a+e,-s*l,s*c,-s*(-l*a+c*o)+o+t,0,0,1),this}scale(e,t){return Pa("Matrix3: .scale() is deprecated. Use .makeScale() instead."),this.premultiply(xo.makeScale(e,t)),this}rotate(e){return Pa("Matrix3: .rotate() is deprecated. Use .makeRotation() instead."),this.premultiply(xo.makeRotation(-e)),this}translate(e,t){return Pa("Matrix3: .translate() is deprecated. Use .makeTranslation() instead."),this.premultiply(xo.makeTranslation(e,t)),this}makeTranslation(e,t){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,t,0,0,1),this}makeRotation(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,n,t,0,0,0,1),this}makeScale(e,t){return this.set(e,0,0,0,t,0,0,0,1),this}equals(e){const t=this.elements,n=e.elements;for(let s=0;s<9;s++)if(t[s]!==n[s])return!1;return!0}fromArray(e,t=0){for(let n=0;n<9;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){const n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e}clone(){return new this.constructor().fromArray(this.elements)}};qc.prototype.isMatrix3=!0;let Ne=qc;const xo=new Ne,yh=new Ne().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),bh=new Ne().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function fm(){const i={enabled:!0,workingColorSpace:za,spaces:{},convert:function(s,r,a){return this.enabled===!1||r===a||!r||!a||(this.spaces[r].transfer===st&&(s.r=ui(s.r),s.g=ui(s.g),s.b=ui(s.b)),this.spaces[r].primaries!==this.spaces[a].primaries&&(s.applyMatrix3(this.spaces[r].toXYZ),s.applyMatrix3(this.spaces[a].fromXYZ)),this.spaces[a].transfer===st&&(s.r=Ts(s.r),s.g=Ts(s.g),s.b=Ts(s.b))),s},workingToColorSpace:function(s,r){return this.convert(s,this.workingColorSpace,r)},colorSpaceToWorking:function(s,r){return this.convert(s,r,this.workingColorSpace)},getPrimaries:function(s){return this.spaces[s].primaries},getTransfer:function(s){return s===li?Ga:this.spaces[s].transfer},getToneMappingMode:function(s){return this.spaces[s].outputColorSpaceConfig.toneMappingMode||"standard"},getLuminanceCoefficients:function(s,r=this.workingColorSpace){return s.fromArray(this.spaces[r].luminanceCoefficients)},define:function(s){Object.assign(this.spaces,s)},_getMatrix:function(s,r,a){return s.copy(this.spaces[a].fromXYZ).multiply(this.spaces[r].toXYZ)},_getDrawingBufferColorSpace:function(s){return this.spaces[s].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(s=this.workingColorSpace){return this.spaces[s].workingColorSpaceConfig.unpackColorSpace}},e=[.64,.33,.3,.6,.15,.06],t=[.2126,.7152,.0722],n=[.3127,.329];return i.define({[za]:{primaries:e,whitePoint:n,transfer:Ga,toXYZ:yh,fromXYZ:bh,luminanceCoefficients:t,workingColorSpaceConfig:{unpackColorSpace:Ft},outputColorSpaceConfig:{drawingBufferColorSpace:Ft}},[Ft]:{primaries:e,whitePoint:n,transfer:st,toXYZ:yh,fromXYZ:bh,luminanceCoefficients:t,outputColorSpaceConfig:{drawingBufferColorSpace:Ft}}}),i}const Xe=fm();function ui(i){return i<.04045?i*.0773993808:Math.pow(i*.9478672986+.0521327014,2.4)}function Ts(i){return i<.0031308?i*12.92:1.055*Math.pow(i,.41666)-.055}let rs;class pm{static getDataURL(e,t="image/png"){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>"u")return e.src;let n;if(e instanceof HTMLCanvasElement)n=e;else{rs===void 0&&(rs=Ha("canvas")),rs.width=e.width,rs.height=e.height;const s=rs.getContext("2d");e instanceof ImageData?s.putImageData(e,0,0):s.drawImage(e,0,0,e.width,e.height),n=rs}return n.toDataURL(t)}static sRGBToLinear(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){const t=Ha("canvas");t.width=e.width,t.height=e.height;const n=t.getContext("2d");n.drawImage(e,0,0,e.width,e.height);const s=n.getImageData(0,0,e.width,e.height),r=s.data;for(let a=0;a<r.length;a++)r[a]=ui(r[a]/255)*255;return n.putImageData(s,0,0),t}else if(e.data){const t=e.data.slice(0);for(let n=0;n<t.length;n++)t instanceof Uint8Array||t instanceof Uint8ClampedArray?t[n]=Math.floor(ui(t[n]/255)*255):t[n]=ui(t[n]);return{data:t,width:e.width,height:e.height}}else return Le("ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}}let mm=0;class Sc{constructor(e=null){this.isTextureSource=!0,Object.defineProperty(this,"id",{value:mm++}),this.uuid=gi(),this.data=e,this.dataReady=!0,this.version=0}getSize(e){const t=this.data;return typeof HTMLVideoElement<"u"&&t instanceof HTMLVideoElement?e.set(t.videoWidth,t.videoHeight,0):typeof VideoFrame<"u"&&t instanceof VideoFrame?e.set(t.displayWidth,t.displayHeight,0):t!==null?e.set(t.width||0,t.height||0,t.depth||0):e.set(0,0,0),e}set needsUpdate(e){e===!0&&this.version++}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.images[this.uuid]!==void 0)return e.images[this.uuid];const n={uuid:this.uuid,url:""},s=this.data;if(s!==null){let r;if(Array.isArray(s)){r=[];for(let a=0,o=s.length;a<o;a++)s[a].isDataTexture?r.push(yo(s[a].image)):r.push(yo(s[a]))}else r=yo(s);n.url=r}return t||(e.images[this.uuid]=n),n}}function yo(i){return typeof HTMLImageElement<"u"&&i instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&i instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&i instanceof ImageBitmap?pm.getDataURL(i):i.data?{data:Array.from(i.data),width:i.width,height:i.height,type:i.data.constructor.name}:(Le("Texture: Unable to serialize Texture."),{})}let gm=0;const bo=new P;class Jt extends ts{constructor(e=Jt.DEFAULT_IMAGE,t=Jt.DEFAULT_MAPPING,n=ci,s=ci,r=nn,a=hi,o=qn,c=ln,l=Jt.DEFAULT_ANISOTROPY,h=li){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:gm++}),this.uuid=gi(),this.name="",this.source=new Sc(e),this.mipmaps=[],this.mapping=t,this.channel=0,this.wrapS=n,this.wrapT=s,this.magFilter=r,this.minFilter=a,this.anisotropy=l,this.format=o,this.internalFormat=null,this.type=c,this.offset=new fe(0,0),this.repeat=new fe(1,1),this.center=new fe(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new Ne,this.generateMipmaps=!0,this.mipmapsAutoUpdate=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=h,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(e&&e.depth&&e.depth>1),this.pmremVersion=0,this.isPMREMTexture=!1,this.normalized=!1}get width(){return this.source.getSize(bo).x}get height(){return this.source.getSize(bo).y}get depth(){return this.source.getSize(bo).z}get image(){return this.source.data}set image(e){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.normalized=e.normalized,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.mipmapsAutoUpdate=e.mipmapsAutoUpdate,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.renderTarget=e.renderTarget,this.isRenderTargetTexture=e.isRenderTargetTexture,this.isPMREMTexture=e.isPMREMTexture,this.isArrayTexture=e.isArrayTexture,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}setValues(e){for(const t in e){const n=e[t];if(n===void 0){Le(`Texture.setValues(): parameter '${t}' has value of undefined.`);continue}const s=this[t];if(s===void 0){Le(`Texture.setValues(): property '${t}' does not exist.`);continue}s&&n&&s.isVector2&&n.isVector2||s&&n&&s.isVector3&&n.isVector3||s&&n&&s.isMatrix3&&n.isMatrix3?s.copy(n):this[t]=n}}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];const n={metadata:{version:4.7,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,normalized:this.normalized,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,mipmapsAutoUpdate:this.mipmapsAutoUpdate,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),t||(e.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(e){if(this.mapping!==_u)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case Oa:e.x=e.x-Math.floor(e.x);break;case ci:e.x=e.x<0?0:1;break;case rl:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x=e.x-Math.floor(e.x);break}if(e.y<0||e.y>1)switch(this.wrapT){case Oa:e.y=e.y-Math.floor(e.y);break;case ci:e.y=e.y<0?0:1;break;case rl:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y=e.y-Math.floor(e.y);break}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(e){e===!0&&this.pmremVersion++}}Jt.DEFAULT_IMAGE=null;Jt.DEFAULT_MAPPING=_u;Jt.DEFAULT_ANISOTROPY=1;const Xc=class Xc{constructor(e=0,t=0,n=0,s=1){this.x=e,this.y=t,this.z=n,this.w=s}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,t,n,s){return this.x=e,this.y=t,this.z=n,this.w=s,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;case 3:this.w=t;break;default:throw new Error("THREE.Vector4: index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("THREE.Vector4: index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w!==void 0?e.w:1,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this.w=e.w+t.w,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this.w+=e.w*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this.w=e.w-t.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){const t=this.x,n=this.y,s=this.z,r=this.w,a=e.elements;return this.x=a[0]*t+a[4]*n+a[8]*s+a[12]*r,this.y=a[1]*t+a[5]*n+a[9]*s+a[13]*r,this.z=a[2]*t+a[6]*n+a[10]*s+a[14]*r,this.w=a[3]*t+a[7]*n+a[11]*s+a[15]*r,this}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this.w/=e.w,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);const t=Math.sqrt(1-e.w*e.w);return t<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/t,this.y=e.y/t,this.z=e.z/t),this}setAxisAngleFromRotationMatrix(e){let t,n,s,r;const c=e.elements,l=c[0],h=c[4],d=c[8],u=c[1],f=c[5],g=c[9],v=c[2],p=c[6],m=c[10];if(Math.abs(h-u)<.01&&Math.abs(d-v)<.01&&Math.abs(g-p)<.01){if(Math.abs(h+u)<.1&&Math.abs(d+v)<.1&&Math.abs(g+p)<.1&&Math.abs(l+f+m-3)<.1)return this.set(1,0,0,0),this;t=Math.PI;const S=(l+1)/2,b=(f+1)/2,A=(m+1)/2,E=(h+u)/4,y=(d+v)/4,w=(g+p)/4;return S>b&&S>A?S<.01?(n=0,s=.707106781,r=.707106781):(n=Math.sqrt(S),s=E/n,r=y/n):b>A?b<.01?(n=.707106781,s=0,r=.707106781):(s=Math.sqrt(b),n=E/s,r=w/s):A<.01?(n=.707106781,s=.707106781,r=0):(r=Math.sqrt(A),n=y/r,s=w/r),this.set(n,s,r,t),this}let x=Math.sqrt((p-g)*(p-g)+(d-v)*(d-v)+(u-h)*(u-h));return Math.abs(x)<.001&&(x=1),this.x=(p-g)/x,this.y=(d-v)/x,this.z=(u-h)/x,this.w=Math.acos((l+f+m-1)/2),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this.w=t[15],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,t){return this.x=Ge(this.x,e.x,t.x),this.y=Ge(this.y,e.y,t.y),this.z=Ge(this.z,e.z,t.z),this.w=Ge(this.w,e.w,t.w),this}clampScalar(e,t){return this.x=Ge(this.x,e,t),this.y=Ge(this.y,e,t),this.z=Ge(this.z,e,t),this.w=Ge(this.w,e,t),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Ge(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this.w+=(e.w-this.w)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this.w=e.w+(t.w-e.w)*n,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this.w=e[t+3],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e[t+3]=this.w,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this.w=e.getW(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}};Xc.prototype.isVector4=!0;let vt=Xc;class vm extends ts{constructor(e=1,t=1,n={}){super(),n=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:nn,depthBuffer:!0,stencilBuffer:!1,resolveColorBuffer:!0,resolveDepthBuffer:!0,resolveStencilBuffer:!0,storeMultisampledColorBuffer:!0,storeMultisampledDepthBuffer:!0,storeMultisampledStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1,useArrayDepthTexture:!1},n),this.isRenderTarget=!0,this.width=e,this.height=t,this.depth=n.depth,this.scissor=new vt(0,0,e,t),this.scissorTest=!1,this.viewport=new vt(0,0,e,t),this.textures=[];const s=n.count;for(let r=0;r<s;r++)this.textures[r]=new Jt({width:e,height:t,depth:n.depth}),this.textures[r].isRenderTargetTexture=!0,this.textures[r].renderTarget=this;this._setTextureOptions(n),this.depthBuffer=n.depthBuffer,this.stencilBuffer=n.stencilBuffer,this.resolveColorBuffer=n.resolveColorBuffer,this.resolveDepthBuffer=n.resolveDepthBuffer,this.resolveStencilBuffer=n.resolveStencilBuffer,this.storeMultisampledColorBuffer=n.storeMultisampledColorBuffer,this.storeMultisampledDepthBuffer=n.storeMultisampledDepthBuffer,this.storeMultisampledStencilBuffer=n.storeMultisampledStencilBuffer,this._depthTexture=null,this.depthTexture=n.depthTexture,this.samples=n.samples,this.multiview=n.multiview,this.useArrayDepthTexture=n.useArrayDepthTexture}_setTextureOptions(e={}){const t={minFilter:nn,generateMipmaps:!1,flipY:!1,internalFormat:null};e.mapping!==void 0&&(t.mapping=e.mapping),e.wrapS!==void 0&&(t.wrapS=e.wrapS),e.wrapT!==void 0&&(t.wrapT=e.wrapT),e.wrapR!==void 0&&(t.wrapR=e.wrapR),e.magFilter!==void 0&&(t.magFilter=e.magFilter),e.minFilter!==void 0&&(t.minFilter=e.minFilter),e.format!==void 0&&(t.format=e.format),e.type!==void 0&&(t.type=e.type),e.anisotropy!==void 0&&(t.anisotropy=e.anisotropy),e.colorSpace!==void 0&&(t.colorSpace=e.colorSpace),e.flipY!==void 0&&(t.flipY=e.flipY),e.generateMipmaps!==void 0&&(t.generateMipmaps=e.generateMipmaps),e.mipmapsAutoUpdate!==void 0&&(t.mipmapsAutoUpdate=e.mipmapsAutoUpdate),e.internalFormat!==void 0&&(t.internalFormat=e.internalFormat);for(let n=0;n<this.textures.length;n++)this.textures[n].setValues(t)}get texture(){return this.textures[0]}set texture(e){this.textures[0]=e}set depthTexture(e){this._depthTexture!==null&&this._depthTexture.renderTarget===this&&(this._depthTexture.renderTarget=null),e!==null&&e.renderTarget===null&&(e.renderTarget=this),this._depthTexture=e}get depthTexture(){return this._depthTexture}setSize(e,t,n=1){if(this.width!==e||this.height!==t||this.depth!==n){this.width=e,this.height=t,this.depth=n;for(let s=0,r=this.textures.length;s<r;s++)this.textures[s].image.width=e,this.textures[s].image.height=t,this.textures[s].image.depth=n,this.textures[s].isData3DTexture!==!0&&(this.textures[s].isArrayTexture=this.textures[s].image.depth>1);this.dispose()}this.viewport.set(0,0,e,t),this.scissor.set(0,0,e,t)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.textures.length=0;for(let t=0,n=e.textures.length;t<n;t++){this.textures[t]=e.textures[t].clone(),this.textures[t].isRenderTargetTexture=!0,this.textures[t].renderTarget=this;const s=Object.assign({},e.textures[t].image);this.textures[t].source=new Sc(s)}if(this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,this.resolveColorBuffer=e.resolveColorBuffer,this.resolveDepthBuffer=e.resolveDepthBuffer,this.resolveStencilBuffer=e.resolveStencilBuffer,this.storeMultisampledColorBuffer=e.storeMultisampledColorBuffer,this.storeMultisampledDepthBuffer=e.storeMultisampledDepthBuffer,this.storeMultisampledStencilBuffer=e.storeMultisampledStencilBuffer,e.depthTexture!==null)if(e.depthTexture.renderTarget===e){const t=e.depthTexture.clone();t.renderTarget=null,this.depthTexture=t}else this.depthTexture=e.depthTexture;else this.depthTexture=null;return this.samples=e.samples,this.multiview=e.multiview,this.useArrayDepthTexture=e.useArrayDepthTexture,this}dispose(){this.dispatchEvent({type:"dispose"})}}class Mn extends vm{constructor(e=1,t=1,n={}){super(e,t,n),this.isWebGLRenderTarget=!0}}class Nu extends Jt{constructor(e=null,t=1,n=1,s=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:t,height:n,depth:s},this.magFilter=zt,this.minFilter=zt,this.wrapR=ci,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}copy(e){return super.copy(e),this.wrapR=e.wrapR,this}addLayerUpdate(e){this.layerUpdates.add(e)}clearLayerUpdates(){this.layerUpdates.clear()}}class xm extends Jt{constructor(e=null,t=1,n=1,s=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:t,height:n,depth:s},this.magFilter=zt,this.minFilter=zt,this.wrapR=ci,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}copy(e){return super.copy(e),this.wrapR=e.wrapR,this}}const Qa=class Qa{constructor(e,t,n,s,r,a,o,c,l,h,d,u,f,g,v,p){this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,t,n,s,r,a,o,c,l,h,d,u,f,g,v,p)}set(e,t,n,s,r,a,o,c,l,h,d,u,f,g,v,p){const m=this.elements;return m[0]=e,m[4]=t,m[8]=n,m[12]=s,m[1]=r,m[5]=a,m[9]=o,m[13]=c,m[2]=l,m[6]=h,m[10]=d,m[14]=u,m[3]=f,m[7]=g,m[11]=v,m[15]=p,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new Qa().fromArray(this.elements)}copy(e){const t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],t[9]=n[9],t[10]=n[10],t[11]=n[11],t[12]=n[12],t[13]=n[13],t[14]=n[14],t[15]=n[15],this}copyPosition(e){const t=this.elements,n=e.elements;return t[12]=n[12],t[13]=n[13],t[14]=n[14],this}setFromMatrix3(e){const t=e.elements;return this.set(t[0],t[3],t[6],0,t[1],t[4],t[7],0,t[2],t[5],t[8],0,0,0,0,1),this}extractBasis(e,t,n){return this.determinantAffine()===0?(e.set(1,0,0),t.set(0,1,0),n.set(0,0,1),this):(e.setFromMatrixColumn(this,0),t.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this)}makeBasis(e,t,n){return this.set(e.x,t.x,n.x,0,e.y,t.y,n.y,0,e.z,t.z,n.z,0,0,0,0,1),this}extractRotation(e){if(e.determinantAffine()===0)return this.identity();const t=this.elements,n=e.elements,s=1/as.setFromMatrixColumn(e,0).length(),r=1/as.setFromMatrixColumn(e,1).length(),a=1/as.setFromMatrixColumn(e,2).length();return t[0]=n[0]*s,t[1]=n[1]*s,t[2]=n[2]*s,t[3]=0,t[4]=n[4]*r,t[5]=n[5]*r,t[6]=n[6]*r,t[7]=0,t[8]=n[8]*a,t[9]=n[9]*a,t[10]=n[10]*a,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromEuler(e){const t=this.elements,n=e.x,s=e.y,r=e.z,a=Math.cos(n),o=Math.sin(n),c=Math.cos(s),l=Math.sin(s),h=Math.cos(r),d=Math.sin(r);if(e.order==="XYZ"){const u=a*h,f=a*d,g=o*h,v=o*d;t[0]=c*h,t[4]=-c*d,t[8]=l,t[1]=f+g*l,t[5]=u-v*l,t[9]=-o*c,t[2]=v-u*l,t[6]=g+f*l,t[10]=a*c}else if(e.order==="YXZ"){const u=c*h,f=c*d,g=l*h,v=l*d;t[0]=u+v*o,t[4]=g*o-f,t[8]=a*l,t[1]=a*d,t[5]=a*h,t[9]=-o,t[2]=f*o-g,t[6]=v+u*o,t[10]=a*c}else if(e.order==="ZXY"){const u=c*h,f=c*d,g=l*h,v=l*d;t[0]=u-v*o,t[4]=-a*d,t[8]=g+f*o,t[1]=f+g*o,t[5]=a*h,t[9]=v-u*o,t[2]=-a*l,t[6]=o,t[10]=a*c}else if(e.order==="ZYX"){const u=a*h,f=a*d,g=o*h,v=o*d;t[0]=c*h,t[4]=g*l-f,t[8]=u*l+v,t[1]=c*d,t[5]=v*l+u,t[9]=f*l-g,t[2]=-l,t[6]=o*c,t[10]=a*c}else if(e.order==="YZX"){const u=a*c,f=a*l,g=o*c,v=o*l;t[0]=c*h,t[4]=v-u*d,t[8]=g*d+f,t[1]=d,t[5]=a*h,t[9]=-o*h,t[2]=-l*h,t[6]=f*d+g,t[10]=u-v*d}else if(e.order==="XZY"){const u=a*c,f=a*l,g=o*c,v=o*l;t[0]=c*h,t[4]=-d,t[8]=l*h,t[1]=u*d+v,t[5]=a*h,t[9]=f*d-g,t[2]=g*d-f,t[6]=o*h,t[10]=v*d+u}return t[3]=0,t[7]=0,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromQuaternion(e){return this.compose(ym,e,bm)}lookAt(e,t,n){const s=this.elements;return cn.subVectors(e,t),cn.lengthSq()===0&&(cn.z=1),cn.normalize(),bi.crossVectors(n,cn),bi.lengthSq()===0&&(Math.abs(n.z)===1?cn.x+=1e-4:cn.z+=1e-4,cn.normalize(),bi.crossVectors(n,cn)),bi.normalize(),zr.crossVectors(cn,bi),s[0]=bi.x,s[4]=zr.x,s[8]=cn.x,s[1]=bi.y,s[5]=zr.y,s[9]=cn.y,s[2]=bi.z,s[6]=zr.z,s[10]=cn.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const n=e.elements,s=t.elements,r=this.elements,a=n[0],o=n[4],c=n[8],l=n[12],h=n[1],d=n[5],u=n[9],f=n[13],g=n[2],v=n[6],p=n[10],m=n[14],x=n[3],S=n[7],b=n[11],A=n[15],E=s[0],y=s[4],w=s[8],L=s[12],R=s[1],N=s[5],F=s[9],V=s[13],I=s[2],H=s[6],J=s[10],z=s[14],ne=s[3],$=s[7],j=s[11],ee=s[15];return r[0]=a*E+o*R+c*I+l*ne,r[4]=a*y+o*N+c*H+l*$,r[8]=a*w+o*F+c*J+l*j,r[12]=a*L+o*V+c*z+l*ee,r[1]=h*E+d*R+u*I+f*ne,r[5]=h*y+d*N+u*H+f*$,r[9]=h*w+d*F+u*J+f*j,r[13]=h*L+d*V+u*z+f*ee,r[2]=g*E+v*R+p*I+m*ne,r[6]=g*y+v*N+p*H+m*$,r[10]=g*w+v*F+p*J+m*j,r[14]=g*L+v*V+p*z+m*ee,r[3]=x*E+S*R+b*I+A*ne,r[7]=x*y+S*N+b*H+A*$,r[11]=x*w+S*F+b*J+A*j,r[15]=x*L+S*V+b*z+A*ee,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[4]*=e,t[8]*=e,t[12]*=e,t[1]*=e,t[5]*=e,t[9]*=e,t[13]*=e,t[2]*=e,t[6]*=e,t[10]*=e,t[14]*=e,t[3]*=e,t[7]*=e,t[11]*=e,t[15]*=e,this}determinant(){const e=this.elements,t=e[0],n=e[4],s=e[8],r=e[12],a=e[1],o=e[5],c=e[9],l=e[13],h=e[2],d=e[6],u=e[10],f=e[14],g=e[3],v=e[7],p=e[11],m=e[15],x=c*f-l*u,S=o*f-l*d,b=o*u-c*d,A=a*f-l*h,E=a*u-c*h,y=a*d-o*h;return t*(v*x-p*S+m*b)-n*(g*x-p*A+m*E)+s*(g*S-v*A+m*y)-r*(g*b-v*E+p*y)}determinantAffine(){const e=this.elements,t=e[0],n=e[4],s=e[8],r=e[1],a=e[5],o=e[9],c=e[2],l=e[6],h=e[10];return t*(a*h-o*l)-n*(r*h-o*c)+s*(r*l-a*c)}transpose(){const e=this.elements;let t;return t=e[1],e[1]=e[4],e[4]=t,t=e[2],e[2]=e[8],e[8]=t,t=e[6],e[6]=e[9],e[9]=t,t=e[3],e[3]=e[12],e[12]=t,t=e[7],e[7]=e[13],e[13]=t,t=e[11],e[11]=e[14],e[14]=t,this}setPosition(e,t,n){const s=this.elements;return e.isVector3?(s[12]=e.x,s[13]=e.y,s[14]=e.z):(s[12]=e,s[13]=t,s[14]=n),this}invert(){const e=this.elements,t=e[0],n=e[1],s=e[2],r=e[3],a=e[4],o=e[5],c=e[6],l=e[7],h=e[8],d=e[9],u=e[10],f=e[11],g=e[12],v=e[13],p=e[14],m=e[15],x=t*o-n*a,S=t*c-s*a,b=t*l-r*a,A=n*c-s*o,E=n*l-r*o,y=s*l-r*c,w=h*v-d*g,L=h*p-u*g,R=h*m-f*g,N=d*p-u*v,F=d*m-f*v,V=u*m-f*p,I=x*V-S*F+b*N+A*R-E*L+y*w;if(I===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const H=1/I;return e[0]=(o*V-c*F+l*N)*H,e[1]=(s*F-n*V-r*N)*H,e[2]=(v*y-p*E+m*A)*H,e[3]=(u*E-d*y-f*A)*H,e[4]=(c*R-a*V-l*L)*H,e[5]=(t*V-s*R+r*L)*H,e[6]=(p*b-g*y-m*S)*H,e[7]=(h*y-u*b+f*S)*H,e[8]=(a*F-o*R+l*w)*H,e[9]=(n*R-t*F-r*w)*H,e[10]=(g*E-v*b+m*x)*H,e[11]=(d*b-h*E-f*x)*H,e[12]=(o*L-a*N-c*w)*H,e[13]=(t*N-n*L+s*w)*H,e[14]=(v*S-g*A-p*x)*H,e[15]=(h*A-d*S+u*x)*H,this}scale(e){const t=this.elements,n=e.x,s=e.y,r=e.z;return t[0]*=n,t[4]*=s,t[8]*=r,t[1]*=n,t[5]*=s,t[9]*=r,t[2]*=n,t[6]*=s,t[10]*=r,t[3]*=n,t[7]*=s,t[11]*=r,this}getMaxScaleOnAxis(){const e=this.elements,t=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],n=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],s=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(t,n,s))}makeTranslation(e,t,n){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,t,0,0,1,n,0,0,0,1),this}makeRotationX(e){const t=Math.cos(e),n=Math.sin(e);return this.set(1,0,0,0,0,t,-n,0,0,n,t,0,0,0,0,1),this}makeRotationY(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,0,n,0,0,1,0,0,-n,0,t,0,0,0,0,1),this}makeRotationZ(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,0,n,t,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,t){const n=Math.cos(t),s=Math.sin(t),r=1-n,a=e.x,o=e.y,c=e.z,l=r*a,h=r*o;return this.set(l*a+n,l*o-s*c,l*c+s*o,0,l*o+s*c,h*o+n,h*c-s*a,0,l*c-s*o,h*c+s*a,r*c*c+n,0,0,0,0,1),this}makeScale(e,t,n){return this.set(e,0,0,0,0,t,0,0,0,0,n,0,0,0,0,1),this}makeShear(e,t,n,s,r,a){return this.set(1,n,r,0,e,1,a,0,t,s,1,0,0,0,0,1),this}compose(e,t,n){const s=this.elements,r=t._x,a=t._y,o=t._z,c=t._w,l=r+r,h=a+a,d=o+o,u=r*l,f=r*h,g=r*d,v=a*h,p=a*d,m=o*d,x=c*l,S=c*h,b=c*d,A=n.x,E=n.y,y=n.z;return s[0]=(1-(v+m))*A,s[1]=(f+b)*A,s[2]=(g-S)*A,s[3]=0,s[4]=(f-b)*E,s[5]=(1-(u+m))*E,s[6]=(p+x)*E,s[7]=0,s[8]=(g+S)*y,s[9]=(p-x)*y,s[10]=(1-(u+v))*y,s[11]=0,s[12]=e.x,s[13]=e.y,s[14]=e.z,s[15]=1,this}decompose(e,t,n){const s=this.elements;e.x=s[12],e.y=s[13],e.z=s[14];const r=this.determinantAffine();if(r===0)return n.set(1,1,1),t.identity(),this;let a=as.set(s[0],s[1],s[2]).length();const o=as.set(s[4],s[5],s[6]).length(),c=as.set(s[8],s[9],s[10]).length();r<0&&(a=-a),En.copy(this);const l=1/a,h=1/o,d=1/c;return En.elements[0]*=l,En.elements[1]*=l,En.elements[2]*=l,En.elements[4]*=h,En.elements[5]*=h,En.elements[6]*=h,En.elements[8]*=d,En.elements[9]*=d,En.elements[10]*=d,t.setFromRotationMatrix(En),n.x=a,n.y=o,n.z=c,this}makePerspective(e,t,n,s,r,a,o=In,c=!1){const l=this.elements,h=2*r/(t-e),d=2*r/(n-s),u=(t+e)/(t-e),f=(n+s)/(n-s);let g,v;if(c)g=r/(a-r),v=a*r/(a-r);else if(o===In)g=-(a+r)/(a-r),v=-2*a*r/(a-r);else if(o===xr)g=-a/(a-r),v=-a*r/(a-r);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+o);return l[0]=h,l[4]=0,l[8]=u,l[12]=0,l[1]=0,l[5]=d,l[9]=f,l[13]=0,l[2]=0,l[6]=0,l[10]=g,l[14]=v,l[3]=0,l[7]=0,l[11]=-1,l[15]=0,this}makeOrthographic(e,t,n,s,r,a,o=In,c=!1){const l=this.elements,h=2/(t-e),d=2/(n-s),u=-(t+e)/(t-e),f=-(n+s)/(n-s);let g,v;if(c)g=1/(a-r),v=a/(a-r);else if(o===In)g=-2/(a-r),v=-(a+r)/(a-r);else if(o===xr)g=-1/(a-r),v=-r/(a-r);else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+o);return l[0]=h,l[4]=0,l[8]=0,l[12]=u,l[1]=0,l[5]=d,l[9]=0,l[13]=f,l[2]=0,l[6]=0,l[10]=g,l[14]=v,l[3]=0,l[7]=0,l[11]=0,l[15]=1,this}equals(e){const t=this.elements,n=e.elements;for(let s=0;s<16;s++)if(t[s]!==n[s])return!1;return!0}fromArray(e,t=0){for(let n=0;n<16;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){const n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e[t+9]=n[9],e[t+10]=n[10],e[t+11]=n[11],e[t+12]=n[12],e[t+13]=n[13],e[t+14]=n[14],e[t+15]=n[15],e}};Qa.prototype.isMatrix4=!0;let Ke=Qa;const as=new P,En=new Ke,ym=new P(0,0,0),bm=new P(1,1,1),bi=new P,zr=new P,cn=new P,_h=new Ke,Mh=new vi;class On{constructor(e=0,t=0,n=0,s=On.DEFAULT_ORDER){this.isEuler=!0,this._x=e,this._y=t,this._z=n,this._order=s}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,t,n,s=this._order){return this._x=e,this._y=t,this._z=n,this._order=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,t=this._order,n=!0){const s=e.elements,r=s[0],a=s[4],o=s[8],c=s[1],l=s[5],h=s[9],d=s[2],u=s[6],f=s[10];switch(t){case"XYZ":this._y=Math.asin(Ge(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(-h,f),this._z=Math.atan2(-a,r)):(this._x=Math.atan2(u,l),this._z=0);break;case"YXZ":this._x=Math.asin(-Ge(h,-1,1)),Math.abs(h)<.9999999?(this._y=Math.atan2(o,f),this._z=Math.atan2(c,l)):(this._y=Math.atan2(-d,r),this._z=0);break;case"ZXY":this._x=Math.asin(Ge(u,-1,1)),Math.abs(u)<.9999999?(this._y=Math.atan2(-d,f),this._z=Math.atan2(-a,l)):(this._y=0,this._z=Math.atan2(c,r));break;case"ZYX":this._y=Math.asin(-Ge(d,-1,1)),Math.abs(d)<.9999999?(this._x=Math.atan2(u,f),this._z=Math.atan2(c,r)):(this._x=0,this._z=Math.atan2(-a,l));break;case"YZX":this._z=Math.asin(Ge(c,-1,1)),Math.abs(c)<.9999999?(this._x=Math.atan2(-h,l),this._y=Math.atan2(-d,r)):(this._x=0,this._y=Math.atan2(o,f));break;case"XZY":this._z=Math.asin(-Ge(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(u,l),this._y=Math.atan2(o,r)):(this._x=Math.atan2(-h,f),this._y=0);break;default:Le("Euler: .setFromRotationMatrix() encountered an unknown order: "+t)}return this._order=t,n===!0&&this._onChangeCallback(),this}setFromQuaternion(e,t,n){return _h.makeRotationFromQuaternion(e),this.setFromRotationMatrix(_h,t,n)}setFromVector3(e,t=this._order){return this.set(e.x,e.y,e.z,t)}reorder(e){return Mh.setFromEuler(this),this.setFromQuaternion(Mh,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}On.DEFAULT_ORDER="XYZ";class wc{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return(this.mask&(1<<e|0))!==0}}let _m=0;const Sh=new P,os=new vi,jn=new Ke,Gr=new P,zs=new P,Mm=new P,Sm=new vi,wh=new P(1,0,0),Eh=new P(0,1,0),Ah=new P(0,0,1),Th={type:"added"},wm={type:"removed"},ls={type:"childadded",child:null},_o={type:"childremoved",child:null};class Et extends ts{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:_m++}),this.uuid=gi(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=Et.DEFAULT_UP.clone();const e=new P,t=new On,n=new vi,s=new P(1,1,1);function r(){n.setFromEuler(t,!1)}function a(){t.setFromQuaternion(n,void 0,!1)}t._onChange(r),n._onChange(a),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:e},rotation:{configurable:!0,enumerable:!0,value:t},quaternion:{configurable:!0,enumerable:!0,value:n},scale:{configurable:!0,enumerable:!0,value:s},modelViewMatrix:{value:new Ke},normalMatrix:{value:new Ne}}),this.matrix=new Ke,this.matrixWorld=new Ke,this.matrixAutoUpdate=Et.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=Et.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new wc,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.static=!1,this.userData={},this.pivot=null}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale),this.pivot!==null&&this.position.copy(this.pivot).applyMatrix4(this.matrix).sub(this.pivot)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,t){this.quaternion.setFromAxisAngle(e,t)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,t){return os.setFromAxisAngle(e,t),this.quaternion.multiply(os),this}rotateOnWorldAxis(e,t){return os.setFromAxisAngle(e,t),this.quaternion.premultiply(os),this}rotateX(e){return this.rotateOnAxis(wh,e)}rotateY(e){return this.rotateOnAxis(Eh,e)}rotateZ(e){return this.rotateOnAxis(Ah,e)}translateOnAxis(e,t){return Sh.copy(e).applyQuaternion(this.quaternion),this.position.add(Sh.multiplyScalar(t)),this}translateX(e){return this.translateOnAxis(wh,e)}translateY(e){return this.translateOnAxis(Eh,e)}translateZ(e){return this.translateOnAxis(Ah,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(jn.copy(this.matrixWorld).invert())}lookAt(e,t,n){e.isVector3?Gr.copy(e):Gr.set(e,t,n);const s=this.parent;this.updateWorldMatrix(!0,!1),zs.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?jn.lookAt(zs,Gr,this.up):jn.lookAt(Gr,zs,this.up),this.quaternion.setFromRotationMatrix(jn),s&&(jn.extractRotation(s.matrixWorld),os.setFromRotationMatrix(jn),this.quaternion.premultiply(os.invert()))}add(e){if(arguments.length>1){for(let t=0;t<arguments.length;t++)this.add(arguments[t]);return this}return e===this?(Ze("Object3D.add: object can't be added as a child of itself.",e),this):(e&&e.isObject3D?(e.removeFromParent(),e.parent=this,this.children.push(e),e.dispatchEvent(Th),ls.child=e,this.dispatchEvent(ls),ls.child=null):Ze("Object3D.add: object not an instance of THREE.Object3D.",e),this)}remove(e){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.remove(arguments[n]);return this}const t=this.children.indexOf(e);return t!==-1&&(e.parent=null,this.children.splice(t,1),e.dispatchEvent(wm),_o.child=e,this.dispatchEvent(_o),_o.child=null),this}removeFromParent(){const e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),jn.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),jn.multiply(e.parent.matrixWorld)),e.applyMatrix4(jn),e.removeFromParent(),e.parent=this,this.children.push(e),e.updateWorldMatrix(!1,!0),e.dispatchEvent(Th),ls.child=e,this.dispatchEvent(ls),ls.child=null,this}getObjectById(e){return this.getObjectByProperty("id",e)}getObjectByName(e){return this.getObjectByProperty("name",e)}getObjectByProperty(e,t){if(this[e]===t)return this;for(let n=0,s=this.children.length;n<s;n++){const a=this.children[n].getObjectByProperty(e,t);if(a!==void 0)return a}}getObjectsByProperty(e,t,n=[]){this[e]===t&&n.push(this);const s=this.children;for(let r=0,a=s.length;r<a;r++)s[r].getObjectsByProperty(e,t,n);return n}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(zs,e,Mm),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(zs,Sm,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);const t=this.matrixWorld.elements;return e.set(t[8],t[9],t[10]).normalize()}raycast(){}intersectsFrustum(){return!0}traverse(e){e(this);const t=this.children;for(let n=0,s=t.length;n<s;n++)t[n].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);const t=this.children;for(let n=0,s=t.length;n<s;n++)t[n].traverseVisible(e)}traverseAncestors(e){const t=this.parent;t!==null&&(e(t),t.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale);const e=this.pivot;if(e!==null){const t=e.x,n=e.y,s=e.z,r=this.matrix.elements;r[12]+=t-r[0]*t-r[4]*n-r[8]*s,r[13]+=n-r[1]*t-r[5]*n-r[9]*s,r[14]+=s-r[2]*t-r[6]*n-r[10]*s}this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,e=!0);const t=this.children;for(let n=0,s=t.length;n<s;n++)t[n].updateMatrixWorld(e)}updateWorldMatrix(e,t,n=!1){const s=this.parent;if(e===!0&&s!==null&&s.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||n)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,n=!0),t===!0){const r=this.children;for(let a=0,o=r.length;a<o;a++)r[a].updateWorldMatrix(!1,!0,n)}}toJSON(e){const t=e===void 0||typeof e=="string",n={};t&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.7,type:"Object",generator:"Object3D.toJSON"});const s={};s.uuid=this.uuid,s.type=this.type,s.name=this.name,s.castShadow=this.castShadow,s.receiveShadow=this.receiveShadow,s.visible=this.visible,s.frustumCulled=this.frustumCulled,s.renderOrder=this.renderOrder,s.static=this.static,s.matrixAutoUpdate=this.matrixAutoUpdate,Object.keys(this.userData).length>0&&(s.userData=this.userData),s.layers=this.layers.mask,s.matrix=this.matrix.toArray(),s.up=this.up.toArray(),this.pivot!==null&&(s.pivot=this.pivot.toArray()),this.morphTargetDictionary!==void 0&&(s.morphTargetDictionary=Object.assign({},this.morphTargetDictionary)),this.morphTargetInfluences!==void 0&&(s.morphTargetInfluences=this.morphTargetInfluences.slice()),this.isInstancedMesh&&(s.type="InstancedMesh",s.count=this.count,s.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(s.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(s.type="BatchedMesh",s.perObjectFrustumCulled=this.perObjectFrustumCulled,s.sortObjects=this.sortObjects,s.drawRanges=this._drawRanges,s.reservedRanges=this._reservedRanges,s.geometryInfo=this._geometryInfo.map(o=>({...o,boundingBox:o.boundingBox?o.boundingBox.toJSON():void 0,boundingSphere:o.boundingSphere?o.boundingSphere.toJSON():void 0})),s.instanceInfo=this._instanceInfo.map(o=>({...o})),s.availableInstanceIds=this._availableInstanceIds.slice(),s.availableGeometryIds=this._availableGeometryIds.slice(),s.nextIndexStart=this._nextIndexStart,s.nextVertexStart=this._nextVertexStart,s.geometryCount=this._geometryCount,s.maxInstanceCount=this._maxInstanceCount,s.maxVertexCount=this._maxVertexCount,s.maxIndexCount=this._maxIndexCount,s.geometryInitialized=this._geometryInitialized,s.matricesTexture=this._matricesTexture.toJSON(e),s.indirectTexture=this._indirectTexture.toJSON(e),this._colorsTexture!==null&&(s.colorsTexture=this._colorsTexture.toJSON(e)),this.boundingSphere!==null&&(s.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(s.boundingBox=this.boundingBox.toJSON()));function r(o,c){return o[c.uuid]===void 0&&(o[c.uuid]=c.toJSON(e)),c.uuid}if(this.isScene)this.background&&(this.background.isColor?s.background=this.background.toJSON():this.background.isTexture&&(s.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(s.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){s.geometry=r(e.geometries,this.geometry);const o=this.geometry.parameters;if(o!==void 0&&o.shapes!==void 0){const c=o.shapes;if(Array.isArray(c))for(let l=0,h=c.length;l<h;l++){const d=c[l];r(e.shapes,d)}else r(e.shapes,c)}}if(this.isSkinnedMesh&&(s.bindMode=this.bindMode,s.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(r(e.skeletons,this.skeleton),s.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const o=[];for(let c=0,l=this.material.length;c<l;c++)o.push(r(e.materials,this.material[c]));s.material=o}else s.material=r(e.materials,this.material);if(this.children.length>0){s.children=[];for(let o=0;o<this.children.length;o++)s.children.push(this.children[o].toJSON(e).object)}if(this.animations.length>0){s.animations=[];for(let o=0;o<this.animations.length;o++){const c=this.animations[o];s.animations.push(r(e.animations,c))}}if(t){const o=a(e.geometries),c=a(e.materials),l=a(e.textures),h=a(e.images),d=a(e.shapes),u=a(e.skeletons),f=a(e.animations),g=a(e.nodes);o.length>0&&(n.geometries=o),c.length>0&&(n.materials=c),l.length>0&&(n.textures=l),h.length>0&&(n.images=h),d.length>0&&(n.shapes=d),u.length>0&&(n.skeletons=u),f.length>0&&(n.animations=f),g.length>0&&(n.nodes=g)}return n.object=s,n;function a(o){const c=[];for(const l in o){const h=o[l];delete h.metadata,c.push(h)}return c}}clone(e){return new this.constructor().copy(this,e)}copy(e,t=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.pivot=e.pivot!==null?e.pivot.clone():null,this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.static=e.static,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),t===!0)for(let n=0;n<e.children.length;n++){const s=e.children[n];this.add(s.clone())}return this}dispose(){this.dispatchEvent({type:"dispose"})}}Et.DEFAULT_UP=new P(0,1,0);Et.DEFAULT_MATRIX_AUTO_UPDATE=!0;Et.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;class yt extends Et{constructor(){super(),this.isGroup=!0,this.type="Group"}}const Em={type:"move"};class Mo{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new yt,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new yt,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new P,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new P),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new yt,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new P,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new P,this._grip.eventsEnabled=!1),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){const t=this._hand;if(t)for(const n of e.hand.values())this._getHandJoint(t,n)}return this.dispatchEvent({type:"connected",data:e}),this}disconnect(e){return this.dispatchEvent({type:"disconnected",data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,t,n){let s=null,r=null,a=null;const o=this._targetRay,c=this._grip,l=this._hand;if(e&&t.session.visibilityState!=="visible-blurred"){if(l&&e.hand){a=!0;for(const v of e.hand.values()){const p=t.getJointPose(v,n),m=this._getHandJoint(l,v);p!==null&&(m.matrix.fromArray(p.transform.matrix),m.matrix.decompose(m.position,m.quaternion,m.scale),m.matrixWorldNeedsUpdate=!0,m.jointRadius=p.radius),m.visible=p!==null}const h=l.joints["index-finger-tip"],d=l.joints["thumb-tip"],u=h.position.distanceTo(d.position),f=.02,g=.005;l.inputState.pinching&&u>f+g?(l.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:e.handedness,target:this})):!l.inputState.pinching&&u<=f-g&&(l.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:e.handedness,target:this}))}else c!==null&&e.gripSpace&&(r=t.getPose(e.gripSpace,n),r!==null&&(c.matrix.fromArray(r.transform.matrix),c.matrix.decompose(c.position,c.quaternion,c.scale),c.matrixWorldNeedsUpdate=!0,r.linearVelocity?(c.hasLinearVelocity=!0,c.linearVelocity.copy(r.linearVelocity)):c.hasLinearVelocity=!1,r.angularVelocity?(c.hasAngularVelocity=!0,c.angularVelocity.copy(r.angularVelocity)):c.hasAngularVelocity=!1,c.eventsEnabled&&c.dispatchEvent({type:"gripUpdated",data:e,target:this})));o!==null&&(s=t.getPose(e.targetRaySpace,n),s===null&&r!==null&&(s=r),s!==null&&(o.matrix.fromArray(s.transform.matrix),o.matrix.decompose(o.position,o.quaternion,o.scale),o.matrixWorldNeedsUpdate=!0,s.linearVelocity?(o.hasLinearVelocity=!0,o.linearVelocity.copy(s.linearVelocity)):o.hasLinearVelocity=!1,s.angularVelocity?(o.hasAngularVelocity=!0,o.angularVelocity.copy(s.angularVelocity)):o.hasAngularVelocity=!1,this.dispatchEvent(Em)))}return o!==null&&(o.visible=s!==null),c!==null&&(c.visible=r!==null),l!==null&&(l.visible=a!==null),this}_getHandJoint(e,t){if(e.joints[t.jointName]===void 0){const n=new yt;n.matrixAutoUpdate=!1,n.visible=!1,e.joints[t.jointName]=n,e.add(n)}return e.joints[t.jointName]}}const Uu={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},_i={h:0,s:0,l:0},Hr={h:0,s:0,l:0};function So(i,e,t){return t<0&&(t+=1),t>1&&(t-=1),t<1/6?i+(e-i)*6*t:t<1/2?e:t<2/3?i+(e-i)*6*(2/3-t):i}class Te{constructor(e,t,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,t,n)}set(e,t,n){if(t===void 0&&n===void 0){const s=e;s&&s.isColor?this.copy(s):typeof s=="number"?this.setHex(s):typeof s=="string"&&this.setStyle(s)}else this.setRGB(e,t,n);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,t=Ft){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,Xe.colorSpaceToWorking(this,t),this}setRGB(e,t,n,s=Xe.workingColorSpace){return this.r=e,this.g=t,this.b=n,Xe.colorSpaceToWorking(this,s),this}setHSL(e,t,n,s=Xe.workingColorSpace){if(e=bc(e,1),t=Ge(t,0,1),n=Ge(n,0,1),t===0)this.r=this.g=this.b=n;else{const r=n<=.5?n*(1+t):n+t-n*t,a=2*n-r;this.r=So(a,r,e+1/3),this.g=So(a,r,e),this.b=So(a,r,e-1/3)}return Xe.colorSpaceToWorking(this,s),this}setStyle(e,t=Ft){function n(r){r!==void 0&&parseFloat(r)<1&&Le("Color: Alpha component of "+e+" will be ignored.")}let s;if(s=/^(\w+)\(([^\)]*)\)/.exec(e)){let r;const a=s[1],o=s[2];switch(a){case"rgb":case"rgba":if(r=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d+(?:\.\d+)?|\.\d+)\s*)?$/.exec(o))return n(r[4]),this.setRGB(Math.min(255,parseInt(r[1],10))/255,Math.min(255,parseInt(r[2],10))/255,Math.min(255,parseInt(r[3],10))/255,t);if(r=/^\s*(\d+(?:\.\d+)?|\.\d+)\%\s*,\s*(\d+(?:\.\d+)?|\.\d+)\%\s*,\s*(\d+(?:\.\d+)?|\.\d+)\%\s*(?:,\s*(\d+(?:\.\d+)?|\.\d+)\s*)?$/.exec(o))return n(r[4]),this.setRGB(Math.min(100,parseFloat(r[1]))/100,Math.min(100,parseFloat(r[2]))/100,Math.min(100,parseFloat(r[3]))/100,t);break;case"hsl":case"hsla":if(r=/^\s*([+-]?(?:\d+(?:\.\d+)?|\.\d+))\s*,\s*(\d+(?:\.\d+)?|\.\d+)\%\s*,\s*(\d+(?:\.\d+)?|\.\d+)\%\s*(?:,\s*(\d+(?:\.\d+)?|\.\d+)\s*)?$/.exec(o))return n(r[4]),this.setHSL(parseFloat(r[1])/360,parseFloat(r[2])/100,parseFloat(r[3])/100,t);break;default:Le("Color: Unknown color model "+e)}}else if(s=/^\#([A-Fa-f\d]+)$/.exec(e)){const r=s[1],a=r.length;if(a===3)return this.setRGB(parseInt(r.charAt(0),16)/15,parseInt(r.charAt(1),16)/15,parseInt(r.charAt(2),16)/15,t);if(a===6)return this.setHex(parseInt(r,16),t);Le("Color: Invalid hex color "+e)}else if(e&&e.length>0)return this.setColorName(e,t);return this}setColorName(e,t=Ft){const n=Uu[e.toLowerCase()];return n!==void 0?this.setHex(n,t):Le("Color: Unknown color "+e),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=ui(e.r),this.g=ui(e.g),this.b=ui(e.b),this}copyLinearToSRGB(e){return this.r=Ts(e.r),this.g=Ts(e.g),this.b=Ts(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=Ft){return Xe.workingToColorSpace(Yt.copy(this),e),Math.round(Ge(Yt.r*255,0,255))*65536+Math.round(Ge(Yt.g*255,0,255))*256+Math.round(Ge(Yt.b*255,0,255))}getHexString(e=Ft){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,t=Xe.workingColorSpace){Xe.workingToColorSpace(Yt.copy(this),t);const n=Yt.r,s=Yt.g,r=Yt.b,a=Math.max(n,s,r),o=Math.min(n,s,r);let c,l;const h=(o+a)/2;if(o===a)c=0,l=0;else{const d=a-o;switch(l=h<=.5?d/(a+o):d/(2-a-o),a){case n:c=(s-r)/d+(s<r?6:0);break;case s:c=(r-n)/d+2;break;case r:c=(n-s)/d+4;break}c/=6}return e.h=c,e.s=l,e.l=h,e}getRGB(e,t=Xe.workingColorSpace){return Xe.workingToColorSpace(Yt.copy(this),t),e.r=Yt.r,e.g=Yt.g,e.b=Yt.b,e}getStyle(e=Ft){Xe.workingToColorSpace(Yt.copy(this),e);const t=Yt.r,n=Yt.g,s=Yt.b;return e!==Ft?`color(${e} ${t.toFixed(3)} ${n.toFixed(3)} ${s.toFixed(3)})`:`rgb(${Math.round(t*255)},${Math.round(n*255)},${Math.round(s*255)})`}offsetHSL(e,t,n){return this.getHSL(_i),this.setHSL(_i.h+e,_i.s+t,_i.l+n)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,t){return this.r=e.r+t.r,this.g=e.g+t.g,this.b=e.b+t.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,t){return this.r+=(e.r-this.r)*t,this.g+=(e.g-this.g)*t,this.b+=(e.b-this.b)*t,this}lerpColors(e,t,n){return this.r=e.r+(t.r-e.r)*n,this.g=e.g+(t.g-e.g)*n,this.b=e.b+(t.b-e.b)*n,this}lerpHSL(e,t){this.getHSL(_i),e.getHSL(Hr);const n=or(_i.h,Hr.h,t),s=or(_i.s,Hr.s,t),r=or(_i.l,Hr.l,t);return this.setHSL(n,s,r),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){const t=this.r,n=this.g,s=this.b,r=e.elements;return this.r=r[0]*t+r[3]*n+r[6]*s,this.g=r[1]*t+r[4]*n+r[7]*s,this.b=r[2]*t+r[5]*n+r[8]*s,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,t=0){return this.r=e[t],this.g=e[t+1],this.b=e[t+2],this}toArray(e=[],t=0){return e[t]=this.r,e[t+1]=this.g,e[t+2]=this.b,e}fromBufferAttribute(e,t){return this.r=e.getX(t),this.g=e.getY(t),this.b=e.getZ(t),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const Yt=new Te;Te.NAMES=Uu;class Ec{constructor(e,t=1,n=1e3){this.isFog=!0,this.name="",this.color=new Te(e),this.near=t,this.far=n}clone(){return new Ec(this.color,this.near,this.far)}toJSON(){return{type:"Fog",name:this.name,color:this.color.getHex(),near:this.near,far:this.far}}}class to extends Et{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new On,this.environmentIntensity=1,this.environmentRotation=new On,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(e,t){return super.copy(e,t),this.background=e.background!==null?e.background.clone():null,this.environment=e.environment!==null?e.environment.clone():null,this.fog=e.fog!==null?e.fog.clone():null,this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,this.backgroundRotation.copy(e.backgroundRotation),this.environmentIntensity=e.environmentIntensity,this.environmentRotation.copy(e.environmentRotation),this.overrideMaterial=e.overrideMaterial!==null?e.overrideMaterial.clone():null,this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){const t=super.toJSON(e);return this.fog!==null&&(t.object.fog=this.fog.toJSON()),t.object.backgroundBlurriness=this.backgroundBlurriness,t.object.backgroundIntensity=this.backgroundIntensity,t.object.backgroundRotation=this.backgroundRotation.toArray(),t.object.environmentIntensity=this.environmentIntensity,t.object.environmentRotation=this.environmentRotation.toArray(),t}}const An=new P,ei=new P,wo=new P,ti=new P,cs=new P,hs=new P,Rh=new P,Eo=new P,Ao=new P,To=new P,Ro=new vt,Co=new vt,Po=new vt;class _n{constructor(e=new P,t=new P,n=new P){this.a=e,this.b=t,this.c=n}static getNormal(e,t,n,s){s.subVectors(n,t),An.subVectors(e,t),s.cross(An);const r=s.lengthSq();return r>0?s.multiplyScalar(1/Math.sqrt(r)):s.set(0,0,0)}static getBarycoord(e,t,n,s,r){An.subVectors(s,t),ei.subVectors(n,t),wo.subVectors(e,t);const a=An.dot(An),o=An.dot(ei),c=An.dot(wo),l=ei.dot(ei),h=ei.dot(wo),d=a*l-o*o;if(d===0)return r.set(0,0,0),null;const u=1/d,f=(l*c-o*h)*u,g=(a*h-o*c)*u;return r.set(1-f-g,g,f)}static containsPoint(e,t,n,s){return this.getBarycoord(e,t,n,s,ti)===null?!1:ti.x>=0&&ti.y>=0&&ti.x+ti.y<=1}static getInterpolation(e,t,n,s,r,a,o,c){return this.getBarycoord(e,t,n,s,ti)===null?(c.x=0,c.y=0,"z"in c&&(c.z=0),"w"in c&&(c.w=0),null):(c.setScalar(0),c.addScaledVector(r,ti.x),c.addScaledVector(a,ti.y),c.addScaledVector(o,ti.z),c)}static getInterpolatedAttribute(e,t,n,s,r,a){return Ro.setScalar(0),Co.setScalar(0),Po.setScalar(0),Ro.fromBufferAttribute(e,t),Co.fromBufferAttribute(e,n),Po.fromBufferAttribute(e,s),a.setScalar(0),a.addScaledVector(Ro,r.x),a.addScaledVector(Co,r.y),a.addScaledVector(Po,r.z),a}static isFrontFacing(e,t,n,s){return An.subVectors(n,t),ei.subVectors(e,t),An.cross(ei).dot(s)<0}set(e,t,n){return this.a.copy(e),this.b.copy(t),this.c.copy(n),this}setFromPointsAndIndices(e,t,n,s){return this.a.copy(e[t]),this.b.copy(e[n]),this.c.copy(e[s]),this}setFromAttributeAndIndices(e,t,n,s){return this.a.fromBufferAttribute(e,t),this.b.fromBufferAttribute(e,n),this.c.fromBufferAttribute(e,s),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return An.subVectors(this.c,this.b),ei.subVectors(this.a,this.b),An.cross(ei).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(e){return _n.getNormal(this.a,this.b,this.c,e)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(e,t){return _n.getBarycoord(e,this.a,this.b,this.c,t)}getInterpolation(e,t,n,s,r){return _n.getInterpolation(e,this.a,this.b,this.c,t,n,s,r)}containsPoint(e){return _n.containsPoint(e,this.a,this.b,this.c)}isFrontFacing(e){return _n.isFrontFacing(this.a,this.b,this.c,e)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,t){const n=this.a,s=this.b,r=this.c;let a,o;cs.subVectors(s,n),hs.subVectors(r,n),Eo.subVectors(e,n);const c=cs.dot(Eo),l=hs.dot(Eo);if(c<=0&&l<=0)return t.copy(n);Ao.subVectors(e,s);const h=cs.dot(Ao),d=hs.dot(Ao);if(h>=0&&d<=h)return t.copy(s);const u=c*d-h*l;if(u<=0&&c>=0&&h<=0&&c-h>0)return a=c/(c-h),t.copy(n).addScaledVector(cs,a);To.subVectors(e,r);const f=cs.dot(To),g=hs.dot(To);if(g>=0&&f<=g)return t.copy(r);const v=f*l-c*g;if(v<=0&&l>=0&&g<=0)return o=l/(l-g),t.copy(n).addScaledVector(hs,o);const p=h*g-f*d;if(p<=0&&d-h>=0&&f-g>=0)return Rh.subVectors(r,s),o=(d-h)/(d-h+(f-g)),t.copy(s).addScaledVector(Rh,o);const m=1/(p+v+u);return a=v*m,o=u*m,t.copy(n).addScaledVector(cs,a).addScaledVector(hs,o)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}}class Ui{constructor(e=new P(1/0,1/0,1/0),t=new P(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromArray(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t+=3)this.expandByPoint(Tn.fromArray(e,t));return this}setFromBufferAttribute(e){this.makeEmpty();for(let t=0,n=e.count;t<n;t++)this.expandByPoint(Tn.fromBufferAttribute(e,t));return this}setFromPoints(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){const n=Tn.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(n),this.max.copy(e).add(n),this}setFromObject(e,t=!1){return this.makeEmpty(),this.expandByObject(e,t)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,t=!1){e.updateWorldMatrix(!1,!1);const n=e.geometry;if(n!==void 0){const r=n.getAttribute("position");if(t===!0&&r!==void 0&&e.isInstancedMesh!==!0&&e.isBatchedMesh!==!0)for(let a=0,o=r.count;a<o;a++)e.isMesh===!0?e.getVertexPosition(a,Tn):Tn.fromBufferAttribute(r,a),Tn.applyMatrix4(e.matrixWorld),this.expandByPoint(Tn);else e.boundingBox!==void 0?(e.boundingBox===null&&e.computeBoundingBox(),Vr.copy(e.boundingBox)):(n.boundingBox===null&&n.computeBoundingBox(),Vr.copy(n.boundingBox)),Vr.applyMatrix4(e.matrixWorld),this.union(Vr)}const s=e.children;for(let r=0,a=s.length;r<a;r++)this.expandByObject(s[r],t);return this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y&&e.z>=this.min.z&&e.z<=this.max.z}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y&&e.max.z>=this.min.z&&e.min.z<=this.max.z}intersectsSphere(e){return this.clampPoint(e.center,Tn),Tn.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let t,n;return e.normal.x>0?(t=e.normal.x*this.min.x,n=e.normal.x*this.max.x):(t=e.normal.x*this.max.x,n=e.normal.x*this.min.x),e.normal.y>0?(t+=e.normal.y*this.min.y,n+=e.normal.y*this.max.y):(t+=e.normal.y*this.max.y,n+=e.normal.y*this.min.y),e.normal.z>0?(t+=e.normal.z*this.min.z,n+=e.normal.z*this.max.z):(t+=e.normal.z*this.max.z,n+=e.normal.z*this.min.z),t<=-e.constant&&n>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(Gs),Wr.subVectors(this.max,Gs),ds.subVectors(e.a,Gs),us.subVectors(e.b,Gs),fs.subVectors(e.c,Gs),Mi.subVectors(us,ds),Si.subVectors(fs,us),Hi.subVectors(ds,fs);let t=[0,-Mi.z,Mi.y,0,-Si.z,Si.y,0,-Hi.z,Hi.y,Mi.z,0,-Mi.x,Si.z,0,-Si.x,Hi.z,0,-Hi.x,-Mi.y,Mi.x,0,-Si.y,Si.x,0,-Hi.y,Hi.x,0];return!Lo(t,ds,us,fs,Wr)||(t=[1,0,0,0,1,0,0,0,1],!Lo(t,ds,us,fs,Wr))?!1:($r.crossVectors(Mi,Si),t=[$r.x,$r.y,$r.z],Lo(t,ds,us,fs,Wr))}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,Tn).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize(Tn).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()?this:(ni[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),ni[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),ni[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),ni[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),ni[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),ni[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),ni[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),ni[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(ni),this)}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(e){return this.min.fromArray(e.min),this.max.fromArray(e.max),this}}const ni=[new P,new P,new P,new P,new P,new P,new P,new P],Tn=new P,Vr=new Ui,ds=new P,us=new P,fs=new P,Mi=new P,Si=new P,Hi=new P,Gs=new P,Wr=new P,$r=new P,Vi=new P;function Lo(i,e,t,n,s){for(let r=0,a=i.length-3;r<=a;r+=3){Vi.fromArray(i,r);const o=s.x*Math.abs(Vi.x)+s.y*Math.abs(Vi.y)+s.z*Math.abs(Vi.z),c=e.dot(Vi),l=t.dot(Vi),h=n.dot(Vi);if(Math.max(-Math.max(c,l,h),Math.min(c,l,h))>o)return!1}return!0}const St=new P,qr=new fe;let Am=0;class Zt extends ts{constructor(e,t,n=!1){if(super(),Array.isArray(e))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:Am++}),this.name="",this.array=e,this.itemSize=t,this.count=e!==void 0?e.length/t:0,this.normalized=n,this.usage=Lu,this.updateRanges=[],this.gpuType=Dn,this.version=0,this._normalizationScale=e!==void 0?eo(e):void 0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this._normalizationScale=e._normalizationScale,this}copyAt(e,t,n){e*=this.itemSize,n*=t.itemSize;for(let s=0,r=this.itemSize;s<r;s++)this.array[e+s]=t.array[n+s];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let t=0,n=this.count;t<n;t++)qr.fromBufferAttribute(this,t),qr.applyMatrix3(e),this.setXY(t,qr.x,qr.y);else if(this.itemSize===3)for(let t=0,n=this.count;t<n;t++)St.fromBufferAttribute(this,t),St.applyMatrix3(e),this.setXYZ(t,St.x,St.y,St.z);return this}applyMatrix4(e){for(let t=0,n=this.count;t<n;t++)St.fromBufferAttribute(this,t),St.applyMatrix4(e),this.setXYZ(t,St.x,St.y,St.z);return this}applyNormalMatrix(e){for(let t=0,n=this.count;t<n;t++)St.fromBufferAttribute(this,t),St.applyNormalMatrix(e),this.setXYZ(t,St.x,St.y,St.z);return this}transformDirection(e){for(let t=0,n=this.count;t<n;t++)St.fromBufferAttribute(this,t),St.transformDirection(e),this.setXYZ(t,St.x,St.y,St.z);return this}set(e,t=0){return this.array.set(e,t),this}getComponent(e,t){let n=this.array[e*this.itemSize+t];return this.normalized&&(n=this._denormalize(n)),n}setComponent(e,t,n){return this.normalized&&(n=this._normalize(n)),this.array[e*this.itemSize+t]=n,this}getX(e){let t=this.array[e*this.itemSize];return this.normalized&&(t=this._denormalize(t)),t}setX(e,t){return this.normalized&&(t=this._normalize(t)),this.array[e*this.itemSize]=t,this}getY(e){let t=this.array[e*this.itemSize+1];return this.normalized&&(t=this._denormalize(t)),t}setY(e,t){return this.normalized&&(t=this._normalize(t)),this.array[e*this.itemSize+1]=t,this}getZ(e){let t=this.array[e*this.itemSize+2];return this.normalized&&(t=this._denormalize(t)),t}setZ(e,t){return this.normalized&&(t=this._normalize(t)),this.array[e*this.itemSize+2]=t,this}getW(e){let t=this.array[e*this.itemSize+3];return this.normalized&&(t=this._denormalize(t)),t}setW(e,t){return this.normalized&&(t=this._normalize(t)),this.array[e*this.itemSize+3]=t,this}setXY(e,t,n){return e*=this.itemSize,this.normalized&&(t=this._normalize(t),n=this._normalize(n)),this.array[e+0]=t,this.array[e+1]=n,this}setXYZ(e,t,n,s){return e*=this.itemSize,this.normalized&&(t=this._normalize(t),n=this._normalize(n),s=this._normalize(s)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=s,this}setXYZW(e,t,n,s,r){return e*=this.itemSize,this.normalized&&(t=this._normalize(t),n=this._normalize(n),s=this._normalize(s),r=this._normalize(r)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=s,this.array[e+3]=r,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return e.name=this.name,e.usage=this.usage,e.gpuType=this.gpuType,e}dispose(){this.dispatchEvent({type:"dispose"})}_denormalize(e){const t=this._normalizationScale;return t!==void 0?Math.max(e/t,-1):_c(e,this.array)}_normalize(e){const t=this._normalizationScale;return t!==void 0?Math.round(e*t):Mc(e,this.array)}}class Fu extends Zt{constructor(e,t,n){super(new Uint16Array(e),t,n)}}class Ou extends Zt{constructor(e,t,n){super(new Uint32Array(e),t,n)}}class He extends Zt{constructor(e,t,n){super(new Float32Array(e),t,n)}}const Tm=new Ui,Hs=new P,Do=new P;class ns{constructor(e=new P,t=-1){this.isSphere=!0,this.center=e,this.radius=t}set(e,t){return this.center.copy(e),this.radius=t,this}setFromPoints(e,t){const n=this.center;t!==void 0?n.copy(t):Tm.setFromPoints(e).getCenter(n);let s=0;for(let r=0,a=e.length;r<a;r++)s=Math.max(s,n.distanceToSquared(e[r]));return this.radius=Math.sqrt(s),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){const t=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=t*t}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,t){const n=this.center.distanceToSquared(e);return t.copy(e),n>this.radius*this.radius&&(t.sub(this.center).normalize(),t.multiplyScalar(this.radius).add(this.center)),t}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;Hs.subVectors(e,this.center);const t=Hs.lengthSq();if(t>this.radius*this.radius){const n=Math.sqrt(t),s=(n-this.radius)*.5;this.center.addScaledVector(Hs,s/n),this.radius+=s}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(Do.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(Hs.copy(e.center).add(Do)),this.expandByPoint(Hs.copy(e.center).sub(Do))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(e){return this.radius=e.radius,this.center.fromArray(e.center),this}}let Rm=0;const xn=new Ke,Io=new Et,ps=new P,hn=new Ui,Vs=new Ui,Ut=new P;class pt extends ts{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:Rm++}),this.uuid=gi(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.indirectOffset=0,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={},this._transformed=!1}getIndex(){return this.index}setIndex(e){return Array.isArray(e)?this.index=new(Yp(e)?Ou:Fu)(e,1):this.index=e,this}setIndirect(e,t=0){return this.indirect=e,this.indirectOffset=t,this}getIndirect(){return this.indirect}getAttribute(e){return this.attributes[e]}setAttribute(e,t){return this.attributes[e]=t,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,t,n=0){this.groups.push({start:e,count:t,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(e,t){this.drawRange.start=e,this.drawRange.count=t}applyMatrix4(e){const t=this.attributes.position;t!==void 0&&(t.applyMatrix4(e),t.needsUpdate=!0);const n=this.attributes.normal;if(n!==void 0){const r=new Ne().getNormalMatrix(e);n.applyNormalMatrix(r),n.needsUpdate=!0}const s=this.attributes.tangent;return s!==void 0&&(s.transformDirection(e),s.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this._transformed=!0,this}applyQuaternion(e){return xn.makeRotationFromQuaternion(e),this.applyMatrix4(xn),this}rotateX(e){return xn.makeRotationX(e),this.applyMatrix4(xn),this}rotateY(e){return xn.makeRotationY(e),this.applyMatrix4(xn),this}rotateZ(e){return xn.makeRotationZ(e),this.applyMatrix4(xn),this}translate(e,t,n){return xn.makeTranslation(e,t,n),this.applyMatrix4(xn),this}scale(e,t,n){return xn.makeScale(e,t,n),this.applyMatrix4(xn),this}lookAt(e){return Io.lookAt(e),Io.updateMatrix(),this.applyMatrix4(Io.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(ps).negate(),this.translate(ps.x,ps.y,ps.z),this}setFromPoints(e){const t=this.getAttribute("position");if(t===void 0){const n=[];for(let s=0,r=e.length;s<r;s++){const a=e[s];n.push(a.x,a.y,a.z||0)}this.setAttribute("position",new He(n,3))}else{const n=Math.min(e.length,t.count);for(let s=0;s<n;s++){const r=e[s];t.setXYZ(s,r.x,r.y,r.z||0)}e.length>t.count&&Le("BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),t.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new Ui);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){Ze("BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new P(-1/0,-1/0,-1/0),new P(1/0,1/0,1/0));return}if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),t)for(let n=0,s=t.length;n<s;n++){const r=t[n];hn.setFromBufferAttribute(r),this.morphTargetsRelative?(Ut.addVectors(this.boundingBox.min,hn.min),this.boundingBox.expandByPoint(Ut),Ut.addVectors(this.boundingBox.max,hn.max),this.boundingBox.expandByPoint(Ut)):(this.boundingBox.expandByPoint(hn.min),this.boundingBox.expandByPoint(hn.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&Ze('BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new ns);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){Ze("BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new P,1/0);return}if(e){const n=this.boundingSphere.center;if(hn.setFromBufferAttribute(e),t)for(let r=0,a=t.length;r<a;r++){const o=t[r];Vs.setFromBufferAttribute(o),this.morphTargetsRelative?(Ut.addVectors(hn.min,Vs.min),hn.expandByPoint(Ut),Ut.addVectors(hn.max,Vs.max),hn.expandByPoint(Ut)):(hn.expandByPoint(Vs.min),hn.expandByPoint(Vs.max))}hn.getCenter(n);let s=0;for(let r=0,a=e.count;r<a;r++)Ut.fromBufferAttribute(e,r),s=Math.max(s,n.distanceToSquared(Ut));if(t)for(let r=0,a=t.length;r<a;r++){const o=t[r],c=this.morphTargetsRelative;for(let l=0,h=o.count;l<h;l++)Ut.fromBufferAttribute(o,l),c&&(ps.fromBufferAttribute(e,l),Ut.add(ps)),s=Math.max(s,n.distanceToSquared(Ut))}this.boundingSphere.radius=Math.sqrt(s),isNaN(this.boundingSphere.radius)&&Ze('BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const e=this.index,t=this.attributes;if(e===null||t.position===void 0||t.normal===void 0||t.uv===void 0){Ze("BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const n=t.position,s=t.normal,r=t.uv;let a=this.getAttribute("tangent");(a===void 0||a.count!==n.count)&&(a=new Zt(new Float32Array(4*n.count),4),this.setAttribute("tangent",a));const o=[],c=[],l=new Uint8Array(n.count);for(let L=0;L<n.count;L++)o[L]=new P,c[L]=new P;const h=new P,d=new P,u=new P,f=new fe,g=new fe,v=new fe,p=new P,m=new P;function x(L,R,N){l[L]=l[R]=l[N]=1,h.fromBufferAttribute(n,L),d.fromBufferAttribute(n,R),u.fromBufferAttribute(n,N),f.fromBufferAttribute(r,L),g.fromBufferAttribute(r,R),v.fromBufferAttribute(r,N),d.sub(h),u.sub(h),g.sub(f),v.sub(f);const F=1/(g.x*v.y-v.x*g.y);isFinite(F)&&(p.copy(d).multiplyScalar(v.y).addScaledVector(u,-g.y).multiplyScalar(F),m.copy(u).multiplyScalar(g.x).addScaledVector(d,-v.x).multiplyScalar(F),o[L].add(p),o[R].add(p),o[N].add(p),c[L].add(m),c[R].add(m),c[N].add(m))}let S=this.groups;S.length===0&&(S=[{start:0,count:e.count}]);for(let L=0,R=S.length;L<R;++L){const N=S[L],F=N.start,V=N.count;for(let I=F,H=F+V;I<H;I+=3)x(e.getX(I+0),e.getX(I+1),e.getX(I+2))}const b=new P,A=new P,E=new P,y=new P;function w(L){E.fromBufferAttribute(s,L),y.copy(E);const R=o[L];b.copy(R),b.sub(E.multiplyScalar(E.dot(R))).normalize(),A.crossVectors(y,R);const F=A.dot(c[L])<0?-1:1;a.setXYZW(L,b.x,b.y,b.z,F)}for(let L=0,R=n.count;L<R;++L)l[L]&&w(L);this._transformed=!0}computeVertexNormals(){const e=this.index,t=this.getAttribute("position");if(t!==void 0){let n=this.getAttribute("normal");if(n===void 0||n.count!==t.count)n=new Zt(new Float32Array(t.count*3),3),this.setAttribute("normal",n);else for(let u=0,f=n.count;u<f;u++)n.setXYZ(u,0,0,0);const s=new P,r=new P,a=new P,o=new P,c=new P,l=new P,h=new P,d=new P;if(e)for(let u=0,f=e.count;u<f;u+=3){const g=e.getX(u+0),v=e.getX(u+1),p=e.getX(u+2);s.fromBufferAttribute(t,g),r.fromBufferAttribute(t,v),a.fromBufferAttribute(t,p),h.subVectors(a,r),d.subVectors(s,r),h.cross(d),o.fromBufferAttribute(n,g),c.fromBufferAttribute(n,v),l.fromBufferAttribute(n,p),o.add(h),c.add(h),l.add(h),n.setXYZ(g,o.x,o.y,o.z),n.setXYZ(v,c.x,c.y,c.z),n.setXYZ(p,l.x,l.y,l.z)}else for(let u=0,f=t.count;u<f;u+=3)s.fromBufferAttribute(t,u+0),r.fromBufferAttribute(t,u+1),a.fromBufferAttribute(t,u+2),h.subVectors(a,r),d.subVectors(s,r),h.cross(d),n.setXYZ(u+0,h.x,h.y,h.z),n.setXYZ(u+1,h.x,h.y,h.z),n.setXYZ(u+2,h.x,h.y,h.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){const e=this.attributes.normal;for(let t=0,n=e.count;t<n;t++)Ut.fromBufferAttribute(e,t),Ut.normalize(),e.setXYZ(t,Ut.x,Ut.y,Ut.z)}toNonIndexed(){function e(o,c){const l=o.array,h=o.itemSize,d=o.normalized,u=new l.constructor(c.length*h);let f=0,g=0;for(let v=0,p=c.length;v<p;v++){o.isInterleavedBufferAttribute?f=c[v]*o.data.stride+o.offset:f=c[v]*h;for(let m=0;m<h;m++)u[g++]=l[f++]}return new Zt(u,h,d)}if(this.index===null)return Le("BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const t=new pt,n=this.index.array,s=this.attributes;for(const o in s){const c=s[o],l=e(c,n);t.setAttribute(o,l)}const r=this.morphAttributes;for(const o in r){const c=[],l=r[o];for(let h=0,d=l.length;h<d;h++){const u=l[h],f=e(u,n);c.push(f)}t.morphAttributes[o]=c}t.morphTargetsRelative=this.morphTargetsRelative;const a=this.groups;for(let o=0,c=a.length;o<c;o++){const l=a[o];t.addGroup(l.start,l.count,l.materialIndex)}return t}toJSON(){const e={metadata:{version:4.7,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(e.uuid=this.uuid,e.type=this.parameters!==void 0&&this._transformed===!0?"BufferGeometry":this.type,e.name=this.name,Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0&&this._transformed!==!0){const c=this.parameters;for(const l in c)c[l]!==void 0&&(e[l]=c[l]);return e}e.data={attributes:{}};const t=this.index;t!==null&&(e.data.index={type:t.array.constructor.name,array:Array.prototype.slice.call(t.array)});const n=this.attributes;for(const c in n){const l=n[c];e.data.attributes[c]=l.toJSON(e.data)}const s={};let r=!1;for(const c in this.morphAttributes){const l=this.morphAttributes[c],h=[];for(let d=0,u=l.length;d<u;d++){const f=l[d];h.push(f.toJSON(e.data))}h.length>0&&(s[c]=h,r=!0)}r&&(e.data.morphAttributes=s,e.data.morphTargetsRelative=this.morphTargetsRelative);const a=this.groups;a.length>0&&(e.data.groups=JSON.parse(JSON.stringify(a)));const o=this.boundingSphere;return o!==null&&(e.data.boundingSphere=o.toJSON()),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const t={};this.name=e.name;const n=e.index;n!==null&&this.setIndex(n.clone());const s=e.attributes;for(const l in s){const h=s[l];this.setAttribute(l,h.clone(t))}const r=e.morphAttributes;for(const l in r){const h=[],d=r[l];for(let u=0,f=d.length;u<f;u++)h.push(d[u].clone(t));this.morphAttributes[l]=h}this.morphTargetsRelative=e.morphTargetsRelative;const a=e.groups;for(let l=0,h=a.length;l<h;l++){const d=a[l];this.addGroup(d.start,d.count,d.materialIndex)}const o=e.boundingBox;o!==null&&(this.boundingBox=o.clone());const c=e.boundingSphere;return c!==null&&(this.boundingSphere=c.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this._transformed=e._transformed,this}dispose(){this.dispatchEvent({type:"dispose"})}}class Cm{constructor(e,t){this.isInterleavedBuffer=!0,this.array=e,this.stride=t,this.count=e!==void 0?e.length/t:0,this.usage=Lu,this.updateRanges=[],this.version=0,this.uuid=gi()}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.array=new e.array.constructor(e.array),this.count=e.count,this.stride=e.stride,this.usage=e.usage,this}copyAt(e,t,n){e*=this.stride,n*=t.stride;for(let s=0,r=this.stride;s<r;s++)this.array[e+s]=t.array[n+s];return this}set(e,t=0){return this.array.set(e,t),this}clone(e){e.arrayBuffers===void 0&&(e.arrayBuffers={});const t=Ch(this.array);e.arrayBuffers[t]===void 0&&(e.arrayBuffers[t]=this.array.slice(0).buffer);const n=new this.array.constructor(e.arrayBuffers[t]),s=new this.constructor(n,this.stride);return s.setUsage(this.usage),s}onUpload(e){return this.onUploadCallback=e,this}toJSON(e){e.arrayBuffers===void 0&&(e.arrayBuffers={});const t=Ch(this.array);e.arrayBuffers[t]===void 0&&(e.arrayBuffers[t]=Array.from(new Uint32Array(this.array.slice(0).buffer)));const n={uuid:this.uuid,buffer:t,type:this.array.constructor.name,stride:this.stride};return n.usage=this.usage,n}}function Ch(i){return i.buffer._uuid===void 0&&(i.buffer._uuid=gi()),i.byteOffset===0&&i.byteLength===i.buffer.byteLength?i.buffer._uuid:i.buffer._uuid+":"+i.byteOffset+":"+i.byteLength}const jt=new P;class Wa{constructor(e,t,n,s=!1){this.isInterleavedBufferAttribute=!0,this.name="",this.data=e,this.itemSize=t,this.offset=n,this.normalized=s,this._normalizationScale=e!==void 0?eo(e.array):void 0}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(e){this.data.needsUpdate=e}applyMatrix4(e){for(let t=0,n=this.data.count;t<n;t++)jt.fromBufferAttribute(this,t),jt.applyMatrix4(e),this.setXYZ(t,jt.x,jt.y,jt.z);return this}applyNormalMatrix(e){for(let t=0,n=this.count;t<n;t++)jt.fromBufferAttribute(this,t),jt.applyNormalMatrix(e),this.setXYZ(t,jt.x,jt.y,jt.z);return this}transformDirection(e){for(let t=0,n=this.count;t<n;t++)jt.fromBufferAttribute(this,t),jt.transformDirection(e),this.setXYZ(t,jt.x,jt.y,jt.z);return this}getComponent(e,t){let n=this.array[e*this.data.stride+this.offset+t];return this.normalized&&(n=this._denormalize(n)),n}setComponent(e,t,n){return this.normalized&&(n=this._normalize(n)),this.data.array[e*this.data.stride+this.offset+t]=n,this}setX(e,t){return this.normalized&&(t=this._normalize(t)),this.data.array[e*this.data.stride+this.offset]=t,this}setY(e,t){return this.normalized&&(t=this._normalize(t)),this.data.array[e*this.data.stride+this.offset+1]=t,this}setZ(e,t){return this.normalized&&(t=this._normalize(t)),this.data.array[e*this.data.stride+this.offset+2]=t,this}setW(e,t){return this.normalized&&(t=this._normalize(t)),this.data.array[e*this.data.stride+this.offset+3]=t,this}getX(e){let t=this.data.array[e*this.data.stride+this.offset];return this.normalized&&(t=this._denormalize(t)),t}getY(e){let t=this.data.array[e*this.data.stride+this.offset+1];return this.normalized&&(t=this._denormalize(t)),t}getZ(e){let t=this.data.array[e*this.data.stride+this.offset+2];return this.normalized&&(t=this._denormalize(t)),t}getW(e){let t=this.data.array[e*this.data.stride+this.offset+3];return this.normalized&&(t=this._denormalize(t)),t}setXY(e,t,n){return e=e*this.data.stride+this.offset,this.normalized&&(t=this._normalize(t),n=this._normalize(n)),this.data.array[e+0]=t,this.data.array[e+1]=n,this}setXYZ(e,t,n,s){return e=e*this.data.stride+this.offset,this.normalized&&(t=this._normalize(t),n=this._normalize(n),s=this._normalize(s)),this.data.array[e+0]=t,this.data.array[e+1]=n,this.data.array[e+2]=s,this}setXYZW(e,t,n,s,r){return e=e*this.data.stride+this.offset,this.normalized&&(t=this._normalize(t),n=this._normalize(n),s=this._normalize(s),r=this._normalize(r)),this.data.array[e+0]=t,this.data.array[e+1]=n,this.data.array[e+2]=s,this.data.array[e+3]=r,this}clone(e){if(e===void 0){Va("InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");const t=[];for(let n=0;n<this.count;n++){const s=n*this.data.stride+this.offset;for(let r=0;r<this.itemSize;r++)t.push(this.data.array[s+r])}return new Zt(new this.array.constructor(t),this.itemSize,this.normalized)}else return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.clone(e)),new Wa(e.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(e){if(e===void 0){Va("InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");const t=[];for(let n=0;n<this.count;n++){const s=n*this.data.stride+this.offset;for(let r=0;r<this.itemSize;r++)t.push(this.data.array[s+r])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:t,normalized:this.normalized}}else return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.toJSON(e)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}_denormalize(e){const t=this._normalizationScale;return t!==void 0?Math.max(e/t,-1):_c(e,this.data.array)}_normalize(e){const t=this._normalizationScale;return t!==void 0?Math.round(e*t):Mc(e,this.data.array)}}const No=new P,Pm=new P,Lm=new Ne;class oi{constructor(e=new P(1,0,0),t=0){this.isPlane=!0,this.normal=e,this.constant=t}set(e,t){return this.normal.copy(e),this.constant=t,this}setComponents(e,t,n,s){return this.normal.set(e,t,n),this.constant=s,this}setFromNormalAndCoplanarPoint(e,t){return this.normal.copy(e),this.constant=-t.dot(this.normal),this}setFromCoplanarPoints(e,t,n){const s=No.subVectors(n,t).cross(Pm.subVectors(e,t)).normalize();return this.setFromNormalAndCoplanarPoint(s,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){const e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,t){return t.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,t,n=!0){const s=e.delta(No),r=this.normal.dot(s);if(r===0)return this.distanceToPoint(e.start)===0?t.copy(e.start):null;const a=-(e.start.dot(this.normal)+this.constant)/r;return n===!0&&(a<0||a>1)?null:t.copy(e.start).addScaledVector(s,a)}intersectsLine(e){const t=this.distanceToPoint(e.start),n=this.distanceToPoint(e.end);return t<0&&n>0||n<0&&t>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,t){const n=t||Lm.getNormalMatrix(e),s=this.coplanarPoint(No).applyMatrix4(e),r=this.normal.applyMatrix3(n).normalize();return this.constant=-s.dot(r),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}toJSON(){return{normal:this.normal.toArray(),constant:this.constant}}fromJSON(e){return this.normal.fromArray(e.normal),this.constant=e.constant,this}}let Dm=0;class Fi extends ts{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:Dm++}),this.uuid=gi(),this.name="",this.type="Material",this.blending=rr,this.side=Ki,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=uu,this.blendDst=fu,this.blendEquation=Ss,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new Te(0,0,0),this.blendAlpha=0,this.depthFunc=mr,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=Hp,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=go,this.stencilZFail=go,this.stencilZPass=go,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(const t in e){const n=e[t];if(n===void 0){Le(`Material: parameter '${t}' has value of undefined.`);continue}const s=this[t];if(s===void 0){Le(`Material: '${t}' is not a property of THREE.${this.type}.`);continue}s&&s.isColor?s.set(n):s&&s.isVector2&&n&&n.isVector2||s&&s.isEuler&&n&&n.isEuler||s&&s.isVector3&&n&&n.isVector3?s.copy(n):this[t]=n}}toJSON(e){const t=e===void 0||typeof e=="string";t&&(e={textures:{},images:{}});const n={metadata:{version:4.7,type:"Material",generator:"Material.toJSON"}};n.uuid=this.uuid,n.type=this.type,n.blending=this.blending,n.side=this.side,n.shadowSide=this.shadowSide,n.vertexColors=this.vertexColors,n.opacity=this.opacity,n.transparent=this.transparent,n.blendSrc=this.blendSrc,n.blendDst=this.blendDst,n.blendEquation=this.blendEquation,n.blendSrcAlpha=this.blendSrcAlpha,n.blendDstAlpha=this.blendDstAlpha,n.blendEquationAlpha=this.blendEquationAlpha,n.blendColor=this.blendColor.getHex(),n.blendAlpha=this.blendAlpha,n.depthFunc=this.depthFunc,n.depthTest=this.depthTest,n.depthWrite=this.depthWrite,n.colorWrite=this.colorWrite,n.clipIntersection=this.clipIntersection,n.clipShadows=this.clipShadows,n.stencilWriteMask=this.stencilWriteMask,n.stencilFunc=this.stencilFunc,n.stencilRef=this.stencilRef,n.stencilFuncMask=this.stencilFuncMask,n.stencilFail=this.stencilFail,n.stencilZFail=this.stencilZFail,n.stencilZPass=this.stencilZPass,n.stencilWrite=this.stencilWrite,n.polygonOffset=this.polygonOffset,n.polygonOffsetFactor=this.polygonOffsetFactor,n.polygonOffsetUnits=this.polygonOffsetUnits,n.dithering=this.dithering,n.alphaTest=this.alphaTest,n.alphaHash=this.alphaHash,n.alphaToCoverage=this.alphaToCoverage,n.premultipliedAlpha=this.premultipliedAlpha,n.forceSinglePass=this.forceSinglePass,n.allowOverride=this.allowOverride,n.visible=this.visible,n.toneMapped=this.toneMapped,n.name=this.name,this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.diffuseRoughness!==void 0&&(n.diffuseRoughness=this.diffuseRoughness),this.diffuseRoughnessMap&&this.diffuseRoughnessMap.isTexture&&(n.diffuseRoughnessMap=this.diffuseRoughnessMap.toJSON(e).uuid),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.sheenColorMap&&this.sheenColorMap.isTexture&&(n.sheenColorMap=this.sheenColorMap.toJSON(e).uuid),this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture&&(n.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(e).uuid),this.dispersion!==void 0&&(n.dispersion=this.dispersion),this.retroreflectivity!==void 0&&(n.retroreflectivity=this.retroreflectivity),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessMinimum!==void 0&&(n.iridescenceThicknessMinimum=this.iridescenceThicknessMinimum),this.iridescenceThicknessMaximum!==void 0&&(n.iridescenceThicknessMaximum=this.iridescenceThicknessMaximum),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(e).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(e).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(e).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(e).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(e).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapRotation!==void 0&&(n.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),Array.isArray(this.clippingPlanes)&&this.clippingPlanes.length>0&&(n.clippingPlanes=this.clippingPlanes.map(r=>r.toJSON())),this.rotation!==void 0&&(n.rotation=this.rotation),this.depthPacking!==void 0&&(n.depthPacking=this.depthPacking),this.linewidth!==void 0&&(n.linewidth=this.linewidth),this.linecap!==void 0&&(n.linecap=this.linecap),this.linejoin!==void 0&&(n.linejoin=this.linejoin),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.wireframe!==void 0&&(n.wireframe=this.wireframe),this.wireframeLinewidth!==void 0&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!==void 0&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!==void 0&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading!==void 0&&(n.flatShading=this.flatShading),this.fog!==void 0&&(n.fog=this.fog),Object.keys(this.userData).length>0&&(n.userData=this.userData);function s(r){const a=[];for(const o in r){const c=r[o];delete c.metadata,a.push(c)}return a}if(t){const r=s(e.textures),a=s(e.images);r.length>0&&(n.textures=r),a.length>0&&(n.images=a)}return n}fromJSON(e,t){if(e.uuid!==void 0&&(this.uuid=e.uuid),e.name!==void 0&&(this.name=e.name),e.color!==void 0&&this.color!==void 0&&this.color.setHex(e.color),e.roughness!==void 0&&(this.roughness=e.roughness),e.metalness!==void 0&&(this.metalness=e.metalness),e.sheen!==void 0&&(this.sheen=e.sheen),e.sheenColor!==void 0&&(this.sheenColor=new Te().setHex(e.sheenColor)),e.sheenRoughness!==void 0&&(this.sheenRoughness=e.sheenRoughness),e.emissive!==void 0&&this.emissive!==void 0&&this.emissive.setHex(e.emissive),e.specular!==void 0&&this.specular!==void 0&&this.specular.setHex(e.specular),e.specularIntensity!==void 0&&(this.specularIntensity=e.specularIntensity),e.specularColor!==void 0&&this.specularColor!==void 0&&this.specularColor.setHex(e.specularColor),e.shininess!==void 0&&(this.shininess=e.shininess),e.clearcoat!==void 0&&(this.clearcoat=e.clearcoat),e.clearcoatRoughness!==void 0&&(this.clearcoatRoughness=e.clearcoatRoughness),e.diffuseRoughness!==void 0&&(this.diffuseRoughness=e.diffuseRoughness),e.dispersion!==void 0&&(this.dispersion=e.dispersion),e.retroreflectivity!==void 0&&(this.retroreflectivity=e.retroreflectivity),e.iridescence!==void 0&&(this.iridescence=e.iridescence),e.iridescenceIOR!==void 0&&(this.iridescenceIOR=e.iridescenceIOR),e.iridescenceThicknessMinimum!==void 0&&(this.iridescenceThicknessMinimum=e.iridescenceThicknessMinimum),e.iridescenceThicknessMaximum!==void 0&&(this.iridescenceThicknessMaximum=e.iridescenceThicknessMaximum),e.iridescenceThicknessRange!==void 0&&(this.iridescenceThicknessMinimum=e.iridescenceThicknessRange[0],this.iridescenceThicknessMaximum=e.iridescenceThicknessRange[1]),e.transmission!==void 0&&(this.transmission=e.transmission),e.thickness!==void 0&&(this.thickness=e.thickness),e.attenuationDistance!==void 0&&(this.attenuationDistance=e.attenuationDistance),e.attenuationColor!==void 0&&this.attenuationColor!==void 0&&this.attenuationColor.setHex(e.attenuationColor),e.anisotropy!==void 0&&(this.anisotropy=e.anisotropy),e.anisotropyRotation!==void 0&&(this.anisotropyRotation=e.anisotropyRotation),e.fog!==void 0&&(this.fog=e.fog),e.flatShading!==void 0&&(this.flatShading=e.flatShading),e.blending!==void 0&&(this.blending=e.blending),e.combine!==void 0&&(this.combine=e.combine),e.side!==void 0&&(this.side=e.side),e.shadowSide!==void 0&&(this.shadowSide=e.shadowSide),e.opacity!==void 0&&(this.opacity=e.opacity),e.transparent!==void 0&&(this.transparent=e.transparent),e.alphaTest!==void 0&&(this.alphaTest=e.alphaTest),e.alphaHash!==void 0&&(this.alphaHash=e.alphaHash),e.depthFunc!==void 0&&(this.depthFunc=e.depthFunc),e.depthTest!==void 0&&(this.depthTest=e.depthTest),e.depthWrite!==void 0&&(this.depthWrite=e.depthWrite),e.colorWrite!==void 0&&(this.colorWrite=e.colorWrite),e.clippingPlanes!==void 0&&(this.clippingPlanes=e.clippingPlanes.map(n=>new oi().fromJSON(n))),e.clipIntersection!==void 0&&(this.clipIntersection=e.clipIntersection),e.clipShadows!==void 0&&(this.clipShadows=e.clipShadows),e.depthPacking!==void 0&&(this.depthPacking=e.depthPacking),e.blendSrc!==void 0&&(this.blendSrc=e.blendSrc),e.blendDst!==void 0&&(this.blendDst=e.blendDst),e.blendEquation!==void 0&&(this.blendEquation=e.blendEquation),e.blendSrcAlpha!==void 0&&(this.blendSrcAlpha=e.blendSrcAlpha),e.blendDstAlpha!==void 0&&(this.blendDstAlpha=e.blendDstAlpha),e.blendEquationAlpha!==void 0&&(this.blendEquationAlpha=e.blendEquationAlpha),e.blendColor!==void 0&&this.blendColor!==void 0&&this.blendColor.setHex(e.blendColor),e.blendAlpha!==void 0&&(this.blendAlpha=e.blendAlpha),e.stencilWriteMask!==void 0&&(this.stencilWriteMask=e.stencilWriteMask),e.stencilFunc!==void 0&&(this.stencilFunc=e.stencilFunc),e.stencilRef!==void 0&&(this.stencilRef=e.stencilRef),e.stencilFuncMask!==void 0&&(this.stencilFuncMask=e.stencilFuncMask),e.stencilFail!==void 0&&(this.stencilFail=e.stencilFail),e.stencilZFail!==void 0&&(this.stencilZFail=e.stencilZFail),e.stencilZPass!==void 0&&(this.stencilZPass=e.stencilZPass),e.stencilWrite!==void 0&&(this.stencilWrite=e.stencilWrite),e.wireframe!==void 0&&(this.wireframe=e.wireframe),e.wireframeLinewidth!==void 0&&(this.wireframeLinewidth=e.wireframeLinewidth),e.wireframeLinecap!==void 0&&(this.wireframeLinecap=e.wireframeLinecap),e.wireframeLinejoin!==void 0&&(this.wireframeLinejoin=e.wireframeLinejoin),e.rotation!==void 0&&(this.rotation=e.rotation),e.linewidth!==void 0&&(this.linewidth=e.linewidth),e.linecap!==void 0&&(this.linecap=e.linecap),e.linejoin!==void 0&&(this.linejoin=e.linejoin),e.dashSize!==void 0&&(this.dashSize=e.dashSize),e.gapSize!==void 0&&(this.gapSize=e.gapSize),e.scale!==void 0&&(this.scale=e.scale),e.polygonOffset!==void 0&&(this.polygonOffset=e.polygonOffset),e.polygonOffsetFactor!==void 0&&(this.polygonOffsetFactor=e.polygonOffsetFactor),e.polygonOffsetUnits!==void 0&&(this.polygonOffsetUnits=e.polygonOffsetUnits),e.dithering!==void 0&&(this.dithering=e.dithering),e.alphaToCoverage!==void 0&&(this.alphaToCoverage=e.alphaToCoverage),e.premultipliedAlpha!==void 0&&(this.premultipliedAlpha=e.premultipliedAlpha),e.forceSinglePass!==void 0&&(this.forceSinglePass=e.forceSinglePass),e.allowOverride!==void 0&&(this.allowOverride=e.allowOverride),e.visible!==void 0&&(this.visible=e.visible),e.toneMapped!==void 0&&(this.toneMapped=e.toneMapped),e.userData!==void 0&&(this.userData=e.userData),e.vertexColors!==void 0&&(typeof e.vertexColors=="number"?this.vertexColors=e.vertexColors>0:this.vertexColors=e.vertexColors),e.size!==void 0&&(this.size=e.size),e.sizeAttenuation!==void 0&&(this.sizeAttenuation=e.sizeAttenuation),e.map!==void 0&&(this.map=t[e.map]||null),e.matcap!==void 0&&(this.matcap=t[e.matcap]||null),e.alphaMap!==void 0&&(this.alphaMap=t[e.alphaMap]||null),e.bumpMap!==void 0&&(this.bumpMap=t[e.bumpMap]||null),e.bumpScale!==void 0&&(this.bumpScale=e.bumpScale),e.normalMap!==void 0&&(this.normalMap=t[e.normalMap]||null),e.normalMapType!==void 0&&(this.normalMapType=e.normalMapType),e.normalScale!==void 0){let n=e.normalScale;Array.isArray(n)===!1&&(n=[n,n]),this.normalScale=new fe().fromArray(n)}return e.displacementMap!==void 0&&(this.displacementMap=t[e.displacementMap]||null),e.displacementScale!==void 0&&(this.displacementScale=e.displacementScale),e.displacementBias!==void 0&&(this.displacementBias=e.displacementBias),e.roughnessMap!==void 0&&(this.roughnessMap=t[e.roughnessMap]||null),e.metalnessMap!==void 0&&(this.metalnessMap=t[e.metalnessMap]||null),e.emissiveMap!==void 0&&(this.emissiveMap=t[e.emissiveMap]||null),e.emissiveIntensity!==void 0&&(this.emissiveIntensity=e.emissiveIntensity),e.specularMap!==void 0&&(this.specularMap=t[e.specularMap]||null),e.specularIntensityMap!==void 0&&(this.specularIntensityMap=t[e.specularIntensityMap]||null),e.specularColorMap!==void 0&&(this.specularColorMap=t[e.specularColorMap]||null),e.envMap!==void 0&&(this.envMap=t[e.envMap]||null),e.envMapRotation!==void 0&&this.envMapRotation.fromArray(e.envMapRotation),e.envMapIntensity!==void 0&&(this.envMapIntensity=e.envMapIntensity),e.reflectivity!==void 0&&(this.reflectivity=e.reflectivity),e.refractionRatio!==void 0&&(this.refractionRatio=e.refractionRatio),e.lightMap!==void 0&&(this.lightMap=t[e.lightMap]||null),e.lightMapIntensity!==void 0&&(this.lightMapIntensity=e.lightMapIntensity),e.aoMap!==void 0&&(this.aoMap=t[e.aoMap]||null),e.aoMapIntensity!==void 0&&(this.aoMapIntensity=e.aoMapIntensity),e.gradientMap!==void 0&&(this.gradientMap=t[e.gradientMap]||null),e.clearcoatMap!==void 0&&(this.clearcoatMap=t[e.clearcoatMap]||null),e.clearcoatRoughnessMap!==void 0&&(this.clearcoatRoughnessMap=t[e.clearcoatRoughnessMap]||null),e.clearcoatNormalMap!==void 0&&(this.clearcoatNormalMap=t[e.clearcoatNormalMap]||null),e.clearcoatNormalScale!==void 0&&(this.clearcoatNormalScale=new fe().fromArray(e.clearcoatNormalScale)),e.diffuseRoughnessMap!==void 0&&(this.diffuseRoughnessMap=t[e.diffuseRoughnessMap]||null),e.iridescenceMap!==void 0&&(this.iridescenceMap=t[e.iridescenceMap]||null),e.iridescenceThicknessMap!==void 0&&(this.iridescenceThicknessMap=t[e.iridescenceThicknessMap]||null),e.transmissionMap!==void 0&&(this.transmissionMap=t[e.transmissionMap]||null),e.thicknessMap!==void 0&&(this.thicknessMap=t[e.thicknessMap]||null),e.anisotropyMap!==void 0&&(this.anisotropyMap=t[e.anisotropyMap]||null),e.sheenColorMap!==void 0&&(this.sheenColorMap=t[e.sheenColorMap]||null),e.sheenRoughnessMap!==void 0&&(this.sheenRoughnessMap=t[e.sheenRoughnessMap]||null),this}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;const t=e.clippingPlanes;let n=null;if(t!==null){const s=t.length;n=new Array(s);for(let r=0;r!==s;++r)n[r]=t[r].clone()}return this.clippingPlanes=n,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.allowOverride=e.allowOverride,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){e===!0&&this.version++}}class Ac extends Fi{constructor(e){super(),this.isSpriteMaterial=!0,this.type="SpriteMaterial",this.color=new Te(16777215),this.map=null,this.alphaMap=null,this.rotation=0,this.sizeAttenuation=!0,this.transparent=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.rotation=e.rotation,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}}let ms;const Ws=new P,gs=new P,vs=new P,xs=new fe,$s=new fe,ku=new Ke,Xr=new P,qs=new P,Yr=new P,Ph=new fe,Uo=new fe,Lh=new fe;class Bu extends Et{constructor(e=new Ac){if(super(),this.isSprite=!0,this.type="Sprite",ms===void 0){ms=new pt;const t=new Float32Array([-.5,-.5,0,0,0,.5,-.5,0,1,0,.5,.5,0,1,1,-.5,.5,0,0,1]),n=new Cm(t,5);ms.setIndex([0,1,2,0,2,3]),ms.setAttribute("position",new Wa(n,3,0,!1)),ms.setAttribute("uv",new Wa(n,2,3,!1))}this.geometry=ms,this.material=e,this.center=new fe(.5,.5),this.count=1}intersectsFrustum(e){return e.intersectsSprite(this)}raycast(e,t){e.camera===null&&Ze('Sprite: "Raycaster.camera" needs to be set in order to raycast against sprites.'),gs.setFromMatrixScale(this.matrixWorld),ku.copy(e.camera.matrixWorld),this.modelViewMatrix.multiplyMatrices(e.camera.matrixWorldInverse,this.matrixWorld),vs.setFromMatrixPosition(this.modelViewMatrix),e.camera.isPerspectiveCamera&&this.material.sizeAttenuation===!1&&gs.multiplyScalar(-vs.z);const n=this.material.rotation;let s,r;n!==0&&(r=Math.cos(n),s=Math.sin(n));const a=this.center;Kr(Xr.set(-.5,-.5,0),vs,a,gs,s,r),Kr(qs.set(.5,-.5,0),vs,a,gs,s,r),Kr(Yr.set(.5,.5,0),vs,a,gs,s,r),Ph.set(0,0),Uo.set(1,0),Lh.set(1,1);let o=e.ray.intersectTriangle(Xr,qs,Yr,!1,Ws);if(o===null&&(Kr(qs.set(-.5,.5,0),vs,a,gs,s,r),Uo.set(0,1),o=e.ray.intersectTriangle(Xr,Yr,qs,!1,Ws),o===null))return;const c=e.ray.origin.distanceTo(Ws);c<e.near||c>e.far||t.push({distance:c,point:Ws.clone(),uv:_n.getInterpolation(Ws,Xr,qs,Yr,Ph,Uo,Lh,new fe),face:null,object:this})}copy(e,t){return super.copy(e,t),e.center!==void 0&&this.center.copy(e.center),this.material=e.material,this}toJSON(e){const t=super.toJSON(e);return t.object.center=this.center.toArray(),t}}function Kr(i,e,t,n,s,r){xs.subVectors(i,t).addScalar(.5).multiply(n),s!==void 0?($s.x=r*xs.x-s*xs.y,$s.y=s*xs.x+r*xs.y):$s.copy(xs),i.copy(e),i.x+=$s.x,i.y+=$s.y,i.applyMatrix4(ku)}const ii=new P,Fo=new P,Jr=new P,Zr=new P;class no{constructor(e=new P,t=new P(0,0,-1)){this.origin=e,this.direction=t}set(e,t){return this.origin.copy(e),this.direction.copy(t),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,t){return t.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,ii)),this}closestPointToPoint(e,t){t.subVectors(e,this.origin);const n=t.dot(this.direction);return n<0?t.copy(this.origin):t.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){const t=ii.subVectors(e,this.origin).dot(this.direction);return t<0?this.origin.distanceToSquared(e):(ii.copy(this.origin).addScaledVector(this.direction,t),ii.distanceToSquared(e))}distanceSqToSegment(e,t,n,s){Fo.copy(e).add(t).multiplyScalar(.5),Jr.copy(t).sub(e).normalize(),Zr.copy(this.origin).sub(Fo);const r=e.distanceTo(t)*.5,a=-this.direction.dot(Jr),o=Zr.dot(this.direction),c=-Zr.dot(Jr),l=Zr.lengthSq(),h=Math.abs(1-a*a);let d,u,f,g;if(h>0)if(d=a*c-o,u=a*o-c,g=r*h,d>=0)if(u>=-g)if(u<=g){const v=1/h;d*=v,u*=v,f=d*(d+a*u+2*o)+u*(a*d+u+2*c)+l}else u=r,d=Math.max(0,-(a*u+o)),f=-d*d+u*(u+2*c)+l;else u=-r,d=Math.max(0,-(a*u+o)),f=-d*d+u*(u+2*c)+l;else u<=-g?(d=Math.max(0,-(-a*r+o)),u=d>0?-r:Math.min(Math.max(-r,-c),r),f=-d*d+u*(u+2*c)+l):u<=g?(d=0,u=Math.min(Math.max(-r,-c),r),f=u*(u+2*c)+l):(d=Math.max(0,-(a*r+o)),u=d>0?r:Math.min(Math.max(-r,-c),r),f=-d*d+u*(u+2*c)+l);else u=a>0?-r:r,d=Math.max(0,-(a*u+o)),f=-d*d+u*(u+2*c)+l;return n&&n.copy(this.origin).addScaledVector(this.direction,d),s&&s.copy(Fo).addScaledVector(Jr,u),f}intersectSphere(e,t){if(e.radius<0)return null;ii.subVectors(e.center,this.origin);const n=ii.dot(this.direction),s=ii.dot(ii)-n*n,r=e.radius*e.radius;if(s>r)return null;const a=Math.sqrt(r-s),o=n-a,c=n+a;return c<0?null:o<0?this.at(c,t):this.at(o,t)}intersectsSphere(e){return e.radius<0?!1:this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){const t=e.normal.dot(this.direction);if(t===0)return e.distanceToPoint(this.origin)===0?0:null;const n=-(this.origin.dot(e.normal)+e.constant)/t;return n>=0?n:null}intersectPlane(e,t){const n=this.distanceToPlane(e);return n===null?null:this.at(n,t)}intersectsPlane(e){const t=e.distanceToPoint(this.origin);return t===0||e.normal.dot(this.direction)*t<0}intersectBox(e,t){let n,s,r,a,o,c;const l=1/this.direction.x,h=1/this.direction.y,d=1/this.direction.z,u=this.origin;return l>=0?(n=(e.min.x-u.x)*l,s=(e.max.x-u.x)*l):(n=(e.max.x-u.x)*l,s=(e.min.x-u.x)*l),h>=0?(r=(e.min.y-u.y)*h,a=(e.max.y-u.y)*h):(r=(e.max.y-u.y)*h,a=(e.min.y-u.y)*h),n>a||r>s||((r>n||isNaN(n))&&(n=r),(a<s||isNaN(s))&&(s=a),d>=0?(o=(e.min.z-u.z)*d,c=(e.max.z-u.z)*d):(o=(e.max.z-u.z)*d,c=(e.min.z-u.z)*d),n>c||o>s)||((o>n||n!==n)&&(n=o),(c<s||s!==s)&&(s=c),s<0)?null:this.at(n>=0?n:s,t)}intersectsBox(e){return this.intersectBox(e,ii)!==null}intersectTriangle(e,t,n,s,r){const a=this.origin,o=this.direction,c=o.x,l=o.y,h=o.z,d=e.x-a.x,u=e.y-a.y,f=e.z-a.z,g=t.x-a.x,v=t.y-a.y,p=t.z-a.z,m=n.x-a.x,x=n.y-a.y,S=n.z-a.z,b=Math.abs(c),A=Math.abs(l),E=Math.abs(h);let y,w,L,R,N,F,V,I,H,J,z,ne;if(b>=A&&b>=E?(L=c,F=d,H=g,ne=m,c>=0?(y=l,w=h,R=u,N=f,V=v,I=p,J=x,z=S):(y=h,w=l,R=f,N=u,V=p,I=v,J=S,z=x)):A>=E?(L=l,F=u,H=v,ne=x,l>=0?(y=h,w=c,R=f,N=d,V=p,I=g,J=S,z=m):(y=c,w=h,R=d,N=f,V=g,I=p,J=m,z=S)):(L=h,F=f,H=p,ne=S,h>=0?(y=c,w=l,R=d,N=u,V=g,I=v,J=m,z=x):(y=l,w=c,R=u,N=d,V=v,I=g,J=x,z=m)),L===0)return null;const $=y/L,j=w/L,ee=1/L,we=R-$*F,Ue=N-j*F,Y=V-$*H,ve=I-j*H,_e=J-$*ne,Ce=z-j*ne,xe=_e*ve-Ce*Y,Oe=we*Ce-Ue*_e,_t=Y*Ue-ve*we;if(s){if(xe<0||Oe<0||_t<0)return null}else if((xe<0||Oe<0||_t<0)&&(xe>0||Oe>0||_t>0))return null;const De=xe+Oe+_t;if(De===0)return null;const nt=ee*(xe*F+Oe*H+_t*ne);return(De>0?nt<0:nt>0)?null:this.at(nt/De,r)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class Ht extends Fi{constructor(e){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new Te(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new On,this.combine=pu,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}}const Dh=new Ke,Wi=new no,Qr=new ns,Ih=new P,jr=new P,ea=new P,ta=new P,Oo=new P,na=new P,Nh=new P,ia=new P;class je extends Et{constructor(e=new pt,t=new Ht){super(),this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0?this.morphTargetInfluences=e.morphTargetInfluences.slice():this.morphTargetInfluences=void 0,e.morphTargetDictionary!==void 0?this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary):this.morphTargetDictionary=void 0,this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){const t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){const s=t[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,a=s.length;r<a;r++){const o=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=r}}}}getVertexPosition(e,t){const n=this.geometry,s=n.attributes.position,r=n.morphAttributes.position,a=n.morphTargetsRelative;t.fromBufferAttribute(s,e);const o=this.morphTargetInfluences;if(r&&o){na.set(0,0,0);for(let c=0,l=r.length;c<l;c++){const h=o[c],d=r[c];h!==0&&(Oo.fromBufferAttribute(d,e),a?na.addScaledVector(Oo,h):na.addScaledVector(Oo.sub(t),h))}t.add(na)}return t}intersectsFrustum(e){return e.intersectsObject(this)}raycast(e,t){const n=this.geometry,s=this.material,r=this.matrixWorld;s!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),Qr.copy(n.boundingSphere),Qr.applyMatrix4(r),Wi.copy(e.ray).recast(e.near),!(Qr.containsPoint(Wi.origin)===!1&&(Wi.intersectSphere(Qr,Ih)===null||Wi.origin.distanceToSquared(Ih)>(e.far-e.near)**2))&&(Dh.copy(r).invert(),Wi.copy(e.ray).applyMatrix4(Dh),!(n.boundingBox!==null&&Wi.intersectsBox(n.boundingBox)===!1)&&this._computeIntersections(e,t,Wi)))}_computeIntersections(e,t,n){let s;const r=this.geometry,a=this.material,o=r.index,c=r.attributes.position,l=r.attributes.uv,h=r.attributes.uv1,d=r.attributes.normal,u=r.groups,f=r.drawRange;if(o!==null)if(Array.isArray(a))for(let g=0,v=u.length;g<v;g++){const p=u[g],m=a[p.materialIndex],x=Math.max(p.start,f.start),S=Math.min(o.count,Math.min(p.start+p.count,f.start+f.count));for(let b=x,A=S;b<A;b+=3){const E=o.getX(b),y=o.getX(b+1),w=o.getX(b+2);s=sa(this,m,e,n,l,h,d,E,y,w),s&&(s.faceIndex=Math.floor(b/3),s.face.materialIndex=p.materialIndex,t.push(s))}}else{const g=Math.max(0,f.start),v=Math.min(o.count,f.start+f.count);for(let p=g,m=v;p<m;p+=3){const x=o.getX(p),S=o.getX(p+1),b=o.getX(p+2);s=sa(this,a,e,n,l,h,d,x,S,b),s&&(s.faceIndex=Math.floor(p/3),t.push(s))}}else if(c!==void 0)if(Array.isArray(a))for(let g=0,v=u.length;g<v;g++){const p=u[g],m=a[p.materialIndex],x=Math.max(p.start,f.start),S=Math.min(c.count,Math.min(p.start+p.count,f.start+f.count));for(let b=x,A=S;b<A;b+=3){const E=b,y=b+1,w=b+2;s=sa(this,m,e,n,l,h,d,E,y,w),s&&(s.faceIndex=Math.floor(b/3),s.face.materialIndex=p.materialIndex,t.push(s))}}else{const g=Math.max(0,f.start),v=Math.min(c.count,f.start+f.count);for(let p=g,m=v;p<m;p+=3){const x=p,S=p+1,b=p+2;s=sa(this,a,e,n,l,h,d,x,S,b),s&&(s.faceIndex=Math.floor(p/3),t.push(s))}}}}function Im(i,e,t,n,s,r,a,o){let c;if(e.side===Gt?c=n.intersectTriangle(a,r,s,!0,o):c=n.intersectTriangle(s,r,a,e.side===Ki,o),c===null)return null;ia.copy(o),ia.applyMatrix4(i.matrixWorld);const l=t.ray.origin.distanceTo(ia);return l<t.near||l>t.far?null:{distance:l,point:ia.clone(),object:i}}function sa(i,e,t,n,s,r,a,o,c,l){i.getVertexPosition(o,jr),i.getVertexPosition(c,ea),i.getVertexPosition(l,ta);const h=Im(i,e,t,n,jr,ea,ta,Nh);if(h){const d=new P;_n.getBarycoord(Nh,jr,ea,ta,d),s&&(h.uv=_n.getInterpolatedAttribute(s,o,c,l,d,new fe)),r&&(h.uv1=_n.getInterpolatedAttribute(r,o,c,l,d,new fe)),a&&(h.normal=_n.getInterpolatedAttribute(a,o,c,l,d,new P),h.normal.dot(n.direction)>0&&h.normal.multiplyScalar(-1));const u={a:o,b:c,c:l,normal:new P,materialIndex:0};_n.getNormal(jr,ea,ta,u.normal),h.face=u,h.barycoord=d}return h}class zu extends Jt{constructor(e=null,t=1,n=1,s,r,a,o,c,l=zt,h=zt,d,u){super(null,a,o,c,l,h,s,r,d,u),this.isDataTexture=!0,this.image={data:e,width:t,height:n},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class Uh extends Zt{constructor(e,t,n,s=1){super(e,t,n),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=s}copy(e){return super.copy(e),this.meshPerAttribute=e.meshPerAttribute,this}toJSON(){const e=super.toJSON();return e.meshPerAttribute=this.meshPerAttribute,e.isInstancedBufferAttribute=!0,e}}const ys=new Ke,Fh=new Ke,ra=[],Oh=new Ui,Nm=new Ke,Xs=new je,Ys=new ns;class Ol extends je{constructor(e,t,n){super(e,t),this.isInstancedMesh=!0,this.instanceMatrix=new Uh(new Float32Array(n*16),16),this.instanceColor=null,this.morphTexture=null,this.count=n,this.boundingBox=null,this.boundingSphere=null;for(let s=0;s<n;s++)this.setMatrixAt(s,Nm)}computeBoundingBox(){const e=this.geometry,t=this.count;this.boundingBox===null&&(this.boundingBox=new Ui),e.boundingBox===null&&e.computeBoundingBox(),this.boundingBox.makeEmpty();for(let n=0;n<t;n++)this.getMatrixAt(n,ys),Oh.copy(e.boundingBox).applyMatrix4(ys),this.boundingBox.union(Oh)}computeBoundingSphere(){const e=this.geometry,t=this.count;this.boundingSphere===null&&(this.boundingSphere=new ns),e.boundingSphere===null&&e.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let n=0;n<t;n++)this.getMatrixAt(n,ys),Ys.copy(e.boundingSphere).applyMatrix4(ys),this.boundingSphere.union(Ys)}copy(e,t){return super.copy(e,t),this.instanceMatrix.copy(e.instanceMatrix),this.morphTexture=e.morphTexture!==null?e.morphTexture.clone():null,this.instanceColor=e.instanceColor!==null?e.instanceColor.clone():null,this.count=e.count,this.boundingBox=e.boundingBox!==null?e.boundingBox.clone():null,this.boundingSphere=e.boundingSphere!==null?e.boundingSphere.clone():null,this}getColorAt(e,t){return this.instanceColor===null?t.setRGB(1,1,1):t.fromArray(this.instanceColor.array,e*3)}getMatrixAt(e,t){return t.fromArray(this.instanceMatrix.array,e*16)}getMorphAt(e,t){const n=t.morphTargetInfluences,s=this.morphTexture.source.data.data,r=n.length+1,a=e*r+1;for(let o=0;o<n.length;o++)n[o]=s[a+o]}raycast(e,t){const n=this.matrixWorld,s=this.count;if(Xs.geometry=this.geometry,Xs.material=this.material,Xs.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),Ys.copy(this.boundingSphere),Ys.applyMatrix4(n),e.ray.intersectsSphere(Ys)!==!1))for(let r=0;r<s;r++){this.getMatrixAt(r,ys),Fh.multiplyMatrices(n,ys),Xs.matrixWorld=Fh,Xs.raycast(e,ra);for(let a=0,o=ra.length;a<o;a++){const c=ra[a];c.instanceId=r,c.object=this,t.push(c)}ra.length=0}}setColorAt(e,t){return this.instanceColor===null&&(this.instanceColor=new Uh(new Float32Array(this.instanceMatrix.count*3).fill(1),3)),t.toArray(this.instanceColor.array,e*3),this}setMatrixAt(e,t){return t.toArray(this.instanceMatrix.array,e*16),this}setMorphAt(e,t){const n=t.morphTargetInfluences,s=n.length+1;this.morphTexture===null&&(this.morphTexture=new zu(new Float32Array(s*this.count),s,this.count,gc,Dn));const r=this.morphTexture.source.data.data;let a=0;for(let l=0;l<n.length;l++)a+=n[l];const o=this.geometry.morphTargetsRelative?1:1-a,c=s*e;return r[c]=o,r.set(n,c+1),this}updateMorphTargets(){}dispose(){super.dispose(),this.instanceMatrix.dispose(),this.instanceColor!==null&&this.instanceColor.dispose(),this.morphTexture!==null&&(this.morphTexture.dispose(),this.morphTexture=null)}}const $i=new ns,Um=new fe(.5,.5),aa=new P;class br{constructor(e=new oi,t=new oi,n=new oi,s=new oi,r=new oi,a=new oi){this.planes=[e,t,n,s,r,a]}set(e,t,n,s,r,a){const o=this.planes;return o[0].copy(e),o[1].copy(t),o[2].copy(n),o[3].copy(s),o[4].copy(r),o[5].copy(a),this}copy(e){const t=this.planes;for(let n=0;n<6;n++)t[n].copy(e.planes[n]);return this}setFromProjectionMatrix(e,t=In,n=!1){const s=this.planes,r=e.elements,a=r[0],o=r[1],c=r[2],l=r[3],h=r[4],d=r[5],u=r[6],f=r[7],g=r[8],v=r[9],p=r[10],m=r[11],x=r[12],S=r[13],b=r[14],A=r[15];if(s[0].setComponents(l-a,f-h,m-g,A-x).normalize(),s[1].setComponents(l+a,f+h,m+g,A+x).normalize(),s[2].setComponents(l+o,f+d,m+v,A+S).normalize(),s[3].setComponents(l-o,f-d,m-v,A-S).normalize(),n)s[4].setComponents(c,u,p,b).normalize(),s[5].setComponents(l-c,f-u,m-p,A-b).normalize();else if(s[4].setComponents(l-c,f-u,m-p,A-b).normalize(),t===In)s[5].setComponents(l+c,f+u,m+p,A+b).normalize();else if(t===xr)s[5].setComponents(c,u,p,b).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+t);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),$i.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{const t=e.geometry;t.boundingSphere===null&&t.computeBoundingSphere(),$i.copy(t.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere($i)}intersectsSprite(e){$i.center.set(0,0,0);const t=Um.distanceTo(e.center);return $i.radius=.7071067811865476+t,$i.applyMatrix4(e.matrixWorld),this.intersectsSphere($i)}intersectsSphere(e){const t=this.planes,n=e.center,s=-e.radius;for(let r=0;r<6;r++)if(t[r].distanceToPoint(n)<s)return!1;return!0}intersectsBox(e){const t=this.planes;for(let n=0;n<6;n++){const s=t[n];if(aa.x=s.normal.x>0?e.max.x:e.min.x,aa.y=s.normal.y>0?e.max.y:e.min.y,aa.z=s.normal.z>0?e.max.z:e.min.z,s.distanceToPoint(aa)<0)return!1}return!0}containsPoint(e){const t=this.planes;for(let n=0;n<6;n++)if(t[n].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}const kh=new Ke;class Tc{constructor(){this.coordinateSystem=In,this._frustums=[],this._count=0}setFromArrayCamera(e){const t=e.cameras,n=this._frustums;for(let s=0;s<t.length;s++){const r=t[s];kh.multiplyMatrices(r.projectionMatrix,r.matrixWorldInverse),n[s]===void 0&&(n[s]=new br),n[s].setFromProjectionMatrix(kh,r.coordinateSystem,r.reversedDepth)}return this._count=t.length,this}getFrustum(e){return this._frustums[e]}intersectsObject(e){const t=this._frustums;for(let n=0;n<this._count;n++)if(t[n].intersectsObject(e))return!0;return!1}intersectsSprite(e){const t=this._frustums;for(let n=0;n<this._count;n++)if(t[n].intersectsSprite(e))return!0;return!1}intersectsSphere(e){const t=this._frustums;for(let n=0;n<this._count;n++)if(t[n].intersectsSphere(e))return!0;return!1}intersectsBox(e){const t=this._frustums;for(let n=0;n<this._count;n++)if(t[n].intersectsBox(e))return!0;return!1}containsPoint(e){const t=this._frustums;for(let n=0;n<this._count;n++)if(t[n].containsPoint(e))return!0;return!1}copy(e){this.coordinateSystem=e.coordinateSystem;const t=this._frustums,n=e._frustums;for(let s=0;s<e._count;s++)t[s]===void 0&&(t[s]=new br),t[s].copy(n[s]);return this._count=e._count,this}clone(){return new Tc().copy(this)}}class Gu extends Fi{constructor(e){super(),this.isLineBasicMaterial=!0,this.type="LineBasicMaterial",this.color=new Te(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.linewidth=e.linewidth,this.linecap=e.linecap,this.linejoin=e.linejoin,this.fog=e.fog,this}}const $a=new P,qa=new P,Bh=new Ke,Ks=new no,oa=new ns,ko=new P,zh=new P;class Fm extends Et{constructor(e=new pt,t=new Gu){super(),this.isLine=!0,this.type="Line",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0?this.morphTargetInfluences=e.morphTargetInfluences.slice():this.morphTargetInfluences=void 0,e.morphTargetDictionary!==void 0?this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary):this.morphTargetDictionary=void 0,this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}computeLineDistances(){const e=this.geometry;if(e.index===null){const t=e.attributes.position,n=[0];for(let s=1,r=t.count;s<r;s++)$a.fromBufferAttribute(t,s-1),qa.fromBufferAttribute(t,s),n[s]=n[s-1],n[s]+=$a.distanceTo(qa);e.setAttribute("lineDistance",new He(n,1))}else Le("Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}intersectsFrustum(e){return e.intersectsObject(this)}raycast(e,t){const n=this.geometry,s=this.matrixWorld,r=e.params.Line.threshold,a=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),oa.copy(n.boundingSphere),oa.applyMatrix4(s),oa.radius+=r,e.ray.intersectsSphere(oa)===!1)return;Bh.copy(s).invert(),Ks.copy(e.ray).applyMatrix4(Bh);const o=r/((this.scale.x+this.scale.y+this.scale.z)/3),c=o*o,l=this.isLineSegments?2:1,h=n.index,u=n.attributes.position;if(h!==null){const f=Math.max(0,a.start),g=Math.min(h.count,a.start+a.count);for(let v=f,p=g-1;v<p;v+=l){const m=h.getX(v),x=h.getX(v+1),S=la(this,e,Ks,c,m,x,v);S&&t.push(S)}if(this.isLineLoop){const v=h.getX(g-1),p=h.getX(f),m=la(this,e,Ks,c,v,p,g-1);m&&t.push(m)}}else{const f=Math.max(0,a.start),g=Math.min(u.count,a.start+a.count);for(let v=f,p=g-1;v<p;v+=l){const m=la(this,e,Ks,c,v,v+1,v);m&&t.push(m)}if(this.isLineLoop){const v=la(this,e,Ks,c,g-1,f,g-1);v&&t.push(v)}}}updateMorphTargets(){const t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){const s=t[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,a=s.length;r<a;r++){const o=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=r}}}}}function la(i,e,t,n,s,r,a){const o=i.geometry.attributes.position;if($a.fromBufferAttribute(o,s),qa.fromBufferAttribute(o,r),t.distanceSqToSegment($a,qa,ko,zh)>n)return;ko.applyMatrix4(i.matrixWorld);const l=e.ray.origin.distanceTo(ko);if(!(l<e.near||l>e.far))return{distance:l,point:zh.clone().applyMatrix4(i.matrixWorld),index:a,face:null,faceIndex:null,barycoord:null,object:i}}const Gh=new P,Hh=new P;class Om extends Fm{constructor(e,t){super(e,t),this.isLineSegments=!0,this.type="LineSegments"}computeLineDistances(){const e=this.geometry;if(e.index===null){const t=e.attributes.position,n=[];for(let s=0,r=t.count;s<r;s+=2)Gh.fromBufferAttribute(t,s),Hh.fromBufferAttribute(t,s+1),n[s]=s===0?0:n[s-1],n[s+1]=n[s]+Gh.distanceTo(Hh);e.setAttribute("lineDistance",new He(n,1))}else Le("LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}}class Xa extends Fi{constructor(e){super(),this.isPointsMaterial=!0,this.type="PointsMaterial",this.color=new Te(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.size=e.size,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}}const Vh=new Ke,kl=new no,ca=new ns,ha=new P;class Bl extends Et{constructor(e=new pt,t=new Xa){super(),this.isPoints=!0,this.type="Points",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0?this.morphTargetInfluences=e.morphTargetInfluences.slice():this.morphTargetInfluences=void 0,e.morphTargetDictionary!==void 0?this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary):this.morphTargetDictionary=void 0,this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}intersectsFrustum(e){return e.intersectsObject(this)}raycast(e,t){const n=this.geometry,s=this.matrixWorld,r=e.params.Points.threshold,a=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),ca.copy(n.boundingSphere),ca.applyMatrix4(s),ca.radius+=r,e.ray.intersectsSphere(ca)===!1)return;Vh.copy(s).invert(),kl.copy(e.ray).applyMatrix4(Vh);const o=r/((this.scale.x+this.scale.y+this.scale.z)/3),c=o*o,l=n.index,d=n.attributes.position;if(l!==null){const u=Math.max(0,a.start),f=Math.min(l.count,a.start+a.count);for(let g=u,v=f;g<v;g++){const p=l.getX(g);ha.fromBufferAttribute(d,p),Wh(ha,p,c,s,e,t,this)}}else{const u=Math.max(0,a.start),f=Math.min(d.count,a.start+a.count);for(let g=u,v=f;g<v;g++)ha.fromBufferAttribute(d,g),Wh(ha,g,c,s,e,t,this)}}updateMorphTargets(){const t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){const s=t[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,a=s.length;r<a;r++){const o=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=r}}}}}function Wh(i,e,t,n,s,r,a){const o=kl.distanceSqToPoint(i);if(o<t){const c=new P;kl.closestPointToPoint(i,c),c.applyMatrix4(n);const l=s.ray.origin.distanceTo(c);if(l<s.near||l>s.far)return;r.push({distance:l,distanceToRay:Math.sqrt(o),point:c,index:e,face:null,faceIndex:null,barycoord:null,object:a})}}class Hu extends Jt{constructor(e=[],t=Ls,n,s,r,a,o,c,l,h){super(e,t,n,s,r,a,o,c,l,h),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}}class io extends Jt{constructor(e,t,n,s,r,a,o,c,l){super(e,t,n,s,r,a,o,c,l),this.isCanvasTexture=!0,this.needsUpdate=!0}}class Is extends Jt{constructor(e,t,n=Kn,s,r,a,o=zt,c=zt,l,h=Pi,d=1){if(h!==Pi&&h!==Ti)throw new Error("THREE.DepthTexture: format must be either THREE.DepthFormat or THREE.DepthStencilFormat");const u={width:e,height:t,depth:d};super(u,s,r,a,o,c,h,n,l),this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.source=new Sc(Object.assign({},e.image)),this.compareFunction=e.compareFunction,this}toJSON(e){const t=super.toJSON(e);return t.compareFunction=this.compareFunction,t}}class Vu extends Is{constructor(e,t=Kn,n=Ls,s,r,a=zt,o=zt,c,l=Pi){const h={width:e,height:e,depth:1},d=[h,h,h,h,h,h];super(e,e,t,n,s,r,a,o,c,l),this.image=d,this.isCubeDepthTexture=!0,this.isCubeTexture=!0}get images(){return this.image}set images(e){this.image=e}}class Wu extends Jt{constructor(e=null){super(),this.sourceTexture=e,this.isExternalTexture=!0}copy(e){return super.copy(e),this.sourceTexture=e.sourceTexture,this}}class is extends pt{constructor(e=1,t=1,n=1,s=1,r=1,a=1){super(),this.type="BoxGeometry",this.parameters={width:e,height:t,depth:n,widthSegments:s,heightSegments:r,depthSegments:a};const o=this;s=Math.floor(s),r=Math.floor(r),a=Math.floor(a);const c=[],l=[],h=[],d=[];let u=0,f=0;g("z","y","x",-1,-1,n,t,e,a,r,0),g("z","y","x",1,-1,n,t,-e,a,r,1),g("x","z","y",1,1,e,n,t,s,a,2),g("x","z","y",1,-1,e,n,-t,s,a,3),g("x","y","z",1,-1,e,t,n,s,r,4),g("x","y","z",-1,-1,e,t,-n,s,r,5),this.setIndex(c),this.setAttribute("position",new He(l,3)),this.setAttribute("normal",new He(h,3)),this.setAttribute("uv",new He(d,2));function g(v,p,m,x,S,b,A,E,y,w,L){const R=b/y,N=A/w,F=b/2,V=A/2,I=E/2,H=y+1,J=w+1;let z=0,ne=0;const $=new P;for(let j=0;j<J;j++){const ee=j*N-V;for(let we=0;we<H;we++){const Ue=we*R-F;$[v]=Ue*x,$[p]=ee*S,$[m]=I,l.push($.x,$.y,$.z),$[v]=0,$[p]=0,$[m]=E>0?1:-1,h.push($.x,$.y,$.z),d.push(we/y),d.push(1-j/w),z+=1}}for(let j=0;j<w;j++)for(let ee=0;ee<y;ee++){const we=u+ee+H*j,Ue=u+ee+H*(j+1),Y=u+(ee+1)+H*(j+1),ve=u+(ee+1)+H*j;c.push(we,Ue,ve),c.push(Ue,Y,ve),ne+=6}o.addGroup(f,ne,L),f+=ne,u+=z}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new is(e.width,e.height,e.depth,e.widthSegments,e.heightSegments,e.depthSegments)}}class Rc extends pt{constructor(e=1,t=1,n=4,s=8,r=1){super(),this.type="CapsuleGeometry",this.parameters={radius:e,height:t,capSegments:n,radialSegments:s,heightSegments:r},t=Math.max(0,t),n=Math.max(1,Math.floor(n)),s=Math.max(3,Math.floor(s)),r=Math.max(1,Math.floor(r));const a=[],o=[],c=[],l=[],h=t/2,d=Math.PI/2*e,u=t,f=2*d+u,g=n*2+r,v=s+1,p=new P,m=new P;for(let x=0;x<=g;x++){let S=0,b=0,A=0,E=0;if(x<=n){const L=x/n,R=L*Math.PI/2;b=-h-e*Math.cos(R),A=e*Math.sin(R),E=-e*Math.cos(R),S=L*d}else if(x<=n+r){const L=(x-n)/r;b=-h+L*t,A=e,E=0,S=d+L*u}else{const L=(x-n-r)/n,R=L*Math.PI/2;b=h+e*Math.sin(R),A=e*Math.cos(R),E=e*Math.sin(R),S=d+u+L*d}const y=Math.max(0,Math.min(1,S/f));let w=0;x===0?w=.5/s:x===g&&(w=-.5/s);for(let L=0;L<=s;L++){const R=L/s,N=R*Math.PI*2,F=Math.sin(N),V=Math.cos(N);m.x=-A*V,m.y=b,m.z=A*F,o.push(m.x,m.y,m.z),p.set(-A*V,E,A*F),p.normalize(),c.push(p.x,p.y,p.z),l.push(R+w,y)}if(x>0){const L=(x-1)*v;for(let R=0;R<s;R++){const N=L+R,F=L+R+1,V=x*v+R,I=x*v+R+1;a.push(N,F,V),a.push(F,I,V)}}}this.setIndex(a),this.setAttribute("position",new He(o,3)),this.setAttribute("normal",new He(c,3)),this.setAttribute("uv",new He(l,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Rc(e.radius,e.height,e.capSegments,e.radialSegments,e.heightSegments)}}class Cc extends pt{constructor(e=1,t=32,n=0,s=Math.PI*2){super(),this.type="CircleGeometry",this.parameters={radius:e,segments:t,thetaStart:n,thetaLength:s},t=Math.max(3,t);const r=[],a=[],o=[],c=[],l=new P,h=new fe;a.push(0,0,0),o.push(0,0,1),c.push(.5,.5);for(let d=0,u=3;d<=t;d++,u+=3){const f=n+d/t*s;l.x=e*Math.cos(f),l.y=e*Math.sin(f),a.push(l.x,l.y,l.z),o.push(0,0,1),h.x=(a[u]/e+1)/2,h.y=(a[u+1]/e+1)/2,c.push(h.x,h.y)}for(let d=1;d<=t;d++)r.push(d,d+1,0);this.setIndex(r),this.setAttribute("position",new He(a,3)),this.setAttribute("normal",new He(o,3)),this.setAttribute("uv",new He(c,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Cc(e.radius,e.segments,e.thetaStart,e.thetaLength)}}class fi extends pt{constructor(e=1,t=1,n=1,s=32,r=1,a=!1,o=0,c=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:e,radiusBottom:t,height:n,radialSegments:s,heightSegments:r,openEnded:a,thetaStart:o,thetaLength:c};const l=this;s=Math.floor(s),r=Math.floor(r);const h=[],d=[],u=[],f=[];let g=0;const v=[],p=n/2;let m=0;x(),a===!1&&(e>0&&S(!0),t>0&&S(!1)),this.setIndex(h),this.setAttribute("position",new He(d,3)),this.setAttribute("normal",new He(u,3)),this.setAttribute("uv",new He(f,2));function x(){const b=new P,A=new P;let E=0;const y=(t-e)/n;for(let w=0;w<=r;w++){const L=[],R=w/r,N=R*(t-e)+e;for(let F=0;F<=s;F++){const V=F/s,I=V*c+o,H=Math.sin(I),J=Math.cos(I);A.x=N*H,A.y=-R*n+p,A.z=N*J,d.push(A.x,A.y,A.z),b.set(H,y,J).normalize(),u.push(b.x,b.y,b.z),f.push(V,1-R),L.push(g++)}v.push(L)}for(let w=0;w<s;w++)for(let L=0;L<r;L++){const R=v[L][w],N=v[L+1][w],F=v[L+1][w+1],V=v[L][w+1];(e>0||L!==0)&&(h.push(R,N,V),E+=3),(t>0||L!==r-1)&&(h.push(N,F,V),E+=3)}l.addGroup(m,E,0),m+=E}function S(b){const A=g,E=new fe,y=new P;let w=0;const L=b===!0?e:t,R=b===!0?1:-1;for(let F=1;F<=s;F++)d.push(0,p*R,0),u.push(0,R,0),f.push(.5,.5),g++;const N=g;for(let F=0;F<=s;F++){const I=F/s*c+o,H=Math.cos(I),J=Math.sin(I);y.x=L*J,y.y=p*R,y.z=L*H,d.push(y.x,y.y,y.z),u.push(0,R,0),E.x=H*.5+.5,E.y=J*.5*R+.5,f.push(E.x,E.y),g++}for(let F=0;F<s;F++){const V=A+F,I=N+F;b===!0?h.push(I,I+1,V):h.push(I+1,I,V),w+=3}l.addGroup(m,w,b===!0?1:2),m+=w}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new fi(e.radiusTop,e.radiusBottom,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}}class Xn extends fi{constructor(e=1,t=1,n=32,s=1,r=!1,a=0,o=Math.PI*2){super(0,e,t,n,s,r,a,o),this.type="ConeGeometry",this.parameters={radius:e,height:t,radialSegments:n,heightSegments:s,openEnded:r,thetaStart:a,thetaLength:o}}static fromJSON(e){return new Xn(e.radius,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}}class Pc extends pt{constructor(e=[],t=[],n=1,s=0){super(),this.type="PolyhedronGeometry",this.parameters={vertices:e,indices:t,radius:n,detail:s};const r=[],a=[];o(s),l(n),h(),this.setAttribute("position",new He(r,3)),this.setAttribute("normal",new He(r.slice(),3)),this.setAttribute("uv",new He(a,2)),s===0?this.computeVertexNormals():this.normalizeNormals();function o(x){const S=new P,b=new P,A=new P;for(let E=0;E<t.length;E+=3)f(t[E+0],S),f(t[E+1],b),f(t[E+2],A),c(S,b,A,x)}function c(x,S,b,A){const E=A+1,y=[];for(let w=0;w<=E;w++){y[w]=[];const L=x.clone().lerp(b,w/E),R=S.clone().lerp(b,w/E),N=E-w;for(let F=0;F<=N;F++)F===0&&w===E?y[w][F]=L:y[w][F]=L.clone().lerp(R,F/N)}for(let w=0;w<E;w++)for(let L=0;L<2*(E-w)-1;L++){const R=Math.floor(L/2);L%2===0?(u(y[w][R+1]),u(y[w+1][R]),u(y[w][R])):(u(y[w][R+1]),u(y[w+1][R+1]),u(y[w+1][R]))}}function l(x){const S=new P;for(let b=0;b<r.length;b+=3)S.x=r[b+0],S.y=r[b+1],S.z=r[b+2],S.normalize().multiplyScalar(x),r[b+0]=S.x,r[b+1]=S.y,r[b+2]=S.z}function h(){const x=new P;for(let S=0;S<r.length;S+=3){x.x=r[S+0],x.y=r[S+1],x.z=r[S+2];const b=p(x)/2/Math.PI+.5,A=m(x)/Math.PI+.5;a.push(b,1-A)}g(),d()}function d(){for(let x=0;x<a.length;x+=6){const S=a[x+0],b=a[x+2],A=a[x+4],E=Math.max(S,b,A),y=Math.min(S,b,A);E>.9&&y<.1&&(S<.2&&(a[x+0]+=1),b<.2&&(a[x+2]+=1),A<.2&&(a[x+4]+=1))}}function u(x){r.push(x.x,x.y,x.z)}function f(x,S){const b=x*3;S.x=e[b+0],S.y=e[b+1],S.z=e[b+2]}function g(){const x=new P,S=new P,b=new P,A=new P,E=new fe,y=new fe,w=new fe;for(let L=0,R=0;L<r.length;L+=9,R+=6){x.set(r[L+0],r[L+1],r[L+2]),S.set(r[L+3],r[L+4],r[L+5]),b.set(r[L+6],r[L+7],r[L+8]),E.set(a[R+0],a[R+1]),y.set(a[R+2],a[R+3]),w.set(a[R+4],a[R+5]),A.copy(x).add(S).add(b).divideScalar(3);const N=p(A);v(E,R+0,x,N),v(y,R+2,S,N),v(w,R+4,b,N)}}function v(x,S,b,A){A<0&&x.x===1&&(a[S]=x.x-1),b.x===0&&b.z===0&&(a[S]=A/2/Math.PI+.5)}function p(x){return Math.atan2(x.z,-x.x)}function m(x){return Math.atan2(-x.y,Math.sqrt(x.x*x.x+x.z*x.z))}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Pc(e.vertices,e.indices,e.radius,e.detail)}}class Zn{constructor(){this.type="Curve",this.arcLengthDivisions=200,this.needsUpdate=!1,this.cacheArcLengths=null}getPoint(){Le("Curve: .getPoint() not implemented.")}getPointAt(e,t){const n=this.getUtoTmapping(e);return this.getPoint(n,t)}getPoints(e=5){const t=[];for(let n=0;n<=e;n++)t.push(this.getPoint(n/e));return t}getSpacedPoints(e=5){const t=[];for(let n=0;n<=e;n++)t.push(this.getPointAt(n/e));return t}getLength(){const e=this.getLengths();return e[e.length-1]}getLengths(e=this.arcLengthDivisions){if(this.cacheArcLengths&&this.cacheArcLengths.length===e+1&&!this.needsUpdate)return this.cacheArcLengths;this.needsUpdate=!1;const t=[];let n,s=this.getPoint(0),r=0;t.push(0);for(let a=1;a<=e;a++)n=this.getPoint(a/e),r+=n.distanceTo(s),t.push(r),s=n;return this.cacheArcLengths=t,t}updateArcLengths(){this.needsUpdate=!0,this.getLengths()}getUtoTmapping(e,t=null){const n=this.getLengths();let s=0;const r=n.length;let a;t?a=t:a=e*n[r-1];let o=0,c=r-1,l;for(;o<=c;)if(s=Math.floor(o+(c-o)/2),l=n[s]-a,l<0)o=s+1;else if(l>0)c=s-1;else{c=s;break}if(s=c,n[s]===a)return s/(r-1);const h=n[s],u=n[s+1]-h,f=(a-h)/u;return(s+f)/(r-1)}getTangent(e,t){let s=e-1e-4,r=e+1e-4;s<0&&(s=0),r>1&&(r=1);const a=this.getPoint(s),o=this.getPoint(r),c=t||(a.isVector2?new fe:new P);return c.copy(o).sub(a).normalize(),c}getTangentAt(e,t){const n=this.getUtoTmapping(e);return this.getTangent(n,t)}computeFrenetFrames(e,t=!1){const n=new P,s=[],r=[],a=[],o=new P,c=new Ke;for(let f=0;f<=e;f++){const g=f/e;s[f]=this.getTangentAt(g,new P)}r[0]=new P,a[0]=new P;let l=Number.MAX_VALUE;const h=Math.abs(s[0].x),d=Math.abs(s[0].y),u=Math.abs(s[0].z);h<=l&&(l=h,n.set(1,0,0)),d<=l&&(l=d,n.set(0,1,0)),u<=l&&n.set(0,0,1),o.crossVectors(s[0],n).normalize(),r[0].crossVectors(s[0],o),a[0].crossVectors(s[0],r[0]);for(let f=1;f<=e;f++){if(r[f]=r[f-1].clone(),a[f]=a[f-1].clone(),o.crossVectors(s[f-1],s[f]),o.length()>Number.EPSILON){o.normalize();const g=Math.acos(Ge(s[f-1].dot(s[f]),-1,1));r[f].applyMatrix4(c.makeRotationAxis(o,g))}a[f].crossVectors(s[f],r[f])}if(t===!0){let f=Math.acos(Ge(r[0].dot(r[e]),-1,1));f/=e,s[0].dot(o.crossVectors(r[0],r[e]))>0&&(f=-f);for(let g=1;g<=e;g++)r[g].applyMatrix4(c.makeRotationAxis(s[g],f*g)),a[g].crossVectors(s[g],r[g])}return{tangents:s,normals:r,binormals:a}}clone(){return new this.constructor().copy(this)}copy(e){return this.arcLengthDivisions=e.arcLengthDivisions,this.cacheArcLengths=null,this}toJSON(){const e={metadata:{version:4.7,type:"Curve",generator:"Curve.toJSON"}};return e.arcLengthDivisions=this.arcLengthDivisions,e.type=this.type,e}fromJSON(e){return this.arcLengthDivisions=e.arcLengthDivisions,this.cacheArcLengths=null,this}}class Lc extends Zn{constructor(e=0,t=0,n=1,s=1,r=0,a=Math.PI*2,o=!1,c=0){super(),this.isEllipseCurve=!0,this.type="EllipseCurve",this.aX=e,this.aY=t,this.xRadius=n,this.yRadius=s,this.aStartAngle=r,this.aEndAngle=a,this.aClockwise=o,this.aRotation=c}getPoint(e,t=new fe){const n=t,s=Math.PI*2;let r=this.aEndAngle-this.aStartAngle;const a=Math.abs(r)<Number.EPSILON;for(;r<0;)r+=s;for(;r>s;)r-=s;r<Number.EPSILON&&(a?r=0:r=s),this.aClockwise===!0&&!a&&(r===s?r=-s:r=r-s);const o=this.aStartAngle+e*r;let c=this.aX+this.xRadius*Math.cos(o),l=this.aY+this.yRadius*Math.sin(o);if(this.aRotation!==0){const h=Math.cos(this.aRotation),d=Math.sin(this.aRotation),u=c-this.aX,f=l-this.aY;c=u*h-f*d+this.aX,l=u*d+f*h+this.aY}return n.set(c,l)}copy(e){return super.copy(e),this.aX=e.aX,this.aY=e.aY,this.xRadius=e.xRadius,this.yRadius=e.yRadius,this.aStartAngle=e.aStartAngle,this.aEndAngle=e.aEndAngle,this.aClockwise=e.aClockwise,this.aRotation=e.aRotation,this}toJSON(){const e=super.toJSON();return e.aX=this.aX,e.aY=this.aY,e.xRadius=this.xRadius,e.yRadius=this.yRadius,e.aStartAngle=this.aStartAngle,e.aEndAngle=this.aEndAngle,e.aClockwise=this.aClockwise,e.aRotation=this.aRotation,e}fromJSON(e){return super.fromJSON(e),this.aX=e.aX,this.aY=e.aY,this.xRadius=e.xRadius,this.yRadius=e.yRadius,this.aStartAngle=e.aStartAngle,this.aEndAngle=e.aEndAngle,this.aClockwise=e.aClockwise,this.aRotation=e.aRotation,this}}class km extends Lc{constructor(e,t,n,s,r,a){super(e,t,n,n,s,r,a),this.isArcCurve=!0,this.type="ArcCurve"}}function Dc(){let i=0,e=0,t=0,n=0;function s(r,a,o,c){i=r,e=o,t=-3*r+3*a-2*o-c,n=2*r-2*a+o+c}return{initCatmullRom:function(r,a,o,c,l){s(a,o,l*(o-r),l*(c-a))},initNonuniformCatmullRom:function(r,a,o,c,l,h,d){let u=(a-r)/l-(o-r)/(l+h)+(o-a)/h,f=(o-a)/h-(c-a)/(h+d)+(c-o)/d;u*=h,f*=h,s(a,o,u,f)},calc:function(r){const a=r*r,o=a*r;return i+e*r+t*a+n*o}}}const $h=new P,qh=new P,Bo=new Dc,zo=new Dc,Go=new Dc;class Bm extends Zn{constructor(e=[],t=!1,n="centripetal",s=.5){super(),this.isCatmullRomCurve3=!0,this.type="CatmullRomCurve3",this.points=e,this.closed=t,this.curveType=n,this.tension=s}getPoint(e,t=new P){const n=t,s=this.points,r=s.length,a=(r-(this.closed?0:1))*e;let o=Math.floor(a),c=a-o;this.closed?o+=o>0?0:(Math.floor(Math.abs(o)/r)+1)*r:c===0&&o===r-1&&(o=r-2,c=1);let l,h;this.closed||o>0?l=s[(o-1)%r]:(qh.subVectors(s[0],s[1]).add(s[0]),l=qh);const d=s[o%r],u=s[(o+1)%r];if(this.closed||o+2<r?h=s[(o+2)%r]:($h.subVectors(s[r-1],s[r-2]).add(s[r-1]),h=$h),this.curveType==="centripetal"||this.curveType==="chordal"){const f=this.curveType==="chordal"?.5:.25;let g=Math.pow(l.distanceToSquared(d),f),v=Math.pow(d.distanceToSquared(u),f),p=Math.pow(u.distanceToSquared(h),f);v<1e-4&&(v=1),g<1e-4&&(g=v),p<1e-4&&(p=v),Bo.initNonuniformCatmullRom(l.x,d.x,u.x,h.x,g,v,p),zo.initNonuniformCatmullRom(l.y,d.y,u.y,h.y,g,v,p),Go.initNonuniformCatmullRom(l.z,d.z,u.z,h.z,g,v,p)}else this.curveType==="catmullrom"&&(Bo.initCatmullRom(l.x,d.x,u.x,h.x,this.tension),zo.initCatmullRom(l.y,d.y,u.y,h.y,this.tension),Go.initCatmullRom(l.z,d.z,u.z,h.z,this.tension));return n.set(Bo.calc(c),zo.calc(c),Go.calc(c)),n}copy(e){super.copy(e),this.points=[];for(let t=0,n=e.points.length;t<n;t++){const s=e.points[t];this.points.push(s.clone())}return this.closed=e.closed,this.curveType=e.curveType,this.tension=e.tension,this}toJSON(){const e=super.toJSON();e.points=[];for(let t=0,n=this.points.length;t<n;t++){const s=this.points[t];e.points.push(s.toArray())}return e.closed=this.closed,e.curveType=this.curveType,e.tension=this.tension,e}fromJSON(e){super.fromJSON(e),this.points=[];for(let t=0,n=e.points.length;t<n;t++){const s=e.points[t];this.points.push(new P().fromArray(s))}return this.closed=e.closed,this.curveType=e.curveType,this.tension=e.tension,this}}function Xh(i,e,t,n,s){const r=(n-e)*.5,a=(s-t)*.5,o=i*i,c=i*o;return(2*t-2*n+r+a)*c+(-3*t+3*n-2*r-a)*o+r*i+t}function zm(i,e){const t=1-i;return t*t*e}function Gm(i,e){return 2*(1-i)*i*e}function Hm(i,e){return i*i*e}function lr(i,e,t,n){return zm(i,e)+Gm(i,t)+Hm(i,n)}function Vm(i,e){const t=1-i;return t*t*t*e}function Wm(i,e){const t=1-i;return 3*t*t*i*e}function $m(i,e){return 3*(1-i)*i*i*e}function qm(i,e){return i*i*i*e}function cr(i,e,t,n,s){return Vm(i,e)+Wm(i,t)+$m(i,n)+qm(i,s)}class $u extends Zn{constructor(e=new fe,t=new fe,n=new fe,s=new fe){super(),this.isCubicBezierCurve=!0,this.type="CubicBezierCurve",this.v0=e,this.v1=t,this.v2=n,this.v3=s}getPoint(e,t=new fe){const n=t,s=this.v0,r=this.v1,a=this.v2,o=this.v3;return n.set(cr(e,s.x,r.x,a.x,o.x),cr(e,s.y,r.y,a.y,o.y)),n}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this.v3.copy(e.v3),this}toJSON(){const e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e.v3=this.v3.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this.v3.fromArray(e.v3),this}}class Xm extends Zn{constructor(e=new P,t=new P,n=new P,s=new P){super(),this.isCubicBezierCurve3=!0,this.type="CubicBezierCurve3",this.v0=e,this.v1=t,this.v2=n,this.v3=s}getPoint(e,t=new P){const n=t,s=this.v0,r=this.v1,a=this.v2,o=this.v3;return n.set(cr(e,s.x,r.x,a.x,o.x),cr(e,s.y,r.y,a.y,o.y),cr(e,s.z,r.z,a.z,o.z)),n}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this.v3.copy(e.v3),this}toJSON(){const e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e.v3=this.v3.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this.v3.fromArray(e.v3),this}}class qu extends Zn{constructor(e=new fe,t=new fe){super(),this.isLineCurve=!0,this.type="LineCurve",this.v1=e,this.v2=t}getPoint(e,t=new fe){const n=t;return e===1?n.copy(this.v2):(n.copy(this.v2).sub(this.v1),n.multiplyScalar(e).add(this.v1)),n}getPointAt(e,t){return this.getPoint(e,t)}getTangent(e,t=new fe){return t.subVectors(this.v2,this.v1).normalize()}getTangentAt(e,t){return this.getTangent(e,t)}copy(e){return super.copy(e),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){const e=super.toJSON();return e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}}class Ym extends Zn{constructor(e=new P,t=new P){super(),this.isLineCurve3=!0,this.type="LineCurve3",this.v1=e,this.v2=t}getPoint(e,t=new P){const n=t;return e===1?n.copy(this.v2):(n.copy(this.v2).sub(this.v1),n.multiplyScalar(e).add(this.v1)),n}getPointAt(e,t){return this.getPoint(e,t)}getTangent(e,t=new P){return t.subVectors(this.v2,this.v1).normalize()}getTangentAt(e,t){return this.getTangent(e,t)}copy(e){return super.copy(e),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){const e=super.toJSON();return e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}}class Xu extends Zn{constructor(e=new fe,t=new fe,n=new fe){super(),this.isQuadraticBezierCurve=!0,this.type="QuadraticBezierCurve",this.v0=e,this.v1=t,this.v2=n}getPoint(e,t=new fe){const n=t,s=this.v0,r=this.v1,a=this.v2;return n.set(lr(e,s.x,r.x,a.x),lr(e,s.y,r.y,a.y)),n}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){const e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}}class Km extends Zn{constructor(e=new P,t=new P,n=new P){super(),this.isQuadraticBezierCurve3=!0,this.type="QuadraticBezierCurve3",this.v0=e,this.v1=t,this.v2=n}getPoint(e,t=new P){const n=t,s=this.v0,r=this.v1,a=this.v2;return n.set(lr(e,s.x,r.x,a.x),lr(e,s.y,r.y,a.y),lr(e,s.z,r.z,a.z)),n}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){const e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}}class Yu extends Zn{constructor(e=[]){super(),this.isSplineCurve=!0,this.type="SplineCurve",this.points=e}getPoint(e,t=new fe){const n=t,s=this.points,r=(s.length-1)*e,a=Math.floor(r),o=r-a,c=s[a===0?a:a-1],l=s[a],h=s[a>s.length-2?s.length-1:a+1],d=s[a>s.length-3?s.length-1:a+2];return n.set(Xh(o,c.x,l.x,h.x,d.x),Xh(o,c.y,l.y,h.y,d.y)),n}copy(e){super.copy(e),this.points=[];for(let t=0,n=e.points.length;t<n;t++){const s=e.points[t];this.points.push(s.clone())}return this}toJSON(){const e=super.toJSON();e.points=[];for(let t=0,n=this.points.length;t<n;t++){const s=this.points[t];e.points.push(s.toArray())}return e}fromJSON(e){super.fromJSON(e),this.points=[];for(let t=0,n=e.points.length;t<n;t++){const s=e.points[t];this.points.push(new fe().fromArray(s))}return this}}var Yh=Object.freeze({__proto__:null,ArcCurve:km,CatmullRomCurve3:Bm,CubicBezierCurve:$u,CubicBezierCurve3:Xm,EllipseCurve:Lc,LineCurve:qu,LineCurve3:Ym,QuadraticBezierCurve:Xu,QuadraticBezierCurve3:Km,SplineCurve:Yu});class Jm extends Zn{constructor(){super(),this.type="CurvePath",this.curves=[],this.autoClose=!1,this.cacheLengths=null}add(e){this.curves.push(e)}closePath(){const e=this.curves[0].getPoint(0),t=this.curves[this.curves.length-1].getPoint(1);if(!e.equals(t)){const n=e.isVector2===!0?"LineCurve":"LineCurve3";this.curves.push(new Yh[n](t,e))}return this}getPoint(e,t){const n=e*this.getLength(),s=this.getCurveLengths();let r=0;for(;r<s.length;){if(s[r]>=n){const a=s[r]-n,o=this.curves[r],c=o.getLength(),l=c===0?0:1-a/c;return o.getPointAt(l,t)}r++}return null}getLength(){const e=this.getCurveLengths();return e[e.length-1]}updateArcLengths(){this.needsUpdate=!0,this.cacheLengths=null,this.getCurveLengths()}getCurveLengths(){if(this.cacheLengths&&this.cacheLengths.length===this.curves.length)return this.cacheLengths;const e=[];let t=0;for(let n=0,s=this.curves.length;n<s;n++)t+=this.curves[n].getLength(),e.push(t);return this.cacheLengths=e,e}getSpacedPoints(e=40){const t=[];for(let n=0;n<=e;n++)t.push(this.getPoint(n/e));return this.autoClose&&t.push(t[0]),t}getPoints(e=12){const t=[];let n;for(let s=0,r=this.curves;s<r.length;s++){const a=r[s],o=a.isEllipseCurve?e*2:a.isLineCurve||a.isLineCurve3?1:a.isSplineCurve?e*a.points.length:e,c=a.getPoints(o);for(let l=0;l<c.length;l++){const h=c[l];n&&n.equals(h)||(t.push(h),n=h)}}return this.autoClose&&t.length>1&&!t[t.length-1].equals(t[0])&&t.push(t[0]),t}copy(e){super.copy(e),this.curves=[];for(let t=0,n=e.curves.length;t<n;t++){const s=e.curves[t];this.curves.push(s.clone())}return this.autoClose=e.autoClose,this.cacheLengths=null,this}toJSON(){const e=super.toJSON();e.autoClose=this.autoClose,e.curves=[];for(let t=0,n=this.curves.length;t<n;t++){const s=this.curves[t];e.curves.push(s.toJSON())}return e}fromJSON(e){super.fromJSON(e),this.autoClose=e.autoClose,this.curves=[];for(let t=0,n=e.curves.length;t<n;t++){const s=e.curves[t];this.curves.push(new Yh[s.type]().fromJSON(s))}return this.cacheLengths=null,this}}class zl extends Jm{constructor(e){super(),this.type="Path",this.currentPoint=new fe,e&&this.setFromPoints(e)}setFromPoints(e){this.moveTo(e[0].x,e[0].y);for(let t=1,n=e.length;t<n;t++)this.lineTo(e[t].x,e[t].y);return this}moveTo(e,t){return this.currentPoint.set(e,t),this}lineTo(e,t){const n=new qu(this.currentPoint.clone(),new fe(e,t));return this.curves.push(n),this.currentPoint.set(e,t),this}quadraticCurveTo(e,t,n,s){const r=new Xu(this.currentPoint.clone(),new fe(e,t),new fe(n,s));return this.curves.push(r),this.currentPoint.set(n,s),this}bezierCurveTo(e,t,n,s,r,a){const o=new $u(this.currentPoint.clone(),new fe(e,t),new fe(n,s),new fe(r,a));return this.curves.push(o),this.currentPoint.set(r,a),this}splineThru(e){const t=[this.currentPoint.clone()].concat(e),n=new Yu(t);return this.curves.push(n),this.currentPoint.copy(e[e.length-1]),this}arc(e,t,n,s,r,a){const o=this.currentPoint.x,c=this.currentPoint.y;return this.absarc(e+o,t+c,n,s,r,a),this}absarc(e,t,n,s,r,a){return this.absellipse(e,t,n,n,s,r,a),this}ellipse(e,t,n,s,r,a,o,c){const l=this.currentPoint.x,h=this.currentPoint.y;return this.absellipse(e+l,t+h,n,s,r,a,o,c),this}absellipse(e,t,n,s,r,a,o,c){const l=new Lc(e,t,n,s,r,a,o,c);if(this.curves.length>0){const d=l.getPoint(0);d.equals(this.currentPoint)||this.lineTo(d.x,d.y)}this.curves.push(l);const h=l.getPoint(1);return this.currentPoint.copy(h),this}copy(e){return super.copy(e),this.currentPoint.copy(e.currentPoint),this}toJSON(){const e=super.toJSON();return e.currentPoint=this.currentPoint.toArray(),e}fromJSON(e){return super.fromJSON(e),this.currentPoint.fromArray(e.currentPoint),this}}class Ku extends zl{constructor(e){super(e),this.uuid=gi(),this.type="Shape",this.holes=[]}getPointsHoles(e){const t=[];for(let n=0,s=this.holes.length;n<s;n++)t[n]=this.holes[n].getPoints(e);return t}extractPoints(e){return{shape:this.getPoints(e),holes:this.getPointsHoles(e)}}copy(e){super.copy(e),this.holes=[];for(let t=0,n=e.holes.length;t<n;t++){const s=e.holes[t];this.holes.push(s.clone())}return this}toJSON(){const e=super.toJSON();e.uuid=this.uuid,e.holes=[];for(let t=0,n=this.holes.length;t<n;t++){const s=this.holes[t];e.holes.push(s.toJSON())}return e}fromJSON(e){super.fromJSON(e),this.uuid=e.uuid,this.holes=[];for(let t=0,n=e.holes.length;t<n;t++){const s=e.holes[t];this.holes.push(new zl().fromJSON(s))}return this}}function Zm(i,e,t=2){const n=e&&e.length,s=n?e[0]*t:i.length;let r=Ju(i,0,s,t,!0);const a=[];if(!r||r.next===r.prev)return a;let o,c,l;if(n&&(r=n0(i,e,r,t)),i.length>80*t){o=i[0],c=i[1];let h=o,d=c;for(let u=t;u<s;u+=t){const f=i[u],g=i[u+1];f<o&&(o=f),g<c&&(c=g),f>h&&(h=f),g>d&&(d=g)}l=Math.max(h-o,d-c),l=l!==0?32767/l:0}return _r(r,a,t,o,c,l,0),a}function Ju(i,e,t,n,s){let r;if(s===f0(i,e,t,n)>0)for(let a=e;a<t;a+=n)r=Kh(a/n|0,i[a],i[a+1],r);else for(let a=t-n;a>=e;a-=n)r=Kh(a/n|0,i[a],i[a+1],r);return r&&Ns(r,r.next)&&(Sr(r),r=r.next),r}function Zi(i,e){if(!i)return i;e||(e=i);let t=i,n;do if(n=!1,!t.steiner&&(Ns(t,t.next)||xt(t.prev,t,t.next)===0)){if(Sr(t),t=e=t.prev,t===t.next)break;n=!0}else t=t.next;while(n||t!==e);return e}function _r(i,e,t,n,s,r,a){if(!i)return;!a&&r&&o0(i,n,s,r);let o=i;for(;i.prev!==i.next;){const c=i.prev,l=i.next;if(r?jm(i,n,s,r):Qm(i)){e.push(c.i,i.i,l.i),Sr(i),i=l.next,o=l.next;continue}if(i=l,i===o){a?a===1?(i=e0(Zi(i),e),_r(i,e,t,n,s,r,2)):a===2&&t0(i,e,t,n,s,r):_r(Zi(i),e,t,n,s,r,1);break}}}function Qm(i){const e=i.prev,t=i,n=i.next;if(xt(e,t,n)>=0)return!1;const s=e.x,r=t.x,a=n.x,o=e.y,c=t.y,l=n.y,h=Math.min(s,r,a),d=Math.min(o,c,l),u=Math.max(s,r,a),f=Math.max(o,c,l);let g=n.next;for(;g!==e;){if(g.x>=h&&g.x<=u&&g.y>=d&&g.y<=f&&er(s,o,r,c,a,l,g.x,g.y)&&xt(g.prev,g,g.next)>=0)return!1;g=g.next}return!0}function jm(i,e,t,n){const s=i.prev,r=i,a=i.next;if(xt(s,r,a)>=0)return!1;const o=s.x,c=r.x,l=a.x,h=s.y,d=r.y,u=a.y,f=Math.min(o,c,l),g=Math.min(h,d,u),v=Math.max(o,c,l),p=Math.max(h,d,u),m=Gl(f,g,e,t,n),x=Gl(v,p,e,t,n);let S=i.prevZ,b=i.nextZ;for(;S&&S.z>=m&&b&&b.z<=x;){if(S.x>=f&&S.x<=v&&S.y>=g&&S.y<=p&&S!==s&&S!==a&&er(o,h,c,d,l,u,S.x,S.y)&&xt(S.prev,S,S.next)>=0||(S=S.prevZ,b.x>=f&&b.x<=v&&b.y>=g&&b.y<=p&&b!==s&&b!==a&&er(o,h,c,d,l,u,b.x,b.y)&&xt(b.prev,b,b.next)>=0))return!1;b=b.nextZ}for(;S&&S.z>=m;){if(S.x>=f&&S.x<=v&&S.y>=g&&S.y<=p&&S!==s&&S!==a&&er(o,h,c,d,l,u,S.x,S.y)&&xt(S.prev,S,S.next)>=0)return!1;S=S.prevZ}for(;b&&b.z<=x;){if(b.x>=f&&b.x<=v&&b.y>=g&&b.y<=p&&b!==s&&b!==a&&er(o,h,c,d,l,u,b.x,b.y)&&xt(b.prev,b,b.next)>=0)return!1;b=b.nextZ}return!0}function e0(i,e){let t=i;do{const n=t.prev,s=t.next.next;!Ns(n,s)&&Qu(n,t,t.next,s)&&Mr(n,s)&&Mr(s,n)&&(e.push(n.i,t.i,s.i),Sr(t),Sr(t.next),t=i=s),t=t.next}while(t!==i);return Zi(t)}function t0(i,e,t,n,s,r){let a=i;do{let o=a.next.next;for(;o!==a.prev;){if(a.i!==o.i&&h0(a,o)){let c=ju(a,o);a=Zi(a,a.next),c=Zi(c,c.next),_r(a,e,t,n,s,r,0),_r(c,e,t,n,s,r,0);return}o=o.next}a=a.next}while(a!==i)}function n0(i,e,t,n){const s=[];for(let r=0,a=e.length;r<a;r++){const o=e[r]*n,c=r<a-1?e[r+1]*n:i.length,l=Ju(i,o,c,n,!1);l===l.next&&(l.steiner=!0),s.push(c0(l))}s.sort(i0);for(let r=0;r<s.length;r++)t=s0(s[r],t);return t}function i0(i,e){let t=i.x-e.x;if(t===0&&(t=i.y-e.y,t===0)){const n=(i.next.y-i.y)/(i.next.x-i.x),s=(e.next.y-e.y)/(e.next.x-e.x);t=n-s}return t}function s0(i,e){const t=r0(i,e);if(!t)return e;const n=ju(t,i);return Zi(n,n.next),Zi(t,t.next)}function r0(i,e){let t=e;const n=i.x,s=i.y;let r=-1/0,a;if(Ns(i,t))return t;do{if(Ns(i,t.next))return t.next;if(s<=t.y&&s>=t.next.y&&t.next.y!==t.y){const d=t.x+(s-t.y)*(t.next.x-t.x)/(t.next.y-t.y);if(d<=n&&d>r&&(r=d,a=t.x<t.next.x?t:t.next,d===n))return a}t=t.next}while(t!==e);if(!a)return null;const o=a,c=a.x,l=a.y;let h=1/0;t=a;do{if(n>=t.x&&t.x>=c&&n!==t.x&&Zu(s<l?n:r,s,c,l,s<l?r:n,s,t.x,t.y)){const d=Math.abs(s-t.y)/(n-t.x);Mr(t,i)&&(d<h||d===h&&(t.x>a.x||t.x===a.x&&a0(a,t)))&&(a=t,h=d)}t=t.next}while(t!==o);return a}function a0(i,e){return xt(i.prev,i,e.prev)<0&&xt(e.next,i,i.next)<0}function o0(i,e,t,n){let s=i;do s.z===0&&(s.z=Gl(s.x,s.y,e,t,n)),s.prevZ=s.prev,s.nextZ=s.next,s=s.next;while(s!==i);s.prevZ.nextZ=null,s.prevZ=null,l0(s)}function l0(i){let e,t=1;do{let n=i,s;i=null;let r=null;for(e=0;n;){e++;let a=n,o=0;for(let l=0;l<t&&(o++,a=a.nextZ,!!a);l++);let c=t;for(;o>0||c>0&&a;)o!==0&&(c===0||!a||n.z<=a.z)?(s=n,n=n.nextZ,o--):(s=a,a=a.nextZ,c--),r?r.nextZ=s:i=s,s.prevZ=r,r=s;n=a}r.nextZ=null,t*=2}while(e>1);return i}function Gl(i,e,t,n,s){return i=(i-t)*s|0,e=(e-n)*s|0,i=(i|i<<8)&16711935,i=(i|i<<4)&252645135,i=(i|i<<2)&858993459,i=(i|i<<1)&1431655765,e=(e|e<<8)&16711935,e=(e|e<<4)&252645135,e=(e|e<<2)&858993459,e=(e|e<<1)&1431655765,i|e<<1}function c0(i){let e=i,t=i;do(e.x<t.x||e.x===t.x&&e.y<t.y)&&(t=e),e=e.next;while(e!==i);return t}function Zu(i,e,t,n,s,r,a,o){return(s-a)*(e-o)>=(i-a)*(r-o)&&(i-a)*(n-o)>=(t-a)*(e-o)&&(t-a)*(r-o)>=(s-a)*(n-o)}function er(i,e,t,n,s,r,a,o){return!(i===a&&e===o)&&Zu(i,e,t,n,s,r,a,o)}function h0(i,e){return i.next.i!==e.i&&i.prev.i!==e.i&&!d0(i,e)&&(Mr(i,e)&&Mr(e,i)&&u0(i,e)&&(xt(i.prev,i,e.prev)||xt(i,e.prev,e))||Ns(i,e)&&xt(i.prev,i,i.next)>0&&xt(e.prev,e,e.next)>0)}function xt(i,e,t){return(e.y-i.y)*(t.x-e.x)-(e.x-i.x)*(t.y-e.y)}function Ns(i,e){return i.x===e.x&&i.y===e.y}function Qu(i,e,t,n){const s=ua(xt(i,e,t)),r=ua(xt(i,e,n)),a=ua(xt(t,n,i)),o=ua(xt(t,n,e));return!!(s!==r&&a!==o||s===0&&da(i,t,e)||r===0&&da(i,n,e)||a===0&&da(t,i,n)||o===0&&da(t,e,n))}function da(i,e,t){return e.x<=Math.max(i.x,t.x)&&e.x>=Math.min(i.x,t.x)&&e.y<=Math.max(i.y,t.y)&&e.y>=Math.min(i.y,t.y)}function ua(i){return i>0?1:i<0?-1:0}function d0(i,e){let t=i;do{if(t.i!==i.i&&t.next.i!==i.i&&t.i!==e.i&&t.next.i!==e.i&&Qu(t,t.next,i,e))return!0;t=t.next}while(t!==i);return!1}function Mr(i,e){return xt(i.prev,i,i.next)<0?xt(i,e,i.next)>=0&&xt(i,i.prev,e)>=0:xt(i,e,i.prev)<0||xt(i,i.next,e)<0}function u0(i,e){let t=i,n=!1;const s=(i.x+e.x)/2,r=(i.y+e.y)/2;do t.y>r!=t.next.y>r&&t.next.y!==t.y&&s<(t.next.x-t.x)*(r-t.y)/(t.next.y-t.y)+t.x&&(n=!n),t=t.next;while(t!==i);return n}function ju(i,e){const t=Hl(i.i,i.x,i.y),n=Hl(e.i,e.x,e.y),s=i.next,r=e.prev;return i.next=e,e.prev=i,t.next=s,s.prev=t,n.next=t,t.prev=n,r.next=n,n.prev=r,n}function Kh(i,e,t,n){const s=Hl(i,e,t);return n?(s.next=n.next,s.prev=n,n.next.prev=s,n.next=s):(s.prev=s,s.next=s),s}function Sr(i){i.next.prev=i.prev,i.prev.next=i.next,i.prevZ&&(i.prevZ.nextZ=i.nextZ),i.nextZ&&(i.nextZ.prevZ=i.prevZ)}function Hl(i,e,t){return{i,x:e,y:t,prev:null,next:null,z:0,prevZ:null,nextZ:null,steiner:!1}}function f0(i,e,t,n){let s=0;for(let r=e,a=t-n;r<t;r+=n)s+=(i[a]-i[r])*(i[r+1]+i[a+1]),a=r;return s}class p0{static triangulate(e,t,n=2){return Zm(e,t,n)}}class hr{static area(e){const t=e.length;let n=0;for(let s=t-1,r=0;r<t;s=r++)n+=e[s].x*e[r].y-e[r].x*e[s].y;return n*.5}static isClockWise(e){return hr.area(e)<0}static triangulateShape(e,t){const n=[],s=[],r=[];Jh(e),Zh(n,e);let a=e.length;t.forEach(Jh);for(let c=0;c<t.length;c++)s.push(a),a+=t[c].length,Zh(n,t[c]);const o=p0.triangulate(n,s);for(let c=0;c<o.length;c+=3)r.push(o.slice(c,c+3));return r}}function Jh(i){const e=i.length;e>2&&i[e-1].equals(i[0])&&i.pop()}function Zh(i,e){for(let t=0;t<e.length;t++)i.push(e[t].x),i.push(e[t].y)}class Pr extends Pc{constructor(e=1,t=0){const n=(1+Math.sqrt(5))/2,s=[-1,n,0,1,n,0,-1,-n,0,1,-n,0,0,-1,n,0,1,n,0,-1,-n,0,1,-n,n,0,-1,n,0,1,-n,0,-1,-n,0,1],r=[0,11,5,0,5,1,0,1,7,0,7,10,0,10,11,1,5,9,5,11,4,11,10,2,10,7,6,7,1,8,3,9,4,3,4,2,3,2,6,3,6,8,3,8,9,4,9,5,2,4,11,6,2,10,8,6,7,9,8,1];super(s,r,e,t),this.type="IcosahedronGeometry",this.parameters={radius:e,detail:t}}static fromJSON(e){return new Pr(e.radius,e.detail)}}class so extends pt{constructor(e=[new fe(0,-.5),new fe(.5,0),new fe(0,.5)],t=12,n=0,s=Math.PI*2){super(),this.type="LatheGeometry",this.parameters={points:e,segments:t,phiStart:n,phiLength:s},t=Math.floor(t),s=Ge(s,0,Math.PI*2);const r=[],a=[],o=[],c=[],l=[],h=1/t,d=new P,u=new fe,f=new P,g=new P,v=new P;let p=0,m=0;for(let x=0;x<=e.length-1;x++)switch(x){case 0:p=e[x+1].x-e[x].x,m=e[x+1].y-e[x].y,f.x=m*1,f.y=-p,f.z=m*0,v.copy(f),f.normalize(),c.push(f.x,f.y,f.z);break;case e.length-1:v.normalize(),c.push(v.x,v.y,v.z);break;default:p=e[x+1].x-e[x].x,m=e[x+1].y-e[x].y,f.x=m*1,f.y=-p,f.z=m*0,g.copy(f),f.x+=v.x,f.y+=v.y,f.z+=v.z,f.normalize(),c.push(f.x,f.y,f.z),v.copy(g)}for(let x=0;x<=t;x++){const S=n+x*h*s,b=Math.sin(S),A=Math.cos(S);for(let E=0;E<=e.length-1;E++){d.x=e[E].x*b,d.y=e[E].y,d.z=e[E].x*A,a.push(d.x,d.y,d.z),u.x=x/t,u.y=E/(e.length-1),o.push(u.x,u.y);const y=c[3*E+0]*b,w=c[3*E+1],L=c[3*E+0]*A;l.push(y,w,L)}}for(let x=0;x<t;x++)for(let S=0;S<e.length-1;S++){const b=S+x*e.length,A=b,E=b+e.length,y=b+e.length+1,w=b+1;r.push(A,E,w),r.push(y,w,E)}this.setIndex(r),this.setAttribute("position",new He(a,3)),this.setAttribute("uv",new He(o,2)),this.setAttribute("normal",new He(l,3))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new so(e.points,e.segments,e.phiStart,e.phiLength)}}class pi extends pt{constructor(e=1,t=1,n=1,s=1){super(),this.type="PlaneGeometry",this.parameters={width:e,height:t,widthSegments:n,heightSegments:s};const r=e/2,a=t/2,o=Math.floor(n),c=Math.floor(s),l=o+1,h=c+1,d=e/o,u=t/c,f=[],g=[],v=[],p=[];for(let m=0;m<h;m++){const x=m*u-a;for(let S=0;S<l;S++){const b=S*d-r;g.push(b,-x,0),v.push(0,0,1),p.push(S/o),p.push(1-m/c)}}for(let m=0;m<c;m++)for(let x=0;x<o;x++){const S=x+l*m,b=x+l*(m+1),A=x+1+l*(m+1),E=x+1+l*m;f.push(S,b,E),f.push(b,A,E)}this.setIndex(f),this.setAttribute("position",new He(g,3)),this.setAttribute("normal",new He(v,3)),this.setAttribute("uv",new He(p,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new pi(e.width,e.height,e.widthSegments,e.heightSegments)}}class Lr extends pt{constructor(e=.5,t=1,n=32,s=1,r=0,a=Math.PI*2){super(),this.type="RingGeometry",this.parameters={innerRadius:e,outerRadius:t,thetaSegments:n,phiSegments:s,thetaStart:r,thetaLength:a},n=Math.max(3,n),s=Math.max(1,s);const o=[],c=[],l=[],h=[];let d=e;const u=(t-e)/s,f=new P,g=new fe;for(let v=0;v<=s;v++){for(let p=0;p<=n;p++){const m=r+p/n*a;f.x=d*Math.cos(m),f.y=d*Math.sin(m),c.push(f.x,f.y,f.z),l.push(0,0,1),g.x=(f.x/t+1)/2,g.y=(f.y/t+1)/2,h.push(g.x,g.y)}d+=u}for(let v=0;v<s;v++){const p=v*(n+1);for(let m=0;m<n;m++){const x=m+p,S=x,b=x+n+1,A=x+n+2,E=x+1;o.push(S,b,E),o.push(b,A,E)}}this.setIndex(o),this.setAttribute("position",new He(c,3)),this.setAttribute("normal",new He(l,3)),this.setAttribute("uv",new He(h,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Lr(e.innerRadius,e.outerRadius,e.thetaSegments,e.phiSegments,e.thetaStart,e.thetaLength)}}class Ic extends pt{constructor(e=new Ku([new fe(0,.5),new fe(-.5,-.5),new fe(.5,-.5)]),t=12){super(),this.type="ShapeGeometry",this.parameters={shapes:e,curveSegments:t};const n=[],s=[],r=[],a=[];let o=0,c=0;if(Array.isArray(e)===!1)l(e);else for(let h=0;h<e.length;h++)l(e[h]),this.addGroup(o,c,h),o+=c,c=0;this.setIndex(n),this.setAttribute("position",new He(s,3)),this.setAttribute("normal",new He(r,3)),this.setAttribute("uv",new He(a,2));function l(h){const d=s.length/3,u=h.extractPoints(t);let f=u.shape;const g=u.holes;hr.isClockWise(f)===!1&&(f=f.reverse());for(let p=0,m=g.length;p<m;p++){const x=g[p];hr.isClockWise(x)===!0&&(g[p]=x.reverse())}const v=hr.triangulateShape(f,g);for(let p=0,m=g.length;p<m;p++){const x=g[p];f=f.concat(x)}for(let p=0,m=f.length;p<m;p++){const x=f[p];s.push(x.x,x.y,0),r.push(0,0,1),a.push(x.x,x.y)}for(let p=0,m=v.length;p<m;p++){const x=v[p],S=x[0]+d,b=x[1]+d,A=x[2]+d;n.push(S,b,A),c+=3}}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}toJSON(){const e=super.toJSON(),t=this.parameters.shapes;return m0(t,e)}static fromJSON(e,t){const n=[];for(let s=0,r=e.shapes.length;s<r;s++){const a=t[e.shapes[s]];n.push(a)}return new Ic(n,e.curveSegments)}}function m0(i,e){if(e.shapes=[],Array.isArray(i))for(let t=0,n=i.length;t<n;t++){const s=i[t];e.shapes.push(s.uuid)}else e.shapes.push(i.uuid);return e}class sn extends pt{constructor(e=1,t=32,n=16,s=0,r=Math.PI*2,a=0,o=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:e,widthSegments:t,heightSegments:n,phiStart:s,phiLength:r,thetaStart:a,thetaLength:o},t=Math.max(3,Math.floor(t)),n=Math.max(2,Math.floor(n));const c=Math.min(a+o,Math.PI);let l=0;const h=[],d=new P,u=new P,f=[],g=[],v=[],p=[];for(let m=0;m<=n;m++){const x=[],S=m/n,b=a+S*o,A=e*Math.cos(b),E=Math.sqrt(e*e-A*A);let y=0;m===0&&a===0?y=.5/t:m===n&&c===Math.PI&&(y=-.5/t);for(let w=0;w<=t;w++){const L=w/t,R=s+L*r;d.x=-E*Math.cos(R),d.y=A,d.z=E*Math.sin(R),g.push(d.x,d.y,d.z),u.copy(d).normalize(),v.push(u.x,u.y,u.z),p.push(L+y,1-S),x.push(l++)}h.push(x)}for(let m=0;m<n;m++)for(let x=0;x<t;x++){const S=h[m][x+1],b=h[m][x],A=h[m+1][x],E=h[m+1][x+1];(m!==0||a>0)&&f.push(S,b,E),(m!==n-1||c<Math.PI)&&f.push(b,A,E)}this.setIndex(f),this.setAttribute("position",new He(g,3)),this.setAttribute("normal",new He(v,3)),this.setAttribute("uv",new He(p,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new sn(e.radius,e.widthSegments,e.heightSegments,e.phiStart,e.phiLength,e.thetaStart,e.thetaLength)}}class Dr extends pt{constructor(e=1,t=.4,n=12,s=48,r=Math.PI*2,a=0,o=Math.PI*2){super(),this.type="TorusGeometry",this.parameters={radius:e,tube:t,radialSegments:n,tubularSegments:s,arc:r,thetaStart:a,thetaLength:o},n=Math.floor(n),s=Math.floor(s);const c=[],l=[],h=[],d=[],u=new P,f=new P,g=new P;for(let v=0;v<=n;v++){const p=a+v/n*o;for(let m=0;m<=s;m++){const x=m/s*r;f.x=(e+t*Math.cos(p))*Math.cos(x),f.y=(e+t*Math.cos(p))*Math.sin(x),f.z=t*Math.sin(p),l.push(f.x,f.y,f.z),u.x=e*Math.cos(x),u.y=e*Math.sin(x),g.subVectors(f,u).normalize(),h.push(g.x,g.y,g.z),d.push(m/s),d.push(v/n)}}for(let v=1;v<=n;v++)for(let p=1;p<=s;p++){const m=(s+1)*v+p-1,x=(s+1)*(v-1)+p-1,S=(s+1)*(v-1)+p,b=(s+1)*v+p;c.push(m,x,b),c.push(x,S,b)}this.setIndex(c),this.setAttribute("position",new He(l,3)),this.setAttribute("normal",new He(h,3)),this.setAttribute("uv",new He(d,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Dr(e.radius,e.tube,e.radialSegments,e.tubularSegments,e.arc,e.thetaStart,e.thetaLength)}}function Us(i){const e={};for(const t in i){e[t]={};for(const n in i[t]){const s=i[t][n];if(Qh(s))s.isRenderTargetTexture?(Le("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),e[t][n]=null):e[t][n]=s.clone();else if(Array.isArray(s))if(Qh(s[0])){const r=[];for(let a=0,o=s.length;a<o;a++)r[a]=s[a].clone();e[t][n]=r}else e[t][n]=s.slice();else e[t][n]=s}}return e}function en(i){const e={};for(let t=0;t<i.length;t++){const n=Us(i[t]);for(const s in n)e[s]=n[s]}return e}function Qh(i){return i&&(i.isColor||i.isMatrix3||i.isMatrix4||i.isVector2||i.isVector3||i.isVector4||i.isTexture||i.isQuaternion)}function g0(i){const e=[];for(let t=0;t<i.length;t++)e.push(i[t].clone());return e}function ef(i){const e=i.getRenderTarget();return e===null?i.outputColorSpace:e.isXRRenderTarget===!0?e.texture.colorSpace:Xe.workingColorSpace}const v0={clone:Us,merge:en};var x0=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,y0=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class fn extends Fi{constructor(e){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=x0,this.fragmentShader=y0,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=Us(e.uniforms),this.uniformsGroups=g0(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this.defaultAttributeValues=Object.assign({},e.defaultAttributeValues),this.index0AttributeName=e.index0AttributeName,this.uniformsNeedUpdate=e.uniformsNeedUpdate,this}toJSON(e){const t=super.toJSON(e);t.glslVersion=this.glslVersion,t.uniforms={};for(const s in this.uniforms){const a=this.uniforms[s].value;a&&a.isTexture?t.uniforms[s]={type:"t",value:a.toJSON(e).uuid}:a&&a.isColor?t.uniforms[s]={type:"c",value:a.getHex()}:a&&a.isVector2?t.uniforms[s]={type:"v2",value:a.toArray()}:a&&a.isVector3?t.uniforms[s]={type:"v3",value:a.toArray()}:a&&a.isVector4?t.uniforms[s]={type:"v4",value:a.toArray()}:a&&a.isMatrix3?t.uniforms[s]={type:"m3",value:a.toArray()}:a&&a.isMatrix4?t.uniforms[s]={type:"m4",value:a.toArray()}:t.uniforms[s]={value:a}}Object.keys(this.defines).length>0&&(t.defines=this.defines),t.vertexShader=this.vertexShader,t.fragmentShader=this.fragmentShader,t.lights=this.lights,t.clipping=this.clipping;const n={};for(const s in this.extensions)this.extensions[s]===!0&&(n[s]=!0);return Object.keys(n).length>0&&(t.extensions=n),t}fromJSON(e,t){if(super.fromJSON(e,t),e.uniforms!==void 0)for(const n in e.uniforms){const s=e.uniforms[n];switch(this.uniforms[n]={},s.type){case"t":this.uniforms[n].value=t[s.value]||null;break;case"c":this.uniforms[n].value=new Te().setHex(s.value);break;case"v2":this.uniforms[n].value=new fe().fromArray(s.value);break;case"v3":this.uniforms[n].value=new P().fromArray(s.value);break;case"v4":this.uniforms[n].value=new vt().fromArray(s.value);break;case"m3":this.uniforms[n].value=new Ne().fromArray(s.value);break;case"m4":this.uniforms[n].value=new Ke().fromArray(s.value);break;default:this.uniforms[n].value=s.value}}if(e.defines!==void 0&&(this.defines=e.defines),e.vertexShader!==void 0&&(this.vertexShader=e.vertexShader),e.fragmentShader!==void 0&&(this.fragmentShader=e.fragmentShader),e.glslVersion!==void 0&&(this.glslVersion=e.glslVersion),e.extensions!==void 0)for(const n in e.extensions)this.extensions[n]=e.extensions[n];return e.lights!==void 0&&(this.lights=e.lights),e.clipping!==void 0&&(this.clipping=e.clipping),this}}class b0 extends fn{constructor(e){super(e),this.isRawShaderMaterial=!0,this.type="RawShaderMaterial"}}class Qi extends Fi{constructor(e){super(),this.isMeshStandardMaterial=!0,this.type="MeshStandardMaterial",this.defines={STANDARD:""},this.color=new Te(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new Te(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=Fl,this.normalScale=new fe(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new On,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.defines={STANDARD:""},this.color.copy(e.color),this.roughness=e.roughness,this.metalness=e.metalness,this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.roughnessMap=e.roughnessMap,this.metalnessMap=e.metalnessMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.envMapIntensity=e.envMapIntensity,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}}class _0 extends Fi{constructor(e){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=zp,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}}class M0 extends Fi{constructor(e){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}}class Nc extends Et{static registerNode(e){this.prototype._lightNode=e}constructor(e,t=1){super(),this.isLight=!0,this.type="Light",this.color=new Te(e),this.intensity=t}copy(e,t){return super.copy(e,t),this.color.copy(e.color),this.intensity=e.intensity,this}toJSON(e){const t=super.toJSON(e);return t.object.color=this.color.getHex(),t.object.intensity=this.intensity,t}}class tf extends Nc{constructor(e,t,n){super(e,n),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(Et.DEFAULT_UP),this.updateMatrix(),this.groundColor=new Te(t)}copy(e,t){return super.copy(e,t),this.groundColor.copy(e.groundColor),this}toJSON(e){const t=super.toJSON(e);return t.object.groundColor=this.groundColor.getHex(),t}}const Ho=new Ke,jh=new P,ed=new P;class S0{constructor(e){this.camera=e,this.intensity=1,this.bias=0,this.biasNode=null,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new fe(512,512),this.mapType=ln,this.map=null,this.mapPass=null,this.matrix=new Ke,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new br,this._frameExtents=new fe(1,1),this._viewportCount=1,this._viewports=[new vt(0,0,1,1)]}getViewportCount(){return this._viewportCount}getCamera(){return this.camera}getFrustum(){return this._frustum}updateMatrices(e){const t=this.camera;jh.setFromMatrixPosition(e.matrixWorld),t.position.copy(jh),ed.setFromMatrixPosition(e.target.matrixWorld),t.lookAt(ed),t.updateMatrixWorld(),this._updateMatrix(t,this.matrix,this._frustum)}_updateMatrix(e,t,n,s){Ho.multiplyMatrices(e.projectionMatrix,e.matrixWorldInverse),n.setFromProjectionMatrix(Ho,e.coordinateSystem,e.reversedDepth);const r=this._frameExtents,a=s?s.z/r.x:1,o=s?s.w/r.y:1,c=s?s.x/r.x:0,l=s?s.y/r.y:0;e.coordinateSystem===xr||e.reversedDepth?t.set(.5*a,0,0,.5*a+c,0,.5*o,0,.5*o+l,0,0,1,0,0,0,0,1):t.set(.5*a,0,0,.5*a+c,0,.5*o,0,.5*o+l,0,0,.5,.5,0,0,0,1),t.multiply(Ho)}getViewport(e){return this._viewports[e]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(e){return this.camera=e.camera.clone(),this.intensity=e.intensity,this.bias=e.bias,this.radius=e.radius,this.autoUpdate=e.autoUpdate,this.needsUpdate=e.needsUpdate,this.normalBias=e.normalBias,this.blurSamples=e.blurSamples,this.mapSize.copy(e.mapSize),this.mapType=e.mapType,this.biasNode=e.biasNode,this}clone(){return new this.constructor().copy(this)}toJSON(){const e={};return e.intensity=this.intensity,e.bias=this.bias,e.normalBias=this.normalBias,e.radius=this.radius,e.blurSamples=this.blurSamples,e.mapSize=this.mapSize.toArray(),e.mapType=this.mapType,e.camera=this.camera.toJSON(!1).object,delete e.camera.matrix,e}}const fa=new P,pa=new vi,Hn=new P;class nf extends Et{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new Ke,this.projectionMatrix=new Ke,this.projectionMatrixInverse=new Ke,this.coordinateSystem=In,this._reversedDepth=!1}get reversedDepth(){return this._reversedDepth}copy(e,t){return super.copy(e,t),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorld.decompose(fa,pa,Hn),Hn.x===1&&Hn.y===1&&Hn.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(fa,pa,Hn.set(1,1,1)).invert()}updateWorldMatrix(e,t,n=!1){super.updateWorldMatrix(e,t,n),this.matrixWorld.decompose(fa,pa,Hn),Hn.x===1&&Hn.y===1&&Hn.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(fa,pa,Hn.set(1,1,1)).invert()}clone(){return new this.constructor().copy(this)}}const wi=new P,td=new fe,nd=new fe;class dn extends nf{constructor(e=50,t=1,n=.1,s=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=n,this.far=s,this.focus=10,this.aspect=t,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){const t=.5*this.getFilmHeight()/e;this.fov=yr*2*Math.atan(t),this.updateProjectionMatrix()}getFocalLength(){const e=Math.tan(ar*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return yr*2*Math.atan(Math.tan(ar*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(e,t,n){wi.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),t.set(wi.x,wi.y).multiplyScalar(-e/wi.z),wi.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),n.set(wi.x,wi.y).multiplyScalar(-e/wi.z)}getViewSize(e,t){return this.getViewBounds(e,td,nd),t.subVectors(nd,td)}setViewOffset(e,t,n,s,r,a){this.aspect=e/t,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=s,this.view.width=r,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=this.near;let t=e*Math.tan(ar*.5*this.fov)/this.zoom,n=2*t,s=this.aspect*n,r=-.5*s;const a=this.view;if(this.view!==null&&this.view.enabled){const c=a.fullWidth,l=a.fullHeight;r+=a.offsetX*s/c,t-=a.offsetY*n/l,s*=a.width/c,n*=a.height/l}const o=this.filmOffset;o!==0&&(r+=e*o/this.getFilmWidth()),this.projectionMatrix.makePerspective(r,r+s,t,t-n,e,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.fov=this.fov,t.object.zoom=this.zoom,t.object.near=this.near,t.object.far=this.far,t.object.focus=this.focus,t.object.aspect=this.aspect,this.view!==null&&(t.object.view=Object.assign({},this.view)),t.object.filmGauge=this.filmGauge,t.object.filmOffset=this.filmOffset,t}}class Uc extends nf{constructor(e=-1,t=1,n=1,s=-1,r=.1,a=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=t,this.top=n,this.bottom=s,this.near=r,this.far=a,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,t,n,s,r,a){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=s,this.view.width=r,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=(this.right-this.left)/(2*this.zoom),t=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,s=(this.top+this.bottom)/2;let r=n-e,a=n+e,o=s+t,c=s-t;if(this.view!==null&&this.view.enabled){const l=(this.right-this.left)/this.view.fullWidth/this.zoom,h=(this.top-this.bottom)/this.view.fullHeight/this.zoom;r+=l*this.view.offsetX,a=r+l*this.view.width,o-=h*this.view.offsetY,c=o-h*this.view.height}this.projectionMatrix.makeOrthographic(r,a,o,c,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.zoom=this.zoom,t.object.left=this.left,t.object.right=this.right,t.object.top=this.top,t.object.bottom=this.bottom,t.object.near=this.near,t.object.far=this.far,this.view!==null&&(t.object.view=Object.assign({},this.view)),t}}class w0 extends S0{constructor(){super(new Uc(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}}class Ya extends Nc{constructor(e,t){super(e,t),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(Et.DEFAULT_UP),this.updateMatrix(),this.target=new Et,this.shadow=new w0}dispose(){super.dispose(),this.shadow.dispose()}copy(e){return super.copy(e),this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}toJSON(e){const t=super.toJSON(e);return t.object.shadow=this.shadow.toJSON(),t.object.target=this.target.uuid,t}}class sf extends Nc{constructor(e,t){super(e,t),this.isAmbientLight=!0,this.type="AmbientLight"}}const bs=-90,_s=1;class Vl extends Et{constructor(e,t,n){super(),this.type="CubeCamera",this.renderTarget=n,this.coordinateSystem=null,this.activeMipmapLevel=0;const s=new dn(bs,_s,e,t);s.layers=this.layers,this.add(s);const r=new dn(bs,_s,e,t);r.layers=this.layers,this.add(r);const a=new dn(bs,_s,e,t);a.layers=this.layers,this.add(a);const o=new dn(bs,_s,e,t);o.layers=this.layers,this.add(o);const c=new dn(bs,_s,e,t);c.layers=this.layers,this.add(c);const l=new dn(bs,_s,e,t);l.layers=this.layers,this.add(l)}updateCoordinateSystem(){const e=this.coordinateSystem,t=this.children.concat(),[n,s,r,a,o,c]=t;for(const l of t)this.remove(l);if(e===In)n.up.set(0,1,0),n.lookAt(1,0,0),s.up.set(0,1,0),s.lookAt(-1,0,0),r.up.set(0,0,-1),r.lookAt(0,1,0),a.up.set(0,0,1),a.lookAt(0,-1,0),o.up.set(0,1,0),o.lookAt(0,0,1),c.up.set(0,1,0),c.lookAt(0,0,-1);else if(e===xr)n.up.set(0,-1,0),n.lookAt(-1,0,0),s.up.set(0,-1,0),s.lookAt(1,0,0),r.up.set(0,0,1),r.lookAt(0,1,0),a.up.set(0,0,-1),a.lookAt(0,-1,0),o.up.set(0,-1,0),o.lookAt(0,0,1),c.up.set(0,-1,0),c.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+e);for(const l of t)this.add(l),l.updateMatrixWorld()}update(e,t){this.parent===null&&this.updateMatrixWorld();const{renderTarget:n,activeMipmapLevel:s}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());const[r,a,o,c,l,h]=this.children,d=e.getRenderTarget(),u=e.getActiveCubeFace(),f=e.getActiveMipmapLevel(),g=e.xr.enabled;e.xr.enabled=!1;const v=n.texture.mipmapsAutoUpdate;n.texture.mipmapsAutoUpdate=!1;let p=!1;e.isWebGLRenderer===!0?p=e.state.buffers.depth.getReversed():p=e.reversedDepthBuffer,e.setRenderTarget(n,0,s),p&&e.autoClear===!1&&e.clearDepth(),e.render(t,r),e.setRenderTarget(n,1,s),p&&e.autoClear===!1&&e.clearDepth(),e.render(t,a),e.setRenderTarget(n,2,s),p&&e.autoClear===!1&&e.clearDepth(),e.render(t,o),e.setRenderTarget(n,3,s),p&&e.autoClear===!1&&e.clearDepth(),e.render(t,c),e.setRenderTarget(n,4,s),p&&e.autoClear===!1&&e.clearDepth(),e.render(t,l),n.texture.mipmapsAutoUpdate=v,e.setRenderTarget(n,5,s),p&&e.autoClear===!1&&e.clearDepth(),e.render(t,h),e.setRenderTarget(d,u,f),e.xr.enabled=g,n.texture.needsPMREMUpdate=!0}}class E0 extends dn{constructor(e=[]){super(),this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=e,this.perCameraFrustumCulled=!1}}const id=new Ke;class A0{constructor(e,t,n=0,s=1/0){this.ray=new no(e,t),this.near=n,this.far=s,this.camera=null,this.layers=new wc,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(e,t){this.ray.set(e,t)}setFromCamera(e,t){t.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(t.matrixWorld),this.ray.direction.set(e.x,e.y,.5).unproject(t).sub(this.ray.origin).normalize(),this.camera=t):t.isOrthographicCamera?(this.ray.origin.set(e.x,e.y,t.projectionMatrix.elements[14]).unproject(t),this.ray.direction.set(0,0,-1).transformDirection(t.matrixWorld),this.camera=t):Ze("Raycaster: Unsupported camera type: "+t.type)}setFromXRController(e){return id.identity().extractRotation(e.matrixWorld),this.ray.origin.setFromMatrixPosition(e.matrixWorld),this.ray.direction.set(0,0,-1).applyMatrix4(id),this}intersectObject(e,t=!0,n=[]){return Wl(e,this,n,t),n.sort(sd),n}intersectObjects(e,t=!0,n=[]){for(let s=0,r=e.length;s<r;s++)Wl(e[s],this,n,t);return n.sort(sd),n}}function sd(i,e){return i.distance-e.distance}function Wl(i,e,t,n){let s=!0;if(i.layers.test(e.layers)&&i.raycast(e,t)===!1&&(s=!1),s===!0&&n===!0){const r=i.children;for(let a=0,o=r.length;a<o;a++)Wl(r[a],e,t,!0)}}function rd(i,e,t,n){const s=T0(n);switch(t){case Au:return i*e;case gc:return i*e/s.components*s.byteLength;case vc:return i*e/s.components*s.byteLength;case Ji:return i*e*2/s.components*s.byteLength;case xc:return i*e*2/s.components*s.byteLength;case Tu:return i*e*3/s.components*s.byteLength;case qn:return i*e*4/s.components*s.byteLength;case yc:return i*e*4/s.components*s.byteLength;case Aa:case Ta:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*8;case Ra:case Ca:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case ol:case cl:return Math.max(i,16)*Math.max(e,8)/4;case al:case ll:return Math.max(i,8)*Math.max(e,8)/2;case hl:case dl:case fl:case pl:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*8;case ul:case ka:case ml:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case gl:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case vl:return Math.floor((i+4)/5)*Math.floor((e+3)/4)*16;case xl:return Math.floor((i+4)/5)*Math.floor((e+4)/5)*16;case yl:return Math.floor((i+5)/6)*Math.floor((e+4)/5)*16;case bl:return Math.floor((i+5)/6)*Math.floor((e+5)/6)*16;case _l:return Math.floor((i+7)/8)*Math.floor((e+4)/5)*16;case Ml:return Math.floor((i+7)/8)*Math.floor((e+5)/6)*16;case Sl:return Math.floor((i+7)/8)*Math.floor((e+7)/8)*16;case wl:return Math.floor((i+9)/10)*Math.floor((e+4)/5)*16;case El:return Math.floor((i+9)/10)*Math.floor((e+5)/6)*16;case Al:return Math.floor((i+9)/10)*Math.floor((e+7)/8)*16;case Tl:return Math.floor((i+9)/10)*Math.floor((e+9)/10)*16;case Rl:return Math.floor((i+11)/12)*Math.floor((e+9)/10)*16;case Cl:return Math.floor((i+11)/12)*Math.floor((e+11)/12)*16;case Pl:case Ll:case Dl:return Math.ceil(i/4)*Math.ceil(e/4)*16;case Il:case Nl:return Math.ceil(i/4)*Math.ceil(e/4)*8;case Ba:case Ul:return Math.ceil(i/4)*Math.ceil(e/4)*16}throw new Error(`Unable to determine texture byte length for ${t} format.`)}function T0(i){switch(i){case ln:case Mu:return{byteLength:1,components:1};case vr:case Su:case Jn:return{byteLength:2,components:1};case pc:case mc:return{byteLength:2,components:4};case Kn:case fc:case Dn:return{byteLength:4,components:1};case wu:case Eu:return{byteLength:4,components:3}}throw new Error(`THREE.TextureUtils: Unknown texture type ${i}.`)}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:dc}}));typeof window<"u"&&(window.__THREE__?Le("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=dc);function rf(){let i=null,e=!1,t=null,n=null;function s(r,a){n=i.requestAnimationFrame(s),t(r,a)}return{start:function(){e!==!0&&t!==null&&i!==null&&(n=i.requestAnimationFrame(s),e=!0)},stop:function(){i!==null&&i.cancelAnimationFrame(n),e=!1},setAnimationLoop:function(r){t=r},setContext:function(r){i=r}}}function R0(i){const e=new WeakMap;function t(o,c){const l=o.array,h=o.usage,d=l.byteLength,u=i.createBuffer();i.bindBuffer(c,u),i.bufferData(c,l,h),o.onUploadCallback();let f;if(l instanceof Float32Array)f=i.FLOAT;else if(typeof Float16Array<"u"&&l instanceof Float16Array)f=i.HALF_FLOAT;else if(l instanceof Uint16Array)o.isFloat16BufferAttribute?f=i.HALF_FLOAT:f=i.UNSIGNED_SHORT;else if(l instanceof Int16Array)f=i.SHORT;else if(l instanceof Uint32Array)f=i.UNSIGNED_INT;else if(l instanceof Int32Array)f=i.INT;else if(l instanceof Int8Array)f=i.BYTE;else if(l instanceof Uint8Array)f=i.UNSIGNED_BYTE;else if(l instanceof Uint8ClampedArray)f=i.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+l);return{buffer:u,type:f,bytesPerElement:l.BYTES_PER_ELEMENT,version:o.version,size:d}}function n(o,c,l){const h=c.array,d=c.updateRanges;if(i.bindBuffer(l,o),d.length===0)i.bufferSubData(l,0,h);else{d.sort((f,g)=>f.start-g.start);let u=0;for(let f=1;f<d.length;f++){const g=d[u],v=d[f];v.start<=g.start+g.count+1?g.count=Math.max(g.count,v.start+v.count-g.start):(++u,d[u]=v)}d.length=u+1;for(let f=0,g=d.length;f<g;f++){const v=d[f];i.bufferSubData(l,v.start*h.BYTES_PER_ELEMENT,h,v.start,v.count)}c.clearUpdateRanges()}c.onUploadCallback()}function s(o){return o.isInterleavedBufferAttribute&&(o=o.data),e.get(o)}function r(o){o.isInterleavedBufferAttribute&&(o=o.data);const c=e.get(o);c&&(i.deleteBuffer(c.buffer),e.delete(o))}function a(o,c){if(o.isInterleavedBufferAttribute&&(o=o.data),o.isGLBufferAttribute){const h=e.get(o);(!h||h.version<o.version)&&e.set(o,{buffer:o.buffer,type:o.type,bytesPerElement:o.elementSize,version:o.version});return}const l=e.get(o);if(l===void 0)e.set(o,t(o,c));else if(l.version<o.version){if(l.size!==o.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");n(l.buffer,o,c),l.version=o.version}}return{get:s,remove:r,update:a}}var C0=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,P0=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,L0=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,D0=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,I0=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,N0=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,U0=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,F0=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,O0=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec4 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 );
	}
#endif`,k0=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,B0=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,z0=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,G0=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,H0=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,V0=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,W0=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,$0=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,q0=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,X0=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,Y0=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#endif`,K0=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#endif`,J0=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec4 vColor;
#endif`,Z0=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec4( 1.0 );
#endif
#ifdef USE_COLOR_ALPHA
	vColor *= color;
#elif defined( USE_COLOR )
	vColor.rgb *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.rgb *= instanceColor.rgb;
#endif
#ifdef USE_BATCHING_COLOR
	vColor *= getBatchingColor( getIndirectIndex( gl_DrawID ) );
#endif`,Q0=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
#define inverseTransformDirection transformDirectionByInverseViewMatrix
vec3 transformNormalByInverseViewMatrix( in vec3 normal, in mat4 viewMatrix ) {
	return normalize( ( vec4( normal, 0.0 ) * viewMatrix ).xyz );
}
vec3 transformDirectionByInverseViewMatrix( in vec3 dir, in mat4 viewMatrix ) {
	return normalize( ( vec4( dir, 0.0 ) * viewMatrix ).xyz );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,j0=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
#endif`,eg=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,tg=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,ng=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,ig=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,sg="gl_FragColor = linearToOutputTexel( gl_FragColor );",rg=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,ag=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * reflectVec );
		#ifdef ENVMAP_BLENDING_MULTIPLY
			outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_MIX )
			outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_ADD )
			outgoingLight += envColor.xyz * specularStrength * reflectivity;
		#endif
	#endif
#endif`,og=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform mat3 envMapRotation;
	uniform samplerCube envMap;
	#ifdef ENVMAP_TYPE_PMREM
		float roughnessToMip( const in float roughness ) {
			float r = clamp( roughness, 0.0, 1.0 );
			return ENVMAP_MAX_LOD * r * ( 2.0 - r );
		}
	#endif
#endif`,lg=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,cg=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,hg=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,dg=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,ug=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,fg=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,pg=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,mg=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,gg=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,vg=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,xg=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,yg=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_SUN_LIGHTS > 0
	struct SunLight {
		vec3 direction;
		vec3 color;
	};
	uniform SunLight sunLights[ NUM_SUN_LIGHTS ];
	void getSunLightInfo( const in SunLight sunLight, out IncidentLight light ) {
		light.color = sunLight.color;
		light.direction = sunLight.direction;
		light.visible = true;
	}
#endif
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif
#include <lightprobes_pars_fragment>`,bg=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_PMREM
			vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
			vec4 envMapColor = textureLod( envMap, envMapRotation * worldNormal, ENVMAP_MAX_LOD );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_PMREM
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, pow4( roughness ) ) );
			reflectVec = transformDirectionByInverseViewMatrix( reflectVec, viewMatrix );
			vec4 envMapColor = textureLod( envMap, envMapRotation * reflectVec, roughnessToMip( roughness ) );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_RETROREFLECTION
		vec3 getIBLRetroRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
			#ifdef ENVMAP_TYPE_PMREM
				vec3 retroVec = normalize( mix( viewDir, normal, pow4( roughness ) ) );
				retroVec = transformDirectionByInverseViewMatrix( retroVec, viewMatrix );
				vec4 envMapColor = textureLod( envMap, envMapRotation * retroVec, roughnessToMip( roughness ) );
				return envMapColor.rgb * envMapIntensity;
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_PMREM
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
		#ifdef USE_RETROREFLECTION
			vec3 getIBLAnisotropyRetroRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
				#ifdef ENVMAP_TYPE_PMREM
					vec3 bentNormal = cross( bitangent, viewDir );
					bentNormal = normalize( cross( bentNormal, bitangent ) );
					bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
					return getIBLRetroRadiance( viewDir, bentNormal, roughness );
				#else
					return vec3( 0.0 );
				#endif
			}
		#endif
	#endif
#endif`,_g=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,Mg=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,Sg=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,wg=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,Eg=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.diffuseContribution = diffuseColor.rgb * ( 1.0 - metalnessFactor );
material.metalness = metalnessFactor;
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.045 );
material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef USE_DIFFUSE_ROUGHNESS
	float diffuseRoughnessFactor = diffuseRoughness;
	#ifdef USE_DIFFUSE_ROUGHNESSMAP
		diffuseRoughnessFactor *= texture2D( diffuseRoughnessMap, vDiffuseRoughnessMapUv ).r;
	#endif
	material.diffuseRoughness = saturate( diffuseRoughnessFactor );
#endif
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor;
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = vec3( 0.04 );
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.045 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_RETROREFLECTION
	material.retroreflectivity = retroreflectivity;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.0001, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,Ag=`uniform sampler2D dfgLUT;
struct PhysicalMaterial {
	vec3 diffuseColor;
	vec3 diffuseContribution;
	vec3 specularColor;
	vec3 specularColorBlended;
	float roughness;
	float metalness;
	float specularF90;
	float dispersion;
	vec2 dfg;
	vec3 multiScatteringCompensation;
	#ifdef USE_DIFFUSE_ROUGHNESS
		float diffuseRoughness;
	#endif
	#ifdef USE_RETROREFLECTION
		float retroreflectivity;
	#endif
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0Dielectric;
		vec3 iridescenceF0Metallic;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
#ifdef USE_DIFFUSE_ROUGHNESS
	const float EON_EPSILON = 1e-7;
	float FON_DirectionalAlbedo( const in float mu, const in float roughness, const in float A ) {
		float muComp = 1.0 - mu;
		float gOverPi = muComp * ( 0.0571085289 + muComp * ( 0.491881867 + muComp * ( - 0.332181442 + muComp * 0.0714429953 ) ) );
		return A * ( 1.0 + roughness * gOverPi );
	}
	vec3 BRDF_EON( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 diffuseColor, const in float roughness ) {
		vec3 rho = saturate( diffuseColor );
		if ( roughness <= EON_EPSILON ) return BRDF_Lambert( rho );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float s = dot( lightDir, viewDir ) - dotNL * dotNV;
		float sOverT = ( s > 0.0 ) ? s / max( max( dotNL, dotNV ), EON_EPSILON ) : s;
		float A = 1.0 / ( 1.0 + ( 0.5 - 2.0 / ( 3.0 * PI ) ) * roughness );
		vec3 singleScatter = rho * RECIPROCAL_PI * A * ( 1.0 + roughness * sOverT );
		float averageAlbedo = A * ( 1.0 + ( 2.0 / 3.0 - 28.0 / ( 15.0 * PI ) ) * roughness );
		float albedoV = FON_DirectionalAlbedo( dotNV, roughness, A );
		float albedoL = FON_DirectionalAlbedo( dotNL, roughness, A );
		vec3 rhoMultiScatter = rho * rho * averageAlbedo / max( vec3( EON_EPSILON ), vec3( 1.0 ) - rho * ( 1.0 - averageAlbedo ) );
		vec3 multiScatter = rhoMultiScatter * RECIPROCAL_PI
			* max( EON_EPSILON, 1.0 - albedoV )
			* max( EON_EPSILON, 1.0 - albedoL )
			/ max( EON_EPSILON, 1.0 - averageAlbedo );
		return singleScatter + multiScatter;
	}
	vec3 EON_DirectionalAlbedo( const in vec3 diffuseColor, const in float roughness, const in float dotNV ) {
		vec3 rho = saturate( diffuseColor );
		if ( roughness <= EON_EPSILON ) return rho;
		float A = 1.0 / ( 1.0 + ( 0.5 - 2.0 / ( 3.0 * PI ) ) * roughness );
		float directionalAlbedo = FON_DirectionalAlbedo( dotNV, roughness, A );
		float averageAlbedo = A * ( 1.0 + ( 2.0 / 3.0 - 28.0 / ( 15.0 * PI ) ) * roughness );
		vec3 rhoMultiScatter = rho * rho * averageAlbedo / max( vec3( EON_EPSILON ), vec3( 1.0 ) - rho * ( 1.0 - averageAlbedo ) );
		return rho * directionalAlbedo + rhoMultiScatter * ( 1.0 - directionalAlbedo );
	}
#endif
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		return 0.5 / max( gv + gl, EPSILON );
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = max( material.clearcoatRoughness, 0.045 );
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColorBlended;
	float f90 = material.specularF90;
	float roughness = max( material.roughness, 0.045 );
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float alphaT = max( material.alphaT, alpha );
		float V = V_GGX_SmithCorrelated_Anisotropic( alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transpose( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float rInv = 1.0 / ( roughness + 0.1 );
	float a = -1.9362 + 1.0678 * roughness + 0.4573 * r2 - 0.8469 * rInv;
	float b = -0.6014 + 0.5538 * roughness - 0.4670 * r2 - 0.1255 * rInv;
	float DG = exp( a * dotNV + b );
	return saturate( DG );
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec2 fab, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec2 fab, const in vec3 specularColor, const in float specularF90, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColorBlended * t2.x + ( material.specularF90 - material.specularColorBlended ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseContribution * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
		#ifdef USE_CLEARCOAT
			vec3 Ncc = geometryClearcoatNormal;
			vec2 uvClearcoat = LTC_Uv( Ncc, viewDir, material.clearcoatRoughness );
			vec4 t1Clearcoat = texture2D( ltc_1, uvClearcoat );
			vec4 t2Clearcoat = texture2D( ltc_2, uvClearcoat );
			mat3 mInvClearcoat = mat3(
				vec3( t1Clearcoat.x, 0, t1Clearcoat.y ),
				vec3(             0, 1,             0 ),
				vec3( t1Clearcoat.z, 0, t1Clearcoat.w )
			);
			vec3 fresnelClearcoat = material.clearcoatF0 * t2Clearcoat.x + ( material.clearcoatF90 - material.clearcoatF0 ) * t2Clearcoat.y;
			clearcoatSpecularDirect += lightColor * fresnelClearcoat * LTC_Evaluate( Ncc, viewDir, position, mInvClearcoat, rectCoords );
		#endif
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
 
 		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
 
 		float sheenAlbedoV = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
 		float sheenAlbedoL = IBLSheenBRDF( geometryNormal, directLight.direction, material.sheenRoughness );
 
 		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * max( sheenAlbedoV, sheenAlbedoL );
 
 		irradiance *= sheenEnergyComp;
 
 	#endif
	vec3 specularBRDF = BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	#ifdef USE_RETROREFLECTION
		vec3 retroViewDir = reflect( - geometryViewDir, geometryNormal );
		vec3 retroSpecularBRDF = BRDF_GGX( directLight.direction, retroViewDir, geometryNormal, material );
		specularBRDF = mix( specularBRDF, retroSpecularBRDF, saturate( material.retroreflectivity ) );
	#endif
	reflectedLight.directSpecular += irradiance * specularBRDF * material.multiScatteringCompensation;
	vec3 halfDir = normalize( directLight.direction + geometryViewDir );
	float dotVH = saturate( dot( geometryViewDir, halfDir ) );
	vec3 F = F_Schlick( material.specularColor, material.specularF90, dotVH );
	#ifdef USE_RETROREFLECTION
		vec3 retroHalfDir = normalize( directLight.direction + retroViewDir );
		float dotRetroVH = saturate( dot( retroViewDir, retroHalfDir ) );
		vec3 retroF = F_Schlick( material.specularColor, material.specularF90, dotRetroVH );
		F = mix( F, retroF, saturate( material.retroreflectivity ) );
	#endif
	#ifdef USE_DIFFUSE_ROUGHNESS
		vec3 diffuseBRDF = BRDF_EON( directLight.direction, geometryViewDir, geometryNormal, material.diffuseColor, material.diffuseRoughness ) * ( 1.0 - material.metalness );
	#else
		vec3 diffuseBRDF = BRDF_Lambert( material.diffuseContribution );
	#endif
	reflectedLight.directDiffuse += irradiance * diffuseBRDF * ( 1.0 - F );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( material.dfg, material.specularColor, material.specularF90, material.iridescence, material.iridescenceF0Dielectric, singleScattering, multiScattering );
	#else
		computeMultiscattering( material.dfg, material.specularColor, material.specularF90, singleScattering, multiScattering );
	#endif
	#ifdef USE_DIFFUSE_ROUGHNESS
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		vec3 diffuseAlbedo = EON_DirectionalAlbedo( material.diffuseColor, material.diffuseRoughness, dotNV ) * ( 1.0 - material.metalness );
		vec3 diffuse = irradiance * RECIPROCAL_PI * diffuseAlbedo * ( 1.0 - singleScattering - multiScattering );
	#else
		vec3 diffuse = irradiance * BRDF_Lambert( material.diffuseContribution ) * ( 1.0 - singleScattering - multiScattering );
	#endif
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		sheenSpecularIndirect += irradiance * material.sheenColor * sheenAlbedo * RECIPROCAL_PI;
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		diffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectDiffuse += diffuse;
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness ) * RECIPROCAL_PI;
 	#endif
	vec3 singleScatteringDielectric = vec3( 0.0 );
	vec3 multiScatteringDielectric = vec3( 0.0 );
	vec3 singleScatteringMetallic = vec3( 0.0 );
	vec3 multiScatteringMetallic = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( material.dfg, material.specularColor, material.specularF90, material.iridescence, material.iridescenceF0Dielectric, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscatteringIridescence( material.dfg, material.diffuseColor, material.specularF90, material.iridescence, material.iridescenceF0Metallic, singleScatteringMetallic, multiScatteringMetallic );
	#else
		computeMultiscattering( material.dfg, material.specularColor, material.specularF90, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscattering( material.dfg, material.diffuseColor, material.specularF90, singleScatteringMetallic, multiScatteringMetallic );
	#endif
	vec3 singleScattering = mix( singleScatteringDielectric, singleScatteringMetallic, material.metalness );
	vec3 multiScattering = mix( multiScatteringDielectric, multiScatteringMetallic, material.metalness );
	vec3 totalScatteringDielectric = singleScatteringDielectric + multiScatteringDielectric;
	#ifdef USE_DIFFUSE_ROUGHNESS
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		vec3 diffuse = EON_DirectionalAlbedo( material.diffuseColor, material.diffuseRoughness, dotNV ) * ( 1.0 - material.metalness ) * ( 1.0 - totalScatteringDielectric );
	#else
		vec3 diffuse = material.diffuseContribution * ( 1.0 - totalScatteringDielectric );
	#endif
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	vec3 indirectSpecular = radiance * singleScattering;
	indirectSpecular += multiScattering * cosineWeightedIrradiance;
	vec3 indirectDiffuse = diffuse * cosineWeightedIrradiance;
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		indirectSpecular *= sheenEnergyComp;
		indirectDiffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectSpecular += indirectSpecular;
	reflectedLight.indirectDiffuse += indirectDiffuse;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,Tg=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		vec3 iridescenceFresnelDielectric = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		vec3 iridescenceFresnelMetallic = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.diffuseColor );
		material.iridescenceFresnel = mix( iridescenceFresnelDielectric, iridescenceFresnelMetallic, material.metalness );
		material.iridescenceF0Dielectric = Schlick_to_F0( iridescenceFresnelDielectric, 1.0, dotNVi );
		material.iridescenceF0Metallic = Schlick_to_F0( iridescenceFresnelMetallic, 1.0, dotNVi );
	}
#endif
#ifdef STANDARD
	float dotNVms = saturate( dot( geometryNormal, geometryViewDir ) );
	material.dfg = texture2D( dfgLUT, vec2( material.roughness, dotNVms ) ).rg;
	#if ( NUM_SUN_LIGHTS > 0 || NUM_DIR_LIGHTS > 0 || NUM_POINT_LIGHTS > 0 || NUM_SPOT_LIGHTS > 0 )
		float EssMs = material.dfg.x + material.dfg.y;
		material.multiScatteringCompensation = 1.0 + material.specularColorBlended * ( 1.0 / EssMs - 1.0 );
	#endif
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS ) && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SUN_LIGHTS > 0 ) && defined( RE_Direct )
	SunLight sunLight;
	#if defined( USE_SHADOWMAP ) && NUM_SUN_LIGHT_SHADOWS > 0
	SunLightShadow sunLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SUN_LIGHTS; i ++ ) {
		sunLight = sunLights[ i ];
		getSunLightInfo( sunLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SUN_LIGHT_SHADOWS )
		sunLightShadow = sunLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getSunShadow( sunShadowMap[ i ], sunLightShadow, UNROLLED_LOOP_INDEX ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_LIGHT_PROBE_GRIDS > 0
		vec3 probeWorldPos = ( ( vec4( geometryPosition, 1.0 ) - viewMatrix[ 3 ] ) * viewMatrix ).xyz;
		vec3 probeWorldNormal = transformNormalByInverseViewMatrix( geometryNormal, viewMatrix );
		int probeGrid = - 1;
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_LIGHT_PROBE_GRIDS; i ++ ) {
			if ( isInsideLightProbeGrid( probeWorldPos, probeWorldNormal, probesMin[ i ], probesMax[ i ], probesResolution[ i ] ) ) probeGrid = UNROLLED_LOOP_INDEX;
		}
		#pragma unroll_loop_end
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_LIGHT_PROBE_GRIDS; i ++ ) {
			if ( probeGrid == UNROLLED_LOOP_INDEX ) irradiance += getLightProbeGridIrradiance( probesSH[ i ], probesMin[ i ], probesMax[ i ], probesResolution[ i ], probeWorldPos, probeWorldNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,Rg=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( ENVMAP_TYPE_PMREM )
		#if defined( STANDARD ) || defined( LAMBERT ) || defined( PHONG )
			iblIrradiance += getIBLIrradiance( geometryNormal );
		#endif
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		vec3 iblRadiance = getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		vec3 iblRadiance = getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_RETROREFLECTION
		#ifdef USE_ANISOTROPY
			vec3 retroIBLRadiance = getIBLAnisotropyRetroRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
		#else
			vec3 retroIBLRadiance = getIBLRetroRadiance( geometryViewDir, geometryNormal, material.roughness );
		#endif
		iblRadiance = mix( iblRadiance, retroIBLRadiance, saturate( material.retroreflectivity ) );
	#endif
	radiance += iblRadiance;
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,Cg=`#if defined( RE_IndirectDiffuse )
	#if defined( LAMBERT ) || defined( PHONG )
		irradiance += iblIrradiance;
	#endif
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,Pg=`#if NUM_LIGHT_PROBE_GRIDS > 0
uniform highp sampler3D probesSH[ NUM_LIGHT_PROBE_GRIDS ];
uniform vec3 probesMin[ NUM_LIGHT_PROBE_GRIDS ];
uniform vec3 probesMax[ NUM_LIGHT_PROBE_GRIDS ];
uniform vec3 probesResolution[ NUM_LIGHT_PROBE_GRIDS ];
bool isInsideLightProbeGrid( vec3 worldPos, vec3 worldNormal, vec3 probesMin, vec3 probesMax, vec3 probesResolution ) {
	vec3 spacing = ( probesMax - probesMin ) / probesResolution;
	vec3 samplePos = worldPos + worldNormal * spacing * 0.5;
	vec3 margin = spacing * 0.01;
	return all( greaterThanEqual( samplePos, probesMin - margin ) ) && all( lessThanEqual( samplePos, probesMax + margin ) );
}
vec3 getLightProbeGridIrradiance( highp sampler3D probesSH, vec3 probesMin, vec3 probesMax, vec3 probesResolution, vec3 worldPos, vec3 worldNormal ) {
	vec3 res = probesResolution;
	vec3 gridRange = probesMax - probesMin;
	vec3 probeSpacing = gridRange / res;
	vec3 samplePos = worldPos + worldNormal * probeSpacing * 0.5;
	vec3 uvw = clamp( ( samplePos - probesMin ) / gridRange, 0.5 / res, 1.0 - 0.5 / res );
	float nz          = res.z;
	float paddedSlices = nz + 2.0;
	float atlasDepth  = 7.0 * paddedSlices;
	float uvZBase     = uvw.z * nz + 1.0;
	vec4 s0 = texture( probesSH, vec3( uvw.xy, ( uvZBase                       ) / atlasDepth ) );
	vec4 s1 = texture( probesSH, vec3( uvw.xy, ( uvZBase +       paddedSlices   ) / atlasDepth ) );
	vec4 s2 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 2.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s3 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 3.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s4 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 4.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s5 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 5.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s6 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 6.0 * paddedSlices   ) / atlasDepth ) );
	vec3 c0 = s0.xyz;
	vec3 c1 = vec3( s0.w, s1.xy );
	vec3 c2 = vec3( s1.zw, s2.x );
	vec3 c3 = s2.yzw;
	vec3 c4 = s3.xyz;
	vec3 c5 = vec3( s3.w, s4.xy );
	vec3 c6 = vec3( s4.zw, s5.x );
	vec3 c7 = s5.yzw;
	vec3 c8 = s6.xyz;
	float x = worldNormal.x, y = worldNormal.y, z = worldNormal.z;
	vec3 result = c0 * 0.886227;
	result += c1 * 2.0 * 0.511664 * y;
	result += c2 * 2.0 * 0.511664 * z;
	result += c3 * 2.0 * 0.511664 * x;
	result += c4 * 2.0 * 0.429043 * x * y;
	result += c5 * 2.0 * 0.429043 * y * z;
	result += c6 * ( 0.743125 * z * z - 0.247708 );
	result += c7 * 2.0 * 0.429043 * x * z;
	result += c8 * 0.429043 * ( x * x - y * y );
	return max( result, vec3( 0.0 ) );
}
#endif`,Lg=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,Dg=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,Ig=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,Ng=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,Ug=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,Fg=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,Og=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,kg=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Bg=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,zg=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,Gg=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,Hg=`#if defined( USE_MORPHCOLORS )
	#if defined( USE_COLOR_ALPHA )
		vColor *= morphTargetBaseInfluence;
	#elif defined( USE_COLOR )
		vColor.rgb *= morphTargetBaseInfluence;
	#endif
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor.rgb += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,Vg=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,Wg=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,$g=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,qg=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#ifdef DOUBLE_SIDED
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#ifdef DOUBLE_SIDED
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,Xg=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#if defined( USE_PACKED_NORMALMAP )
		mapN = vec3( mapN.xy, sqrt( saturate( 1.0 - dot( mapN.xy, mapN.xy ) ) ) );
	#endif
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,Yg=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Kg=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Jg=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
		#ifdef FLIP_SIDED
			vBitangent = - vBitangent;
		#endif
	#endif
#endif`,Zg=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,Qg=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,jg=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,ev=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,tv=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,nv=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,iv=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	#ifdef USE_REVERSED_DEPTH_BUFFER
	
		return depth * ( far - near ) - far;
	#else
		return depth * ( near - far ) - near;
	#endif
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	
	#ifdef USE_REVERSED_DEPTH_BUFFER
		return ( near * far ) / ( ( near - far ) * depth - near );
	#else
		return ( near * far ) / ( ( far - near ) * depth - far );
	#endif
}`,sv=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,rv=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,av=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,ov=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,lv=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,cv=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,hv=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
		#define SUN_LIGHT_CASCADES 2
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow sunShadowMap[ NUM_SUN_LIGHT_SHADOWS ];
		#else
			uniform sampler2D sunShadowMap[ NUM_SUN_LIGHT_SHADOWS ];
		#endif
		uniform mat4 sunShadowMatrix[ NUM_SUN_LIGHT_SHADOWS * SUN_LIGHT_CASCADES ];
		uniform vec4 sunShadowCascade[ NUM_SUN_LIGHT_SHADOWS * SUN_LIGHT_CASCADES ];
		varying vec4 vSunShadowWorldPosition;
		varying vec3 vSunShadowWorldNormal;
		struct SunLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SunLightShadow sunLightShadows[ NUM_SUN_LIGHT_SHADOWS ];
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#else
			uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#endif
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#else
			uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#endif
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform samplerCubeShadow pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#elif defined( SHADOWMAP_TYPE_BASIC )
			uniform samplerCube pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#endif
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float interleavedGradientNoise( vec2 position ) {
			return fract( 52.9829189 * fract( dot( position, vec2( 0.06711056, 0.00583715 ) ) ) );
		}
		vec2 vogelDiskSample( int sampleIndex, int samplesCount, float phi ) {
			const float goldenAngle = 2.399963229728653;
			float r = sqrt( ( float( sampleIndex ) + 0.5 ) / float( samplesCount ) );
			float theta = float( sampleIndex ) * goldenAngle + phi;
			return vec2( cos( theta ), sin( theta ) ) * r;
		}
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float getShadow( sampler2DShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
				vec2 radius = shadowRadius * texelSize;
				float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
				shadow = (
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 0, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 1, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 2, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 3, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 4, 5, phi ) * radius, shadowCoord.z ) )
				) * 0.2;
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#elif defined( SHADOWMAP_TYPE_VSM )
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 distribution = texture2D( shadowMap, shadowCoord.xy ).rg;
				float mean = distribution.x;
				float variance = distribution.y * distribution.y;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					float hard_shadow = step( mean, shadowCoord.z );
				#else
					float hard_shadow = step( shadowCoord.z, mean );
				#endif
				
				if ( hard_shadow == 1.0 ) {
					shadow = 1.0;
				} else {
					variance = max( variance, 0.0000001 );
					float d = shadowCoord.z - mean;
					float p_max = variance / ( variance + d * d );
					p_max = clamp( ( p_max - 0.3 ) / 0.65, 0.0, 1.0 );
					shadow = max( hard_shadow, p_max );
				}
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#else
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				float depth = texture2D( shadowMap, shadowCoord.xy ).r;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					shadow = step( depth, shadowCoord.z );
				#else
					shadow = step( shadowCoord.z, depth );
				#endif
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#endif
	#if NUM_SUN_LIGHT_SHADOWS > 0
		float getSunShadow(
			#if defined( SHADOWMAP_TYPE_PCF )
				sampler2DShadow shadowMap,
			#else
				sampler2D shadowMap,
			#endif
			SunLightShadow sunLightShadow,
			int shadowIndex
		) {
			vec4 shadowWorldPosition = vec4( vSunShadowWorldPosition.xyz + vSunShadowWorldNormal * sunLightShadow.shadowNormalBias, 1.0 );
			float viewDepth = vSunShadowWorldPosition.w;
			int cascadeOffset = shadowIndex * SUN_LIGHT_CASCADES;
			float shadow = 1.0;
			for ( int i = SUN_LIGHT_CASCADES - 1; i >= 0; i -- ) {
				vec4 cascade = sunShadowCascade[ cascadeOffset + i ];
				if ( viewDepth >= cascade.x && viewDepth < cascade.y ) {
					float cascadeShadow = getShadow(
						shadowMap,
						sunLightShadow.shadowMapSize,
						sunLightShadow.shadowIntensity,
						sunLightShadow.shadowBias,
						sunLightShadow.shadowRadius,
						sunShadowMatrix[ cascadeOffset + i ] * shadowWorldPosition
					);
					shadow = mix( cascadeShadow, shadow, smoothstep( cascade.z, cascade.y, viewDepth ) );
				}
			}
			return shadow;
		}
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	#if defined( SHADOWMAP_TYPE_PCF )
	float getPointShadow( samplerCubeShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 bd3D = normalize( lightToPosition );
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			float lightDistance = length( lightToPosition );
			float depthRange = shadowCameraFar - shadowCameraNear;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				float depthA = - shadowCameraNear / depthRange - shadowBias;
				float depthB = shadowCameraNear * shadowCameraFar / ( depthRange * lightDistance );
			#else
				float depthA = shadowCameraFar / depthRange + shadowBias;
				float depthB = - shadowCameraNear * shadowCameraFar / ( depthRange * lightDistance );
			#endif
			float texelSize = shadowRadius / shadowMapSize.x;
			vec3 absDir = abs( bd3D );
			vec3 tangent = absDir.x > absDir.z ? vec3( 0.0, 1.0, 0.0 ) : vec3( 1.0, 0.0, 0.0 );
			tangent = normalize( cross( bd3D, tangent ) );
			vec3 bitangent = cross( bd3D, tangent );
			float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
			shadow = 0.0;
			for ( int i = 0; i < 5; i ++ ) {
				vec2 offset = vogelDiskSample( i, 5, phi );
				vec3 direction = bd3D + ( tangent * offset.x + bitangent * offset.y ) * texelSize;
				vec3 absDirection = abs( direction );
				float dp = depthA + depthB / max( max( absDirection.x, absDirection.y ), absDirection.z );
				shadow += texture( shadowMap, vec4( direction, dp ) );
			}
			shadow *= 0.2;
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#elif defined( SHADOWMAP_TYPE_BASIC )
	float getPointShadow( samplerCube shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			float depth = textureCube( shadowMap, bd3D ).r;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				depth = 1.0 - depth;
			#endif
			shadow = step( dp, depth );
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#endif
	#endif
#endif`,dv=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
		varying vec4 vSunShadowWorldPosition;
		varying vec3 vSunShadowWorldNormal;
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,uv=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_SUN_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	#ifdef HAS_NORMAL
		vec3 shadowWorldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
	#else
		vec3 shadowWorldNormal = vec3( 0.0 );
	#endif
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_SUN_LIGHT_SHADOWS > 0
		vSunShadowWorldPosition = vec4( worldPosition.xyz, - mvPosition.z );
		vSunShadowWorldNormal = shadowWorldNormal;
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,fv=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
	SunLightShadow sunLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SUN_LIGHT_SHADOWS; i ++ ) {
		sunLight = sunLightShadows[ i ];
		shadow *= receiveShadow ? getSunShadow( sunShadowMap[ i ], sunLight, UNROLLED_LOOP_INDEX ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0 && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,pv=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,mv=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,gv=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,vv=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,xv=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,yv=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,bv=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,_v=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,Mv=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseContribution, material.specularColorBlended, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,Sv=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,wv=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_DIFFUSE_ROUGHNESSMAP
	varying vec2 vDiffuseRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Ev=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_DIFFUSE_ROUGHNESSMAP
	uniform mat3 diffuseRoughnessMapTransform;
	varying vec2 vDiffuseRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Av=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DIFFUSE_ROUGHNESSMAP
	vDiffuseRoughnessMapUv = ( diffuseRoughnessMapTransform * vec3( DIFFUSE_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,Tv=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const Rv=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,Cv=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Pv=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Lv=`uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <envmap_common_pars_fragment>
void main() {
	#ifdef ENVMAP_TYPE_PMREM
		vec4 texColor = textureLod( envMap, backgroundRotation * vWorldDirection, roughnessToMip( backgroundBlurriness ) );
	#else
		vec4 texColor = textureCube( envMap, backgroundRotation * vWorldDirection );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Dv=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Iv=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Nv=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,Uv=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,Fv=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,Ov=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = vec4( dist, 0.0, 0.0, 1.0 );
}`,kv=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,Bv=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,zv=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Gv=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Hv=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,Vv=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Wv=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,$v=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,qv=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,Xv=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Yv=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,Kv=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( normalize( normal ) * 0.5 + 0.5, diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,Jv=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Zv=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Qv=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,jv=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DIFFUSE_ROUGHNESS
	uniform float diffuseRoughness;
	#ifdef USE_DIFFUSE_ROUGHNESSMAP
		uniform sampler2D diffuseRoughnessMap;
	#endif
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_RETROREFLECTION
	uniform float retroreflectivity;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
 
		outgoingLight = outgoingLight + sheenSpecularDirect + sheenSpecularIndirect;
 
 	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,ex=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,tx=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,nx=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,ix=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,sx=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,rx=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,ax=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,ox=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,ze={alphahash_fragment:C0,alphahash_pars_fragment:P0,alphamap_fragment:L0,alphamap_pars_fragment:D0,alphatest_fragment:I0,alphatest_pars_fragment:N0,aomap_fragment:U0,aomap_pars_fragment:F0,batching_pars_vertex:O0,batching_vertex:k0,begin_vertex:B0,beginnormal_vertex:z0,bsdfs:G0,iridescence_fragment:H0,bumpmap_pars_fragment:V0,clipping_planes_fragment:W0,clipping_planes_pars_fragment:$0,clipping_planes_pars_vertex:q0,clipping_planes_vertex:X0,color_fragment:Y0,color_pars_fragment:K0,color_pars_vertex:J0,color_vertex:Z0,common:Q0,defaultnormal_vertex:j0,displacementmap_pars_vertex:eg,displacementmap_vertex:tg,emissivemap_fragment:ng,emissivemap_pars_fragment:ig,colorspace_fragment:sg,colorspace_pars_fragment:rg,envmap_fragment:ag,envmap_common_pars_fragment:og,envmap_pars_fragment:lg,envmap_pars_vertex:cg,envmap_physical_pars_fragment:bg,envmap_vertex:hg,fog_vertex:dg,fog_pars_vertex:ug,fog_fragment:fg,fog_pars_fragment:pg,gradientmap_pars_fragment:mg,lightmap_pars_fragment:gg,lights_lambert_fragment:vg,lights_lambert_pars_fragment:xg,lights_pars_begin:yg,lights_toon_fragment:_g,lights_toon_pars_fragment:Mg,lights_phong_fragment:Sg,lights_phong_pars_fragment:wg,lights_physical_fragment:Eg,lights_physical_pars_fragment:Ag,lights_fragment_begin:Tg,lights_fragment_maps:Rg,lights_fragment_end:Cg,lightprobes_pars_fragment:Pg,logdepthbuf_fragment:Lg,logdepthbuf_pars_fragment:Dg,logdepthbuf_pars_vertex:Ig,logdepthbuf_vertex:Ng,map_fragment:Ug,map_pars_fragment:Fg,map_particle_fragment:Og,map_particle_pars_fragment:kg,metalnessmap_fragment:Bg,metalnessmap_pars_fragment:zg,morphinstance_vertex:Gg,morphcolor_vertex:Hg,morphnormal_vertex:Vg,morphtarget_pars_vertex:Wg,morphtarget_vertex:$g,normal_fragment_begin:qg,normal_fragment_maps:Xg,normal_pars_fragment:Yg,normal_pars_vertex:Kg,normal_vertex:Jg,normalmap_pars_fragment:Zg,clearcoat_normal_fragment_begin:Qg,clearcoat_normal_fragment_maps:jg,clearcoat_pars_fragment:ev,iridescence_pars_fragment:tv,opaque_fragment:nv,packing:iv,premultiplied_alpha_fragment:sv,project_vertex:rv,dithering_fragment:av,dithering_pars_fragment:ov,roughnessmap_fragment:lv,roughnessmap_pars_fragment:cv,shadowmap_pars_fragment:hv,shadowmap_pars_vertex:dv,shadowmap_vertex:uv,shadowmask_pars_fragment:fv,skinbase_vertex:pv,skinning_pars_vertex:mv,skinning_vertex:gv,skinnormal_vertex:vv,specularmap_fragment:xv,specularmap_pars_fragment:yv,tonemapping_fragment:bv,tonemapping_pars_fragment:_v,transmission_fragment:Mv,transmission_pars_fragment:Sv,uv_pars_fragment:wv,uv_pars_vertex:Ev,uv_vertex:Av,worldpos_vertex:Tv,background_vert:Rv,background_frag:Cv,backgroundCube_vert:Pv,backgroundCube_frag:Lv,cube_vert:Dv,cube_frag:Iv,depth_vert:Nv,depth_frag:Uv,distance_vert:Fv,distance_frag:Ov,equirect_vert:kv,equirect_frag:Bv,linedashed_vert:zv,linedashed_frag:Gv,meshbasic_vert:Hv,meshbasic_frag:Vv,meshlambert_vert:Wv,meshlambert_frag:$v,meshmatcap_vert:qv,meshmatcap_frag:Xv,meshnormal_vert:Yv,meshnormal_frag:Kv,meshphong_vert:Jv,meshphong_frag:Zv,meshphysical_vert:Qv,meshphysical_frag:jv,meshtoon_vert:ex,meshtoon_frag:tx,points_vert:nx,points_frag:ix,shadow_vert:sx,shadow_frag:rx,sprite_vert:ax,sprite_frag:ox},me={common:{diffuse:{value:new Te(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new Ne},alphaMap:{value:null},alphaMapTransform:{value:new Ne},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new Ne}},envmap:{envMap:{value:null},envMapRotation:{value:new Ne},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98},dfgLUT:{value:null}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new Ne}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new Ne}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new Ne},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new Ne},normalScale:{value:new fe(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new Ne},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new Ne}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new Ne}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new Ne}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new Te(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},sunLights:{value:[],properties:{direction:{},color:{}}},sunLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},sunShadowMatrix:{value:[]},sunShadowCascade:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null},probesSH:{value:[]},probesMin:{value:[]},probesMax:{value:[]},probesResolution:{value:[]}},points:{diffuse:{value:new Te(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new Ne},alphaTest:{value:0},uvTransform:{value:new Ne}},sprite:{diffuse:{value:new Te(16777215)},opacity:{value:1},center:{value:new fe(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new Ne},alphaMap:{value:null},alphaMapTransform:{value:new Ne},alphaTest:{value:0}}},Wn={basic:{uniforms:en([me.common,me.specularmap,me.envmap,me.aomap,me.lightmap,me.fog]),vertexShader:ze.meshbasic_vert,fragmentShader:ze.meshbasic_frag},lambert:{uniforms:en([me.common,me.specularmap,me.envmap,me.aomap,me.lightmap,me.emissivemap,me.bumpmap,me.normalmap,me.displacementmap,me.fog,me.lights,{emissive:{value:new Te(0)},envMapIntensity:{value:1}}]),vertexShader:ze.meshlambert_vert,fragmentShader:ze.meshlambert_frag},phong:{uniforms:en([me.common,me.specularmap,me.envmap,me.aomap,me.lightmap,me.emissivemap,me.bumpmap,me.normalmap,me.displacementmap,me.fog,me.lights,{emissive:{value:new Te(0)},specular:{value:new Te(1118481)},shininess:{value:30},envMapIntensity:{value:1}}]),vertexShader:ze.meshphong_vert,fragmentShader:ze.meshphong_frag},standard:{uniforms:en([me.common,me.envmap,me.aomap,me.lightmap,me.emissivemap,me.bumpmap,me.normalmap,me.displacementmap,me.roughnessmap,me.metalnessmap,me.fog,me.lights,{emissive:{value:new Te(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:ze.meshphysical_vert,fragmentShader:ze.meshphysical_frag},toon:{uniforms:en([me.common,me.aomap,me.lightmap,me.emissivemap,me.bumpmap,me.normalmap,me.displacementmap,me.gradientmap,me.fog,me.lights,{emissive:{value:new Te(0)}}]),vertexShader:ze.meshtoon_vert,fragmentShader:ze.meshtoon_frag},matcap:{uniforms:en([me.common,me.bumpmap,me.normalmap,me.displacementmap,me.fog,{matcap:{value:null}}]),vertexShader:ze.meshmatcap_vert,fragmentShader:ze.meshmatcap_frag},points:{uniforms:en([me.points,me.fog]),vertexShader:ze.points_vert,fragmentShader:ze.points_frag},dashed:{uniforms:en([me.common,me.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:ze.linedashed_vert,fragmentShader:ze.linedashed_frag},depth:{uniforms:en([me.common,me.displacementmap]),vertexShader:ze.depth_vert,fragmentShader:ze.depth_frag},normal:{uniforms:en([me.common,me.bumpmap,me.normalmap,me.displacementmap,{opacity:{value:1}}]),vertexShader:ze.meshnormal_vert,fragmentShader:ze.meshnormal_frag},sprite:{uniforms:en([me.sprite,me.fog]),vertexShader:ze.sprite_vert,fragmentShader:ze.sprite_frag},background:{uniforms:{uvTransform:{value:new Ne},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:ze.background_vert,fragmentShader:ze.background_frag},backgroundCube:{uniforms:{envMap:{value:null},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new Ne}},vertexShader:ze.backgroundCube_vert,fragmentShader:ze.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:ze.cube_vert,fragmentShader:ze.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:ze.equirect_vert,fragmentShader:ze.equirect_frag},distance:{uniforms:en([me.common,me.displacementmap,{referencePosition:{value:new P},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:ze.distance_vert,fragmentShader:ze.distance_frag},shadow:{uniforms:en([me.lights,me.fog,{color:{value:new Te(0)},opacity:{value:1}}]),vertexShader:ze.shadow_vert,fragmentShader:ze.shadow_frag}};Wn.physical={uniforms:en([Wn.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new Ne},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new Ne},clearcoatNormalScale:{value:new fe(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new Ne},diffuseRoughness:{value:0},diffuseRoughnessMap:{value:null},diffuseRoughnessMapTransform:{value:new Ne},dispersion:{value:0},retroreflectivity:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new Ne},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new Ne},sheen:{value:0},sheenColor:{value:new Te(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new Ne},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new Ne},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new Ne},transmissionSamplerSize:{value:new fe},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new Ne},attenuationDistance:{value:0},attenuationColor:{value:new Te(0)},specularColor:{value:new Te(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new Ne},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new Ne},anisotropyVector:{value:new fe},anisotropyMap:{value:null},anisotropyMapTransform:{value:new Ne}}]),vertexShader:ze.meshphysical_vert,fragmentShader:ze.meshphysical_frag};const ma={r:0,b:0,g:0},lx=new Ke,af=new Ne;af.set(-1,0,0,0,1,0,0,0,1);function cx(i,e,t,n,s,r){const a=new Te(0);let o=s===!0?0:1,c,l,h=null,d=0,u=null;function f(x){let S=x.isScene===!0?x.background:null;if(S&&S.isTexture){const b=x.backgroundBlurriness>0;S=e.get(S,b)}return S}function g(x){let S=!1;const b=f(x);b===null?p(a,o):b&&b.isColor&&(p(b,1),S=!0);const A=i.xr.getEnvironmentBlendMode();A==="additive"?t.buffers.color.setClear(0,0,0,1,r):A==="alpha-blend"&&t.buffers.color.setClear(0,0,0,0,r),(i.autoClear||S)&&(t.buffers.depth.setTest(!0),t.buffers.depth.setMask(!0),t.buffers.color.setMask(!0),i.clear(i.autoClearColor,i.autoClearDepth,i.autoClearStencil))}function v(x,S){const b=f(S);b&&b.isCubeTexture?(l===void 0&&(l=new je(new is(1,1,1),new fn({name:"BackgroundCubeMaterial",uniforms:Us(Wn.backgroundCube.uniforms),vertexShader:Wn.backgroundCube.vertexShader,fragmentShader:Wn.backgroundCube.fragmentShader,side:Gt,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),l.geometry.deleteAttribute("normal"),l.geometry.deleteAttribute("uv"),l.onBeforeRender=function(A,E,y){this.matrixWorld.copyPosition(y.matrixWorld)},Object.defineProperty(l.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),n.update(l)),l.material.uniforms.envMap.value=b,l.material.uniforms.backgroundBlurriness.value=S.backgroundBlurriness,l.material.uniforms.backgroundIntensity.value=S.backgroundIntensity,l.material.uniforms.backgroundRotation.value.setFromMatrix4(lx.makeRotationFromEuler(S.backgroundRotation)).transpose(),b.isRenderTargetTexture===!1&&l.material.uniforms.backgroundRotation.value.premultiply(af),l.material.toneMapped=Xe.getTransfer(b.colorSpace)!==st,(h!==b||d!==b.version||u!==i.toneMapping)&&(l.material.needsUpdate=!0,h=b,d=b.version,u=i.toneMapping),l.layers.enableAll(),x.unshift(l,l.geometry,l.material,0,0,null)):b&&b.isTexture&&(c===void 0&&(c=new je(new pi(2,2),new fn({name:"BackgroundMaterial",uniforms:Us(Wn.background.uniforms),vertexShader:Wn.background.vertexShader,fragmentShader:Wn.background.fragmentShader,side:Ki,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),c.geometry.deleteAttribute("normal"),Object.defineProperty(c.material,"map",{get:function(){return this.uniforms.t2D.value}}),n.update(c)),c.material.uniforms.t2D.value=b,c.material.uniforms.backgroundIntensity.value=S.backgroundIntensity,c.material.toneMapped=Xe.getTransfer(b.colorSpace)!==st,b.matrixAutoUpdate===!0&&b.updateMatrix(),c.material.uniforms.uvTransform.value.copy(b.matrix),(h!==b||d!==b.version||u!==i.toneMapping)&&(c.material.needsUpdate=!0,h=b,d=b.version,u=i.toneMapping),c.layers.enableAll(),x.unshift(c,c.geometry,c.material,0,0,null))}function p(x,S){x.getRGB(ma,ef(i)),t.buffers.color.setClear(ma.r,ma.g,ma.b,S,r)}function m(){l!==void 0&&(l.geometry.dispose(),l.material.dispose(),l=void 0),c!==void 0&&(c.geometry.dispose(),c.material.dispose(),c=void 0)}return{getClearColor:function(){return a},setClearColor:function(x,S=1){a.set(x),o=S,p(a,o)},getClearAlpha:function(){return o},setClearAlpha:function(x){o=x,p(a,o)},render:g,addToRenderList:v,dispose:m}}function hx(i,e){const t=i.getParameter(i.MAX_VERTEX_ATTRIBS),n={},s=u(null);let r=s,a=!1;function o(N,F,V,I,H){let J=!1;const z=d(N,I,V,F);r!==z&&(r=z,l(r.object)),J=f(N,I,V,H),J&&g(N,I,V,H),H!==null&&e.update(H,i.ELEMENT_ARRAY_BUFFER),(J||a)&&(a=!1,b(N,F,V,I),H!==null&&i.bindBuffer(i.ELEMENT_ARRAY_BUFFER,e.get(H).buffer))}function c(){return i.createVertexArray()}function l(N){return i.bindVertexArray(N)}function h(N){return i.deleteVertexArray(N)}function d(N,F,V,I){const H=I.wireframe===!0;let J=n[F.id];J===void 0&&(J={},n[F.id]=J);const z=N.isInstancedMesh===!0?N.id:0;let ne=J[z];ne===void 0&&(ne={},J[z]=ne);let $=ne[V.id];$===void 0&&($={},ne[V.id]=$);let j=$[H];return j===void 0&&(j=u(c()),$[H]=j),j}function u(N){const F=[],V=[],I=[];for(let H=0;H<t;H++)F[H]=0,V[H]=0,I[H]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:F,enabledAttributes:V,attributeDivisors:I,object:N,attributes:{},index:null}}function f(N,F,V,I){const H=r.attributes,J=F.attributes;let z=0;const ne=V.getAttributes();for(const $ in ne)if(ne[$].location>=0){const ee=H[$];let we=J[$];if(we===void 0&&($==="instanceMatrix"&&N.instanceMatrix&&(we=N.instanceMatrix),$==="instanceColor"&&N.instanceColor&&(we=N.instanceColor)),ee===void 0||ee.attribute!==we||we&&ee.data!==we.data)return!0;z++}return r.attributesNum!==z||r.index!==I}function g(N,F,V,I){const H={},J=F.attributes;let z=0;const ne=V.getAttributes();for(const $ in ne)if(ne[$].location>=0){let ee=J[$];ee===void 0&&($==="instanceMatrix"&&N.instanceMatrix&&(ee=N.instanceMatrix),$==="instanceColor"&&N.instanceColor&&(ee=N.instanceColor));const we={};we.attribute=ee,ee&&ee.data&&(we.data=ee.data),H[$]=we,z++}r.attributes=H,r.attributesNum=z,r.index=I}function v(){const N=r.newAttributes;for(let F=0,V=N.length;F<V;F++)N[F]=0}function p(N){m(N,0)}function m(N,F){const V=r.newAttributes,I=r.enabledAttributes,H=r.attributeDivisors;V[N]=1,I[N]===0&&(i.enableVertexAttribArray(N),I[N]=1),H[N]!==F&&(i.vertexAttribDivisor(N,F),H[N]=F)}function x(){const N=r.newAttributes,F=r.enabledAttributes;for(let V=0,I=F.length;V<I;V++)F[V]!==N[V]&&(i.disableVertexAttribArray(V),F[V]=0)}function S(N,F,V,I,H,J,z){z===!0?i.vertexAttribIPointer(N,F,V,H,J):i.vertexAttribPointer(N,F,V,I,H,J)}function b(N,F,V,I){v();const H=I.attributes,J=V.getAttributes(),z=F.defaultAttributeValues;for(const ne in J){const $=J[ne];if($.location>=0){let j=H[ne];if(j===void 0&&(ne==="instanceMatrix"&&N.instanceMatrix&&(j=N.instanceMatrix),ne==="instanceColor"&&N.instanceColor&&(j=N.instanceColor)),j!==void 0){const ee=j.normalized,we=j.itemSize,Ue=e.get(j);if(Ue===void 0)continue;const Y=Ue.buffer,ve=Ue.type,_e=Ue.bytesPerElement,Ce=ve===i.INT||ve===i.UNSIGNED_INT||j.gpuType===fc;if(j.isInterleavedBufferAttribute){const xe=j.data,Oe=xe.isInterleavedBuffer===!0?xe.stride:xe.itemSize,_t=j.offset;if(xe.isInstancedInterleavedBuffer||xe.isInstancedBufferAttribute){for(let De=0;De<$.locationSize;De++)m($.location+De,xe.meshPerAttribute);N.isInstancedMesh!==!0&&I._maxInstanceCount===void 0&&(I._maxInstanceCount=xe.meshPerAttribute*xe.count)}else for(let De=0;De<$.locationSize;De++)p($.location+De);i.bindBuffer(i.ARRAY_BUFFER,Y);for(let De=0;De<$.locationSize;De++)S($.location+De,we/$.locationSize,ve,ee,Oe*_e,(_t+we/$.locationSize*De)*_e,Ce)}else{if(j.isInstancedBufferAttribute){for(let xe=0;xe<$.locationSize;xe++)m($.location+xe,j.meshPerAttribute);N.isInstancedMesh!==!0&&I._maxInstanceCount===void 0&&(I._maxInstanceCount=j.meshPerAttribute*j.count)}else for(let xe=0;xe<$.locationSize;xe++)p($.location+xe);i.bindBuffer(i.ARRAY_BUFFER,Y);for(let xe=0;xe<$.locationSize;xe++)S($.location+xe,we/$.locationSize,ve,ee,we*_e,we/$.locationSize*xe*_e,Ce)}}else if(z!==void 0){const ee=z[ne];if(ee!==void 0)switch(ee.length){case 2:i.vertexAttrib2fv($.location,ee);break;case 3:i.vertexAttrib3fv($.location,ee);break;case 4:i.vertexAttrib4fv($.location,ee);break;default:i.vertexAttrib1fv($.location,ee)}}}}x()}function A(){L();for(const N in n){const F=n[N];for(const V in F){const I=F[V];for(const H in I){const J=I[H];for(const z in J)h(J[z].object),delete J[z];delete I[H]}}delete n[N]}}function E(N){if(n[N.id]===void 0)return;const F=n[N.id];for(const V in F){const I=F[V];for(const H in I){const J=I[H];for(const z in J)h(J[z].object),delete J[z];delete I[H]}}delete n[N.id]}function y(N){for(const F in n){const V=n[F];for(const I in V){const H=V[I];if(H[N.id]===void 0)continue;const J=H[N.id];for(const z in J)h(J[z].object),delete J[z];delete H[N.id]}}}function w(N){for(const F in n){const V=n[F],I=N.isInstancedMesh===!0?N.id:0,H=V[I];if(H!==void 0){for(const J in H){const z=H[J];for(const ne in z)h(z[ne].object),delete z[ne];delete H[J]}delete V[I],Object.keys(V).length===0&&delete n[F]}}}function L(){R(),a=!0,r!==s&&(r=s,l(r.object))}function R(){s.geometry=null,s.program=null,s.wireframe=!1}return{setup:o,reset:L,resetDefaultState:R,dispose:A,releaseStatesOfGeometry:E,releaseStatesOfObject:w,releaseStatesOfProgram:y,initAttributes:v,enableAttribute:p,disableUnusedAttributes:x}}function dx(i,e,t){let n;function s(c){n=c}function r(c,l){i.drawArrays(n,c,l),t.update(l,n,1)}function a(c,l,h){h!==0&&(i.drawArraysInstanced(n,c,l,h),t.update(l,n,h))}function o(c,l,h){if(h===0)return;e.get("WEBGL_multi_draw").multiDrawArraysWEBGL(n,c,0,l,0,h);let u=0;for(let f=0;f<h;f++)u+=l[f];t.update(u,n,1)}this.setMode=s,this.render=r,this.renderInstances=a,this.renderMultiDraw=o}function ux(i,e,t,n){let s;function r(){if(s!==void 0)return s;if(e.has("EXT_texture_filter_anisotropic")===!0){const y=e.get("EXT_texture_filter_anisotropic");s=i.getParameter(y.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else s=0;return s}function a(y){return!(y!==qn&&n.convert(y)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_FORMAT))}function o(y){const w=y===Jn&&(e.has("EXT_color_buffer_half_float")||e.has("EXT_color_buffer_float"));return!(y!==ln&&y!==Dn&&!w&&n.convert(y)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_TYPE))}function c(y){if(y==="highp"){if(i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.HIGH_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.HIGH_FLOAT).precision>0)return"highp";y="mediump"}return y==="mediump"&&i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.MEDIUM_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let l=t.precision!==void 0?t.precision:"highp";const h=c(l);h!==l&&(Le("WebGLRenderer:",l,"not supported, using",h,"instead."),l=h);const d=t.reversedDepthBuffer===!0&&e.has("EXT_clip_control"),u=t.logarithmicDepthBuffer===!0&&d===!1;t.reversedDepthBuffer===!0&&d===!1&&Le("WebGLRenderer: Unable to use reversed depth buffer due to missing EXT_clip_control extension. Fallback to default depth buffer."),t.logarithmicDepthBuffer===!0&&d===!0&&Le("WebGLRenderer: Logarithmic depth buffer is ignored when reversed depth buffer is enabled.");const f=i.getParameter(i.MAX_TEXTURE_IMAGE_UNITS),g=i.getParameter(i.MAX_VERTEX_TEXTURE_IMAGE_UNITS),v=i.getParameter(i.MAX_TEXTURE_SIZE),p=i.getParameter(i.MAX_CUBE_MAP_TEXTURE_SIZE),m=i.getParameter(i.MAX_VERTEX_ATTRIBS),x=i.getParameter(i.MAX_VERTEX_UNIFORM_VECTORS),S=i.getParameter(i.MAX_VARYING_VECTORS),b=i.getParameter(i.MAX_FRAGMENT_UNIFORM_VECTORS),A=i.getParameter(i.MAX_SAMPLES),E=i.getParameter(i.SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:r,getMaxPrecision:c,textureFormatReadable:a,textureTypeReadable:o,precision:l,logarithmicDepthBuffer:u,reversedDepthBuffer:d,maxTextures:f,maxVertexTextures:g,maxTextureSize:v,maxCubemapSize:p,maxAttributes:m,maxVertexUniforms:x,maxVaryings:S,maxFragmentUniforms:b,maxSamples:A,samples:E}}function fx(i){const e=this;let t=null,n=0,s=!1,r=!1;const a=new oi,o=new Ne,c={value:null,needsUpdate:!1};this.uniform=c,this.numPlanes=0,this.numIntersection=0,this.init=function(d,u){const f=d.length!==0||u||n!==0||s;return s=u,n=d.length,f},this.beginShadows=function(){r=!0,h(null)},this.endShadows=function(){r=!1},this.setGlobalState=function(d,u){t=h(d,u,0)},this.setState=function(d,u,f){const g=d.clippingPlanes,v=d.clipIntersection,p=d.clipShadows,m=i.get(d);if(!s||g===null||g.length===0||r&&!p)r?h(null):l();else{const x=r?0:n,S=x*4;let b=m.clippingState||null;c.value=b,b=h(g,u,S,f);for(let A=0;A!==S;++A)b[A]=t[A];m.clippingState=b,this.numIntersection=v?this.numPlanes:0,this.numPlanes+=x}};function l(){c.value!==t&&(c.value=t,c.needsUpdate=n>0),e.numPlanes=n,e.numIntersection=0}function h(d,u,f,g){const v=d!==null?d.length:0;let p=null;if(v!==0){if(p=c.value,g!==!0||p===null){const m=f+v*4,x=u.matrixWorldInverse;o.getNormalMatrix(x),(p===null||p.length<m)&&(p=new Float32Array(m));for(let S=0,b=f;S!==v;++S,b+=4)a.copy(d[S]).applyMatrix4(x,o),a.normal.toArray(p,b),p[b+3]=a.constant}c.value=p,c.needsUpdate=!0}return e.numPlanes=v,e.numIntersection=0,p}}class Fc extends Mn{constructor(e=1,t={}){super(e,e,t),this.isWebGLCubeRenderTarget=!0;const n={width:e,height:e,depth:1},s=[n,n,n,n,n,n];this.texture=new Hu(s),this._setTextureOptions(t),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(e,t){this.texture.type=t.type,this.texture.colorSpace=t.colorSpace,this.texture.generateMipmaps=t.generateMipmaps,this.texture.minFilter=t.minFilter,this.texture.magFilter=t.magFilter;const n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},s=new is(5,5,5),r=new fn({name:"CubemapFromEquirect",uniforms:Us(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:Gt,blending:As});r.uniforms.tEquirect.value=t;const a=new je(s,r),o=t.minFilter;return t.minFilter===hi&&(t.minFilter=nn),new Vl(1,10,this).update(e,a),t.minFilter=o,a.geometry.dispose(),a.material.dispose(),this}clear(e,t=!0,n=!0,s=!0){const r=e.getRenderTarget();for(let a=0;a<6;a++)e.setRenderTarget(this,a),e.clear(t,n,s);e.setRenderTarget(r)}}const ad=256,px=3,mx=20,of=256,lf=16,gx=3,vx=new P,xx=new Te;class Ka{constructor(e){this._renderer=e,this._cubeSize=0,this._sourceTarget=null,this._cubeCamera=new Vl(1,10,null),this._boxMesh=new je(new is(5,5,5),null),this._cubemapMaterial=null,this._equirectMaterial=null,this._blurMaterial=null,this._ggxMaterial=null,this._integrationMaterial=null}fromScene(e,t=0,n=.1,s=100,r={}){const{size:a=256,position:o=vx}=r,c=this._renderer;this._setSize(a);const l=this._allocateTarget(),h=this._getSourceTarget(!0);t>0&&(h.texture.mipmapsAutoUpdate=!1);const d=c.autoClear,u=c.autoClearColor,f=c.autoClearDepth,g=c.autoClearStencil,v=e.background;c.autoClear=!0,c.autoClearColor=!0,c.autoClearDepth=!0,c.autoClearStencil=!0,v===null&&(e.background=c.getClearColor(xx));const p=new Vl(n,s,h);return p.position.copy(o),p.update(c,e),c.autoClear=d,c.autoClearColor=u,c.autoClearDepth=f,c.autoClearStencil=g,e.background=v,t>0&&(h.texture.mipmapsAutoUpdate=!0,this._blur(l,t)),this._applyPMREM(l),l}fromEquirectangular(e,t=null){return this._fromTexture(e,t)}fromCubemap(e,t=null){return this._fromTexture(e,t)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=cd(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=ld(),this._compileMaterial(this._equirectMaterial))}dispose(){this._sourceTarget!==null&&this._sourceTarget.dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose(),this._blurMaterial!==null&&this._blurMaterial.dispose(),this._ggxMaterial!==null&&this._ggxMaterial.dispose(),this._integrationMaterial!==null&&this._integrationMaterial.dispose(),this._boxMesh.geometry.dispose()}static lodToRoughness(e,t){return t>0?1-Math.sqrt(1-e/t):0}_setSize(e){this._cubeSize=Math.max(ad,Iu(e))}_fromTexture(e,t){e.mapping===Ls||e.mapping===gr?this._setSize(e.image.length===0?ad:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4);const n=t||this._allocateTarget();return this._textureToCubemap(e),this._applyPMREM(n),n}_allocateTarget(){const e=this._cubeSize,t=od(e,!1,!1),n=Math.log2(e)-px;for(let s=0;s<=n;s++)t.texture.mipmaps.push({width:e>>s,height:e>>s});return t.texture.name="PMREM",t.texture.isPMREMTexture=!0,t}_getSourceTarget(e=!1){const t=this._cubeSize,n=this._sourceTarget;return(n===null||n.width!==t||e&&n.depthBuffer===!1)&&(n!==null&&n.dispose(),this._sourceTarget=od(t,!0,e)),this._sourceTarget}_compileMaterial(e){this._boxMesh.material=e,this._renderer.compile(this._boxMesh,this._cubeCamera.children[0])}_renderCube(e,t,n){const s=this._boxMesh,r=this._cubeCamera;s.material=n,r.renderTarget=e,r.activeMipmapLevel=t;const a=e.width>>t;e.viewport.set(0,0,a,a),r.update(this._renderer,s),e.viewport.set(0,0,e.width,e.height)}_textureToCubemap(e){let t;e.mapping===Ls||e.mapping===gr?(this._cubemapMaterial===null&&(this._cubemapMaterial=cd()),t=this._cubemapMaterial,t.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):(this._equirectMaterial===null&&(this._equirectMaterial=ld()),t=this._equirectMaterial),t.uniforms.envMap.value=e,this._renderCube(this._getSourceTarget(),0,t)}_applyPMREM(e){this._ggxMaterial===null&&(this._ggxMaterial=yx(),this._integrationMaterial=bx());const t=this._cubeSize,n=e.texture.mipmaps.length-1,s=this._ggxMaterial.uniforms;s.envMap.value=this._sourceTarget.texture;const r=this._integrationMaterial.uniforms;r.envMap.value=this._sourceTarget.texture,r.sourceLod.value=Math.log2(t/lf);for(let a=0;a<=n;a++){const o=Ka.lodToRoughness(a,n);if(a>n-gx)r.roughness.value=o,this._renderCube(e,a,this._integrationMaterial);else{const c=o>0?Math.log2(t)+.5*Math.log2(6/(of*Math.pow(o,4)))+.5:0;s.roughness.value=o,s.lodBias.value=c,this._renderCube(e,a,this._ggxMaterial)}}}_blur(e,t){this._blurMaterial===null&&(this._blurMaterial=_x());const n=this._blurMaterial,s=n.uniforms,r=this._sourceTarget;s.sigma.value=Math.min(t,Math.PI)/Math.SQRT2,s.envMap.value=r.texture,this._renderCube(e,0,n),s.envMap.value=e.texture,this._renderCube(r,0,n)}}function od(i,e,t){return new Fc(i,{minFilter:hi,generateMipmaps:e,type:Jn,colorSpace:za,depthBuffer:t})}function Ir(i,e,t){return new fn({name:i,uniforms:e,vertexShader:ze.cube_vert,fragmentShader:t,side:Gt,blending:As,depthTest:!1,depthWrite:!1})}function yx(){return Ir("PMREMGGXConvolution",{envMap:{value:null},roughness:{value:0},lodBias:{value:0}},`

		#define GGX_SAMPLES ${of}u

		varying vec3 vWorldDirection;

		uniform samplerCube envMap;
		uniform float roughness;
		uniform float lodBias;

		#include <common>

		// Van der Corput radical inverse
		float radicalInverse_VdC( uint bits ) {

			bits = ( bits << 16u ) | ( bits >> 16u );
			bits = ( ( bits & 0x55555555u ) << 1u ) | ( ( bits & 0xAAAAAAAAu ) >> 1u );
			bits = ( ( bits & 0x33333333u ) << 2u ) | ( ( bits & 0xCCCCCCCCu ) >> 2u );
			bits = ( ( bits & 0x0F0F0F0Fu ) << 4u ) | ( ( bits & 0xF0F0F0F0u ) >> 4u );
			bits = ( ( bits & 0x00FF00FFu ) << 8u ) | ( ( bits & 0xFF00FF00u ) >> 8u );
			return float( bits ) * 2.3283064365386963e-10; // / 0x100000000

		}

		// Hammersley sequence
		vec2 hammersley( uint i, uint N ) {

			return vec2( float( i ) / float( N ), radicalInverse_VdC( i ) );

		}

		void main() {

			vec3 N = normalize( vWorldDirection );

			// For very low roughness, just sample the environment directly
			if ( roughness < 0.001 ) {

				gl_FragColor = vec4( textureLod( envMap, N, 0.0 ).rgb, 1.0 );
				return;

			}

			float alpha = roughness * roughness;
			float alpha2 = alpha * alpha;

			// Tangent space basis for VNDF sampling
			vec3 up = abs( N.z ) < 0.999 ? vec3( 0.0, 0.0, 1.0 ) : vec3( 1.0, 0.0, 0.0 );
			vec3 tangent = normalize( cross( up, N ) );
			vec3 bitangent = cross( N, tangent );

			vec3 prefilteredColor = vec3( 0.0 );
			float totalWeight = 0.0;

			for ( uint i = 0u; i < GGX_SAMPLES; i ++ ) {

				vec2 Xi = hammersley( i, GGX_SAMPLES );

				// With V = N, sample the reflected direction directly.
				float invQ = 1.0 / ( 1.0 - Xi.x + alpha2 * Xi.x );
				float NdotL = ( 1.0 - Xi.x - alpha2 * Xi.x ) * invQ;

				if ( NdotL > 0.0 ) {

					float phi = 2.0 * PI * Xi.y;
					float sinTheta = 2.0 * alpha * sqrt( Xi.x * ( 1.0 - Xi.x ) ) * invQ;
					vec3 L = N * NdotL + ( tangent * cos( phi ) + bitangent * sin( phi ) ) * sinTheta;

					// Match the source mip to the sample's solid angle. The terms
					// independent of the sample are precomputed in lodBias.
					float d = alpha2 * invQ;
					float lod = max( log2( d ) + lodBias, 0.0 );

					// Weight by NdotL for the split-sum approximation
					prefilteredColor += textureLod( envMap, L, lod ).rgb * NdotL;
					totalWeight += NdotL;

				}

			}

			gl_FragColor = vec4( prefilteredColor / totalWeight, 1.0 );

		}
	`)}function bx(){return Ir("PMREMGGXIntegration",{envMap:{value:null},roughness:{value:0},sourceLod:{value:0},sourceSize:{value:lf}},`

		varying vec3 vWorldDirection;

		uniform samplerCube envMap;
		uniform float roughness;
		uniform float sourceLod;
		uniform int sourceSize;

		void main() {

			vec3 N = normalize( vWorldDirection );

			float alpha = roughness * roughness;
			float alpha2 = alpha * alpha;

			float texelSize = 2.0 / float( sourceSize );

			vec3 prefilteredColor = vec3( 0.0 );
			float totalWeight = 0.0;

			// Pair opposite texels: only the one in N's hemisphere contributes.
			for ( int face = 0; face < 3; face ++ ) {

				for ( int y = 0; y < sourceSize; y ++ ) {

					for ( int x = 0; x < sourceSize; x ++ ) {

						vec2 uv = ( vec2( x, y ) + 0.5 ) * texelSize - 1.0;
						vec3 texelDirection = face == 0 ? vec3( 1.0, uv ) : ( face == 1 ? vec3( uv.x, 1.0, uv.y ) : vec3( uv, 1.0 ) );

						float invDistance = inversesqrt( 1.0 + dot( uv, uv ) );
						float NdotL = dot( N, texelDirection );
						texelDirection *= NdotL < 0.0 ? - 1.0 : 1.0;
						NdotL = abs( NdotL ) * invDistance;

						// With V = N, NdotH squared is ( 1 + NdotL ) / 2. Common factors
						// in the GGX distribution and texel solid angle cancel when normalized.
						float d = 1.0 + alpha2 + ( alpha2 - 1.0 ) * NdotL;
						float weight = NdotL * invDistance * invDistance * invDistance / ( d * d );

						prefilteredColor += textureLod( envMap, texelDirection, sourceLod ).rgb * weight;
						totalWeight += weight;

					}

				}

			}

			gl_FragColor = vec4( prefilteredColor / totalWeight, 1.0 );

		}
	`)}function _x(){return Ir("PMREMSphericalGaussianBlur",{envMap:{value:null},sigma:{value:0}},`

		#define SAMPLES ${mx}
		#define GOLDEN_ANGLE 2.39996322973

		varying vec3 vWorldDirection;

		uniform samplerCube envMap;
		uniform float sigma;

		#include <common>

		void main() {

			vec3 outputDirection = normalize( vWorldDirection );

			vec3 up = abs( outputDirection.z ) < 0.999 ? vec3( 0.0, 0.0, 1.0 ) : vec3( 1.0, 0.0, 0.0 );
			vec3 tangent = normalize( cross( up, outputDirection ) );
			vec3 bitangent = cross( outputDirection, tangent );

			// Truncate the kernel at three standard deviations or at the antipode.
			float thetaMax = min( 3.0 * sigma, PI );
			float truncation = 1.0 - exp( - 0.5 * thetaMax * thetaMax / ( sigma * sigma ) );

			vec3 accumColor = vec3( 0.0 );
			float accumWeight = 0.0;

			for ( int i = 0; i < SAMPLES; i ++ ) {

				// Stratified inverse-CDF sampling of the Gaussian, placed on a golden-angle spiral.
				float stratum = ( float( i ) + 0.5 ) / float( SAMPLES );
				float theta = sigma * sqrt( - 2.0 * log( 1.0 - stratum * truncation ) );
				float phi = float( i ) * GOLDEN_ANGLE;

				vec3 offset = cos( phi ) * tangent + sin( phi ) * bitangent;
				vec3 sampleDirection = cos( theta ) * outputDirection + sin( theta ) * offset;

				// Correct the planar sample density to solid angle.
				float weight = sin( theta ) / theta;

				accumColor += weight * textureLod( envMap, sampleDirection, 0.0 ).rgb;
				accumWeight += weight;

			}

			gl_FragColor = vec4( accumColor / accumWeight, 1.0 );

		}
	`)}function ld(){return Ir("PMREMEquirectangularToCubemap",{envMap:{value:null}},`

		varying vec3 vWorldDirection;

		uniform sampler2D envMap;

		#include <common>

		void main() {

			// Average four subpixel samples to preserve small, bright features.
			vec3 direction = normalize( vWorldDirection );
			vec3 dx = dFdx( direction ) * 0.25;
			vec3 dy = dFdy( direction ) * 0.25;

			vec3 color = textureLod( envMap, equirectUv( normalize( direction - dx - dy ) ), 0.0 ).rgb;
			color += textureLod( envMap, equirectUv( normalize( direction + dx - dy ) ), 0.0 ).rgb;
			color += textureLod( envMap, equirectUv( normalize( direction - dx + dy ) ), 0.0 ).rgb;
			color += textureLod( envMap, equirectUv( normalize( direction + dx + dy ) ), 0.0 ).rgb;
			gl_FragColor = vec4( color * 0.25, 1.0 );

		}
	`)}function cd(){return Ir("PMREMCubemapToCubemap",{envMap:{value:null},flipEnvMap:{value:-1}},`

		varying vec3 vWorldDirection;

		uniform samplerCube envMap;
		uniform float flipEnvMap;

		void main() {

			gl_FragColor = vec4( textureCube( envMap, vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) ).rgb, 1.0 );

		}
	`)}function Mx(i){let e=new WeakMap,t=new WeakMap,n=null;function s(u,f=!1){return u==null?null:f?a(u):r(u)}function r(u){if(u&&u.isTexture){const f=u.mapping;if(f===fo||f===po)if(e.has(u)){const g=e.get(u).texture;return o(g,u.mapping)}else{const g=u.image;if(g&&g.height>0){const v=new Fc(g.height);return v.fromEquirectangularTexture(i,u),e.set(u,v),u.addEventListener("dispose",l),o(v.texture,u.mapping)}else return null}}return u}function a(u){if(u&&u.isTexture&&u.isPMREMTexture!==!0){const f=u.mapping,g=f===fo||f===po,v=f===Ls||f===gr;if(g||v){let p=t.get(u);const m=p!==void 0?p.texture.pmremVersion:0;if(u.isRenderTargetTexture&&u.pmremVersion!==m)return n===null&&(n=new Ka(i)),p=g?n.fromEquirectangular(u,p):n.fromCubemap(u,p),p.texture.pmremVersion=u.pmremVersion,t.set(u,p),p.texture;if(p!==void 0)return p.texture;{const x=u.image;return g&&x&&x.height>0||v&&x&&c(x)?(n===null&&(n=new Ka(i)),p=g?n.fromEquirectangular(u):n.fromCubemap(u),p.texture.pmremVersion=u.pmremVersion,t.set(u,p),u.addEventListener("dispose",h),p.texture):null}}}return u}function o(u,f){return f===fo?u.mapping=Ls:f===po&&(u.mapping=gr),u}function c(u){let f=0;const g=6;for(let v=0;v<g;v++)u[v]!==void 0&&f++;return f===g}function l(u){const f=u.target;f.removeEventListener("dispose",l);const g=e.get(f);g!==void 0&&(e.delete(f),g.dispose())}function h(u){const f=u.target;f.removeEventListener("dispose",h);const g=t.get(f);g!==void 0&&(t.delete(f),g.dispose())}function d(){e=new WeakMap,t=new WeakMap,n!==null&&(n.dispose(),n=null)}return{get:s,dispose:d}}function Sx(i){const e={};function t(n){if(e[n]!==void 0)return e[n];const s=i.getExtension(n);return e[n]=s,s}return{has:function(n){return t(n)!==null},init:function(){t("EXT_color_buffer_float"),t("WEBGL_clip_cull_distance"),t("OES_texture_float_linear"),t("EXT_color_buffer_half_float"),t("WEBGL_multisampled_render_to_texture"),t("WEBGL_render_shared_exponent")},get:function(n){const s=t(n);return s===null&&Pa("WebGLRenderer: "+n+" extension not supported."),s}}}function wx(i,e,t,n){const s={},r=new WeakMap,a=new FinalizationRegistry(g=>delete s[g]);function o(g){c(g.target)}function c(g){g.index!==null&&e.remove(g.index);for(const p in g.attributes)e.remove(g.attributes[p]);g.removeEventListener("dispose",o),delete s[g.id],a.unregister(g);const v=r.get(g);v&&(e.remove(v),r.delete(g)),n.releaseStatesOfGeometry(g),g.isInstancedBufferGeometry===!0&&delete g._maxInstanceCount,t.memory.geometries--}function l(g,v){return s[v.id]!==void 0||(v.addEventListener("dispose",o),s[v.id]=new WeakRef(v),a.register(v,v.id,v),t.memory.geometries++),v}function h(g){const v=g.attributes;for(const p in v)e.update(v[p],i.ARRAY_BUFFER)}function d(g){const v=g.index,p=g.attributes.position;let m=0;if(p===void 0)return;const x=v!==null?v.array.length:p.array.length/3-1,S=p.count>=65535?Ou:Fu,b=new S(Math.ceil(x/3)*6,1),A=b.array;if(v!==null){const y=v.array;m=v.version;for(let w=0,L=0;w<x;w+=3){const R=y[w+0],N=y[w+1],F=y[w+2];A[L++]=R,A[L++]=N,A[L++]=N,A[L++]=F,A[L++]=F,A[L++]=R}}else{m=p.version;for(let y=0,w=0;y<x;y+=3){const L=y+0,R=y+1,N=y+2;A[w++]=L,A[w++]=R,A[w++]=R,A[w++]=N,A[w++]=N,A[w++]=L}}b.version=m;const E=r.get(g);E&&e.remove(E),r.set(g,b)}function u(g){const v=r.get(g);if(v){const p=g.index;p!==null&&v.version<p.version&&d(g)}else d(g);return r.get(g)}function f(){for(const g in s){const v=s[g].deref();v!==void 0&&c(v)}}return{get:l,update:h,getWireframeAttribute:u,dispose:f}}function Ex(i,e,t){let n;function s(d){n=d}let r,a;function o(d){r=d.type,a=d.bytesPerElement}function c(d,u){i.drawElements(n,u,r,d*a),t.update(u,n,1)}function l(d,u,f){f!==0&&(i.drawElementsInstanced(n,u,r,d*a,f),t.update(u,n,f))}function h(d,u,f){if(f===0)return;e.get("WEBGL_multi_draw").multiDrawElementsWEBGL(n,u,0,r,d,0,f);let v=0;for(let p=0;p<f;p++)v+=u[p];t.update(v,n,1)}this.setMode=s,this.setIndex=o,this.render=c,this.renderInstances=l,this.renderMultiDraw=h}function Ax(i){const e={geometries:0,textures:0},t={frame:0,calls:0,triangles:0,points:0,lines:0};function n(r,a,o){switch(t.calls++,a){case i.TRIANGLES:t.triangles+=o*(r/3);break;case i.LINES:t.lines+=o*(r/2);break;case i.LINE_STRIP:t.lines+=o*(r-1);break;case i.LINE_LOOP:t.lines+=o*r;break;case i.POINTS:t.points+=o*r;break;default:Ze("WebGLInfo: Unknown draw mode:",a);break}}function s(){t.calls=0,t.triangles=0,t.points=0,t.lines=0}return{memory:e,render:t,programs:null,autoReset:!0,reset:s,update:n}}function Tx(i,e,t){const n=new WeakMap,s=new vt;function r(a,o,c){const l=a.morphTargetInfluences,h=o.morphAttributes.position||o.morphAttributes.normal||o.morphAttributes.color,d=h!==void 0?h.length:0;let u=n.get(o);if(u===void 0||u.count!==d){let R=function(){w.dispose(),n.delete(o),o.removeEventListener("dispose",R)};var f=R;u!==void 0&&u.texture.dispose();const g=o.morphAttributes.position!==void 0,v=o.morphAttributes.normal!==void 0,p=o.morphAttributes.color!==void 0,m=o.morphAttributes.position||[],x=o.morphAttributes.normal||[],S=o.morphAttributes.color||[];let b=0;g===!0&&(b=1),v===!0&&(b=2),p===!0&&(b=3);let A=o.attributes.position.count*b,E=1;A>e.maxTextureSize&&(E=Math.ceil(A/e.maxTextureSize),A=e.maxTextureSize);const y=new Float32Array(A*E*4*d),w=new Nu(y,A,E,d);w.type=Dn,w.needsUpdate=!0;const L=b*4;for(let N=0;N<d;N++){const F=m[N],V=x[N],I=S[N],H=A*E*4*N;for(let J=0;J<F.count;J++){const z=J*L;g===!0&&(s.fromBufferAttribute(F,J),y[H+z+0]=s.x,y[H+z+1]=s.y,y[H+z+2]=s.z,y[H+z+3]=0),v===!0&&(s.fromBufferAttribute(V,J),y[H+z+4]=s.x,y[H+z+5]=s.y,y[H+z+6]=s.z,y[H+z+7]=0),p===!0&&(s.fromBufferAttribute(I,J),y[H+z+8]=s.x,y[H+z+9]=s.y,y[H+z+10]=s.z,y[H+z+11]=I.itemSize===4?s.w:1)}}u={count:d,texture:w,size:new fe(A,E)},n.set(o,u),o.addEventListener("dispose",R)}if(a.isInstancedMesh===!0&&a.morphTexture!==null)c.getUniforms().setValue(i,"morphTexture",a.morphTexture,t);else{let g=0;for(let p=0;p<l.length;p++)g+=l[p];const v=o.morphTargetsRelative?1:1-g;c.getUniforms().setValue(i,"morphTargetBaseInfluence",v),c.getUniforms().setValue(i,"morphTargetInfluences",l)}c.getUniforms().setValue(i,"morphTargetsTexture",u.texture,t),c.getUniforms().setValue(i,"morphTargetsTextureSize",u.size)}return{update:r}}function Rx(i,e,t,n,s){let r=new WeakMap;function a(l){const h=s.render.frame,d=l.geometry,u=e.get(l,d);if(r.get(u)!==h&&(e.update(u),r.set(u,h)),l.isInstancedMesh&&(l.hasEventListener("dispose",c)===!1&&l.addEventListener("dispose",c),r.get(l)!==h&&(t.update(l.instanceMatrix,i.ARRAY_BUFFER),l.instanceColor!==null&&t.update(l.instanceColor,i.ARRAY_BUFFER),r.set(l,h))),l.isSkinnedMesh){const f=l.skeleton;r.get(f)!==h&&(f.update(),r.set(f,h))}return u}function o(){r=new WeakMap}function c(l){const h=l.target;h.removeEventListener("dispose",c),n.releaseStatesOfObject(h),t.remove(h.instanceMatrix),h.instanceColor!==null&&t.remove(h.instanceColor)}return{update:a,dispose:o}}const Cx={[mu]:"LINEAR_TONE_MAPPING",[gu]:"REINHARD_TONE_MAPPING",[vu]:"CINEON_TONE_MAPPING",[uc]:"ACES_FILMIC_TONE_MAPPING",[yu]:"AGX_TONE_MAPPING",[bu]:"NEUTRAL_TONE_MAPPING",[xu]:"CUSTOM_TONE_MAPPING"};function Px(i,e,t,n,s,r){const a=new Mn(e,t,{type:i,depthBuffer:s,stencilBuffer:r,samples:n?4:0,storeMultisampledDepthBuffer:!1,storeMultisampledStencilBuffer:!1,resolveDepthBuffer:!1,resolveStencilBuffer:!1});let o=null,c=null,l=null;const h=new pt;h.setAttribute("position",new He([-1,3,0,-1,-1,0,3,-1,0],3)),h.setAttribute("uv",new He([0,2,0,0,2,0],2));const d=new b0({uniforms:{tDiffuse:{value:null}},vertexShader:`
			precision highp float;

			uniform mat4 modelViewMatrix;
			uniform mat4 projectionMatrix;

			attribute vec3 position;
			attribute vec2 uv;

			varying vec2 vUv;

			void main() {
				vUv = uv;
				gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
			}`,fragmentShader:`
			precision highp float;

			uniform sampler2D tDiffuse;

			varying vec2 vUv;

			#include <tonemapping_pars_fragment>
			#include <colorspace_pars_fragment>

			void main() {
				gl_FragColor = texture2D( tDiffuse, vUv );

				#ifdef LINEAR_TONE_MAPPING
					gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );
				#elif defined( REINHARD_TONE_MAPPING )
					gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );
				#elif defined( CINEON_TONE_MAPPING )
					gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );
				#elif defined( ACES_FILMIC_TONE_MAPPING )
					gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );
				#elif defined( AGX_TONE_MAPPING )
					gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );
				#elif defined( NEUTRAL_TONE_MAPPING )
					gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );
				#elif defined( CUSTOM_TONE_MAPPING )
					gl_FragColor.rgb = CustomToneMapping( gl_FragColor.rgb );
				#endif

				#ifdef SRGB_TRANSFER
					gl_FragColor = sRGBTransferOETF( gl_FragColor );
				#endif
			}`,depthTest:!1,depthWrite:!1}),u=new je(h,d),f=new Uc(-1,1,1,-1,0,1);let g=null,v=null,p=!1,m,x=null,S=[],b=!1;this.setSize=function(A,E){a.setSize(A,E),o!==null&&o.setSize(A,E),c!==null&&c.setSize(A,E);for(let y=0;y<S.length;y++){const w=S[y];w.setSize&&w.setSize(A,E)}},this.setEffects=function(A){S=A,b=S.length>0&&S[0].isRenderPass===!0;const E=a.width,y=a.height;S.length>0&&o===null&&(o=new Mn(E,y,{type:Jn,depthBuffer:!1,stencilBuffer:!1}),c=new Mn(E,y,{type:Jn,depthBuffer:!1,stencilBuffer:!1}));const w=s===!0&&S.some(L=>L.needsDepthTexture===!0);w!==(a.depthTexture!==null)&&(w===!0&&l===null&&(l=new Is(E,y),r===!0&&(l.format=Ti,l.type=Ds)),a.dispose(),a.depthTexture=w?l:null,a.resolveDepthBuffer=w,a.storeMultisampledDepthBuffer=w);for(let L=0;L<S.length;L++){const R=S[L];R.setSize&&R.setSize(E,y),w&&R.needsDepthTexture===!0&&R.setDepthTexture&&R.setDepthTexture(l)}},this.begin=function(A,E){if(p||A.toneMapping===di&&S.length===0)return!1;if(x=E,E!==null){const y=E.width,w=E.height;(a.width!==y||a.height!==w)&&this.setSize(y,w)}return b===!1&&A.setRenderTarget(a),m=A.toneMapping,A.toneMapping=di,!0},this.hasRenderPass=function(){return b},this.end=function(A,E){A.toneMapping=m,p=!0;let y=a,w=o;for(let L=0;L<S.length;L++){const R=S[L];R.enabled!==!1&&(R.render(A,w,y,E),R.needsSwap!==!1&&(y=w,w=w===o?c:o))}if(g!==A.outputColorSpace||v!==A.toneMapping){g=A.outputColorSpace,v=A.toneMapping,d.defines={},Xe.getTransfer(g)===st&&(d.defines.SRGB_TRANSFER="");const L=Cx[v];L&&(d.defines[L]=""),d.needsUpdate=!0}d.uniforms.tDiffuse.value=y.texture,A.setRenderTarget(x),A.render(u,f),x=null,p=!1},this.isCompositing=function(){return p},this.dispose=function(){a.dispose(),o!==null&&o.dispose(),c!==null&&c.dispose(),h.dispose(),d.dispose()}}const cf=new Jt,hf=new Is(1,1),df=new Vu(1),uf=new Nu,ff=new xm,pf=new Hu,hd=[],dd=[],ud=new Float32Array(16),fd=new Float32Array(9),pd=new Float32Array(4);function Os(i,e,t){const n=i[0];if(n<=0||n>0)return i;const s=e*t;let r=hd[s];if(r===void 0&&(r=new Float32Array(s),hd[s]=r),e!==0){n.toArray(r,0);for(let a=1,o=0;a!==e;++a)o+=t,i[a].toArray(r,o)}return r}function Pt(i,e){if(i.length!==e.length)return!1;for(let t=0,n=i.length;t<n;t++)if(i[t]!==e[t])return!1;return!0}function Lt(i,e){for(let t=0,n=e.length;t<n;t++)i[t]=e[t]}function ro(i,e){let t=dd[e];t===void 0&&(t=new Int32Array(e),dd[e]=t);for(let n=0;n!==e;++n)t[n]=i.allocateTextureUnit();return t}function Lx(i,e){const t=this.cache;t[0]!==e&&(i.uniform1f(this.addr,e),t[0]=e)}function Dx(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2f(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Pt(t,e))return;i.uniform2fv(this.addr,e),Lt(t,e)}}function Ix(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3f(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else if(e.r!==void 0)(t[0]!==e.r||t[1]!==e.g||t[2]!==e.b)&&(i.uniform3f(this.addr,e.r,e.g,e.b),t[0]=e.r,t[1]=e.g,t[2]=e.b);else{if(Pt(t,e))return;i.uniform3fv(this.addr,e),Lt(t,e)}}function Nx(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4f(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Pt(t,e))return;i.uniform4fv(this.addr,e),Lt(t,e)}}function Ux(i,e){const t=this.cache,n=e.elements;if(n===void 0){if(Pt(t,e))return;i.uniformMatrix2fv(this.addr,!1,e),Lt(t,e)}else{if(Pt(t,n))return;pd.set(n),i.uniformMatrix2fv(this.addr,!1,pd),Lt(t,n)}}function Fx(i,e){const t=this.cache,n=e.elements;if(n===void 0){if(Pt(t,e))return;i.uniformMatrix3fv(this.addr,!1,e),Lt(t,e)}else{if(Pt(t,n))return;fd.set(n),i.uniformMatrix3fv(this.addr,!1,fd),Lt(t,n)}}function Ox(i,e){const t=this.cache,n=e.elements;if(n===void 0){if(Pt(t,e))return;i.uniformMatrix4fv(this.addr,!1,e),Lt(t,e)}else{if(Pt(t,n))return;ud.set(n),i.uniformMatrix4fv(this.addr,!1,ud),Lt(t,n)}}function kx(i,e){const t=this.cache;t[0]!==e&&(i.uniform1i(this.addr,e),t[0]=e)}function Bx(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2i(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Pt(t,e))return;i.uniform2iv(this.addr,e),Lt(t,e)}}function zx(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3i(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(Pt(t,e))return;i.uniform3iv(this.addr,e),Lt(t,e)}}function Gx(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4i(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Pt(t,e))return;i.uniform4iv(this.addr,e),Lt(t,e)}}function Hx(i,e){const t=this.cache;t[0]!==e&&(i.uniform1ui(this.addr,e),t[0]=e)}function Vx(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2ui(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Pt(t,e))return;i.uniform2uiv(this.addr,e),Lt(t,e)}}function Wx(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3ui(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(Pt(t,e))return;i.uniform3uiv(this.addr,e),Lt(t,e)}}function $x(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4ui(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Pt(t,e))return;i.uniform4uiv(this.addr,e),Lt(t,e)}}function ao(i){return i.version===0&&(i.compareFunction=Pu,i.needsUpdate=!0),i}function qx(i,e,t){const n=this.cache,s=t.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s);let r;this.type===i.SAMPLER_2D_SHADOW?r=ao(hf):r=cf,t.setTexture2D(e||r,s)}function Xx(i,e,t){const n=this.cache,s=t.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),t.setTexture3D(e||ff,s)}function Yx(i,e,t){const n=this.cache,s=t.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s);let r;this.type===i.SAMPLER_CUBE_SHADOW?r=ao(df):r=pf,t.setTextureCube(e||r,s)}function Kx(i,e,t){const n=this.cache,s=t.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),t.setTexture2DArray(e||uf,s)}function Jx(i){switch(i){case 5126:return Lx;case 35664:return Dx;case 35665:return Ix;case 35666:return Nx;case 35674:return Ux;case 35675:return Fx;case 35676:return Ox;case 5124:case 35670:return kx;case 35667:case 35671:return Bx;case 35668:case 35672:return zx;case 35669:case 35673:return Gx;case 5125:return Hx;case 36294:return Vx;case 36295:return Wx;case 36296:return $x;case 35678:case 36198:case 36298:case 36306:case 35682:return qx;case 35679:case 36299:case 36307:return Xx;case 35680:case 36300:case 36308:case 36293:return Yx;case 36289:case 36303:case 36311:case 36292:return Kx}}function Zx(i,e){i.uniform1fv(this.addr,e)}function Qx(i,e){const t=Os(e,this.size,2);i.uniform2fv(this.addr,t)}function jx(i,e){const t=Os(e,this.size,3);i.uniform3fv(this.addr,t)}function ey(i,e){const t=Os(e,this.size,4);i.uniform4fv(this.addr,t)}function ty(i,e){const t=Os(e,this.size,4);i.uniformMatrix2fv(this.addr,!1,t)}function ny(i,e){const t=Os(e,this.size,9);i.uniformMatrix3fv(this.addr,!1,t)}function iy(i,e){const t=Os(e,this.size,16);i.uniformMatrix4fv(this.addr,!1,t)}function sy(i,e){i.uniform1iv(this.addr,e)}function ry(i,e){i.uniform2iv(this.addr,e)}function ay(i,e){i.uniform3iv(this.addr,e)}function oy(i,e){i.uniform4iv(this.addr,e)}function ly(i,e){i.uniform1uiv(this.addr,e)}function cy(i,e){i.uniform2uiv(this.addr,e)}function hy(i,e){i.uniform3uiv(this.addr,e)}function dy(i,e){i.uniform4uiv(this.addr,e)}function uy(i,e,t){const n=this.cache,s=e.length,r=ro(t,s);Pt(n,r)||(i.uniform1iv(this.addr,r),Lt(n,r));let a;this.type===i.SAMPLER_2D_SHADOW?a=ao(hf):a=cf;for(let o=0;o!==s;++o)t.setTexture2D(e[o]||a,r[o])}function fy(i,e,t){const n=this.cache,s=e.length,r=ro(t,s);Pt(n,r)||(i.uniform1iv(this.addr,r),Lt(n,r));for(let a=0;a!==s;++a)t.setTexture3D(e[a]||ff,r[a])}function py(i,e,t){const n=this.cache,s=e.length,r=ro(t,s);Pt(n,r)||(i.uniform1iv(this.addr,r),Lt(n,r));let a;this.type===i.SAMPLER_CUBE_SHADOW?a=ao(df):a=pf;for(let o=0;o!==s;++o)t.setTextureCube(e[o]||a,r[o])}function my(i,e,t){const n=this.cache,s=e.length,r=ro(t,s);Pt(n,r)||(i.uniform1iv(this.addr,r),Lt(n,r));for(let a=0;a!==s;++a)t.setTexture2DArray(e[a]||uf,r[a])}function gy(i){switch(i){case 5126:return Zx;case 35664:return Qx;case 35665:return jx;case 35666:return ey;case 35674:return ty;case 35675:return ny;case 35676:return iy;case 5124:case 35670:return sy;case 35667:case 35671:return ry;case 35668:case 35672:return ay;case 35669:case 35673:return oy;case 5125:return ly;case 36294:return cy;case 36295:return hy;case 36296:return dy;case 35678:case 36198:case 36298:case 36306:case 35682:return uy;case 35679:case 36299:case 36307:return fy;case 35680:case 36300:case 36308:case 36293:return py;case 36289:case 36303:case 36311:case 36292:return my}}class vy{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.setValue=Jx(t.type)}}class xy{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.size=t.size,this.setValue=gy(t.type)}}class yy{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,t,n){const s=this.seq;for(let r=0,a=s.length;r!==a;++r){const o=s[r];o.setValue(e,t[o.id],n)}}}const Vo=/(\w+)(\])?(\[|\.)?/g;function md(i,e){i.seq.push(e),i.map[e.id]=e}function by(i,e,t){const n=i.name,s=n.length;for(Vo.lastIndex=0;;){const r=Vo.exec(n),a=Vo.lastIndex;let o=r[1];const c=r[2]==="]",l=r[3];if(c&&(o=o|0),l===void 0||l==="["&&a+2===s){md(t,l===void 0?new vy(o,i,e):new xy(o,i,e));break}else{let d=t.map[o];d===void 0&&(d=new yy(o),md(t,d)),t=d}}}class La{constructor(e,t){this.seq=[],this.map={};const n=e.getProgramParameter(t,e.ACTIVE_UNIFORMS);for(let a=0;a<n;++a){const o=e.getActiveUniform(t,a),c=e.getUniformLocation(t,o.name);by(o,c,this)}const s=[],r=[];for(const a of this.seq)a.type===e.SAMPLER_2D_SHADOW||a.type===e.SAMPLER_CUBE_SHADOW||a.type===e.SAMPLER_2D_ARRAY_SHADOW?s.push(a):r.push(a);s.length>0&&(this.seq=s.concat(r))}setValue(e,t,n,s){const r=this.map[t];r!==void 0&&r.setValue(e,n,s)}setOptional(e,t,n){const s=t[n];s!==void 0&&this.setValue(e,n,s)}static upload(e,t,n,s){for(let r=0,a=t.length;r!==a;++r){const o=t[r],c=n[o.id];c.needsUpdate!==!1&&o.setValue(e,c.value,s)}}static seqWithValue(e,t){const n=[];for(let s=0,r=e.length;s!==r;++s){const a=e[s];a.id in t&&n.push(a)}return n}}function gd(i,e,t){const n=i.createShader(e);return i.shaderSource(n,t),i.compileShader(n),n}const _y=37297;let My=0;function Sy(i,e){const t=i.split(`
`),n=[],s=Math.max(e-6,0),r=Math.min(e+6,t.length);for(let a=s;a<r;a++){const o=a+1;n.push(`${o===e?">":" "} ${o}: ${t[a]}`)}return n.join(`
`)}const vd=new Ne;function wy(i){Xe._getMatrix(vd,Xe.workingColorSpace,i);const e=`mat3( ${vd.elements.map(t=>t.toFixed(4))} )`;switch(Xe.getTransfer(i)){case Ga:return[e,"LinearTransferOETF"];case st:return[e,"sRGBTransferOETF"];default:return Le("WebGLProgram: Unsupported color space: ",i),[e,"LinearTransferOETF"]}}function xd(i,e,t){const n=i.getShaderParameter(e,i.COMPILE_STATUS),r=(i.getShaderInfoLog(e)||"").trim();if(n&&r==="")return"";const a=/ERROR: 0:(\d+)/.exec(r);if(a){const o=parseInt(a[1]);return t.toUpperCase()+`

`+r+`

`+Sy(i.getShaderSource(e),o)}else return r}function Ey(i,e){const t=wy(e);return[`vec4 ${i}( vec4 value ) {`,`	return ${t[1]}( vec4( ${t[0]} * value.rgb, value.a ) );`,"}"].join(`
`)}const Ay={[mu]:"Linear",[gu]:"Reinhard",[vu]:"Cineon",[uc]:"ACESFilmic",[yu]:"AgX",[bu]:"Neutral",[xu]:"Custom"};function Ty(i,e){const t=Ay[e];return t===void 0?(Le("WebGLProgram: Unsupported toneMapping:",e),"vec3 "+i+"( vec3 color ) { return LinearToneMapping( color ); }"):"vec3 "+i+"( vec3 color ) { return "+t+"ToneMapping( color ); }"}const ga=new P;function Ry(){Xe.getLuminanceCoefficients(ga);const i=ga.x.toFixed(4),e=ga.y.toFixed(4),t=ga.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${i}, ${e}, ${t} );`,"	return dot( weights, rgb );","}"].join(`
`)}function Cy(i){return[i.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",i.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(tr).join(`
`)}function Py(i){const e=[];for(const t in i){const n=i[t];n!==!1&&e.push("#define "+t+" "+n)}return e.join(`
`)}function Ly(i,e){const t={},n=i.getProgramParameter(e,i.ACTIVE_ATTRIBUTES);for(let s=0;s<n;s++){const r=i.getActiveAttrib(e,s),a=r.name;let o=1;r.type===i.FLOAT_MAT2&&(o=2),r.type===i.FLOAT_MAT3&&(o=3),r.type===i.FLOAT_MAT4&&(o=4),t[a]={type:r.type,location:i.getAttribLocation(e,a),locationSize:o}}return t}function tr(i){return i!==""}function yd(i,e){const t=e.numSpotLightShadows+e.numSpotLightMaps-e.numSpotLightShadowsWithMaps;return i.replace(/NUM_SUN_LIGHTS/g,e.numSunLights).replace(/NUM_DIR_LIGHTS/g,e.numDirLights).replace(/NUM_SPOT_LIGHTS/g,e.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,e.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,t).replace(/NUM_RECT_AREA_LIGHTS/g,e.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,e.numPointLights).replace(/NUM_HEMI_LIGHTS/g,e.numHemiLights).replace(/NUM_SUN_LIGHT_SHADOWS/g,e.numSunLightShadows).replace(/NUM_DIR_LIGHT_SHADOWS/g,e.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,e.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,e.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,e.numPointLightShadows).replace(/NUM_LIGHT_PROBE_GRIDS/g,e.numLightProbeGrids)}function bd(i,e){return i.replace(/NUM_CLIPPING_PLANES/g,e.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,e.numClippingPlanes-e.numClipIntersection)}const Dy=/^[ \t]*#include +<([\w\d./]+)>/gm;function $l(i){return i.replace(Dy,Iy)}function Iy(i,e){const t=ze[e];if(t===void 0)throw new Error("THREE.WebGLProgram: Can not resolve #include <"+e+">");return $l(t)}const Ny=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function _d(i){return i.replace(Ny,Uy)}function Uy(i,e,t,n){let s="";for(let r=parseInt(e);r<parseInt(t);r++)s+=n.replace(/\[\s*i\s*\]/g,"[ "+r+" ]").replace(/UNROLLED_LOOP_INDEX/g,r);return s}function Md(i){let e=`precision ${i.precision} float;
	precision ${i.precision} int;
	precision ${i.precision} sampler2D;
	precision ${i.precision} samplerCube;
	precision ${i.precision} sampler3D;
	precision ${i.precision} sampler2DArray;
	precision ${i.precision} sampler2DShadow;
	precision ${i.precision} samplerCubeShadow;
	precision ${i.precision} sampler2DArrayShadow;
	precision ${i.precision} isampler2D;
	precision ${i.precision} isampler3D;
	precision ${i.precision} isamplerCube;
	precision ${i.precision} isampler2DArray;
	precision ${i.precision} usampler2D;
	precision ${i.precision} usampler3D;
	precision ${i.precision} usamplerCube;
	precision ${i.precision} usampler2DArray;
	`;return i.precision==="highp"?e+=`
#define HIGH_PRECISION`:i.precision==="mediump"?e+=`
#define MEDIUM_PRECISION`:i.precision==="lowp"&&(e+=`
#define LOW_PRECISION`),e}const Fy={[Ea]:"SHADOWMAP_TYPE_PCF",[js]:"SHADOWMAP_TYPE_VSM"};function Oy(i){return Fy[i.shadowMapType]||"SHADOWMAP_TYPE_BASIC"}const ky={[gr]:"ENVMAP_MODE_REFRACTION"};function By(i){return i.envMap===!1?"ENVMAP_MODE_REFLECTION":ky[i.envMapMode]||"ENVMAP_MODE_REFLECTION"}const zy={[pu]:"ENVMAP_BLENDING_MULTIPLY",[Op]:"ENVMAP_BLENDING_MIX",[kp]:"ENVMAP_BLENDING_ADD"};function Gy(i){return i.envMap===!1?"ENVMAP_BLENDING_NONE":zy[i.combine]||"ENVMAP_BLENDING_NONE"}function Hy(i,e,t,n){const s=i.getContext(),r=t.defines;let a=t.vertexShader,o=t.fragmentShader;const c=Oy(t),l=t.envMapPMREM===!0?"ENVMAP_TYPE_PMREM":"ENVMAP_TYPE_CUBE",h=By(t),d=Gy(t),u=Cy(t),f=Py(r),g=s.createProgram();let v,p,m=t.glslVersion?"#version "+t.glslVersion+`
`:"";t.isRawShaderMaterial?(v=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,f].filter(tr).join(`
`),v.length>0&&(v+=`
`),p=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,f].filter(tr).join(`
`),p.length>0&&(p+=`
`)):(v=[Md(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,f,t.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",t.batching?"#define USE_BATCHING":"",t.batchingColor?"#define USE_BATCHING_COLOR":"",t.instancing?"#define USE_INSTANCING":"",t.instancingColor?"#define USE_INSTANCING_COLOR":"",t.instancingMorph?"#define USE_INSTANCING_MORPH":"",t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+h:"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.displacementMap?"#define USE_DISPLACEMENTMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.diffuseRoughnessMap?"#define USE_DIFFUSE_ROUGHNESSMAP":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.mapUv?"#define MAP_UV "+t.mapUv:"",t.alphaMapUv?"#define ALPHAMAP_UV "+t.alphaMapUv:"",t.lightMapUv?"#define LIGHTMAP_UV "+t.lightMapUv:"",t.aoMapUv?"#define AOMAP_UV "+t.aoMapUv:"",t.emissiveMapUv?"#define EMISSIVEMAP_UV "+t.emissiveMapUv:"",t.bumpMapUv?"#define BUMPMAP_UV "+t.bumpMapUv:"",t.normalMapUv?"#define NORMALMAP_UV "+t.normalMapUv:"",t.displacementMapUv?"#define DISPLACEMENTMAP_UV "+t.displacementMapUv:"",t.metalnessMapUv?"#define METALNESSMAP_UV "+t.metalnessMapUv:"",t.roughnessMapUv?"#define ROUGHNESSMAP_UV "+t.roughnessMapUv:"",t.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+t.anisotropyMapUv:"",t.clearcoatMapUv?"#define CLEARCOATMAP_UV "+t.clearcoatMapUv:"",t.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+t.clearcoatNormalMapUv:"",t.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+t.clearcoatRoughnessMapUv:"",t.diffuseRoughnessMapUv?"#define DIFFUSE_ROUGHNESSMAP_UV "+t.diffuseRoughnessMapUv:"",t.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+t.iridescenceMapUv:"",t.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+t.iridescenceThicknessMapUv:"",t.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+t.sheenColorMapUv:"",t.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+t.sheenRoughnessMapUv:"",t.specularMapUv?"#define SPECULARMAP_UV "+t.specularMapUv:"",t.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+t.specularColorMapUv:"",t.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+t.specularIntensityMapUv:"",t.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+t.transmissionMapUv:"",t.thicknessMapUv?"#define THICKNESSMAP_UV "+t.thicknessMapUv:"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexNormals?"#define HAS_NORMAL":"",t.vertexColors?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.flatShading?"#define FLAT_SHADED":"",t.skinning?"#define USE_SKINNING":"",t.morphTargets?"#define USE_MORPHTARGETS":"",t.morphNormals&&t.flatShading===!1?"#define USE_MORPHNORMALS":"",t.morphColors?"#define USE_MORPHCOLORS":"",t.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+t.morphTextureStride:"",t.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+t.morphTargetsCount:"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+c:"",t.sizeAttenuation?"#define USE_SIZEATTENUATION":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",t.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(tr).join(`
`),p=[Md(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,f,t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",t.map?"#define USE_MAP":"",t.matcap?"#define USE_MATCAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+l:"",t.envMap?"#define "+h:"",t.envMap?"#define "+d:"",t.envMapPMREM?"#define ENVMAP_MAX_LOD "+t.envMapMaxLod+".0":"",t.envMapPMREM?"#define ENVMAP_SIZE "+t.envMapSize+".0":"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.packedNormalMap?"#define USE_PACKED_NORMALMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoat?"#define USE_CLEARCOAT":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.diffuseRoughness?"#define USE_DIFFUSE_ROUGHNESS":"",t.diffuseRoughnessMap?"#define USE_DIFFUSE_ROUGHNESSMAP":"",t.dispersion?"#define USE_DISPERSION":"",t.retroreflection?"#define USE_RETROREFLECTION":"",t.iridescence?"#define USE_IRIDESCENCE":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaTest?"#define USE_ALPHATEST":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.sheen?"#define USE_SHEEN":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors||t.instancingColor?"#define USE_COLOR":"",t.vertexAlphas||t.batchingColor?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.gradientMap?"#define USE_GRADIENTMAP":"",t.flatShading?"#define FLAT_SHADED":"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+c:"",t.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",t.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",t.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",t.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",t.toneMapping!==di?"#define TONE_MAPPING":"",t.toneMapping!==di?ze.tonemapping_pars_fragment:"",t.toneMapping!==di?Ty("toneMapping",t.toneMapping):"",t.dithering?"#define DITHERING":"",t.opaque?"#define OPAQUE":"",ze.colorspace_pars_fragment,Ey("linearToOutputTexel",t.outputColorSpace),Ry(),t.useDepthPacking?"#define DEPTH_PACKING "+t.depthPacking:"",`
`].filter(tr).join(`
`)),a=$l(a),a=yd(a,t),a=bd(a,t),o=$l(o),o=yd(o,t),o=bd(o,t),a=_d(a),o=_d(o),t.isRawShaderMaterial!==!0&&(m=`#version 300 es
`,v=[u,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+v,p=["#define varying in",t.glslVersion===mh?"":"layout(location = 0) out highp vec4 pc_fragColor;",t.glslVersion===mh?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+p);const x=m+v+a,S=m+p+o,b=gd(s,s.VERTEX_SHADER,x),A=gd(s,s.FRAGMENT_SHADER,S);s.attachShader(g,b),s.attachShader(g,A),t.index0AttributeName!==void 0?s.bindAttribLocation(g,0,t.index0AttributeName):t.hasPositionAttribute===!0&&s.bindAttribLocation(g,0,"position"),s.linkProgram(g);function E(R){if(i.debug.checkShaderErrors){const N=s.getProgramInfoLog(g)||"",F=s.getShaderInfoLog(b)||"",V=s.getShaderInfoLog(A)||"",I=N.trim(),H=F.trim(),J=V.trim();let z=!0,ne=!0;if(s.getProgramParameter(g,s.LINK_STATUS)===!1)if(z=!1,typeof i.debug.onShaderError=="function")i.debug.onShaderError(s,g,b,A);else{const $=xd(s,b,"vertex"),j=xd(s,A,"fragment");Ze("WebGLProgram: Shader Error "+s.getError()+" - VALIDATE_STATUS "+s.getProgramParameter(g,s.VALIDATE_STATUS)+`

Material Name: `+R.name+`
Material Type: `+R.type+`

Program Info Log: `+I+`
`+$+`
`+j)}else I!==""?Le("WebGLProgram: Program Info Log:",I):(H===""||J==="")&&(ne=!1);ne&&(R.diagnostics={runnable:z,programLog:I,vertexShader:{log:H,prefix:v},fragmentShader:{log:J,prefix:p}})}s.deleteShader(b),s.deleteShader(A),y=new La(s,g),w=Ly(s,g)}let y;this.getUniforms=function(){return y===void 0&&E(this),y};let w;this.getAttributes=function(){return w===void 0&&E(this),w};let L=t.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return L===!1&&(L=s.getProgramParameter(g,_y)),L},this.destroy=function(){n.releaseStatesOfProgram(this),s.deleteProgram(g),this.program=void 0},this.type=t.shaderType,this.name=t.shaderName,this.id=My++,this.cacheKey=e,this.usedTimes=1,this.program=g,this.vertexShader=b,this.fragmentShader=A,this}let Vy=0;class Wy{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e,t,n){const s=this._getShaderCacheForMaterial(e);return s.has(t)===!1&&(s.add(t),t.usedTimes++),s.has(n)===!1&&(s.add(n),n.usedTimes++),this}remove(e){const t=this.materialCache.get(e);for(const n of t)n.usedTimes--,n.usedTimes===0&&this.shaderCache.delete(n.code);return this.materialCache.delete(e),this}getVertexShaderStage(e){return this._getShaderStage(e.vertexShader)}getFragmentShaderStage(e){return this._getShaderStage(e.fragmentShader)}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){const t=this.materialCache;let n=t.get(e);return n===void 0&&(n=new Set,t.set(e,n)),n}_getShaderStage(e){const t=this.shaderCache;let n=t.get(e);return n===void 0&&(n=new $y(e),t.set(e,n)),n}}class $y{constructor(e){this.id=Vy++,this.code=e,this.usedTimes=0}}function qy(i){return i===Ji||i===ka||i===Ba}function Xy(i,e,t,n,s,r){const a=new wc,o=new Wy,c=new Set,l=[],h=new Map,d=n.logarithmicDepthBuffer,u={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distance",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function f(y){return c.add(y),y===0?"uv":`uv${y}`}function g(y,w,L,R,N,F){const V=R.fog,I=N.geometry,H=y.isMeshStandardMaterial||y.isMeshLambertMaterial||y.isMeshPhongMaterial?R.environment:null,J=y.isMeshStandardMaterial||y.isMeshLambertMaterial&&!y.envMap||y.isMeshPhongMaterial&&!y.envMap,z=e.get(y.envMap||H,J),ne=u[y.type];let $=n.precision;y.precision!==null&&($=n.getMaxPrecision(y.precision),$!==y.precision&&Le("WebGLProgram.getParameters:",y.precision,"not supported, using",$,"instead."));const j=I.morphAttributes.position||I.morphAttributes.normal||I.morphAttributes.color,ee=j!==void 0?j.length:0;let we=0;I.morphAttributes.position!==void 0&&(we=1),I.morphAttributes.normal!==void 0&&(we=2),I.morphAttributes.color!==void 0&&(we=3);let Ue,Y,ve,_e;if(ne){const ge=Wn[ne];Ue=ge.vertexShader,Y=ge.fragmentShader}else{Ue=y.vertexShader,Y=y.fragmentShader;const ge=o.getVertexShaderStage(y),it=o.getFragmentShaderStage(y);o.update(y,ge,it),ve=ge.id,_e=it.id}const Ce=i.getRenderTarget(),xe=i.state.buffers.depth.getReversed(),Oe=N.isInstancedMesh===!0,_t=N.isBatchedMesh===!0,De=!!y.map,nt=!!y.matcap,ot=!!z,Ve=ot&&z.isPMREMTexture===!0,kt=!!y.aoMap,At=!!y.lightMap,rn=!!y.bumpMap&&y.wireframe===!1,mt=!!y.normalMap,zn=!!y.displacementMap,Dt=!!y.emissiveMap,pn=!!y.metalnessMap,mn=!!y.roughnessMap,gn=y.anisotropy>0,U=y.clearcoat>0,vn=y.diffuseRoughness>0,ut=y.dispersion>0,ft=y.retroreflectivity>0,pe=y.iridescence>0,Tt=y.sheen>0,Pe=y.transmission>0,Ie=gn&&!!y.anisotropyMap,T=U&&!!y.clearcoatMap,_=U&&!!y.clearcoatNormalMap,k=U&&!!y.clearcoatRoughnessMap,te=vn&&!!y.diffuseRoughnessMap,Z=pe&&!!y.iridescenceMap,ae=pe&&!!y.iridescenceThicknessMap,de=Tt&&!!y.sheenColorMap,q=Tt&&!!y.sheenRoughnessMap,X=!!y.specularMap,le=!!y.specularColorMap,C=!!y.specularIntensityMap,K=Pe&&!!y.transmissionMap,W=Pe&&!!y.thicknessMap,ce=!!y.gradientMap,se=!!y.alphaMap,oe=y.alphaTest>0,Ae=!!y.alphaHash,Be=!!y.extensions;let ie=di;y.toneMapped&&(Ce===null||Ce.isXRRenderTarget===!0)&&(ie=i.toneMapping);const Re=Ve?z.isCompressedCubeTexture?z.image[0].mipmaps:z.mipmaps:null,ke={shaderID:ne,shaderType:y.type,shaderName:y.name,vertexShader:Ue,fragmentShader:Y,defines:y.defines,customVertexShaderID:ve,customFragmentShaderID:_e,isRawShaderMaterial:y.isRawShaderMaterial===!0,glslVersion:y.glslVersion,precision:$,batching:_t,batchingColor:_t&&N._colorsTexture!==null,instancing:Oe,instancingColor:Oe&&N.instanceColor!==null,instancingMorph:Oe&&N.morphTexture!==null,outputColorSpace:Ce===null?i.outputColorSpace:Ce.isXRRenderTarget===!0?Ce.texture.colorSpace:Xe.workingColorSpace,alphaToCoverage:!!y.alphaToCoverage,map:De,matcap:nt,envMap:ot,envMapMode:ot&&z.mapping,envMapPMREM:Ve,envMapMaxLod:Ve?Re.length-1:null,envMapSize:Ve?Re[0].width:null,aoMap:kt,lightMap:At,bumpMap:rn,normalMap:mt,displacementMap:zn,emissiveMap:Dt,normalMapObjectSpace:mt&&y.normalMapType===Gp,normalMapTangentSpace:mt&&y.normalMapType===Fl,packedNormalMap:mt&&y.normalMapType===Fl&&qy(y.normalMap.format),metalnessMap:pn,roughnessMap:mn,anisotropy:gn,anisotropyMap:Ie,clearcoat:U,clearcoatMap:T,clearcoatNormalMap:_,clearcoatRoughnessMap:k,diffuseRoughness:vn,diffuseRoughnessMap:te,dispersion:ut,retroreflection:ft,iridescence:pe,iridescenceMap:Z,iridescenceThicknessMap:ae,sheen:Tt,sheenColorMap:de,sheenRoughnessMap:q,specularMap:X,specularColorMap:le,specularIntensityMap:C,transmission:Pe,transmissionMap:K,thicknessMap:W,gradientMap:ce,opaque:y.transparent===!1&&y.blending===rr&&y.alphaToCoverage===!1,alphaMap:se,alphaTest:oe,alphaHash:Ae,combine:y.combine,mapUv:De&&f(y.map.channel),aoMapUv:kt&&f(y.aoMap.channel),lightMapUv:At&&f(y.lightMap.channel),bumpMapUv:rn&&f(y.bumpMap.channel),normalMapUv:mt&&f(y.normalMap.channel),displacementMapUv:zn&&f(y.displacementMap.channel),emissiveMapUv:Dt&&f(y.emissiveMap.channel),metalnessMapUv:pn&&f(y.metalnessMap.channel),roughnessMapUv:mn&&f(y.roughnessMap.channel),anisotropyMapUv:Ie&&f(y.anisotropyMap.channel),clearcoatMapUv:T&&f(y.clearcoatMap.channel),clearcoatNormalMapUv:_&&f(y.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:k&&f(y.clearcoatRoughnessMap.channel),diffuseRoughnessMapUv:te&&f(y.diffuseRoughnessMap.channel),iridescenceMapUv:Z&&f(y.iridescenceMap.channel),iridescenceThicknessMapUv:ae&&f(y.iridescenceThicknessMap.channel),sheenColorMapUv:de&&f(y.sheenColorMap.channel),sheenRoughnessMapUv:q&&f(y.sheenRoughnessMap.channel),specularMapUv:X&&f(y.specularMap.channel),specularColorMapUv:le&&f(y.specularColorMap.channel),specularIntensityMapUv:C&&f(y.specularIntensityMap.channel),transmissionMapUv:K&&f(y.transmissionMap.channel),thicknessMapUv:W&&f(y.thicknessMap.channel),alphaMapUv:se&&f(y.alphaMap.channel),vertexTangents:!!I.attributes.tangent&&(mt||gn),vertexNormals:!!I.attributes.normal,vertexColors:y.vertexColors,vertexAlphas:y.vertexColors===!0&&!!I.attributes.color&&I.attributes.color.itemSize===4,pointsUvs:N.isPoints===!0&&!!I.attributes.uv&&(De||se),fog:!!V,useFog:y.fog===!0,fogExp2:!!V&&V.isFogExp2,flatShading:y.wireframe===!1&&(y.flatShading===!0||I.attributes.normal===void 0&&mt===!1&&(y.isMeshLambertMaterial||y.isMeshPhongMaterial||y.isMeshStandardMaterial||y.isMeshPhysicalMaterial)),sizeAttenuation:y.sizeAttenuation===!0,logarithmicDepthBuffer:d,reversedDepthBuffer:xe,skinning:N.isSkinnedMesh===!0,hasPositionAttribute:I.attributes.position!==void 0,morphTargets:I.morphAttributes.position!==void 0,morphNormals:I.morphAttributes.normal!==void 0,morphColors:I.morphAttributes.color!==void 0,morphTargetsCount:ee,morphTextureStride:we,numSunLights:w.sun.length,numDirLights:w.directional.length,numPointLights:w.point.length,numSpotLights:w.spot.length,numSpotLightMaps:w.spotLightMap.length,numRectAreaLights:w.rectArea.length,numHemiLights:w.hemi.length,numSunLightShadows:w.sunShadowMap.length,numDirLightShadows:w.directionalShadowMap.length,numPointLightShadows:w.pointShadowMap.length,numSpotLightShadows:w.spotShadowMap.length,numSpotLightShadowsWithMaps:w.numSpotLightShadowsWithMaps,numLightProbes:w.numLightProbes,numLightProbeGrids:F.filter(ge=>ge.texture!==null).length,numClippingPlanes:r.numPlanes,numClipIntersection:r.numIntersection,dithering:y.dithering,shadowMapEnabled:i.shadowMap.enabled&&L.length>0,shadowMapType:i.shadowMap.type,toneMapping:ie,decodeVideoTexture:De&&y.map.isVideoTexture===!0&&Xe.getTransfer(y.map.colorSpace)===st,decodeVideoTextureEmissive:Dt&&y.emissiveMap.isVideoTexture===!0&&Xe.getTransfer(y.emissiveMap.colorSpace)===st,premultipliedAlpha:y.premultipliedAlpha,doubleSided:y.side===bn,flipSided:y.side===Gt,useDepthPacking:y.depthPacking>=0,depthPacking:y.depthPacking||0,index0AttributeName:y.index0AttributeName,extensionClipCullDistance:Be&&y.extensions.clipCullDistance===!0&&t.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(Be&&y.extensions.multiDraw===!0||_t)&&t.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:t.has("KHR_parallel_shader_compile"),customProgramCacheKey:y.customProgramCacheKey()};return ke.vertexUv1s=c.has(1),ke.vertexUv2s=c.has(2),ke.vertexUv3s=c.has(3),c.clear(),ke}function v(y){const w=[];if(y.shaderID?w.push(y.shaderID):(w.push(y.customVertexShaderID),w.push(y.customFragmentShaderID)),y.defines!==void 0)for(const L in y.defines)w.push(L),w.push(y.defines[L]);return y.isRawShaderMaterial===!1&&(p(w,y),m(w,y),w.push(i.outputColorSpace)),w.push(y.customProgramCacheKey),w.join()}function p(y,w){y.push(w.precision),y.push(w.outputColorSpace),y.push(w.envMapMode),y.push(w.envMapPMREM),y.push(w.envMapMaxLod),y.push(w.envMapSize),y.push(w.mapUv),y.push(w.alphaMapUv),y.push(w.lightMapUv),y.push(w.aoMapUv),y.push(w.bumpMapUv),y.push(w.normalMapUv),y.push(w.displacementMapUv),y.push(w.emissiveMapUv),y.push(w.metalnessMapUv),y.push(w.roughnessMapUv),y.push(w.anisotropyMapUv),y.push(w.clearcoatMapUv),y.push(w.clearcoatNormalMapUv),y.push(w.clearcoatRoughnessMapUv),y.push(w.diffuseRoughnessMapUv),y.push(w.iridescenceMapUv),y.push(w.iridescenceThicknessMapUv),y.push(w.sheenColorMapUv),y.push(w.sheenRoughnessMapUv),y.push(w.specularMapUv),y.push(w.specularColorMapUv),y.push(w.specularIntensityMapUv),y.push(w.transmissionMapUv),y.push(w.thicknessMapUv),y.push(w.combine),y.push(w.fogExp2),y.push(w.sizeAttenuation),y.push(w.morphTargetsCount),y.push(w.numSunLights),y.push(w.numDirLights),y.push(w.numPointLights),y.push(w.numSpotLights),y.push(w.numSpotLightMaps),y.push(w.numHemiLights),y.push(w.numRectAreaLights),y.push(w.numSunLightShadows),y.push(w.numDirLightShadows),y.push(w.numPointLightShadows),y.push(w.numSpotLightShadows),y.push(w.numSpotLightShadowsWithMaps),y.push(w.numLightProbes),y.push(w.numLightProbeGrids),y.push(w.shadowMapType),y.push(w.toneMapping),y.push(w.numClippingPlanes),y.push(w.numClipIntersection),y.push(w.depthPacking)}function m(y,w){a.disableAll(),w.instancing&&a.enable(0),w.instancingColor&&a.enable(1),w.instancingMorph&&a.enable(2),w.matcap&&a.enable(3),w.envMap&&a.enable(4),w.normalMapObjectSpace&&a.enable(5),w.normalMapTangentSpace&&a.enable(6),w.clearcoat&&a.enable(7),w.iridescence&&a.enable(8),w.alphaTest&&a.enable(9),w.vertexColors&&a.enable(10),w.vertexAlphas&&a.enable(11),w.vertexUv1s&&a.enable(12),w.vertexUv2s&&a.enable(13),w.vertexUv3s&&a.enable(14),w.vertexTangents&&a.enable(15),w.anisotropy&&a.enable(16),w.alphaHash&&a.enable(17),w.batching&&a.enable(18),w.dispersion&&a.enable(19),w.retroreflection&&a.enable(24),w.diffuseRoughness&&a.enable(25),w.batchingColor&&a.enable(20),w.gradientMap&&a.enable(21),w.packedNormalMap&&a.enable(22),w.vertexNormals&&a.enable(23),y.push(a.mask),a.disableAll(),w.fog&&a.enable(0),w.useFog&&a.enable(1),w.flatShading&&a.enable(2),w.logarithmicDepthBuffer&&a.enable(3),w.reversedDepthBuffer&&a.enable(4),w.skinning&&a.enable(5),w.morphTargets&&a.enable(6),w.morphNormals&&a.enable(7),w.morphColors&&a.enable(8),w.premultipliedAlpha&&a.enable(9),w.shadowMapEnabled&&a.enable(10),w.doubleSided&&a.enable(11),w.flipSided&&a.enable(12),w.useDepthPacking&&a.enable(13),w.dithering&&a.enable(14),w.transmission&&a.enable(15),w.sheen&&a.enable(16),w.opaque&&a.enable(17),w.pointsUvs&&a.enable(18),w.decodeVideoTexture&&a.enable(19),w.decodeVideoTextureEmissive&&a.enable(20),w.alphaToCoverage&&a.enable(21),w.numLightProbeGrids>0&&a.enable(22),w.hasPositionAttribute&&a.enable(23),y.push(a.mask)}function x(y){const w=u[y.type];let L;if(w){const R=Wn[w];L=v0.clone(R.uniforms)}else L=y.uniforms;return L}function S(y,w){let L=h.get(w);return L!==void 0?++L.usedTimes:(L=new Hy(i,w,y,s),l.push(L),h.set(w,L)),L}function b(y){if(--y.usedTimes===0){const w=l.indexOf(y);l[w]=l[l.length-1],l.pop(),h.delete(y.cacheKey),y.destroy()}}function A(y){o.remove(y)}function E(){o.dispose()}return{getParameters:g,getProgramCacheKey:v,getUniforms:x,acquireProgram:S,releaseProgram:b,releaseShaderCache:A,programs:l,dispose:E}}function Yy(){let i=new WeakMap;function e(a){return i.has(a)}function t(a){let o=i.get(a);return o===void 0&&(o={},i.set(a,o)),o}function n(a){i.delete(a)}function s(a,o,c){i.get(a)[o]=c}function r(){i=new WeakMap}return{has:e,get:t,remove:n,update:s,dispose:r}}function Ky(i,e){return i.groupOrder!==e.groupOrder?i.groupOrder-e.groupOrder:i.renderOrder!==e.renderOrder?i.renderOrder-e.renderOrder:i.material.id!==e.material.id?i.material.id-e.material.id:i.materialVariant!==e.materialVariant?i.materialVariant-e.materialVariant:i.z!==e.z?i.z-e.z:i.id-e.id}function Sd(i,e){return i.groupOrder!==e.groupOrder?i.groupOrder-e.groupOrder:i.renderOrder!==e.renderOrder?i.renderOrder-e.renderOrder:i.z!==e.z?e.z-i.z:i.id-e.id}function wd(){const i=[];let e=0;const t=[],n=[],s=[];function r(){e=0,t.length=0,n.length=0,s.length=0}function a(u){let f=0;return u.isInstancedMesh&&(f+=2),u.isSkinnedMesh&&(f+=1),f}function o(u,f,g,v,p,m){let x=i[e];return x===void 0?(x={id:u.id,object:u,geometry:f,material:g,materialVariant:a(u),groupOrder:v,renderOrder:u.renderOrder,z:p,group:m},i[e]=x):(x.id=u.id,x.object=u,x.geometry=f,x.material=g,x.materialVariant=a(u),x.groupOrder=v,x.renderOrder=u.renderOrder,x.z=p,x.group=m),e++,x}function c(u,f,g,v,p,m,x){x.reversedDepth===!0&&(p=-p);const S=o(u,f,g,v,p,m);g.transmission>0?n.push(S):g.transparent===!0?s.push(S):t.push(S)}function l(u,f,g,v,p,m){const x=o(u,f,g,v,p,m);g.transmission>0?n.unshift(x):g.transparent===!0?s.unshift(x):t.unshift(x)}function h(u,f){t.length>1&&t.sort(u||Ky),n.length>1&&n.sort(f||Sd),s.length>1&&s.sort(f||Sd)}function d(){for(let u=e,f=i.length;u<f;u++){const g=i[u];if(g.id===null)break;g.id=null,g.object=null,g.geometry=null,g.material=null,g.group=null}}return{opaque:t,transmissive:n,transparent:s,init:r,push:c,unshift:l,finish:d,sort:h}}function Jy(){let i=new WeakMap;function e(n,s){const r=i.get(n);let a;return r===void 0?(a=new wd,i.set(n,[a])):s>=r.length?(a=new wd,r.push(a)):a=r[s],a}function t(){i=new WeakMap}return{get:e,dispose:t}}function Zy(){const i={};return{get:function(e){if(i[e.id]!==void 0)return i[e.id];let t;switch(e.type){case"SunLight":case"DirectionalLight":t={direction:new P,color:new Te};break;case"SpotLight":t={position:new P,direction:new P,color:new Te,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":t={position:new P,color:new Te,distance:0,decay:0};break;case"HemisphereLight":t={direction:new P,skyColor:new Te,groundColor:new Te};break;case"RectAreaLight":t={color:new Te,position:new P,halfWidth:new P,halfHeight:new P};break}return i[e.id]=t,t}}}function Qy(){const i={};return{get:function(e){if(i[e.id]!==void 0)return i[e.id];let t;switch(e.type){case"SunLight":case"DirectionalLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new fe};break;case"SpotLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new fe};break;case"PointLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new fe,shadowCameraNear:1,shadowCameraFar:1e3};break}return i[e.id]=t,t}}}let jy=0;function eb(i,e){return(e.castShadow?2:0)-(i.castShadow?2:0)+(e.map?1:0)-(i.map?1:0)}function tb(i){const e=new Zy,t=Qy(),n={version:0,hash:{sunLength:-1,directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numSunShadows:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],sun:[],sunShadow:[],sunShadowMap:[],sunShadowMatrix:[],sunShadowCascade:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let l=0;l<9;l++)n.probe.push(new P);const s=new P,r=new Ke,a=new Ke;function o(l){let h=0,d=0,u=0;for(let F=0;F<9;F++)n.probe[F].set(0,0,0);let f=0,g=0,v=0,p=0,m=0,x=0,S=0,b=0,A=0,E=0,y=0,w=0,L=0,R=0;l.sort(eb);for(let F=0,V=l.length;F<V;F++){const I=l[F],H=I.color,J=I.intensity,z=I.distance;let ne=null;if(I.shadow&&I.shadow.map&&(I.shadow.map.texture.format===Ji?ne=I.shadow.map.texture:ne=I.shadow.map.depthTexture||I.shadow.map.texture),I.isAmbientLight)h+=H.r*J,d+=H.g*J,u+=H.b*J;else if(I.isLightProbe){for(let $=0;$<9;$++)n.probe[$].addScaledVector(I.sh.coefficients[$],J);R++}else if(I.isSunLight){const $=e.get(I);if($.color.copy(I.color).multiplyScalar(I.intensity),I.castShadow){const j=I.shadow,ee=t.get(I);ee.shadowIntensity=j.intensity,ee.shadowBias=j.bias,ee.shadowNormalBias=j.normalBias,ee.shadowRadius=j.radius,ee.shadowMapSize.copy(j.mapSize).multiply(j.getFrameExtents()),n.sunShadow[g]=ee,n.sunShadowMap[g]=ne;const we=j.getViewportCount();for(let Ue=0;Ue<we;Ue++)n.sunShadowMatrix[v+Ue]=j.getMatrix(Ue),n.sunShadowCascade[v+Ue]=j._cascadeData[Ue];v+=we,g++}n.sun[f]=$,f++}else if(I.isDirectionalLight){const $=e.get(I);if($.color.copy(I.color).multiplyScalar(I.intensity),I.castShadow){const j=I.shadow,ee=t.get(I);ee.shadowIntensity=j.intensity,ee.shadowBias=j.bias,ee.shadowNormalBias=j.normalBias,ee.shadowRadius=j.radius,ee.shadowMapSize=j.mapSize,n.directionalShadow[p]=ee,n.directionalShadowMap[p]=ne,n.directionalShadowMatrix[p]=I.shadow.matrix,A++}n.directional[p]=$,p++}else if(I.isSpotLight){const $=e.get(I);$.position.setFromMatrixPosition(I.matrixWorld),$.color.copy(H).multiplyScalar(J),$.distance=z,$.coneCos=Math.cos(I.angle),$.penumbraCos=Math.cos(I.angle*(1-I.penumbra)),$.decay=I.decay,n.spot[x]=$;const j=I.shadow;if(I.map&&(n.spotLightMap[w]=I.map,w++,j.updateMatrices(I),I.castShadow&&L++),n.spotLightMatrix[x]=j.matrix,I.castShadow){const ee=t.get(I);ee.shadowIntensity=j.intensity,ee.shadowBias=j.bias,ee.shadowNormalBias=j.normalBias,ee.shadowRadius=j.radius,ee.shadowMapSize=j.mapSize,n.spotShadow[x]=ee,n.spotShadowMap[x]=ne,y++}x++}else if(I.isRectAreaLight){const $=e.get(I);$.color.copy(H).multiplyScalar(J),$.halfWidth.set(I.width*.5,0,0),$.halfHeight.set(0,I.height*.5,0),n.rectArea[S]=$,S++}else if(I.isPointLight){const $=e.get(I);if($.color.copy(I.color).multiplyScalar(I.intensity),$.distance=I.distance,$.decay=I.decay,I.castShadow){const j=I.shadow,ee=t.get(I);ee.shadowIntensity=j.intensity,ee.shadowBias=j.bias,ee.shadowNormalBias=j.normalBias,ee.shadowRadius=j.radius,ee.shadowMapSize=j.mapSize,ee.shadowCameraNear=j.camera.near,ee.shadowCameraFar=j.camera.far,n.pointShadow[m]=ee,n.pointShadowMap[m]=ne,n.pointShadowMatrix[m]=I.shadow.matrix,E++}n.point[m]=$,m++}else if(I.isHemisphereLight){const $=e.get(I);$.skyColor.copy(I.color).multiplyScalar(J),$.groundColor.copy(I.groundColor).multiplyScalar(J),n.hemi[b]=$,b++}}S>0&&(i.has("OES_texture_float_linear")===!0?(n.rectAreaLTC1=me.LTC_FLOAT_1,n.rectAreaLTC2=me.LTC_FLOAT_2):(n.rectAreaLTC1=me.LTC_HALF_1,n.rectAreaLTC2=me.LTC_HALF_2)),n.ambient[0]=h,n.ambient[1]=d,n.ambient[2]=u;const N=n.hash;(N.sunLength!==f||N.directionalLength!==p||N.pointLength!==m||N.spotLength!==x||N.rectAreaLength!==S||N.hemiLength!==b||N.numSunShadows!==g||N.numDirectionalShadows!==A||N.numPointShadows!==E||N.numSpotShadows!==y||N.numSpotMaps!==w||N.numLightProbes!==R)&&(n.sun.length=f,n.directional.length=p,n.spot.length=x,n.rectArea.length=S,n.point.length=m,n.hemi.length=b,n.sunShadow.length=g,n.sunShadowMap.length=g,n.sunShadowMatrix.length=v,n.sunShadowCascade.length=v,n.directionalShadow.length=A,n.directionalShadowMap.length=A,n.directionalShadowMatrix.length=A,n.pointShadow.length=E,n.pointShadowMap.length=E,n.pointShadowMatrix.length=E,n.spotShadow.length=y,n.spotShadowMap.length=y,n.spotLightMatrix.length=y+w-L,n.spotLightMap.length=w,n.numSpotLightShadowsWithMaps=L,n.numLightProbes=R,N.sunLength=f,N.directionalLength=p,N.pointLength=m,N.spotLength=x,N.rectAreaLength=S,N.hemiLength=b,N.numSunShadows=g,N.numDirectionalShadows=A,N.numPointShadows=E,N.numSpotShadows=y,N.numSpotMaps=w,N.numLightProbes=R,n.version=jy++)}function c(l,h){let d=0,u=0,f=0,g=0,v=0,p=0;const m=h.matrixWorldInverse;for(let x=0,S=l.length;x<S;x++){const b=l[x];if(b.isSunLight){const A=n.sun[d];A.direction.setFromMatrixPosition(b.matrixWorld),A.direction.transformDirection(m),d++}else if(b.isDirectionalLight){const A=n.directional[u];A.direction.setFromMatrixPosition(b.matrixWorld),s.setFromMatrixPosition(b.target.matrixWorld),A.direction.sub(s),A.direction.transformDirection(m),u++}else if(b.isSpotLight){const A=n.spot[g];A.position.setFromMatrixPosition(b.matrixWorld),A.position.applyMatrix4(m),A.direction.setFromMatrixPosition(b.matrixWorld),s.setFromMatrixPosition(b.target.matrixWorld),A.direction.sub(s),A.direction.transformDirection(m),g++}else if(b.isRectAreaLight){const A=n.rectArea[v];A.position.setFromMatrixPosition(b.matrixWorld),A.position.applyMatrix4(m),a.identity(),r.copy(b.matrixWorld),r.premultiply(m),a.extractRotation(r),A.halfWidth.set(b.width*.5,0,0),A.halfHeight.set(0,b.height*.5,0),A.halfWidth.applyMatrix4(a),A.halfHeight.applyMatrix4(a),v++}else if(b.isPointLight){const A=n.point[f];A.position.setFromMatrixPosition(b.matrixWorld),A.position.applyMatrix4(m),f++}else if(b.isHemisphereLight){const A=n.hemi[p];A.direction.setFromMatrixPosition(b.matrixWorld),A.direction.transformDirection(m),p++}}}return{setup:o,setupView:c,state:n}}function Ed(i){const e=new tb(i),t=[],n=[],s=[];function r(d){h.camera=d,t.length=0,n.length=0,s.length=0}function a(d){d.isLightProbeGrid?s.push(d):t.push(d)}function o(d){n.push(d)}function c(){e.setup(t),s.sort((d,u)=>d.priority-u.priority||d.id-u.id)}function l(d){e.setupView(t,d)}const h={lightsArray:t,shadowsArray:n,lightProbeGridArray:s,camera:null,lights:e,transmissionRenderTarget:{},textureUnits:0};return{init:r,state:h,setupLights:c,setupLightsView:l,pushLight:a,pushShadow:o}}function nb(i){let e=new WeakMap;function t(s,r=0){const a=e.get(s);let o;return a===void 0?(o=new Ed(i),e.set(s,[o])):r>=a.length?(o=new Ed(i),a.push(o)):o=a[r],o}function n(){e=new WeakMap}return{get:t,dispose:n}}const ib=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,sb=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ).rg;
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ).r;
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( max( 0.0, squared_mean - mean * mean ) );
	gl_FragColor = vec4( mean, std_dev, 0.0, 1.0 );
}`,rb=[new P(1,0,0),new P(-1,0,0),new P(0,1,0),new P(0,-1,0),new P(0,0,1),new P(0,0,-1)],ab=[new P(0,-1,0),new P(0,-1,0),new P(0,0,1),new P(0,0,-1),new P(0,-1,0),new P(0,-1,0)],Ad=new Ke,Js=new P,Wo=new P;function ob(i,e,t){let n=new br;const s=new fe,r=new fe,a=new vt,o=new _0,c=new M0,l={},h=t.maxTextureSize,d={[Ki]:Gt,[Gt]:Ki,[bn]:bn},u=new fn({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new fe},radius:{value:4}},vertexShader:ib,fragmentShader:sb}),f=u.clone();f.defines.HORIZONTAL_PASS=1;const g=new pt;g.setAttribute("position",new Zt(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const v=new je(g,u),p=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=Ea;let m=this.type;this.render=function(E,y,w){if(p.enabled===!1||p.autoUpdate===!1&&p.needsUpdate===!1||E.length===0)return;this.type===du&&(Le("WebGLShadowMap: PCFSoftShadowMap has been removed. Using PCFShadowMap instead."),this.type=Ea);const L=i.getRenderTarget(),R=i.getActiveCubeFace(),N=i.getActiveMipmapLevel(),F=i.state;F.setBlending(As),F.buffers.depth.getReversed()===!0?F.buffers.color.setClear(0,0,0,0):F.buffers.color.setClear(1,1,1,1),F.buffers.depth.setTest(!0),F.setScissorTest(!1);const V=m!==this.type;V&&y.traverse(function(I){I.material&&(Array.isArray(I.material)?I.material.forEach(H=>H.needsUpdate=!0):I.material.needsUpdate=!0)});for(let I=0,H=E.length;I<H;I++){const J=E[I],z=J.shadow;if(z===void 0){Le("WebGLShadowMap:",J,"has no shadow.");continue}if(z.autoUpdate===!1&&z.needsUpdate===!1)continue;s.copy(z.mapSize);const ne=z.getFrameExtents();s.multiply(ne),r.copy(z.mapSize),(s.x>h||s.y>h)&&(s.x>h&&(r.x=Math.floor(h/ne.x),s.x=r.x*ne.x,z.mapSize.x=r.x),s.y>h&&(r.y=Math.floor(h/ne.y),s.y=r.y*ne.y,z.mapSize.y=r.y));const $=i.state.buffers.depth.getReversed();if(z.camera._reversedDepth=$,z.map===null||V===!0){if(z.map!==null&&(z.map.depthTexture!==null&&(z.map.depthTexture.dispose(),z.map.depthTexture=null),z.map.dispose()),this.type===js){if(J.isPointLight){Le("WebGLShadowMap: VSM shadow maps are not supported for PointLights. Use PCF or BasicShadowMap instead.");continue}z.map=new Mn(s.x,s.y,{format:Ji,type:Jn,minFilter:nn,magFilter:nn,generateMipmaps:!1}),z.map.texture.name=J.name+".shadowMap",z.map.depthTexture=new Is(s.x,s.y,Dn),z.map.depthTexture.name=J.name+".shadowMapDepth",z.map.depthTexture.format=Pi,z.map.depthTexture.compareFunction=null,z.map.depthTexture.minFilter=zt,z.map.depthTexture.magFilter=zt}else J.isPointLight?(z.map=new Fc(s.x),z.map.depthTexture=new Vu(s.x,Kn)):(z.map=new Mn(s.x,s.y),z.map.depthTexture=new Is(s.x,s.y,Kn)),z.map.depthTexture.name=J.name+".shadowMap",z.map.depthTexture.format=Pi,this.type===Ea?(z.map.depthTexture.compareFunction=$?Cu:Ru,z.map.depthTexture.minFilter=nn,z.map.depthTexture.magFilter=nn):(z.map.depthTexture.compareFunction=null,z.map.depthTexture.minFilter=zt,z.map.depthTexture.magFilter=zt);z.camera.updateProjectionMatrix()}z.map.isWebGLCubeRenderTarget!==!0&&(z.map.width!==s.x||z.map.height!==s.y)&&z.map.setSize(s.x,s.y);const j=z.map.isWebGLCubeRenderTarget?6:z.getViewportCount();J.isPointLight!==!0&&z.updateMatrices(J,w);const ee=(z.camera.layers.mask&4294967294)!==0?z.camera.layers:w.layers;for(let we=0;we<j;we++){const Ue=z.getCamera(we);if(J.isPointLight){const Y=z.camera,ve=z.matrix,_e=J.distance||Y.far;_e!==Y.far&&(Y.far=_e,Y.updateProjectionMatrix()),Js.setFromMatrixPosition(J.matrixWorld),Y.position.copy(Js),Wo.copy(Y.position),Wo.add(rb[we]),Y.up.copy(ab[we]),Y.lookAt(Wo),Y.updateMatrixWorld(),ve.makeTranslation(-Js.x,-Js.y,-Js.z),Ad.multiplyMatrices(Y.projectionMatrix,Y.matrixWorldInverse),z._frustum.setFromProjectionMatrix(Ad,Y.coordinateSystem,Y.reversedDepth)}if(z.map.isWebGLCubeRenderTarget)i.setRenderTarget(z.map,we),i.clear();else{we===0&&(i.setRenderTarget(z.map),i.clear());const Y=z.getViewport(we);a.set(r.x*Y.x,r.y*Y.y,r.x*Y.z,r.y*Y.w),F.viewport(a)}n=z.getFrustum(we),b(y,w,Ue,J,ee,this.type)}z.isPointLightShadow!==!0&&this.type===js&&x(z,w),z.needsUpdate=!1}m=this.type,p.needsUpdate=!1,i.setRenderTarget(L,R,N)};function x(E,y){const w=e.update(v);u.defines.VSM_SAMPLES!==E.blurSamples&&(u.defines.VSM_SAMPLES=E.blurSamples,f.defines.VSM_SAMPLES=E.blurSamples,u.needsUpdate=!0,f.needsUpdate=!0),E.mapPass===null?E.mapPass=new Mn(s.x,s.y,{format:Ji,type:Jn}):(E.mapPass.width!==E.map.width||E.mapPass.height!==E.map.height)&&E.mapPass.setSize(E.map.width,E.map.height),u.uniforms.shadow_pass.value=E.map.depthTexture,u.uniforms.resolution.value.set(E.map.width,E.map.height),u.uniforms.radius.value=E.radius,i.setRenderTarget(E.mapPass),i.clear(),i.renderBufferDirect(y,null,w,u,v,null),f.uniforms.shadow_pass.value=E.mapPass.texture,f.uniforms.resolution.value.set(E.map.width,E.map.height),f.uniforms.radius.value=E.radius,i.setRenderTarget(E.map),i.clear(),i.renderBufferDirect(y,null,w,f,v,null)}function S(E,y,w,L){let R=null;const N=w.isPointLight===!0?E.customDistanceMaterial:E.customDepthMaterial;if(N!==void 0)R=N;else if(R=w.isPointLight===!0?c:o,i.localClippingEnabled&&y.clipShadows===!0&&Array.isArray(y.clippingPlanes)&&y.clippingPlanes.length!==0||y.displacementMap&&y.displacementScale!==0||y.alphaMap&&y.alphaTest>0||y.map&&y.alphaTest>0||y.alphaToCoverage===!0){const F=R.uuid,V=y.uuid;let I=l[F];I===void 0&&(I={},l[F]=I);let H=I[V];H===void 0&&(H=R.clone(),I[V]=H,y.addEventListener("dispose",A)),R=H}if(R.visible=y.visible,R.wireframe=y.wireframe,L===js?R.side=y.shadowSide!==null?y.shadowSide:y.side:R.side=y.shadowSide!==null?y.shadowSide:d[y.side],R.alphaMap=y.alphaMap,R.alphaTest=y.alphaToCoverage===!0?.5:y.alphaTest,R.map=y.map,R.clipShadows=y.clipShadows,R.clippingPlanes=y.clippingPlanes,R.clipIntersection=y.clipIntersection,R.displacementMap=y.displacementMap,R.displacementScale=y.displacementScale,R.displacementBias=y.displacementBias,R.wireframeLinewidth=y.wireframeLinewidth,R.linewidth=y.linewidth,w.isPointLight===!0&&R.isMeshDistanceMaterial===!0){const F=i.properties.get(R);F.light=w}return R}function b(E,y,w,L,R,N){if(E.visible===!1)return;if(E.layers.test(R)&&(E.isMesh||E.isLine||E.isPoints)&&(E.castShadow||E.receiveShadow&&N===js)&&(!E.frustumCulled||E.intersectsFrustum(n))){E.modelViewMatrix.multiplyMatrices(w.matrixWorldInverse,E.matrixWorld);const I=e.update(E),H=E.material;if(Array.isArray(H)){const J=I.groups;for(let z=0,ne=J.length;z<ne;z++){const $=J[z],j=H[$.materialIndex];if(j&&j.visible){const ee=S(E,j,L,N);E.onBeforeShadow(i,E,y,w,I,ee,$),i.renderBufferDirect(w,null,I,ee,E,$),E.onAfterShadow(i,E,y,w,I,ee,$)}}}else if(H.visible){const J=S(E,H,L,N);E.onBeforeShadow(i,E,y,w,I,J,null),i.renderBufferDirect(w,null,I,J,E,null),E.onAfterShadow(i,E,y,w,I,J,null)}}const V=E.children;for(let I=0,H=V.length;I<H;I++)b(V[I],y,w,L,R,N)}function A(E){E.target.removeEventListener("dispose",A);for(const w in l){const L=l[w],R=E.target.uuid;R in L&&(L[R].dispose(),delete L[R])}}}function lb(i,e){function t(){let C=!1;const K=new vt;let W=null;const ce=new vt(0,0,0,0);return{setMask:function(se){W!==se&&!C&&(i.colorMask(se,se,se,se),W=se)},setLocked:function(se){C=se},setClear:function(se,oe,Ae,Be,ie){ie===!0&&(se*=Be,oe*=Be,Ae*=Be),K.set(se,oe,Ae,Be),ce.equals(K)===!1&&(i.clearColor(se,oe,Ae,Be),ce.copy(K))},reset:function(){C=!1,W=null,ce.set(-1,0,0,0)}}}function n(){let C=!1,K=!1,W=null,ce=null,se=null;return{setReversed:function(oe){if(K!==oe){const Ae=e.get("EXT_clip_control");oe?Ae.clipControlEXT(Ae.LOWER_LEFT_EXT,Ae.ZERO_TO_ONE_EXT):Ae.clipControlEXT(Ae.LOWER_LEFT_EXT,Ae.NEGATIVE_ONE_TO_ONE_EXT),K=oe;const Be=se;se=null,this.setClear(Be)}},getReversed:function(){return K},setTest:function(oe){oe?xe(i.DEPTH_TEST):Oe(i.DEPTH_TEST)},setMask:function(oe){W!==oe&&!C&&(i.depthMask(oe),W=oe)},setFunc:function(oe){if(K&&(oe=Zp[oe]),ce!==oe){switch(oe){case Qo:i.depthFunc(i.NEVER);break;case jo:i.depthFunc(i.ALWAYS);break;case el:i.depthFunc(i.LESS);break;case mr:i.depthFunc(i.LEQUAL);break;case tl:i.depthFunc(i.EQUAL);break;case nl:i.depthFunc(i.GEQUAL);break;case il:i.depthFunc(i.GREATER);break;case sl:i.depthFunc(i.NOTEQUAL);break;default:i.depthFunc(i.LEQUAL)}ce=oe}},setLocked:function(oe){C=oe},setClear:function(oe){se!==oe&&(se=oe,K&&(oe=1-oe),i.clearDepth(oe))},reset:function(){C=!1,W=null,ce=null,se=null,K=!1}}}function s(){let C=!1,K=null,W=null,ce=null,se=null,oe=null,Ae=null,Be=null,ie=null;return{setTest:function(Re){C||(Re?xe(i.STENCIL_TEST):Oe(i.STENCIL_TEST))},setMask:function(Re){K!==Re&&!C&&(i.stencilMask(Re),K=Re)},setFunc:function(Re,ke,ge){(W!==Re||ce!==ke||se!==ge)&&(i.stencilFunc(Re,ke,ge),W=Re,ce=ke,se=ge)},setOp:function(Re,ke,ge){(oe!==Re||Ae!==ke||Be!==ge)&&(i.stencilOp(Re,ke,ge),oe=Re,Ae=ke,Be=ge)},setLocked:function(Re){C=Re},setClear:function(Re){ie!==Re&&(i.clearStencil(Re),ie=Re)},reset:function(){C=!1,K=null,W=null,ce=null,se=null,oe=null,Ae=null,Be=null,ie=null}}}const r=new t,a=new n,o=new s;let c={};const l=new WeakMap;let h={},d={},u={},f=new WeakMap,g=[],v=null,p=!1,m=null,x=null,S=null,b=null,A=null,E=null,y=null,w=new Te(0,0,0),L=0,R=!1,N=null,F=null,V=null,I=null,H=null;const J=i.getParameter(i.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let z=!1,ne=0;const $=i.getParameter(i.VERSION);$.indexOf("WebGL")!==-1?(ne=parseFloat(/^WebGL (\d)/.exec($)[1]),z=ne>=1):$.indexOf("OpenGL ES")!==-1&&(ne=parseFloat(/^OpenGL ES (\d)/.exec($)[1]),z=ne>=2);let j=null,ee={};const we=i.getParameter(i.SCISSOR_BOX),Ue=i.getParameter(i.VIEWPORT),Y=new vt().fromArray(we),ve=new vt().fromArray(Ue);function _e(C,K,W,ce){const se=new Uint8Array(4),oe=i.createTexture();i.bindTexture(C,oe),i.texParameteri(C,i.TEXTURE_MIN_FILTER,i.NEAREST),i.texParameteri(C,i.TEXTURE_MAG_FILTER,i.NEAREST);for(let Ae=0;Ae<W;Ae++)C===i.TEXTURE_3D||C===i.TEXTURE_2D_ARRAY?i.texImage3D(K,0,i.RGBA,1,1,ce,0,i.RGBA,i.UNSIGNED_BYTE,se):i.texImage2D(K+Ae,0,i.RGBA,1,1,0,i.RGBA,i.UNSIGNED_BYTE,se);return oe}const Ce={};Ce[i.TEXTURE_2D]=_e(i.TEXTURE_2D,i.TEXTURE_2D,1),Ce[i.TEXTURE_CUBE_MAP]=_e(i.TEXTURE_CUBE_MAP,i.TEXTURE_CUBE_MAP_POSITIVE_X,6),Ce[i.TEXTURE_2D_ARRAY]=_e(i.TEXTURE_2D_ARRAY,i.TEXTURE_2D_ARRAY,1,1),Ce[i.TEXTURE_3D]=_e(i.TEXTURE_3D,i.TEXTURE_3D,1,1),r.setClear(0,0,0,1),a.setClear(1),o.setClear(0),xe(i.DEPTH_TEST),a.setFunc(mr),rn(!1),mt(uh),xe(i.CULL_FACE),kt(As);function xe(C){h[C]!==!0&&(i.enable(C),h[C]=!0)}function Oe(C){h[C]!==!1&&(i.disable(C),h[C]=!1)}function _t(C,K){return u[C]!==K?(i.bindFramebuffer(C,K),u[C]=K,C===i.DRAW_FRAMEBUFFER&&(u[i.FRAMEBUFFER]=K),C===i.FRAMEBUFFER&&(u[i.DRAW_FRAMEBUFFER]=K),!0):!1}function De(C,K){let W=g,ce=!1;if(C){W=f.get(K),W===void 0&&(W=[],f.set(K,W));const se=C.textures;if(W.length!==se.length||W[0]!==i.COLOR_ATTACHMENT0){for(let oe=0,Ae=se.length;oe<Ae;oe++)W[oe]=i.COLOR_ATTACHMENT0+oe;W.length=se.length,ce=!0}}else W[0]!==i.BACK&&(W[0]=i.BACK,ce=!0);ce&&i.drawBuffers(W)}function nt(C){return v!==C?(i.useProgram(C),v=C,!0):!1}const ot={[Ss]:i.FUNC_ADD,[bp]:i.FUNC_SUBTRACT,[_p]:i.FUNC_REVERSE_SUBTRACT};ot[Mp]=i.MIN,ot[Sp]=i.MAX;const Ve={[wp]:i.ZERO,[Ep]:i.ONE,[Ap]:i.SRC_COLOR,[uu]:i.SRC_ALPHA,[Dp]:i.SRC_ALPHA_SATURATE,[Pp]:i.DST_COLOR,[Rp]:i.DST_ALPHA,[Tp]:i.ONE_MINUS_SRC_COLOR,[fu]:i.ONE_MINUS_SRC_ALPHA,[Lp]:i.ONE_MINUS_DST_COLOR,[Cp]:i.ONE_MINUS_DST_ALPHA,[Ip]:i.CONSTANT_COLOR,[Np]:i.ONE_MINUS_CONSTANT_COLOR,[Up]:i.CONSTANT_ALPHA,[Fp]:i.ONE_MINUS_CONSTANT_ALPHA};function kt(C,K,W,ce,se,oe,Ae,Be,ie,Re){if(C===As){p===!0&&(Oe(i.BLEND),p=!1);return}if(p===!1&&(xe(i.BLEND),p=!0),C!==yp){if(C!==m||Re!==R){if((x!==Ss||A!==Ss)&&(i.blendEquation(i.FUNC_ADD),x=Ss,A=Ss),Re)switch(C){case rr:i.blendFuncSeparate(i.ONE,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case Fa:i.blendFunc(i.ONE,i.ONE);break;case fh:i.blendFuncSeparate(i.ZERO,i.ONE_MINUS_SRC_COLOR,i.ZERO,i.ONE);break;case ph:i.blendFuncSeparate(i.DST_COLOR,i.ONE_MINUS_SRC_ALPHA,i.ZERO,i.ONE);break;default:Ze("WebGLState: Invalid blending: ",C);break}else switch(C){case rr:i.blendFuncSeparate(i.SRC_ALPHA,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case Fa:i.blendFuncSeparate(i.SRC_ALPHA,i.ONE,i.ONE,i.ONE);break;case fh:Ze("WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true");break;case ph:Ze("WebGLState: MultiplyBlending requires material.premultipliedAlpha = true");break;default:Ze("WebGLState: Invalid blending: ",C);break}S=null,b=null,E=null,y=null,w.set(0,0,0),L=0,m=C,R=Re}return}se=se||K,oe=oe||W,Ae=Ae||ce,(K!==x||se!==A)&&(i.blendEquationSeparate(ot[K],ot[se]),x=K,A=se),(W!==S||ce!==b||oe!==E||Ae!==y)&&(i.blendFuncSeparate(Ve[W],Ve[ce],Ve[oe],Ve[Ae]),S=W,b=ce,E=oe,y=Ae),(Be.equals(w)===!1||ie!==L)&&(i.blendColor(Be.r,Be.g,Be.b,ie),w.copy(Be),L=ie),m=C,R=!1}function At(C,K){C.side===bn?Oe(i.CULL_FACE):xe(i.CULL_FACE);let W=C.side===Gt;K&&(W=!W),rn(W),C.blending===rr&&C.transparent===!1?kt(As):kt(C.blending,C.blendEquation,C.blendSrc,C.blendDst,C.blendEquationAlpha,C.blendSrcAlpha,C.blendDstAlpha,C.blendColor,C.blendAlpha,C.premultipliedAlpha),a.setFunc(C.depthFunc),a.setTest(C.depthTest),a.setMask(C.depthWrite),r.setMask(C.colorWrite);const ce=C.stencilWrite;o.setTest(ce),ce&&(o.setMask(C.stencilWriteMask),o.setFunc(C.stencilFunc,C.stencilRef,C.stencilFuncMask),o.setOp(C.stencilFail,C.stencilZFail,C.stencilZPass)),Dt(C.polygonOffset,C.polygonOffsetFactor,C.polygonOffsetUnits),C.alphaToCoverage===!0?xe(i.SAMPLE_ALPHA_TO_COVERAGE):Oe(i.SAMPLE_ALPHA_TO_COVERAGE)}function rn(C){N!==C&&(C?i.frontFace(i.CW):i.frontFace(i.CCW),N=C)}function mt(C){C!==vp?(xe(i.CULL_FACE),C!==F&&(C===uh?i.cullFace(i.BACK):C===xp?i.cullFace(i.FRONT):i.cullFace(i.FRONT_AND_BACK))):Oe(i.CULL_FACE),F=C}function zn(C){C!==V&&(z&&i.lineWidth(C),V=C)}function Dt(C,K,W){C?(xe(i.POLYGON_OFFSET_FILL),(I!==K||H!==W)&&(I=K,H=W,a.getReversed()&&(K=-K,W=-W),i.polygonOffset(K,W))):Oe(i.POLYGON_OFFSET_FILL)}function pn(C){C?xe(i.SCISSOR_TEST):Oe(i.SCISSOR_TEST)}function mn(C){C===void 0&&(C=i.TEXTURE0+J-1),j!==C&&(i.activeTexture(C),j=C)}function gn(C,K,W){W===void 0&&(j===null?W=i.TEXTURE0+J-1:W=j);let ce=ee[W];ce===void 0&&(ce={type:void 0,texture:void 0},ee[W]=ce),(ce.type!==C||ce.texture!==K)&&(j!==W&&(i.activeTexture(W),j=W),i.bindTexture(C,K||Ce[C]),ce.type=C,ce.texture=K)}function U(){const C=ee[j];C!==void 0&&C.type!==void 0&&(i.bindTexture(C.type,null),C.type=void 0,C.texture=void 0)}function vn(){try{i.compressedTexImage2D(...arguments)}catch(C){Ze("WebGLState:",C)}}function ut(){try{i.compressedTexImage3D(...arguments)}catch(C){Ze("WebGLState:",C)}}function ft(){try{i.texSubImage2D(...arguments)}catch(C){Ze("WebGLState:",C)}}function pe(){try{i.texSubImage3D(...arguments)}catch(C){Ze("WebGLState:",C)}}function Tt(){try{i.compressedTexSubImage2D(...arguments)}catch(C){Ze("WebGLState:",C)}}function Pe(){try{i.compressedTexSubImage3D(...arguments)}catch(C){Ze("WebGLState:",C)}}function Ie(){try{i.texStorage2D(...arguments)}catch(C){Ze("WebGLState:",C)}}function T(){try{i.texStorage3D(...arguments)}catch(C){Ze("WebGLState:",C)}}function _(){try{i.texImage2D(...arguments)}catch(C){Ze("WebGLState:",C)}}function k(){try{i.texImage3D(...arguments)}catch(C){Ze("WebGLState:",C)}}function te(C){return d[C]!==void 0?d[C]:i.getParameter(C)}function Z(C,K){d[C]!==K&&(i.pixelStorei(C,K),d[C]=K)}function ae(C){Y.equals(C)===!1&&(i.scissor(C.x,C.y,C.z,C.w),Y.copy(C))}function de(C){ve.equals(C)===!1&&(i.viewport(C.x,C.y,C.z,C.w),ve.copy(C))}function q(C,K){let W=l.get(K);W===void 0&&(W=new WeakMap,l.set(K,W));let ce=W.get(C);ce===void 0&&(ce=i.getUniformBlockIndex(K,C.name),i.uniformBlockBinding(K,ce,ce),W.set(C,ce))}function X(C,K,W){const se=l.get(K).get(C);c[se]!==W&&(i.bindBufferBase(i.UNIFORM_BUFFER,se,W),c[se]=W)}function le(){i.disable(i.BLEND),i.disable(i.CULL_FACE),i.disable(i.DEPTH_TEST),i.disable(i.POLYGON_OFFSET_FILL),i.disable(i.SCISSOR_TEST),i.disable(i.STENCIL_TEST),i.disable(i.SAMPLE_ALPHA_TO_COVERAGE),i.blendEquation(i.FUNC_ADD),i.blendFunc(i.ONE,i.ZERO),i.blendFuncSeparate(i.ONE,i.ZERO,i.ONE,i.ZERO),i.blendColor(0,0,0,0),i.colorMask(!0,!0,!0,!0),i.clearColor(0,0,0,0),i.depthMask(!0),i.depthFunc(i.LESS),a.setReversed(!1),i.clearDepth(1),i.stencilMask(4294967295),i.stencilFunc(i.ALWAYS,0,4294967295),i.stencilOp(i.KEEP,i.KEEP,i.KEEP),i.clearStencil(0),i.cullFace(i.BACK),i.frontFace(i.CCW),i.polygonOffset(0,0),i.activeTexture(i.TEXTURE0),i.bindFramebuffer(i.FRAMEBUFFER,null),i.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),i.bindFramebuffer(i.READ_FRAMEBUFFER,null),i.useProgram(null),i.lineWidth(1),i.scissor(0,0,i.canvas.width,i.canvas.height),i.viewport(0,0,i.canvas.width,i.canvas.height),i.pixelStorei(i.PACK_ALIGNMENT,4),i.pixelStorei(i.UNPACK_ALIGNMENT,4),i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,!1),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,!1),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,i.BROWSER_DEFAULT_WEBGL),i.pixelStorei(i.PACK_ROW_LENGTH,0),i.pixelStorei(i.PACK_SKIP_PIXELS,0),i.pixelStorei(i.PACK_SKIP_ROWS,0),i.pixelStorei(i.UNPACK_ROW_LENGTH,0),i.pixelStorei(i.UNPACK_IMAGE_HEIGHT,0),i.pixelStorei(i.UNPACK_SKIP_PIXELS,0),i.pixelStorei(i.UNPACK_SKIP_ROWS,0),i.pixelStorei(i.UNPACK_SKIP_IMAGES,0),h={},d={},j=null,ee={},u={},c={},f=new WeakMap,g=[],v=null,p=!1,m=null,x=null,S=null,b=null,A=null,E=null,y=null,w=new Te(0,0,0),L=0,R=!1,N=null,F=null,V=null,I=null,H=null,Y.set(0,0,i.canvas.width,i.canvas.height),ve.set(0,0,i.canvas.width,i.canvas.height),r.reset(),a.reset(),o.reset()}return{buffers:{color:r,depth:a,stencil:o},enable:xe,disable:Oe,bindFramebuffer:_t,drawBuffers:De,useProgram:nt,setBlending:kt,setMaterial:At,setFlipSided:rn,setCullFace:mt,setLineWidth:zn,setPolygonOffset:Dt,setScissorTest:pn,activeTexture:mn,bindTexture:gn,unbindTexture:U,compressedTexImage2D:vn,compressedTexImage3D:ut,texImage2D:_,texImage3D:k,pixelStorei:Z,getParameter:te,updateUBOMapping:q,uniformBlockBinding:X,texStorage2D:Ie,texStorage3D:T,texSubImage2D:ft,texSubImage3D:pe,compressedTexSubImage2D:Tt,compressedTexSubImage3D:Pe,scissor:ae,viewport:de,reset:le}}function cb(i,e,t,n,s,r,a){const o=e.has("WEBGL_multisampled_render_to_texture")?e.get("WEBGL_multisampled_render_to_texture"):null,c=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),l=new fe,h=new WeakMap,d=new Set;let u;const f=new WeakMap,g=new Set,v=new FinalizationRegistry(T=>g.delete(T));let p=!1;try{p=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function m(T,_){return p?new OffscreenCanvas(T,_):Ha("canvas")}function x(T,_,k){let te=1;const Z=Ie(T);if((Z.width>k||Z.height>k)&&(te=k/Math.max(Z.width,Z.height)),te<1)if(typeof HTMLImageElement<"u"&&T instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&T instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&T instanceof ImageBitmap||typeof VideoFrame<"u"&&T instanceof VideoFrame){const ae=Math.floor(te*Z.width),de=Math.floor(te*Z.height);u===void 0&&(u=m(ae,de));const q=_?m(ae,de):u;return q.width=ae,q.height=de,q.getContext("2d").drawImage(T,0,0,ae,de),Le("WebGLRenderer: Texture has been resized from ("+Z.width+"x"+Z.height+") to ("+ae+"x"+de+")."),q}else return"data"in T&&Le("WebGLRenderer: Image in DataTexture is too big ("+Z.width+"x"+Z.height+")."),T;return T}function S(T){return T.generateMipmaps}function b(T){i.generateMipmap(T)}function A(T){return T.isWebGLCubeRenderTarget?i.TEXTURE_CUBE_MAP:T.isWebGL3DRenderTarget?i.TEXTURE_3D:T.isWebGLArrayRenderTarget||T.isCompressedArrayTexture?i.TEXTURE_2D_ARRAY:i.TEXTURE_2D}function E(T,_,k,te,Z,ae=!1){if(T!==null){if(i[T]!==void 0)return i[T];Le("WebGLRenderer: Attempt to use non-existing WebGL internal format '"+T+"'")}let de;te&&(de=e.get("EXT_texture_norm16"),de||Le("WebGLRenderer: Unable to use normalized textures without EXT_texture_norm16 extension"));let q=_;if(_===i.RED&&(k===i.FLOAT&&(q=i.R32F),k===i.HALF_FLOAT&&(q=i.R16F),k===i.UNSIGNED_BYTE&&(q=i.R8),k===i.UNSIGNED_SHORT&&de&&(q=de.R16_EXT),k===i.SHORT&&de&&(q=de.R16_SNORM_EXT)),_===i.RED_INTEGER&&(k===i.UNSIGNED_BYTE&&(q=i.R8UI),k===i.UNSIGNED_SHORT&&(q=i.R16UI),k===i.UNSIGNED_INT&&(q=i.R32UI),k===i.BYTE&&(q=i.R8I),k===i.SHORT&&(q=i.R16I),k===i.INT&&(q=i.R32I)),_===i.RG&&(k===i.FLOAT&&(q=i.RG32F),k===i.HALF_FLOAT&&(q=i.RG16F),k===i.UNSIGNED_BYTE&&(q=i.RG8),k===i.UNSIGNED_SHORT&&de&&(q=de.RG16_EXT),k===i.SHORT&&de&&(q=de.RG16_SNORM_EXT)),_===i.RG_INTEGER&&(k===i.UNSIGNED_BYTE&&(q=i.RG8UI),k===i.UNSIGNED_SHORT&&(q=i.RG16UI),k===i.UNSIGNED_INT&&(q=i.RG32UI),k===i.BYTE&&(q=i.RG8I),k===i.SHORT&&(q=i.RG16I),k===i.INT&&(q=i.RG32I)),_===i.RGB_INTEGER&&(k===i.UNSIGNED_BYTE&&(q=i.RGB8UI),k===i.UNSIGNED_SHORT&&(q=i.RGB16UI),k===i.UNSIGNED_INT&&(q=i.RGB32UI),k===i.BYTE&&(q=i.RGB8I),k===i.SHORT&&(q=i.RGB16I),k===i.INT&&(q=i.RGB32I)),_===i.RGBA_INTEGER&&(k===i.UNSIGNED_BYTE&&(q=i.RGBA8UI),k===i.UNSIGNED_SHORT&&(q=i.RGBA16UI),k===i.UNSIGNED_INT&&(q=i.RGBA32UI),k===i.BYTE&&(q=i.RGBA8I),k===i.SHORT&&(q=i.RGBA16I),k===i.INT&&(q=i.RGBA32I)),_===i.RGB&&(k===i.UNSIGNED_SHORT&&de&&(q=de.RGB16_EXT),k===i.SHORT&&de&&(q=de.RGB16_SNORM_EXT),k===i.UNSIGNED_INT_5_9_9_9_REV&&(q=i.RGB9_E5),k===i.UNSIGNED_INT_10F_11F_11F_REV&&(q=i.R11F_G11F_B10F)),_===i.RGBA){const X=ae?Ga:Xe.getTransfer(Z);k===i.FLOAT&&(q=i.RGBA32F),k===i.HALF_FLOAT&&(q=i.RGBA16F),k===i.UNSIGNED_BYTE&&(q=X===st?i.SRGB8_ALPHA8:i.RGBA8),k===i.UNSIGNED_SHORT&&de&&(q=de.RGBA16_EXT),k===i.SHORT&&de&&(q=de.RGBA16_SNORM_EXT),k===i.UNSIGNED_SHORT_4_4_4_4&&(q=i.RGBA4),k===i.UNSIGNED_SHORT_5_5_5_1&&(q=i.RGB5_A1)}return(q===i.R16F||q===i.R32F||q===i.RG16F||q===i.RG32F||q===i.RGBA16F||q===i.RGBA32F)&&e.get("EXT_color_buffer_float"),q}function y(T,_){let k;return T?_===null||_===Kn||_===Ds?k=i.DEPTH24_STENCIL8:_===Dn?k=i.DEPTH32F_STENCIL8:_===vr&&(k=i.DEPTH24_STENCIL8,Le("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):_===null||_===Kn||_===Ds?k=i.DEPTH_COMPONENT24:_===Dn?k=i.DEPTH_COMPONENT32F:_===vr&&(k=i.DEPTH_COMPONENT16),k}function w(T,_){return S(T)===!0||T.isFramebufferTexture&&T.minFilter!==zt&&T.minFilter!==nn?Math.log2(Math.max(_.width,_.height))+1:T.mipmaps.length>0?T.mipmaps.length:T.isCompressedTexture&&Array.isArray(T.image)?_.mipmaps.length:1}function L(T){const _=new WeakRef(T);n.get(T).__ref=_,g.add(_),v.register(T,_,_)}function R(T){const _=n.get(T).__ref;_!==void 0&&(g.delete(_),v.unregister(_))}function N(T){V(T.target)}function F(T){I(T.target)}function V(T){T.removeEventListener("dispose",N),R(T),J(T),T.isVideoTexture&&h.delete(T),T.isHTMLTexture&&d.delete(T)}function I(T){T.removeEventListener("dispose",F),R(T),ne(T)}function H(){for(const T of g){const _=T.deref();_!==void 0&&(_.isRenderTarget===!0?I(_):V(_))}g.clear(),d.clear()}function J(T){const _=n.get(T);if(_.__webglInit===void 0)return;const k=T.source,te=f.get(k);if(te){const Z=te[_.__cacheKey];Z.usedTimes--,Z.usedTimes===0&&z(T),Object.keys(te).length===0&&f.delete(k)}n.remove(T)}function z(T){const _=n.get(T);i.deleteTexture(_.__webglTexture);const k=T.source,te=f.get(k);delete te[_.__cacheKey],a.memory.textures--}function ne(T){const _=n.get(T);_.__depthDisposeCallback&&_.__depthDisposeCallback();const k=T.depthTexture;if(k&&k.renderTarget===T&&V(k),T.isWebGLCubeRenderTarget)for(let Z=0;Z<6;Z++){if(Array.isArray(_.__webglFramebuffer[Z]))for(let ae=0;ae<_.__webglFramebuffer[Z].length;ae++)i.deleteFramebuffer(_.__webglFramebuffer[Z][ae]);else i.deleteFramebuffer(_.__webglFramebuffer[Z]);_.__webglDepthbuffer&&i.deleteRenderbuffer(_.__webglDepthbuffer[Z])}else{if(Array.isArray(_.__webglFramebuffer))for(let Z=0;Z<_.__webglFramebuffer.length;Z++)i.deleteFramebuffer(_.__webglFramebuffer[Z]);else i.deleteFramebuffer(_.__webglFramebuffer);if(_.__webglDepthbuffer&&i.deleteRenderbuffer(_.__webglDepthbuffer),_.__webglMultisampledFramebuffer&&i.deleteFramebuffer(_.__webglMultisampledFramebuffer),_.__webglColorRenderbuffer)for(let Z=0;Z<_.__webglColorRenderbuffer.length;Z++)_.__webglColorRenderbuffer[Z]&&i.deleteRenderbuffer(_.__webglColorRenderbuffer[Z]);_.__webglDepthRenderbuffer&&i.deleteRenderbuffer(_.__webglDepthRenderbuffer)}const te=T.textures;for(let Z=0,ae=te.length;Z<ae;Z++){const de=n.get(te[Z]);de.__webglTexture&&(i.deleteTexture(de.__webglTexture),a.memory.textures--),n.remove(te[Z])}n.remove(T)}let $=0;function j(){$=0}function ee(){return $}function we(T){$=T}function Ue(){const T=$;return T>=s.maxTextures&&Le("WebGLTextures: Trying to use "+(T+1)+" texture units while this GPU supports only "+s.maxTextures),$+=1,T}function Y(T){const _=[];return _.push(T.wrapS),_.push(T.wrapT),_.push(T.wrapR||0),_.push(T.magFilter),_.push(T.minFilter),_.push(T.anisotropy),_.push(T.internalFormat),_.push(T.format),_.push(T.type),_.push(T.generateMipmaps),_.push(T.mipmapsAutoUpdate),_.push(T.premultiplyAlpha),_.push(T.flipY),_.push(T.unpackAlignment),_.push(T.colorSpace),_.join()}function ve(T,_){const k=n.get(T);if(T.isVideoTexture&&Tt(T),T.isRenderTargetTexture===!1&&T.isExternalTexture!==!0&&T.version>0&&k.__version!==T.version){const te=T.image;if(te===null)Le("WebGLRenderer: Texture marked for update but no image data found.");else if(te.complete===!1)Le("WebGLRenderer: Texture marked for update but image is incomplete");else{At(k,T,_);return}}else T.isExternalTexture&&(k.__webglTexture=T.sourceTexture?T.sourceTexture:null);t.bindTexture(i.TEXTURE_2D,k.__webglTexture,i.TEXTURE0+_)}function _e(T,_){const k=n.get(T);if(T.isRenderTargetTexture===!1&&T.version>0&&k.__version!==T.version){At(k,T,_);return}else T.isExternalTexture&&(k.__webglTexture=T.sourceTexture?T.sourceTexture:null);t.bindTexture(i.TEXTURE_2D_ARRAY,k.__webglTexture,i.TEXTURE0+_)}function Ce(T,_){const k=n.get(T);if(T.isRenderTargetTexture===!1&&T.version>0&&k.__version!==T.version){At(k,T,_);return}t.bindTexture(i.TEXTURE_3D,k.__webglTexture,i.TEXTURE0+_)}function xe(T,_){const k=n.get(T);if(T.version>0&&k.__version!==T.version){rn(k,T,_);return}t.bindTexture(i.TEXTURE_CUBE_MAP,k.__webglTexture,i.TEXTURE0+_)}const Oe={[Oa]:i.REPEAT,[ci]:i.CLAMP_TO_EDGE,[rl]:i.MIRRORED_REPEAT},_t={[zt]:i.NEAREST,[Bp]:i.NEAREST_MIPMAP_NEAREST,[Br]:i.NEAREST_MIPMAP_LINEAR,[nn]:i.LINEAR,[mo]:i.LINEAR_MIPMAP_NEAREST,[hi]:i.LINEAR_MIPMAP_LINEAR},De={[Vp]:i.NEVER,[Pu]:i.ALWAYS,[Wp]:i.LESS,[Ru]:i.LEQUAL,[$p]:i.EQUAL,[Cu]:i.GEQUAL,[qp]:i.GREATER,[Xp]:i.NOTEQUAL};function nt(T,_){if(_.type===Dn&&e.has("OES_texture_float_linear")===!1&&(_.magFilter===nn||_.magFilter===mo||_.magFilter===Br||_.magFilter===hi||_.minFilter===nn||_.minFilter===mo||_.minFilter===Br||_.minFilter===hi)&&Le("WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),i.texParameteri(T,i.TEXTURE_WRAP_S,Oe[_.wrapS]),i.texParameteri(T,i.TEXTURE_WRAP_T,Oe[_.wrapT]),(T===i.TEXTURE_3D||T===i.TEXTURE_2D_ARRAY)&&i.texParameteri(T,i.TEXTURE_WRAP_R,Oe[_.wrapR]),i.texParameteri(T,i.TEXTURE_MAG_FILTER,_t[_.magFilter]),i.texParameteri(T,i.TEXTURE_MIN_FILTER,_t[_.minFilter]),_.compareFunction&&(i.texParameteri(T,i.TEXTURE_COMPARE_MODE,i.COMPARE_REF_TO_TEXTURE),i.texParameteri(T,i.TEXTURE_COMPARE_FUNC,De[_.compareFunction])),e.has("EXT_texture_filter_anisotropic")===!0){if(_.magFilter===zt||_.minFilter!==Br&&_.minFilter!==hi||_.type===Dn&&e.has("OES_texture_float_linear")===!1)return;if(_.anisotropy>1||n.get(_).__currentAnisotropy){const k=e.get("EXT_texture_filter_anisotropic");i.texParameterf(T,k.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(_.anisotropy,s.getMaxAnisotropy())),n.get(_).__currentAnisotropy=_.anisotropy}}}function ot(T,_){let k=!1;T.__webglInit===void 0&&(T.__webglInit=!0,_.addEventListener("dispose",N),L(_));const te=_.source;let Z=f.get(te);Z===void 0&&(Z={},f.set(te,Z));const ae=Y(_);if(ae!==T.__cacheKey){Z[ae]===void 0&&(Z[ae]={texture:i.createTexture(),usedTimes:0},a.memory.textures++,k=!0),Z[ae].usedTimes++;const de=Z[T.__cacheKey];de!==void 0&&(Z[T.__cacheKey].usedTimes--,de.usedTimes===0&&z(_)),T.__cacheKey=ae,T.__webglTexture=Z[ae].texture}return k}function Ve(T,_,k){return Math.floor(Math.floor(T/k)/_)}function kt(T,_,k,te){const ae=T.updateRanges;if(ae.length===0)t.texSubImage2D(i.TEXTURE_2D,0,0,0,_.width,_.height,k,te,_.data);else{ae.sort((C,K)=>C.start-K.start);let de=0;for(let C=1;C<ae.length;C++){const K=ae[de],W=ae[C],ce=K.start+K.count,se=Ve(W.start,_.width,4),oe=Ve(K.start,_.width,4);W.start<=ce+1&&se===oe&&Ve(W.start+W.count-1,_.width,4)===se?K.count=Math.max(K.count,W.start+W.count-K.start):(++de,ae[de]=W)}ae.length=de+1;const q=t.getParameter(i.UNPACK_ROW_LENGTH),X=t.getParameter(i.UNPACK_SKIP_PIXELS),le=t.getParameter(i.UNPACK_SKIP_ROWS);t.pixelStorei(i.UNPACK_ROW_LENGTH,_.width);for(let C=0,K=ae.length;C<K;C++){const W=ae[C],ce=Math.floor(W.start/4),se=Math.ceil(W.count/4),oe=ce%_.width,Ae=Math.floor(ce/_.width),Be=se,ie=1;t.pixelStorei(i.UNPACK_SKIP_PIXELS,oe),t.pixelStorei(i.UNPACK_SKIP_ROWS,Ae),t.texSubImage2D(i.TEXTURE_2D,0,oe,Ae,Be,ie,k,te,_.data)}T.clearUpdateRanges(),t.pixelStorei(i.UNPACK_ROW_LENGTH,q),t.pixelStorei(i.UNPACK_SKIP_PIXELS,X),t.pixelStorei(i.UNPACK_SKIP_ROWS,le)}}function At(T,_,k){let te=i.TEXTURE_2D;(_.isDataArrayTexture||_.isCompressedArrayTexture)&&(te=i.TEXTURE_2D_ARRAY),_.isData3DTexture&&(te=i.TEXTURE_3D);const Z=ot(T,_),ae=_.source;t.bindTexture(te,T.__webglTexture,i.TEXTURE0+k);const de=n.get(ae);if(ae.version!==de.__version||Z===!0){if(t.activeTexture(i.TEXTURE0+k),(typeof ImageBitmap<"u"&&_.image instanceof ImageBitmap)===!1){const ie=Xe.getPrimaries(Xe.workingColorSpace),Re=_.colorSpace===li?null:Xe.getPrimaries(_.colorSpace),ke=_.colorSpace===li||ie===Re?i.NONE:i.BROWSER_DEFAULT_WEBGL;t.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,_.flipY),t.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,_.premultiplyAlpha),t.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,ke)}t.pixelStorei(i.UNPACK_ALIGNMENT,_.unpackAlignment);let X=x(_.image,!1,s.maxTextureSize);X=Pe(_,X);const le=r.convert(_.format,_.colorSpace),C=r.convert(_.type);let K=E(_.internalFormat,le,C,_.normalized,_.colorSpace,_.isVideoTexture);nt(te,_);let W;const ce=_.mipmaps,se=_.isVideoTexture!==!0,oe=de.__version===void 0||Z===!0,Ae=ae.dataReady,Be=w(_,X);if(_.isDepthTexture)K=y(_.format===Ti,_.type),oe&&(se?t.texStorage2D(i.TEXTURE_2D,1,K,X.width,X.height):t.texImage2D(i.TEXTURE_2D,0,K,X.width,X.height,0,le,C,null));else if(_.isDataTexture)if(ce.length>0){se&&oe&&t.texStorage2D(i.TEXTURE_2D,Be,K,ce[0].width,ce[0].height);for(let ie=0,Re=ce.length;ie<Re;ie++)W=ce[ie],se?Ae&&t.texSubImage2D(i.TEXTURE_2D,ie,0,0,W.width,W.height,le,C,W.data):t.texImage2D(i.TEXTURE_2D,ie,K,W.width,W.height,0,le,C,W.data);_.generateMipmaps=!1}else se?(oe&&t.texStorage2D(i.TEXTURE_2D,Be,K,X.width,X.height),Ae&&kt(_,X,le,C)):t.texImage2D(i.TEXTURE_2D,0,K,X.width,X.height,0,le,C,X.data);else if(_.isCompressedTexture)if(_.isCompressedArrayTexture){se&&oe&&t.texStorage3D(i.TEXTURE_2D_ARRAY,Be,K,ce[0].width,ce[0].height,X.depth);for(let ie=0,Re=ce.length;ie<Re;ie++)if(W=ce[ie],_.format!==qn)if(le!==null)if(se){if(Ae)if(_.layerUpdates.size>0){const ke=rd(W.width,W.height,_.format,_.type);for(const ge of _.layerUpdates){const it=W.data.subarray(ge*ke/W.data.BYTES_PER_ELEMENT,(ge+1)*ke/W.data.BYTES_PER_ELEMENT);t.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,ie,0,0,ge,W.width,W.height,1,le,it)}}else t.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,ie,0,0,0,W.width,W.height,X.depth,le,W.data)}else t.compressedTexImage3D(i.TEXTURE_2D_ARRAY,ie,K,W.width,W.height,X.depth,0,W.data,0,0);else Le("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else se?Ae&&t.texSubImage3D(i.TEXTURE_2D_ARRAY,ie,0,0,0,W.width,W.height,X.depth,le,C,W.data):t.texImage3D(i.TEXTURE_2D_ARRAY,ie,K,W.width,W.height,X.depth,0,le,C,W.data);_.layerUpdates.size>0&&_.clearLayerUpdates()}else{se&&oe&&t.texStorage2D(i.TEXTURE_2D,Be,K,ce[0].width,ce[0].height);for(let ie=0,Re=ce.length;ie<Re;ie++)W=ce[ie],_.format!==qn?le!==null?se?Ae&&t.compressedTexSubImage2D(i.TEXTURE_2D,ie,0,0,W.width,W.height,le,W.data):t.compressedTexImage2D(i.TEXTURE_2D,ie,K,W.width,W.height,0,W.data):Le("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):se?Ae&&t.texSubImage2D(i.TEXTURE_2D,ie,0,0,W.width,W.height,le,C,W.data):t.texImage2D(i.TEXTURE_2D,ie,K,W.width,W.height,0,le,C,W.data)}else if(_.isDataArrayTexture)if(se){if(oe&&t.texStorage3D(i.TEXTURE_2D_ARRAY,Be,K,X.width,X.height,X.depth),Ae)if(_.layerUpdates.size>0){const ie=rd(X.width,X.height,_.format,_.type);for(const Re of _.layerUpdates){const ke=X.data.subarray(Re*ie/X.data.BYTES_PER_ELEMENT,(Re+1)*ie/X.data.BYTES_PER_ELEMENT);t.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,Re,X.width,X.height,1,le,C,ke)}_.clearLayerUpdates()}else t.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,0,X.width,X.height,X.depth,le,C,X.data)}else t.texImage3D(i.TEXTURE_2D_ARRAY,0,K,X.width,X.height,X.depth,0,le,C,X.data);else if(_.isData3DTexture)se?(oe&&t.texStorage3D(i.TEXTURE_3D,Be,K,X.width,X.height,X.depth),Ae&&t.texSubImage3D(i.TEXTURE_3D,0,0,0,0,X.width,X.height,X.depth,le,C,X.data)):t.texImage3D(i.TEXTURE_3D,0,K,X.width,X.height,X.depth,0,le,C,X.data);else if(_.isFramebufferTexture){if(oe)if(se)t.texStorage2D(i.TEXTURE_2D,Be,K,X.width,X.height);else{let ie=X.width,Re=X.height;for(let ke=0;ke<Be;ke++)t.texImage2D(i.TEXTURE_2D,ke,K,ie,Re,0,le,C,null),ie>>=1,Re>>=1}}else if(_.isHTMLTexture){if("texElementImage2D"in i){const ie=i.canvas;if(ie.hasAttribute("layoutsubtree")||ie.setAttribute("layoutsubtree","true"),X.parentNode!==ie){ie.appendChild(X),d.add(_),ie.onpaint=Re=>{const ke=Re.changedElements;for(const ge of d)ke.includes(ge.image)&&(ge.needsUpdate=!0)},ie.requestPaint();return}if(i.texElementImage2D.length===3)i.texElementImage2D(i.TEXTURE_2D,i.RGBA8,X);else{const ke=i.RGBA,ge=i.RGBA,it=i.UNSIGNED_BYTE;i.texElementImage2D(i.TEXTURE_2D,0,ke,ge,it,X)}i.texParameteri(i.TEXTURE_2D,i.TEXTURE_MIN_FILTER,i.LINEAR),i.texParameteri(i.TEXTURE_2D,i.TEXTURE_WRAP_S,i.CLAMP_TO_EDGE),i.texParameteri(i.TEXTURE_2D,i.TEXTURE_WRAP_T,i.CLAMP_TO_EDGE)}}else if(ce.length>0){if(se&&oe){const ie=Ie(ce[0]);t.texStorage2D(i.TEXTURE_2D,Be,K,ie.width,ie.height)}for(let ie=0,Re=ce.length;ie<Re;ie++)W=ce[ie],se?Ae&&t.texSubImage2D(i.TEXTURE_2D,ie,0,0,le,C,W):t.texImage2D(i.TEXTURE_2D,ie,K,le,C,W);_.generateMipmaps=!1}else if(se){if(oe){const ie=Ie(X);t.texStorage2D(i.TEXTURE_2D,Be,K,ie.width,ie.height)}Ae&&t.texSubImage2D(i.TEXTURE_2D,0,0,0,le,C,X)}else t.texImage2D(i.TEXTURE_2D,0,K,le,C,X);S(_)&&_.mipmapsAutoUpdate===!0&&b(te),de.__version=ae.version,_.onUpdate&&_.onUpdate(_)}T.__version=_.version}function rn(T,_,k){if(_.image.length!==6)return;const te=ot(T,_),Z=_.source;t.bindTexture(i.TEXTURE_CUBE_MAP,T.__webglTexture,i.TEXTURE0+k);const ae=n.get(Z);if(Z.version!==ae.__version||te===!0){t.activeTexture(i.TEXTURE0+k);const de=Xe.getPrimaries(Xe.workingColorSpace),q=_.colorSpace===li?null:Xe.getPrimaries(_.colorSpace),X=_.colorSpace===li||de===q?i.NONE:i.BROWSER_DEFAULT_WEBGL;t.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,_.flipY),t.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,_.premultiplyAlpha),t.pixelStorei(i.UNPACK_ALIGNMENT,_.unpackAlignment),t.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,X);const le=_.isCompressedTexture||_.image[0].isCompressedTexture,C=_.image[0]&&_.image[0].isDataTexture,K=[];for(let ge=0;ge<6;ge++)!le&&!C?K[ge]=x(_.image[ge],!0,s.maxCubemapSize):K[ge]=C?_.image[ge].image:_.image[ge],K[ge]=Pe(_,K[ge]);const W=K[0],ce=r.convert(_.format,_.colorSpace),se=r.convert(_.type);let oe=E(_.internalFormat,ce,se,_.normalized,_.colorSpace);const Ae=_.isVideoTexture!==!0,Be=ae.__version===void 0||te===!0,ie=Z.dataReady;let Re=w(_,W);nt(i.TEXTURE_CUBE_MAP,_);let ke;if(_.isDepthTexture){if(oe=y(_.format===Ti,_.type),Be)if(Ae)t.texStorage2D(i.TEXTURE_CUBE_MAP,1,oe,W.width,W.height);else for(let ge=0;ge<6;ge++)t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ge,0,oe,W.width,W.height,0,ce,se,null)}else if(le){Ae&&Be&&t.texStorage2D(i.TEXTURE_CUBE_MAP,Re,oe,W.width,W.height);for(let ge=0;ge<6;ge++){ke=K[ge].mipmaps;for(let it=0;it<ke.length;it++){const It=ke[it];_.format!==qn?ce!==null?Ae?ie&&t.compressedTexSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ge,it,0,0,It.width,It.height,ce,It.data):t.compressedTexImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ge,it,oe,It.width,It.height,0,It.data):Le("WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):Ae?ie&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ge,it,0,0,It.width,It.height,ce,se,It.data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ge,it,oe,It.width,It.height,0,ce,se,It.data)}}}else{if(ke=_.mipmaps,Ae&&Be){ke.length>0&&Re++;const ge=Ie(K[0]);t.texStorage2D(i.TEXTURE_CUBE_MAP,Re,oe,ge.width,ge.height)}for(let ge=0;ge<6;ge++)if(C){Ae?ie&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ge,0,0,0,K[ge].width,K[ge].height,ce,se,K[ge].data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ge,0,oe,K[ge].width,K[ge].height,0,ce,se,K[ge].data);for(let it=0;it<ke.length;it++){const xi=ke[it].image[ge].image;Ae?ie&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ge,it+1,0,0,xi.width,xi.height,ce,se,xi.data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ge,it+1,oe,xi.width,xi.height,0,ce,se,xi.data)}}else{Ae?ie&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ge,0,0,0,ce,se,K[ge]):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ge,0,oe,ce,se,K[ge]);for(let it=0;it<ke.length;it++){const It=ke[it];Ae?ie&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ge,it+1,0,0,ce,se,It.image[ge]):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ge,it+1,oe,ce,se,It.image[ge])}}}S(_)&&_.mipmapsAutoUpdate===!0&&b(i.TEXTURE_CUBE_MAP),ae.__version=Z.version,_.onUpdate&&_.onUpdate(_)}T.__version=_.version}function mt(T,_,k,te,Z,ae){const de=r.convert(k.format,k.colorSpace),q=r.convert(k.type),X=E(k.internalFormat,de,q,k.normalized,k.colorSpace),le=n.get(_),C=n.get(k);if(C.__renderTarget=_,!le.__hasExternalTextures){const K=Math.max(1,_.width>>ae),W=Math.max(1,_.height>>ae);Z===i.TEXTURE_3D||Z===i.TEXTURE_2D_ARRAY?t.texImage3D(Z,ae,X,K,W,_.depth,0,de,q,null):t.texImage2D(Z,ae,X,K,W,0,de,q,null)}t.bindFramebuffer(i.FRAMEBUFFER,T),pe(_)?o.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,te,Z,C.__webglTexture,0,ft(_)):(Z===i.TEXTURE_2D||Z>=i.TEXTURE_CUBE_MAP_POSITIVE_X&&Z<=i.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&i.framebufferTexture2D(i.FRAMEBUFFER,te,Z,C.__webglTexture,ae),t.bindFramebuffer(i.FRAMEBUFFER,null)}function zn(T,_,k){if(i.bindRenderbuffer(i.RENDERBUFFER,T),_.depthBuffer){const te=_.depthTexture,Z=te&&te.isDepthTexture?te.type:null,ae=y(_.stencilBuffer,Z),de=_.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT;pe(_)?o.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,ft(_),ae,_.width,_.height):k?i.renderbufferStorageMultisample(i.RENDERBUFFER,ft(_),ae,_.width,_.height):i.renderbufferStorage(i.RENDERBUFFER,ae,_.width,_.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,de,i.RENDERBUFFER,T)}else{const te=_.textures;for(let Z=0;Z<te.length;Z++){const ae=te[Z],de=r.convert(ae.format,ae.colorSpace),q=r.convert(ae.type),X=E(ae.internalFormat,de,q,ae.normalized,ae.colorSpace);pe(_)?o.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,ft(_),X,_.width,_.height):k?i.renderbufferStorageMultisample(i.RENDERBUFFER,ft(_),X,_.width,_.height):i.renderbufferStorage(i.RENDERBUFFER,X,_.width,_.height)}}i.bindRenderbuffer(i.RENDERBUFFER,null)}function Dt(T,_,k){const te=_.isWebGLCubeRenderTarget===!0;if(t.bindFramebuffer(i.FRAMEBUFFER,T),!(_.depthTexture&&_.depthTexture.isDepthTexture))throw new Error("THREE.WebGLTextures: renderTarget.depthTexture must be an instance of THREE.DepthTexture.");const Z=n.get(_.depthTexture);Z.__renderTarget=_;const ae=te?_.depthTexture.image[0]:_.depthTexture.image;(!Z.__webglTexture||ae.width!==_.width||ae.height!==_.height)&&(ae.width=_.width,ae.height=_.height,_.depthTexture.needsUpdate=!0),te?xe(_.depthTexture,0):ve(_.depthTexture,0);const de=Z.__webglTexture,q=ft(_),X=te?i.TEXTURE_CUBE_MAP_POSITIVE_X+k:i.TEXTURE_2D,le=_.depthTexture.format===Ti?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT;if(_.depthTexture.format===Pi)pe(_)?o.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,le,X,de,0,q):i.framebufferTexture2D(i.FRAMEBUFFER,le,X,de,0);else if(_.depthTexture.format===Ti)pe(_)?o.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,le,X,de,0,q):i.framebufferTexture2D(i.FRAMEBUFFER,le,X,de,0);else throw new Error("THREE.WebGLTextures: Unknown depthTexture format.")}function pn(T){const _=n.get(T),k=T.isWebGLCubeRenderTarget===!0;if(_.__boundDepthTexture!==T.depthTexture){const te=T.depthTexture;if(_.__depthDisposeCallback&&_.__depthDisposeCallback(),te){const Z=()=>{delete _.__boundDepthTexture,delete _.__depthDisposeCallback,te.removeEventListener("dispose",Z)};te.addEventListener("dispose",Z),_.__depthDisposeCallback=Z}_.__boundDepthTexture=te}if(T.depthTexture&&!_.__autoAllocateDepthBuffer)if(k)for(let te=0;te<6;te++)Dt(_.__webglFramebuffer[te],T,te);else T.texture.mipmaps.length>0?Dt(_.__webglFramebuffer[0],T,0):Dt(_.__webglFramebuffer,T,0);else if(k){_.__webglDepthbuffer=[];for(let te=0;te<6;te++)if(t.bindFramebuffer(i.FRAMEBUFFER,_.__webglFramebuffer[te]),_.__webglDepthbuffer[te]===void 0)_.__webglDepthbuffer[te]=i.createRenderbuffer(),zn(_.__webglDepthbuffer[te],T,!1);else{const Z=T.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,ae=_.__webglDepthbuffer[te];i.bindRenderbuffer(i.RENDERBUFFER,ae),i.framebufferRenderbuffer(i.FRAMEBUFFER,Z,i.RENDERBUFFER,ae)}}else if(T.texture.mipmaps.length>0?t.bindFramebuffer(i.FRAMEBUFFER,_.__webglFramebuffer[0]):t.bindFramebuffer(i.FRAMEBUFFER,_.__webglFramebuffer),_.__webglDepthbuffer===void 0)_.__webglDepthbuffer=i.createRenderbuffer(),zn(_.__webglDepthbuffer,T,!1);else{const Z=T.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,ae=_.__webglDepthbuffer;i.bindRenderbuffer(i.RENDERBUFFER,ae),i.framebufferRenderbuffer(i.FRAMEBUFFER,Z,i.RENDERBUFFER,ae)}t.bindFramebuffer(i.FRAMEBUFFER,null)}function mn(T,_,k){const te=n.get(T);_!==void 0&&mt(te.__webglFramebuffer,T,T.texture,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,0),k!==void 0&&pn(T)}function gn(T){const _=T.texture,k=n.get(T),te=n.get(_);T.addEventListener("dispose",F),L(T);const Z=T.textures,ae=T.isWebGLCubeRenderTarget===!0,de=Z.length>1;if(de||(te.__webglTexture===void 0&&(te.__webglTexture=i.createTexture()),te.__version=_.version,a.memory.textures++),ae){k.__webglFramebuffer=[];for(let q=0;q<6;q++)if(_.mipmaps.length>0){k.__webglFramebuffer[q]=[];for(let X=0;X<_.mipmaps.length;X++)k.__webglFramebuffer[q][X]=i.createFramebuffer()}else k.__webglFramebuffer[q]=i.createFramebuffer()}else{if(_.mipmaps.length>0){k.__webglFramebuffer=[];for(let q=0;q<_.mipmaps.length;q++)k.__webglFramebuffer[q]=i.createFramebuffer()}else k.__webglFramebuffer=i.createFramebuffer();if(de)for(let q=0,X=Z.length;q<X;q++){const le=n.get(Z[q]);le.__webglTexture===void 0&&(le.__webglTexture=i.createTexture(),a.memory.textures++)}if(T.samples>0&&pe(T)===!1){k.__webglMultisampledFramebuffer=i.createFramebuffer(),k.__webglColorRenderbuffer=[],t.bindFramebuffer(i.FRAMEBUFFER,k.__webglMultisampledFramebuffer);for(let q=0;q<Z.length;q++){const X=Z[q];k.__webglColorRenderbuffer[q]=i.createRenderbuffer(),i.bindRenderbuffer(i.RENDERBUFFER,k.__webglColorRenderbuffer[q]);const le=r.convert(X.format,X.colorSpace),C=r.convert(X.type),K=E(X.internalFormat,le,C,X.normalized,X.colorSpace,T.isXRRenderTarget===!0),W=ft(T);i.renderbufferStorageMultisample(i.RENDERBUFFER,W,K,T.width,T.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+q,i.RENDERBUFFER,k.__webglColorRenderbuffer[q])}i.bindRenderbuffer(i.RENDERBUFFER,null),T.depthBuffer&&(k.__webglDepthRenderbuffer=i.createRenderbuffer(),zn(k.__webglDepthRenderbuffer,T,!0)),t.bindFramebuffer(i.FRAMEBUFFER,null)}}if(ae){t.bindTexture(i.TEXTURE_CUBE_MAP,te.__webglTexture),nt(i.TEXTURE_CUBE_MAP,_);for(let q=0;q<6;q++)if(_.mipmaps.length>0)for(let X=0;X<_.mipmaps.length;X++)mt(k.__webglFramebuffer[q][X],T,_,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+q,X);else mt(k.__webglFramebuffer[q],T,_,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+q,0);S(_)?b(i.TEXTURE_CUBE_MAP):_.mipmaps.length>0&&i.texParameteri(i.TEXTURE_CUBE_MAP,i.TEXTURE_MAX_LEVEL,_.mipmaps.length-1),t.unbindTexture()}else if(de){for(let q=0,X=Z.length;q<X;q++){const le=Z[q],C=n.get(le);let K=i.TEXTURE_2D;(T.isWebGL3DRenderTarget||T.isWebGLArrayRenderTarget)&&(K=T.isWebGL3DRenderTarget?i.TEXTURE_3D:i.TEXTURE_2D_ARRAY),t.bindTexture(K,C.__webglTexture),nt(K,le),mt(k.__webglFramebuffer,T,le,i.COLOR_ATTACHMENT0+q,K,0),S(le)&&b(K)}t.unbindTexture()}else{let q=i.TEXTURE_2D;if((T.isWebGL3DRenderTarget||T.isWebGLArrayRenderTarget)&&(q=T.isWebGL3DRenderTarget?i.TEXTURE_3D:i.TEXTURE_2D_ARRAY),t.bindTexture(q,te.__webglTexture),nt(q,_),_.mipmaps.length>0)for(let X=0;X<_.mipmaps.length;X++)mt(k.__webglFramebuffer[X],T,_,i.COLOR_ATTACHMENT0,q,X);else mt(k.__webglFramebuffer,T,_,i.COLOR_ATTACHMENT0,q,0);S(_)?b(q):_.mipmaps.length>0&&i.texParameteri(q,i.TEXTURE_MAX_LEVEL,_.mipmaps.length-1),t.unbindTexture()}T.depthBuffer&&pn(T)}function U(T){const _=T.textures;for(let k=0,te=_.length;k<te;k++){const Z=_[k];if(S(Z)&&Z.mipmapsAutoUpdate===!0){const ae=A(T),de=n.get(Z).__webglTexture;t.bindTexture(ae,de),b(ae),t.unbindTexture()}}}const vn=[];function ut(T){if(T.samples>0){if(pe(T)===!1){const _=T.textures,k=T.width,te=T.height;let Z=i.COLOR_BUFFER_BIT;const ae=T.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,de=n.get(T),q=_.length>1;if(q)for(let le=0;le<_.length;le++)t.bindFramebuffer(i.FRAMEBUFFER,de.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+le,i.RENDERBUFFER,null),t.bindFramebuffer(i.FRAMEBUFFER,de.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+le,i.TEXTURE_2D,null,0);t.bindFramebuffer(i.READ_FRAMEBUFFER,de.__webglMultisampledFramebuffer),T.texture.mipmaps.length>0?t.bindFramebuffer(i.DRAW_FRAMEBUFFER,de.__webglFramebuffer[0]):t.bindFramebuffer(i.DRAW_FRAMEBUFFER,de.__webglFramebuffer);for(let le=0;le<_.length;le++){if(T.resolveDepthBuffer&&(T.depthBuffer&&(Z|=i.DEPTH_BUFFER_BIT),T.stencilBuffer&&T.resolveStencilBuffer&&(Z|=i.STENCIL_BUFFER_BIT)),q){i.framebufferRenderbuffer(i.READ_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.RENDERBUFFER,de.__webglColorRenderbuffer[le]);const C=n.get(_[le]).__webglTexture;i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,C,0)}i.blitFramebuffer(0,0,k,te,0,0,k,te,Z,i.NEAREST),c===!0&&(vn.length=0,vn.push(i.COLOR_ATTACHMENT0+le),T.depthBuffer&&T.storeMultisampledDepthBuffer===!1&&vn.push(ae),i.invalidateFramebuffer(i.READ_FRAMEBUFFER,vn))}if(t.bindFramebuffer(i.READ_FRAMEBUFFER,null),t.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),q)for(let le=0;le<_.length;le++){t.bindFramebuffer(i.FRAMEBUFFER,de.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+le,i.RENDERBUFFER,de.__webglColorRenderbuffer[le]);const C=n.get(_[le]).__webglTexture;t.bindFramebuffer(i.FRAMEBUFFER,de.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+le,i.TEXTURE_2D,C,0)}t.bindFramebuffer(i.DRAW_FRAMEBUFFER,de.__webglMultisampledFramebuffer)}else if(T.depthBuffer&&T.storeMultisampledDepthBuffer===!1&&c){const _=T.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT;i.invalidateFramebuffer(i.DRAW_FRAMEBUFFER,[_])}}}function ft(T){return Math.min(s.maxSamples,T.samples)}function pe(T){const _=n.get(T);return T.samples>0&&e.has("WEBGL_multisampled_render_to_texture")===!0&&_.__useRenderToTexture!==!1}function Tt(T){const _=a.render.frame;h.get(T)!==_&&(h.set(T,_),T.update())}function Pe(T,_){const k=T.colorSpace,te=T.format,Z=T.type;return T.isCompressedTexture===!0||T.isVideoTexture===!0||k!==za&&k!==li&&(Xe.getTransfer(k)===st?(te!==qn||Z!==ln)&&Le("WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):Ze("WebGLTextures: Unsupported texture color space:",k)),_}function Ie(T){return typeof HTMLImageElement<"u"&&T instanceof HTMLImageElement?(l.width=T.naturalWidth||T.width,l.height=T.naturalHeight||T.height):typeof VideoFrame<"u"&&T instanceof VideoFrame?(l.width=T.displayWidth,l.height=T.displayHeight):(l.width=T.width,l.height=T.height),l}this.allocateTextureUnit=Ue,this.resetTextureUnits=j,this.getTextureUnits=ee,this.setTextureUnits=we,this.setTexture2D=ve,this.setTexture2DArray=_e,this.setTexture3D=Ce,this.setTextureCube=xe,this.rebindTextures=mn,this.setupRenderTarget=gn,this.updateRenderTargetMipmap=U,this.updateMultisampleRenderTarget=ut,this.setupDepthRenderbuffer=pn,this.setupFrameBufferTexture=mt,this.useMultisampledRTT=pe,this.dispose=H}function hb(i,e){function t(n,s=li){let r;const a=Xe.getTransfer(s);if(n===ln)return i.UNSIGNED_BYTE;if(n===pc)return i.UNSIGNED_SHORT_4_4_4_4;if(n===mc)return i.UNSIGNED_SHORT_5_5_5_1;if(n===wu)return i.UNSIGNED_INT_5_9_9_9_REV;if(n===Eu)return i.UNSIGNED_INT_10F_11F_11F_REV;if(n===Mu)return i.BYTE;if(n===Su)return i.SHORT;if(n===vr)return i.UNSIGNED_SHORT;if(n===fc)return i.INT;if(n===Kn)return i.UNSIGNED_INT;if(n===Dn)return i.FLOAT;if(n===Jn)return i.HALF_FLOAT;if(n===Au)return i.ALPHA;if(n===Tu)return i.RGB;if(n===qn)return i.RGBA;if(n===Pi)return i.DEPTH_COMPONENT;if(n===Ti)return i.DEPTH_STENCIL;if(n===gc)return i.RED;if(n===vc)return i.RED_INTEGER;if(n===Ji)return i.RG;if(n===xc)return i.RG_INTEGER;if(n===yc)return i.RGBA_INTEGER;if(n===Aa||n===Ta||n===Ra||n===Ca)if(a===st)if(r=e.get("WEBGL_compressed_texture_s3tc_srgb"),r!==null){if(n===Aa)return r.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(n===Ta)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(n===Ra)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(n===Ca)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(r=e.get("WEBGL_compressed_texture_s3tc"),r!==null){if(n===Aa)return r.COMPRESSED_RGB_S3TC_DXT1_EXT;if(n===Ta)return r.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(n===Ra)return r.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(n===Ca)return r.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(n===al||n===ol||n===ll||n===cl)if(r=e.get("WEBGL_compressed_texture_pvrtc"),r!==null){if(n===al)return r.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(n===ol)return r.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(n===ll)return r.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(n===cl)return r.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(n===hl||n===dl||n===ul||n===fl||n===pl||n===ka||n===ml)if(r=e.get("WEBGL_compressed_texture_etc"),r!==null){if(n===hl||n===dl)return a===st?r.COMPRESSED_SRGB8_ETC2:r.COMPRESSED_RGB8_ETC2;if(n===ul)return a===st?r.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:r.COMPRESSED_RGBA8_ETC2_EAC;if(n===fl)return r.COMPRESSED_R11_EAC;if(n===pl)return r.COMPRESSED_SIGNED_R11_EAC;if(n===ka)return r.COMPRESSED_RG11_EAC;if(n===ml)return r.COMPRESSED_SIGNED_RG11_EAC}else return null;if(n===gl||n===vl||n===xl||n===yl||n===bl||n===_l||n===Ml||n===Sl||n===wl||n===El||n===Al||n===Tl||n===Rl||n===Cl)if(r=e.get("WEBGL_compressed_texture_astc"),r!==null){if(n===gl)return a===st?r.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:r.COMPRESSED_RGBA_ASTC_4x4_KHR;if(n===vl)return a===st?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:r.COMPRESSED_RGBA_ASTC_5x4_KHR;if(n===xl)return a===st?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:r.COMPRESSED_RGBA_ASTC_5x5_KHR;if(n===yl)return a===st?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:r.COMPRESSED_RGBA_ASTC_6x5_KHR;if(n===bl)return a===st?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:r.COMPRESSED_RGBA_ASTC_6x6_KHR;if(n===_l)return a===st?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:r.COMPRESSED_RGBA_ASTC_8x5_KHR;if(n===Ml)return a===st?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:r.COMPRESSED_RGBA_ASTC_8x6_KHR;if(n===Sl)return a===st?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:r.COMPRESSED_RGBA_ASTC_8x8_KHR;if(n===wl)return a===st?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:r.COMPRESSED_RGBA_ASTC_10x5_KHR;if(n===El)return a===st?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:r.COMPRESSED_RGBA_ASTC_10x6_KHR;if(n===Al)return a===st?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:r.COMPRESSED_RGBA_ASTC_10x8_KHR;if(n===Tl)return a===st?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:r.COMPRESSED_RGBA_ASTC_10x10_KHR;if(n===Rl)return a===st?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:r.COMPRESSED_RGBA_ASTC_12x10_KHR;if(n===Cl)return a===st?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:r.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(n===Pl||n===Ll||n===Dl)if(r=e.get("EXT_texture_compression_bptc"),r!==null){if(n===Pl)return a===st?r.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:r.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(n===Ll)return r.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(n===Dl)return r.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(n===Il||n===Nl||n===Ba||n===Ul)if(r=e.get("EXT_texture_compression_rgtc"),r!==null){if(n===Il)return r.COMPRESSED_RED_RGTC1_EXT;if(n===Nl)return r.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(n===Ba)return r.COMPRESSED_RED_GREEN_RGTC2_EXT;if(n===Ul)return r.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return n===Ds?i.UNSIGNED_INT_24_8:i[n]!==void 0?i[n]:null}return{convert:t}}const db=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,ub=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class fb{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(e,t){if(this.texture===null){const n=new Wu(e.texture);(e.depthNear!==t.depthNear||e.depthFar!==t.depthFar)&&(this.depthNear=e.depthNear,this.depthFar=e.depthFar),this.texture=n}}getMesh(e){if(this.texture!==null&&this.mesh===null){const t=e.cameras[0].viewport,n=new fn({vertexShader:db,fragmentShader:ub,uniforms:{depthColor:{value:this.texture},depthWidth:{value:t.z},depthHeight:{value:t.w}}});this.mesh=new je(new pi(20,20),n)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class pb extends ts{constructor(e,t){super();const n=this;let s=null,r=1,a=null,o="local-floor",c=1,l=null,h=null,d=null,u=null,f=null,g=null;const v=typeof XRWebGLBinding<"u",p=new fb,m={},x=t.getContextAttributes();let S=null,b=null;const A=[],E=[],y=new fe;let w=null,L=null;const R=new dn;R.viewport=new vt;const N=new dn;N.viewport=new vt;const F=[R,N],V=new E0;let I=null,H=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(Y){let ve=A[Y];return ve===void 0&&(ve=new Mo,A[Y]=ve),ve.getTargetRaySpace()},this.getControllerGrip=function(Y){let ve=A[Y];return ve===void 0&&(ve=new Mo,A[Y]=ve),ve.getGripSpace()},this.getHand=function(Y){let ve=A[Y];return ve===void 0&&(ve=new Mo,A[Y]=ve),ve.getHandSpace()};function J(Y){const ve=E.indexOf(Y.inputSource);if(ve===-1)return;const _e=A[ve];_e!==void 0&&(_e.update(Y.inputSource,Y.frame,l||a),_e.dispatchEvent({type:Y.type,data:Y.inputSource}))}function z(){s.removeEventListener("select",J),s.removeEventListener("selectstart",J),s.removeEventListener("selectend",J),s.removeEventListener("squeeze",J),s.removeEventListener("squeezestart",J),s.removeEventListener("squeezeend",J),s.removeEventListener("end",z),s.removeEventListener("inputsourceschange",ne);for(let Y=0;Y<A.length;Y++){const ve=E[Y];ve!==null&&(E[Y]=null,A[Y].disconnect(ve))}I=null,H=null,p.reset();for(const Y in m)delete m[Y];if(e.setRenderTarget(S),f=null,u=null,d=null,s=null,b=null,Ue.stop(),n.isPresenting=!1,e.setPixelRatio(w),e.setSize(y.width,y.height,!1),L!==null){const Y=L.camera;Y.fov=L.fov,Y.zoom=L.zoom,Y.updateProjectionMatrix(),L=null}n.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(Y){r=Y,n.isPresenting===!0&&Le("WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(Y){o=Y,n.isPresenting===!0&&Le("WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return l||a},this.setReferenceSpace=function(Y){l=Y},this.getBaseLayer=function(){return u!==null?u:f},this.getBinding=function(){return d===null&&v&&(d=new XRWebGLBinding(s,t)),d},this.getFrame=function(){return g},this.getSession=function(){return s},this.setSession=async function(Y){if(s=Y,s!==null){if(S=e.getRenderTarget(),s.addEventListener("select",J),s.addEventListener("selectstart",J),s.addEventListener("selectend",J),s.addEventListener("squeeze",J),s.addEventListener("squeezestart",J),s.addEventListener("squeezeend",J),s.addEventListener("end",z),s.addEventListener("inputsourceschange",ne),x.xrCompatible!==!0&&await t.makeXRCompatible(),w=e.getPixelRatio(),e.getSize(y),v&&"createProjectionLayer"in XRWebGLBinding.prototype){let _e=null,Ce=null,xe=null;x.depth&&(xe=x.stencil?t.DEPTH24_STENCIL8:t.DEPTH_COMPONENT24,_e=x.stencil?Ti:Pi,Ce=x.stencil?Ds:Kn);const Oe={colorFormat:t.RGBA8,depthFormat:xe,scaleFactor:r};d=this.getBinding(),u=d.createProjectionLayer(Oe),s.updateRenderState({layers:[u]}),e.setPixelRatio(1),e.setSize(u.textureWidth,u.textureHeight,!1),b=new Mn(u.textureWidth,u.textureHeight,{format:qn,type:ln,depthTexture:new Is(u.textureWidth,u.textureHeight,Ce,void 0,void 0,void 0,void 0,void 0,void 0,_e),stencilBuffer:x.stencil,colorSpace:e.outputColorSpace,samples:x.antialias?4:0,resolveDepthBuffer:u.ignoreDepthValues===!1,resolveStencilBuffer:u.ignoreDepthValues===!1,storeMultisampledDepthBuffer:u.ignoreDepthValues===!1,storeMultisampledStencilBuffer:u.ignoreDepthValues===!1})}else{const _e={antialias:x.antialias,alpha:!0,depth:x.depth,stencil:x.stencil,framebufferScaleFactor:r};f=new XRWebGLLayer(s,t,_e),s.updateRenderState({baseLayer:f}),e.setPixelRatio(1),e.setSize(f.framebufferWidth,f.framebufferHeight,!1),b=new Mn(f.framebufferWidth,f.framebufferHeight,{format:qn,type:ln,colorSpace:e.outputColorSpace,stencilBuffer:x.stencil,resolveDepthBuffer:f.ignoreDepthValues===!1,resolveStencilBuffer:f.ignoreDepthValues===!1,storeMultisampledDepthBuffer:f.ignoreDepthValues===!1,storeMultisampledStencilBuffer:f.ignoreDepthValues===!1})}b.isXRRenderTarget=!0,this.setFoveation(c),l=null,a=await s.requestReferenceSpace(o),Ue.setContext(s),Ue.start(),n.isPresenting=!0,n.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(s!==null)return s.environmentBlendMode},this.getDepthTexture=function(){return p.getDepthTexture()};function ne(Y){for(let ve=0;ve<Y.removed.length;ve++){const _e=Y.removed[ve],Ce=E.indexOf(_e);Ce>=0&&(E[Ce]=null,A[Ce].disconnect(_e))}for(let ve=0;ve<Y.added.length;ve++){const _e=Y.added[ve];let Ce=E.indexOf(_e);if(Ce===-1){for(let Oe=0;Oe<A.length;Oe++)if(Oe>=E.length){E.push(_e),Ce=Oe;break}else if(E[Oe]===null){E[Oe]=_e,Ce=Oe;break}if(Ce===-1)break}const xe=A[Ce];xe&&xe.connect(_e)}}function $(Y,ve){ve===null?Y.matrixWorld.copy(Y.matrix):Y.matrixWorld.multiplyMatrices(ve.matrixWorld,Y.matrix),Y.matrixWorldInverse.copy(Y.matrixWorld).invert()}this.updateCamera=function(Y){if(s===null)return;let ve=Y.near,_e=Y.far;p.texture!==null&&(p.depthNear>0&&(ve=p.depthNear),p.depthFar>0&&(_e=p.depthFar)),V.near=N.near=R.near=ve,V.far=N.far=R.far=_e,(I!==V.near||H!==V.far)&&(s.updateRenderState({depthNear:V.near,depthFar:V.far}),I=V.near,H=V.far),V.layers.mask=Y.layers.mask|6,R.layers.mask=V.layers.mask&-5,N.layers.mask=V.layers.mask&-3;const Ce=Y.parent,xe=V.cameras;$(V,Ce);for(let Oe=0;Oe<xe.length;Oe++)$(xe[Oe],Ce);V.projectionMatrix.copy(R.projectionMatrix),V.projectionMatrixInverse.copy(R.projectionMatrixInverse),L===null&&Y.isPerspectiveCamera&&(L={camera:Y,fov:Y.fov,zoom:Y.zoom}),j(Y,V,Ce)};function j(Y,ve,_e){_e===null?Y.matrix.copy(ve.matrixWorld):(Y.matrix.copy(_e.matrixWorld),Y.matrix.invert(),Y.matrix.multiply(ve.matrixWorld)),Y.matrix.decompose(Y.position,Y.quaternion,Y.scale),Y.updateMatrixWorld(!0),Y.projectionMatrix.copy(ve.projectionMatrix),Y.projectionMatrixInverse.copy(ve.projectionMatrixInverse),Y.isPerspectiveCamera&&(Y.fov=yr*2*Math.atan(1/Y.projectionMatrix.elements[5]),Y.zoom=1)}this.getCamera=function(){return V},this.getFoveation=function(){if(!(u===null&&f===null))return c},this.setFoveation=function(Y){c=Y,u!==null&&(u.fixedFoveation=Y),f!==null&&f.fixedFoveation!==void 0&&(f.fixedFoveation=Y)},this.hasDepthSensing=function(){return p.texture!==null},this.getDepthSensingMesh=function(){return p.getMesh(V)},this.getCameraTexture=function(Y){return m[Y]};let ee=null;function we(Y,ve){if(h=ve.getViewerPose(l||a),g=ve,h!==null){const _e=h.views;f!==null&&(e.setRenderTargetFramebuffer(b,f.framebuffer),e.setRenderTarget(b));let Ce=!1;_e.length!==V.cameras.length&&(V.cameras.length=0,Ce=!0);for(let De=0;De<_e.length;De++){const nt=_e[De];let ot=null;if(f!==null)ot=f.getViewport(nt);else{const kt=d.getViewSubImage(u,nt);ot=kt.viewport,De===0&&(e.setRenderTargetTextures(b,kt.colorTexture,kt.depthStencilTexture),e.setRenderTarget(b))}let Ve=F[De];Ve===void 0&&(Ve=new dn,Ve.layers.enable(De),Ve.viewport=new vt,F[De]=Ve),Ve.matrix.fromArray(nt.transform.matrix),Ve.matrix.decompose(Ve.position,Ve.quaternion,Ve.scale),Ve.projectionMatrix.fromArray(nt.projectionMatrix),Ve.projectionMatrixInverse.copy(Ve.projectionMatrix).invert(),Ve.viewport.set(ot.x,ot.y,ot.width,ot.height),De===0&&(V.matrix.copy(Ve.matrix),V.matrix.decompose(V.position,V.quaternion,V.scale)),Ce===!0&&V.cameras.push(Ve)}const xe=s.enabledFeatures;if(xe&&xe.includes("depth-sensing")&&s.depthUsage=="gpu-optimized"&&v){d=n.getBinding();const De=d.getDepthInformation(_e[0]);De&&De.isValid&&De.texture&&p.init(De,s.renderState)}if(xe&&xe.includes("camera-access")&&v){e.state.unbindTexture(),d=n.getBinding();for(let De=0;De<_e.length;De++){const nt=_e[De].camera;if(nt){let ot=m[nt];ot||(ot=new Wu,m[nt]=ot);const Ve=d.getCameraImage(nt);ot.sourceTexture=Ve}}}}for(let _e=0;_e<A.length;_e++){const Ce=E[_e],xe=A[_e];Ce!==null&&xe!==void 0&&xe.update(Ce,ve,l||a)}ee&&ee(Y,ve),ve.detectedPlanes&&n.dispatchEvent({type:"planesdetected",data:ve}),g=null}const Ue=new rf;Ue.setAnimationLoop(we),this.setAnimationLoop=function(Y){ee=Y},this.dispose=function(){}}}const mb=new Ke,mf=new Ne;mf.set(-1,0,0,0,1,0,0,0,1);function gb(i,e){function t(p,m){p.matrixAutoUpdate===!0&&p.updateMatrix(),m.value.copy(p.matrix)}function n(p,m){m.color.getRGB(p.fogColor.value,ef(i)),m.isFog?(p.fogNear.value=m.near,p.fogFar.value=m.far):m.isFogExp2&&(p.fogDensity.value=m.density)}function s(p,m,x,S,b){m.isNodeMaterial?m.uniformsNeedUpdate=!1:m.isMeshBasicMaterial?r(p,m):m.isMeshLambertMaterial?(r(p,m),m.envMap&&(p.envMapIntensity.value=m.envMapIntensity)):m.isMeshToonMaterial?(r(p,m),d(p,m)):m.isMeshPhongMaterial?(r(p,m),h(p,m),m.envMap&&(p.envMapIntensity.value=m.envMapIntensity)):m.isMeshStandardMaterial?(r(p,m),u(p,m),m.isMeshPhysicalMaterial&&f(p,m,b)):m.isMeshMatcapMaterial?(r(p,m),g(p,m)):m.isMeshDepthMaterial?r(p,m):m.isMeshDistanceMaterial?(r(p,m),v(p,m)):m.isMeshNormalMaterial?r(p,m):m.isLineBasicMaterial?(a(p,m),m.isLineDashedMaterial&&o(p,m)):m.isPointsMaterial?c(p,m,x,S):m.isSpriteMaterial?l(p,m):m.isShadowMaterial?(p.color.value.copy(m.color),p.opacity.value=m.opacity):m.isShaderMaterial&&(m.uniformsNeedUpdate=!1)}function r(p,m){p.opacity.value=m.opacity,m.color&&p.diffuse.value.copy(m.color),m.emissive&&p.emissive.value.copy(m.emissive).multiplyScalar(m.emissiveIntensity),m.map&&(p.map.value=m.map,t(m.map,p.mapTransform)),m.alphaMap&&(p.alphaMap.value=m.alphaMap,t(m.alphaMap,p.alphaMapTransform)),m.bumpMap&&(p.bumpMap.value=m.bumpMap,t(m.bumpMap,p.bumpMapTransform),p.bumpScale.value=m.bumpScale,m.side===Gt&&(p.bumpScale.value*=-1)),m.normalMap&&(p.normalMap.value=m.normalMap,t(m.normalMap,p.normalMapTransform),p.normalScale.value.copy(m.normalScale),m.side===Gt&&p.normalScale.value.negate()),m.displacementMap&&(p.displacementMap.value=m.displacementMap,t(m.displacementMap,p.displacementMapTransform),p.displacementScale.value=m.displacementScale,p.displacementBias.value=m.displacementBias),m.emissiveMap&&(p.emissiveMap.value=m.emissiveMap,t(m.emissiveMap,p.emissiveMapTransform)),m.specularMap&&(p.specularMap.value=m.specularMap,t(m.specularMap,p.specularMapTransform)),m.alphaTest>0&&(p.alphaTest.value=m.alphaTest);const x=e.get(m),S=x.envMap,b=x.envMapRotation;S&&(p.envMap.value=S,p.envMapRotation.value.setFromMatrix4(mb.makeRotationFromEuler(b)).transpose(),S.isCubeTexture&&S.isRenderTargetTexture===!1&&p.envMapRotation.value.premultiply(mf),p.reflectivity.value=m.reflectivity,p.ior.value=m.ior,p.refractionRatio.value=m.refractionRatio),m.lightMap&&(p.lightMap.value=m.lightMap,p.lightMapIntensity.value=m.lightMapIntensity,t(m.lightMap,p.lightMapTransform)),m.aoMap&&(p.aoMap.value=m.aoMap,p.aoMapIntensity.value=m.aoMapIntensity,t(m.aoMap,p.aoMapTransform))}function a(p,m){p.diffuse.value.copy(m.color),p.opacity.value=m.opacity,m.map&&(p.map.value=m.map,t(m.map,p.mapTransform))}function o(p,m){p.dashSize.value=m.dashSize,p.totalSize.value=m.dashSize+m.gapSize,p.scale.value=m.scale}function c(p,m,x,S){p.diffuse.value.copy(m.color),p.opacity.value=m.opacity,p.size.value=m.size*x,p.scale.value=S*.5,m.map&&(p.map.value=m.map,t(m.map,p.uvTransform)),m.alphaMap&&(p.alphaMap.value=m.alphaMap,t(m.alphaMap,p.alphaMapTransform)),m.alphaTest>0&&(p.alphaTest.value=m.alphaTest)}function l(p,m){p.diffuse.value.copy(m.color),p.opacity.value=m.opacity,p.rotation.value=m.rotation,m.map&&(p.map.value=m.map,t(m.map,p.mapTransform)),m.alphaMap&&(p.alphaMap.value=m.alphaMap,t(m.alphaMap,p.alphaMapTransform)),m.alphaTest>0&&(p.alphaTest.value=m.alphaTest)}function h(p,m){p.specular.value.copy(m.specular),p.shininess.value=Math.max(m.shininess,1e-4)}function d(p,m){m.gradientMap&&(p.gradientMap.value=m.gradientMap)}function u(p,m){p.metalness.value=m.metalness,m.metalnessMap&&(p.metalnessMap.value=m.metalnessMap,t(m.metalnessMap,p.metalnessMapTransform)),p.roughness.value=m.roughness,m.roughnessMap&&(p.roughnessMap.value=m.roughnessMap,t(m.roughnessMap,p.roughnessMapTransform)),m.envMap&&(p.envMapIntensity.value=m.envMapIntensity)}function f(p,m,x){p.ior.value=m.ior,m.diffuseRoughness>0&&(p.diffuseRoughness.value=m.diffuseRoughness,m.diffuseRoughnessMap&&(p.diffuseRoughnessMap.value=m.diffuseRoughnessMap,t(m.diffuseRoughnessMap,p.diffuseRoughnessMapTransform))),m.sheen>0&&(p.sheenColor.value.copy(m.sheenColor).multiplyScalar(m.sheen),p.sheenRoughness.value=m.sheenRoughness,m.sheenColorMap&&(p.sheenColorMap.value=m.sheenColorMap,t(m.sheenColorMap,p.sheenColorMapTransform)),m.sheenRoughnessMap&&(p.sheenRoughnessMap.value=m.sheenRoughnessMap,t(m.sheenRoughnessMap,p.sheenRoughnessMapTransform))),m.clearcoat>0&&(p.clearcoat.value=m.clearcoat,p.clearcoatRoughness.value=m.clearcoatRoughness,m.clearcoatMap&&(p.clearcoatMap.value=m.clearcoatMap,t(m.clearcoatMap,p.clearcoatMapTransform)),m.clearcoatRoughnessMap&&(p.clearcoatRoughnessMap.value=m.clearcoatRoughnessMap,t(m.clearcoatRoughnessMap,p.clearcoatRoughnessMapTransform)),m.clearcoatNormalMap&&(p.clearcoatNormalMap.value=m.clearcoatNormalMap,t(m.clearcoatNormalMap,p.clearcoatNormalMapTransform),p.clearcoatNormalScale.value.copy(m.clearcoatNormalScale),m.side===Gt&&p.clearcoatNormalScale.value.negate())),m.dispersion>0&&(p.dispersion.value=m.dispersion),m.retroreflectivity>0&&(p.retroreflectivity.value=m.retroreflectivity),m.iridescence>0&&(p.iridescence.value=m.iridescence,p.iridescenceIOR.value=m.iridescenceIOR,p.iridescenceThicknessMinimum.value=m.iridescenceThicknessMinimum,p.iridescenceThicknessMaximum.value=m.iridescenceThicknessMaximum,m.iridescenceMap&&(p.iridescenceMap.value=m.iridescenceMap,t(m.iridescenceMap,p.iridescenceMapTransform)),m.iridescenceThicknessMap&&(p.iridescenceThicknessMap.value=m.iridescenceThicknessMap,t(m.iridescenceThicknessMap,p.iridescenceThicknessMapTransform))),m.transmission>0&&(p.transmission.value=m.transmission,p.transmissionSamplerMap.value=x.texture,p.transmissionSamplerSize.value.set(x.width,x.height),m.transmissionMap&&(p.transmissionMap.value=m.transmissionMap,t(m.transmissionMap,p.transmissionMapTransform)),p.thickness.value=m.thickness,m.thicknessMap&&(p.thicknessMap.value=m.thicknessMap,t(m.thicknessMap,p.thicknessMapTransform)),p.attenuationDistance.value=m.attenuationDistance,p.attenuationColor.value.copy(m.attenuationColor)),m.anisotropy>0&&(p.anisotropyVector.value.set(m.anisotropy*Math.cos(m.anisotropyRotation),m.anisotropy*Math.sin(m.anisotropyRotation)),m.anisotropyMap&&(p.anisotropyMap.value=m.anisotropyMap,t(m.anisotropyMap,p.anisotropyMapTransform))),p.specularIntensity.value=m.specularIntensity,p.specularColor.value.copy(m.specularColor),m.specularColorMap&&(p.specularColorMap.value=m.specularColorMap,t(m.specularColorMap,p.specularColorMapTransform)),m.specularIntensityMap&&(p.specularIntensityMap.value=m.specularIntensityMap,t(m.specularIntensityMap,p.specularIntensityMapTransform))}function g(p,m){m.matcap&&(p.matcap.value=m.matcap)}function v(p,m){const x=e.get(m).light;p.referencePosition.value.setFromMatrixPosition(x.matrixWorld),p.nearDistance.value=x.shadow.camera.near,p.farDistance.value=x.shadow.camera.far}return{refreshFogUniforms:n,refreshMaterialUniforms:s}}function vb(i,e,t,n){let s={},r={};function a(x,S){const b=S.program;n.uniformBlockBinding(x,b,s[x.id])}function o(x,S){let b=s[x.id];b===void 0&&(g(x),b=c(x),s[x.id]=b,x.addEventListener("dispose",p));const A=S.program;n.updateUBOMapping(x,A);const E=e.render.frame;r[x.id]!==E&&(l(x),r[x.id]=E)}function c(x){const S=i.createBuffer(),b=x.__size,A=x.usage;return i.bindBuffer(i.UNIFORM_BUFFER,S),i.bufferData(i.UNIFORM_BUFFER,b,A),i.bindBuffer(i.UNIFORM_BUFFER,null),S}function l(x){const S=s[x.id],b=x.uniforms,A=x.__cache;i.bindBuffer(i.UNIFORM_BUFFER,S);for(let E=0,y=b.length;E<y;E++){const w=b[E];if(Array.isArray(w))for(let L=0,R=w.length;L<R;L++)h(w[L],E,L,A);else h(w,E,0,A)}i.bindBuffer(i.UNIFORM_BUFFER,null)}function h(x,S,b,A){if(u(x,S,b,A)===!0){const E=x.__offset,y=x.value;if(Array.isArray(y)){let w=0;for(let L=0;L<y.length;L++){const R=y[L],N=v(R,!0);d(R,x.__data,w),w+=N.storage/Float32Array.BYTES_PER_ELEMENT}}else d(y,x.__data,0);i.bufferSubData(i.UNIFORM_BUFFER,E,x.__data)}}function d(x,S,b){typeof x=="number"||typeof x=="boolean"?S[b]=x:x.isMatrix3?(S[b]=x.elements[0],S[b+1]=x.elements[1],S[b+2]=x.elements[2],S[b+3]=0,S[b+4]=x.elements[3],S[b+5]=x.elements[4],S[b+6]=x.elements[5],S[b+7]=0,S[b+8]=x.elements[6],S[b+9]=x.elements[7],S[b+10]=x.elements[8],S[b+11]=0):ArrayBuffer.isView(x)?S.set(x.subarray(0,S.length-b),b):x.toArray(S,b)}function u(x,S,b,A){const E=x.value,y=S+"_"+b;if(Array.isArray(E)){A[y]===void 0&&(A[y]=[]);const w=A[y];let L=!1;for(let R=0;R<E.length;R++)f(E[R],w,R)===!0&&(L=!0);return L}return f(E,A,y)}function f(x,S,b){if(S[b]===void 0)return typeof x=="number"||typeof x=="boolean"?S[b]=x:ArrayBuffer.isView(x)?S[b]=x.slice():S[b]=x.clone(),!0;{const A=S[b];if(typeof x=="number"||typeof x=="boolean"){if(A!==x)return S[b]=x,!0}else{if(ArrayBuffer.isView(x))return!0;if(A.equals(x)===!1)return A.copy(x),!0}}return!1}function g(x){const S=x.uniforms;let b=0;const A=16;for(let y=0,w=S.length;y<w;y++){const L=Array.isArray(S[y])?S[y]:[S[y]];for(let R=0,N=L.length;R<N;R++){const F=L[R],V=Array.isArray(F.value)?F.value:[F.value],I=Array.isArray(S[y])||Array.isArray(F.value);let H=b;for(let z=0,ne=V.length;z<ne;z++){const $=V[z],j=v($,I),ee=b%A,we=ee%j.boundary,Ue=ee+we;b+=we,Ue!==0&&A-Ue<j.storage&&(b+=A-Ue),z===0&&(H=b),b+=j.storage}const J=F.type==="int"?Int32Array:F.type==="uint"?Uint32Array:Float32Array;F.__data=new J((b-H)/Float32Array.BYTES_PER_ELEMENT),F.__offset=H}}const E=b%A;return E>0&&(b+=A-E),x.__size=b,x.__cache={},this}function v(x,S){const b={boundary:0,storage:0};return typeof x=="number"||typeof x=="boolean"?(b.boundary=4,b.storage=4):x.isVector2?(b.boundary=8,b.storage=8):x.isVector3||x.isColor?(b.boundary=16,b.storage=12):x.isVector4?(b.boundary=16,b.storage=16):x.isMatrix3?(b.boundary=16,b.storage=48):x.isMatrix4?(b.boundary=16,b.storage=64):x.isTexture?Le("WebGLRenderer: Texture samplers can not be part of an uniforms group."):ArrayBuffer.isView(x)?(b.boundary=16,b.storage=x.byteLength):Le("WebGLRenderer: Unsupported uniform value type.",x),S===!0&&(b.boundary=16,b.storage=Math.ceil(b.storage/16)*16),b}function p(x){const S=x.target;S.removeEventListener("dispose",p),i.deleteBuffer(s[S.id]),delete s[S.id],delete r[S.id]}function m(){for(const x in s)i.deleteBuffer(s[x]);s={},r={}}return{bind:a,update:o,dispose:m}}const xb=new Uint16Array([12469,15057,12620,14925,13266,14620,13807,14376,14323,13990,14545,13625,14713,13328,14840,12882,14931,12528,14996,12233,15039,11829,15066,11525,15080,11295,15085,10976,15082,10705,15073,10495,13880,14564,13898,14542,13977,14430,14158,14124,14393,13732,14556,13410,14702,12996,14814,12596,14891,12291,14937,11834,14957,11489,14958,11194,14943,10803,14921,10506,14893,10278,14858,9960,14484,14039,14487,14025,14499,13941,14524,13740,14574,13468,14654,13106,14743,12678,14818,12344,14867,11893,14889,11509,14893,11180,14881,10751,14852,10428,14812,10128,14765,9754,14712,9466,14764,13480,14764,13475,14766,13440,14766,13347,14769,13070,14786,12713,14816,12387,14844,11957,14860,11549,14868,11215,14855,10751,14825,10403,14782,10044,14729,9651,14666,9352,14599,9029,14967,12835,14966,12831,14963,12804,14954,12723,14936,12564,14917,12347,14900,11958,14886,11569,14878,11247,14859,10765,14828,10401,14784,10011,14727,9600,14660,9289,14586,8893,14508,8533,15111,12234,15110,12234,15104,12216,15092,12156,15067,12010,15028,11776,14981,11500,14942,11205,14902,10752,14861,10393,14812,9991,14752,9570,14682,9252,14603,8808,14519,8445,14431,8145,15209,11449,15208,11451,15202,11451,15190,11438,15163,11384,15117,11274,15055,10979,14994,10648,14932,10343,14871,9936,14803,9532,14729,9218,14645,8742,14556,8381,14461,8020,14365,7603,15273,10603,15272,10607,15267,10619,15256,10631,15231,10614,15182,10535,15118,10389,15042,10167,14963,9787,14883,9447,14800,9115,14710,8665,14615,8318,14514,7911,14411,7507,14279,7198,15314,9675,15313,9683,15309,9712,15298,9759,15277,9797,15229,9773,15166,9668,15084,9487,14995,9274,14898,8910,14800,8539,14697,8234,14590,7790,14479,7409,14367,7067,14178,6621,15337,8619,15337,8631,15333,8677,15325,8769,15305,8871,15264,8940,15202,8909,15119,8775,15022,8565,14916,8328,14804,8009,14688,7614,14569,7287,14448,6888,14321,6483,14088,6171,15350,7402,15350,7419,15347,7480,15340,7613,15322,7804,15287,7973,15229,8057,15148,8012,15046,7846,14933,7611,14810,7357,14682,7069,14552,6656,14421,6316,14251,5948,14007,5528,15356,5942,15356,5977,15353,6119,15348,6294,15332,6551,15302,6824,15249,7044,15171,7122,15070,7050,14949,6861,14818,6611,14679,6349,14538,6067,14398,5651,14189,5311,13935,4958,15359,4123,15359,4153,15356,4296,15353,4646,15338,5160,15311,5508,15263,5829,15188,6042,15088,6094,14966,6001,14826,5796,14678,5543,14527,5287,14377,4985,14133,4586,13869,4257,15360,1563,15360,1642,15358,2076,15354,2636,15341,3350,15317,4019,15273,4429,15203,4732,15105,4911,14981,4932,14836,4818,14679,4621,14517,4386,14359,4156,14083,3795,13808,3437,15360,122,15360,137,15358,285,15355,636,15344,1274,15322,2177,15281,2765,15215,3223,15120,3451,14995,3569,14846,3567,14681,3466,14511,3305,14344,3121,14037,2800,13753,2467,15360,0,15360,1,15359,21,15355,89,15346,253,15325,479,15287,796,15225,1148,15133,1492,15008,1749,14856,1882,14685,1886,14506,1783,14324,1608,13996,1398,13702,1183]);let Vn=null;function yb(){return Vn===null&&(Vn=new zu(xb,16,16,Ji,Jn),Vn.name="DFG_LUT",Vn.minFilter=nn,Vn.magFilter=nn,Vn.wrapS=ci,Vn.wrapT=ci,Vn.generateMipmaps=!1,Vn.needsUpdate=!0),Vn}class bb{constructor(e={}){const{canvas:t=Kp(),context:n=null,depth:s=!0,stencil:r=!1,alpha:a=!1,antialias:o=!1,premultipliedAlpha:c=!0,preserveDrawingBuffer:l=!1,powerPreference:h="default",failIfMajorPerformanceCaveat:d=!1,reversedDepthBuffer:u=!1,outputBufferType:f=ln}=e;this.isWebGLRenderer=!0;let g;if(n!==null){if(typeof WebGLRenderingContext<"u"&&n instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");g=n.getContextAttributes().alpha}else g=a;const v=f,p=new Set([yc,xc,vc]),m=new Set([ln,Kn,vr,Ds,pc,mc]),x=new Uint32Array(4),S=new Int32Array(4),b={textures:[],min:[],max:[],resolution:[]};let A=null,E=null;const y=[],w=[];let L=null;this.domElement=t,this.debug={checkShaderErrors:!0,diagnostics:{keywords:!1},onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=di,this.toneMappingExposure=1,this.transmissionResolutionScale=1;const R=this;let N=!1,F=null,V=null,I=null,H=null;this._outputColorSpace=Ft;let J=0,z=0,ne=null,$=-1,j=null;const ee=new vt,we=new vt;let Ue=null;const Y=new Te(0);let ve=0,_e=t.width,Ce=t.height,xe=1,Oe=null,_t=null;const De=new vt(0,0,_e,Ce),nt=new vt(0,0,_e,Ce);let ot=!1;const Ve=new br,kt=new Tc;let At=!1,rn=!1;const mt=new Ke,zn=new P,Dt=new vt,pn={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let mn=!1;function gn(){return ne===null?xe:1}let U=n;function vn(M,D){return t.getContext(M,D)}let ut,ft,pe,Tt,Pe,Ie,T,_,k,te,Z,ae,de,q,X,le,C,K,W,ce,se,oe,Ae;try{const M={alpha:!0,depth:s,stencil:r,antialias:o,premultipliedAlpha:c,preserveDrawingBuffer:l,powerPreference:h,failIfMajorPerformanceCaveat:d};if("setAttribute"in t&&t.setAttribute("data-engine",`three.js r${dc}`),t.addEventListener("webglcontextlost",Re,!1),t.addEventListener("webglcontextrestored",ke,!1),t.addEventListener("webglcontextcreationerror",ge,!1),U===null){const D="webgl2";if(U=vn(D,M),U===null)throw vn(D)?new Error("THREE.WebGLRenderer: Error creating WebGL context with your selected attributes."):new Error("THREE.WebGLRenderer: Error creating WebGL context.")}Be()}catch(M){throw t.removeEventListener("webglcontextlost",Re,!1),t.removeEventListener("webglcontextrestored",ke,!1),t.removeEventListener("webglcontextcreationerror",ge,!1),Ze("WebGLRenderer: "+M.message),M}function Be(){ut=new Sx(U),ut.init(),se=new hb(U,ut),ft=new ux(U,ut,e,se),pe=new lb(U,ut),ft.reversedDepthBuffer&&u&&pe.buffers.depth.setReversed(!0),V=U.createFramebuffer(),I=U.createFramebuffer(),H=U.createFramebuffer(),Tt=new Ax(U),Pe=new Yy,Ie=new cb(U,ut,pe,Pe,ft,se,Tt),T=new Mx(R),_=new R0(U),oe=new hx(U,_),k=new wx(U,_,Tt,oe),te=new Rx(U,k,_,oe,Tt),K=new Tx(U,ft,Ie),X=new fx(Pe),Z=new Xy(R,T,ut,ft,oe,X),ae=new gb(R,Pe),de=new Jy,q=new nb(ut),C=new cx(R,T,pe,te,g,c),le=new ob(R,te,ft),Ae=new vb(U,Tt,ft,pe),W=new dx(U,ut,Tt),ce=new Ex(U,ut,Tt),Tt.programs=Z.programs,R.capabilities=ft,R.extensions=ut,R.properties=Pe,R.renderLists=de,R.shadowMap=le,R.state=pe,R.info=Tt}v!==ln&&(L=new Px(v,t.width,t.height,o,s,r));const ie=new pb(R,U);this.xr=ie,this.getContext=function(){return U},this.getContextAttributes=function(){return U.getContextAttributes()},this.forceContextLoss=function(){const M=ut.get("WEBGL_lose_context");M&&M.loseContext()},this.forceContextRestore=function(){const M=ut.get("WEBGL_lose_context");M&&M.restoreContext()},this.getPixelRatio=function(){return xe},this.setPixelRatio=function(M){M!==void 0&&(xe=M,this.setSize(_e,Ce,!1))},this.getSize=function(M){return M.set(_e,Ce)},this.setSize=function(M,D,G=!0){if(ie.isPresenting){Le("WebGLRenderer: Can't change size while VR device is presenting.");return}_e=M,Ce=D,t.width=Math.floor(M*xe),t.height=Math.floor(D*xe),G===!0&&(t.style.width=M+"px",t.style.height=D+"px"),L!==null&&L.setSize(t.width,t.height),this.setViewport(0,0,M,D)},this.getDrawingBufferSize=function(M){return M.set(_e*xe,Ce*xe).floor()},this.setDrawingBufferSize=function(M,D,G){_e=M,Ce=D,xe=G,t.width=Math.floor(M*G),t.height=Math.floor(D*G),this.setViewport(0,0,M,D)},this.setEffects=function(M){if(v===ln){Ze("WebGLRenderer: setEffects() requires outputBufferType set to HalfFloatType or FloatType.");return}if(M){for(let D=0;D<M.length;D++)if(M[D].isOutputPass===!0){Le("WebGLRenderer: OutputPass is not needed in setEffects(). Tone mapping and color space conversion are applied automatically.");break}}L.setEffects(M||[])},this.getCurrentViewport=function(M){return M.copy(ee)},this.getViewport=function(M){return M.copy(De)},this.setViewport=function(M,D,G,O){M.isVector4?De.set(M.x,M.y,M.z,M.w):De.set(M,D,G,O),pe.viewport(ee.copy(De).multiplyScalar(gn()).round())},this.getScissor=function(M){return M.copy(nt)},this.setScissor=function(M,D,G,O){M.isVector4?nt.set(M.x,M.y,M.z,M.w):nt.set(M,D,G,O),pe.scissor(we.copy(nt).multiplyScalar(gn()).round())},this.getScissorTest=function(){return ot},this.setScissorTest=function(M){pe.setScissorTest(ot=M)},this.setOpaqueSort=function(M){Oe=M},this.setTransparentSort=function(M){_t=M},this.getClearColor=function(M){return M.copy(C.getClearColor())},this.setClearColor=function(){C.setClearColor(...arguments)},this.getClearAlpha=function(){return C.getClearAlpha()},this.setClearAlpha=function(){C.setClearAlpha(...arguments)},this.clear=function(M=!0,D=!0,G=!0){let O=0;if(M){let B=!1;if(ne!==null){const ue=ne.texture.format;B=p.has(ue)}if(B){const ue=ne.texture.type,be=m.has(ue),he=C.getClearColor(),ye=C.getClearAlpha(),Ee=he.r,Fe=he.g,We=he.b;be?(x[0]=Ee,x[1]=Fe,x[2]=We,x[3]=ye,U.clearBufferuiv(U.COLOR,0,x)):(S[0]=Ee,S[1]=Fe,S[2]=We,S[3]=ye,U.clearBufferiv(U.COLOR,0,S))}else O|=U.COLOR_BUFFER_BIT}D&&(O|=U.DEPTH_BUFFER_BIT,this.state.buffers.depth.setMask(!0)),G&&(O|=U.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),O!==0&&U.clear(O)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.setNodesHandler=function(M){M.setRenderer(this),F=M},this.dispose=function(){t.removeEventListener("webglcontextlost",Re,!1),t.removeEventListener("webglcontextrestored",ke,!1),t.removeEventListener("webglcontextcreationerror",ge,!1),C.dispose(),de.dispose(),q.dispose(),Ie.dispose(),Pe.dispose(),T.dispose(),te.dispose(),k.dispose(),oe.dispose(),Ae.dispose(),Z.dispose(),ie.dispose(),ie.removeEventListener("sessionstart",Kc),ie.removeEventListener("sessionend",Jc),Oi.stop()};function Re(M){M.preventDefault(),Va("WebGLRenderer: Context Lost."),N=!0}function ke(){Va("WebGLRenderer: Context Restored."),N=!1;const M=Tt.autoReset,D=le.enabled,G=le.autoUpdate,O=le.needsUpdate,B=le.type;Be(),Tt.autoReset=M,le.enabled=D,le.autoUpdate=G,le.needsUpdate=O,le.type=B}function ge(M){Ze("WebGLRenderer: A WebGL context could not be created. Reason: ",M.statusMessage)}function it(M){const D=M.target;D.removeEventListener("dispose",it),It(D)}function It(M){xi(M),Pe.remove(M)}function xi(M){const D=Pe.get(M).programs;D!==void 0&&(D.forEach(function(G){Z.releaseProgram(G)}),M.isShaderMaterial&&Z.releaseShaderCache(M))}this.renderBufferDirect=function(M,D,G,O,B,ue){D===null&&(D=pn);const be=B.isMesh&&B.matrixWorld.determinantAffine()<0,he=Yf(M,D,G,O,B);pe.setMaterial(O,be);let ye=G.index,Ee=1;if(O.wireframe===!0){if(ye=k.getWireframeAttribute(G),ye===void 0)return;Ee=2}const Fe=G.drawRange,We=G.attributes.position;let Me=Fe.start*Ee,$e=(Fe.start+Fe.count)*Ee;ue!==null&&(Me=Math.max(Me,ue.start*Ee),$e=Math.min($e,(ue.start+ue.count)*Ee)),ye!==null?(Me=Math.max(Me,0),$e=Math.min($e,ye.count)):We!=null&&(Me=Math.max(Me,0),$e=Math.min($e,We.count));const Mt=$e-Me;if(Mt<0||Mt===1/0)return;oe.setup(B,O,he,G,ye);let ct,lt=W;if(ye!==null&&(ct=_.get(ye),lt=ce,lt.setIndex(ct)),B.isMesh)O.wireframe===!0?(pe.setLineWidth(O.wireframeLinewidth*gn()),lt.setMode(U.LINES)):lt.setMode(U.TRIANGLES);else if(B.isLine){let $t=O.linewidth;$t===void 0&&($t=1),pe.setLineWidth($t*gn()),B.isLineSegments?lt.setMode(U.LINES):B.isLineLoop?lt.setMode(U.LINE_LOOP):lt.setMode(U.LINE_STRIP)}else B.isPoints?lt.setMode(U.POINTS):B.isSprite&&lt.setMode(U.TRIANGLES);if(B.isBatchedMesh)if(ut.get("WEBGL_multi_draw"))lt.renderMultiDraw(B._multiDrawStarts,B._multiDrawCounts,B._multiDrawCount);else{const $t=B._multiDrawStarts,Se=B._multiDrawCounts,Qt=B._multiDrawCount,et=ye?_.get(ye).bytesPerElement:1,ki=Pe.get(O).currentProgram.getUniforms();for(let qt=0;qt<Qt;qt++)ki.setValue(U,"_gl_DrawID",qt),lt.render($t[qt]/et,Se[qt])}else if(B.isInstancedMesh)lt.renderInstances(Me,Mt,B.count);else if(G.isInstancedBufferGeometry){const $t=G._maxInstanceCount!==void 0?G._maxInstanceCount:1/0,Se=Math.min(G.instanceCount,$t);lt.renderInstances(Me,Mt,Se)}else lt.render(Me,Mt)};function Yc(M,D,G,O){F!==null&&M.isNodeMaterial&&F.setObject(O,M),At===!0&&X.setState(M,G,!1),M.transparent===!0&&M.side===bn&&M.forceSinglePass===!1?(M.side=Gt,M.needsUpdate=!0,Bs(M,D,O),M.side=Ki,M.needsUpdate=!0,Bs(M,D,O),M.side=bn):Bs(M,D,O)}this.compile=function(M,D,G=null){G===null&&(G=M),F!==null&&F.renderStart(M,D,G),E=q.get(G),E.init(D),w.push(E),G.traverseVisible(function(B){B.isLight&&B.layers.test(D.layers)&&(E.pushLight(B),B.castShadow&&E.pushShadow(B))}),M!==G&&M.traverseVisible(function(B){B.isLight&&B.layers.test(D.layers)&&(E.pushLight(B),B.castShadow&&E.pushShadow(B))}),E.setupLights(),F!==null&&F.updateLights(E.state.lightsArray),rn=this.localClippingEnabled,At=X.init(this.clippingPlanes,rn),At===!0&&X.setGlobalState(this.clippingPlanes,D),F!==null&&le.render(E.state.shadowsArray,G,D);const O=new Set;return M.traverse(function(B){if(!(B.isMesh||B.isPoints||B.isLine||B.isSprite))return;const ue=B.material;if(ue)if(Array.isArray(ue))for(let be=0;be<ue.length;be++){const he=ue[be];Yc(he,G,D,B),O.add(he)}else Yc(ue,G,D,B),O.add(ue)}),E=w.pop(),F!==null&&F.renderEnd(),O},this.compileAsync=function(M,D,G=null){const O=this.compile(M,D,G);return new Promise(B=>{function ue(){if(O.forEach(function(be){const ye=Pe.get(be).currentProgram;(ye===void 0||ye.isReady())&&O.delete(be)}),O.size===0){B(M);return}setTimeout(ue,10)}ut.get("KHR_parallel_shader_compile")!==null?ue():setTimeout(ue,10)})};let lo=null;function qf(M){lo&&lo(M)}function Kc(){Oi.stop()}function Jc(){Oi.start()}const Oi=new rf;Oi.setAnimationLoop(qf),typeof self<"u"&&Oi.setContext(self),this.setAnimationLoop=function(M){lo=M,ie.setAnimationLoop(M),M===null?Oi.stop():Oi.start()},ie.addEventListener("sessionstart",Kc),ie.addEventListener("sessionend",Jc),this.render=function(M,D){if(D!==void 0&&D.isCamera!==!0){Ze("WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(N===!0)return;F!==null&&F.renderStart(M,D);const G=ie.enabled===!0&&ie.isPresenting===!0,O=L!==null&&(ne===null||G)&&L.begin(R,ne);if(M.matrixWorldAutoUpdate===!0&&M.updateMatrixWorld(),D.parent===null&&D.matrixWorldAutoUpdate===!0&&D.updateMatrixWorld(),ie.enabled===!0&&ie.isPresenting===!0&&(L===null||L.isCompositing()===!1)&&(ie.cameraAutoUpdate===!0&&ie.updateCamera(D),D=ie.getCamera()),M.isScene===!0&&M.onBeforeRender(R,M,D,ne),E=q.get(M,w.length),E.init(D),E.state.textureUnits=Ie.getTextureUnits(),w.push(E),mt.multiplyMatrices(D.projectionMatrix,D.matrixWorldInverse),D.isArrayCamera?kt.setFromArrayCamera(D):Ve.setFromProjectionMatrix(mt,In,D.reversedDepth),rn=this.localClippingEnabled,At=X.init(this.clippingPlanes,rn),A=de.get(M,y.length),A.init(),y.push(A),this.info.render.frame++,ie.enabled===!0&&ie.isPresenting===!0){const be=R.xr.getDepthSensingMesh();be!==null&&co(be,D,-1/0,R.sortObjects)}co(M,D,0,R.sortObjects),A.finish(),F!==null&&F.updateLights(E.state.lightsArray),R.sortObjects===!0&&A.sort(Oe,_t),mn=ie.enabled===!1||ie.isPresenting===!1||ie.hasDepthSensing()===!1,mn&&C.addToRenderList(A,M),this.info.autoReset===!0&&this.info.reset(),At===!0&&X.beginShadows();const B=E.state.shadowsArray;if(le.render(B,M,D),At===!0&&X.endShadows(),(O&&L.hasRenderPass())===!1){const be=A.opaque,he=A.transmissive;if(E.setupLights(),D.isArrayCamera){const ye=D.cameras;if(he.length>0)for(let Ee=0,Fe=ye.length;Ee<Fe;Ee++){const We=ye[Ee];Qc(be,he,M,We)}mn&&C.render(M);for(let Ee=0,Fe=ye.length;Ee<Fe;Ee++){const We=ye[Ee];Zc(A,M,We,We.viewport)}}else he.length>0&&Qc(be,he,M,D),mn&&C.render(M),Zc(A,M,D)}ne!==null&&z===0&&(Ie.updateMultisampleRenderTarget(ne),Ie.updateRenderTargetMipmap(ne)),O&&L.end(R),M.isScene===!0&&M.onAfterRender(R,M,D),oe.resetDefaultState(),$=-1,j=null,w.pop(),w.length>0?(E=w[w.length-1],Ie.setTextureUnits(E.state.textureUnits),At===!0&&X.setGlobalState(R.clippingPlanes,E.state.camera)):E=null,y.pop(),y.length>0?A=y[y.length-1]:A=null,F!==null&&F.renderEnd()};function co(M,D,G,O){if(M.visible===!1)return;if(M.layers.test(D.layers)){if(M.isGroup)G=M.renderOrder;else if(M.isLOD)M.autoUpdate===!0&&M.update(D);else if(M.isLight)E.pushLight(M),M.castShadow&&E.pushShadow(M);else if(M.isSprite){const be=D.isArrayCamera?kt:Ve;if(!M.frustumCulled||M.intersectsFrustum(be)){O&&Dt.setFromMatrixPosition(M.matrixWorld).applyMatrix4(mt);const he=te.update(M),ye=M.material;ye.visible&&A.push(M,he,ye,G,Dt.z,null,D)}}else if(M.isMesh||M.isLine||M.isPoints){const be=D.isArrayCamera?kt:Ve;if(!M.frustumCulled||M.intersectsFrustum(be)){const he=te.update(M),ye=M.material;if(O&&(M.boundingSphere!==void 0?(M.boundingSphere===null&&M.computeBoundingSphere(),Dt.copy(M.boundingSphere.center)):(he.boundingSphere===null&&he.computeBoundingSphere(),Dt.copy(he.boundingSphere.center)),Dt.applyMatrix4(M.matrixWorld).applyMatrix4(mt)),Array.isArray(ye)){const Ee=he.groups;for(let Fe=0,We=Ee.length;Fe<We;Fe++){const Me=Ee[Fe],$e=ye[Me.materialIndex];$e&&$e.visible&&A.push(M,he,$e,G,Dt.z,Me,D)}}else ye.visible&&A.push(M,he,ye,G,Dt.z,null,D)}}}const ue=M.children;for(let be=0,he=ue.length;be<he;be++)co(ue[be],D,G,O)}function Zc(M,D,G,O){const{opaque:B,transmissive:ue,transparent:be}=M;E.setupLightsView(G),At===!0&&X.setGlobalState(R.clippingPlanes,G),O&&pe.viewport(ee.copy(O)),B.length>0&&Nr(B,D,G),ue.length>0&&Nr(ue,D,G),be.length>0&&Nr(be,D,G),pe.buffers.depth.setTest(!0),pe.buffers.depth.setMask(!0),pe.buffers.color.setMask(!0),pe.setPolygonOffset(!1)}function Qc(M,D,G,O){if((G.isScene===!0?G.overrideMaterial:null)!==null)return;if(E.state.transmissionRenderTarget[O.id]===void 0){const Me=ut.has("EXT_color_buffer_half_float")||ut.has("EXT_color_buffer_float");E.state.transmissionRenderTarget[O.id]=new Mn(1,1,{generateMipmaps:!0,type:Me?Jn:ln,minFilter:hi,samples:Math.max(4,ft.samples),stencilBuffer:r,resolveDepthBuffer:!1,resolveStencilBuffer:!1,storeMultisampledDepthBuffer:!1,storeMultisampledStencilBuffer:!1,colorSpace:Xe.workingColorSpace})}const ue=E.state.transmissionRenderTarget[O.id],be=O.viewport||ee;ue.setSize(be.z*R.transmissionResolutionScale,be.w*R.transmissionResolutionScale);const he=R.getRenderTarget(),ye=R.getActiveCubeFace(),Ee=R.getActiveMipmapLevel();R.setRenderTarget(ue),R.getClearColor(Y),ve=R.getClearAlpha(),ve<1&&R.setClearColor(16777215,.5),R.clear(),mn&&C.render(G);const Fe=R.toneMapping;R.toneMapping=di;const We=O.viewport;if(O.viewport!==void 0&&(O.viewport=void 0),E.setupLightsView(O),At===!0&&X.setGlobalState(R.clippingPlanes,O),Nr(M,G,O),Ie.updateMultisampleRenderTarget(ue),Ie.updateRenderTargetMipmap(ue),ut.has("WEBGL_multisampled_render_to_texture")===!1){let Me=!1;for(let $e=0,Mt=D.length;$e<Mt;$e++){const ct=D[$e],{object:lt,geometry:$t,material:Se,group:Qt}=ct;if(Se.side===bn&&lt.layers.test(O.layers)){const et=Se.side;Se.side=Gt,Se.needsUpdate=!0,jc(lt,G,O,$t,Se,Qt),Se.side=et,Se.needsUpdate=!0,Me=!0}}Me===!0&&(Ie.updateMultisampleRenderTarget(ue),Ie.updateRenderTargetMipmap(ue))}R.setRenderTarget(he,ye,Ee),R.setClearColor(Y,ve),We!==void 0&&(O.viewport=We),R.toneMapping=Fe}function Nr(M,D,G){const O=D.isScene===!0?D.overrideMaterial:null;for(let B=0,ue=M.length;B<ue;B++){const be=M[B],{object:he,geometry:ye,group:Ee}=be;let Fe=be.material;Fe.allowOverride===!0&&O!==null&&(Fe=O),he.layers.test(G.layers)&&jc(he,D,G,ye,Fe,Ee)}}function jc(M,D,G,O,B,ue){F!==null&&B.isNodeMaterial&&F.setObject(M,B),M.onBeforeRender(R,D,G,O,B,ue),M.modelViewMatrix.multiplyMatrices(G.matrixWorldInverse,M.matrixWorld),M.normalMatrix.getNormalMatrix(M.modelViewMatrix),B.onBeforeRender(R,D,G,O,M,ue),B.transparent===!0&&B.side===bn&&B.forceSinglePass===!1?(B.side=Gt,B.needsUpdate=!0,R.renderBufferDirect(G,D,O,B,M,ue),B.side=Ki,B.needsUpdate=!0,R.renderBufferDirect(G,D,O,B,M,ue),B.side=bn):R.renderBufferDirect(G,D,O,B,M,ue),M.onAfterRender(R,D,G,O,B,ue)}function eh(M){let D=0;for(const G of M)G.texture!==null&&D++;return D}function Bs(M,D,G){D.isScene!==!0&&(D=pn);const O=Pe.get(M),B=E.state.lights,ue=E.state.shadowsArray,be=B.state.version,he=Z.getParameters(M,B.state,ue,D,G,E.state.lightProbeGridArray),ye=Z.getProgramCacheKey(he);let Ee=O.programs;O.environment=M.isMeshStandardMaterial||M.isMeshLambertMaterial||M.isMeshPhongMaterial?D.environment:null,O.fog=D.fog;const Fe=M.isMeshStandardMaterial||M.isMeshLambertMaterial&&!M.envMap||M.isMeshPhongMaterial&&!M.envMap;O.envMap=T.get(M.envMap||O.environment,Fe),O.envMapRotation=O.environment!==null&&M.envMap===null?D.environmentRotation:M.envMapRotation,Ee===void 0&&(M.addEventListener("dispose",it),Ee=new Map,O.programs=Ee,O.programVariants=new Map);let We=Ee.get(ye);if(We!==void 0){if(O.currentProgram===We&&O.lightsStateVersion===be)return nh(M,he),We}else he.uniforms=Z.getUniforms(M),F!==null&&M.isNodeMaterial&&F.build(M,G,he),M.onBeforeCompile(he,R),We=Z.acquireProgram(he,ye),Ee.set(ye,We),O.uniforms=he.uniforms;const Me=O.uniforms;return(!M.isShaderMaterial&&!M.isRawShaderMaterial||M.clipping===!0)&&(Me.clippingPlanes=X.uniform),nh(M,he),O.needsLights=Jf(M),O.lightsStateVersion=be,O.needsLights&&(Me.ambientLightColor.value=B.state.ambient,Me.lightProbe.value=B.state.probe,Me.sunLights.value=B.state.sun,Me.sunLightShadows.value=B.state.sunShadow,Me.directionalLights.value=B.state.directional,Me.directionalLightShadows.value=B.state.directionalShadow,Me.spotLights.value=B.state.spot,Me.spotLightShadows.value=B.state.spotShadow,Me.rectAreaLights.value=B.state.rectArea,Me.ltc_1.value=B.state.rectAreaLTC1,Me.ltc_2.value=B.state.rectAreaLTC2,Me.pointLights.value=B.state.point,Me.pointLightShadows.value=B.state.pointShadow,Me.hemisphereLights.value=B.state.hemi,Me.sunShadowMatrix.value=B.state.sunShadowMatrix,Me.sunShadowCascade.value=B.state.sunShadowCascade,Me.directionalShadowMatrix.value=B.state.directionalShadowMatrix,Me.spotLightMatrix.value=B.state.spotLightMatrix,Me.spotLightMap.value=B.state.spotLightMap,Me.pointShadowMatrix.value=B.state.pointShadowMatrix),O.numLightProbeGrids=eh(E.state.lightProbeGridArray),O.currentProgram=We,O.uniformsList=null,We}function Xf(M,D,G,O,B){const ue=Pe.get(M),be=ue.currentProgram.id+","+O+","+B;let he=ue.programVariants.get(be);return he===void 0?(he=Bs(M,D,G),ue.programVariants.set(be,he)):(ue.currentProgram=he,ue.uniformsList=null,ue.outputColorSpace=O,ue.toneMapping=B),he}function th(M){if(M.uniformsList===null){const D=M.currentProgram.getUniforms();M.uniformsList=La.seqWithValue(D.seq,M.uniforms)}return M.uniformsList}function nh(M,D){const G=Pe.get(M);G.outputColorSpace=D.outputColorSpace,G.batching=D.batching,G.batchingColor=D.batchingColor,G.instancing=D.instancing,G.instancingColor=D.instancingColor,G.instancingMorph=D.instancingMorph,G.skinning=D.skinning,G.morphTargets=D.morphTargets,G.morphNormals=D.morphNormals,G.morphColors=D.morphColors,G.morphTargetsCount=D.morphTargetsCount,G.numClippingPlanes=D.numClippingPlanes,G.numIntersection=D.numClipIntersection,G.vertexAlphas=D.vertexAlphas,G.vertexTangents=D.vertexTangents,G.toneMapping=D.toneMapping}function Yf(M,D,G,O,B){D.isScene!==!0&&(D=pn),Ie.resetTextureUnits();const ue=D.fog,be=O.isMeshStandardMaterial||O.isMeshLambertMaterial||O.isMeshPhongMaterial?D.environment:null,he=ne===null?R.outputColorSpace:ne.isXRRenderTarget===!0?ne.texture.colorSpace:Xe.workingColorSpace,ye=O.isMeshStandardMaterial||O.isMeshLambertMaterial&&!O.envMap||O.isMeshPhongMaterial&&!O.envMap,Ee=T.get(O.envMap||be,ye),Fe=O.vertexColors===!0&&!!G.attributes.color&&G.attributes.color.itemSize===4,We=!!G.attributes.tangent&&(!!O.normalMap||O.anisotropy>0),Me=!!G.morphAttributes.position,$e=!!G.morphAttributes.normal,Mt=!!G.morphAttributes.color;let ct=di;O.toneMapped&&(ne===null||ne.isXRRenderTarget===!0)&&(ct=R.toneMapping);const lt=G.morphAttributes.position||G.morphAttributes.normal||G.morphAttributes.color,$t=lt!==void 0?lt.length:0,Se=Pe.get(O),Qt=E.state.lights;if(At===!0&&(rn===!0||M!==j)){const gt=M===j&&O.id===$;X.setState(O,M,gt)}let et=!1,ki=!1;O.version===Se.__version?Se.needsLights&&Se.lightsStateVersion!==Qt.state.version||B.isBatchedMesh&&Se.batching===!1||!B.isBatchedMesh&&Se.batching===!0||B.isBatchedMesh&&Se.batchingColor===!0&&B._colorsTexture===null||B.isBatchedMesh&&Se.batchingColor===!1&&B._colorsTexture!==null||B.isInstancedMesh&&Se.instancing===!1||!B.isInstancedMesh&&Se.instancing===!0||B.isSkinnedMesh&&Se.skinning===!1||!B.isSkinnedMesh&&Se.skinning===!0||B.isInstancedMesh&&Se.instancingColor===!0&&B.instanceColor===null||B.isInstancedMesh&&Se.instancingColor===!1&&B.instanceColor!==null||B.isInstancedMesh&&Se.instancingMorph===!0&&B.morphTexture===null||B.isInstancedMesh&&Se.instancingMorph===!1&&B.morphTexture!==null||Se.envMap!==Ee||O.fog===!0&&Se.fog!==ue||Se.numClippingPlanes!==void 0&&(Se.numClippingPlanes!==X.numPlanes||Se.numIntersection!==X.numIntersection)||Se.vertexAlphas!==Fe||Se.vertexTangents!==We||Se.morphTargets!==Me||Se.morphNormals!==$e||Se.morphColors!==Mt||Se.morphTargetsCount!==$t||Se.numLightProbeGrids!==eh(E.state.lightProbeGridArray)?et=!0:(Se.outputColorSpace!==he||Se.toneMapping!==ct)&&(ki=!0):(et=!0,Se.__version=O.version);let qt=Se.currentProgram;(et===!0||ki===!0)&&(qt=ki===!0?Xf(O,D,B,he,ct):Bs(O,D,B),F&&O.isNodeMaterial&&F.onUpdateProgram(O,qt,Se));let Ur=!1,yi=!1,Bi=!1;const Je=qt.getUniforms(),Bt=Se.uniforms;if(pe.useProgram(qt.program)&&(Ur=!0,yi=!0,Bi=!0),O.id!==$&&($=O.id,yi=!0),Ur||j!==M){pe.buffers.depth.getReversed()&&M.reversedDepth!==!0&&(M._reversedDepth=!0,M.updateProjectionMatrix()),Je.setValue(U,"projectionMatrix",M.projectionMatrix),Je.setValue(U,"viewMatrix",M.matrixWorldInverse);const Nt=Je.map.cameraPosition;Nt!==void 0&&Nt.setValue(U,zn.setFromMatrixPosition(M.matrixWorld)),ft.logarithmicDepthBuffer&&Je.setValue(U,"logDepthBufFC",2/(Math.log(M.far+1)/Math.LN2)),(O.isMeshPhongMaterial||O.isMeshToonMaterial||O.isMeshLambertMaterial||O.isMeshBasicMaterial||O.isMeshStandardMaterial||O.isShaderMaterial)&&Je.setValue(U,"isOrthographic",M.isOrthographicCamera===!0),j!==M&&(j=M,yi=!0,Bi=!0)}if(Se.needsLights&&(Qt.state.sunShadowMap.length>0&&Je.setValue(U,"sunShadowMap",Qt.state.sunShadowMap,Ie),Qt.state.directionalShadowMap.length>0&&Je.setValue(U,"directionalShadowMap",Qt.state.directionalShadowMap,Ie),Qt.state.spotShadowMap.length>0&&Je.setValue(U,"spotShadowMap",Qt.state.spotShadowMap,Ie),Qt.state.pointShadowMap.length>0&&Je.setValue(U,"pointShadowMap",Qt.state.pointShadowMap,Ie)),B.isSkinnedMesh){Je.setOptional(U,B,"bindMatrix"),Je.setOptional(U,B,"bindMatrixInverse");const gt=B.skeleton;gt&&(gt.boneTexture===null&&gt.computeBoneTexture(),Je.setValue(U,"boneTexture",gt.boneTexture,Ie))}B.isBatchedMesh&&(Je.setOptional(U,B,"batchingTexture"),Je.setValue(U,"batchingTexture",B._matricesTexture,Ie),Je.setOptional(U,B,"batchingIdTexture"),Je.setValue(U,"batchingIdTexture",B._indirectTexture,Ie),Je.setOptional(U,B,"batchingColorTexture"),B._colorsTexture!==null&&Je.setValue(U,"batchingColorTexture",B._colorsTexture,Ie));const wn=G.morphAttributes;if((wn.position!==void 0||wn.normal!==void 0||wn.color!==void 0)&&K.update(B,G,qt),(yi||Se.receiveShadow!==B.receiveShadow)&&(Se.receiveShadow=B.receiveShadow,Je.setValue(U,"receiveShadow",B.receiveShadow)),(O.isMeshStandardMaterial||O.isMeshLambertMaterial||O.isMeshPhongMaterial)&&O.envMap===null&&D.environment!==null&&(Bt.envMapIntensity.value=D.environmentIntensity),Bt.dfgLUT!==void 0&&(Bt.dfgLUT.value=yb()),yi){if(Je.setValue(U,"toneMappingExposure",R.toneMappingExposure),Se.needsLights&&Kf(Bt,Bi),ue&&O.fog===!0&&ae.refreshFogUniforms(Bt,ue),ae.refreshMaterialUniforms(Bt,O,xe,Ce,E.state.transmissionRenderTarget[M.id]),Se.needsLights&&Se.numLightProbeGrids>0){const gt=b;let Nt=0;for(const Qn of E.state.lightProbeGridArray)Qn.texture!==null&&(gt.textures[Nt]=Qn.texture,gt.min[Nt]=Qn.boundingBox.min,gt.max[Nt]=Qn.boundingBox.max,gt.resolution[Nt]=Qn.resolution,Nt++);for(const Qn in gt)gt[Qn].length=Nt;Bt.probesSH.value=gt.textures,Bt.probesMin.value=gt.min,Bt.probesMax.value=gt.max,Bt.probesResolution.value=gt.resolution}La.upload(U,th(Se),Bt,Ie)}if(O.isShaderMaterial&&O.uniformsNeedUpdate===!0&&(La.upload(U,th(Se),Bt,Ie),O.uniformsNeedUpdate=!1),O.isSpriteMaterial&&Je.setValue(U,"center",B.center),Je.setValue(U,"modelViewMatrix",B.modelViewMatrix),Je.setValue(U,"normalMatrix",B.normalMatrix),Je.setValue(U,"modelMatrix",B.matrixWorld),O.uniformsGroups!==void 0){const gt=O.uniformsGroups;for(let Nt=0,Qn=gt.length;Nt<Qn;Nt++){const sh=gt[Nt];Ae.update(sh,qt),Ae.bind(sh,qt)}}return qt}function Kf(M,D){M.ambientLightColor.needsUpdate=D,M.lightProbe.needsUpdate=D,M.sunLights.needsUpdate=D,M.sunLightShadows.needsUpdate=D,M.directionalLights.needsUpdate=D,M.directionalLightShadows.needsUpdate=D,M.pointLights.needsUpdate=D,M.pointLightShadows.needsUpdate=D,M.spotLights.needsUpdate=D,M.spotLightShadows.needsUpdate=D,M.rectAreaLights.needsUpdate=D,M.hemisphereLights.needsUpdate=D}function Jf(M){return M.isMeshLambertMaterial||M.isMeshToonMaterial||M.isMeshPhongMaterial||M.isMeshStandardMaterial||M.isShadowMaterial||M.isShaderMaterial&&M.lights===!0}this.getActiveCubeFace=function(){return J},this.getActiveMipmapLevel=function(){return z},this.getRenderTarget=function(){return ne},this.setRenderTargetTextures=function(M,D,G){const O=Pe.get(M);O.__autoAllocateDepthBuffer=M.resolveDepthBuffer===!1,O.__autoAllocateDepthBuffer===!1&&(O.__useRenderToTexture=!1),Pe.get(M.texture).__webglTexture=D,Pe.get(M.depthTexture).__webglTexture=O.__autoAllocateDepthBuffer?void 0:G,O.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(M,D){const G=Pe.get(M);G.__webglFramebuffer=D,G.__useDefaultFramebuffer=D===void 0},this.setRenderTarget=function(M,D=0,G=0){ne=M,J=D,z=G;let O=null,B=!1,ue=!1;if(M){const he=Pe.get(M);if(he.__useDefaultFramebuffer!==void 0){pe.bindFramebuffer(U.FRAMEBUFFER,he.__webglFramebuffer),ee.copy(M.viewport),we.copy(M.scissor),Ue=M.scissorTest,pe.viewport(ee),pe.scissor(we),pe.setScissorTest(Ue),$=-1;return}else if(he.__webglFramebuffer===void 0)Ie.setupRenderTarget(M);else if(he.__hasExternalTextures)Ie.rebindTextures(M,Pe.get(M.texture).__webglTexture,Pe.get(M.depthTexture).__webglTexture);else if(M.depthBuffer){const Fe=M.depthTexture;if(he.__boundDepthTexture!==Fe){if(Fe!==null&&Pe.has(Fe)&&(M.width!==Fe.image.width||M.height!==Fe.image.height))throw new Error("THREE.WebGLRenderer: Attached DepthTexture is initialized to the incorrect size.");Ie.setupDepthRenderbuffer(M)}}const ye=M.texture;(ye.isData3DTexture||ye.isDataArrayTexture||ye.isCompressedArrayTexture)&&(ue=!0);const Ee=Pe.get(M).__webglFramebuffer;M.isWebGLCubeRenderTarget?(Array.isArray(Ee[D])?O=Ee[D][G]:O=Ee[D],B=!0):M.samples>0&&Ie.useMultisampledRTT(M)===!1?O=Pe.get(M).__webglMultisampledFramebuffer:Array.isArray(Ee)?O=Ee[G]:O=Ee,ee.copy(M.viewport),we.copy(M.scissor),Ue=M.scissorTest}else ee.copy(De).multiplyScalar(xe).floor(),we.copy(nt).multiplyScalar(xe).floor(),Ue=ot;if(G!==0&&(O=V),pe.bindFramebuffer(U.FRAMEBUFFER,O)&&pe.drawBuffers(M,O),pe.viewport(ee),pe.scissor(we),pe.setScissorTest(Ue),B){const he=Pe.get(M.texture);U.framebufferTexture2D(U.FRAMEBUFFER,U.COLOR_ATTACHMENT0,U.TEXTURE_CUBE_MAP_POSITIVE_X+D,he.__webglTexture,G)}else if(ue){const he=D;for(let ye=0;ye<M.textures.length;ye++){const Ee=Pe.get(M.textures[ye]);U.framebufferTextureLayer(U.FRAMEBUFFER,U.COLOR_ATTACHMENT0+ye,Ee.__webglTexture,G,he)}}else if(M!==null&&G!==0){const he=Pe.get(M.texture);U.framebufferTexture2D(U.FRAMEBUFFER,U.COLOR_ATTACHMENT0,U.TEXTURE_2D,he.__webglTexture,G)}$=-1};function ih(M){const D=Pe.get(M);return(D.__readFormat!==M.format||D.__readType!==M.type)&&(D.__readFormat=M.format,D.__readType=M.type,D.__formatReadable=ft.textureFormatReadable(M.format),D.__typeReadable=ft.textureTypeReadable(M.type)),D}this.readRenderTargetPixels=function(M,D,G,O,B,ue,be,he=0){if(!(M&&M.isWebGLRenderTarget)){Ze("WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let ye=Pe.get(M).__webglFramebuffer;if(M.isWebGLCubeRenderTarget&&be!==void 0&&(ye=ye[be],Array.isArray(ye)&&(ye=ye[0])),ye){pe.bindFramebuffer(U.FRAMEBUFFER,ye);try{const Ee=M.textures[he],Fe=Ee.format,We=Ee.type;M.textures.length>1&&U.readBuffer(U.COLOR_ATTACHMENT0+he);const Me=ih(Ee);if(Me.__formatReadable===!1){Ze("WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(Me.__typeReadable===!1){Ze("WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}D>=0&&D<=M.width-O&&G>=0&&G<=M.height-B&&U.readPixels(D,G,O,B,se.convert(Fe),se.convert(We),ue)}finally{const Ee=ne!==null?Pe.get(ne).__webglFramebuffer:null;pe.bindFramebuffer(U.FRAMEBUFFER,Ee)}}},this.readRenderTargetPixelsAsync=async function(M,D,G,O,B,ue,be,he=0){if(!(M&&M.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let ye=Pe.get(M).__webglFramebuffer;if(M.isWebGLCubeRenderTarget&&be!==void 0&&(ye=ye[be],Array.isArray(ye)&&(ye=ye[0])),ye)if(D>=0&&D<=M.width-O&&G>=0&&G<=M.height-B){pe.bindFramebuffer(U.FRAMEBUFFER,ye);const Ee=M.textures[he],Fe=Ee.format,We=Ee.type;M.textures.length>1&&U.readBuffer(U.COLOR_ATTACHMENT0+he);const Me=ih(Ee);if(Me.__formatReadable===!1)throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(Me.__typeReadable===!1)throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");const $e=U.createBuffer();U.bindBuffer(U.PIXEL_PACK_BUFFER,$e),U.bufferData(U.PIXEL_PACK_BUFFER,ue.byteLength,U.STREAM_READ),U.readPixels(D,G,O,B,se.convert(Fe),se.convert(We),0),U.bindBuffer(U.PIXEL_PACK_BUFFER,null);const Mt=ne!==null?Pe.get(ne).__webglFramebuffer:null;pe.bindFramebuffer(U.FRAMEBUFFER,Mt);const ct=U.fenceSync(U.SYNC_GPU_COMMANDS_COMPLETE,0);return U.flush(),await Jp(U,ct,4),U.bindBuffer(U.PIXEL_PACK_BUFFER,$e),U.getBufferSubData(U.PIXEL_PACK_BUFFER,0,ue),U.bindBuffer(U.PIXEL_PACK_BUFFER,null),U.deleteBuffer($e),U.deleteSync(ct),ue}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")},this.copyFramebufferToTexture=function(M,D=null,G=0){const O=Math.pow(2,-G),B=Math.floor(M.image.width*O),ue=Math.floor(M.image.height*O),be=D!==null?D.x:0,he=D!==null?D.y:0;Ie.setTexture2D(M,0),U.copyTexSubImage2D(U.TEXTURE_2D,G,0,0,be,he,B,ue),pe.unbindTexture()},this.copyTextureToTexture=function(M,D,G=null,O=null,B=0,ue=0){let be,he,ye,Ee,Fe,We,Me,$e,Mt;const ct=M.isCompressedTexture?M.mipmaps[ue]:M.image;if(G!==null)be=G.max.x-G.min.x,he=G.max.y-G.min.y,ye=G.isBox3?G.max.z-G.min.z:1,Ee=G.min.x,Fe=G.min.y,We=G.isBox3?G.min.z:0;else{const Je=Math.pow(2,-B);be=Math.floor(ct.width*Je),he=Math.floor(ct.height*Je),M.isDataArrayTexture?ye=ct.depth:M.isData3DTexture?ye=Math.floor(ct.depth*Je):ye=1,Ee=0,Fe=0,We=0}O!==null?(Me=O.x,$e=O.y,Mt=O.z):(Me=0,$e=0,Mt=0);const lt=se.convert(D.format),$t=se.convert(D.type);let Se;D.isData3DTexture?(Ie.setTexture3D(D,0),Se=U.TEXTURE_3D):D.isDataArrayTexture||D.isCompressedArrayTexture?(Ie.setTexture2DArray(D,0),Se=U.TEXTURE_2D_ARRAY):(Ie.setTexture2D(D,0),Se=U.TEXTURE_2D),pe.activeTexture(U.TEXTURE0),pe.pixelStorei(U.UNPACK_FLIP_Y_WEBGL,D.flipY),pe.pixelStorei(U.UNPACK_PREMULTIPLY_ALPHA_WEBGL,D.premultiplyAlpha),pe.pixelStorei(U.UNPACK_ALIGNMENT,D.unpackAlignment);const Qt=pe.getParameter(U.UNPACK_ROW_LENGTH),et=pe.getParameter(U.UNPACK_IMAGE_HEIGHT),ki=pe.getParameter(U.UNPACK_SKIP_PIXELS),qt=pe.getParameter(U.UNPACK_SKIP_ROWS),Ur=pe.getParameter(U.UNPACK_SKIP_IMAGES);pe.pixelStorei(U.UNPACK_ROW_LENGTH,ct.width),pe.pixelStorei(U.UNPACK_IMAGE_HEIGHT,ct.height),pe.pixelStorei(U.UNPACK_SKIP_PIXELS,Ee),pe.pixelStorei(U.UNPACK_SKIP_ROWS,Fe),pe.pixelStorei(U.UNPACK_SKIP_IMAGES,We);const yi=M.isDataArrayTexture||M.isData3DTexture,Bi=D.isDataArrayTexture||D.isData3DTexture;if(M.isDepthTexture){const Je=Pe.get(M),Bt=Pe.get(D),wn=Pe.get(Je.__renderTarget),gt=Pe.get(Bt.__renderTarget);pe.bindFramebuffer(U.READ_FRAMEBUFFER,wn.__webglFramebuffer),pe.bindFramebuffer(U.DRAW_FRAMEBUFFER,gt.__webglFramebuffer);for(let Nt=0;Nt<ye;Nt++)yi&&(U.framebufferTextureLayer(U.READ_FRAMEBUFFER,U.COLOR_ATTACHMENT0,Pe.get(M).__webglTexture,B,We+Nt),U.framebufferTextureLayer(U.DRAW_FRAMEBUFFER,U.COLOR_ATTACHMENT0,Pe.get(D).__webglTexture,ue,Mt+Nt)),U.blitFramebuffer(Ee,Fe,Ee+be,Fe+he,Me,$e,Me+be,$e+he,U.DEPTH_BUFFER_BIT,U.NEAREST);pe.bindFramebuffer(U.READ_FRAMEBUFFER,null),pe.bindFramebuffer(U.DRAW_FRAMEBUFFER,null)}else if(B!==0||M.isRenderTargetTexture||Pe.has(M)){const Je=Pe.get(M),Bt=Pe.get(D);pe.bindFramebuffer(U.READ_FRAMEBUFFER,I),pe.bindFramebuffer(U.DRAW_FRAMEBUFFER,H);for(let wn=0;wn<ye;wn++)yi?U.framebufferTextureLayer(U.READ_FRAMEBUFFER,U.COLOR_ATTACHMENT0,Je.__webglTexture,B,We+wn):U.framebufferTexture2D(U.READ_FRAMEBUFFER,U.COLOR_ATTACHMENT0,U.TEXTURE_2D,Je.__webglTexture,B),Bi?U.framebufferTextureLayer(U.DRAW_FRAMEBUFFER,U.COLOR_ATTACHMENT0,Bt.__webglTexture,ue,Mt+wn):U.framebufferTexture2D(U.DRAW_FRAMEBUFFER,U.COLOR_ATTACHMENT0,U.TEXTURE_2D,Bt.__webglTexture,ue),B!==0?U.blitFramebuffer(Ee,Fe,Ee+be,Fe+he,Me,$e,Me+be,$e+he,U.COLOR_BUFFER_BIT,U.NEAREST):Bi?U.copyTexSubImage3D(Se,ue,Me,$e,Mt+wn,Ee,Fe,be,he):U.copyTexSubImage2D(Se,ue,Me,$e,Ee,Fe,be,he);pe.bindFramebuffer(U.READ_FRAMEBUFFER,null),pe.bindFramebuffer(U.DRAW_FRAMEBUFFER,null)}else Bi?M.isDataTexture||M.isData3DTexture?U.texSubImage3D(Se,ue,Me,$e,Mt,be,he,ye,lt,$t,ct.data):D.isCompressedArrayTexture?U.compressedTexSubImage3D(Se,ue,Me,$e,Mt,be,he,ye,lt,ct.data):U.texSubImage3D(Se,ue,Me,$e,Mt,be,he,ye,lt,$t,ct):M.isDataTexture?U.texSubImage2D(U.TEXTURE_2D,ue,Me,$e,be,he,lt,$t,ct.data):M.isCompressedTexture?U.compressedTexSubImage2D(U.TEXTURE_2D,ue,Me,$e,ct.width,ct.height,lt,ct.data):U.texSubImage2D(U.TEXTURE_2D,ue,Me,$e,be,he,lt,$t,ct);pe.pixelStorei(U.UNPACK_ROW_LENGTH,Qt),pe.pixelStorei(U.UNPACK_IMAGE_HEIGHT,et),pe.pixelStorei(U.UNPACK_SKIP_PIXELS,ki),pe.pixelStorei(U.UNPACK_SKIP_ROWS,qt),pe.pixelStorei(U.UNPACK_SKIP_IMAGES,Ur),ue===0&&D.generateMipmaps===!0&&D.mipmapsAutoUpdate===!0&&U.generateMipmap(Se),pe.unbindTexture()},this.initRenderTarget=function(M){Pe.get(M).__webglFramebuffer===void 0&&Ie.setupRenderTarget(M)},this.initTexture=function(M){M.isCubeTexture?Ie.setTextureCube(M,0):M.isData3DTexture?Ie.setTexture3D(M,0):M.isDataArrayTexture||M.isCompressedArrayTexture?Ie.setTexture2DArray(M,0):Ie.setTexture2D(M,0),pe.unbindTexture()},this.resetState=function(){J=0,z=0,ne=null,pe.reset(),oe.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return In}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;const t=this.getContext();t.drawingBufferColorSpace=Xe._getDrawingBufferColorSpace(e),t.unpackColorSpace=Xe._getUnpackColorSpace()}}const Td={earth:{id:"earth",ground:["#4a8f3e","#5ea34a","#3a7a36","#6cad52"],base:"#5aa648",rim:"#c9b98c",rock:"#8a8478",sky:["#2f6fd0","#8fc3f2","#e8f2ff"],fog:"#cfe2f6",fogNear:90,fogFar:420,sun:"#fff1d6",sunI:2.4,amb:["#bcd8ff","#3b5a34",.75],sea:"#2a78b8",seaSide:1,hills:9,flora:"trees",clouds:"#ffffff",cloudN:26,stars:0}},Rt=ji/2;function _b(i){const e=ja(i),t=new Float32Array(256*256).map(()=>e()),n=(s,r)=>{const a=Math.floor(s),o=Math.floor(r),c=s-a,l=r-o,h=(f,g)=>t[(f&255)<<8|g&255],d=c*c*(3-2*c),u=l*l*(3-2*l);return(h(a,o)*(1-d)+h(a+1,o)*d)*(1-u)+(h(a,o+1)*(1-d)+h(a+1,o+1)*d)*u};return(s,r)=>n(s,r)*.55+n(s*2.1+7,r*2.1+3)*.3+n(s*4.3+1,r*4.3+9)*.15}class Mb{constructor(e,t,n){this.scene=e,this.quality=n,this.group=new yt,this.clouds=new yt,this.water=null,this.grid=null,this.bound=null,this.height=()=>0,this.look=Td[t]||Td.earth,this.sky=this.makeSky(),this.build()}makeSky(){const e=this.look,t=new sn(3e3,32,16),n=new fn({side:Gt,depthWrite:!1,fog:!1,uniforms:{top:{value:new Te(e.sky[0])},mid:{value:new Te(e.sky[1])},hor:{value:new Te(e.sky[2])},sunDir:{value:new P(-.55,.62,.42).normalize()},sunCol:{value:new Te(e.sun)},stars:{value:e.stars||0}},vertexShader:"varying vec3 vP; void main(){ vP = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }",fragmentShader:`uniform vec3 top, mid, hor, sunCol, sunDir; uniform float stars; varying vec3 vP;
        float h(vec3 p){ return fract(sin(dot(p, vec3(12.9898,78.233,37.719))) * 43758.5453); }
        void main(){ float y = vP.y; vec3 c = y > 0.18 ? mix(mid, top, smoothstep(0.18, 0.75, y)) : mix(hor, mid, smoothstep(-0.02, 0.18, y));
          float sd = max(dot(vP, sunDir), 0.0); c += sunCol * (pow(sd, 900.0) * 3.0 + pow(sd, 18.0) * 0.18);
          if (stars > 0.0) { vec3 q = floor(vP * 420.0); float s = step(0.9975, h(q)); c += vec3(s) * stars * smoothstep(0.0, 0.2, y); }
          gl_FragColor = vec4(c, 1.0); }`}),s=new je(t,n);return s.renderOrder=-10,s.frustumCulled=!1,this.scene.add(s),s}build(){const e=this.look,t=_b(77),n=ja(5),s=520,r=this.quality==="high"?200:140,a=(v,p)=>e.seaSide?(v+p)/Math.SQRT2:99999;this.height=(v,p)=>{const m=Math.max(Math.abs(v),Math.abs(p)),x=qi.smoothstep(m,Rt+4,Rt+30);let S=x*(t(v*.018,p*.018)*e.hills*2.2+t(v*.06,p*.06)*2.2-1.2)+x*Math.max(0,m-90)*.06;if(e.seaSide){const b=a(v,p);S=Math.min(S,qi.lerp(-6,S,qi.smoothstep(b,-Rt-34,-Rt-12)))}return S};const o=new pi(s,s,r,r);o.rotateX(-Math.PI/2);const c=o.attributes.position,l=new Float32Array(c.count*3),h=new Te,d=e.ground.map(v=>new Te(v)),u=new Te(e.base),f=new Te(e.rim);new Te(e.rock);for(let v=0;v<c.count;v++){const p=c.getX(v),m=c.getZ(v),x=this.height(p,m);c.setY(v,x);const S=Math.max(Math.abs(p),Math.abs(m)),b=t(p*.09+3,m*.09);if(h.copy(d[0]).lerp(d[1],b).lerp(d[2],t(p*.03,m*.03+5)*.8),S<Rt+2){h.lerp(u,.6);const A=Math.floor((p+m+400)/2)%2;h.offsetHSL(0,0,A?.025:-.015)}if(e.seaSide){const A=a(p,m);A<-Rt-8&&x<1.2&&h.lerp(f,qi.smoothstep(-A,Rt+8,Rt+16)*qi.smoothstep(-x,-1.2,.2))}l.set([h.r,h.g,h.b],v*3)}o.setAttribute("color",new Zt(l,3)),o.computeVertexNormals();const g=new je(o,new Qi({vertexColors:!0,roughness:.95,metalness:0,flatShading:!0}));if(g.receiveShadow=!0,g.name="ground",this.group.add(g),e.sea){const v=new je(new pi(2400,2400),new fn({transparent:!0,fog:!0,uniforms:{t:{value:0},col:{value:new Te(e.sea)},deep:{value:new Te(e.sea).multiplyScalar(.5)},sky:{value:new Te(e.sky[2])},sunDir:{value:new P(-.55,.62,.42).normalize()},...me.fog},vertexShader:`#include <fog_pars_vertex>
varying vec3 vW; void main(){ vec4 w = modelMatrix * vec4(position,1.0); vW = w.xyz; vec4 mvPosition = viewMatrix * w; gl_Position = projectionMatrix * mvPosition;
#include <fog_vertex>
}`,fragmentShader:`#include <fog_pars_fragment>
          uniform float t; uniform vec3 col, deep, sky, sunDir; varying vec3 vW;
          void main(){ vec2 q = vW.xz * 0.15; float w = sin(q.x * 3.1 + t * 1.3) * 0.5 + sin(q.y * 2.3 - t * 1.1 + q.x) * 0.5 + sin((q.x + q.y) * 5.0 + t * 2.0) * 0.25;
            vec3 n = normalize(vec3(cos(q.x * 3.1 + t) * 0.08, 1.0, cos(q.y * 2.3 - t) * 0.08 + w * 0.03)); vec3 v = normalize(cameraPosition - vW);
            float fr = pow(1.0 - max(dot(n, v), 0.0), 3.0); vec3 c = mix(deep, col, 0.6 + 0.2 * w); c = mix(c, sky, fr * 0.7);
            vec3 h = normalize(sunDir + v); c += vec3(1.0, 0.95, 0.85) * pow(max(dot(n, h), 0.0), 220.0) * 1.8;
            gl_FragColor = vec4(c, 0.94);
          #include <fog_fragment>
          }`}));v.rotation.x=-Math.PI/2,v.position.y=-.4,this.water=v,this.group.add(v)}if(e.flora==="trees"){const v=[],p=new vi;for(let b=0;b<(this.quality==="high"?1400:700);b++){const A=(n()-.5)*360,E=(n()-.5)*360;if(Math.max(Math.abs(A),Math.abs(E))<Rt+5)continue;const w=this.height(A,E);if(w<.5||w>e.hills*2||t(A*.05+9,E*.05)<.42)continue;const L=.7+n()*.9;p.setFromEuler(new On(0,n()*6,0)),v.push(new Ke().compose(new P(A,w,E),p,new P(L,L*(.9+n()*.5),L)))}const m=new fi(.1,.14,.8,5);m.translate(0,.4,0);const x=new Xn(.75,1.9,7);x.translate(0,1.6,0);const S=new Xn(.55,1.3,7);S.translate(0,2.4,0);for(const[b,A]of[[m,"#6b4a2e"],[x,"#2f6b34"],[S,"#3a7d3c"]]){const E=new Ol(b,new Qi({color:A,flatShading:!0,roughness:.9}),v.length);v.forEach((y,w)=>E.setMatrixAt(w,y)),E.castShadow=A!=="#6b4a2e",E.receiveShadow=!0,this.group.add(E)}}if(e.clouds){const v=Sb();for(let p=0;p<(e.cloudN||0);p++){const m=new Bu(new Ac({map:v,color:e.clouds,transparent:!0,opacity:.75,depthWrite:!1,fog:!1})),x=n()*Math.PI*2,S=120+n()*900;m.position.set(Math.cos(x)*S,60+n()*70,Math.sin(x)*S);const b=60+n()*110;m.scale.set(b,b*.38,1),m.userData.v=.6+n()*1.2,this.clouds.add(m)}this.group.add(this.clouds)}this.scene.add(this.group)}setArea(e,t){this.grid&&(this.group.remove(this.grid),this.grid.geometry.dispose()),this.bound&&(this.group.remove(this.bound),this.bound.geometry.dispose());const n=[];for(let u=e;u<=t;u++)n.push(u-Rt,.03,e-Rt,u-Rt,.03,t-Rt,e-Rt,.03,u-Rt,t-Rt,.03,u-Rt);const s=new pt;s.setAttribute("position",new He(n,3)),this.grid=new Om(s,new Gu({color:"#ffffff",transparent:!0,opacity:.22})),this.grid.visible=!1,this.group.add(this.grid);const r=t-e;new Lr(0,1,4,1).dispose();const o=new Ku,c=r/2+.25,l=r/2;o.moveTo(-c,-c),o.lineTo(c,-c),o.lineTo(c,c),o.lineTo(-c,c),o.lineTo(-c,-c);const h=new zl;h.moveTo(-l,-l),h.lineTo(-l,l),h.lineTo(l,l),h.lineTo(l,-l),h.lineTo(-l,-l),o.holes.push(h);const d=new Ic(o);d.rotateX(-Math.PI/2),this.bound=new je(d,new Ht({color:"#f4e7b8",transparent:!0,opacity:.55,depthWrite:!1})),this.bound.position.set((e+t)/2-Rt,.04,(e+t)/2-Rt),this.group.add(this.bound)}showGrid(e){this.grid&&(this.grid.visible=e)}update(e,t){this.water&&(this.water.material.uniforms.t.value=e);for(const n of this.clouds.children)n.position.x+=n.userData.v*t,n.position.x>1e3&&(n.position.x=-1e3)}dispose(){this.scene.remove(this.group),this.scene.remove(this.sky)}}let Zs=null;function Sb(){if(Zs)return Zs;const i=document.createElement("canvas");i.width=128,i.height=64;const e=i.getContext("2d"),t=ja(3);for(let n=0;n<14;n++){const s=20+t()*88,r=22+t()*22,a=10+t()*18,o=e.createRadialGradient(s,r,0,s,r,a);o.addColorStop(0,"rgba(255,255,255,0.9)"),o.addColorStop(1,"rgba(255,255,255,0)"),e.fillStyle=o,e.beginPath(),e.arc(s,r,a,0,7),e.fill()}return Zs=new io(i),Zs.colorSpace=Ft,Zs}function wb(i,e=!1){const t=i[0].index!==null,n=new Set(Object.keys(i[0].attributes)),s=new Set(Object.keys(i[0].morphAttributes)),r={},a={},o=i[0].morphTargetsRelative,c=new pt;c.morphTargetsRelative=o;let l=0;for(let h=0;h<i.length;++h){const d=i[h];let u=0,f=0;if(t!==(d.index!==null))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". All geometries must have compatible attributes; make sure index attribute exists among all geometries, or in none of them."),null;for(const g in d.attributes){if(!n.has(g))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+'. All geometries must have compatible attributes; make sure "'+g+'" attribute exists among all geometries, or in none of them.'),null;r[g]===void 0&&(r[g]=[]),r[g].push(d.attributes[g]),u++}if(u!==n.size)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". Make sure all geometries have the same number of attributes."),null;if(o!==d.morphTargetsRelative)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". .morphTargetsRelative must be consistent throughout all geometries."),null;for(const g in d.morphAttributes){if(!s.has(g))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+".  .morphAttributes must be consistent throughout all geometries."),null;if(d.morphAttributes[g].length!==i[0].morphAttributes[g].length)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+'. All geometries must have the same number of morph targets for the "'+g+'" morph attribute.'),null;a[g]===void 0&&(a[g]=[]),a[g].push(d.morphAttributes[g]),f++}if(f!==s.size)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". Make sure all geometries have the same number of morph attributes."),null;if(e){let g;if(t)g=d.index.count;else if(d.attributes.position!==void 0)g=d.attributes.position.count;else return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". The geometry must have either an index or a position attribute"),null;c.addGroup(l,g,h),l+=g}}if(t){let h=0;const d=[];for(let u=0;u<i.length;++u){const f=i[u].index;for(let g=0;g<f.count;++g)d.push(f.getX(g)+h);h+=i[u].attributes.position.count}c.setIndex(d)}for(const h in r){const d=Rd(r[h]);if(!d)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+h+" attribute."),null;c.setAttribute(h,d)}for(const h in a){const d=a[h][0].length;if(d!==0){c.morphAttributes=c.morphAttributes||{},c.morphAttributes[h]=[];for(let u=0;u<d;++u){const f=[];for(let v=0;v<a[h].length;++v)f.push(a[h][v][u]);const g=Rd(f);if(!g)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+h+" morphAttribute."),null;c.morphAttributes[h].push(g)}}}return c}function Rd(i){let e,t,n,s=-1,r=0;for(let l=0;l<i.length;++l){const h=i[l];if(e===void 0&&(e=h.array.constructor),e!==h.array.constructor)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.array must be of consistent array types across matching attributes."),null;if(t===void 0&&(t=h.itemSize),t!==h.itemSize)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.itemSize must be consistent across matching attributes."),null;if(n===void 0&&(n=h.normalized),n!==h.normalized)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.normalized must be consistent across matching attributes."),null;if(s===-1&&(s=h.gpuType),s!==h.gpuType)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.gpuType must be consistent across matching attributes."),null;r+=h.count*t}const a=new e(r),o=new Zt(a,t,n);let c=0;for(let l=0;l<i.length;++l){const h=i[l];if(h.isInterleavedBufferAttribute){const d=c/t;for(let u=0,f=h.count;u<f;u++)for(let g=0;g<t;g++){const v=h.getComponent(u,g);o.setComponent(u+d,g,v)}}else a.set(h.array,c);c+=h.count*t}return s!==void 0&&(o.gpuType=s),o}const va=new Te,Da={body:new Qi({vertexColors:!0,flatShading:!0,roughness:.62,metalness:.12}),glow:new Ht({vertexColors:!0,toneMapped:!1}),glass:new Qi({vertexColors:!0,transparent:!0,opacity:.38,roughness:.08,metalness:.2,depthWrite:!1}),ghostOk:new Ht({color:6160282,transparent:!0,opacity:.45,depthWrite:!1}),ghostBad:new Ht({color:16734826,transparent:!0,opacity:.45,depthWrite:!1})};class Qe{constructor(){this.parts={body:[],glow:[],glass:[]}}add(e,t,n=0,s=0,r=0,a={}){let o=e.index?e.toNonIndexed():e.clone();o.attributes.uv&&o.deleteAttribute("uv"),o.attributes.uv1&&o.deleteAttribute("uv1");const c=new Ke().compose(new P(n,s,r),new vi().setFromEuler(new On(a.rx||0,a.ry||0,a.rz||0)),new P(a.sx??1,a.sy??1,a.sz??1));o.applyMatrix4(c),va.set(t);const l=o.attributes.position.count,h=new Float32Array(l*3);for(let d=0;d<l;d++)h[d*3]=va.r,h[d*3+1]=va.g,h[d*3+2]=va.b;return o.setAttribute("color",new Zt(h,3)),this.parts[a.glow?"glow":a.glass?"glass":"body"].push(o),e.dispose(),this}box(e,t,n,s,r=0,a=0,o=0,c={}){return this.add(new is(e,t,n),s,r,a+t/2,o,c)}cyl(e,t,n,s,r,a=0,o=0,c=0,l={}){return this.add(new fi(e,t,n,s),r,a,o+n/2,c,l)}sphere(e,t,n=0,s=0,r=0,a={}){return this.add(new sn(e,a.w||10,a.h||7,0,Math.PI*2,0,a.theta||Math.PI),t,n,s,r,a)}build(e=""){const t=new yt;t.name=e;for(const n of["body","glow","glass"]){const s=this.parts[n];if(!s.length)continue;const r=wb(s,!1);if(s.forEach(o=>o.dispose()),!r)continue;const a=new je(r,Da[n]);a.castShadow=n==="body",a.receiveShadow=n==="body",a.userData.bucket=n,t.add(a)}return t}}const Un=(i,e)=>{const t=new Te(i);return e<0?t.lerp(new Te(0),-e):t.lerp(new Te(16777215),e),"#"+t.getHexString()},Eb="#cfd3d8",wr="#3b4350",Kt="#aeb8c4",gf="#ffe7a8",ql="#9fd3ff",Wt=i=>Math.min(6,1+Math.floor((Math.max(1,i)-1)/4));function Ot(i,e,t,n=Eb){i.box(e-.08,.1,t-.08,n),i.box(e-.08,.03,.06,"#f2d36b",0,.1,t/2-.1)}function Vt(i,e,t,n,s,r=0,a=0){i.box(e+.05,s,t+.05,gf,r,n,a,{glow:!0});for(let o=-e/2+.35;o<e/2-.2;o+=.42)i.box(.07,s+.02,t+.07,"#5b6676",r+o,n-.01,a)}function Ab(i,e){const t=new Qe,n=Wt(i),s=e.primary,r=e.accent;Ot(t,5,5);const a=.95+n*.12;t.box(3.3,a,2.3,s,.55,.1,.55),Vt(t,3.3,2.3,.4,.3,.55,.55),t.box(3.36,.1,2.36,r,.55,.1+a,.55),t.box(3,a-.15,.06,ql,.55,.15,-.62,{glass:!0});for(let p=-.8;p<=1.9;p+=.45)t.box(.05,a-.15,.08,Un(s,-.3),p,.15,-.62);for(let p=1;p<Math.min(n,4);p++){const m=3-p*.5,x=2-p*.3,S=.2+a+(p-1)*.62;t.box(m,.55,x,p%2?Un(s,-.05):s,.85,S,.75),Vt(t,m,x,S+.18,.2,.85,.75),t.box(m+.05,.06,x+.05,r,.85,S+.55,.75)}t.box(.5,.3,.4,"#9aa3ad",1.6,.2+a,1.2),t.box(.4,.25,.4,"#9aa3ad",1.1,.2+a,1.4);const o=2+n*.45,c=-1.35,l=-1.15;t.cyl(.42,.5,o,8,Un(s,-.04),c,.1,l);for(let p=.6;p<o-.3;p+=.55)t.cyl(.43,.43,.05,8,r,c,.1+p,l);t.cyl(.8,.55,.22,10,s,c,.1+o,l),t.cyl(.78,.78,.42,10,ql,c,.32+o,l,{glass:!0}),t.cyl(.7,.7,.36,10,gf,c,.35+o,l,{glow:!0}),t.cyl(.86,.86,.1,10,r,c,.74+o,l),t.cyl(.55,.8,.14,10,s,c,.84+o,l),t.cyl(.03,.03,.9,5,Kt,c,.98+o,l),t.sphere(.06,"#ff4f4f",c,1.9+o,l,{glow:!0});const h=t.build("hq"),d=new yt;{const p=new Qe;p.add(new sn(.6+n*.05,16,8,0,Math.PI*2,0,Math.PI/3.2),"#eef2f6",0,0,0,{rx:Math.PI}),p.cyl(.02,.02,.5,4,Kt,0,-.55,0),p.sphere(.05,r,0,-.8,0);const m=p.build();m.rotation.x=-.9,d.add(m)}const u=new Qe;u.cyl(.1,.16,.45,8,Kt,0,0,0);const f=u.build();f.position.set(.1,.2+a,.3),h.add(f),d.position.set(.1,.75+a,.3),h.add(d);const g=new Qe;g.cyl(.03,.035,2.4,5,Kt,2.15,.1,-2.05),h.add(g.build());const v=new je(new pi(.75,.48),new Qi({map:Xb(e.banner),side:bn,roughness:.8}));return v.position.set(2.53,2.25,-2.05),h.add(v),{group:h,height:o+1.4,anim:p=>{d.rotation.y=p*.25,v.rotation.y=Math.sin(p*2)*.15}}}function Tb(i,e){const t=new Qe,n=Wt(i),s=e.primary,r=e.accent;Ot(t,4,4);const a=.9+n*.18;t.box(2.6,a,2,s,-.5,.1,.5),Vt(t,2.6,2,.4,.26,-.5,.5),t.box(2.65,.08,2.05,r,-.5,.1+a,.5);for(let o=0;o<Math.min(3,1+Math.floor(n/2));o++){const l=-1+o*1;t.cyl(.42,.42,.45,12,"#e9edf2",1.1,.1,l),t.sphere(.42,"#f6f8fb",1.1,.55,l,{theta:Math.PI/2,w:14}),t.box(.12,.3,.5,wr,1.1,.7,l,{ry:.6})}return t.cyl(.32,.32,3,10,Kt,-.6,.45,-1.35,{rz:Math.PI/2}),t.cyl(.36,.36,.2,10,r,-2,.45,-1.35,{rz:Math.PI/2}),n>=3&&(t.box(1.2,.8,1,Un(s,-.08),-.9,.1+a,.6),Vt(t,1.2,1,.25+a,.2,-.9,.6)),{group:t.build("research"),height:a+1.2}}function Rb(i,e){const t=new Qe,n=Wt(i),s="#e8dcc6",r=e.accent;Ot(t,4,4,"#7fae5a"),t.box(3.2,.9,1.3,s,0,.1,-1.1),t.box(3.3,.18,1.4,"#a8452f",0,1,-1.1);for(let o=-3;o<=3;o++)t.cyl(.06,.06,.8,6,"#f6f1e6",o*.45,.1,-.4);t.box(3.4,.08,.3,"#f6f1e6",0,.9,-.42),t.box(1,.9,2.2,s,-1.2,.1,.7),t.box(1.1,.16,2.3,"#a8452f",-1.2,1,.7),Vt(t,1,2.2,.45,.2,-1.2,.7),Vt(t,3.2,1.3,.45,.2,0,-1.1);const a=1.6+n*.25;t.box(.6,a,.6,s,1.2,.1,.9),t.box(.7,.1,.7,r,1.2,.1+a,.9),t.cyl(0,.42,.6,4,"#a8452f",1.2,.2+a,.9,{ry:Math.PI/4}),t.cyl(.18,.18,.05,12,"#fff8dc",1.2,a-.35,1.21,{rx:Math.PI/2,glow:!0});for(let o=0;o<3;o++)t.cyl(.05,.07,.35,5,"#6b4a2e",.1+o*.5,.1,.9),t.sphere(.25,"#3f8a3a",.1+o*.5,.6,.9);return{group:t.build("university"),height:a+.9}}function Cb(i,e){const t=new Qe,n=Wt(i),s=e.accent;Ot(t,3,3,"#8e8170");for(let a=0;a<3;a++){const o=2-a*.55;t.box(o,.06,o,a%2?"#6e6152":"#7d6f5e",-.25,.1-a*.05,-.25)}t.box(.7,.04,.7,"#4a4036",-.25,-.02,-.25);const r=1.4+n*.2;for(const[a,o]of[[.75,.55],[1.15,.55],[.75,.95],[1.15,.95]])t.box(.07,r,.07,"#c0392b",a,.1,o);return t.box(.55,.08,.55,"#c0392b",.95,.1+r,.75),t.cyl(.16,.16,.06,10,wr,.95,.15+r,.75,{rx:Math.PI/2}),t.box(.18,.12,1.5,wr,.2,.45,.9,{rx:-.35}),t.add(new Xn(.45,.5,7),"#9aa3ad",-.9,.35,.95),t.box(.6,.35,.4,s,-.95,.1,-1),t.box(.3,.25,.4,"#f5c542",-.55,.1,-1),n>=3&&(t.box(.9,.7,.6,"#d8d2c6",.9,.1,-.9),Vt(t,.9,.6,.35,.16,.9,-.9)),{group:t.build("mine"),height:r+.5}}function Pb(i,e){const t=new Qe,n=Wt(i),s=e.accent;Ot(t,3,3);const r=Math.min(4,1+Math.floor(n/2));for(let l=0;l<r;l++){const h=1.6+n*.2-l*.2,d=-.9+l*.55;t.cyl(.18,.2,h,10,"#e4e7eb",d,.1,-.8);for(let u=1;u<4;u++)t.cyl(.21,.21,.05,10,s,d,.1+h*u/4,-.8)}t.sphere(.45,"#f1f3f5",.6,.6,.6,{w:14,h:9}),t.cyl(.05,.05,.4,5,Kt,.6,.1,.6),n>=2&&t.sphere(.36,"#f1f3f5",-.5,.5,.75,{w:12,h:8}),t.box(2.2,.08,.08,Kt,0,.45,0),t.box(.08,.08,1.5,Kt,.1,.35,0);const a=1.9+n*.25;t.cyl(.05,.07,a,6,wr,1.15,.1,-1.1);const o=t.build("refinery"),c=new je(new Xn(.1,.4,8),new Ht({color:"#ffb347",toneMapped:!1}));return c.position.set(1.15,.1+a+.2,-1.1),o.add(c),{group:o,height:a+.6,anim:(l,h)=>{c.visible=h.working,c.scale.set(1,.8+Math.sin(l*13)*.25+Math.sin(l*7.3)*.15,1)}}}function Lb(i,e){const t=new Qe,n=Wt(i),s=e.primary,r=e.accent;Ot(t,3,3);const a=1.2+n*.55;t.box(1.7,a,1.5,ql,-.2,.1,-.2,{glass:!0}),t.box(1.6,a-.05,1.4,"#5d7da0",-.2,.1,-.2);for(let o=.4;o<a;o+=.42)t.box(1.72,.05,1.52,r,-.2,.1+o,-.2);return t.box(1.8,.12,1.6,s,-.2,.1+a,-.2),Vt(t,1.62,1.42,.3,a-.5,-.2,-.2),t.box(1,.6,.9,s,.6,.1,.8),Vt(t,1,.9,.25,.18,.6,.8),t.box(.5,.05,.25,"#ffd166",.6,.72,1.26,{glow:!0}),{group:t.build("office"),height:a+.4}}function Db(i){const e=new Qe,t=Wt(i);Ot(e,3,3,"#a5b07f");const n=Math.min(4,2+Math.floor(t/2)),s=t>=4?3:2;for(let r=0;r<n;r++)for(let a=0;a<s;a++){const o=-.95+a*(1.9/Math.max(1,s-1))*(s>1?1:0),c=-1+r*2/Math.max(1,n-1);e.box(.05,.3,.05,Kt,o,.1,c),e.box(s>2?.8:1.1,.04,.45,"#1d3c78",o,.42,c,{rx:-.5}),e.box(s>2?.82:1.12,.02,.47,"#4f7fd6",o,.445,c+.01,{rx:-.5})}return e.box(.35,.3,.3,"#e8eaee",1.2,.1,1.2),{group:e.build("solar"),height:.9}}function Ib(i,e){const t=new Qe,n=Wt(i),s=e.accent;Ot(t,4,4);const r=[];for(let l=0;l<=12;l++){const h=l/12;r.push(new fe(.95-Math.sin(h*Math.PI*.85)*.38+h*.05,h*(2.2+n*.2)))}t.add(new so(r,18),"#d9dde2",-.6,.1,-.5),t.cyl(.62,.62,.05,18,s,-.6,1.5+n*.15,-.5),t.cyl(.6,.6,.9,16,"#eef0f3",1,.1,.8),t.sphere(.6,"#eef0f3",1,1,.8,{theta:Math.PI/2,w:16}),t.box(1.2,.6,.8,"#c9cdd3",.9,.1,-.6),Vt(t,1.2,.8,.3,.14,.9,-.6);const a=t.build("fission"),o=new yt,c=new Ht({color:"#ffffff",transparent:!0,opacity:.5,depthWrite:!1});for(let l=0;l<5;l++){const h=new je(new Pr(.4,1),c);h.userData.o=l/5,o.add(h)}return o.position.set(-.6,2.3+n*.2,-.5),a.add(o),{group:a,height:3+n*.2,anim:(l,h)=>{o.visible=h.working,o.children.forEach(d=>{const u=(l*.25+d.userData.o)%1;d.position.set(Math.sin(u*7)*.2,u*2.2,u*.6),d.scale.setScalar(.6+u*1.6)}),c.opacity=.45}}}function Nb(i,e){const t=new Qe,n=Wt(i),s=e.primary,r=e.accent;Ot(t,3,3);const a=Math.min(2,1+Math.floor(n/3));for(let c=0;c<a;c++){const l=-.7+c*.95;t.box(1.7,.55,.8,s,-.4,.1,l),t.add(new fi(.4,.4,1.7,12,1,!1,0,Math.PI),Un(s,-.12),-.4,.65,l,{rz:Math.PI/2,sz:1}),t.box(.5,.4,.04,r,-1.26,.1,l)}const o=Math.min(3,1+Math.floor(n/2));for(let c=0;c<o;c++){const l=-.9+c*.8;t.cyl(.32,.32,.8+n*.1,12,"#eceff2",1.05,.1,l),t.cyl(.33,.33,.05,12,r,1.05,.5,l)}for(let c=0;c<3;c++)t.box(.25,.25,.25,["#c98b3a","#5b8bd6","#c94a4a"][c],-.9+c*.32,.1,1.15);return{group:t.build("depot"),height:1.3}}function Ub(i,e){const t=new Qe,n=Wt(i),s=e.accent;Ot(t,6,6,"#bfc4ca"),t.box(2.4,.3,2.4,"#9aa1a9",0,.1,0),t.box(.9,.05,2.6,"#2b2f36",0,.38,0),t.box(.95,.12,.6,"#2b2f36",0,.05,2.6);const r=2.6+n*.6;for(const[a,o]of[[-1.7,-.55],[-1.7,.55],[-2.5,-.55],[-2.5,.55]])t.box(.08,r,.08,"#c0392b",a,.1,o);for(let a=.6;a<r;a+=.55)t.box(.9,.05,1.18,"#c0392b",-2.1,.1+a,0);t.box(1,.12,1.2,"#7d838c",-2.1,.1+r,0),t.box(.7,.06,.1,Kt,-1.4,.1+r*.75,0);for(const[a,o]of[[2.5,2.5],[-2.5,2.5],[2.5,-2.5]])t.cyl(.04,.06,r+1.2,5,Kt,a,.1,o),t.sphere(.06,"#ff4f4f",a,r+1.35,o,{glow:!0});return t.cyl(.35,.35,.5,10,"#e9edf2",2.3,1.6,-2.2),t.box(.06,1.5,.06,Kt,2.1,.1,-2),t.box(.06,1.5,.06,Kt,2.5,.1,-2.4),t.box(1.2,.5,.8,s,2,.1,.4),Vt(t,1.2,.8,.25,.12,2,.4),{group:t.build("launch"),height:r+1.6}}function Fb(i,e){const t=new Qe,n=Wt(i),s="#e6e9ed",r=e.accent;Ot(t,4,5);const a=2.6+n*.55;t.box(3.4,a,4.2,s,0,.1,0),t.box(3.45,.14,4.25,Un(s,-.15),0,.1+a,0),t.box(1.3,a-.3,.04,"#9aa3ad",0,.1,2.11);for(let o=.5;o<a-.3;o+=.45)t.box(1.32,.03,.05,"#7c858f",0,.1+o,2.12);return t.box(.05,a*.7,1.4,e.banner.bg,1.71,.1+a*.2,-.6),t.box(.06,a*.12,1.4,r,1.72,.1+a*.5,-.6),t.box(1.2,.7,1.6,Un(s,-.05),-2.25,.1,1.2),Vt(t,1.2,1.6,.3,.14,-2.25,1.2),{group:t.build("vab"),height:a+.4}}function Ob(i,e){const t=new Qe,n=Wt(i);Ot(t,4,4),t.box(1.1,.6,.9,"#d9dde2",1.2,.1,1.3),Vt(t,1.1,.9,.3,.12,1.2,1.3);const s=1.1+n*.15;t.cyl(.25,.4,1+n*.1,8,"#c9ced5",-.3,.1,-.3);const r=t.build("tracking"),a=new yt,o=new Qe;o.add(new sn(s,20,10,0,Math.PI*2,0,Math.PI/3.4),"#f3f5f8",0,0,0,{rx:Math.PI}),o.cyl(.03,.03,s*.8,4,Kt,0,-s*.85,0),o.sphere(.08,e.accent,0,-s*1.25,0);const c=o.build();c.rotation.x=-.75,a.add(c),a.position.set(-.3,1.3+n*.1+s*.4,-.3),r.add(a);for(let l=0;l<Math.min(3,n-1);l++){const h=new Qe;h.cyl(.04,.06,.5,6,Kt,0,0,0),h.add(new sn(.35,12,6,0,Math.PI*2,0,Math.PI/3.2),"#eef2f6",0,.85,0,{rx:Math.PI-.7});const d=h.build();d.position.set(1.3-l*.7,.1,-1.4),r.add(d)}return{group:r,height:2.4+n*.3,anim:l=>{a.rotation.y=Math.sin(l*.12)*1.2}}}function kb(i,e){const t=new Qe,n=Wt(i),s=e.primary,r=e.accent;Ot(t,4,4),t.box(2.4,.9+n*.12,1.4,s,-.6,.1,-1.1),Vt(t,2.4,1.4,.4,.2,-.6,-1.1),t.box(2.45,.08,1.45,r,-.6,1+n*.12,-1.1),t.box(1.4,.06,1,"#4fb3e8",1,.1,1,{glass:!0}),t.box(1.5,.1,1.1,"#e9edf2",1,.08,1),t.cyl(.35,.45,.5,10,"#d9dde2",-.6,.1,.8);const a=t.build("academy"),o=new yt,c=new Qe;return c.box(2.2,.08,.12,Kt,0,0,0),c.sphere(.2,r,1.1,0,0,{w:10,h:7}),c.box(.25,.25,.25,"#eef0f3",-1.1,-.1,0),o.add(c.build()),o.position.set(-.6,.75,.8),a.add(o),{group:a,height:1.6+n*.15,anim:l=>{o.rotation.y=l*1.6}}}function Bb(i,e){const t=new Qe,n=Wt(i),s=e.primary,r=e.accent;Ot(t,4,4);const a=1+n*.12;t.box(2.8,a,2.2,s,-.3,.1,-.4);for(let f=0;f<4;f++)t.add(new fi(.35,.35,2.2,3,1,!1,0,Math.PI),Un(s,-.1),-1.35+f*.7,.1+a,-.4,{rx:Math.PI/2,rz:Math.PI/2});Vt(t,2.8,2.2,.35,.22,-.3,-.4),t.box(1,a-.2,.05,"#2b3340",-.3,.1,.72),t.box(1.04,.08,.08,r,-.3,a-.12,.73);for(let f=0;f<Math.min(3,1+Math.floor(n/2));f++)t.cyl(.18,.2,.32,10,"#e9edf2",1.45,.1,-1.2+f*.6),t.sphere(.13,r,1.45,.52,-1.2+f*.6,{glow:!0,w:10,h:7});t.box(1.6,.1,.4,wr,.4,.15,1.35);const o=t.build("workshop"),c=new yt,l=new Qe;l.cyl(.12,.16,.25,8,"#f5c542",0,0,0),l.box(.1,.8,.1,"#f5c542",0,.25,0);const h=l.build();c.add(h);const d=new yt,u=new Qe;return u.box(.08,.6,.08,"#f5c542",0,0,0),u.sphere(.06,"#7ff5ff",0,.62,0,{glow:!0}),d.add(u.build()),d.position.y=1,c.add(d),c.position.set(1,.1,1.15),o.add(c),{group:o,height:a+.8,anim:(f,g)=>{const v=g.working?1:.2;c.rotation.y=Math.sin(f*.9)*1.2*v,d.rotation.z=-.6+Math.sin(f*1.7)*.5*v}}}function zb(i,e){const t=new Qe,n=Wt(i),s=e.accent;Ot(t,3,3,"#c3c8cf");const r=Math.min(4,2+Math.floor(n/2)),a=[];for(let c=0;c<r;c++){const l=-.9+c%2*1.8,h=-.7+Math.floor(c/2)*1.3;t.cyl(.42,.46,.12,14,"#8a939e",l,.1,h),t.box(.08,.9,.08,"#9aa3ad",l-.35,.1,h),t.box(.35,.06,.06,"#9aa3ad",l-.18,.95,h)}t.box(2.6,.06,.2,s,0,1.2,0),t.box(.1,1.1,.1,"#9aa3ad",-1.25,.1,0),t.box(.1,1.1,.1,"#9aa3ad",1.25,.1,0);const o=t.build("dock");for(let c=0;c<r;c++){const l=-.9+c%2*1.8,h=-.7+Math.floor(c/2)*1.3,d=new je(new Dr(.4,.03,6,24),new Ht({color:s,toneMapped:!1,transparent:!0,opacity:.8}));d.rotation.x=Math.PI/2,d.position.set(l,.3,h),o.add(d),a.push(d)}return{group:o,height:1.4,anim:c=>a.forEach((l,h)=>{l.position.y=.25+(c*.6+h*.3)%1*.6,l.material.opacity=.9-(c*.6+h*.3)%1*.8})}}function Gb(i,e){const t=new Qe,n=Wt(i),s=e.accent;Ot(t,3,3);const r=Math.min(3,1+Math.floor(n/2));for(let a=0;a<r;a++){const o=-.9+a*.8;t.box(2,.08,.5,"#5b6676",-.3,.1,o);for(let c=0;c<6;c++)t.cyl(.11,.11,.42,8,"#7cf29a",-1.1+c*.32,.18,o,{glow:!0}),t.cyl(.08,.08,.05,8,"#e9edf2",-1.1+c*.32,.6,o)}t.box(.7,.8,.7,"#d9dde2",1.05,.1,.8),t.box(.72,.08,.72,s,1.05,.9,.8);for(let a=0;a<3;a++)t.cyl(.05,.05,.3,6,"#9aa3ad",.85+a*.2,.98,.8);return{group:t.build("cellplant"),height:1.2}}function Hb(i,e){const t=new Qe,n=Wt(i),s=e.primary,r=e.accent;Ot(t,4,4);for(const l of[-1.15,1.15])t.cyl(.55,.6,1.1+n*.1,12,s,l,.1,-.2),t.sphere(.55,Un(s,-.05),l,1.2+n*.1,-.2,{theta:Math.PI/2,w:14}),t.cyl(.57,.57,.08,12,r,l,.6,-.2);t.cyl(.22,.22,1.6,10,"#9aa3ad",0,.75,-.2,{rz:Math.PI/2}),t.box(2.6,.5,.9,Un(s,-.08),0,.1,1.2),Vt(t,2.6,.9,.22,.14,0,1.2);const a=t.build("fusionlab"),o=new je(new Pr(.32,1),new Ht({color:"#c49bff",toneMapped:!1}));o.position.set(0,1,-.2),a.add(o);const c=new je(new Dr(.5,.03,6,28),new Ht({color:"#ff9be8",toneMapped:!1}));return c.position.copy(o.position),a.add(c),{group:a,height:1.9+n*.1,anim:(l,h)=>{const d=h.working?1:.3;o.rotation.y=l*1.5,o.scale.setScalar(.85+Math.sin(l*4)*.12*d),c.rotation.x=l*1.1,c.rotation.y=l*.7}}}function Vb(i,e){const t=at[i],[n,s]=t?t.fp:[3,3],r=new Qe;return Ot(r,n,s),r.box(n*.7,1.2,s*.7,e.primary,0,.1,0),Vt(r,n*.7,s*.7,.5,.2),r.box(n*.72,.1,s*.72,e.accent,0,1.3,0),{group:r.build(i),height:1.6}}function Xl(i,e,t){switch(i){case"hq":return Ab(e,t);case"research":return Tb(e,t);case"university":return Rb(e,t);case"mine":return Cb(e,t);case"refinery":return Pb(e,t);case"office":return Lb(e,t);case"solar":return Db(e);case"fission":return Ib(e,t);case"depot":return Nb(e,t);case"launch":return Ub(e,t);case"vab":return Fb(e,t);case"tracking":return Ob(e,t);case"academy":return kb(e,t);case"workshop":return Bb(e,t);case"dock":return zb(e,t);case"cellplant":return Gb(e,t);case"fusionlab":return Hb(e,t)}return Vb(i,t)}function Wb(i,e,t){const n=new Qe,s="#f5c542";for(const[r,a]of[[-i/2+.15,-e/2+.15],[i/2-.15,-e/2+.15],[-i/2+.15,e/2-.15],[i/2-.15,e/2-.15]])n.box(.06,t,.06,s,r,0,a);for(let r=.5;r<t;r+=.6)n.box(i-.2,.05,.08,s,0,r,-e/2+.15),n.box(i-.2,.05,.08,s,0,r,e/2-.15),n.box(.08,.05,e-.2,s,-i/2+.15,r,0),n.box(.08,.05,e-.2,s,i/2-.15,r,0);return n.box(.08,t+.8,.08,"#e67e22",i/2-.4,0,-e/2+.4),n.build("scaffold")}function $b(){const i=new Qe;i.box(.34,.1,.34,"#f2f4f7"),i.box(.36,.03,.36,"#f5c542",0,.1,0);for(const[e,t]of[[.24,.24],[-.24,.24],[.24,-.24],[-.24,-.24]])i.box(.2,.025,.04,"#3b4350",e*.6,.06,t*.6,{ry:Math.atan2(t,e)}),i.cyl(.11,.11,.015,10,"#9aa3ad",e,.09,t);return i.sphere(.05,"#7ff5ff",0,-.04,0,{glow:!0}),i.build("drone")}const Cd=new Map;function qb(i,e,t){if(i.beginPath(),e==="star")for(let n=0;n<10;n++){const s=-Math.PI/2+n*Math.PI/5,r=n%2?t*.45:t;i.lineTo(Math.cos(s)*r,Math.sin(s)*r)}else e==="planet"?(i.arc(0,0,t*.6,0,7),i.moveTo(t,0),i.ellipse(0,0,t,t*.28,-.3,0,7)):e==="rocket"?(i.moveTo(0,-t),i.quadraticCurveTo(t*.45,-t*.3,t*.3,t*.5),i.lineTo(t*.6,t),i.lineTo(-t*.6,t),i.lineTo(-t*.3,t*.5),i.quadraticCurveTo(-t*.45,-t*.3,0,-t)):e==="bolt"?(i.moveTo(t*.2,-t),i.lineTo(-t*.5,t*.1),i.lineTo(0,t*.1),i.lineTo(-t*.2,t),i.lineTo(t*.5,-t*.1),i.lineTo(0,-t*.1)):i.arc(0,0,t*.8,0,7);i.closePath()}function Xb(i){const e=i.bg+i.fg+i.emblem,t=Cd.get(e);if(t)return t;const n=document.createElement("canvas");n.width=128,n.height=80;const s=n.getContext("2d");s.fillStyle=i.bg,s.fillRect(0,0,128,80),s.fillStyle=i.fg,s.translate(64,40),qb(s,i.emblem,24),s.fill();const r=new io(n);return r.colorSpace=Ft,Cd.set(e,r),r}const Yb=`
vec3 mod289(vec3 x){return x-floor(x*(1.0/289.0))*289.0;} vec4 mod289(vec4 x){return x-floor(x*(1.0/289.0))*289.0;}
vec4 permute(vec4 x){return mod289(((x*34.0)+1.0)*x);} vec4 taylorInvSqrt(vec4 r){return 1.79284291400159-0.85373472095314*r;}
float snoise(vec3 v){ const vec2 C=vec2(1.0/6.0,1.0/3.0); const vec4 D=vec4(0.0,0.5,1.0,2.0);
  vec3 i=floor(v+dot(v,C.yyy)); vec3 x0=v-i+dot(i,C.xxx); vec3 g=step(x0.yzx,x0.xyz); vec3 l=1.0-g; vec3 i1=min(g.xyz,l.zxy); vec3 i2=max(g.xyz,l.zxy);
  vec3 x1=x0-i1+C.xxx; vec3 x2=x0-i2+C.yyy; vec3 x3=x0-D.yyy; i=mod289(i);
  vec4 p=permute(permute(permute(i.z+vec4(0.0,i1.z,i2.z,1.0))+i.y+vec4(0.0,i1.y,i2.y,1.0))+i.x+vec4(0.0,i1.x,i2.x,1.0));
  float n_=0.142857142857; vec3 ns=n_*D.wyz-D.xzx; vec4 j=p-49.0*floor(p*ns.z*ns.z); vec4 x_=floor(j*ns.z); vec4 y_=floor(j-7.0*x_);
  vec4 x=x_*ns.x+ns.yyyy; vec4 y=y_*ns.x+ns.yyyy; vec4 h=1.0-abs(x)-abs(y); vec4 b0=vec4(x.xy,y.xy); vec4 b1=vec4(x.zw,y.zw);
  vec4 s0=floor(b0)*2.0+1.0; vec4 s1=floor(b1)*2.0+1.0; vec4 sh=-step(h,vec4(0.0)); vec4 a0=b0.xzyw+s0.xzyw*sh.xxyy; vec4 a1=b1.xzyw+s1.xzyw*sh.zzww;
  vec3 p0=vec3(a0.xy,h.x); vec3 p1=vec3(a0.zw,h.y); vec3 p2=vec3(a1.xy,h.z); vec3 p3=vec3(a1.zw,h.w);
  vec4 norm=taylorInvSqrt(vec4(dot(p0,p0),dot(p1,p1),dot(p2,p2),dot(p3,p3))); p0*=norm.x; p1*=norm.y; p2*=norm.z; p3*=norm.w;
  vec4 m=max(0.6-vec4(dot(x0,x0),dot(x1,x1),dot(x2,x2),dot(x3,x3)),0.0); m=m*m;
  return 42.0*dot(m*m,vec4(dot(p0,x0),dot(p1,x1),dot(p2,x2),dot(p3,x3))); }
float fbm(vec3 p, int oct){ float s=0.0, a=0.5; for(int i=0;i<8;i++){ if(i>=oct) break; s+=a*snoise(p); p=p*2.03+vec3(1.7,9.2,3.1); a*=0.5; } return s; }
vec3 hash3(vec3 p){ p=fract(p*vec3(0.1031,0.1030,0.0973)); p+=dot(p,p.yxz+33.33); return fract((p.xxy+p.yxx)*p.zyx); }
float craters(vec3 p){ vec3 i=floor(p), f=fract(p); float c=0.0; for(int x=-1;x<=1;x++) for(int y=-1;y<=1;y++) for(int z=-1;z<=1;z++){ vec3 o=vec3(float(x),float(y),float(z)); vec3 h=hash3(i+o); vec3 d=o+h-f; float r=0.15+0.3*h.x; float dd=length(d)/r; if(dd<1.0){ c+= (dd<0.8? -0.6*(1.0-dd*dd*1.4) : 0.0) + (dd>=0.75 ? 0.5*(1.0-abs(dd-0.88)/0.13) : 0.0); } } return c; }`,Kb="varying vec2 vUv; void main(){ vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }",Jb=`precision highp float; varying vec2 vUv; uniform int uMode; uniform float uSeed;
${Yb}
vec3 dirOf(vec2 uv){ float lon = (uv.x - 0.5) * 6.2831853; float lat = (uv.y - 0.5) * 3.1415926; return vec3(cos(lat)*cos(lon), sin(lat), cos(lat)*sin(lon)); }
void main(){ vec3 n = dirOf(vUv); vec3 p = n*1.2 + vec3(uSeed*7.31, uSeed*3.17, uSeed*1.91);
  if (uMode == 0) { // Earth albedo (rgb) + water mask (a)
    float h = fbm(p*1.6, 7) + 0.35*fbm(p*5.0, 4); float wl = 0.02; vec3 col; float water = 0.0;
    if (h < wl) { float dpt = clamp((wl-h)*3.0, 0.0, 1.0); col = mix(vec3(0.12,0.42,0.65), vec3(0.04,0.16,0.36), dpt); water = 1.0; }
    else { float e = clamp((h-wl)/0.73, 0.0, 1.0); float dry = smoothstep(0.1, 0.5, snoise(p*1.3+4.0)*0.5+0.5) * (1.0-abs(n.y));
      vec3 green = mix(vec3(0.20,0.45,0.18), vec3(0.62,0.55,0.34), dry); col = e < 0.45 ? mix(green, vec3(0.55,0.5,0.36), e/0.45) : mix(vec3(0.55,0.5,0.36), vec3(0.92,0.9,0.86), (e-0.45)/0.55); }
    float lat = abs(n.y) + 0.06*snoise(p*2.0); float ice = smoothstep(0.84, 0.89, lat); col = mix(col, vec3(0.94,0.96,1.0), ice); water *= 1.0-ice;
    gl_FragColor = vec4(col, water); }
  else if (uMode == 1) { // clouds (r), city lights (g)
    float cl = smoothstep(0.36, 0.78, fbm(n*2.2 + vec3(uSeed), 6)*0.5+0.5); cl = max(cl, smoothstep(0.55, 0.9, fbm(n*vec3(1.0,3.5,1.0)*2.0+3.0, 4)*0.5+0.5)*0.8*(1.0-abs(n.y)));
    float h = fbm(p*1.6, 7) + 0.35*fbm(p*5.0, 4); float land = smoothstep(0.03, 0.12, h-0.02);
    float region = smoothstep(0.55, 0.8, snoise(p*5.0)*0.5+0.5); float dots = smoothstep(0.6, 0.9, snoise(p*70.0)*0.5+0.5) + 0.35*smoothstep(0.7, 0.95, snoise(p*26.0)*0.5+0.5);
    gl_FragColor = vec4(cl, region*dots*land*(1.0-smoothstep(0.75, 0.9, abs(n.y))), 0.0, 1.0); }
  else if (uMode == 2) { // Moon albedo
    float h = fbm(p*1.6, 6)*0.6 + craters(n*6.0+uSeed)*0.5 + craters(n*15.0+uSeed*2.0)*0.25; float mare = smoothstep(0.1, -0.2, fbm(p*0.9+2.0, 4));
    vec3 col = mix(vec3(0.62,0.61,0.59), vec3(0.36,0.36,0.37), mare) * (0.8 + h*0.35); gl_FragColor = vec4(col, 1.0); }
  else if (uMode == 4) { // Mars albedo: rust plains, dark regions, polar caps
    float h = fbm(p*1.4, 6); float dark = smoothstep(0.05, 0.35, fbm(p*0.8+5.0, 4)); vec3 col = mix(vec3(0.78,0.42,0.24), vec3(0.42,0.2,0.13), dark) * (0.85 + h*0.25);
    float ice = smoothstep(0.86, 0.9, abs(n.y) + 0.04*snoise(p*3.0)); col = mix(col, vec3(0.95,0.93,0.9), ice); gl_FragColor = vec4(col, 1.0); }
  else { // nebula sky
    float n1 = fbm(n*1.8 + 1.3, 5)*0.5+0.5; float n2 = fbm(n*4.0 + 3.0, 4)*0.5+0.5; vec3 col = vec3(0.004,0.006,0.016) + vec3(0.12,0.22,0.5)*pow(n1, 3.4)*0.6 + vec3(0.25,0.08,0.3)*pow(n2, 4.0)*0.5;
    float band = exp(-pow(n.y*3.2 + 0.4*snoise(n*3.0), 2.0)); col += vec3(0.16,0.15,0.2)*band*(0.5+0.5*n1);
    gl_FragColor = vec4(col, 1.0); } }`;function Zb(i,e,t,n,s=1){const r=new Mn(t,n,{type:ln,generateMipmaps:!0,minFilter:hi,magFilter:nn,wrapS:Oa}),a=new to,o=new Uc(-1,1,1,-1,0,1),c=new fn({vertexShader:Kb,fragmentShader:Jb,uniforms:{uMode:{value:e},uSeed:{value:s}}}),l=new je(new pi(2,2),c);a.add(l);const h=i.getRenderTarget();return i.setRenderTarget(r),i.render(a,o),i.setRenderTarget(h),c.dispose(),l.geometry.dispose(),r.texture.colorSpace=e===1?li:Ft,r}const Qb="varying vec3 vN; varying vec3 vW; varying vec2 vUv; void main(){ vUv = uv; vN = normalize(mat3(modelMatrix)*normal); vec4 w = modelMatrix*vec4(position,1.0); vW = w.xyz; gl_Position = projectionMatrix*viewMatrix*w; }",jb=`uniform sampler2D uDay; uniform sampler2D uAux; uniform vec3 uSun; uniform float uTime; varying vec3 vN; varying vec3 vW; varying vec2 vUv;
void main(){ vec3 n = normalize(vN); vec3 v = normalize(cameraPosition - vW); float ndl = dot(n, uSun);
  vec4 day = texture2D(uDay, vUv); vec4 aux = texture2D(uAux, vUv); float cl = texture2D(uAux, vUv + vec2(uTime*0.0016, 0.0)).r;
  float diff = max(ndl, 0.0); vec3 col = day.rgb*(0.025 + diff*1.1);
  vec3 h = normalize(uSun + v); col += vec3(1.0,0.93,0.8)*pow(max(dot(n,h),0.0), 70.0)*day.a*diff*0.9;
  col = mix(col, vec3(1.0)*(0.04 + diff*1.15), cl*0.9);
  col += vec3(1.0,0.72,0.38)*aux.g*(1.0-cl*0.85)*smoothstep(0.05,-0.25,ndl)*1.6;
  float limb = pow(1.0 - max(dot(n, v), 0.0), 3.0); col += vec3(0.32,0.58,1.0)*limb*(0.15 + diff*0.95);
  col = mix(col, col*vec3(1.15,0.85,0.7), smoothstep(0.2,0.0,ndl)*smoothstep(-0.1,0.05,ndl)*0.6);
  gl_FragColor = vec4(col, 1.0); }`,e_=`uniform vec3 uSun; varying vec3 vN; varying vec3 vW; void main(){ vec3 n = normalize(vN); vec3 v = normalize(cameraPosition - vW); float rim = pow(1.0 - abs(dot(n, v)), 2.6);
  float lit = clamp(dot(n, uSun)*0.9 + 0.35, 0.0, 1.0); gl_FragColor = vec4(vec3(0.35,0.62,1.0)*rim*lit*1.6, rim*lit); }`,vf="varying vec3 vN; varying vec3 vW; varying vec2 vUv; void main(){ vUv = uv; vN = normalize(mat3(modelMatrix)*normal); vec4 w = modelMatrix*vec4(position,1.0); vW = w.xyz; gl_Position = projectionMatrix*viewMatrix*w; }",t_="uniform sampler2D uMap; uniform vec3 uSun; varying vec3 vN; varying vec2 vUv; void main(){ float d = max(dot(normalize(vN), uSun), 0.0); gl_FragColor = vec4(texture2D(uMap, vUv).rgb*(0.02 + d*1.2), 1.0); }";function n_(i,e,t=2){const n=new Float32Array(e*3),s=new Float32Array(e*3),r=new Te;for(let o=0;o<e;o++){const c=Math.random()*2-1,l=Math.random()*Math.PI*2,h=Math.sqrt(1-c*c);n.set([h*Math.cos(l)*i,c*i,h*Math.sin(l)*i],o*3),r.setHSL(.55+Math.random()*.15-(Math.random()<.2?.45:0),.5,.75+Math.random()*.25),s.set([r.r,r.g,r.b],o*3)}const a=new pt;return a.setAttribute("position",new Zt(n,3)),a.setAttribute("color",new Zt(s,3)),new Bl(a,new Xa({size:t,sizeAttenuation:!1,vertexColors:!0,depthWrite:!1,transparent:!0,opacity:.95}))}let xa=null;function i_(i){if(!xa){const t=document.createElement("canvas");t.width=t.height=128;const n=t.getContext("2d"),s=n.createRadialGradient(64,64,0,64,64,64);s.addColorStop(0,"rgba(255,255,240,1)"),s.addColorStop(.12,"rgba(255,248,220,0.95)"),s.addColorStop(.35,"rgba(255,220,160,0.25)"),s.addColorStop(1,"rgba(255,200,120,0)"),n.fillStyle=s,n.fillRect(0,0,128,128),xa=new io(t),xa.colorSpace=Ft}const e=new Bu(new Ac({map:xa,depthWrite:!1,blending:Fa,transparent:!0}));return e.scale.setScalar(i),e}const Pd={},Ja=(i,e,t,n)=>{const s=e+":"+t+":"+n;return(Pd[s]=Pd[s]||Zb(i,e,t,t/2,n)).texture};function s_(i,e,t,n){const s={uDay:{value:Ja(i,0,n?2048:1024,1)},uAux:{value:Ja(i,1,n?2048:1024,1)},uSun:{value:t},uTime:{value:0}},r=new yt,a=new je(new sn(e,n?128:72,n?64:40),new fn({vertexShader:Qb,fragmentShader:jb,uniforms:s}));r.add(a);const o=new je(new sn(e*1.035,64,32),new fn({vertexShader:vf,fragmentShader:e_,uniforms:{uSun:{value:t}},side:Gt,transparent:!0,blending:Fa,depthWrite:!1}));return r.add(o),{group:r,mesh:a,uniforms:s}}function r_(i,e,t,n,s,r){const a=new yt,o=new je(new sn(e,64,32),new fn({vertexShader:vf,fragmentShader:t_,uniforms:{uMap:{value:Ja(i,n,1024,s)},uSun:{value:t}}}));return a.add(o),{group:a,mesh:o}}const a_=(i,e)=>Ja(i,3,e?1024:512,2),dr={leo:{name:"Low Earth Orbit",base:3,alt:"400 km"},geo:{name:"Geostationary",base:2,alt:"35,786 km"},lagrange:{name:"Earth–Moon L1/L2",base:0,alt:"326,000 km"}},kn={comms:{name:"Comms Satellite",orbit:"geo",cls:2,req:"satComms",prod:{credits:[900,1.28]},cost:{credits:[1800,1.55],metal:[1500,1.55],fuel:[600,1.5]},flight:[600,1.3],desc:"Relays TV, phone and internet traffic. Pays its way in credits."},observe:{name:"Earth Observation",orbit:"leo",cls:2,req:"remoteSensing",mult:{metal:.05,fuel:.05},cost:{credits:[2200,1.55],metal:[1800,1.55],fuel:[700,1.5]},flight:[600,1.3],desc:"Maps mineral deposits and oil fields from orbit. Metal and fuel +5% per level."},weather:{name:"Weather Satellite",orbit:"leo",cls:2,req:"remoteSensing",mult:{credits:.04,metal:.03,fuel:.03},rel:.01,cost:{credits:[2e3,1.55],metal:[1600,1.55],fuel:[700,1.5]},flight:[600,1.3],desc:"Predicts storms and launch weather. Small boosts to production and launch reliability."},nav:{name:"Navigation Satellite",orbit:"leo",cls:3,req:"gps",rel:.015,flightCut:.04,cost:{credits:[5e3,1.55],metal:[4200,1.55],fuel:[2e3,1.5]},flight:[1200,1.3],desc:"Precise positioning and timing. Missions fly faster and succeed more often."},telescope:{name:"Space Telescope",orbit:"leo",cls:3,req:"telescopes",prod:{science:[420,1.28]},cost:{credits:[9e3,1.55],metal:[7e3,1.55],fuel:[3e3,1.5]},flight:[1800,1.3],desc:"A mirror above the atmosphere. Floods your labs with data."},power:{name:"Solar Power Satellite",orbit:"geo",cls:4,req:"spacePower",gen:[90,1.3],cost:{credits:[3e4,1.55],metal:[42e3,1.55],fuel:[12e3,1.5]},flight:[3600,1.3],desc:"Kilometre-wide solar wings beam microwave power to the grid."},relay:{name:"Deep Space Relay",orbit:"lagrange",cls:4,req:"deepSpace",rel:.02,prod:{science:[600,1.28]},cost:{credits:[4e4,1.55],metal:[36e3,1.55],fuel:[2e4,1.5]},flight:[7200,1.3],desc:"Parked at a Lagrange point: always-on contact with the Moon and beyond."}},ks={core:{name:"Core Module",cls:3,req:"spaceStation",prod:{science:[250,1.24]},max:10,cost:{credits:[2e4,1.6],metal:[26e3,1.6],fuel:[9e3,1.5]},flight:[7200,1.25],desc:"Power, guidance and the first living quarters. Every other module docks here."},lab:{name:"Laboratory",cls:3,req:"spaceStation",needs:"core",prod:{science:[500,1.264]},speed:.04,max:15,cost:{credits:[24e3,1.6],metal:[28e3,1.6],fuel:[9e3,1.5]},flight:[7200,1.25],desc:"Microgravity research. Science, plus 4% faster research per level."},solar:{name:"Solar Wings",cls:3,req:"spaceStation",needs:"core",gen:[60,1.28],max:15,cost:{credits:[16e3,1.6],metal:[22e3,1.6],fuel:[7e3,1.5]},flight:[5400,1.25],desc:"Huge photovoltaic arrays. They feed the station and beam spare power down."},habitat:{name:"Habitat Module",cls:4,req:"closedLoop",needs:"core",prod:{credits:[1500,1.264]},max:15,cost:{credits:[45e3,1.6],metal:[6e4,1.6],fuel:[2e4,1.5]},flight:[10800,1.25],desc:"Room for more crew, and for paying space tourists."},depot:{name:"Fuel Depot",cls:4,req:"cryo",needs:"core",fuelCut:.05,cap:{fuel:[2e4,1.45]},max:10,cost:{credits:[3e4,1.6],metal:[4e4,1.6],fuel:[3e4,1.5]},flight:[10800,1.25],desc:"Refuel in orbit. Missions beyond low orbit burn 5% less fuel per level."},yard:{name:"Orbital Shipyard",cls:4,req:"orbitalShipyard",needs:"core",max:10,cost:{credits:[4e5,1.6],metal:[5e5,1.6],fuel:[1e5,1.5]},flight:[14400,1.2],desc:"Gantries, robot welders and a spin-gravity crew ring: where interplanetary ships are built. Higher levels build bigger ships, faster."},dock:{name:"Docking Hub",cls:4,req:"crewed",needs:"core",rel:.012,max:10,cost:{credits:[28e3,1.6],metal:[36e3,1.6],fuel:[12e3,1.5]},flight:[10800,1.25],desc:"Berths for capsules and tugs. Crewed missions get safer."}},Er={suborbital:{name:"Suborbital Test Flight",kind:"repeat",cls:1,req:[],fuel:150,credits:200,flight:120,reward:{science:220},firstReward:{dm:10},flag:"suborbital",desc:"Up to 100 km, down by parachute. Every flight teaches the engineers something."},firstOrbit:{name:"First Satellite in Orbit",kind:"once",cls:2,req:["orbital"],fuel:600,credits:1500,flight:900,reward:{science:1500,dm:20},flag:"firstOrbit",desc:"A beeping sphere circling the Earth: the whole world will hear it."},crewOrbit:{name:"Crewed Orbital Flight",kind:"once",cls:3,req:["crewed"],needs:{academy:1},fuel:3e3,credits:8e3,flight:3600,crewed:!0,reward:{science:6e3,credits:2e4,dm:30},flag:"crewOrbit",desc:"An astronaut sees the curve of the Earth. A nation holds its breath."},lunarProbe:{name:"Lunar Survey Probe",kind:"once",cls:3,req:["deepSpace"],fuel:5e3,credits:12e3,flight:10800,reward:{science:12e3,dm:20},flag:"lunarProbe",desc:"Map the Moon from orbit: ice in the polar craters, helium-3 in the regolith."},lunarLanding:{name:"Crewed Lunar Landing",kind:"once",cls:4,req:["lunarLanders"],needs:{academy:3},fuel:2e4,credits:6e4,flight:21600,crewed:!0,lander:!0,reward:{science:5e4,credits:1e5,dm:60},flag:"lunarLanding",desc:'"One small step." Footprints in the regolith that will last a million years.'},lunarOutpost:{name:"Establish Lunar Outpost",kind:"outpost",cls:4,req:["isru"],flags:["lunarLanding"],fuel:4e4,credits:15e4,metal:12e4,flight:43200,base:"moon",reward:{dm:80},flag:"moonBase",desc:"Prefabricated habitats, a power plant and a crew of twelve. Humanity's first home off Earth."},lunarSample:{name:"Lunar Sample Return",kind:"repeat",cls:4,req:["lunarLanders"],flags:["lunarLanding"],fuel:12e3,credits:3e4,flight:14400,reward:{science:25e3,he3:120},desc:"Robotic landers scoop regolith and fly it home for the labs."}},o_=20,Ld=23.6,Dd=34,$o=25.2;class l_{constructor(e,t){this.scene=new to,this.camera=new dn(40,1,.05,2e4),this.sun=new P(-.7,.35,.6).normalize(),this.sats=new yt,this.station=new yt,this.key="",this.satObjs=[],this.cam={yaw:.6,pitch:.35,dist:78,tdist:78,tyaw:.6,tpitch:.35},this.focus="earth",this.t=0,this.earth=s_(e,o_,this.sun,t),this.earth.mesh.rotation.z=.41,this.scene.add(this.earth.group),this.moon=r_(e,5.4,this.sun,2,4),this.moon.group.position.set(-150,22,-96),this.scene.add(this.moon.group),this.scene.add(new je(new sn(9e3,48,24),new Ht({map:a_(e,t),side:Gt,depthWrite:!1}))),this.scene.add(n_(8e3,t?3500:1800,t?2.2:1.8));const n=i_(1400);n.position.copy(this.sun).multiplyScalar(7e3),this.scene.add(n);const s=new Ya("#fff4e0",2.6);s.position.copy(this.sun).multiplyScalar(100),this.scene.add(s,new sf("#334466",.6));for(const[r,a]of[[Ld,"#6ee7ff"],[Dd,"#ffd36a"]]){const o=new je(new Lr(r-.03,r+.03,160),new Ht({color:a,transparent:!0,opacity:.18,side:bn,depthWrite:!1}));o.rotation.x=Math.PI/2,this.scene.add(o)}this.scene.add(this.sats,this.station)}resize(e,t){this.camera.aspect=e/t,this.camera.updateProjectionMatrix()}sync(e){const t=JSON.stringify([e.sats,e.modules]);if(t===this.key)return;this.key=t,this.sats.clear(),this.satObjs=[];const n={};e.sats.forEach(r=>{const a=kn[r.type],o=n[a.orbit]=(n[a.orbit]||0)+1,c=c_(r.type,r.lvl);c.scale.setScalar(1.3+r.lvl*.08),this.sats.add(c),this.satObjs.push({g:c,orbit:a.orbit,ph:o*2.1+(a.orbit==="geo"?.5:0),r:a.orbit==="geo"?Dd:Ld+o%3*.5,inc:a.orbit==="leo"?o%2?.5:-.35:0})}),this.station.clear();const s=e.modules;s.core&&this.station.add(h_(s))}stationPos(e){const t=e*.05;return new P(Math.cos(t)*$o,Math.sin(t)*$o*.36,Math.sin(t)*$o*.93)}drag(e,t){this.cam.tyaw-=e*.006,this.cam.tpitch=bt(this.cam.tpitch+t*.005,-1.2,1.2)}zoom(e){this.cam.tdist=bt(this.cam.tdist*e,this.focus==="station"?3:30,this.focus==="station"?30:260)}setFocus(e){this.focus=e,this.cam.tdist=e==="station"?9:78}frame(e){this.t+=e;const t=this.t,n=this.cam,s=.12;n.yaw+=(n.tyaw-n.yaw)*s,n.pitch+=(n.tpitch-n.pitch)*s,n.dist+=(n.tdist-n.dist)*s,this.earth.mesh.rotation.y=t*.01,this.earth.uniforms&&(this.earth.uniforms.uTime.value=t);for(const o of this.satObjs){const c=o.orbit==="geo"?.01:o.orbit==="lagrange"?0:.07,l=o.ph+t*c;o.orbit==="lagrange"?(o.g.position.copy(this.moon.group.position).multiplyScalar(.84),o.g.position.y+=Math.sin(t*.3+o.ph)*.6):o.g.position.set(Math.cos(l)*o.r,Math.sin(l)*o.r*o.inc,Math.sin(l)*o.r*Math.cos(o.inc)),o.g.lookAt(0,0,0)}const r=this.stationPos(t);this.station.position.copy(r),this.station.rotation.y=t*.02,this.station.scale.setScalar(this.focus==="station"?1:1.6);const a=this.focus==="station"&&this.station.children.length?r:new P;this.camera.position.set(a.x+Math.cos(n.pitch)*Math.sin(n.yaw)*n.dist,a.y+Math.sin(n.pitch)*n.dist,a.z+Math.cos(n.pitch)*Math.cos(n.yaw)*n.dist),this.camera.lookAt(a)}}function c_(i,e){const t=new Qe,n="#d9a82e",s="#1d3c78",r="#e9edf2",a=(o,c=.3)=>{t.box(o,.02,c,s,o/2+.2,0,0),t.box(o,.02,c,s,-o/2-.2,0,0),t.box(o*2+.4,.015,.03,"#9aa3ad",0,0,0)};switch(i){case"comms":t.box(.3,.3,.3,n),a(.8+e*.05),t.add(new sn(.22,12,6,0,Math.PI*2,0,Math.PI/3),r,0,.35,0,{rx:Math.PI});break;case"observe":t.box(.25,.35,.25,r),t.cyl(.08,.08,.3,10,"#3a3f47",0,-.4,0),a(.6);break;case"weather":t.cyl(.18,.18,.4,10,r),a(.7,.25),t.cyl(.02,.02,.4,4,"#9aa3ad",0,.2,0);break;case"nav":t.box(.28,.28,.28,"#c9d6e6"),a(.7),t.cyl(.015,.015,.5,4,n,0,.15,0);break;case"telescope":t.cyl(.16,.16,.9,12,r,0,-.2,0),t.cyl(.17,.17,.05,12,n,0,.1,0),a(.5,.35);break;case"power":t.box(.3,.2,.3,n),a(2.2+e*.15,.9);break;default:t.box(.3,.3,.3,n),t.add(new sn(.4,14,6,0,Math.PI*2,0,Math.PI/3),r,0,.45,0,{rx:Math.PI}),a(.5)}return t.sphere(.04,"#ff5b5b",0,.2,.18,{glow:!0}),t.build("sat")}function h_(i){const e=new Qe,t="#e6e9ee",n="#d9a82e",s="#1d3c78";if(e.cyl(.32,.32,2,14,t,0,-1,0,{rz:Math.PI/2}),e.cyl(.34,.34,.1,14,n,-.4,-.05,0,{rz:Math.PI/2}),i.lab){const a=1.2+i.lab*.05;e.cyl(.3,.3,a,14,t,0,-a/2,.3+a/2,{rx:Math.PI/2}),e.cyl(.31,.31,.08,14,"#6ee7ff",0,-.04,.3+a*.8,{rx:Math.PI/2,glow:!0})}if(i.habitat&&(e.sphere(.55+i.habitat*.02,"#f1f3f5",1.5,0,0,{w:16,h:10}),e.cyl(.18,.18,.5,10,t,1,-.25,0,{rz:Math.PI/2})),i.depot)for(let a=0;a<Math.min(4,1+Math.floor(i.depot/3));a++)e.sphere(.3,"#c9ced5",-1.4,0,-.6-a*.62,{w:12,h:8});if(i.dock){e.cyl(.5,.5,.12,20,"#b8c4d6",0,-.06,-.9,{rx:Math.PI/2});for(let a=0;a<4;a++){const o=a/4*Math.PI*2;e.cyl(.08,.08,.3,8,n,Math.cos(o)*.5,Math.sin(o)*.5-.15,-.9,{rz:o+Math.PI/2})}}if(i.yard){for(let a=0;a<4;a++)e.box(.04,.04,2.6,"#9aa3ad",-.9+a%2*1.8,-1.2-Math.floor(a/2)*.9,0);for(let a=-1.2;a<=1.2;a+=.6)e.box(1.84,.04,.04,"#9aa3ad",0,-1.2,a);e.box(.6,.3,1.4,"#c9ced5",0,-1.65,0)}const r=i.solar?2+Math.min(6,i.solar):2;for(let a=0;a<r;a++){const o=-.8+(a%2?1.6:0)*0+(a-(r-1)/2)*.55;e.box(.06,.06,4,"#9aa3ad",o,.42,0),e.box(.45,.02,1.6,s,o,.42,1),e.box(.45,.02,1.6,s,o,.42,-1)}return e.sphere(.05,"#ff5b5b",1,.4,0,{glow:!0}),e.sphere(.05,"#7cf29a",-1,.4,0,{glow:!0}),e.build("station")}const Q=(i,e,t,n,s,r,a)=>({name:i,el:e,rarity:t,chassis:n,desc:s,...r?{price:r,unlock:a}:{}}),tt={helio:Q("Helio",["solar"],"standard","orb","A floating solar collector with a sunny disposition. Your first crewmate.",300,1),ember:Q("Ember",["plasma"],"standard","rover","Welds hull plates with a plasma torch it is very proud of.",350,1),tidepool:Q("Tidepool",["hydro"],"standard","crawler","Recycles every drop of water on the island. Twice.",400,2),frostbyte:Q("Frostbyte",["cryo"],"standard","walker","Keeps the servers cold and the jokes colder.",450,3),digger:Q("Digger",["geo"],"standard","rover","Has never met a rock it could not move.",500,3),sprout:Q("Sprout",["bio"],"standard","android","Talks to the greenhouse plants. They grow faster.",550,4),sparky:Q("Sparky",["volt"],"standard","drone","A hyperactive power drone. Do not let it near the coffee.",600,4),bolt:Q("Bolt",["alloy"],"standard","mech","Lifts girders, opens jars, never complains.",700,5),zephyr:Q("Zephyr",["aero"],"standard","drone","Rides the ventilation currents for fun.",800,5),lumen:Q("Lumen",["photon"],"standard","drone","A flying floodlight that loves an audience.",900,6),brawler:Q("Brawler",["kinetic"],"standard","mech","Built for demolition, adores being useful.",1e3,6),anchor:Q("Anchor",["gravity"],"standard","walker","Heavier than it looks, calmer than it sounds.",1200,7),umbra:Q("Umbra",["void"],"standard","orb","Absorbs stray light. Prefers the night shift.",1400,7),tick:Q("Tick",["chrono"],"standard","android","Always exactly on time, sometimes slightly early.",1600,8),cortex:Q("Cortex",["neural"],"standard","orb","A small AI that asks a lot of questions.",1800,8),solarflare:Q("Solarflare",["solar","plasma"],"advanced","drone","Catches sunlight, throws it back as fire.",2600,9),thunderhead:Q("Thunderhead",["volt","hydro"],"advanced","orb","A storm in a sphere. Crackles when it is happy.",3200,10),magmaw:Q("Magmaw",["geo","plasma"],"advanced","crawler","Eats rock, breathes lava, purrs.",3800,11),greenhouse:Q("Greenhouse",["bio","solar"],"advanced","android","A walking garden that photosynthesises on the job.",4400,12),glacier:Q("Glacier",["cryo","alloy"],"advanced","mech","Ice-armoured and unhurried. Nothing gets past.",5e3,13),floe:Q("Floe",["hydro","cryo"],"advanced","crawler","Skates across frozen reservoirs, clearing them.",5600,14),quarry:Q("Quarry",["geo","alloy"],"advanced","mech","Turns asteroids into neatly stacked bricks.",6200,15),mangrove:Q("Mangrove",["bio","hydro"],"advanced","walker","Grows roots into the water pipes. On purpose.",6900,16),dynamo:Q("Dynamo",["volt","alloy"],"advanced","rover","A rolling generator with a lot of torque.",7600,17),eclipse:Q("Eclipse",["void","photon"],"advanced","orb","Half light, half dark, entirely mysterious.",8400,18),rampart:Q("Rampart",["kinetic","alloy"],"advanced","mech","A wall that walks. Very reassuring.",9200,19),stormkite:Q("Stormkite",["aero","volt"],"advanced","drone","Flies into lightning to recharge.",1e4,20),monolith:Q("Monolith",["gravity","geo"],"advanced","walker","Stands perfectly still for days. Then dances.",11e3,21),paradox:Q("Paradox",["chrono","neural"],"advanced","android","Remembers things that have not happened yet.",12e3,22),synapse:Q("Synapse",["neural","volt"],"advanced","orb","Thinks in lightning. Talks in puns.",13e3,23),blizzard:Q("Blizzard",["aero","cryo"],"advanced","drone","Brings its own weather everywhere it goes.",14e3,24),prism:Q("Prism",["photon","solar"],"advanced","orb","Splits starlight into every colour it knows.",15e3,25),undertow:Q("Undertow",["void","gravity"],"advanced","crawler","Pulls things in. Gently. Usually.",16e3,26),blastforge:Q("Blastforge",["plasma","kinetic"],"advanced","mech","Forges hull plates with controlled explosions.",17500,27),rootbound:Q("Rootbound",["bio","geo"],"advanced","walker","Plants a tree with every step.",19e3,28),rainmaker:Q("Rainmaker",["hydro","aero"],"advanced","drone","Seeds clouds over the greenhouses.",20500,29),sundial:Q("Sundial",["chrono","photon"],"advanced","android","Tells time by the shadows it casts.",22e3,30),mycelium:Q("Mycelium",["neural","bio"],"advanced","crawler","A network of thinking fungus in a shell.",24e3,31),orbiter:Q("Orbiter",["gravity","aero"],"advanced","orb","Has its own small moon. It is very attached.",26e3,32),permafrost:Q("Permafrost",["cryo","void"],"advanced","walker","Cold enough to freeze light.",28e3,33),arcjet:Q("Arcjet",["volt","plasma"],"advanced","rover","Rides a cushion of ionised air.",3e4,34),mirrorplate:Q("Mirrorplate",["alloy","photon"],"advanced","mech","Polished so well it reflects your mood.",32e3,35),striker:Q("Striker",["kinetic","aero"],"advanced","drone","Fast, precise, slightly showing off.",34e3,36),pendulum:Q("Pendulum",["chrono","gravity"],"advanced","walker","Swings between moments.",36e3,37),oracle:Q("Oracle",["neural","photon"],"advanced","orb","Answers questions before you ask them.",38e3,38),mudlark:Q("Mudlark",["geo","hydro"],"advanced","rover","Happiest up to its axles in wet regolith.",4e4,39),sunvolt:Q("Sunvolt",["solar","volt"],"advanced","rover","Charges in sunlight, discharges in enthusiasm.",42e3,40),phantom:Q("Phantom",["void","neural"],"advanced","android","Appears on cameras that are switched off.",45e3,41),thermocline:Q("Thermocline",["plasma","cryo"],"advanced","crawler","Hot on one side, frozen on the other.",48e3,42),corona:Q("Corona",["solar","plasma","photon"],"elite","orb","A miniature star on a leash."),tsunami:Q("Tsunami",["hydro","kinetic","aero"],"elite","crawler","Moves like a wave and hits like one too."),tectonic:Q("Tectonic",["geo","gravity","kinetic"],"elite","mech","Rearranges continents for practice."),verdant:Q("Verdant",["bio","solar","hydro"],"elite","android","Terraforms a garden wherever it stands."),tesla:Q("Tesla",["volt","alloy","neural"],"elite","android","An inventor bot with a coil for a heart."),borealis:Q("Borealis",["cryo","photon","aero"],"elite","drone","Paints the polar sky in green fire."),nightshade:Q("Nightshade",["void","bio","neural"],"elite","crawler","Beautiful, clever, best kept at arm's length."),chronoforge:Q("Chronoforge",["chrono","plasma","alloy"],"elite","mech","Forges parts it will need tomorrow."),gravwell:Q("Gravwell",["gravity","void","hydro"],"elite","orb","A floating whirlpool that hums."),overclock:Q("Overclock",["volt","chrono","kinetic"],"elite","rover","Runs every process twice as fast. Including naps."),dreadnought:Q("Dreadnought",["alloy","kinetic","gravity"],"elite","mech","Armour plate all the way down."),lumina:Q("Lumina",["photon","bio","neural"],"elite","android","A gardener that glows in the dark."),supernova:Q("Supernova",["solar","plasma","gravity","photon"],"epic","orb","Contains a star's last breath, politely."),leviathan:Q("Leviathan",["hydro","cryo","gravity","kinetic"],"epic","crawler","The deep-ocean bot of Europa legends."),titanforge:Q("Titanforge",["alloy","geo","plasma","kinetic"],"epic","mech","Builds space stations single-handed. It has four hands."),gaia:Q("Gaia",["bio","geo","hydro","solar"],"epic","android","Turns dead rock into living soil."),tempest:Q("Tempest",["aero","volt","hydro","cryo"],"epic","drone","A hurricane that follows instructions."),eventide:Q("Eventide",["void","chrono","photon"],"epic","orb","Lives in the moment between day and night."),hivemind:Q("Hivemind",["neural","bio","alloy","volt"],"epic","crawler","A thousand tiny minds in one shell."),starweaver:Q("Starweaver",["photon","gravity","aero"],"epic","drone","Spins light sails from starlight."),quasar:Q("Quasar",["volt","void","photon","gravity"],"epic","orb","Brighter than a galaxy, smaller than a fridge."),juggernaut:Q("Juggernaut",["kinetic","alloy","gravity","geo"],"epic","mech","Unstoppable. Literally: nobody has tried."),solaris:Q("Solaris Prime",["solar","photon","plasma","neural"],"legendary","android","The first AI to dream of the Sun, and then build one."),abyssal:Q("Abyssal",["void","hydro","gravity","cryo"],"legendary","crawler","From the dark oceans beneath Enceladus."),chronarch:Q("Chronarch",["chrono","neural","photon","void"],"legendary","android","Keeper of every second the colony has lived."),colossus:Q("Colossus",["alloy","kinetic","geo","gravity"],"legendary","mech","A walking fortress the size of a hab block."),seraph:Q("Seraph",["aero","photon","bio","solar"],"legendary","drone","Six wings of light, one gentle voice."),voltaic:Q("Voltaic Storm",["volt","aero","plasma","kinetic"],"legendary","orb","Lightning that learned to fly."),omega:Q("Omega Protocol",["neural","alloy","chrono","kinetic"],"prototype","mech","The last line of code anyone wrote by hand."),genesis:Q("Genesis Engine",["bio","solar","hydro","geo"],"prototype","android","Makes worlds. Small ones, for now."),horizon:Q("Event Horizon",["gravity","void","chrono","photon"],"prototype","orb","Nothing it looks at can look away."),architect:Q("The Architect",["neural","chrono","gravity","photon"],"singularity","orb","It designed itself. Then it designed the rest."),primemover:Q("Prime Mover",["kinetic","plasma","solar","gravity"],"singularity","mech","The engine at the start of everything."),veyari:{...Q("Veyari Gardener",["bio","photon","void"],"legendary","android","A crystalline gardener from Proxima b, a gift from the Veyari to seal first contact."),alien:"contact"},synod:{...Q("Synod Envoy",["alloy","neural","chrono"],"legendary","mech","A delegate of the machine Synod of Barnard's Star. It votes on everything."),alien:"contact"},mycelar:{...Q("Mycelar Sporeling",["bio","neural","hydro"],"epic","crawler","A fragment of Tau Ceti's singing fungal mind, curious about everything."),alien:"contact"},oshoru:{...Q("Oshoru Swimmer",["hydro","aero","kinetic"],"epic","orb","A young Oshoru from TRAPPIST-1e, sent to see the stars."),alien:"contact"},lumenchoir:{...Q("Lumen Choir",["photon","solar","neural"],"prototype","orb","A being of pure light from Epsilon Eridani. It hums in harmonies."),alien:"contact"},krdrone:{...Q("Kr'thul Drone",["void","kinetic"],"advanced","crawler","A Swarm drone, captured and reprogrammed. Still a little bitey."),alien:"swarm"},krwarrior:{...Q("Kr'thul Warrior",["void","kinetic","plasma"],"elite","crawler","A Swarm warrior that now fights for the colony."),alien:"swarm"},solstice:{...Q("Solstice Seraph",["solar","photon","aero"],"legendary","drone","Born in the light of the Solar Solstice. It never casts a shadow."),alien:"event"},champion:{...Q("Arena Champion",["kinetic","alloy","photon"],"legendary","mech","Forged for the Arena Cup. It bows before every fight."),alien:"event"},voyager:{...Q("Deep Voyager",["gravity","void","aero"],"legendary","orb","A Deep Space Week veteran that has seen the edge of the Solar System."),alien:"event"},chimera:{...Q("Chimera Core",["neural","bio","plasma","chrono"],"legendary","crawler","A happy accident of the Fusion Frenzy. Nobody is quite sure what it is."),alien:"event"},blossom:{...Q("Blossom Sentinel",["bio","hydro","photon"],"legendary","android","Guardian of the Garden Gala. Flowers open as it passes."),alien:"event"},anvil:{...Q("Anvil Titan",["alloy","plasma","geo"],"legendary","mech","Built during Forge Fest by every builder drone at once."),alien:"event"},aurorawisp:{...Q("Aurora Wisp",["aurora","relic","bio"],"epic","orb","A Precursor intelligence of Aurora, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},aurorawarden:{...Q("Aurora Warden",["aurora","relic","photon"],"legendary","android","A Precursor intelligence of Aurora, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},auroraprime:{...Q("Aurora Prime",["aurora","relic","solar"],"prototype","drone","A Precursor intelligence of Aurora, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},arcanaglyph:{...Q("Arcana Glyph",["arcana","relic","neural"],"epic","orb","A Precursor intelligence of Arcana, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},arcanamagus:{...Q("Arcana Magus",["arcana","relic","chrono"],"legendary","android","A Precursor intelligence of Arcana, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},arcanaprime:{...Q("Arcana Prime",["arcana","relic","void"],"prototype","orb","A Precursor intelligence of Arcana, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},entropyspark:{...Q("Entropy Spark",["entropy","relic","plasma"],"epic","crawler","A Precursor intelligence of Entropy, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},entropyreaver:{...Q("Entropy Reaver",["entropy","relic","kinetic"],"legendary","mech","A Precursor intelligence of Entropy, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},entropyprime:{...Q("Entropy Prime",["entropy","relic","gravity"],"prototype","orb","A Precursor intelligence of Entropy, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},joysprite:{...Q("Joy Sprite",["joy","relic","aero"],"epic","drone","A Precursor intelligence of Joy, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},joyjester:{...Q("Joy Jester",["joy","relic","volt"],"legendary","android","A Precursor intelligence of Joy, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},joyprime:{...Q("Joy Prime",["joy","relic","photon"],"prototype","orb","A Precursor intelligence of Joy, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},reveriedrifter:{...Q("Reverie Drifter",["reverie","relic","cryo"],"epic","orb","A Precursor intelligence of Reverie, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},reverieoracle:{...Q("Reverie Oracle",["reverie","relic","neural"],"legendary","android","A Precursor intelligence of Reverie, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},reverieprime:{...Q("Reverie Prime",["reverie","relic","hydro"],"prototype","drone","A Precursor intelligence of Reverie, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},soulember:{...Q("Soul Ember",["soul","relic","solar"],"epic","orb","A Precursor intelligence of Soul, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},soulkeeper:{...Q("Soul Keeper",["soul","relic","geo"],"legendary","mech","A Precursor intelligence of Soul, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},soulprime:{...Q("Soul Prime",["soul","relic","chrono"],"prototype","android","A Precursor intelligence of Soul, woken in the Vault. It earns Iridium and never fights."),alien:"relic"},krbrood:{...Q("Kr'thul Brood",["void","bio","gravity","kinetic"],"epic","crawler","A living Swarm carrier. It keeps trying to adopt the other bots."),alien:"swarm"}},Oc=Object.keys(tt),un={solar:{name:"Solar",color:"#ffb23e",glow:"#ffe08a",glyph:"☀",strong:["bio","cryo"],blurb:"Runs on starlight. Hums when the Sun is up."},plasma:{name:"Plasma",color:"#ff5a3c",glow:"#ffb08a",glyph:"♨",strong:["alloy","bio"],blurb:"Contained fire at ten thousand degrees."},hydro:{name:"Hydro",color:"#2f8cff",glow:"#9fd0ff",glyph:"≈",strong:["plasma","geo"],blurb:"Pumps, cleans and cools. Every colony needs water."},cryo:{name:"Cryo",color:"#7fe4ff",glow:"#dff8ff",glyph:"❄",strong:["aero","bio"],blurb:"Supercooled circuits, near absolute zero."},geo:{name:"Geo",color:"#b07a4a",glow:"#e2b48c",glyph:"▲",strong:["volt","plasma"],blurb:"Drills, diggers and regolith movers."},bio:{name:"Bio",color:"#4fcf5a",glow:"#b6ffb0",glyph:"❦",strong:["hydro","geo"],blurb:"Gardeners of greenhouses and living hulls."},volt:{name:"Volt",color:"#ffe23a",glow:"#fff6a8",glyph:"ϟ",strong:["hydro","aero"],blurb:"Lightning in a capacitor."},alloy:{name:"Alloy",color:"#9aa7b8",glow:"#e6edf5",glyph:"⚙",strong:["cryo","kinetic"],blurb:"Armour, welders and heavy lifting."},void:{name:"Void",color:"#6b3fd6",glow:"#c2a6ff",glyph:"◐",strong:["photon","neural"],blurb:"Built for the dark between stars."},photon:{name:"Photon",color:"#fff4c2",glow:"#ffffff",glyph:"✦",strong:["void","chrono"],blurb:"Lasers, lenses and light."},kinetic:{name:"Kinetic",color:"#ff7a1a",glow:"#ffc28a",glyph:"✊",strong:["alloy","gravity"],blurb:"Impact, momentum, mass drivers."},aero:{name:"Aero",color:"#b9f0e6",glow:"#ecfffb",glyph:"༄",strong:["geo","kinetic"],blurb:"Flyers and atmosphere shapers."},gravity:{name:"Gravity",color:"#3c4aa8",glow:"#9aa6ff",glyph:"◉",strong:["aero","photon"],blurb:"Bends space a little, on purpose."},chrono:{name:"Chrono",color:"#c9a2ff",glow:"#eedcff",glyph:"⧗",strong:["neural","volt"],blurb:"Clocks running a little sideways."},neural:{name:"Neural",color:"#ff6fd8",glow:"#ffc4f0",glyph:"✺",strong:["kinetic","gravity"],blurb:"Artificial minds. They learn from everything."},relic:{name:"Relic",color:"#d8b46a",glow:"#fff0c4",glyph:"⌬",relic:!0,strong:[],blurb:"Precursor make, older than our species."},aurora:{name:"Aurora",color:"#6fffc8",glow:"#d6fff0",glyph:"❈",relic:!0,strong:[],blurb:"Beauty as a power source."},arcana:{name:"Arcana",color:"#8a5cff",glow:"#d7c6ff",glyph:"✧",relic:!0,strong:[],blurb:"Technology indistinguishable from magic."},entropy:{name:"Entropy",color:"#ff3d6e",glow:"#ffb3c6",glyph:"✹",relic:!0,strong:[],blurb:"Chaos, harnessed."},joy:{name:"Joy",color:"#ffd24a",glow:"#fff2b8",glyph:"☺",relic:!0,strong:[],blurb:"Precursor machines made to be happy."},reverie:{name:"Reverie",color:"#7aa8ff",glow:"#d2e2ff",glyph:"☾",relic:!0,strong:[],blurb:"They dream in mathematics."},soul:{name:"Soul",color:"#f2f2ff",glow:"#ffffff",glyph:"❂",relic:!0,strong:[],blurb:"Something in them is alive."}},d_=Object.keys(un).filter(i=>!un[i].relic),Nn={standard:{name:"Standard",color:"#b9c3cf",earn:10,power:1,fuseChance:1,assembly:30},advanced:{name:"Advanced",color:"#5fdc7a",earn:15,power:1.2,fuseChance:.6,assembly:600},elite:{name:"Elite",color:"#4aa8ff",earn:22,power:1.45,fuseChance:.35,assembly:3600},epic:{name:"Epic",color:"#b06dff",earn:34,power:1.75,fuseChance:.18,assembly:4*3600},legendary:{name:"Legendary",color:"#ffa53a",earn:52,power:2.1,fuseChance:.08,assembly:12*3600},prototype:{name:"Prototype",color:"#ff4f6a",earn:80,power:2.6,fuseChance:.035,assembly:24*3600},singularity:{name:"Singularity",color:"#7af7ff",earn:125,power:3.2,fuseChance:.015,assembly:48*3600}},kc=Object.keys(Nn),Rn="#2c3340",ya="#cdd5df";function xf(i,e=1){const t=tt[i],n=un[t.el[0]].color,s=t.el[1]?un[t.el[1]].color:Un(n,-.35),r=Nn[t.rarity].color,a=new yt,o=new Qe;let c=0;const l=v=>(a.add(v),v),h=v=>{const p=new Qe;return v(p),p.build()};let d=()=>{};switch(t.chassis){case"orb":{c=.55,o.sphere(.26,n,0,0,0,{w:14,h:10}),o.sphere(.27,s,0,0,0,{w:14,h:4,theta:Math.PI*.18}),o.sphere(.09,r,0,.02,.22,{glow:!0,w:8,h:6}),o.sphere(.05,"#ffffff",.02,.05,.27,{glow:!0,w:6,h:4});const v=l(h(p=>p.add(new Dr(.38,.025,5,28),s)));v.rotation.x=Math.PI/2.4,d=p=>{v.rotation.z=p*1.8};break}case"drone":{c=.6,o.box(.34,.14,.34,n,0,-.07,0),o.sphere(.16,s,0,.05,0,{theta:Math.PI/2,w:10,h:5}),o.box(.12,.05,.02,r,0,-.01,.18,{glow:!0});const v=[];for(const[p,m]of[[.28,.28],[-.28,.28],[.28,-.28],[-.28,-.28]]){o.box(.24,.03,.04,Rn,p/2,0,m/2,{ry:Math.atan2(p,m)});const x=l(h(S=>{S.cyl(.13,.13,.012,10,ya,0,0,0,{glass:!0}),S.box(.24,.01,.03,Rn)}));x.position.set(p,.02,m),v.push(x)}d=p=>v.forEach((m,x)=>{m.rotation.y=p*30*(x%2?1:-1)});break}case"rover":{o.box(.5,.18,.36,n,0,.12,0),o.box(.3,.1,.3,s,-.05,.3,0),o.cyl(.02,.02,.22,5,ya,.12,.3,0),o.box(.14,.08,.08,Rn,.12,.52,0),o.box(.02,.04,.06,r,.19,.53,0,{glow:!0});const v=[];for(const[p,m]of[[.17,.2],[-.17,.2],[.17,-.2],[-.17,-.2]]){const x=l(h(S=>S.cyl(.09,.09,.07,10,Rn,0,-.035,0,{rx:Math.PI/2})));x.position.set(p,.09,m),v.push(x)}i==="digger"&&o.add(new Xn(.08,.22,7),ya,.32,.18,0,{rz:-Math.PI/2}),i==="ember"&&o.cyl(.035,.035,.2,5,Rn,.25,.28,0,{rz:-.9}),d=(p,m)=>v.forEach(x=>{x.rotation.z=m?-p*8:0});break}case"walker":{const v=l(h(m=>{m.box(.36,.22,.3,n,0,0,0),m.box(.3,.06,.26,s,0,.22,0),m.box(.14,.05,.02,r,.06,.12,.16,{glow:!0}),m.box(.06,.05,.02,r,-.08,.12,.16,{glow:!0})}));v.position.y=.34;const p=[];for(const m of[.11,-.11]){const x=l(h(S=>{S.box(.07,.32,.07,Rn,0,-.32,0),S.box(.13,.04,.16,s,0,-.34,.02)}));x.position.set(m,.36,0),p.push(x)}d=(m,x)=>{p.forEach((S,b)=>{S.rotation.x=x?Math.sin(m*9+b*Math.PI)*.5:0}),v.position.y=.34+(x?Math.abs(Math.sin(m*9))*.03:0)};break}case"android":{const v=l(h(m=>{m.box(.24,.3,.16,n,0,0,0),m.box(.26,.06,.18,s,0,.24,0),m.sphere(.12,ya,0,.42,0,{w:10,h:8}),m.box(.18,.05,.05,r,0,.43,.09,{glow:!0}),m.sphere(.035,r,0,.12,.085,{glow:!0,w:6,h:4})}));v.position.y=.3;const p=[];for(const[m,x,S,b]of[[.16,.56,.26,s],[-.16,.56,.26,s],[.07,.3,.3,Rn],[-.07,.3,.3,Rn]]){const A=l(h(E=>E.box(.07,S,.07,b,0,-S,0)));A.position.set(m,x,0),p.push(A)}i==="sprout"&&o.add(new Pr(.08,0),"#5fdc5a",0,.86,0),d=(m,x)=>{p.forEach((S,b)=>{S.rotation.x=x?Math.sin(m*8+b%2*Math.PI+(b>1?Math.PI:0))*.55:Math.sin(m*1.5+b)*.05})};break}case"mech":{const v=l(h(m=>{m.box(.46,.34,.34,n,0,0,0),m.box(.2,.12,.2,s,0,.34,0),m.box(.16,.05,.02,r,0,.4,.105,{glow:!0});for(const x of[.29,-.29])m.box(.14,.14,.2,s,x,.16,0),m.box(.11,.3,.11,Rn,x,-.14,.02)}));v.position.y=.36;const p=[];for(const m of[.13,-.13]){const x=l(h(S=>{S.box(.12,.34,.12,Rn,0,-.34,0),S.box(.18,.05,.22,s,0,-.36,.02)}));x.position.set(m,.38,0),p.push(x)}d=(m,x)=>{p.forEach((S,b)=>{S.rotation.x=x?Math.sin(m*5+b*Math.PI)*.35:0}),v.rotation.y=x?Math.sin(m*5)*.06:0};break}case"crawler":{const v=l(h(m=>{m.sphere(.16,n,.18,0,0,{w:10,h:7}),m.sphere(.13,s,0,0,0,{w:10,h:7}),m.sphere(.11,n,-.16,0,0,{w:10,h:7}),m.sphere(.035,r,.31,.04,.06,{glow:!0,w:6,h:4}),m.sphere(.035,r,.31,.04,-.06,{glow:!0,w:6,h:4})}));v.position.y=.2;const p=[];for(let m=0;m<6;m++){const x=.16-(m>>1)*.16,S=m%2?1:-1,b=l(h(A=>A.box(.03,.03,.24,Rn,0,0,.1*S)));b.position.set(x,.18,.08*S),b.rotation.x=.5*S,p.push(b)}d=(m,x)=>p.forEach((S,b)=>{S.rotation.y=x?Math.sin(m*14+b)*.35:0});break}}const u=o.build("bot");a.add(u),(t.chassis==="orb"||t.chassis==="drone")&&(u.position.y=0);const f=new yt;for(;a.children.length;)f.add(a.children[0]);if(f.position.y=c,a.add(f),c){const v=new je(new Cc(.22,12),new Ht({color:un[t.el[0]].glow,transparent:!0,opacity:.35,depthWrite:!1}));v.rotation.x=-Math.PI/2,v.position.y=.02,v.name="hoverGlow",a.add(v)}const g=.95+kc.indexOf(t.rarity)*.08+Math.min(.25,(e-1)*.008);return a.scale.setScalar(g),a.traverse(v=>{v.isMesh&&(v.castShadow=!0)}),{group:a,hover:c,anim:(v,p)=>{d(v,p),c&&(f.position.y=c+Math.sin(v*2.2+e)*.05)}}}const Id=ji/2,Nd=["#f2f4f7","#ff8a3c","#2f6fd0","#22c7e8","#f5c542","#e9edf2"],Ud=["#f1c9a5","#d9a47c","#a86d4a","#7a4a2e","#ffdcbc"];class u_{constructor(e,t){this.group=new yt,this.people=[],this.bots=new Map,this.doors=[],this.m4=new Ke,this.q=new vi,this.max=t==="high"?48:24;const n=new Rc(.075,.18,3,6);n.translate(0,.17,0);const s=new sn(.06,8,6);s.translate(0,.38,0),this.body=new Ol(n,new Qi({color:"#ffffff",roughness:.7}),this.max),this.head=new Ol(s,new Qi({color:"#ffffff",roughness:.6}),this.max);const r=new Te;for(let a=0;a<this.max;a++)this.body.setColorAt(a,r.set(Nd[a%Nd.length])),this.head.setColorAt(a,r.set(Ud[a*7%Ud.length]));this.body.castShadow=!0,this.body.count=0,this.head.count=0,this.group.add(this.body,this.head),e.add(this.group)}sync(e,t,n){const s=e.bases[t];if(!s)return;this.doors=s.items.filter(l=>l.lvl>0).map(l=>f_(l));const r=Math.min(this.max,Math.round(2+this.doors.length*1.6));for(;this.people.length<r&&this.doors.length;){const l=this.doors[Math.floor(Math.random()*this.doors.length)].clone();this.people.push({p:l,path:[],wait:Math.random()*3,speed:.7+Math.random()*.5,ph:Math.random()*6})}this.people.length=Math.min(this.people.length,r),this.body.count=this.head.count=this.people.length;const a=new Set,o=s.items.filter(l=>l.b==="dock"&&l.lvl>0);let c=0;for(const l of n.slice(0,this.max)){let h,d=!1;if(l.post&&l.post.base===t?(h=Ct(e,t,l.post.item),d=!0):!l.post&&o.length&&(h=o[c++%o.length]),!h)continue;a.add(l.id);let u=this.bots.get(l.id);const f=h.id;if(!u||u.home!==f){u&&this.group.remove(u.m.group);const g=xf(l.sp,l.lvl);g.group.scale.setScalar(.85);const p=Yl(h).clone().add(new P((Math.random()-.5)*1.2,0,(Math.random()-.5)*1.2));g.group.position.copy(p),this.group.add(g.group),u={m:g,home:f,pos:p,target:p.clone(),wait:0,working:d},this.bots.set(l.id,u)}u.working=d}for(const[l,h]of this.bots)a.has(l)||(this.group.remove(h.m.group),this.bots.delete(l))}frame(e,t,n,s){const r=e.bases[t];if(r){this.people.forEach((a,o)=>{if(a.wait>0)a.wait-=s;else if(a.path.length){const l=a.path[0],h=l.x-a.p.x,d=l.z-a.p.z,u=Math.hypot(h,d),f=a.speed*s;u<=f?(a.p.copy(l),a.path.shift()):(a.p.x+=h/u*f,a.p.z+=d/u*f,a.ph=Math.atan2(h,d))}else{if(this.doors.length){const l=this.doors[Math.floor(Math.random()*this.doors.length)];a.path=[new P(l.x,0,a.p.z),l.clone()]}a.wait=1+Math.random()*4}const c=a.path.length?Math.abs(Math.sin(n*9+o))*.03:0;this.q.setFromEuler(new On(0,a.ph,0)),this.m4.compose(new P(a.p.x,c,a.p.z),this.q,new P(1,1,1)),this.body.setMatrixAt(o,this.m4),this.head.setMatrixAt(o,this.m4)}),this.body.instanceMatrix.needsUpdate=!0,this.head.instanceMatrix.needsUpdate=!0;for(const a of this.bots.values()){const o=r.items.find(d=>d.id===a.home);if(!o)continue;const c=Yl(o),[l,h]=on(o.b,o.r);if(a.wait>0)a.wait-=s;else{const d=a.target.x-a.pos.x,u=a.target.z-a.pos.z,f=Math.hypot(d,u);if(f<.05)a.target.set(c.x+(Math.random()-.5)*(l+.6),0,c.z+(Math.random()-.5)*(h+.6)),Math.abs(a.target.x-c.x)<l/2-.2&&Math.abs(a.target.z-c.z)<h/2-.2&&(a.target.z=c.z+(h/2+.35)*Math.sign(a.target.z-c.z||1)),a.wait=a.working?.5+Math.random()*2:1+Math.random()*3;else{const g=.8*s;a.pos.x+=d/f*Math.min(g,f),a.pos.z+=u/f*Math.min(g,f),a.m.group.rotation.y=Math.atan2(d,u)}}a.m.group.position.set(a.pos.x,.05+(a.m.hover?a.m.hover*.6:0),a.pos.z),a.m.anim(n,a.wait<=0)}}}clear(){for(const e of this.bots.values())this.group.remove(e.m.group);this.bots.clear(),this.people=[],this.body.count=this.head.count=0}}function Yl(i){const[e,t]=on(i.b,i.r);return new P(i.x+e/2-Id,0,i.z+t/2-Id)}function f_(i){const[e,t]=on(i.b,i.r),n=Yl(i);return new P(n.x+(Math.random()-.5)*e*.5,0,n.z+t/2+.25)}const Bc={hq:["neural","chrono"],research:["neural","chrono","photon"],university:["neural","chrono"],llab:["neural","photon","chrono"],xenolab:["neural","void"],mine:["geo","kinetic"],regolith:["geo","kinetic"],refinery:["cryo","plasma"],ice:["hydro","cryo"],methane:["cryo","hydro"],he3x:["geo","plasma"],office:["neural","photon"],dome:["bio","neural"],solar:["solar","photon"],lsolar:["solar","photon"],fission:["plasma","volt"],fusion:["plasma","volt"],reactor:["plasma","volt"],depot:["alloy","gravity"],launch:["aero","gravity"],vab:["alloy","gravity","kinetic"],tracking:["photon","aero"],academy:["neural","bio"],greenhouse:["bio","hydro"],terraformer:["bio","aero"],beltControl:["gravity","kinetic"],casimir:["void","gravity"],antimatter:["void","plasma"],elevator:["gravity","alloy"],massDriver:["kinetic","gravity"],workshop:["alloy","kinetic"],cellplant:["volt","solar"],fusionlab:["neural","chrono"]},p_={launch:"launch reliability",vab:"rocket assembly speed",workshop:"core assembly speed",fusionlab:"fusion speed",academy:"crewed-flight safety",depot:"storage"},m_=[.08,.12,.18,.26,.38,.55,.8],g_=1,v_=.35,yf=2,bf=30,_f=(i,e)=>i==="dock"||!Bc[i]||e<=0?0:1+(e>=8?1:0)+(e>=16?1:0),x_=i=>i<=0?0:3+i,y_=(i,e)=>Math.round(20*Math.pow(1.17,i-1)*(1+.45*e)/5)*5,zc=[{name:"Standard core",rarity:0,cost:{credits:800,metal:600,cells:60},ws:1,desc:"A single-element robot: dependable, cheap, quick to boot."},{name:"Advanced core",rarity:1,cost:{credits:9e3,metal:7e3,cells:400},ws:5,desc:"A two-element robot that suits more jobs."},{name:"Elite core",rarity:2,cost:{credits:9e4,metal:7e4,cells:3e3},ws:12,desc:"A three-element specialist, rarely seen outside fusion labs."}],b_=[2,4,8,15,30,60,120],ur=4,__=["helio","digger"],wt=i=>i.robots||(i.robots={list:[],dex:{},cores:[],made:0}),tn=i=>kc.indexOf(tt[i].rarity),Kl=i=>Object.values(i.bases).reduce((e,t)=>e+t.items.filter(n=>n.b==="dock").reduce((n,s)=>n+x_(s.lvl),0),0),Li=i=>Sn(i,"earth","workshop"),Gc=i=>Sn(i,"earth","fusionlab"),Mf=i=>Li(i)?1+Math.floor(Li(i)/5):0,Sf=i=>i.jobs.filter(e=>e.kind==="core").length,Bn=(i,e)=>wt(i).list.find(t=>t.id===e)||null,wf=i=>Object.keys(wt(i).dex).filter(e=>tt[e]).length,Fd=()=>Oc.filter(i=>!tt[i].alien||["event","swarm","contact"].includes(String(tt[i].alien))),nr=(i,e)=>tt[i].el.some(t=>(Bc[e]||[]).includes(t)),Xi=(i,e)=>m_[tn(i.sp)]*(1+.035*(i.lvl-1))*(nr(i.sp,e)?g_:v_),oo=(i,e,t)=>wt(i).list.filter(n=>n.post&&n.post.base===e&&n.post.item===t);function Ef(i,e,t){const n=Ct(i,e,t);if(!n)return 0;let s=0;for(const r of oo(i,e,t))s+=Xi(r,n.b);return Math.min(yf,s)}function M_(i){const e={};for(const t of wt(i).list){if(!t.post)continue;const n=Ct(i,t.post.base,t.post.item);if(!n){t.post=null;continue}e[n.id]=Math.min(yf,(e[n.id]||0)+Xi(t,n.b))}return e}function S_(i,e,t,n){const s=Bn(i,e),r=Ct(i,t,n);if(!s||!r)return{ok:!1,why:"Gone"};if(r.lvl<1)return{ok:!1,why:"Under construction"};const a=_f(r.b,r.lvl);return a?s.post&&s.post.item===n?{ok:!1,why:"Already working here"}:oo(i,t,n).length>=a?{ok:!1,why:`All ${a} operator station${a>1?"s are":" is"} taken${r.lvl<16?" (more at levels 8 and 16)":""}`}:{ok:!0}:{ok:!1,why:"No operator stations here"}}function w_(i,e,t,n){const s=S_(i,e,t,n);return s.ok&&(Bn(i,e).post={base:t,item:n}),s}function E_(i,e){const t=Bn(i,e);t&&(t.post=null)}const A_=(i,e)=>Math.max(10,Math.round(Nn[tt[e].rarity].assembly*(1-.03*(Li(i)-1))/(1+Af(i,"workshop")))),Af=(i,e)=>{const t=i.bases.earth?.items.find(n=>n.b===e);return t?Ef(i,"earth",t.id):0},T_=(i,e)=>{const t=Oc.filter(s=>!tt[s].alien&&tn(s)===i),n=e?t.filter(s=>tt[s].el.includes(e)):[];return n.length?n:t};function Tf(i,e){const t=zc[e];return t?Li(i)?Li(i)<t.ws?{ok:!1,why:`Robotics Workshop level ${t.ws}`,locked:!0}:Sf(i)>=Mf(i)?{ok:!1,why:"All assembly bays are busy",busy:!0}:es(i,t.cost)?{ok:!0,cost:t.cost}:{ok:!1,why:"Not enough resources",cost:t.cost}:{ok:!1,why:"Build the Robotics Workshop",locked:!0}:{ok:!1}}function R_(i,e,t,n=Date.now()){const s=Tf(i,e);if(!s.ok)return s;Ii(i,s.cost);const r=ja(rp(i.created+":"+wt(i).made++)),a=T_(zc[e].rarity,t),o=a[Math.floor(r()*a.length)],c=A_(i,o);return i.jobs.push({id:Yn(i),kind:"core",sp:o,src:"workshop",start:n,end:n+c*1e3}),{...s,sp:o,time:c}}function Rf(i,e){return wt(i).cores.some(t=>t.id===e)?wt(i).list.length>=Kl(i)?{ok:!1,why:Kl(i)?"Every dock is full: build or upgrade a Robot Dock":"Build a Robot Dock first",full:!0}:{ok:!0}:{ok:!1}}function C_(i,e,t=Date.now()){const n=Rf(i,e);if(!n.ok)return n;const s=wt(i),r=s.cores.find(c=>c.id===e);s.cores=s.cores.filter(c=>c!==r);const a={id:Yn(i,"r"),sp:r.sp,lvl:1,post:null,born:t};s.list.push(a),i.stats.robots=s.list.length;let o=0;return s.dex[r.sp]||(s.dex[r.sp]=t,o=b_[tn(r.sp)],i.res.dm=(i.res.dm||0)+o),{ok:!0,robot:a,dm:o}}const Hc=(i,e,t="gift")=>{wt(i).cores.push({id:Yn(i,"c"),sp:e,from:t})};function Cf(i,e){const t=Bn(i,e);if(!t)return{ok:!1};if(t.lvl>=bf)return{ok:!1,why:"Maximum level",max:!0};const n=y_(t.lvl,tn(t.sp));return(i.res.cells||0)<n?{ok:!1,why:"Not enough Power Cells",cost:{cells:n}}:{ok:!0,cost:{cells:n}}}function P_(i,e){const t=Cf(i,e);if(!t.ok)return t;Ii(i,t.cost);const n=Bn(i,e);return n.lvl++,i.stats.feeds=(i.stats.feeds||0)+1,{...t,lvl:n.lvl}}function Pf(i,e){const t=tt[i.sp],n=tt[e.sp],s=new Set([...t.el,...n.el]),r=tn(i.sp),a=tn(e.sp),o=Math.min(r,a),c=Math.max(r,a),l=[];for(const d of Oc){const u=tt[d],f=tn(d),g=d===i.sp||d===e.sp;u.alien&&!g||!g&&(!u.el.every(v=>s.has(v))||!u.el.some(v=>t.el.includes(v))||!u.el.some(v=>n.el.includes(v))||u.el.length<2||f<(o>=2?o:o-1)||f===3&&c<1||f===4&&o<2||f===5&&o<3||f===6&&o<4||f>c+2)||l.push({sp:d,w:Nn[u.rarity].fuseChance*(g?1.3:1)})}const h=l.reduce((d,u)=>d+u.w,0);return l.map(d=>({sp:d.sp,p:d.w/h})).sort((d,u)=>tn(u.sp)-tn(d.sp)||u.p-d.p)}const Lf=(i,e)=>{const t=tn(i.sp),n=tn(e.sp);return{credits:Math.round(300*(1+t)*(1+n)*Math.pow(1.8,Math.max(t,n))),cells:Math.round(40*(1+t+n))}},L_=(i,e)=>Math.max(20,Math.round(Nn[tt[e].rarity].assembly*1.2*(1-.05*(Gc(i)-1))/(1+Af(i,"fusionlab"))));function Df(i,e,t){if(!Gc(i))return{ok:!1,why:"Build the Fusion Lab",locked:!0};const n=i.bases.earth.items.find(o=>o.b==="fusionlab");if(Ci(i,n.id))return{ok:!1,why:"The Fusion Lab is being upgraded"};if(i.jobs.some(o=>o.kind==="fuse"))return{ok:!1,why:"Already fusing",busy:!0};const s=Bn(i,e),r=Bn(i,t);if(!s||!r)return{ok:!1,why:"Pick two robots"};if(s===r)return{ok:!1,why:"Pick two different robots"};if(s.lvl<ur||r.lvl<ur)return{ok:!1,why:`Both parents need level ${ur}`};const a=Lf(s,r);return es(i,a)?{ok:!0,cost:a}:{ok:!1,why:"Not enough resources",cost:a}}function D_(i,e,t,n=Date.now()){const s=Df(i,e,t);if(!s.ok)return s;Ii(i,s.cost);const r=Pf(Bn(i,e),Bn(i,t));let a=Math.random(),o=r[r.length-1].sp;for(const l of r)if(a-=l.p,a<=0){o=l.sp;break}const c=L_(i,o);return i.jobs.push({id:Yn(i),kind:"fuse",sp:o,start:n,end:n+c*1e3}),i.stats.fusions=(i.stats.fusions||0)+1,{...s,sp:o,time:c}}Fs.core=(i,e)=>(Hc(i,e.sp,e.src||"workshop"),{kind:"core",sp:e.sp});Fs.fuse=(i,e)=>(Hc(i,e.sp,"fusion"),{kind:"core",sp:e.sp,fused:!0});function I_(i,e){if(e==="workshop"&&!i.flags.starters){i.flags.starters=1;for(const t of __)Hc(i,t,"gift");nc.push({kind:"starters"})}}Kd.push(i=>M_(i));ic.push(I_);Ni.robots=(i,e)=>wt(i).list.length>=e.n;Ni.dex=(i,e)=>wf(i)>=e.n;Ni.operators=(i,e)=>wt(i).list.filter(t=>t.post).length>=e.n;const Rs={solid:{name:"Solid motor",P:1,E:.6,R:.86,cost:{credits:400,metal:330,fuel:130},req:"rocketry",color:"#e8e8e8",desc:"Simple, cheap and punchy. Lights once and burns until empty."},kerolox:{name:"Kerolox engine",P:1.6,E:1,R:.89,cost:{credits:600,metal:650,fuel:230},req:"liquidProp",color:"#3a3f47",desc:"Kerosene and liquid oxygen: throttleable, restartable, the workhorse of the early space age."},hydrolox:{name:"Hydrolox engine",P:1.4,E:1.6,R:.9,cost:{credits:1300,metal:1600,fuel:700},req:"cryo",color:"#c9d6e6",desc:"Liquid hydrogen: the most efficient chemical rocket, superb for upper stages."},methalox:{name:"Methalox engine",P:2.2,E:1.3,R:.93,cost:{credits:2500,metal:3e3,fuel:1100},req:"reusable",color:"#8a929c",desc:"Full-flow methane engines: powerful, clean-burning and built to fly again and again."},nuclear:{name:"Nuclear thermal",P:1,E:3,R:.92,cost:{credits:6e3,metal:8e3,fuel:3e3},req:"nuclearThermal",upper:!0,color:"#d9c34a",desc:"A reactor heats hydrogen to 2,500 °C. Upper stages only: never lit in the atmosphere."}},$n={S:{name:"S",cap:1,cost:1,vab:0,r:.26,h:1},M:{name:"M",cap:1.6,cost:2.2,vab:1,r:.34,h:1.45},L:{name:"L",cap:2.6,cost:5,vab:3,r:.44,h:2},XL:{name:"XL",cap:4.2,cost:12,vab:5,req:"heavy",r:.56,h:2.6},XXL:{name:"XXL",cap:7,cost:30,vab:7,req:"reusable",r:.7,h:3.3}},Ar={probe:{name:"Probe nose",cost:{credits:150,metal:100},h:.6,desc:"A pointed nose over instruments or a small satellite."},fairing:{name:"Payload fairing",cost:{credits:900,metal:1100},req:"orbital",h:1.1,desc:"A big clamshell for satellites and station modules."},capsule:{name:"Crew capsule",cost:{credits:5e3,metal:4e3,fuel:600},req:"crewed",crew:!0,h:1,desc:"Seats, life support and a launch-escape tower. Needed for crewed missions."},lander:{name:"Lunar lander",cost:{credits:22e3,metal:26e3,fuel:6e3},req:"lunarLanders",crew:!0,lander:!0,h:1.6,desc:"A capsule riding a legged descent stage. Needed to land people on another world."}},Za=[null,"multistage","orbital"],If={2:"multistage",4:"heavy"},Ei=[.5,4,10,22,45,90,180,360],Qs=[.1,1.2,9,28,120,400,1200,4e3],Od=["","Sounding rocket","Light launcher","Medium launcher","Heavy lifter","Super-heavy","Nuclear shuttle","Interplanetary","Deep-space"];function Di(i){let e=0,t=1,n=0;const s={},r=(u,f=1)=>{for(const g in u)s[g]=(s[g]||0)+u[g]*f},a=new Set;if(i.stages.forEach((u,f)=>{const g=Rs[u.eng],v=$n[u.tank];!g||!v||(e+=g.P*v.cap*Math.sqrt(g.E)*(f>0?1.4:1),t=Math.min(t,g.R),r(g.cost,v.cost),n=Math.max(n,v.vab),a.add(g.req),v.req&&a.add(v.req),Za[f]&&a.add(Za[f]))}),i.boost.n>0){const u=$n[i.boost.tank];e+=i.boost.n*1.2*u.cap,t=Math.min(t,Rs.solid.R+.06-.003*i.boost.n),r(Rs.solid.cost,u.cost*.6*i.boost.n),n=Math.max(n,u.vab,1),a.add(If[i.boost.n]||"multistage"),u.req&&a.add(u.req)}t-=.012*(i.stages.length-1),i.stages.length>1&&(n=Math.max(n,1));const o=Ar[i.top]||Ar.probe;if(r(o.cost),o.req&&a.add(o.req),i.legs){for(const u in s)s[u]*=1.2;a.add("reusable"),t+=.01}let c=0;for(let u=0;u<Ei.length;u++)e>=Ei[u]&&(c=u+1);const l=c===0?0:c>=Ei.length?Qs[Qs.length-1]*e/Ei[Ei.length-1]:Qs[c-1]*Math.pow(Qs[c]/Qs[c-1],(e-Ei[c-1])/(Ei[c]-Ei[c-1]));for(const u in s)s[u]=Math.round(s[u]/10)*10;const h=Math.round(120*Math.pow(Math.max(.7,e),1.6)*(o.crew?1.3:1)),d=i.stages.reduce((u,f)=>u+($n[f.tank]?.h||1),0)+o.h+.3;return{D:e,cls:c,payload:l,rel:Math.max(.05,Math.min(.99,t)),cost:s,time:h,vab:n,height:d,reqs:[...a],crew:!!o.crew,lander:!!o.lander}}const Nf=[{id:"kestrel",name:"Kestrel",stages:[{eng:"solid",tank:"S"}],boost:{n:0,tank:"S"},top:"probe",legs:!1},{id:"swift",name:"Swift",stages:[{eng:"kerolox",tank:"M"},{eng:"kerolox",tank:"S"}],boost:{n:0,tank:"S"},top:"probe",legs:!1},{id:"meridian",name:"Meridian",stages:[{eng:"kerolox",tank:"L"},{eng:"kerolox",tank:"M"}],boost:{n:2,tank:"M"},top:"fairing",legs:!1},{id:"meridianCrew",name:"Meridian Crew",stages:[{eng:"kerolox",tank:"L"},{eng:"kerolox",tank:"M"}],boost:{n:2,tank:"M"},top:"capsule",legs:!1},{id:"colossus",name:"Colossus",stages:[{eng:"hydrolox",tank:"XL"},{eng:"hydrolox",tank:"L"}],boost:{n:4,tank:"L"},top:"fairing",legs:!1},{id:"colossusLunar",name:"Colossus Lunar",stages:[{eng:"hydrolox",tank:"XL"},{eng:"hydrolox",tank:"L"}],boost:{n:4,tank:"L"},top:"lander",legs:!1},{id:"leviathan",name:"Leviathan",stages:[{eng:"methalox",tank:"XXL"},{eng:"methalox",tank:"XL"}],boost:{n:4,tank:"XL"},top:"fairing",legs:!0}];function Jl(i,e){const t=new Qe,n="#f2f4f7",s=e.accent,r="#2f343c";let a=0;const o=$n[i.stages[0]?.tank||"S"];if(i.legs)for(let u=0;u<4;u++){const f=u/4*Math.PI*2+Math.PI/4;t.box(.05,.7,.05,r,Math.cos(f)*(o.r+.12),-.1,Math.sin(f)*(o.r+.12),{rz:Math.cos(f)*.35,rx:-Math.sin(f)*.35})}i.stages.forEach((u,f)=>{const g=$n[u.tank],v=Rs[u.eng],p=g.r*(f>0?.92:1);if(f===0){const m=v.P>=2?7:v.P>=1.5?3:1;for(let x=0;x<m;x++){const S=x/Math.max(1,m-1)*Math.PI*2,b=m>1&&x>0?p*.55:0;t.add(new fi(p*(m>1?.18:.42),p*(m>1?.3:.62),.32,10,1,!0),v.color,Math.cos(S)*b,0,Math.sin(S)*b)}a=.16}if(t.cyl(p,p,g.h,16,n,0,a,0),t.cyl(p+.01,p+.01,g.h*.08,16,f%2?r:s,0,a+g.h*.7,0),f===0&&t.cyl(p+.012,p+.012,g.h*.05,16,r,0,a+g.h*.25,0),v.req==="nuclearThermal"&&t.cyl(p*1.02,p*1.02,g.h*.18,16,"#d9c34a",0,a+g.h*.05,0),a+=g.h,f<i.stages.length-1){const m=$n[i.stages[f+1].tank].r*.92;t.cyl(m,p,.18,16,r,0,a,0),a+=.18}});const c=$n[i.stages[i.stages.length-1]?.tank||"S"].r*.92,l=Ar[i.top]||Ar.probe;if(i.top==="fairing"){const u=Math.max(c*1.15,.34);t.cyl(u,c,.2,16,n,0,a,0);const f=[];for(let g=0;g<=10;g++){const v=g/10;f.push(new fe(u*Math.cos(v*Math.PI/2*.95)**.7,.2+v*l.h))}t.add(new so(f,16),n,0,a,0),t.cyl(u+.01,u+.01,.06,16,s,0,a+.3,0),a+=l.h+.2}else if(i.top==="capsule"||i.top==="lander"){if(i.top==="lander"){t.box(c*1.5,.5,c*1.5,"#d9a82e",0,a,0);for(let u=0;u<4;u++){const f=u/4*Math.PI*2;t.box(.04,.45,.04,"#9aa3ad",Math.cos(f)*c*.95,a-.12,Math.sin(f)*c*.95,{rz:Math.cos(f)*.5,rx:-Math.sin(f)*.5})}a+=.5}t.cyl(c*.45,c*.95,.55,16,"#e6e9ee",0,a,0),t.cyl(c*.96,c*.96,.04,16,s,0,a,0),t.box(.12,.08,.02,"#4fb3ff",c*.35,a+.28,c*.66,{glass:!0}),a+=.55,t.cyl(.03,.03,.55,5,"#c0392b",0,a,0),t.cyl(0,.07,.18,8,"#c0392b",0,a+.55,0),a+=.75}else t.add(new Xn(c,l.h,16),n,0,a+l.h/2,0),t.cyl(c+.01,c+.01,.05,16,s,0,a+.02,0),a+=l.h;if(i.boost.n>0){const u=$n[i.boost.tank],f=u.r*.5,g=u.h*1.25;for(let v=0;v<i.boost.n;v++){const p=v/i.boost.n*Math.PI*2+(i.boost.n===2?0:Math.PI/4),m=Math.cos(p)*(o.r+f*.95),x=Math.sin(p)*(o.r+f*.95);t.add(new fi(f*.5,f*.8,.22,10,1,!0),r,m,0,x),t.cyl(f,f,g,12,n,m,.1,x),t.cyl(f+.01,f+.01,.1,12,r,m,.1+g*.3,x),t.cyl(f+.01,f+.01,.1,12,r,m,.1+g*.65,x),t.add(new Xn(f,f*2.2,12),n,m,.1+g+f*1.1,x)}}const h=t.build("rocket");h.traverse(u=>{const f=u;f.isMesh&&(f.castShadow=!0)});const d=new je(new Xn(Math.max(.18,o.r*.9),1.6+o.r*2,12,1,!0),new Ht({color:"#ffcf6b",transparent:!0,opacity:.9,toneMapped:!1,depthWrite:!1}));return d.rotation.x=Math.PI,d.position.y=-(.8+o.r),d.visible=!1,h.add(d),{group:h,height:a,flame:d}}const Cn=ji/2;class N_{constructor(e,t){this.canvas=e,this.scene=new to,this.views=new Map,this.drones=new Map,this.baseId="",this.look={primary:"#e9eef5",accent:"#22c7e8",banner:{bg:"#1b6fd8",fg:"#ffd23a",emblem:"rocket"}},this.cam={x:0,z:2,y:0,dist:44,yaw:Math.PI/4,tx:0,tz:2,ty:0,tdist:44,tyaw:Math.PI/4},this.mode="base",this.walkers=null,this.walkKey="",this.orbit=null,this.padRocket=null,this.flights=[],this.saved=null,this.ghost=null,this.ghostObj=null,this.selected=null,this.t=0,this.ray=new A0,this.ptr=new fe,this.fx=[],this.area={lo:0,hi:0},this.onTap=()=>{},this.onGhostMove=()=>{},this.shF=0,this.shX=1e9,this.shZ=1e9;const n=/Android|iPhone|iPad|iPod/i.test(navigator.userAgent)||navigator.maxTouchPoints>1&&Math.min(screen.width,screen.height)<820;this.quality=t==="auto"?n?"low":"high":t,this.renderer=new bb({canvas:e,antialias:this.quality==="high",powerPreference:"high-performance"}),this.renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,this.quality==="high"?2:1.5)),this.renderer.outputColorSpace=Ft,this.renderer.toneMapping=uc,this.renderer.toneMappingExposure=1,this.renderer.shadowMap.enabled=!0,this.renderer.shadowMap.type=du,this.camera=new dn(38,1,.5,6e3),this.sun=new Ya("#fff1d6",2.8),this.sun.castShadow=!0;const s=this.quality==="high"?2048:1024;this.sun.shadow.mapSize.set(s,s);const r=this.sun.shadow.camera;r.left=-34,r.right=34,r.top=34,r.bottom=-34,r.near=1,r.far=160,this.sun.shadow.bias=-4e-4,this.sun.shadow.normalBias=.03,this.hemi=new tf("#bcd8ff","#5a6a3a",.9),this.scene.add(this.sun,this.sun.target,this.hemi,new sf("#405070",.25)),this.selRing=new je(new Lr(.92,1,48),new Ht({color:"#6ee7ff",transparent:!0,opacity:.9,depthWrite:!1,side:bn})),this.selRing.rotation.x=-Math.PI/2,this.selRing.visible=!1,this.scene.add(this.selRing),this.resize(),window.addEventListener("resize",()=>this.resize()),this.input()}resize(){const e=this.canvas.clientWidth||window.innerWidth,t=this.canvas.clientHeight||window.innerHeight;this.renderer.setSize(e,t,!1),this.camera.aspect=e/t,this.camera.updateProjectionMatrix(),this.orbit?.resize(e,t)}openOrbit(e){this.orbit||(this.orbit=new l_(this.renderer,this.quality==="high"),this.resize()),this.orbit.sync(e),this.mode="orbit",this.select(null)}closeOrbit(){this.mode="base"}setWorld(e,t){if(this.baseId===e)return;this.baseId=e,this.env&&this.env.dispose(),this.env=new Mb(this.scene,t,this.quality),this.walkers?this.walkers.clear():this.walkers=new u_(this.scene,this.quality),this.walkKey="";for(const s of this.views.values())this.scene.remove(s.root);this.views.clear();for(const s of this.drones.values())this.scene.remove(s.g);this.drones.clear();const n=this.env.look;this.scene.fog=new Ec(n.fog,n.fogNear,n.fogFar),this.sun.color.set(n.sun),this.sun.intensity=n.sunI,this.hemi.color.set(n.amb[0]),this.hemi.groundColor.set(n.amb[1]),this.hemi.intensity=n.amb[2],this.area={lo:-1,hi:-1}}placeCamera(){const e=this.cam,t=.16;e.x+=(e.tx-e.x)*t,e.z+=(e.tz-e.z)*t,e.dist+=(e.tdist-e.dist)*t,e.yaw+=(e.tyaw-e.yaw)*t,e.y+=(e.ty-e.y)*.08;const n=qi.degToRad(qi.lerp(52,17,bt((e.dist-14)/81))),s=this.camera.aspect<.8?1.45:1,r=e.dist*s;this.camera.position.set(e.x+Math.sin(e.yaw)*Math.cos(n)*r,Math.sin(n)*r+1+e.y*.85,e.z+Math.cos(e.yaw)*Math.cos(n)*r),this.camera.lookAt(e.x,.5+e.y,e.z),this.sun.target.position.set(e.x,0,e.z),this.sun.position.set(e.x-.55*70,.62*70,e.z+.42*70)}focus(e,t,n){this.cam.tx=e,this.cam.tz=t,n&&(this.cam.tdist=n)}clampCam(){const e=this.cam,t=Cn+6;e.tx=bt(e.tx,-t,t),e.tz=bt(e.tz,-t,t),e.tdist=bt(e.tdist,12,95)}groundAt(e,t){const n=this.canvas.getBoundingClientRect();this.ptr.set((e-n.left)/n.width*2-1,-((t-n.top)/n.height)*2+1),this.ray.setFromCamera(this.ptr,this.camera);const s=new P;return this.ray.ray.intersectPlane(new oi(new P(0,1,0),0),s)?s:null}input(){const e=this.canvas,t=new Map;let n=!1,s=0,r=null,a=!1;const o=()=>{const[l,h]=[...t.values()];return{d:Math.hypot(l.x-h.x,l.y-h.y),a:Math.atan2(h.y-l.y,h.x-l.x)}};e.addEventListener("pointerdown",l=>{if(e.setPointerCapture(l.pointerId),t.set(l.pointerId,{x:l.clientX,y:l.clientY,sx:l.clientX,sy:l.clientY}),n=!1,s=performance.now(),t.size===2&&(r=o()),a=!1,this.ghost&&t.size===1){const h=this.groundAt(l.clientX,l.clientY);if(h){const[d,u]=on(this.ghost.b,this.ghost.r),f=this.ghost.x-Cn,g=this.ghost.z-Cn;h.x>=f-.6&&h.x<=f+d+.6&&h.z>=g-.6&&h.z<=g+u+.6&&(a=!0)}}}),e.addEventListener("pointermove",l=>{const h=t.get(l.pointerId);if(!h)return;const d=l.clientX-h.x,u=l.clientY-h.y;if(h.x=l.clientX,h.y=l.clientY,Math.hypot(h.x-h.sx,h.y-h.sy)>7&&(n=!0),!!n){if(this.mode==="orbit"&&this.orbit){if(t.size===1)this.orbit.drag(d,u);else if(t.size===2&&r){const f=o();this.orbit.zoom(r.d/Math.max(1,f.d)),r=f}return}if(t.size===1){if(a&&this.ghost){this.ghostTo(l.clientX,l.clientY);return}if(l.buttons===2){this.cam.tyaw-=d*.008;return}const f=this.cam.dist*.0021*(this.camera.aspect<.8?1.45:1),g=Math.cos(this.cam.yaw),v=Math.sin(this.cam.yaw);this.cam.tx-=(d*g+u*v*1.3)*f,this.cam.tz-=(-d*v+u*g*1.3)*f,this.clampCam()}else if(t.size===2&&r){const f=o();this.cam.tdist*=r.d/Math.max(1,f.d),this.cam.tyaw-=f.a-r.a,r=f,this.clampCam()}}});const c=l=>{const h=t.get(l.pointerId);t.delete(l.pointerId),t.size<2&&(r=null),!(!h||n||l.button===2)&&(performance.now()-s>600||this.tap(l.clientX,l.clientY))};e.addEventListener("pointerup",c),e.addEventListener("pointercancel",l=>t.delete(l.pointerId)),e.addEventListener("contextmenu",l=>l.preventDefault()),e.addEventListener("wheel",l=>{if(l.preventDefault(),this.mode==="orbit"&&this.orbit){this.orbit.zoom(Math.pow(1.0015,l.deltaY));return}this.cam.tdist*=Math.pow(1.0015,l.deltaY),this.clampCam()},{passive:!1}),window.addEventListener("keydown",l=>{l.target.tagName!=="INPUT"&&((l.key==="q"||l.key==="Q")&&(this.cam.tyaw+=Math.PI/4),(l.key==="e"||l.key==="E")&&(this.cam.tyaw-=Math.PI/4))})}tap(e,t){if(this.mode==="orbit")return;if(this.ghost){this.ghostTo(e,t);return}const n=this.canvas.getBoundingClientRect();this.ptr.set((e-n.left)/n.width*2-1,-((t-n.top)/n.height)*2+1),this.ray.setFromCamera(this.ptr,this.camera);const s=this.ray.intersectObjects([...this.views.values()].map(a=>a.pick),!1)[0];if(s){this.onTap({item:s.object.userData.item});return}const r=this.groundAt(e,t);this.onTap(r?{cell:[Math.floor(r.x+Cn),Math.floor(r.z+Cn)]}:{})}startGhost(e){this.ghost=e,this.env.showGrid(!0),this.rebuildGhost()}endGhost(){this.ghost=null,this.ghostObj&&this.scene.remove(this.ghostObj),this.ghostObj=null,this.env.showGrid(!1);for(const e of this.views.values())e.root.visible=!0}ghostTo(e,t){const n=this.groundAt(e,t);if(!n||!this.ghost)return;const[s,r]=on(this.ghost.b,this.ghost.r),a=Math.round(n.x+Cn-s/2),o=Math.round(n.z+Cn-r/2);(a!==this.ghost.x||o!==this.ghost.z)&&(this.ghost.x=a,this.ghost.z=o,this.onGhostMove())}rotateGhost(){this.ghost&&(this.ghost.r=(this.ghost.r+1)%4,this.rebuildGhost(),this.onGhostMove())}rebuildGhost(){this.ghostObj&&this.scene.remove(this.ghostObj);const e=this.ghost,[t,n]=on(e.b,e.r),s=new yt,r=Xl(e.b,1,this.look);r.group.rotation.y=-e.r*Math.PI/2,r.group.traverse(o=>{const c=o;c.isMesh&&(c.castShadow=!1)}),s.add(r.group);const a=new je(new pi(t,n),Da.ghostOk);a.rotation.x=-Math.PI/2,a.position.y=.06,a.name="foot",s.add(a),this.ghostObj=s,this.scene.add(s),this.syncGhost()}syncGhost(){const e=this.ghost;if(!e||!this.ghostObj)return;const[t,n]=on(e.b,e.r);this.ghostObj.position.set(e.x+t/2-Cn,.05,e.z+n/2-Cn),this.ghostObj.getObjectByName("foot").material=e.ok?Da.ghostOk:Da.ghostBad}sync(e){const t=e.bases[this.baseId];if(!t)return;const n=Rr(e,this.baseId);(n.lo!==this.area.lo||n.hi!==this.area.hi)&&(this.area={lo:n.lo,hi:n.hi},this.env.setArea(n.lo,n.hi));const s=JSON.stringify(this.look),r=new Set;for(const l of t.items){r.add(l.id);const h=Ci(e,l.id),d=`${l.b}|${l.lvl}|${l.r}|${h?1:0}|${s}`;let u=this.views.get(l.id);(!u||u.key!==d)&&(u&&this.scene.remove(u.root),u=this.makeView(l.id,l.b,l.lvl,l.r,!!h,d),this.views.set(l.id,u));const[f,g]=on(l.b,l.r);u.root.position.set(l.x+f/2-Cn,0,l.z+g/2-Cn),u.root.visible=!(this.ghost&&this.ghost.move===l.id)}for(const[l,h]of this.views)r.has(l)||(this.scene.remove(h.root),this.views.delete(l));const a=wt(e),o=t.items.map(l=>l.id+l.lvl).join()+"|"+a.list.map(l=>l.id+l.lvl+(l.post?l.post.item:"")).join();o!==this.walkKey&&(this.walkKey=o,this.walkers.sync(e,this.baseId,a.list));const c=new Set;for(const l of e.jobs)if(l.kind==="build"&&l.base===this.baseId&&(c.add(l.id),!this.drones.has(l.id))){const h=$b(),d=new je(new sn(.08,6,4),new Ht({color:"#bff8ff",toneMapped:!1}));h.add(d),this.scene.add(h),this.drones.set(l.id,{g:h,job:l.item,ph:Math.random()*6,spark:d})}for(const[l,h]of this.drones)c.has(l)||(this.scene.remove(h.g),this.drones.delete(l))}makeView(e,t,n,s,r,a){const o=new yt,c=Xl(t,Math.max(1,n),this.look);c.group.rotation.y=-s*Math.PI/2,o.add(c.group);const[l,h]=on(t,s),d=Math.max(.8,c.height),u=new je(new is(l*.96,d,h*.96),new Ht({visible:!1}));u.position.y=d/2,u.userData.item=e,o.add(u);let f;return r&&(f=Wb(l,h,Math.max(1,c.height*.8)),o.add(f),n===0&&(c.group.scale.y=.3)),this.scene.add(o),{key:a,root:o,model:c,pick:u,scaf:f}}centerOf(e){const t=this.views.get(e);return t?t.root.position.clone():null}topOf(e){const t=this.views.get(e);if(!t)return null;const n=t.root.position.clone();return n.y=t.model.height+.4,n}select(e){this.selected=e;const t=e?this.views.get(e):null;if(!t){this.selRing.visible=!1;return}const n=new Ui().setFromObject(t.pick),s=Math.max(n.max.x-n.min.x,n.max.z-n.min.z)*.62;this.selRing.scale.setScalar(s),this.selRing.position.set(t.root.position.x,.08,t.root.position.z),this.selRing.visible=!0}project(e){const t=new P(e.x,e.y,e.z).project(this.camera),n=this.canvas.getBoundingClientRect();return{x:n.left+(t.x+1)/2*n.width,y:n.top+(1-t.y)/2*n.height,behind:t.z>1}}burst(e,t,n=24){const s=new Float32Array(n*3),r=new Float32Array(n*3);for(let c=0;c<n;c++)s.set([e.x,e.y,e.z],c*3),r.set([(Math.random()-.5)*4,2+Math.random()*4,(Math.random()-.5)*4],c*3);const a=new pt;a.setAttribute("position",new Zt(s,3));const o=new Bl(a,new Xa({color:t,size:.28,transparent:!0,depthWrite:!1}));this.scene.add(o),this.fx.push({pts:o,v:r,life:1})}setPadRocket(e,t){const n=e&&t?e.id+JSON.stringify(e)+t+JSON.stringify(this.look):"";if(this.padRocket&&this.padRocket.key===n||(this.padRocket&&(this.views.get(this.padRocket.item)?.root.remove(this.padRocket.m.group),this.padRocket=null),!e||!t))return;const s=this.views.get(t);if(!s)return;const r=Jl(e,this.look);r.group.position.set(0,.42,0),s.root.add(r.group),this.padRocket={key:n,m:r,item:t}}launchFx(e,t){const n=this.views.get(t);if(!n)return;this.padRocket&&this.padRocket.item===t&&(n.root.remove(this.padRocket.m.group),this.padRocket=null);const s=Jl(e,this.look),r=n.root.position.x,a=n.root.position.z;s.group.position.set(r,.42,a),s.flame.visible=!0,this.scene.add(s.group);const o=this.quality==="high"?420:220,c=new Float32Array(o*3).fill(-999),l=new Float32Array(o*3),h=new Float32Array(o),d=new pt;d.setAttribute("position",new Zt(c,3));const u=new Bl(d,new Xa({color:"#eef0f3",size:3.2,transparent:!0,opacity:.55,depthWrite:!1,map:U_()}));this.scene.add(u),this.flights.push({m:s,t:0,x:r,z:a,smoke:u,v:l,life:h}),this.saved={x:this.cam.tx,z:this.cam.tz,dist:this.cam.tdist},this.focus(r,a,Math.max(this.cam.tdist,34))}flightsFrame(e){for(const t of[...this.flights]){t.t+=e;const n=Math.max(0,t.t-1.2),s=.42+2.2*n*n+.6*n;t.m.group.position.y=s,t.m.flame.scale.set(1,.8+Math.random()*.4+Math.min(1.5,n*.4),1),t.m.group.rotation.z=Math.min(.25,n*n*.004);const r=t.smoke.geometry.attributes.position,a=t.life.length,o=t.t<8?5:0;let c=0;for(let l=0;l<a;l++){if(t.life[l]<=0&&c<o){c++,t.life[l]=1;const h=s<3;r.setXYZ(l,t.x+(Math.random()-.5)*.4,h?.4:s-1.2,t.z+(Math.random()-.5)*.4);const d=Math.random()*Math.PI*2,u=h?1.2+Math.random()*1.8:.25;t.v.set([Math.cos(d)*u,h?.3+Math.random()*.6:-.8,Math.sin(d)*u],l*3)}t.life[l]>0&&(t.life[l]-=e*.22,r.setXYZ(l,r.getX(l)+t.v[l*3]*e,r.getY(l)+t.v[l*3+1]*e,r.getZ(l)+t.v[l*3+2]*e),t.v[l*3]*=.97,t.v[l*3+2]*=.97,t.v[l*3+1]+=e*.25,t.life[l]<=0&&r.setXYZ(l,0,-999,0))}r.needsUpdate=!0,this.cam.ty=Math.min(28,Math.max(0,s-2)*.8),t.t>11&&(this.scene.remove(t.m.group,t.smoke),t.smoke.geometry.dispose(),this.flights.splice(this.flights.indexOf(t),1),this.cam.ty=0,this.saved&&!this.flights.length&&(this.focus(this.saved.x,this.saved.z,this.saved.dist),this.saved=null))}}frame(e,t,n){this.t+=t;const s=this.t;if(this.mode==="orbit"&&this.orbit){this.orbit.frame(t),this.renderer.render(this.orbit.scene,this.orbit.camera);return}this.placeCamera(),this.env.update(s,t),this.flightsFrame(t),this.walkers?.frame(e,this.baseId,s,t);for(const[r,a]of this.views)if(a.model.anim?.(s,{working:n(r)}),a.scaf){const o=a.scaf.children[0];o&&(o.rotation.y=0)}for(const r of this.drones.values()){const a=this.views.get(r.job);if(!a)continue;const o=a.model.height+.8,c=s*1.3+r.ph;r.g.position.set(a.root.position.x+Math.cos(c)*.9,o+Math.sin(s*3+r.ph)*.15,a.root.position.z+Math.sin(c)*.9),r.g.rotation.y=-c,r.spark.position.set(0,-.25-Math.random()*.1,0),r.spark.visible=Math.sin(s*23+r.ph)>.2}this.selRing.visible&&(this.selRing.material.opacity=.55+Math.sin(s*4)*.3);for(const r of[...this.fx]){r.life-=t*1.2;const a=r.pts.geometry.attributes.position;for(let o=0;o<a.count;o++)r.v[o*3+1]-=t*7,a.setXYZ(o,a.getX(o)+r.v[o*3]*t,a.getY(o)+r.v[o*3+1]*t,a.getZ(o)+r.v[o*3+2]*t);a.needsUpdate=!0,r.pts.material.opacity=Math.max(0,r.life),r.life<=0&&(this.scene.remove(r.pts),r.pts.geometry.dispose(),this.fx.splice(this.fx.indexOf(r),1))}if(this.quality==="low"){const r=this.renderer.shadowMap,a=this.sun.target.position;r.autoUpdate=!1,(++this.shF%3===0||Math.abs(a.x-this.shX)+Math.abs(a.z-this.shZ)>.001)&&(r.needsUpdate=!0,this.shX=a.x,this.shZ=a.z)}this.renderer.render(this.scene,this.camera)}}let ba=null;function U_(){if(ba)return ba;const i=document.createElement("canvas");i.width=i.height=64;const e=i.getContext("2d"),t=e.createRadialGradient(32,32,0,32,32,32);return t.addColorStop(0,"rgba(255,255,255,1)"),t.addColorStop(.6,"rgba(255,255,255,0.5)"),t.addColorStop(1,"rgba(255,255,255,0)"),e.fillStyle=t,e.fillRect(0,0,64,64),ba=new io(i),ba}class F_{constructor(e){this.renderer=e,this.scene=new to,this.cam=new dn(30,1,.1,100),this.cache=new Map,this.size=192,this.rt=new Mn(this.size,this.size,{samples:4}),this.rt.texture.colorSpace=Ft;const t=new Ya("#fff3df",2.6);t.position.set(-3,5,4),this.scene.add(t,new tf("#cfe4ff","#3a2a22",1.1));const n=new Ya("#7ab6ff",.9);n.position.set(4,2,-4),this.scene.add(n)}shoot(e,t,n,s){const r=this.cache.get(t);if(r)return r;this.scene.add(e),this.cam.position.set(n*.7,s+n*.55,n*.85),this.cam.lookAt(0,s*.45,0);const a=this.renderer.getRenderTarget(),o=this.renderer.getClearColor(new Te),c=this.renderer.getClearAlpha(),l=this.renderer.shadowMap.enabled;this.renderer.setClearColor(0,0),this.renderer.setRenderTarget(this.rt),this.renderer.clear(),this.renderer.render(this.scene,this.cam);const h=new Uint8Array(this.size*this.size*4);this.renderer.readRenderTargetPixels(this.rt,0,0,this.size,this.size,h),this.renderer.setRenderTarget(a),this.renderer.setClearColor(o,c),this.renderer.shadowMap.enabled=l,this.scene.remove(e);const d=document.createElement("canvas");d.width=d.height=this.size;const u=d.getContext("2d"),f=u.createImageData(this.size,this.size);for(let v=0;v<this.size;v++)f.data.set(h.subarray((this.size-1-v)*this.size*4,(this.size-v)*this.size*4),v*this.size*4);u.putImageData(f,0,0);const g=d.toDataURL("image/png");return this.cache.set(t,g),g}building(e,t,n){const s=Xl(e,t,n),[r,a]=at[e].fp,o=Math.max(r,a);return this.shoot(s.group,`b|${e}|${t}|${n.primary}${n.accent}${n.banner.bg}${n.banner.fg}${n.banner.emblem}`,o*1.45+1.2,Math.max(.8,s.height*.55))}rocket(e,t){const n=Jl(e,t);n.group.rotation.y=.6;const s=n.height;return this.shoot(n.group,`r|${JSON.stringify(e)}|${t.accent}`,s*1.45+1.2,s*.95)}bot(e){const t=xf(e,1);t.group.rotation.y=.5;const n=t.group.getObjectByName("hoverGlow");return n&&(n.visible=!1),this.shoot(t.group,`bot|${e}`,1.75,.55)}}const Ye=i=>i.space||(i.space={designs:[],hangar:{},sats:[],modules:{},flights:0,fails:0,done:{}}),Yi=i=>Sn(i,"earth","vab"),Cs=i=>Sn(i,"earth","launch"),Uf=i=>Cs(i)?1+(Cs(i)>=10?1:0)+(Cs(i)>=18?1:0):0,Ff=i=>1+(Yi(i)>=10?1:0),Of=i=>i.jobs.filter(e=>e.kind==="mission").length,kf=i=>i.jobs.filter(e=>e.kind==="rocket").length,Vc=i=>Math.min(9,Math.ceil(Cs(i)/2)),Bf=(i,e,t=mi(i))=>dr[e].base+(t.flags.has("orbitalOps")?1:0)+(e==="leo"&&t.flags.has("constellations")?2:0)+(e==="lagrange"&&i.tech.deepSpace?1:0),zf=(i,e)=>Ye(i).sats.filter(t=>kn[t.type].orbit===e),Tr=(i,e)=>Ye(i).designs.find(t=>t.id===e)||Nf.find(t=>t.id===e)||null,O_=(i,e)=>!e||!!i.tech[e],k_=(i,e)=>Di(e).reqs.every(t=>O_(i,t)),kd=i=>[...Nf.filter(e=>k_(i,e)&&!Ye(i).designs.some(t=>t.id===e.id)),...Ye(i).designs];function Gf(i,e,t=!1){let n=Di(e).rel+Math.min(.06,Sn(i,"earth","tracking")*.004);for(const s of Ye(i).sats)n+=(kn[s.type].rel||0)*s.lvl;return t&&(n+=Sn(i,"earth","academy")*.01+(Ye(i).modules.dock||0)*(ks.dock.rel||0)),i.tech.reusable&&(n+=.02),bt(n,.05,.99)}const qo=i=>bt(Ye(i).sats.reduce((e,t)=>e+(kn[t.type].flightCut||0)*t.lvl,0),0,.5),Xo=i=>bt((Ye(i).modules.depot||0)*(ks.depot.fuelCut||0)+Sn(i,"moon","massDriver")*.03,0,.6),Hf=i=>bt(Sn(i,"earth","elevator")*.03,0,.45);function Vf(i,e){const t=Ye(i),n=t.designs.findIndex(s=>s.id===e.id);n>=0?t.designs[n]=e:t.designs.push(e)}function Bd(i){return"d"+(i.seq++).toString(36)}function B_(i,e){const t=Ye(i);return(t.hangar[e]||0)>0||i.jobs.some(n=>n.kind==="rocket"&&n.design.id===e)?!1:(t.designs=t.designs.filter(n=>n.id!==e),!0)}function Zl(i,e){if(!e.stages.length)return{ok:!1,why:"Add a stage"};const t=Di(e);return t.reqs.filter(s=>!i.tech[s]).length?{ok:!1,why:"Some parts need research",locked:!0}:e.stages.some((s,r)=>r===0&&Rs[s.eng].upper)?{ok:!1,why:"Nuclear engines only fire in space: use them on upper stages"}:t.cls===0?{ok:!1,why:"Too weak to reach space"}:t.vab>0&&!Yi(i)?{ok:!1,why:"Multi-stage rockets are stacked in the Vehicle Assembly",locked:!0}:Yi(i)<t.vab?{ok:!1,why:`Vehicle Assembly level ${t.vab} for ${t.vab>=7?"XXL":t.vab>=5?"XL":t.vab>=3?"L":"M"} tanks`,locked:!0}:t.cls>Vc(i)?{ok:!1,why:`Launch Complex level ${t.cls*2-1} to fly class ${t.cls}`,locked:!0}:{ok:!0}}const Ql=(i,e)=>{const t={...Di(e).cost},n=(i.tech.reusable?.85:1)*(1-Hf(i));if(n<1)for(const s in t)t[s]=ai(t[s]*n);return t},jl=(i,e)=>Math.max(10,Math.round(Di(e).time/(1+Yi(i)*.06)));function ec(i,e){if(!Cs(i))return{ok:!1,why:"Build the Launch Complex",locked:!0};const t=Zl(i,e);if(!t.ok)return t;if(kf(i)>=Ff(i))return{ok:!1,why:"Assembly line busy",busy:!0};const n=Ql(i,e);return es(i,n)?{ok:!0,cost:n,time:jl(i,e)}:{ok:!1,why:"Not enough resources",cost:n}}function zd(i,e,t=Date.now()){const n=ec(i,e);return n.ok&&(Ii(i,n.cost),i.jobs.push({id:Yn(i),kind:"rocket",design:JSON.parse(JSON.stringify(e)),start:t,end:t+n.time*1e3})),n}function z_(i,e,t=!1,n=!1){let s=null,r=99;for(const a in Ye(i).hangar){if((Ye(i).hangar[a]||0)<=0)continue;const o=Tr(i,a);if(!o)continue;const c=Di(o);if(c.cls<e||t&&!c.crew||n&&!c.lander)continue;const l=c.cls+(c.crew&&!t?.5:0);l<r&&(r=l,s=o)}return s}function G_(i,e){const t=1-Hf(i);if(e.sat){const r=kn[e.sat],a=e.idx!==void 0?Ye(i).sats[e.idx]:null,o=a?a.lvl+1:1,c={};for(const l in r.cost)c[l]=ai(Pn(r.cost[l][0],r.cost[l][1],o)*t);return c.fuel&&(c.fuel=ai(c.fuel*(1-Xo(i)))),{name:`${a?"Upgrade":"Launch"} ${r.name}${o>1?" Mk "+o:""}`,cls:r.cls,cost:c,flight:Math.round(Pn(r.flight[0],r.flight[1],o)*(1-qo(i))),req:[r.req],lvl:o}}if(e.module){const r=ks[e.module],a=(Ye(i).modules[e.module]||0)+1,o={};for(const c in r.cost)o[c]=ai(Pn(r.cost[c][0],r.cost[c][1],a)*t);return o.fuel&&(o.fuel=ai(o.fuel*(1-Xo(i)))),{name:`${a>1?"Expand":"Launch"} ${r.name}${a>1?" (level "+a+")":""}`,cls:r.cls,cost:o,flight:Math.round(Pn(r.flight[0],r.flight[1],a)*(1-qo(i))),req:[r.req],lvl:a,needs:r.needs}}const n=Er[e.mission],s={fuel:ai(n.fuel*(1-Xo(i))*t),credits:ai(n.credits*t)};return n.metal&&(s.metal=ai(n.metal*t)),{name:n.name,cls:n.cls,cost:s,flight:Math.round(n.flight*(1-qo(i))),req:n.req,crew:!!n.crewed,lander:!!n.lander}}function Wf(i,e){const t=G_(i,e);if(!Cs(i))return{ok:!1,why:"Build the Launch Complex",locked:!0,ms:t};if(t.req.filter(r=>r&&!i.tech[r]).length)return{ok:!1,why:"Research required",locked:!0,ms:t};if(e.mission){const r=Er[e.mission];if((r.flags||[]).some(a=>!i.flags[a]))return{ok:!1,why:"Complete earlier missions first",locked:!0,ms:t};if(r.kind!=="repeat"&&r.flag&&i.flags[r.flag])return{ok:!1,why:"Accomplished",done:!0,ms:t};if(r.needs&&r.needs.academy&&Sn(i,"earth","academy")<r.needs.academy)return{ok:!1,why:`Astronaut Academy level ${r.needs.academy}`,locked:!0,ms:t};if(i.jobs.some(a=>a.kind==="mission"&&a.payload.mission===e.mission&&r.kind!=="repeat"))return{ok:!1,why:"Already in flight",busy:!0,ms:t}}if(e.module){const r=ks[e.module];if(t.needs&&!Ye(i).modules[t.needs])return{ok:!1,why:"Launch the Core Module first",locked:!0,ms:t};if((t.lvl||1)>r.max)return{ok:!1,why:"Maximum level",done:!0,ms:t};if(i.jobs.some(a=>a.kind==="mission"&&a.payload.module===e.module))return{ok:!1,why:"Already in flight",busy:!0,ms:t}}if(e.sat){const r=kn[e.sat];if(e.idx===void 0){if(zf(i,r.orbit).length+i.jobs.filter(o=>o.kind==="mission"&&o.payload.sat&&o.payload.idx===void 0&&kn[o.payload.sat].orbit===r.orbit).length>=Bf(i,r.orbit))return{ok:!1,why:`No free ${dr[r.orbit].name} slot`,full:!0,ms:t}}else if(i.jobs.some(a=>a.kind==="mission"&&a.payload.sat&&a.payload.idx===e.idx))return{ok:!1,why:"Upgrade already in flight",busy:!0,ms:t}}if(t.cls>Vc(i))return{ok:!1,why:`Launch Complex level ${t.cls*2-1} needed`,locked:!0,ms:t};const s=z_(i,t.cls,t.crew,t.lander);return s?Of(i)>=Uf(i)?{ok:!1,why:"Launch pad busy",busy:!0,ms:t}:es(i,t.cost)?{ok:!0,ms:t,rocket:s,rel:Gf(i,s,t.crew)}:{ok:!1,why:"Not enough resources",cost:t.cost,ms:t}:{ok:!1,why:`Needs a class ${t.cls}+ rocket${t.lander?" with a lander":t.crew?" with a crew capsule":""} in the hangar`,noRocket:!0,ms:t}}function H_(i,e,t=Date.now()){const n=Wf(i,e);if(!n.ok)return n;Ii(i,n.ms.cost);const s=Ye(i);s.hangar[n.rocket.id]--;const r=Math.random()<n.rel;return i.jobs.push({id:Yn(i),kind:"mission",payload:e,design:JSON.parse(JSON.stringify(n.rocket)),name:n.ms.name,ok:r,start:t,end:t+n.ms.flight*1e3}),s.flights++,i.stats.launches=(i.stats.launches||0)+1,n}Fs.rocket=(i,e)=>{const t=Ye(i),n=e.design;return Tr(i,n.id)||Vf(i,n),t.hangar[n.id]=(t.hangar[n.id]||0)+1,i.stats.rocketsBuilt=(i.stats.rocketsBuilt||0)+1,{kind:"rocket",design:n.id,name:n.name}};Fs.mission=(i,e)=>{const t=Ye(i),n=e.payload,s=e.design;if(s.legs&&Math.random()<.85&&(t.hangar[s.id]=(t.hangar[s.id]||0)+1),!e.ok){t.fails++;const o=n.mission?Math.round(((Er[n.mission].reward||{}).science||1e3)*.1):300;return ws(i,{science:o}),{kind:"fail",name:e.name,sci:o}}if(n.sat)return n.idx!==void 0&&t.sats[n.idx]?t.sats[n.idx].lvl++:t.sats.push({type:n.sat,lvl:1}),{kind:"sat",sat:n.sat,name:e.name};if(n.module)return t.modules[n.module]=(t.modules[n.module]||0)+1,{kind:"module",mod:n.module,lvl:t.modules[n.module],name:e.name};const r=Er[n.mission],a=!t.done[n.mission];return t.done[n.mission]=(t.done[n.mission]||0)+1,ws(i,r.reward||{}),a&&r.firstReward&&ws(i,r.firstReward),r.flag&&(i.flags[r.flag]=1),{kind:"mission",mission:n.mission,name:r.name,first:a,reward:r.reward,base:r.base}};Ni.rockets=(i,e)=>(i.stats.rocketsBuilt||0)>=e.n;Ni.sat=(i,e)=>Ye(i).sats.some(t=>t.type===e.sat);Ni.module=(i,e)=>(Ye(i).modules[e.mod]||0)>=e.lvl;Xd.push((i,e)=>{for(const t of Ye(i).sats){const n=kn[t.type];for(const s in n.mult||{})e.mult[s]=(e.mult[s]||0)+n.mult[s]*t.lvl}});Yd.push((i,e)=>{const t=Ye(i),n=e.m;for(const s of t.sats){const r=kn[s.type];for(const a in r.prod||{})e.prod[a]+=Pn(r.prod[a][0],r.prod[a][1],s.lvl)*(1+(n.mult[a]||0));r.gen&&(e.gen+=Pn(r.gen[0],r.gen[1],s.lvl)*(1+n.gen))}for(const s in t.modules){const r=t.modules[s],a=ks[s];if(!(!r||!a)){for(const o in a.prod||{})e.prod[o]+=Pn(a.prod[o][0],a.prod[o][1],r)*(1+(n.mult[o]||0));for(const o in a.cap||{})e.cap[o]+=Pn(a.cap[o][0],a.cap[o][1],r)*(1+n.cap);a.gen&&(e.gen+=Pn(a.gen[0],a.gen[1],r)*(1+n.gen)),a.speed&&(e.speed+=a.speed*r)}}});class V_{constructor(e){this.ui=e,this.tab="missions",this.design=null,this.near=t=>!t||!!this.s.tech[t]||rt[t]&&rt[t].req.every(n=>this.s.tech[n])}get s(){return this.ui.app.s}get A(){return this.ui.app}html(){const e=this.s,t=Ye(e),n=[["missions","Missions"],["sats","Satellites"],["station","Station"],["rockets",`Rockets (${Object.values(t.hangar).reduce((o,c)=>o+c,0)})`]],r=e.jobs.filter(o=>o.kind==="mission").map(o=>`<div class="now"><div class="grow"><div class="tier">IN FLIGHT · ${re(o.design.name)}</div><b class="ox">${re(o.name)}</b><div class="bar gold" style="margin-top:6px"><i style="width:${bt(1-(o.end-Date.now())/(o.end-o.start))*100}%"></i></div></div><div style="text-align:right"><b class="ox">${an((o.end-Date.now())/1e3)}</b><br><button class="btn gold small" data-a="finish" data-job="${o.id}">Finish</button></div></div>`).join("");let a="";return this.tab==="missions"?a=this.missions():this.tab==="sats"?a=this.sats():this.tab==="station"?a=this.station():a=this.rockets(),`<div class="head"><h1>Launch Control</h1><span class="chip">🚀 ${Of(e)}/${Uf(e)} pads · class ${Vc(e)} max</span><button class="ibtn" data-a="close">✕</button></div><div class="tabs">${n.map(([o,c])=>`<button class="tab ${o===this.tab?"on":""}" data-a="ltab" data-t="${o}">${c}</button>`).join("")}</div><div class="body">${r}${a}</div>`}launchBtn(e,t="Launch"){const n=Wf(this.s,e),s=re(JSON.stringify(e));return`<div class="row"><span class="grow">${Ln(n.ms.cost,this.s.res)}</span><span class="muted" style="font-size:11px">⏱ ${an(n.ms.flight)}</span></div>${n.ok?`<div class="muted" style="font-size:11px">On a ${re(n.rocket.name)} · ${Ai(n.rel)} success</div>`:""}<button class="btn small ${n.ok?"gold":""}" data-a="launch" data-p="${s}" ${n.ok||n.why==="Not enough resources"?"":"disabled"}>${n.ok?"🚀 "+t:re(n.why||"")}</button>${n.noRocket?'<button class="btn small" data-a="ltab" data-t="rockets">Build a rocket</button>':""}`}missions(){const e=this.s,t=Ye(e);return`<div class="techs">${Object.entries(Er).filter(([,s])=>s.req.every(r=>this.near(r))&&(s.flags||[]).every(r=>e.flags[r])).map(([s,r])=>{const a=r.kind!=="repeat"&&r.flag&&e.flags[r.flag];return`<div class="tech ${a?"done":""}" style="--bc:#ff8a5b"><div class="row"><span class="tier grow">CLASS ${r.cls}${r.crewed?" · CREWED":""}${r.lander?" · LANDER":""}${r.kind==="repeat"?" · REPEATABLE":""}</span>${a?'<span class="good">✓</span>':""}</div><b>${re(r.name)}</b><p class="desc">${re(r.desc)}</p>${r.reward?`<div class="unl">Reward: ${Ln(r.reward)}${r.firstReward&&!t.done[s]?` + first time ${Ln(r.firstReward)}`:""}</div>`:""}${a?"":this.launchBtn({mission:s})}</div>`}).join("")||'<p class="muted">Research Rocketry Fundamentals and build the Launch Complex to fly your first mission.</p>'}</div>`}sats(){const e=this.s,t=Ye(e);let n=`<div class="row" style="margin-bottom:10px">${Object.entries(dr).map(([r,a])=>`<span class="chip">${re(a.name)} · ${zf(e,r).length}/${Bf(e,r)}</span>`).join("")}</div>`;t.sats.length&&(n+=`<h3 class="ox">Your satellites</h3><div class="techs">${t.sats.map((r,a)=>{const o=kn[r.type];return`<div class="tech" style="--bc:#6ee7ff"><span class="tier">${re(dr[o.orbit].name)} · MK ${r.lvl}</span><b>${re(o.name)}</b><p class="desc">${re(o.desc)}</p>${this.launchBtn({sat:r.type,idx:a},"Upgrade")}</div>`}).join("")}</div>`);const s=Object.entries(kn).filter(([,r])=>this.near(r.req));return n+=`<h3 class="ox">Launch a new satellite</h3><div class="techs">${s.map(([r,a])=>`<div class="tech ${e.tech[a.req]?"":"locked"}" style="--bc:#ffd36a"><span class="tier">${re(dr[a.orbit].name)} · CLASS ${a.cls}</span><b>${re(a.name)}</b><p class="desc">${re(a.desc)}</p>${e.tech[a.req]?this.launchBtn({sat:r}):`<div class="warn" style="font-size:12px">Research ${re(rt[a.req].name)}</div>`}</div>`).join("")||'<p class="muted">Research Orbital Mechanics, then Communication Satellites or Remote Sensing.</p>'}</div>`,n}station(){const e=this.s,t=Ye(e),n=Object.entries(ks).filter(([,s])=>this.near(s.req));return`${t.modules.core?'<button class="btn small" data-a="orbitStation" style="margin-bottom:10px">🛰 View the station</button>':""}<div class="techs">${n.map(([s,r])=>{const a=t.modules[s]||0;return`<div class="tech ${e.tech[r.req]?"":"locked"}" style="--bc:#b892ff"><span class="tier">CLASS ${r.cls} · LEVEL ${a}/${r.max}</span><b>${re(r.name)}</b><p class="desc">${re(r.desc)}</p>${e.tech[r.req]?a>=r.max?'<div class="good ox">Complete</div>':this.launchBtn({module:s},a?"Expand":"Launch"):`<div class="warn" style="font-size:12px">Research ${re(rt[r.req].name)}</div>`}</div>`}).join("")||'<p class="muted">Research Orbital Assembly to start a space station.</p>'}</div>`}rockets(){const e=this.s,t=Ye(e);let s=e.jobs.filter(a=>a.kind==="rocket").map(a=>`<div class="now"><div class="grow"><div class="tier">ASSEMBLING</div><b class="ox">${re(a.design.name)}</b><div class="bar gold" style="margin-top:6px"><i style="width:${bt(1-(a.end-Date.now())/(a.end-a.start))*100}%"></i></div></div><div style="text-align:right"><b class="ox">${an((a.end-Date.now())/1e3)}</b><br><button class="btn gold small" data-a="finish" data-job="${a.id}">Finish</button></div></div>`).join("");s+=`<div class="row" style="margin-bottom:10px"><span class="chip">🏭 ${kf(e)}/${Ff(e)} assembly lines</span><span class="chip">Vehicle Assembly level ${Yi(e)}</span><button class="btn small gold" data-a="newDesign">✚ New design</button></div>`;const r=kd(e);return s+=`<div class="grid">${r.map(a=>{const o=Di(a),c=ec(e,a),l=t.hangar[a.id]||0,h=!t.designs.some(d=>d.id===a.id);return`<div class="card"><div class="thumb" style="height:150px"><img src="${this.A.studio.rocket(a,this.A.world.look)}" alt=""></div><div class="row"><b class="grow">${re(a.name)}</b><span class="n">${l} ready</span></div><div class="muted" style="font-size:12px">Class ${o.cls} · ${re(Od[o.cls]||"")} · ${qe(o.payload)} t · ${Ai(o.rel)}${o.crew?" · crew":""}${o.lander?" · lander":""}${a.legs?" · reusable":""}${h?" · template":""}</div>
        <div class="row"><span class="grow">${Ln(Ql(e,a),e.res)}</span><span class="muted" style="font-size:11px">⏱ ${an(jl(e,a))}</span></div><div class="row"><button class="btn small ${c.ok?"gold":""} grow" data-a="assemble" data-id="${a.id}" ${c.ok||c.why==="Not enough resources"?"":"disabled"}>${c.ok?"Assemble":re(c.why||"")}</button><button class="btn small" data-a="editDesign" data-id="${a.id}">✎</button></div></div>`}).join("")||'<p class="muted">Research Rocketry Fundamentals to unlock your first rocket parts.</p>'}</div>`,s}designerHTML(){const e=this.s,t=this.design,n=Di(t),s=Zl(e,t),r=l=>!l||!!e.tech[l],a=(l,h,d,u,f,g="")=>`<button class="tab ${l?"on":""}" ${h?'disabled style="opacity:.35"':""} data-a="${d}" ${u} title="${re(g)}">${f}</button>`,o=t.stages.map((l,h)=>`<div class="box"><div class="row"><b class="ox grow">Stage ${h+1}${h===0?" (first)":""}</b>${h>0&&h===t.stages.length-1?'<button class="btn small red" data-a="dRemove">Remove</button>':""}</div>
      <div class="row" style="margin-top:6px">${Object.entries(Rs).map(([d,u])=>a(l.eng===d,!r(u.req)||h===0&&!!u.upper,"dEng",`data-i="${h}" data-k="${d}"`,re(u.name),r(u.req)?u.desc:`Research ${rt[u.req].name}`)).join("")}</div>
      <div class="row" style="margin-top:6px">Tank ${Object.entries($n).map(([d,u])=>a(l.tank===d,!r(u.req)||Yi(e)<u.vab&&u.vab>0,"dTank",`data-i="${h}" data-k="${d}"`,d,u.vab?`Vehicle Assembly level ${u.vab}`:"")).join("")}</div></div>`).join(""),c=t.stages.length<3&&r(Za[t.stages.length]||void 0);return`<div class="head"><h1>Rocket designer</h1><button class="ibtn" data-a="dClose">✕</button></div><div class="body" style="max-width:980px;margin:0 auto;width:100%"><div class="row" style="align-items:flex-start;gap:14px">
      <div class="grow" style="min-width:300px"><label class="ox">Name<input id="dname" value="${re(t.name)}" maxlength="22" style="width:100%;margin:6px 0 4px;padding:10px;border-radius:10px;border:1px solid var(--line);background:#0d1a2e;color:#fff;font:600 15px Barlow"></label>
        ${o}${c?'<button class="btn small" data-a="dAdd">✚ Add a stage</button>':t.stages.length<3?`<p class="muted" style="font-size:12px">Research ${re(rt[Za[t.stages.length]].name)} for stage ${t.stages.length+1}.</p>`:""}
        <div class="box"><b class="ox">Strap-on boosters</b><div class="row" style="margin-top:6px">${[0,2,4].map(l=>a(t.boost.n===l,l>0&&!r(If[l]),"dBoost",`data-n="${l}"`,l?`${l} solid`:"None")).join("")}</div>${t.boost.n?`<div class="row" style="margin-top:6px">Size ${Object.entries($n).map(([l,h])=>a(t.boost.tank===l,!r(h.req)||Yi(e)<h.vab&&h.vab>0,"dBTank",`data-k="${l}"`,l)).join("")}</div>`:""}</div>
        <div class="box"><b class="ox">Payload</b><div class="row" style="margin-top:6px">${Object.entries(Ar).map(([l,h])=>a(t.top===l,!r(h.req),"dTop",`data-k="${l}"`,re(h.name),r(h.req)?h.desc:`Research ${rt[h.req].name}`)).join("")}</div>
          <div class="row" style="margin-top:6px">${a(t.legs,!r("reusable"),"dLegs","",t.legs?"✓ Landing legs (reusable)":"Landing legs",r("reusable")?"The first stage lands itself: 85% of flights return the rocket to the hangar.":"Research Reusable Boosters")}</div></div></div>
      <div style="width:280px;max-width:100%"><div class="card"><div class="thumb" style="height:260px"><img src="${this.A.studio.rocket(t,this.A.world.look)}" alt=""></div>
        <table class="stats"><tr><td>Class</td><td>${n.cls?`${n.cls} · ${re(Od[n.cls])}`:"–"}</td></tr><tr><td>Payload to orbit</td><td>${qe(n.payload)} t</td></tr><tr><td>Lift rating</td><td>${n.D.toFixed(1)}</td></tr><tr><td>Reliability</td><td>${Ai(Gf(e,t))}</td></tr><tr><td>Build time</td><td>${an(jl(e,t))}</td></tr></table>
        <div>${Ln(Ql(e,t),e.res)}</div>${s.ok?"":`<p class="why">${re(s.why||"")}</p>`}
        <div class="row" style="margin-top:8px"><button class="btn small grow" data-a="dSave">Save</button><button class="btn small gold grow" data-a="dBuild" ${ec(e,t).ok?"":"disabled"}>Save & assemble</button></div>${Ye(e).designs.some(l=>l.id===t.id)?'<button class="btn small red" style="margin-top:6px;width:100%" data-a="dDelete">Delete design</button>':""}</div></div></div></div>`}act(e,t){const n=this.s,s=this.A,r=this.ui,a=this.design,o=()=>{r.renderOver(),s.audio.play("tap")},c=()=>{const l=document.getElementById("dname");l&&a&&(a.name=l.value.trim().slice(0,22)||a.name)};switch(e){case"launchctl":return r.openOver("launch"),s.audio.play("tap"),!0;case"ltab":return this.tab=t.dataset.t,r.over!=="launch"?r.openOver("launch"):r.renderOver(),s.audio.play("tap"),!0;case"launch":{const l=JSON.parse(t.dataset.p),h=H_(n,l);return h.ok?(r.closeOver(),s.launched(h.rocket)):r.deny(h.why),!0}case"assemble":{const l=Tr(n,t.dataset.id);if(!l)return!0;const h=zd(n,l);return h.ok?(s.audio.play("build"),s.changed(),r.renderOver()):r.deny(h.why),!0}case"newDesign":{const l=kd(n)[0]||{id:"",name:"Rocket",stages:[{eng:"solid",tank:"S"}],boost:{n:0,tank:"S"},top:"probe",legs:!1};return this.design={...JSON.parse(JSON.stringify(l)),id:Bd(n),name:"My rocket "+(Ye(n).designs.length+1)},r.openOver("designer"),!0}case"editDesign":{const l=Tr(n,t.dataset.id);if(!l)return!0;const h=Ye(n).designs.some(d=>d.id===l.id);return this.design=h?JSON.parse(JSON.stringify(l)):{...JSON.parse(JSON.stringify(l)),id:Bd(n),name:l.name+" II"},r.openOver("designer"),!0}case"dClose":return this.tab="rockets",r.openOver("launch"),!0;case"dEng":return c(),a.stages[+t.dataset.i].eng=t.dataset.k,o(),!0;case"dTank":return c(),a.stages[+t.dataset.i].tank=t.dataset.k,o(),!0;case"dAdd":return c(),a.stages.push({eng:a.stages[a.stages.length-1].eng,tank:"S"}),o(),!0;case"dRemove":return c(),a.stages.pop(),o(),!0;case"dBoost":return c(),a.boost.n=+t.dataset.n,o(),!0;case"dBTank":return c(),a.boost.tank=t.dataset.k,o(),!0;case"dTop":return c(),a.top=t.dataset.k,o(),!0;case"dLegs":return c(),a.legs=!a.legs,o(),!0;case"dSave":case"dBuild":{if(c(),!a)return!0;const l=Zl(n,a);if(!l.ok&&e==="dBuild")return r.deny(l.why),!0;if(Vf(n,JSON.parse(JSON.stringify(a))),e==="dBuild"){const h=zd(n,a);if(!h.ok)return r.deny(h.why),!0;s.audio.play("build")}else s.audio.play("buy");return s.changed(),r.toast(`Design saved: ${re(a.name)}`,"good"),this.tab="rockets",r.openOver("launch"),!0}case"dDelete":return a&&B_(n,a.id)?(r.toast("Design deleted"),this.tab="rockets",r.openOver("launch"),s.changed()):r.deny("Fly or scrap the rockets built from it first"),!0;case"orbitStation":return r.closeOver(),s.openOrbit("station"),!0}return!1}}const Ms=i=>`<span class="els">${i.map(e=>`<span class="el" style="background:${un[e].color}" title="${un[e].name}">${un[e].glyph}</span>`).join("")}</span>`,_a=i=>{const e=Nn[tt[i].rarity];return`<span class="rar" style="color:${e.color}">${e.name}</span>`};class W_{constructor(e){this.ui=e,this.tab="crew",this.focus="",this.fA="",this.fB="",this.pickFor=null}get s(){return this.ui.app.s}get A(){return this.ui.app}pic(e,t=!0,n=54){return`<div class="pic" style="width:${n}px;height:${n}px;background:radial-gradient(circle, ${un[tt[e].el[0]].color}44, transparent 70%)"><img src="${this.A.studio.bot(e)}" style="${t?"":"filter:brightness(0) opacity(.5)"}"></div>`}html(){const e=this.s,t=wt(e),n=t.cores.length,s=[["crew",`Crew (${t.list.length}/${Kl(e)})`],["cores",`Workshop${n?` · ${n} ready`:""}`],["fusion","Fusion"],["dex",`Botdex ${wf(e)}/${Fd().length}`]];let r=this.tab==="crew"?this.crew():this.tab==="cores"?this.cores():this.tab==="fusion"?this.fusion():this.dex();return`<div class="head"><h1>Robots</h1><span class="chip">⚡ ${qe(e.res.cells||0)} Power Cells</span><button class="ibtn" data-a="close">✕</button></div><div class="tabs">${s.map(([a,o])=>`<button class="tab ${a===this.tab?"on":""}" data-a="rtabR" data-t="${a}">${o}</button>`).join("")}</div><div class="body">${r}</div>`}crew(){const e=this.s,t=wt(e);return t.list.length?`<div class="bots">${[...t.list].sort((s,r)=>tn(r.sp)-tn(s.sp)||r.lvl-s.lvl).map(s=>{const r=tt[s.sp],a=Cf(e,s.id),o=s.post?Xi(s,(e.bases[s.post.base]?.items.find(l=>l.id===s.post.item)||{b:""}).b):0,c=s.post?e.bases[s.post.base]?.items.find(l=>l.id===s.post.item):null;return`<div class="botc">${this.pic(s.sp)}<div><b>${re(r.name)}</b> ${_a(s.sp)} ${Ms(r.el)}<div class="meta">Level ${s.lvl}/${bf} · ${c?`operating the ${re(at[c.b].name)} (+${Ai(o)}${nr(s.sp,c.b)?", a perfect fit":""})`:"resting in a dock"}</div></div>
        <div class="row" style="flex-direction:column;align-items:flex-end;gap:4px"><button class="btn small ${a.ok?"green":""}" data-a="feedR" data-id="${s.id}" ${a.ok||a.why==="Not enough Power Cells"?"":"disabled"}>${a.max?"MAX":`⚡${qe(a.cost?.cells||0)} Level up`}</button>${s.post?`<button class="btn small" data-a="unassignR" data-id="${s.id}">Recall</button>`:""}</div></div>`}).join("")}</div>`:`<p class="desc">No robots yet. ${Li(e)?"Assemble a core in the Workshop, then activate it.":"Research Industrial Automation and build a Robotics Workshop: your first two robots come with it."}</p>`}cores(){const e=this.s,t=wt(e),n=Li(e);let s="";t.cores.length&&(s+=`<h3 class="ox">Ready to activate</h3><div class="bots">${t.cores.map(a=>{const o=Rf(e,a.id);return`<div class="botc">${this.pic(a.sp,!1)}<div><b>A ${re(Nn[tt[a.sp].rarity].name)} core</b><div class="meta">${a.from==="fusion"?"Fused in the lab":a.from==="gift"?"A gift":"From the Workshop"} · who will it be?</div></div><button class="btn small ${o.ok?"gold":""}" data-a="activateR" data-id="${a.id}" ${o.ok?"":"disabled"}>${o.ok?"Activate":re(o.why||"")}</button></div>`}).join("")}</div>`);const r=e.jobs.filter(a=>a.kind==="core"||a.kind==="fuse");return r.length&&(s+=r.map(a=>`<div class="now"><div class="grow"><div class="tier">${a.kind==="fuse"?"FUSING":"ASSEMBLING"}</div><b class="ox">A ${re(Nn[tt[a.sp].rarity].name)} core</b><div class="bar gold" style="margin-top:6px"><i style="width:${bt(1-(a.end-Date.now())/(a.end-a.start))*100}%"></i></div></div><div style="text-align:right"><b class="ox">${an((a.end-Date.now())/1e3)}</b><br><button class="btn gold small" data-a="finish" data-job="${a.id}">Finish</button></div></div>`).join("")),n?(s+=`<h3 class="ox">Assemble a core <span class="muted" style="font-size:12px">· ${Sf(e)}/${Mf(e)} bays busy</span></h3><div class="box"><div class="muted" style="font-size:12px;margin-bottom:6px">Focus on an element (the robot will carry it):</div><div class="row">${["",...d_].map(a=>`<button class="tab ${this.focus===a?"on":""}" data-a="focusR" data-e="${a}">${a?`${un[a].glyph} ${un[a].name}`:"Any"}</button>`).join("")}</div></div>
      <div class="grid">${zc.map((a,o)=>{const c=Tf(e,o);return`<div class="card ${n<a.ws?"locked":""}"><b style="color:${Nn[kc[a.rarity]].color}">${re(a.name)}</b><p class="desc">${re(a.desc)}</p><div>${Ln(a.cost,e.res)}</div><button class="btn small ${c.ok?"gold":""}" data-a="craftR" data-i="${o}" ${c.ok||c.why==="Not enough resources"?"":"disabled"}>${c.ok?"Assemble":re(c.why||"")}</button></div>`}).join("")}</div>`,s):s+'<p class="desc">Build the Robotics Workshop (Industrial Automation) to assemble robot cores.</p>'}fusion(){const e=this.s,t=wt(e);if(!Gc(e))return'<p class="desc">Research Construction Robotics and build the Fusion Lab (Mission Control 4) to fuse two robots into a new hybrid core. Rarer parents make rarer robots.</p>';const n=Bn(e,this.fA),s=Bn(e,this.fB),r=o=>`<div class="bots" style="max-height:260px;overflow:auto">${t.list.filter(c=>c.lvl>=ur).map(c=>`<div class="botc" style="${(o==="A"?this.fA:this.fB)===c.id?"border-color:var(--gold)":""};cursor:pointer" data-a="pickF" data-s="${o}" data-id="${c.id}">${this.pic(c.sp,!0,40)}<div><b>${re(tt[c.sp].name)}</b> ${Ms(tt[c.sp].el)}<div class="meta">Level ${c.lvl}</div></div><span></span></div>`).join("")||`<p class="muted">Robots need level ${ur} to fuse.</p>`}</div>`;let a="";if(n&&s&&n!==s){const o=Pf(n,s).slice(0,8),c=Df(e,n.id,s.id);a=`<div class="box"><b class="ox">Possible results</b><div class="bots">${o.map(l=>`<div class="botc">${this.pic(l.sp,!!t.dex[l.sp],40)}<div><b>${t.dex[l.sp]?re(tt[l.sp].name):"???"}</b> ${_a(l.sp)} ${Ms(tt[l.sp].el)}</div><b class="ox">${Ai(l.p,l.p<.1?1:0)}</b></div>`).join("")}</div><div class="row" style="margin-top:8px"><span class="grow">${Ln(c.cost||Lf(n,s),e.res)}</span><button class="btn ${c.ok?"gold":""}" data-a="fuseR" ${c.ok?"":"disabled"}>${c.ok?"🧬 Fuse":re(c.why||"")}</button></div><p class="muted" style="font-size:12px">The parents are not used up: they go back to work.</p></div>`}return`<div class="row" style="align-items:flex-start"><div class="grow" style="min-width:260px"><b class="ox">Parent A</b>${r("A")}</div><div class="grow" style="min-width:260px"><b class="ox">Parent B</b>${r("B")}</div></div>${a}`}dex(){const e=this.s,t=wt(e);return`<div class="grid" style="grid-template-columns:repeat(auto-fill,minmax(120px,1fr))">${Fd().map(s=>{const r=!!t.dex[s];return`<div class="card" style="align-items:center;text-align:center">${this.pic(s,r,72)}<b style="font-size:12px">${r?re(tt[s].name):"???"}</b>${_a(s)}${Ms(tt[s].el)}</div>`}).join("")}</div>`}panelHTML(e,t){const n=this.s,s=n.bases[e]?.items.find(l=>l.id===t);if(!s||s.lvl<1)return"";const r=_f(s.b,s.lvl);if(!r)return"";const a=oo(n,e,t),o=Ef(n,e,t),c=p_[s.b]||"output";return`<div class="box"><div class="row"><b class="ox grow">Robot operators</b><span class="good ox">+${Ai(o)} ${re(c)}</span></div><div class="row" style="margin-top:6px">${Array.from({length:r},(l,h)=>{const d=a[h];return d?`<div class="botc" style="grid-template-columns:40px 1fr auto;padding:4px 6px;flex:1;min-width:150px">${this.pic(d.sp,!0,40)}<div><b style="font-size:12px">${re(tt[d.sp].name)}</b><div class="meta">Lv ${d.lvl} · +${Ai(Xi(d,s.b))}${nr(d.sp,s.b)?" ✓":""}</div></div><button class="btn small" data-a="unassignR" data-id="${d.id}">✕</button></div>`:`<button class="btn small" style="flex:1;min-width:150px" data-a="pickOp" data-base="${e}" data-id="${t}">✚ Assign a robot</button>`}).join("")}</div>
      <div class="muted" style="font-size:11px;margin-top:4px">Suits: ${(Bc[s.b]||[]).map(l=>`${un[l].glyph} ${un[l].name}`).join(", ")}${s.lvl<16?" · more stations at levels 8 and 16":""}</div></div>`}pickerHTML(){const e=this.s,t=this.pickFor,n=e.bases[t.base]?.items.find(r=>r.id===t.item);if(!n)return"";const s=[...wt(e).list].sort((r,a)=>Xi(a,n.b)-Xi(r,n.b));return`<h1 style="font-size:20px">Assign to the ${re(at[n.b].name)}</h1><p class="muted" style="font-size:12px">Best fits first. A robot can work one station at a time.</p><div class="bots" style="max-height:52vh;overflow:auto;text-align:left">${s.map(r=>{const a=r.post?e.bases[r.post.base]?.items.find(o=>o.id===r.post.item):null;return`<div class="botc">${this.pic(r.sp,!0,44)}<div><b>${re(tt[r.sp].name)}</b> ${Ms(tt[r.sp].el)}<div class="meta">Lv ${r.lvl} · +${Ai(Xi(r,n.b))}${nr(r.sp,n.b)?" ✓ fits":""}${a?` · now at ${re(at[a.b].name)}`:""}</div></div><button class="btn small ${nr(r.sp,n.b)?"gold":""}" data-a="assignR" data-id="${r.id}">Assign</button></div>`}).join("")||'<p class="muted">No robots yet.</p>'}</div><button class="btn" data-a="closeModal">Close</button>`}reveal(e,t){const n=tt[e.sp],s=Nn[n.rarity];this.ui.modal(`<div class="ox muted" style="letter-spacing:.2em">NEW ROBOT ONLINE</div><div style="margin:8px auto;width:150px;height:150px;border-radius:24px;background:radial-gradient(circle, ${s.color}55, transparent 70%)"><img src="${this.A.studio.bot(e.sp)}" style="width:100%;height:100%"></div><h1>${re(n.name)}</h1>${_a(e.sp)} ${Ms(n.el)}<p class="desc">${re(n.desc||"")}</p>${t?`<div class="good ox">New in the Botdex: +${t} Dark Matter</div>`:""}<p class="muted" style="font-size:12px">Assign it to a building that suits its elements: tap a building, then "Assign a robot".</p><button class="btn gold" data-a="closeModal">Welcome aboard</button>`,{rays:tn(e.sp)>=2})}act(e,t){const n=this.s,s=this.A,r=this.ui;switch(e){case"robots":return r.openOver("robots"),s.audio.play("tap"),!0;case"rtabR":return this.tab=t.dataset.t,r.renderOver(),s.audio.play("tap"),!0;case"focusR":return this.focus=t.dataset.e||"",r.renderOver(),s.audio.play("tap"),!0;case"craftR":{const a=R_(n,+t.dataset.i,this.focus||void 0);return a.ok?(s.audio.play("build"),s.changed(),r.renderOver()):r.deny(a.why),!0}case"activateR":{const a=C_(n,t.dataset.id);return a.ok?(s.audio.play(tn(a.robot.sp)>=2?"levelup":"claim"),s.changed(),r.renderOver(),this.reveal(a.robot,a.dm)):r.deny(a.why),!0}case"feedR":{const a=P_(n,t.dataset.id);return a.ok?(s.audio.play("feed"),s.changed(),r.renderOver(),r.renderPanel()):r.deny(a.why),!0}case"unassignR":return E_(n,t.dataset.id),s.audio.play("tap"),s.changed(),r.renderOver(),r.renderPanel(),!0;case"pickOp":return this.pickFor={base:t.dataset.base,item:t.dataset.id},r.modal(this.pickerHTML()),s.audio.play("tap"),!0;case"assignR":{if(!this.pickFor)return!0;const a=w_(n,t.dataset.id,this.pickFor.base,this.pickFor.item);return a.ok?(s.audio.play("place"),r.closeModal(),s.changed(),r.renderPanel()):r.deny(a.why),!0}case"pickF":return t.dataset.s==="A"?this.fA=t.dataset.id:this.fB=t.dataset.id,r.renderOver(),s.audio.play("tap"),!0;case"fuseR":{const a=D_(n,this.fA,this.fB);return a.ok?(s.audio.play("build"),s.changed(),this.tab="cores",r.renderOver(),r.toast("The Fusion Lab hums to life: a new core is forming","good")):r.deny(a.why),!0}}return!1}}const Gd=["credits","metal","fuel","science"],ri=i=>`<span class="ci" style="color:${dt[i]?.color||"#fff"}">${dt[i]?.icon||""}</span>`;function Ln(i,e){return`<span class="costs">${Object.entries(i).filter(([,t])=>t>0).map(([t,n])=>`<span class="cost ${e&&(e[t]||0)<n?"short":""}" title="${dt[t]?.name||t}">${ri(t)}${qe(n)}</span>`).join("")}</span>`}class $_{constructor(e){this.app=e,this.sel=null,this.over="",this.tab="production",this.rtab="avail",this.bubbles=new Map,this.lastRes={},this.panelKey="",this.tick=0,this.launch=new V_(this),this.robots=new W_(this),document.addEventListener("click",t=>{const n=t.target.closest("[data-a]");n&&(t.stopPropagation(),this.act(n.dataset.a,n))}),document.addEventListener("change",t=>{const n=t.target;if(n.id==="aname"){const s=n.value.trim().slice(0,24);s&&(this.s.name=s,this.s.bases.earth.name=s,this.app.changed(),this.renderHud())}n.dataset.set&&this.app.setSetting(n.dataset.set,n.type==="range"?+n.value:n.value)})}get s(){return this.app.s}get R(){return this.app.R}renderHud(){const e=this.s,t=this.R,n=Sa(e,t);ht("#hud").innerHTML=`<div class="kchip" data-a="kard" title="Kardashev scale"><div class="ring" id="kring"><b id="kval">${n.toFixed(2)}</b></div><div class="nm"><b>${re(e.name)}</b><i id="ktitle">Kardashev ${n.toFixed(3)}</i></div></div>
      ${Gd.map(s=>`<div class="res" id="r-${s}" data-a="resinfo" data-r="${s}" style="--c:${dt[s].color}" title="${dt[s].name}"><span class="ic" style="color:${dt[s].color}">${dt[s].icon}</span><span class="v">0</span><span class="cap"><i></i></span></div>`).join("")}
      <div class="res" id="r-dm" data-a="resinfo" data-r="dm" title="Dark Matter"><span class="ic" style="color:${dt.dm.color}">${dt.dm.icon}</span><span class="v">0</span></div>
      <span class="sp"></span><span class="chip" id="energy" data-a="energy" title="Energy: generation / demand">⚡ <span>0</span></span><span class="chip" id="crews" title="Construction drones">🛸 <span>0/0</span></span><button class="ibtn" data-a="settings" title="Settings">⚙</button>`,this.lastRes={},this.updHud()}updHud(){const e=this.s,t=this.R;for(const o of[...Gd,"dm"]){const c=ht(`#r-${o}`);if(!c)continue;const l=Math.floor(e.res[o]||0);l!==this.lastRes[o]&&(c.querySelector(".v").textContent=qe(l),l>(this.lastRes[o]??l)&&(c.classList.remove("bump"),c.offsetWidth,c.classList.add("bump")),this.lastRes[o]=l);const h=t.cap[o],d=c.querySelector(".cap i");if(d&&isFinite(h)){const u=bt(l/Math.max(1,h));d.style.width=u*100+"%",c.classList.toggle("full",u>=.999),c.title=`${dt[o].name}: ${qe(l)} / ${qe(h)}`}}const n=ht("#energy");n&&(n.querySelector("span").textContent=`${qe(t.gen)} / ${qe(t.draw)}`,n.classList.toggle("low",t.gen<t.draw));const s=ht("#crews");s&&(s.querySelector("span").textContent=`${Es(e)}/${pr(e,t.m)}`);const r=Sa(e,t),a=ht("#kval");if(a){a.textContent=r.toFixed(2);const o=wa.find(l=>l>r)||3,c=[...wa].reverse().find(l=>l<=r)||.7;ht("#kring").style.setProperty("--p",bt((r-c)/(o-c))*100+"%"),ht("#ktitle").textContent=`Kardashev ${r.toFixed(3)}`}}renderNav(){const e=this.s.jobs.some(c=>c.kind==="research")?"":Object.keys(rt).some(c=>Ua(this.s,c).ok)?'<span class="rdot"></span>':"",t=this.s,n=Ye(t);if(this.app.world&&this.app.world.mode==="orbit"){ht("#nav").innerHTML=`<button data-a="base"><span class="g">🏠</span>Base</button><button data-a="orbitFocus" data-f="earth"><span class="g">🌍</span>Earth</button>${n.modules.core?'<button data-a="orbitFocus" data-f="station"><span class="g">🛰</span>Station</button>':""}<button data-a="launchctl"><span class="g">🚀</span>Launch</button>`;return}const s=Sn(t,"earth","launch")>0,r=Object.values(n.hangar).some(c=>c>0)&&t.jobs.every(c=>c.kind!=="mission"),a=Li(t)>0||wt(t).list.length>0,o=wt(t).cores.length>0;ht("#nav").innerHTML=`<button data-a="shop"><span class="g">🏗</span>Build</button><button data-a="research"><span class="g">🔬</span>Research${e}</button>${a?`<button data-a="robots"><span class="g">🤖</span>Robots${o?'<span class="rdot"></span>':""}</button>`:""}${s?`<button data-a="launchctl"><span class="g">🚀</span>Launch${r?'<span class="rdot"></span>':""}</button>`:""}${n.sats.length||n.modules.core?'<button data-a="orbit"><span class="g">🌍</span>Orbit</button>':""}<button data-a="goals"><span class="g">🎯</span>Goals</button><button data-a="kard"><span class="g">☀</span>Kardashev</button>`}renderObj(){const e=this.s,t=sr(e),n=ht("#obj");if(!t){n.classList.add("hidden");return}n.classList.remove("hidden");const s=hc(e,t,this.R),r=Ma.find(a=>a.id===t.ch);n.classList.toggle("done",s),n.innerHTML=`<div class="t">${re(r?r.name:"Objective")}</div><p>${re(t.text)}</p><div class="rw">Reward: ${Ln(t.reward)}</div>${s?'<button class="btn gold claim" data-a="claim">✓ Claim reward</button>':this.hint(t)}`}hint(e){if(e.kind==="build"||e.kind==="hq"){const t=e.kind==="hq"?"hq":e.b,n=this.s.bases.earth.items.find(s=>s.b===t);return n?`<div class="go" data-a="goto" data-id="${n.id}">Show me →</div>`:`<div class="go" data-a="shopFor" data-b="${t}">Open the build menu →</div>`}return e.kind==="tech"?'<div class="go" data-a="research">Open research →</div>':""}frameBubbles(){const e=this.s,t=this.app.world,n=this.R,s=ht("#bubbles"),r=new Set,a=e.bases[e.at];if(!a)return;const o=(c,l,h,d,u,f)=>{if(!l)return;const g=t.project(l);if(g.behind)return;r.add(c);let v=this.bubbles.get(c);v||(v=document.createElement("div"),v.className="bub",u&&(v.dataset.a=u,f&&(v.dataset.id=f)),s.appendChild(v),this.bubbles.set(c,v)),v.dataset.h!==h+d&&(v.innerHTML=h,v.className="bub "+d,v.dataset.h=h+d),v.style.left=g.x+"px",v.style.top=g.y+"px"};if(!t.ghost)for(const c of a.items){const l=t.topOf(c.id),h=Ci(e,c.id);if(h){const f=bt(1-(h.end-Date.now())/(h.end-h.start));o("t"+c.id,l,`<span>${an((h.end-Date.now())/1e3)}</span><div class="bar"><i style="width:${f*100}%"></i></div>`,"timer");continue}const d=n.item[c.id],u=c.held||0;if(d&&u>=Math.max(1,d.hold*.03)){const f=u>=d.hold*.98;o("c"+c.id,l,`<span class="bi" style="color:${dt[d.r].color}">${dt[d.r].icon}</span>${qe(u)}`,f?"full":"","collect",c.id)}}for(const[c,l]of this.bubbles)r.has(c)||(l.remove(),this.bubbles.delete(c))}popText(e,t,n,s="#fff"){const r=document.createElement("div");r.className="pop",r.textContent=n,r.style.left=e+"px",r.style.top=t+"px",r.style.color=s,document.body.appendChild(r),setTimeout(()=>r.remove(),1100)}select(e){this.sel=e,this.app.world.select(e),this.renderPanel()}panelSig(){const e=this.s,t=this.sel?Ct(e,e.at,this.sel):null;if(!t)return"";const n=Ci(e,t.id);return[t.id,t.lvl,t.x,t.z,n?n.id:"",Na(e,e.at,t.id).ok,Es(e),Math.floor((e.res.dm||0)/5),oo(e,e.at,t.id).map(s=>s.id+s.lvl).join()].join("|")}refreshPanel(){if(!this.sel)return;if(this.panelSig()!==this.panelKey){this.renderPanel();return}const t=this.s;Or("#panel [data-left]").forEach(a=>{const o=t.jobs.find(c=>c.id===a.dataset.left);o&&(a.textContent=an((o.end-Date.now())/1e3))}),Or("#panel [data-bar]").forEach(a=>{const o=t.jobs.find(c=>c.id===a.dataset.bar);o&&(a.style.width=bt(1-(o.end-Date.now())/(o.end-o.start))*100+"%")}),Or("#panel [data-dm]").forEach(a=>{const o=t.jobs.find(c=>c.id===a.dataset.dm);if(o){const c=ir((o.end-Date.now())/1e3);a.innerHTML=c?`${ri("dm")}${c} Finish now`:"Finish (free)"}});const n=Ct(t,t.at,this.sel),s=n&&this.R.item[n.id],r=ht("#panel #held");if(r&&s&&n){r.textContent=`${qe(n.held||0)} / ${qe(s.hold)}`;const a=ht("#panel #heldbar");a&&(a.style.width=bt((n.held||0)/s.hold)*100+"%")}Or("#panel [data-cost]").forEach(a=>{const[o,c]=a.dataset.cost.split(":");a.classList.toggle("short",(t.res[o]||0)<+c)})}renderPanel(){const e=ht("#panel"),t=this.s,n=this.sel?Ct(t,t.at,this.sel):null;if(!n){e.classList.add("hidden");return}e.classList.remove("hidden"),this.panelKey=this.panelSig();const s=at[n.b],r=this.R.m,a=Ci(t,n.id),o=lc(t,t.at,n.b);let c=`<button class="ibtn x" data-a="deselect">✕</button><h2>${re(s.name)}</h2><div class="sub">${n.lvl?`Level ${n.lvl} of ${s.max}`:"Under construction"}${!s.command&&o<s.max?` · up to ${o} at this ${t.at==="earth"?"Mission Control":"Colony Hub"} level`:""} · ${oh[s.cat]||""}</div><p class="desc">${re(s.desc)}</p>`;if(a){const h=ir((a.end-Date.now())/1e3);c+=`<div class="box"><div class="row"><b class="grow ox">${a.from===0?"Building":`Upgrading to level ${a.to}`}</b><b data-left="${a.id}">${an((a.end-Date.now())/1e3)}</b></div><div class="bar" style="margin:6px 0"><i data-bar="${a.id}" style="width:0%"></i></div><div class="row"><button class="btn gold small grow" data-a="finish" data-job="${a.id}" data-dm="${a.id}">${h?`${ri("dm")}${h} Finish now`:"Finish (free)"}</button><button class="btn small" data-a="cancel" data-job="${a.id}">Cancel</button></div></div>`}const l=this.R.item[n.id];if(l&&n.lvl>0&&(c+=`<div class="box"><div class="row"><span class="grow">${ri(l.r)} Stored here <b id="held" class="ox">${qe(n.held||0)} / ${qe(l.hold)}</b></span><button class="btn green small" data-a="collect" data-id="${n.id}" ${(n.held||0)>=1?"":"disabled"}>Collect</button></div><div class="bar green" style="margin-top:6px"><i id="heldbar" style="width:${bt((n.held||0)/l.hold)*100}%"></i></div><div class="muted" style="font-size:11px;margin-top:4px">Fills in ${Hd(n.lvl).toFixed(1)} h. Come back and tap the bubble to collect.</div></div>`),c+=this.statsHTML(n.b,Math.max(1,n.lvl),r,!a&&n.lvl<s.max),c+=this.robots.panelHTML(t.at,n.id),!a&&n.lvl>0){const h=Na(t,t.at,n.id);if(h.max)c+='<p class="good ox">Maximum level reached.</p>';else{const d=Ps(n.b,n.lvl+1,r);c+=`<div class="box"><div class="row"><b class="grow ox">Upgrade to level ${n.lvl+1}</b><span class="muted">⏱ ${an(fr(n.b,n.lvl+1,r))}</span></div><div style="margin:6px 0">${this.costLive(d)}</div>`,h.reqs&&h.reqs.length&&(c+=`<ul class="reqs">${h.reqs.map(([u,f])=>`<li>${re(at[u].name)} level ${f}</li>`).join("")}</ul>`),c+=`<button class="btn ${h.ok?"gold":""}" style="width:100%" data-a="upgrade" data-id="${n.id}" ${h.ok||h.why==="Not enough resources"?"":"disabled"}>⬆ Upgrade</button>${h.ok?"":`<p class="why">${re(h.why||"")}</p>`}</div>`}}n.b==="research"&&(c+='<button class="btn" style="width:100%" data-a="research">🔬 Open research</button>'),(n.b==="launch"||n.b==="vab")&&n.lvl>0&&(c+=`<button class="btn" style="width:100%" data-a="ltab" data-t="${n.b==="vab"?"rockets":"missions"}">🚀 Launch Control</button>`),c+=`<div class="row" style="margin-top:10px"><button class="btn small" data-a="move" data-id="${n.id}">✥ Move</button>${cc(t,t.at,n.id)?`<button class="btn small red" data-a="demolish" data-id="${n.id}">Demolish</button>`:""}</div>`,e.innerHTML=c,this.refreshPanel()}costLive(e){return`<span class="costs">${Object.entries(e).map(([t,n])=>`<span class="cost ${(this.s.res[t]||0)<n?"short":""}" data-cost="${t}:${n}">${ri(t)}${qe(n)}</span>`).join("")}</span>`}statsHTML(e,t,n,s){const r=Jo(e,t,n),a=s?Jo(e,t+1,n):null,o=[],c=(l,h)=>h!==void 0&&h>l?`<span class="up">→ ${qe(h)}</span>`:"";for(const l in r.prod)o.push(`<tr><td>${ri(l)} ${dt[l].name} per hour</td><td>${qe(r.prod[l])}${c(r.prod[l],a?.prod[l])}</td></tr>`);for(const l in r.cap)o.push(`<tr><td>${ri(l)} ${dt[l].name} storage</td><td>+${qe(r.cap[l])}${c(r.cap[l],a?.cap[l])}</td></tr>`);return r.gen&&o.push(`<tr><td>⚡ Energy generated</td><td>${qe(r.gen)}${c(r.gen,a?.gen)}</td></tr>`),r.draw&&o.push(`<tr><td>⚡ Energy used</td><td>${qe(r.draw)}${a&&a.draw>r.draw?`<span class="up" style="color:var(--amber)">→ ${qe(a.draw)}</span>`:""}</td></tr>`),r.speed&&o.push(`<tr><td>🔬 Research speed</td><td>+${Math.round(r.speed*100)}%</td></tr>`),o.length?`<table class="stats">${o.join("")}</table>`:""}openOver(e,t){this.over=e,t&&(e==="shop"?this.tab=t:this.rtab=t),this.select(null),this.renderOver(),this.app.platform.gameplayStop()}closeOver(){this.over="",ht("#over").classList.add("hidden"),this.app.platform.gameplayStart()}renderOver(){const e=ht("#over");if(!this.over){e.classList.add("hidden");return}e.classList.remove("hidden");const t=this.s;if(this.over==="shop"){const n=t.at,s=["core","production","power","storage","science","spaceflight"].filter(o=>Object.values(at).some(c=>c.cat===o&&c.bases.includes(n)));s.includes(this.tab)||(this.tab=s[0]);const r=o=>!o||!!t.tech[o]||rt[o]&&rt[o].req.every(c=>t.tech[c]),a=Object.entries(at).filter(([,o])=>o.cat===this.tab&&o.bases.includes(n)&&!o.command&&r(o.req&&o.req.tech));e.innerHTML=`<div class="head"><h1>Build</h1><span class="chip">🛸 ${Es(t)}/${pr(t,this.R.m)} drones busy</span><button class="ibtn" data-a="close">✕</button></div><div class="tabs">${s.map(o=>`<button class="tab ${o===this.tab?"on":""}" data-a="tab" data-t="${o}">${oh[o]}</button>`).join("")}</div>
        <div class="body"><div class="grid">${a.map(([o,c])=>this.shopCard(o,c)).join("")||'<p class="muted">Nothing to build here yet.</p>'}</div></div>`;return}if(this.over==="research"){e.innerHTML=this.researchHTML();return}if(this.over==="launch"){e.innerHTML=this.launch.html();return}if(this.over==="designer"){e.innerHTML=this.launch.designerHTML();return}if(this.over==="robots"){e.innerHTML=this.robots.html();return}if(this.over==="goals"){e.innerHTML=this.goalsHTML();return}}shopCard(e,t){const n=this.s,s=Ia(n,n.at,e),r=Fn(n,n.at),a=oc(n,n.at,e),o=Wd(t,r),c=Ps(e,1,this.R.m),l=!s.ok&&s.why!=="Not enough resources"&&!s.crews;return`<div class="card ${l?"locked":""}"><div class="thumb"><img src="${this.app.studio.building(e,1,this.app.world.look)}" alt=""></div><div class="row"><b class="grow">${re(t.name)}</b><span class="n">${a}/${o}</span></div><p class="desc">${re(t.desc)}</p>
      <div class="row"><span class="grow">${this.costLive(c)}</span><span class="muted" style="font-size:11px">⏱ ${an(fr(e,1,this.R.m))}</span></div><button class="btn ${s.ok?"gold":""} small" data-a="buy" data-b="${e}" ${s.ok||s.why==="Not enough resources"?"":"disabled"}>${l?"🔒 "+re(s.why||""):"Build"}</button></div>`}researchHTML(){const e=this.s,t=e.jobs.filter(o=>o.kind==="research"),n=Object.keys(rt),s=[["avail","Available"],...Object.entries(uo).map(([o,c])=>[o,c.name]),["done","Done"]];let r=n.filter(o=>this.rtab==="avail"?!e.tech[o]&&rt[o].req.every(c=>e.tech[c]):this.rtab==="done"?!!e.tech[o]:rt[o].branch===this.rtab);r.sort((o,c)=>rt[o].tier-rt[c].tier||(rt[o].hq||0)-(rt[c].hq||0));const a=t.map(o=>{const c=rt[o.tech],l=ir((o.end-Date.now())/1e3);return`<div class="now"><div class="grow"><div class="tier">RESEARCHING</div><b class="ox" style="font-size:16px">${re(c.name)}</b><div class="bar gold" style="margin-top:6px"><i style="width:${bt(1-(o.end-Date.now())/(o.end-o.start))*100}%"></i></div></div><div style="text-align:right"><b class="ox">${an((o.end-Date.now())/1e3)}</b><br><button class="btn gold small" data-a="finish" data-job="${o.id}">${l?`${ri("dm")}${l}`:"Finish"}</button></div></div>`}).join("");return`<div class="head"><h1>Research</h1><span class="chip">🔬 ${ac(e)}/${rc(e,this.R.m)} slots</span><button class="ibtn" data-a="close">✕</button></div><div class="tabs">${s.map(([o,c])=>`<button class="tab ${o===this.rtab?"on":""}" data-a="rtab" data-t="${o}">${re(c)}</button>`).join("")}</div>
      <div class="body">${a}<div class="techs">${r.map(o=>this.techCard(o)).join("")||'<p class="muted">Nothing here yet.</p>'}</div></div>`}techCard(e){const t=this.s,n=rt[e],s=Ua(t,e),r=!!t.tech[e],a=t.jobs.some(h=>h.kind==="research"&&h.tech===e),o=tc(n),c=r?"done":a?"busy":s.locked?"locked":s.ok?"ready":"",l=s.time||sc(e,this.R);return`<div class="tech ${c}" style="--bc:${uo[n.branch]?.color}"><div class="row"><span class="tier grow">${re(uo[n.branch]?.name||"")} · TIER ${n.tier}${n.hq?` · MC ${n.hq}`:""}</span>${r?'<span class="good">✓</span>':""}</div><b>${re(n.name)}</b><p class="desc">${re(n.desc)}</p>${n.unlocks?`<div class="unl">Unlocks: ${re(n.unlocks)}</div>`:""}
      ${r?"":a?'<div class="warn ox">In progress</div>':`<div class="row"><span class="grow">${this.costLive(o)}</span><span class="muted" style="font-size:11px">⏱ ${an(l)}</span></div><button class="btn small ${s.ok?"gold":""}" data-a="study" data-t="${e}" ${s.ok||s.why==="Not enough resources"?"":"disabled"}>${s.ok?"Research":re(s.why||"")}</button>`}</div>`}goalsHTML(){const e=this.s,t=sr(e);let n=`<div class="head"><h1>Goals</h1><span class="chip">${lu(e)}/${cu()} complete</span><button class="ibtn" data-a="close">✕</button></div><div class="body" style="max-width:760px;margin:0 auto;width:100%">`;for(const s of Ma){if(!s.steps.some(a=>e.obj.claimed[a.id]||t&&t.id===a.id)){n+=`<div class="box muted">🔒 ${re(s.name)}</div>`;continue}n+=`<div class="box"><b class="ox">${re(s.name)}</b><p class="desc">${re(s.intro)}</p><ul class="reqs">${s.steps.map(a=>`<li class="${e.obj.claimed[a.id]?"ok":""}" style="${t&&t.id===a.id?"color:var(--gold)":e.obj.claimed[a.id]?"":"opacity:.55"}">${re(a.text)}</li>`).join("")}</ul></div>`}return n+"</div>"}kardHTML(){const e=this.s,t=this.R,n=Sa(e,t),s=e.kMax||0,r=a=>bt((a-.7)/2.3)*100;return`<div class="ox muted" style="letter-spacing:.2em">THE KARDASHEV SCALE</div><div class="kbig">${n.toFixed(3)}</div><b class="ox">${re(up(n))}</b>
      <p class="desc">How much energy a civilisation commands. Humanity today runs about 20 terawatts (0.73). Type I harnesses a whole planet, Type II a star, Type III a galaxy. Every watt you generate moves the needle.</p>
      <div class="kscale">${[[.73,"Today"],[1,"Type I"],[2,"Type II"],[3,"Type III"]].map(([a,o])=>`<span class="lb" style="left:${r(+a)}%">${o}</span>`).join("")}<span class="mk" style="left:${r(n)}%"></span></div>
      <div class="mlist">${wa.map(a=>`<div class="ms ${s>=a?"got":""}">${a.toFixed(2)}<i>${s>=a?"reached":`${ri("dm")}${$f(a)}`}</i></div>`).join("")}</div>
      <p class="muted" style="font-size:12px">Power now: ${qe(t.gen)} generated, ${qe(t.draw)} used.</p><button class="btn" data-a="closeModal">Close</button>`}toast(e,t=""){const n=document.createElement("div");n.className="toast "+t,n.innerHTML=e,ht("#toasts").appendChild(n),setTimeout(()=>n.remove(),3200)}modal(e,t={}){const n=ht("#modal");n.innerHTML=`${t.rays?'<div class="rays"></div>':""}<div class="box ${t.wide?"wide":""}">${e}</div>`,n.classList.remove("hidden"),this.app.platform.gameplayStop()}closeModal(){ht("#modal").classList.add("hidden"),ht("#modal").innerHTML="",this.over||this.app.platform.gameplayStart()}deny(e){e&&this.toast(re(e),"bad"),this.app.audio.play("deny")}settingsHTML(){const e=this.s.settings;return`<h1>Settings</h1><div class="box" style="text-align:left"><label class="ox">Agency name<input id="aname" value="${re(this.s.name)}" maxlength="24" style="width:100%;margin-top:6px;padding:10px;border-radius:10px;border:1px solid var(--line);background:#0d1a2e;color:#fff;font:600 15px Barlow"></label>
      <label class="row" style="margin-top:10px"><span class="grow">Sound effects</span><input type="range" min="0" max="1" step="0.05" value="${e.sfx}" data-set="sfx"></label><label class="row"><span class="grow">Music</span><input type="range" min="0" max="1" step="0.05" value="${e.music}" data-set="music"></label>
      <label class="row"><span class="grow">Graphics</span><select data-set="quality" style="background:#0d1a2e;color:#fff;border:1px solid var(--line);border-radius:8px;padding:6px">${["auto","high","low"].map(t=>`<option ${e.quality===t?"selected":""}>${t}</option>`).join("")}</select></label></div>
      <p class="muted" style="font-size:12px">Graphics changes apply after a reload. Camera: drag to pan, scroll or pinch to zoom, right-drag, two-finger twist or Q/E to rotate.</p><div class="row" style="justify-content:center"><button class="btn red small" data-a="reset">Start over</button><button class="btn" data-a="closeModal">Close</button></div>`}act(e,t){const n=this.app,s=this.s;if(n.audio.unlock(),this.launch.act(e,t)||this.robots.act(e,t))return;const r=t.dataset.id,a=r?Ct(s,s.at,r):void 0;switch(e){case"orbit":n.openOrbit("earth"),n.audio.play("whoosh");break;case"base":n.closeOrbit(),n.audio.play("whoosh");break;case"orbitFocus":n.world.orbit?.setFocus(t.dataset.f),n.audio.play("tap");break;case"shop":this.openOver("shop"),n.audio.play("tap");break;case"shopFor":{const o=at[t.dataset.b];this.openOver("shop",o?o.cat:void 0),n.audio.play("tap");break}case"research":this.openOver("research",this.rtab),n.audio.play("tap");break;case"goals":this.openOver("goals"),n.audio.play("tap");break;case"close":this.closeOver(),n.audio.play("tap");break;case"tab":this.tab=t.dataset.t,this.renderOver(),n.audio.play("tap");break;case"rtab":this.rtab=t.dataset.t,this.renderOver(),n.audio.play("tap");break;case"kard":this.modal(this.kardHTML(),{wide:!0}),n.audio.play("tap");break;case"settings":this.modal(this.settingsHTML()),n.audio.play("tap");break;case"closeModal":this.closeModal(),n.audio.play("tap");break;case"claim":{const o=hu(s);if(o){n.audio.play("claim"),this.toast(`Objective complete: ${Ln(o.reward)}`,"gold"),n.changed();const c=sr(s);if(c&&c.ch!==o.ch){const l=Ma.find(h=>h.id===c.ch);l&&n.enqueue(()=>this.modal(`<div class="ox muted" style="letter-spacing:.2em">NEW CHAPTER</div><h1>${re(l.name)}</h1><p class="desc">${re(l.intro)}</p><button class="btn gold" data-a="closeModal">Onward</button>`,{rays:!0}))}}break}case"goto":if(r){const o=n.world.centerOf(r);o&&n.world.focus(o.x,o.z),this.select(r),n.audio.play("tap")}break;case"deselect":this.select(null);break;case"collect":a&&n.collect(a.id);break;case"upgrade":if(a){const o=eu(s,s.at,a.id);o.ok?(n.audio.play("build"),n.changed(),this.renderPanel()):this.deny(o.why)}break;case"finish":{const o=ru(s,t.dataset.job);o.ok?(n.audio.play("done"),n.tickNow(),this.renderOver()):this.deny(o.why);break}case"cancel":au(s,t.dataset.job)&&(n.audio.play("tap"),this.toast("Cancelled: half the cost refunded"),n.changed(),this.sel&&!Ct(s,s.at,this.sel)&&this.select(null));break;case"buy":{const o=t.dataset.b,c=Ia(s,s.at,o);if(!c.ok){this.deny(c.why);break}this.closeOver(),n.startPlacing(o);break}case"study":{const o=su(s,t.dataset.t);o.ok?(n.audio.play("buy"),n.changed(),this.renderOver(),this.renderNav()):this.deny(o.why);break}case"move":a&&n.startPlacing(a.b,a.id);break;case"demolish":a&&this.modal(`<h1>Demolish?</h1><p class="desc">${re(at[a.b].name)} (level ${a.lvl}) will be cleared. Nothing is refunded.</p><div class="row" style="justify-content:center"><button class="btn" data-a="closeModal">Keep it</button><button class="btn red" data-a="demolishYes" data-id="${a.id}">Demolish</button></div>`);break;case"demolishYes":a&&nu(s,s.at,a.id)&&(this.closeModal(),this.select(null),n.changed(),n.audio.play("build"));break;case"place":n.confirmPlace();break;case"rotate":n.world.rotateGhost(),n.audio.play("tap");break;case"unplace":n.cancelPlace();break;case"resinfo":{const o=t.dataset.r,c=this.R,l=(c.prod[o]||0)+(c.collect[o]||0);this.toast(`${dt[o].icon} <b>${dt[o].name}</b>: ${qe(s.res[o]||0)}${isFinite(c.cap[o])?` / ${qe(c.cap[o])}`:""}${l?` · +${qe(l)}/h`:""}`);break}case"energy":{const o=this.R;this.toast(o.gen>=o.draw?`⚡ ${qe(o.gen)} generated, ${qe(o.draw)} used. All systems powered.`:`⚡ Power shortage: ${qe(o.gen)} of ${qe(o.draw)}. Production runs at ${Math.round((.25+.75*o.eff)*100)}%. Build or upgrade Solar Farms.`,o.gen>=o.draw?"good":"bad");break}case"reset":this.modal('<h1>Start over?</h1><p class="desc">Your whole programme will be erased. This cannot be undone.</p><div class="row" style="justify-content:center"><button class="btn" data-a="closeModal">Cancel</button><button class="btn red" data-a="resetYes">Erase everything</button></div>');break;case"resetYes":n.reset();break}}}const $f=i=>Math.round(10+(i-.7)*60);class q_{constructor(){this.ctx=null,this.out=null,this.vol=.8,this.mvol=.45,this.muted=!1,this.music=null,this.timer=0}unlock(){if(this.ctx){this.ctx.state==="suspended"&&this.ctx.resume();return}try{this.ctx=new(window.AudioContext||window.webkitAudioContext),this.out=this.ctx.createGain(),this.out.gain.value=this.muted?0:this.vol,this.out.connect(this.ctx.destination)}catch{this.ctx=null}}setVolume(e){this.vol=e,this.out&&(this.out.gain.value=this.muted?0:e)}setMuted(e){this.muted=e,this.out&&(this.out.gain.value=e?0:this.vol),this.music&&(this.music.bus.gain.value=e?0:this.mvol*.4)}tone(e,t,n,s="sine",r=.2,a=0){const o=this.ctx,c=o.createOscillator(),l=o.createGain();c.type=s,c.frequency.setValueAtTime(e,t),a&&c.frequency.exponentialRampToValueAtTime(Math.max(30,e*a),t+n),l.gain.setValueAtTime(0,t),l.gain.linearRampToValueAtTime(r,t+.008),l.gain.exponentialRampToValueAtTime(1e-4,t+n),c.connect(l),l.connect(this.out),c.start(t),c.stop(t+n+.05)}noise(e,t,n=.2,s=800){const r=this.ctx,a=r.createBuffer(1,Math.floor(r.sampleRate*t),r.sampleRate),o=a.getChannelData(0);for(let d=0;d<o.length;d++)o[d]=(Math.random()*2-1)*(1-d/o.length);const c=r.createBufferSource();c.buffer=a;const l=r.createBiquadFilter();l.type="lowpass",l.frequency.value=s;const h=r.createGain();h.gain.value=n,c.connect(l),l.connect(h),h.connect(this.out),c.start(e)}play(e,t=1){if(!this.ctx||!this.out||this.muted)return;const n=this.ctx.currentTime;switch(e){case"tap":this.tone(880,n,.06,"triangle",.08);break;case"collect":{const s=Math.min(6,2+Math.floor(Math.log10(Math.max(1,t))));[0,4,7,12,16,19].slice(0,s).forEach((r,a)=>this.tone(988*Math.pow(2,r/12),n+a*.055,.22,"triangle",.12));break}case"harvest":[0,5,9].forEach((s,r)=>this.tone(660*Math.pow(2,s/12),n+r*.06,.2,"square",.05)),this.tone(1320,n+.2,.3,"sine",.08);break;case"build":this.noise(n,.12,.25,500),this.tone(120,n,.18,"sine",.3,.5);break;case"place":this.tone(220,n,.12,"sine",.25,.6),this.noise(n,.08,.15,1200);break;case"done":[0,4,7,12].forEach((s,r)=>this.tone(523*Math.pow(2,s/12),n+r*.08,.3,"triangle",.12));break;case"feed":this.tone(300,n,.15,"sawtooth",.06,2.2),this.tone(600,n+.05,.12,"square",.04,1.6);break;case"levelup":[0,4,7,12,16,19,24].forEach((s,r)=>this.tone(392*Math.pow(2,s/12),n+r*.07,.5,"triangle",.13)),[0,4,7].forEach(s=>this.tone(784*Math.pow(2,s/12),n+.55,.9,"sine",.09));break;case"deny":this.tone(180,n,.16,"square",.07,.7);break;case"buy":this.tone(660,n,.1,"triangle",.1),this.tone(990,n+.08,.18,"triangle",.1);break;case"claim":[0,7,12].forEach((s,r)=>this.tone(659*Math.pow(2,s/12),n+r*.07,.35,"triangle",.12));break;case"whoosh":this.noise(n,.35,.18,2400);break;case"hit":this.noise(n,.09,.22,900),this.tone(170,n,.12,"square",.07,.5);break;case"crit":this.noise(n,.18,.32,1800),this.tone(95,n,.28,"sawtooth",.11,.4),this.tone(1250,n+.02,.16,"triangle",.06,.5);break;case"launch":this.noise(n,1.8,.32,320),this.tone(55,n,1.8,"sawtooth",.1,2.6),this.noise(n+.2,1.4,.12,2600);break;case"crystal":[0,7,12,19].forEach((s,r)=>this.tone(1046*Math.pow(2,s/12),n+r*.05,.45,"sine",.07)),this.tone(2093,n+.22,.6,"triangle",.03);break;case"evolve":[0,4,7,11,14,19,24].forEach((s,r)=>{this.tone(330*Math.pow(2,s/12),n+r*.06,.55,"triangle",.1),this.tone(660*Math.pow(2,s/12),n+r*.06+.02,.4,"sine",.04)}),this.noise(n+.42,.5,.08,5e3);break;case"sparkle":[12,19,24,31].forEach((s,r)=>this.tone(784*Math.pow(2,s/12)/2,n+r*.045,.3,"sine",.06));break}}setMusic(e){this.mvol=e,this.music?this.music.bus.gain.setTargetAtTime(this.muted?0:e*.4,this.ctx.currentTime,.4):e>0&&this.startMusic()}startMusic(){if(!this.ctx||this.music||this.mvol<=0)return;const e=this.ctx,t=e.createGain();t.gain.value=0,t.gain.setTargetAtTime(this.muted?0:this.mvol*.4,e.currentTime,2),t.connect(e.destination);const n=e.createBiquadFilter();n.type="lowpass",n.frequency.value=1200,n.connect(t),this.music={bus:t,next:e.currentTime+.5,chord:0,lp:n},this.timer=window.setInterval(()=>this.tick(),300)}tick(){const e=this.ctx,t=this.music;if(!e||!t||e.state!=="running")return;const n=e.currentTime;if(n<t.next)return;const s=[[261.63,329.63,392,493.88],[220,261.63,329.63,392],[174.61,220,261.63,329.63],[196,246.94,293.66,392],[233.08,293.66,349.23,440]],r=s[t.chord%s.length];t.chord+=1+(Math.random()<.25?1:0);const a=9;for(const o of r)for(const c of[-6,5]){const l=e.createOscillator();l.type="sawtooth",l.frequency.value=o/2,l.detune.value=c;const h=e.createGain();h.gain.setValueAtTime(0,n),h.gain.linearRampToValueAtTime(.011,n+3),h.gain.setValueAtTime(.011,n+a-2.5),h.gain.linearRampToValueAtTime(0,n+a+1),l.connect(h),h.connect(t.lp),l.start(n),l.stop(n+a+1.5)}for(let o=0;o<3;o++){const c=r[Math.floor(Math.random()*r.length)]*2,l=e.createOscillator();l.type="sine",l.frequency.value=c;const h=e.createGain(),d=n+1+o*2.4+Math.random();h.gain.setValueAtTime(0,d),h.gain.linearRampToValueAtTime(.03,d+.01),h.gain.exponentialRampToValueAtTime(1e-4,d+2.5),l.connect(h),h.connect(t.bus),l.start(d),l.stop(d+2.6)}t.lp.frequency.setTargetAtTime(800+Math.random()*900,n,3),t.next=n+a-1.5}}class X_{constructor(){this.version="2.0-dev",this.platform=Zf,this.audio=new q_,this.last=performance.now(),this.acc=0,this.saveAt=0,this.queue=[],this.placing=null}async boot(){await this.platform.init(),this.platform.loadingStart();let e=null;try{e=this.platform.load(lh)}catch{e=null}let t=null;try{t=e?JSON.parse(e):null}catch{t=null}this.s=t&&t.v?ip(t):Ko();const n=Date.now()-this.s.last,s={...this.s.res},r=Zo(this.s,Date.now());this.R=Ri(this.s),this.s.stats.sessions++,this.world=new N_(ht("#gl"),this.s.settings.quality),this.studio=new F_(this.world.renderer),this.ui=new $_(this),this.world.setWorld(this.s.at,this.s.bases[this.s.at].body),this.world.sync(this.s),this.world.onTap=l=>this.tapped(l),this.world.onGhostMove=()=>this.ghostMoved();const a=Rr(this.s,this.s.at),o=(a.lo+a.hi)/2-26;this.world.focus(o,o+2,30+a.side*.55),this.world.cam.dist=30+a.side*.55,this.ui.renderHud(),this.ui.renderNav(),this.ui.renderObj(),this.audio.setVolume(this.s.settings.sfx),this.audio.mvol=this.s.settings.music,this.platform.onMute=l=>this.audio.setMuted(l),this.audio.setMuted(this.platform.muted()),document.addEventListener("pointerdown",()=>{this.audio.unlock(),this.audio.startMusic()},{once:!0}),document.addEventListener("visibilitychange",()=>{document.hidden?this.save():this.tickNow()}),window.addEventListener("pagehide",()=>this.save()),window.__app=this,window.__G=gp,requestAnimationFrame(l=>this.loop(l)),this.platform.loadingStop();const c=ht("#load");c.style.opacity="0",setTimeout(()=>c.remove(),500),this.platform.gameplayStart(),this.s.stats.sessions===1&&this.s.obj.i===0?this.enqueue(()=>this.ui.modal(`<div class="ox muted" style="letter-spacing:.2em">CHAPTER 1</div><h1>Humble Beginnings</h1><p class="desc">A patch of coastal scrubland, a borrowed budget and a dream. Build the programme that will carry humanity from this launch pad to the stars, and one day to a civilisation spanning the galaxy.</p><p class="desc">Tap the bubbles over your Metal Mine and Agency Office to collect, then follow the goals card: every goal pays a reward.</p><button class="btn gold" data-a="closeModal">Let's begin</button>`,{rays:!0})):n>5*6e4&&this.enqueue(()=>this.report(n,s,r))}report(e,t,n){const s=Object.keys(dt).filter(o=>(this.s.res[o]||0)-(t[o]||0)>=1).map(o=>`<span class="cost">${dt[o].icon} +${qe(this.s.res[o]-t[o])}</span>`).join(" "),r=this.s.bases[this.s.at].items.reduce((o,c)=>o+(c.held||0),0),a=n.filter(o=>o.kind==="build"||o.kind==="research").map(o=>o.kind==="build"?`${re(at[o.b].name)} → level ${o.lvl}`:`Researched ${re(rt[o.tech].name)}`);this.ui.modal(`<div class="ox muted" style="letter-spacing:.2em">WELCOME BACK</div><h1>${an(e/1e3)} away</h1><div class="report"><div>${s||"Your stockpile is full or unchanged."}</div>${r>=1?`<div>Waiting in your collectors: <b>${qe(r)}</b>. Tap the bubbles!</div>`:""}${a.length?`<div>${a.slice(0,6).join("<br>")}</div>`:""}</div><button class="btn gold" data-a="closeModal">Back to work</button>`)}loop(e){const t=Math.min(.1,(e-this.last)/1e3);this.last=e,this.acc+=t,this.s.stats.playS+=t,this.acc>=.25&&(this.acc=0,this.tick()),this.world.frame(this.s,t,n=>{const s=Ct(this.s,this.s.at,n);return!!s&&s.lvl>0&&this.R.eff>.5}),this.ui.frameBubbles(),this.ui.refreshPanel(),this.queue.length&&ht("#modal").classList.contains("hidden")&&!this.placing&&this.queue.shift()(),requestAnimationFrame(n=>this.loop(n))}tickNow(){this.tick(),this.changed()}tick(){const e=Zo(this.s,Date.now());this.R=Ri(this.s);for(const s of e)this.note(s);e.length&&this.changed();for(const s of nc.splice(0))s.kind==="starters"&&this.enqueue(()=>this.ui.modal(`<div class="ox muted" style="letter-spacing:.2em">ROBOTICS WORKSHOP ONLINE</div><h1>Your first robots</h1><p class="desc">Two robot cores are waiting in the Workshop. Robots make life easier for your people: put each one to work in a building that suits its elements and it boosts that building's output.</p><p class="desc">Build a Robot Dock to house them, then open <b>Robots → Workshop</b> to activate them.</p><button class="btn gold" data-a="closeModal">Let's meet them</button>`,{rays:!0}));this.ui.updHud(),this.ui.tick++,this.ui.tick%4===0&&this.ui.renderObj(),this.ui.tick%12===0&&this.ui.renderNav();const t=Sa(this.s,this.R),n=wa.find(s=>s>(this.s.kMax||0)&&t>=s);if(n){this.s.kMax=n;const s=$f(n);this.s.res.dm=(this.s.res.dm||0)+s,this.audio.play("levelup"),this.platform.happytime(),this.enqueue(()=>this.ui.modal(`<div class="ox muted" style="letter-spacing:.2em">KARDASHEV MILESTONE</div><div class="big">${n.toFixed(2)}</div><p class="desc">Your civilisation now commands more power than ever. Reward:</p><div class="rewards">${Ln({dm:s})}</div><button class="btn gold" data-a="closeModal">Onward</button>`,{rays:!0}))}Date.now()>this.saveAt&&(this.saveAt=Date.now()+1e4,this.save())}note(e){if(e.kind==="build"){const t=at[e.b];this.audio.play("done");const n=this.world.topOf(e.item);n&&this.world.burst(n,"#ffd36a",28),this.ui.toast(`${re(t.name)} ${e.first?"is ready":`reached level ${e.lvl}`}`,"good"),e.b==="hq"&&(this.platform.happytime(),this.ui.toast("The spaceport grows: more room to build","gold"))}else e.kind==="core"?(this.audio.play("claim"),this.ui.toast(`${e.fused?"Fusion complete":"Core assembled"}: a ${Nn[tt[e.sp].rarity].name} core is ready to activate (Robots → Workshop)`,"gold"),this.ui.renderNav(),this.ui.over==="robots"&&this.ui.renderOver()):e.kind==="rocket"?(this.audio.play("done"),this.ui.toast(`${re(e.name)} is assembled and waiting on the pad`,"good"),this.ui.renderNav(),this.ui.over==="launch"&&this.ui.renderOver()):e.kind==="mission"?(this.audio.play("levelup"),this.platform.happytime(),e.first?this.enqueue(()=>this.ui.modal(`<div class="ox muted" style="letter-spacing:.2em">MISSION ACCOMPLISHED</div><h1>${re(e.name)}</h1>${e.reward?`<div class="rewards">${Ln(e.reward)}</div>`:""}<button class="btn gold" data-a="closeModal">Onward</button>`,{rays:!0})):this.ui.toast(`${re(e.name)} complete`,"good")):e.kind==="sat"||e.kind==="module"?(this.audio.play("levelup"),this.ui.toast(`${re(e.name)}: in orbit and working`,"gold"),this.ui.renderNav()):e.kind==="fail"?(this.audio.play("deny"),this.ui.toast(`${re(e.name)} failed. The engineers learned something: +${qe(e.sci)} science`,"bad")):e.kind==="research"&&(this.audio.play("levelup"),this.ui.toast(`Research complete: <b>${re(rt[e.tech].name)}</b>`,"gold"),this.ui.renderNav(),this.ui.over==="research"&&this.ui.renderOver())}changed(){this.R=Ri(this.s),this.world.sync(this.s),this.syncPad(),this.world.orbit&&this.world.orbit.sync(Ye(this.s)),this.ui.renderObj(),this.ui.renderPanel(),this.ui.renderNav(),this.ui.updHud(),this.saveAt=Math.min(this.saveAt,Date.now()+1500)}syncPad(){const e=this.s.bases.earth.items.find(r=>r.b==="launch"&&r.lvl>0),t=Ye(this.s),n=Object.keys(t.hangar).find(r=>t.hangar[r]>0),s=n?Tr(this.s,n):null;this.world.setPadRocket(this.s.at==="earth"&&!this.s.jobs.some(r=>r.kind==="mission"&&Date.now()-r.start<12e3)?s:null,e?e.id:null)}launched(e){const t=this.s.bases.earth.items.find(n=>n.b==="launch");this.world.mode==="orbit"&&this.closeOrbit(),t&&this.world.launchFx(e,t.id),this.audio.play("launch"),this.ui.toast(`Liftoff! ${re(e.name)} is on its way`,"gold"),this.changed(),this.ui.renderNav()}openOrbit(e){this.ui.select(null),this.world.openOrbit(Ye(this.s)),this.world.orbit.setFocus(e),document.body.classList.add("orbiting"),this.ui.renderNav()}closeOrbit(){this.world.closeOrbit(),document.body.classList.remove("orbiting"),this.ui.renderNav()}enqueue(e){this.queue.push(e)}tapped(e){if(!this.placing){if(e.item){const t=Ct(this.s,this.s.at,e.item);t&&this.R.item[t.id]&&(t.held||0)>=1&&this.ui.sel!==t.id&&this.collect(t.id),this.ui.select(e.item),this.audio.play("tap");return}this.ui.select(null)}}collect(e){const t=iu(this.s,this.s.at,e,this.R);if(!t)return;if(t.n<=0){this.ui.toast(`${dt[t.r].name} storage is full. Build or upgrade a Logistics Depot.`,"bad"),this.audio.play("deny");return}this.audio.play("collect",t.n);const n=this.world.topOf(e);if(n){this.world.burst(n,dt[t.r].color,16+Math.min(24,Math.floor(Math.log10(t.n)*5)));const s=this.world.project(n);this.ui.popText(s.x,s.y-10,`+${qe(t.n)} ${dt[t.r].icon}`,dt[t.r].color)}t.full&&this.ui.toast(`${dt[t.r].name} storage is full: the rest stays in the building.`,"bad"),this.changed()}startPlacing(e,t){const n=this.s;let s=0,r=0,a=0;if(t){const h=Ct(n,n.at,t);s=h.x,r=h.z,a=h.r}else{const h=Zd(n,n.at,e);if(!h){this.ui.deny("No room left: raise Mission Control to expand the spaceport");return}[s,r]=h}this.placing={b:e,move:t},this.ui.select(null),this.world.startGhost({b:e,r:a,x:s,z:r,move:t,ok:!0}),this.ghostMoved();const[o,c]=on(e,a);this.world.focus(s+o/2-26,r+c/2-26);const l=ht("#place");l.classList.remove("hidden"),l.innerHTML=`<span class="lbl">${t?"Move":"Place"} ${re(at[e].name)}</span><button class="btn small" data-a="rotate">⟳ Rotate</button><button class="btn small red" data-a="unplace">✕</button><button class="btn small gold" data-a="place" id="placeOk">✓ ${t?"Move here":"Build here"}</button>`,this.world.sync(n)}ghostMoved(){const e=this.world.ghost;if(!e)return;e.ok=Cr(this.s,this.s.at,e.b,e.x,e.z,e.r,e.move).ok,this.world.syncGhost();const t=ht("#placeOk");t&&(t.disabled=!e.ok)}confirmPlace(){const e=this.world.ghost,t=this.placing;if(!e||!t)return;const n=this.s,s=t.move?tu(n,n.at,t.move,e.x,e.z,e.r):Qd(n,n.at,e.b,e.x,e.z,e.r);if(!s.ok){this.ui.deny(s.why);return}this.audio.play(t.move?"place":"build"),this.cancelPlace(),!t.move&&s.item&&this.ui.select(s.item.id),this.changed()}cancelPlace(){this.placing=null,this.world.endGhost(),ht("#place").classList.add("hidden"),this.world.sync(this.s)}setSetting(e,t){this.s.settings[e]=t,e==="sfx"&&this.audio.setVolume(t),e==="music"&&this.audio.setMusic(t),this.save()}save(){try{this.s.last=Math.max(this.s.last,Date.now()),this.platform.save(lh,JSON.stringify(this.s))}catch{}}reset(){this.s=Ko(),this.save(),location.reload()}}new X_().boot();
